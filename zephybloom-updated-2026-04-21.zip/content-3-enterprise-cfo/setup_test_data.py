"""
SETUP: Creare dati storici per testare il trending

Questo script:
1. Inizializza il database
2. Crea 2 mesi di dati (marzo e aprile)
3. Configura tutto per il test del trending
"""

import sys
sys.path.insert(0, '/Users/thestar23/Downloads/content-3-enterprise-cfo')

from db.models import init_db, CompanyMetricsHistory, Base
from db.session import init_session_factory, get_session
from core.company_metrics import save_company_metrics
from datetime import datetime

DATABASE_URL = "sqlite:///./zephytheory.db"

print("🔧 Inizializzando database...")

# Init database
engine = init_db(DATABASE_URL)
print("✅ Database inizializzato")

# Initialize session factory
init_session_factory()

# Get session
db = next(get_session())

try:
    # ========================================
    # MESE 1: MARZO 2026 (Base)
    # ========================================
    print("\n📊 Creando dati MARZO 2026 (benchmark)...")
    
    march_metrics = {
        "fatturato": 5_000_000,
        "costi_variabili": 3_250_000,  # 65%
        "costi_fissi": 900_000,
        "investimenti": 500_000,
        "gross_profit": 1_750_000,
        "gross_margin_pct": 35.0,
        "ebitda": 850_000,
        "ebitda_margin_pct": 17.0,
        "net_profit": 850_000,
        "net_margin_pct": 17.0,
        "roi_pct": 170.0,
    }
    
    from core.company_metrics import save_company_metrics
    
    record1 = save_company_metrics(
        session=db,
        tenant_id="demo-company",
        company_id="acme-us",
        company_name="Acme Manufacturing",
        metrics=march_metrics,
        measurement_date=datetime(2026, 3, 15),  # March 15, 2026
        industry="manufacturing",
        company_size="medium",
        notes="March 2026 baseline"
    )
    
    print(f"✅ MARZO: Margine lordo {march_metrics['gross_margin_pct']:.1f}%, EBITDA margin {march_metrics['ebitda_margin_pct']:.1f}%")
    
    # ========================================
    # MESE 2: APRILE 2026 (Declining)
    # ========================================
    print("\n📊 Creando dati APRILE 2026 (in calo)...")
    
    april_metrics = {
        "fatturato": 5_100_000,  # +2% revenue growth
        "costi_variabili": 3_468_000,  # +6.7% COGS (problema!)
        "costi_fissi": 920_000,  # +2.2%
        "investimenti": 500_000,
        "gross_profit": 1_632_000,  # Down
        "gross_margin_pct": 32.0,  # Down from 35%
        "ebitda": 712_000,
        "ebitda_margin_pct": 13.96,  # Down from 17%
        "net_profit": 712_000,
        "net_margin_pct": 13.96,
        "roi_pct": 142.4,
    }
    
    record2 = save_company_metrics(
        session=db,
        tenant_id="demo-company",
        company_id="acme-us",
        company_name="Acme Manufacturing",
        metrics=april_metrics,
        measurement_date=datetime(2026, 4, 15),  # April 15, 2026
        industry="manufacturing",
        company_size="medium",
        notes="April 2026 - margin compression"
    )
    
    print(f"✅ APRILE: Margine lordo {april_metrics['gross_margin_pct']:.1f}%, EBITDA margin {april_metrics['ebitda_margin_pct']:.1f}%")
    
    # ========================================
    # VERIFICA
    # ========================================
    print("\n📈 Verifica dati salvati:")
    
    from core.trend_analysis import TrendAnalyzer
    
    analyzer = TrendAnalyzer()
    trends = analyzer.analyze_metrics(april_metrics, march_metrics, "Acme Manufacturing")
    
    print(f"\n🔍 TREND ANALYSIS:")
    print(f"  Revenue:        {trends.revenue_trend.display_change}" if trends.revenue_trend else "  Revenue: N/A")
    print(f"  Gross Margin:   {trends.gross_margin_trend.display_change} ALERT={trends.gross_margin_trend.is_alert}" if trends.gross_margin_trend else "  Gross Margin: N/A")
    print(f"  EBITDA Margin:  {trends.ebitda_margin_trend.display_change} ALERT={trends.ebitda_margin_trend.is_alert}" if trends.ebitda_margin_trend else "  EBITDA: N/A")
    print(f"  Net Margin:     {trends.net_margin_trend.display_change} ALERT={trends.net_margin_trend.is_alert}" if trends.net_margin_trend else "  Net Margin: N/A")
    print(f"  Momentum:       {trends.momentum_score:.0f} ({trends.momentum_score:.0f} = {'📉 Declining' if trends.momentum_score < -10 else '→ Stable' if abs(trends.momentum_score) <= 10 else '📈 Improving'})")
    
    print("\n✅ Setup completato!")
    print("\nDati pronti per il test:")
    print("  - Tenant: demo-company")
    print("  - Company: acme-us (Acme Manufacturing)")
    print("  - Marzo 2026: Baseline con margini sani (35% gross)")
    print("  - Aprile 2026: Margin compression (32% gross) - ALERT!")
    
finally:
    db.close()
