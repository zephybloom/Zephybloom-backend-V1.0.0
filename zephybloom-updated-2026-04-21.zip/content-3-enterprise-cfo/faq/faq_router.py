# -*- coding: utf-8 -*-
# content/faq/faq_router.py

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml


def _candidate_paths(explicit_path: Optional[str | Path] = None) -> List[Path]:
    paths: List[Path] = []

    if explicit_path:
        paths.append(Path(explicit_path))

    paths.extend(
        [
            Path("faq/faq.yml"),
            Path("content/faq/faq.yml"),
            Path("/content/drive/MyDrive/content/faq/faq.yml"),
            Path("/content/content/faq/faq.yml"),
        ]
    )

    # dedup
    out: List[Path] = []
    seen = set()
    for p in paths:
        key = str(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def _resolve_existing_path(explicit_path: Optional[str | Path] = None) -> Optional[Path]:
    for p in _candidate_paths(explicit_path):
        if p.exists() and p.is_file():
            return p
    return None


def _safe_load_yaml(path: Path) -> List[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()

        data = yaml.safe_load(raw)

        if data is None:
            return []

        if isinstance(data, list):
            return data

        if isinstance(data, dict):
            for key in ("faq", "faqs", "items", "questions", "data"):
                value = data.get(key)
                if isinstance(value, list):
                    return value

        return []
    except Exception as e:
        print("YAML LOAD ERROR:", type(e).__name__, str(e))
        return []


def load_faq(faq_path: Optional[str | Path] = None) -> List[Dict[str, Any]]:
    resolved = _resolve_existing_path(faq_path)
    if resolved is None:
        return []
    return _safe_load_yaml(resolved)


def _normalize(text: str) -> str:
    return " ".join(str(text or "").lower().strip().split())


def _extract_questions(item: Dict[str, Any]) -> List[str]:
    questions: List[str] = []

    # formato flat moderno
    if "question" in item:
        q = item.get("question")
        if isinstance(q, str) and q.strip():
            questions.append(q.strip())

    if "aliases" in item:
        aliases = item.get("aliases", [])
        if isinstance(aliases, list):
            for a in aliases:
                if isinstance(a, str) and a.strip():
                    questions.append(a.strip())
        elif isinstance(aliases, str) and aliases.strip():
            questions.append(aliases.strip())

    # eventuale formato alternativo
    if "questions" in item:
        qs = item.get("questions", [])
        if isinstance(qs, list):
            for q in qs:
                if isinstance(q, str) and q.strip():
                    questions.append(q.strip())
        elif isinstance(qs, str) and qs.strip():
            questions.append(qs.strip())

    # dedup
    deduped: List[str] = []
    seen = set()
    for q in questions:
        key = q.lower().strip()
        if key and key not in seen:
            seen.add(key)
            deduped.append(q)

    return deduped


def _score_question(user_text: str, candidate: str) -> int:
    u = _normalize(user_text)
    c = _normalize(candidate)

    if not u or not c:
        return 0

    if u == c:
        return 100

    if c in u:
        return 90

    if u in c:
        return 85

    u_tokens = set(u.split())
    c_tokens = set(c.split())

    if not u_tokens or not c_tokens:
        return 0

    overlap = len(u_tokens & c_tokens)
    if overlap == 0:
        return 0

    return int((overlap / max(1, len(c_tokens))) * 100)


def route_faq(text: str, faq_path: Optional[str | Path] = None) -> Dict[str, Any]:
    faq_data = load_faq(faq_path)

    best_score = 0
    best_item: Optional[Dict[str, Any]] = None
    best_match: Optional[str] = None

    for item in faq_data:
        if not isinstance(item, dict):
            continue

        questions = _extract_questions(item)
        answer = str(item.get("answer", "") or "").strip()

        if not questions or not answer:
            continue

        for q in questions:
            score = _score_question(text, q)
            if score > best_score:
                best_score = score
                best_item = item
                best_match = q

    if best_item is None or best_score < 60:
        return {
            "matched": False,
            "answer": None,
            "score": 0,
            "item": None,
            "category": None,
            "matched_question": None,
        }

    return {
        "matched": True,
        "answer": best_item.get("answer"),
        "score": best_score,
        "item": best_item,
        "category": best_item.get("category") or best_item.get("intent"),
        "matched_question": best_match,
    }
