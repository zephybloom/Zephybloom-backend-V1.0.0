# content/faq/validate_faq.py
from __future__ import annotations
import sys
import argparse
import collections
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

try:
    import yaml  # PyYAML
except Exception:
    print("Errore: manca PyYAML. Installa con: pip install pyyaml", file=sys.stderr)
    sys.exit(2)

# --------- Config minime per qualità dataset ---------
MIN_Q_PER_ENTRY = 1         # almeno 1 variante domanda
MAX_Q_PER_ENTRY = 10        # massimo varianti per evitare rumore
MIN_ANSWER_LEN = 20         # evitare risposte troppo corte
MAX_ANSWER_LEN = 2000       # evitare papiri in FAQ (consigliato: 120–600)
ALLOWED_TOP_KEYS = {"category", "qas"}
ALLOWED_QAS_KEYS = {"q", "a", "tags"}
ALLOWED_FLAT_KEYS = {"question", "aliases", "intent", "category", "answer", "tags"}

@dataclass
class Issue:
    level: str   # "ERROR" | "WARN"
    msg: str
    where: str   # es. "categoria: X / idx: 3"

@dataclass
class Stats:
    categories: Dict[str, int] = field(default_factory=lambda: collections.defaultdict(int))
    variants: Dict[str, int] = field(default_factory=lambda: collections.defaultdict(int))
    total_entries: int = 0
    total_pairs: int = 0
    total_variants: int = 0

def load_yaml(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)

def _norm_text(s: str) -> str:
    return " ".join((s or "").strip().split()).lower()

def validate_structure(data: Any) -> Tuple[List[Issue], Stats]:
    issues: List[Issue] = []
    stats = Stats()

    if not isinstance(data, list):
        issues.append(Issue("ERROR", "Il root YAML deve essere una lista di categorie.", "root"))
        return issues, stats

    if _looks_like_flat_faq(data):
        return _validate_flat_faq(data)

    seen_q_normalized: set[str] = set()

    for ci, cat in enumerate(data):
        where_cat = f"categoria_index={ci}"
        if not isinstance(cat, dict):
            issues.append(Issue("ERROR", "Ogni elemento della lista deve essere un dict.", where_cat))
            continue

        extrakeys = set(cat.keys()) - ALLOWED_TOP_KEYS
        if extrakeys:
            issues.append(Issue("WARN", f"Chiavi sconosciute a livello categoria: {sorted(extrakeys)}", where_cat))

        category = str(cat.get("category", "")).strip()
        if not category:
            issues.append(Issue("ERROR", "Campo 'category' mancante o vuoto.", where_cat))
            continue

        qas = cat.get("qas")
        if not isinstance(qas, list) or not qas:
            issues.append(Issue("ERROR", "Campo 'qas' mancante o vuoto; deve essere lista.", f"category={category}"))
            continue

        stats.categories[category] += 1  # numero blocchi categoria
        for qi, qa in enumerate(qas):
            where = f"category={category} / qas_idx={qi}"
            if not isinstance(qa, dict):
                issues.append(Issue("ERROR", "Ogni 'qas' deve essere un dict.", where))
                continue

            extrakeys = set(qa.keys()) - ALLOWED_QAS_KEYS
            if extrakeys:
                issues.append(Issue("WARN", f"Chiavi sconosciute in qas: {sorted(extrakeys)}", where))

            q = qa.get("q")
            a = qa.get("a")

            # q può essere string o lista di stringhe
            variants: List[str] = []
            if isinstance(q, str):
                variants = [q]
            elif isinstance(q, list) and all(isinstance(x, str) for x in q):
                variants = q
            else:
                issues.append(Issue("ERROR", "Campo 'q' deve essere string o lista di stringhe.", where))
                continue

            if len(variants) < MIN_Q_PER_ENTRY:
                issues.append(Issue("ERROR", f"Almeno {MIN_Q_PER_ENTRY} variante domanda richiesta.", where))
            if len(variants) > MAX_Q_PER_ENTRY:
                issues.append(Issue("WARN", f"Troppe varianti domanda ({len(variants)} > {MAX_Q_PER_ENTRY}).", where))

            # risposta
            if not isinstance(a, str) or not a.strip():
                issues.append(Issue("ERROR", "Campo 'a' deve essere una string non vuota.", where))
                continue
            alen = len(a.strip())
            if alen < MIN_ANSWER_LEN:
                issues.append(Issue("WARN", f"Risposta molto breve ({alen} char) — valuta di arricchirla.", where))
            if alen > MAX_ANSWER_LEN:
                issues.append(Issue("WARN", f"Risposta molto lunga ({alen} char) — valuta di sintetizzare.", where))

            # duplicati globali (normalizzati)
            for v in variants:
                vn = _norm_text(v)
                if vn in seen_q_normalized:
                    issues.append(Issue("WARN", "Domanda duplicata (variante già vista).", where + f" / q='{v[:80]}'"))
                else:
                    seen_q_normalized.add(vn)

            # stats
            stats.total_entries += 1
            stats.total_pairs += 1
            stats.variants[category] += len(variants)
            stats.total_variants += len(variants)

    return issues, stats


def _looks_like_flat_faq(data: List[Any]) -> bool:
    return any(isinstance(item, dict) and ("question" in item or "answer" in item) for item in data)


def _validate_flat_faq(data: List[Any]) -> Tuple[List[Issue], Stats]:
    issues: List[Issue] = []
    stats = Stats()
    seen_q_normalized: set[str] = set()

    for idx, item in enumerate(data):
        where = f"faq_idx={idx}"
        if not isinstance(item, dict):
            issues.append(Issue("ERROR", "Ogni FAQ deve essere un dict.", where))
            continue

        extrakeys = set(item.keys()) - ALLOWED_FLAT_KEYS
        if extrakeys:
            issues.append(Issue("WARN", f"Chiavi sconosciute in FAQ: {sorted(extrakeys)}", where))

        question = item.get("question")
        if not isinstance(question, str) or not question.strip():
            issues.append(Issue("ERROR", "Campo 'question' mancante o vuoto.", where))
            continue

        variants = [question]
        aliases = item.get("aliases", [])
        if isinstance(aliases, list):
            if not all(isinstance(alias, str) for alias in aliases):
                issues.append(Issue("ERROR", "Campo 'aliases' deve contenere solo stringhe.", where))
                continue
            variants.extend(aliases)
        elif isinstance(aliases, str):
            variants.append(aliases)
        elif aliases:
            issues.append(Issue("ERROR", "Campo 'aliases' deve essere stringa o lista di stringhe.", where))
            continue

        if len(variants) < MIN_Q_PER_ENTRY:
            issues.append(Issue("ERROR", f"Almeno {MIN_Q_PER_ENTRY} variante domanda richiesta.", where))
        if len(variants) > MAX_Q_PER_ENTRY:
            issues.append(Issue("WARN", f"Troppe varianti domanda ({len(variants)} > {MAX_Q_PER_ENTRY}).", where))

        answer = item.get("answer")
        if not isinstance(answer, str) or not answer.strip():
            issues.append(Issue("ERROR", "Campo 'answer' deve essere una string non vuota.", where))
            continue

        alen = len(answer.strip())
        if alen < MIN_ANSWER_LEN:
            issues.append(Issue("WARN", f"Risposta molto breve ({alen} char) — valuta di arricchirla.", where))
        if alen > MAX_ANSWER_LEN:
            issues.append(Issue("WARN", f"Risposta molto lunga ({alen} char) — valuta di sintetizzare.", where))

        category = str(item.get("category") or item.get("intent") or "flat").strip()
        stats.categories[category] += 1
        stats.total_entries += 1
        stats.total_pairs += 1
        stats.variants[category] += len(variants)
        stats.total_variants += len(variants)

        for variant in variants:
            vn = _norm_text(variant)
            if vn in seen_q_normalized:
                issues.append(Issue("WARN", "Domanda duplicata (variante già vista).", where + f" / q='{variant[:80]}'"))
            else:
                seen_q_normalized.add(vn)

    return issues, stats

def print_report(issues: List[Issue], stats: Stats, *, strict: bool) -> int:
    # Riepilogo
    print("\n=== RIEPILOGO FAQ ===")
    print(f"Blocchi (category items): {sum(stats.categories.values())}")
    print(f"Q/A entries:              {stats.total_pairs}")
    print(f"Varianti totali (q):      {stats.total_variants}\n")

    if stats.categories:
        print("Per categoria:")
        for cat in sorted(stats.categories.keys()):
            print(f"  - {cat}: entries={stats.categories[cat]}, varianti_domande={stats.variants.get(cat, 0)}")
        print()

    # Problemi
    errors = [i for i in issues if i.level == "ERROR"]
    warns  = [i for i in issues if i.level == "WARN"]

    if errors:
        print("=== ERRORI ===")
        for e in errors:
            print(f"[ERROR] {e.where}: {e.msg}")
        print()

    if warns:
        print("=== AVVISI ===")
        for w in warns:
            print(f"[WARN]  {w.where}: {w.msg}")
        print()

    if strict and errors:
        print(f"‼️  {len(errors)} errori: esco con codice 1 (modalità --strict).")
        return 1

    print("✅ Validazione completata.")
    if not errors and not warns:
        print("Nessun problema rilevato.")
    elif not errors:
        print("Nessun errore bloccante. Sono presenti avvisi (migliorabili).")
    else:
        print("Sono presenti errori (da correggere).")
    return 0

def main(argv: List[str]) -> int:
    ap = argparse.ArgumentParser(description="Validator per faq/faq.yml")
    ap.add_argument("path", nargs="?", default="faq/faq.yml", help="Percorso file YAML (default: faq/faq.yml)")
    ap.add_argument("--strict", action="store_true", help="Esci con codice 1 se ci sono ERROR")
    args = ap.parse_args(argv)

    try:
        data = load_yaml(args.path)
    except FileNotFoundError:
        print(f"Errore: file non trovato: {args.path}", file=sys.stderr)
        return 2
    except yaml.YAMLError as e:
        print(f"Errore YAML: {e}", file=sys.stderr)
        return 2

    issues, stats = validate_structure(data)
    return print_report(issues, stats, strict=args.strict)

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
