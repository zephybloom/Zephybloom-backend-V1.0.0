# 🎨 ZephyBloom Design System v1.0

> **Status:** Specification Document (PRE-IMPLEMENTATION)  
> **Purpose:** Complete design specification before UI development  
> **Target:** Premium fintech SaaS (Stripe/Linear/Notion level)

---

## 📐 PART 1: BRAND IDENTITY & PERCEPTION

### Brand Essence
- **Name:** ZephyBloom
- **Tagline:** "Your AI CFO, Right in Your Dashboard"
- **Positioning:** Premium CFO Intelligence + Accessibility
- **Perception:** Enterprise-grade | Professional | Trustworthy | Modern | Authoritative

### Personality
- **Tone:** Confident but approachable
- **Vibe:** Elegant minimalism meets strategic depth
- **Visual:** Clean, spacious, powerful
- **Feeling:** "We know finance; you're in expert hands"

### Key Attributes
✓ Premium  
✓ Trustworthy  
✓ Intelligent  
✓ Efficient  
✓ Elegant  
✓ Strategic  

---

## 🎨 PART 2: COLOR PALETTE

### Primary Colors (Dark Mode - Primary)

| Name | Hex | RGB | Usage |
|------|-----|-----|-------|
| **Background Base** | `#0A0E27` | 10, 14, 39 | Page background |
| **Surface Primary** | `#131829` | 19, 24, 41 | Cards, panels |
| **Surface Secondary** | `#1A1F3A` | 26, 31, 58 | Elevated surfaces |
| **Surface Tertiary** | `#242B4A` | 36, 43, 74 | Hover state |
| **Border Subtle** | `#2D3454` | 45, 52, 84 | Soft dividers |
| **Border Strong** | `#3D4466` | 61, 68, 102 | Emphasized borders |

### Accent Colors (Tech-Forward)

| Name | Hex | RGB | Usage |
|------|-----|-----|-------|
| **Electric Blue** | `#0EA5E9` | 14, 165, 233 | Primary action, focus |
| **Cyan Edge** | `#06B6D4` | 6, 182, 212 | Secondary action |
| **Violet Power** | `#A78BFA` | 167, 139, 250 | Tertiary accent, links |
| **Amber Alert** | `#FBBF24` | 251, 191, 36 | Warnings, attention |
| **Emerald Success** | `#10B981` | 16, 185, 129 | Success, positive delta |
| **Rose Critical** | `#F43F5E` | 244, 63, 94 | Errors, critical |

### Text Colors

| Name | Hex | Usage |
|------|-----|-------|
| **Primary Text** | `#F1F5F9` | Body text, primary |
| **Secondary Text** | `#CBD5E1` | Muted, secondary |
| **Tertiary Text** | `#94A3B8` | Helper text, labels |
| **Disabled Text** | `#64748B` | Disabled states |

### Chart/Data Colors

| Name | Hex | Usage |
|------|-----|-------|
| **Revenue** | `#0EA5E9` | Income visualization |
| **Costs** | `#F43F5E` | Expense visualization |
| **Margin** | `#10B981` | Profit/margin viz |
| **EBITDA** | `#A78BFA` | EBITDA visualization |
| **Forecast** | `#FBBF24` | Projected/scenario viz |

### Semantic Colors

```
✓ Success     → #10B981 (Emerald)
⚠ Warning    → #FBBF24 (Amber)
✗ Error      → #F43F5E (Rose)
ℹ Info       → #0EA5E9 (Electric Blue)
⊙ Pending    → #64748B (Gray)
```

---

## 🔤 PART 3: TYPOGRAPHY

### Font Stack (System First, Fallback)

```css
Primary Font:   'Segoe UI', -apple-system, BlinkMacSystemFont, 'Helvetica Neue'
Code Font:      'Fira Code', 'Monaco', monospace
```

### Type Scale (8px baseline)

| Size | Rem | Px | Weight | Usage |
|------|-----|----|---------|----|
| **Display 1** | 3.5rem | 56px | 700 | Page hero, main headline |
| **Display 2** | 2.8rem | 44px | 700 | Section headline |
| **H1** | 2rem | 32px | 600 | Page title |
| **H2** | 1.5rem | 24px | 600 | Section title |
| **H3** | 1.25rem | 20px | 600 | Subsection |
| **H4** | 1.125rem | 18px | 600 | Component title |
| **Body Large** | 1.125rem | 18px | 400 | Primary body text |
| **Body** | 1rem | 16px | 400 | Default body text |
| **Body Small** | 0.875rem | 14px | 400 | Secondary text |
| **Label** | 0.75rem | 12px | 500 | Labels, captions |
| **Caption** | 0.75rem | 12px | 400 | Tiny text |

### Font Weights

- **400** Regular (body text)
- **500** Medium (labels, toggles)
- **600** Semibold (headings, emphasis)
- **700** Bold (hero, strong emphasis)

### Line Heights

- **Headlines:** 1.2 (tight)
- **Body:** 1.6 (readable)
- **Small:** 1.5 (compact)

---

## 📏 PART 4: SPACING SYSTEM (8px Grid)

### Base Unit: 8px

```
4px  = 0.5x (micro)
8px  = 1x  (xs)
12px = 1.5x (sm)
16px = 2x  (md)
24px = 3x  (lg)
32px = 4x  (xl)
40px = 5x  (2xl)
48px = 6x  (3xl)
56px = 7x  (4xl)
64px = 8x  (5xl)
80px = 10x (6xl)
96px = 12x (7xl)
```

### Padding/Margin System

| Component | Value |
|-----------|-------|
| **Card Padding** | 24px |
| **Container Padding** | 32px |
| **Gutter (Column Gap)** | 24px |
| **Row Gap** | 16px |
| **Button Padding (H)** | 16px |
| **Button Padding (V)** | 12px |
| **Input Padding** | 12px |
| **Section Margin** | 64px |
| **Component Gap** | 8px |

---

## 🔘 PART 5: COMPONENTS SPECIFICATION

### 5.1 BUTTONS

#### Primary Button
```
Background:    #0EA5E9 (Electric Blue)
Text:          #0A0E27 (Dark)
Padding:       12px 16px
Border Radius: 8px
Font Size:     1rem (16px)
Font Weight:   600
Cursor:        pointer
Transition:    all 150ms ease

States:
  Default:     bg-[#0EA5E9] text-[#0A0E27]
  Hover:       bg-[#0284C7] (darker blue) shadow-md
  Active:      bg-[#0369A1] (darkest)
  Disabled:    bg-[#64748B] text-[#94A3B8] opacity-50
  Loading:     spinner inside, disabled
```

#### Secondary Button
```
Background:    transparent
Border:        1px solid #3D4466
Text:          #0EA5E9
Padding:       12px 16px
Border Radius: 8px

States:
  Default:     border-[#3D4466] text-[#0EA5E9]
  Hover:       border-[#0EA5E9] bg-[#0EA5E9]/5%
  Active:      border-[#0284C7] bg-[#0EA5E9]/10%
```

#### Ghost Button
```
Background:    transparent
Text:          #CBD5E1
Padding:       12px 16px
Border Radius: 8px

States:
  Default:     text-[#CBD5E1]
  Hover:       text-[#F1F5F9] bg-[#1A1F3A]
  Active:      text-[#0EA5E9]
```

#### Icon Button
```
Size:          40px × 40px
Background:    transparent
Padding:       8px
Border Radius: 8px
Icon Size:     24px

States:
  Default:     text-[#CBD5E1]
  Hover:       bg-[#1A1F3A] text-[#F1F5F9]
  Active:      text-[#0EA5E9]
```

### 5.2 INPUTS & FORMS

#### Text Input
```
Background:    #131829
Border:        1px solid #2D3454
Text Color:    #F1F5F9
Placeholder:   #94A3B8
Padding:       12px 16px
Border Radius: 8px
Font Size:     1rem
Height:        44px (44px = 11 × 4px grid)

States:
  Default:     border-[#2D3454] bg-[#131829]
  Hover:       border-[#3D4466]
  Focus:       border-[#0EA5E9] shadow-[0 0 0 3px rgba(14,165,233,0.1)]
  Disabled:    bg-[#0A0E27] border-[#1A1F3A] opacity-50
  Error:       border-[#F43F5E]
```

#### Select Dropdown
```
Same as text input + chevron icon
Chevron Color: #94A3B8
```

#### Checkbox
```
Size:          20px × 20px
Border Radius: 4px
Background:    #131829
Border:        2px solid #2D3454

States:
  Default:     border-[#2D3454]
  Checked:     bg-[#0EA5E9] border-[#0EA5E9]
  Hover:       border-[#3D4466]
  Disabled:    opacity-50
```

#### Toggle / Switch
```
Width:         48px
Height:        28px
Background:    #1A1F3A
Border Radius: 14px (pill)

States:
  Off:         bg-[#1A1F3A]
  On:          bg-[#10B981]
  Knob:        white circle inside, smooth transition 200ms
```

#### Radio Button
```
Size:          20px × 20px
Border Radius: 50%
Border:        2px solid #2D3454

States:
  Default:     border-[#2D3454]
  Selected:    border-[#0EA5E9] + inner dot 8px
  Disabled:    opacity-50
```

### 5.3 CARDS

#### KPI Card (Dashboard)
```
Background:    #131829
Border:        1px solid #2D3454
Border Radius: 12px
Padding:       24px
Box Shadow:    0 4px 6px rgba(0,0,0,0.1)

Layout:
- Header (title + icon or trend)
- Value (large number)
- Meta (subtitle, unit, change %)

Hover State:   border-[#3D4466] shadow-lg elevation increase
```

#### Data Card
```
Background:    #1A1F3A
Border:        none
Border Radius: 8px
Padding:       16px
Shadow:        0 2px 4px rgba(0,0,0,0.1)
```

#### Featured Card (Call-to-Action)
```
Background:    linear-gradient(135deg, #0EA5E9, #06B6D4)
Border:        none
Border Radius: 12px
Padding:       32px
Text Color:    white
Shadow:        0 8px 16px rgba(14,165,233,0.2)
```

### 5.4 TABS

```
Background:    transparent
Border Bottom: 1px solid #2D3454
Padding:       12px (vertical)
Font Size:     1rem

States:
  Inactive:    text-[#94A3B8] border-none
  Active:      text-[#0EA5E9] border-bottom-[3px solid #0EA5E9]
  Hover:       text-[#CBD5E1]
```

### 5.5 BADGES & TAGS

#### Status Badge
```
Background:    varies (#10B981 for success, #F43F5E for error, etc.)
Text:          white
Padding:       4px 12px
Border Radius: 4px
Font Size:     0.75rem
Font Weight:   600
```

#### Tag/Pill
```
Background:    #1A1F3A
Text:          #CBD5E1
Padding:       6px 12px
Border Radius: 16px
Font Size:     0.875rem
Border:        1px solid #2D3454
```

### 5.6 MODALS & DIALOGS

```
Background:    #131829 (card) over #0A0E27 with 60% opacity overlay
Border:        1px solid #2D3454
Border Radius: 16px
Padding:       32px
Max Width:     600px (medium dialog)
Box Shadow:    0 20px 40px rgba(0,0,0,0.3)

Overlay:
  Background:  rgba(0,0,0,0.6)
  Transition:  200ms ease
  Backdrop Filter: blur(4px) (optional)

Close Button:  Top-right, icon, hover underline
```

### 5.7 LOADING STATES

#### Spinner
```
Size:          24px or 40px (configurable)
Color:         #0EA5E9
Animation:     360° rotation 1.5s linear infinite
Style:         SVG circle with stroke-dasharray
```

#### Skeleton (Placeholder)
```
Background:    #1A1F3A
Animation:     pulse opacity 0.5 → 1 → 0.5 (2s ease-in-out)
Border Radius: match component (4px for text, 8px for cards)
```

#### Progress Bar
```
Background:    #1A1F3A
Fill Color:    #0EA5E9 or #10B981
Height:        4px
Border Radius: 2px
Animation:     smooth fill transition 300ms ease
```

### 5.8 TOOLTIPS & POPOVERS

```
Background:    #1A1F3A
Text:          #F1F5F9
Border:        1px solid #2D3454
Padding:       12px 16px
Border Radius: 8px
Font Size:     0.875rem
Box Shadow:    0 10px 20px rgba(0,0,0,0.2)
Arrow/Tail:    CSS triangle, #1A1F3A fill

Trigger:       Hover or focus
Delay:         300ms show, instant dismiss
Animation:     fade-in 150ms ease
```

---

## 📐 PART 6: ELEVATION & SHADOWS

### Shadow System

```css
/* Elevation Levels */

0 (Flat):       none
1 (Raised):     0 1px 2px rgba(0, 0, 0, 0.05)
2 (Card):       0 4px 6px rgba(0, 0, 0, 0.1)
3 (Hover):      0 10px 15px rgba(0, 0, 0, 0.1)
4 (Dialog):     0 20px 25px rgba(0, 0, 0, 0.15)
5 (Popover):    0 25px 50px rgba(0, 0, 0, 0.25)
```

### Border Radius System

```
2px   → Inputs, small UI
4px   → Badges, chips
8px   → Buttons, cards, modals
12px  → Featured cards, prominent dialogs
16px  → Large modals, hero sections
```

---

## 🎬 PART 7: MOTION & ANIMATIONS

### Transition Durations

```
Fast:     150ms (hover states, simple changes)
Medium:   200ms (modal open, tab switch)
Slow:     300ms (page transitions, complex animations)
```

### Easing Functions

```
ui-ease:      cubic-bezier(0.4, 0, 0.2, 1)  [Standard material]
ease-in:      cubic-bezier(0.4, 0, 1, 1)    [Accelerate]
ease-out:     cubic-bezier(0, 0, 0.2, 1)    [Decelerate]
ease-in-out:  cubic-bezier(0.4, 0, 0.2, 1)  [Smooth]
```

### Micro-Interactions

```
Button Hover:      Scale 1.02 + shadow elevation
Card Hover:        Border color shift + shadow +2
Input Focus:       Glow shadow (0 0 0 3px accent/10%)
Tab Activate:      Slide indicator + fade text
Checkbox Toggle:   Scale 1.1 briefly then back
Loading:           Smooth rotation 1.5s infinite
Toast/Alert:       Slide-in from top/bottom 200ms, slide-out 150ms
Page Load:          Fade-in 300ms + stagger children 50ms each
Scroll Reveal:      Fade-in + translate-y(-10px) on viewport entry
```

### Avoid

```
❌ Bounce easing (too casual)
❌ Spring animations (not enterprise)
❌ Delay > 300ms (feels slow)
❌ Jingly sounds or vibration
```

---

## 🎨 PART 8: ICONS & ICONOGRAPHY

### Icon System

```
Size Options:     16px, 20px, 24px, 32px, 40px
Style:            Outlined (stroke-based, NOT filled for most)
Stroke Width:     1.5px (24px+), 2px (20px-), 2.5px (16px-)
Color Primary:    #CBD5E1 (default), #0EA5E9 (active/accent)
Color Secondary:  #94A3B8 (muted)

Naming:           icon-[name] (e.g., icon-chart, icon-settings)
Format:           SVG (preferred for scaling)
Source:           Consistent set (Heroicons, Feather, or custom)
```

### Icon Palette

```
Neutral:          #CBD5E1
Active/Primary:   #0EA5E9
Success:          #10B981
Warning:          #FBBF24
Error:            #F43F5E
Disabled:         #64748B
```

---

## 📐 PART 9: LAYOUT SYSTEM

### Container Sizes

```
Max Content Width:  1280px (container-2xl)
Padding (Desktop):  32px sides
Padding (Tablet):   24px sides
Padding (Mobile):   16px sides
```

### Grid System (12-column)

```
Desktop:   12 columns, 24px gutter
Tablet:    8 columns, 16px gutter
Mobile:    4 columns, 12px gutter
Min Width: 320px
Max Width: 1920px
```

### Breakpoints

```
xs:  320px   (mobile small)
sm:  640px   (mobile large)
md:  768px   (tablet)
lg:  1024px  (desktop small)
xl:  1280px  (desktop medium)
2xl: 1536px  (desktop large)
```

### Common Layouts

```
Sidebar + Content:
  Sidebar: 280px fixed
  Content: calc(100% - 280px)
  Gutter: 24px

Two-Column Grid:
  Column Width: calc(50% - 12px)
  
Three-Column Grid:
  Column Width: calc(33.333% - 16px)

Stacked (Mobile):
  Full width (100% - padding)
  Stack at < md breakpoint
```

---

## 📊 PART 10: DATA VISUALIZATION

### Chart Colors (Consistent with Palette)

```
Primary Series:    #0EA5E9 (Electric Blue)
Secondary:         #06B6D4 (Cyan)
Tertiary:          #A78BFA (Violet)
Success/Positive:  #10B981 (Emerald)
Negative/Costs:    #F43F5E (Rose)
Neutral/Forecast:  #FBBF24 (Amber)
```

### Chart Style

```
Background:        Transparent (let card bg show)
Grid Lines:        #2D3454 (subtle)
Axis Text:         #94A3B8
Legend:            Compact, below chart
Tooltip:           Dark popover with shadow
Animation:         Smooth 500ms easing on load
Legend Items:       12px label + 12px colored square
```

### Table Styling

```
Header Row:        bg-[#1A1F3A] border-b-[1px solid #2D3454]
Body Rows:         bg-[#131829] striped alt bg-[#1A1F3A]
Row Height:        48px (compact), 56px (comfortable)
Cell Padding:      12px
Border:            1px solid #2D3454 (subtle)
Hover Row:         bg-[#1A1F3A] (subtle change)
Cell Alignment:    Left for text, right for numbers
```

---

## 🗺️ PART 11: SITEMAP

```
ZephyBloom Product Structure

├─ PUBLIC PAGES
│  ├─ Landing Page (/)
│  ├─ Pricing (/pricing)
│  ├─ Features (/features)
│  ├─ Docs (/docs)
│  └─ Blog (/blog)
│
├─ AUTH PAGES
│  ├─ Login (/login)
│  ├─ Register (/register)
│  ├─ Forgot Password (/auth/forgot-password)
│  └─ Reset Password (/auth/reset-password/:token)
│
├─ ONBOARDING (POST-SIGNUP)
│  ├─ Welcome (/onboarding/welcome)
│  ├─ Company Info (/onboarding/company)
│  ├─ Financial Data Upload (/onboarding/upload)
│  ├─ Data Validation (/onboarding/validate)
│  └─ First Dashboard (/onboarding/complete)
│
├─ PRODUCT (AUTHENTICATED)
│  ├─ Dashboard
│  │  ├─ Main Dashboard (/dashboard)
│  │  ├─ KPI Details (/dashboard/kpi/:id)
│  │  └─ Historical View (/dashboard/history)
│  │
│  ├─ Scenarios & Planning
│  │  ├─ Scenarios (/scenarios)
│  │  ├─ Multi-Scenario View (/scenarios/compare)
│  │  ├─ What-If Analysis (/whatif)
│  │  └─ Forecasting (/forecast)
│  │
│  ├─ Decisions & Analysis
│  │  ├─ Decision Hub (/decisions)
│  │  ├─ ROI Calculator (/decisions/roi)
│  │  ├─ Hiring Planner (/decisions/hiring)
│  │  └─ Pricing Strategy (/decisions/pricing)
│  │
│  ├─ Chat CFO
│  │  ├─ Chat Interface (/chat)
│  │  ├─ Conversation History (/chat/history)
│  │  └─ Insights (/chat/insights)
│  │
│  ├─ Data & Settings
│  │  ├─ Data Upload (/data/upload)
│  │  ├─ Data Sources (/data/sources)
│  │  ├─ Account Settings (/settings/account)
│  │  ├─ Company Settings (/settings/company)
│  │  ├─ Billing (/settings/billing)
│  │  ├─ Team & Permissions (/settings/team)
│  │  └─ Integrations (/settings/integrations)
│  │
│  └─ Help & Resources
│     ├─ Knowledge Base (/help)
│     ├─ Contact Support (/help/support)
│     └─ Feedback (/help/feedback)
│
└─ ADMIN (IF APPLICABLE)
   ├─ Admin Dashboard (/admin)
   ├─ Users Management (/admin/users)
   ├─ Billing Management (/admin/billing)
   └─ System Settings (/admin/settings)
```

---

## 👥 PART 12: USER JOURNEY & FLOWS

### Journey 1: New Sign-Up → First Use

```
1. AWARENESS
   User lands on Landing Page (/)
   Sees value prop, pricing, CTA
   Action: Click "Start Free Trial" or "Sign Up"

2. SIGNUP
   → Register (/register)
   Fields: Email, Password, Company Name
   Action: Create account

3. WELCOME
   → Onboarding Welcome (/onboarding/welcome)
   Brief intro video or text
   "Let's get you started" button

4. COMPANY INFO
   → Company Info Form (/onboarding/company)
   Fields: 
     - Company Name
     - Industry/Sector
     - Company Size
     - Annual Revenue (approx)
   Action: Next

5. DATA UPLOAD
   → Upload (/onboarding/upload)
   Options:
     - Upload CSV/Excel (income statement, balance sheet)
     - Manual Data Entry
     - API Integration (future)
   File preview + validation
   Action: Confirm data

6. VALIDATION
   → Data Check (/onboarding/validate)
   System checks data integrity
   Shows any warnings/issues
   User confirms or fixes
   Action: Continue

7. FIRST DASHBOARD
   → Dashboard (/dashboard)
   System shows 
     - Initial KPI Scorecard
     - Key Findings
     - Top 3 Actions
   Celebration moment ("Your CFO is ready!")

8. EXPLORATION
   User explores:
   → Chat CFO (/chat)
   → Scenarios (/scenarios)
   → Decisions (/decisions)
   Action: Explore features
```

### Journey 2: Returning Power User

```
1. LOGIN
   → Login Page (/login)
   Credentials or SSO
   
2. DASHBOARD
   → Main Dashboard (/dashboard)
   Immediate view of:
     - Current KPIs
     - Changes since last visit
     - Alerts/Recommendations
     - Quick actions
   
3. DECISION-MAKING
   User navigates to specific need:
   → /scenarios (for planning)
   → /decisions/roi (for evaluation)
   → /chat (for strategic guidance)
   → /forecast (for projections)

4. EXPORT/SHARE
   User exports findings
   Shares with team/board
   Action: Export PDF, Share Link
```

### Journey 3: Chat CFO Interaction

```
1. USER OPENS CHAT
   → /chat
   Chat window visible
   Input field ready
   Suggested prompts shown
   
2. USER TYPES QUERY
   "How can I improve profitability?"
   "What's the risk in scenario?"
   "Should I hire more people?"
   
3. CFO RESPONDS
   - Analyzes data
   - Provides strategic insight
   - Offers 2-3 actionable recommendations
   - Suggests next steps
   
4. USER FOLLOWS UP
   Chat remembers context
   CFO refines recommendations
   User can request calculations/simulations
```

---

## 🎯 PART 13: KEY PAGE FLOWS

### Dashboard Flow
```
Navbar (persistent) → Main Content
                   → Sidebar (persistent left)
                   → KPI Cards Grid (top)
                   → Charts Section (middle)
                   → Data Table (bottom)
                   → Chat Docked (right or bottom-right)
```

### Onboarding Flow
```
Full-screen progressive form
Step indicator (1/5, 2/5, etc.)
Progress bar (visual)
Back/Next buttons
Clear sections
No distractions
```

### Chat Flow
```
Chat window (full-screen or docked)
Message history (scrollable, timestamped)
Input field (rich text, file attachment)
Suggested prompts below input
Typing indicator when CFO "thinking"
```

---

## 📋 PART 14: COMPONENT INVENTORY (Reusable)

### Atoms (Smallest Units)
```
□ Button (Primary, Secondary, Ghost, Icon)
□ Input (Text, Number, Select, Password)
□ Checkbox
□ Radio Button
□ Toggle
□ Badge / Tag
□ Icon
□ Text Styles (Headings, Body, Label)
□ Divider
□ Spinner
□ Loading Skeleton
```

### Molecules (Component Groups)
```
□ Form Input Group (Label + Input + Helper text + Error)
□ Card (Header + Body + Footer)
□ Button Group
□ Breadcrumb
□ Pagination
□ Tab Group
□ Status Indicator (Badge + Label)
□ List Item (Avatar + Title + Subtitle)
□ KPI Card (Header + Value + Delta)
□ Tooltip
```

### Organisms (Complex Components)
```
□ Navbar (Logo + Menu + User Menu)
□ Sidebar Navigation
□ Header (Breadcrumb + Title + Actions)
□ Form (Multiple inputs + validation + submit)
□ Table (Header + Rows + Pagination + Actions)
□ Chart (Chart.js or Recharts component)
□ Modal/Dialog
□ Upload Area (Drag-drop + file input)
□ Chat Interface (Messages + Input + Suggestions)
□ KPI Grid (Multiple KPI cards)
```

### Pages (Full Templates)
```
□ Landing Page
□ Login/Register
□ Onboarding Steps
□ Dashboard
□ Scenarios Page
□ Decisions Page
□ Chat Page
□ Settings Page
```

---

## ✨ PART 15: SPECIAL DESIGN DETAILS

### Empty States
```
Icon (large, themed)
Headline ("No data yet")
Subheading (what to do)
Primary CTA Button
Optional secondary link

Colors: Muted (#94A3B8), accent for button
```

### Error States
```
Icon: ⚠️ or ✗
Background: #F43F5E with 10% opacity tint
Border: 1px solid #F43F5E
Text: Error message (clear, actionable)
Action: Clear button or retry button
```

### Success States
```
Icon: ✓
Background: #10B981 with 10% opacity tint
Border: 1px solid #10B981
Text: Success message
Action: Continue or dismiss
Duration: Auto-dismiss 3-4 seconds (with option to keep)
```

### Disabled States
```
Opacity: 50% or 40%
Cursor: not-allowed
Color: #64748B (muted)
No interactions
```

### Hover States
```
All interactive elements have distinct hover
Subtle color shift + cursor pointer
Optional: Slight elevation increase
Optional: Background color shift
```

---

## 🔒 PART 16: ACCESSIBILITY COMMITMENTS

```
✓ WCAG 2.1 AA Compliance
✓ Keyboard Navigation (Tab, Enter, Esc)
✓ Focus Indicators (visible, colored)
✓ Color Contrast (4.5:1 for text)
✓ Alt Text for Images
✓ ARIA Labels for Interactive Elements
✓ Screen Reader Support
✓ Motion Reduced Preferences Respected
✓ Touch-Friendly (48px+ tap targets)
```

---

## 🚀 DELIVERABLES CHECKLIST

- [ ] Design System Document (THIS FILE)
- [ ] Component Library (Figma or similar)
- [ ] Color Palette Export
- [ ] Typography Scale Export
- [ ] Icon Set
- [ ] Responsive Breakpoint Definitions
- [ ] Animations CSS (or Framer Motion specs)
- [ ] Sitemap Diagram
- [ ] User Journey Diagrams
- [ ] Wireframes (low-fidelity)
- [ ] High-Fidelity Mockups (all pages)
- [ ] Interactive Prototype (Figma)

---

## 📱 PART 17: RESPONSIVE BEHAVIOR

### Mobile-First Approach

```
Base Design: Mobile (320px+)
Enhancement: Tablet (768px+)
Optimization: Desktop (1024px+)
Premium: Large Screens (1280px+)

Mobile Strategy:
- Stack all layouts vertically
- Full-width components
- Large touch targets (44px+)
- Simplified navigation (hamburger menu)
- Docked chat (bottom)

Tablet Strategy:
- 2-column layouts where sensible
- Sidebar visible if space
- Adjusted spacing

Desktop Strategy:
- 3+ column layouts
- Persistent sidebar
- Chat docked right or floating
- Spacious card layouts
```

---

## 🎨 PART 18: BRAND VOICE IN UI

### Microcopy Examples

```
Button Labels:
- "Get Started" (not "Submit")
- "Create Scenario" (not "Save")
- "View Details" (not "Click Here")
- "Analyze" (not "Run")

Empty States:
- "No scenarios yet. Ready to forecast your future?"
- "Your decisions will appear here once you create them."

Errors:
- "We couldn't upload that file. Try CSV or Excel."
- "Please check your data and try again."

Success:
- "Perfect! Your data is ready."
- "Scenario created. Compare it with others?"
```

---

## 📋 SIGN-OFF

**Design System Version:** 1.0  
**Status:** Ready for Stakeholder Review  
**Next Step:** APPROVE → Proceed to UI/Page Generation  

**Questions to Validate:**

1. ✅ Does this color palette feel premium and fintech-grade?
2. ✅ Is the spacing system generous enough for elegance?
3. ✅ Do the component specs cover all design needs?
4. ✅ Is the user journey realistic and complete?
5. ✅ Are we ready to build the UI pages?

---

## 🎨 FINAL NOTES

This design system ensures:
- ✓ Visual consistency across all pages
- ✓ Premium, enterprise-grade perception
- ✓ Accessibility & ease of use
- ✓ Scalability for future features
- ✓ Mobile-first responsive design
- ✓ Professional fintech aesthetic
- ✓ Clear hierarchy & information architecture

**DO NOT SKIP THIS SPEC.** Every page built must adhere to this system.

---

**Ready to proceed with Page-by-Page UI Generation?**  
**Awaiting Your Approval on Design System Above** ✨
