# ZephyBloom Frontend

Premium SaaS frontend for the ZephyBloom AI CFO assistant. Built with React 18, Vite, Tailwind CSS, and designed per premium fintech standards (comparable to Stripe, Linear, Notion).

## 🎨 Design System

- **Visual Theme:** Dark with electric blue accents
- **Typography:** Clean, minimal, authoritative
- **Colors:** 20+ custom colors in Tailwind config
- **Components:** Reusable atoms, molecules, organisms
- **Responsive:** Mobile-first with 6 breakpoints (sm, md, lg, xl, 2xl, 3xl)

## 📦 Tech Stack

- **Framework:** React 18.2
- **Build Tool:** Vite
- **CSS Framework:** Tailwind CSS 3.3
- **Routing:** React Router DOM
- **State Management:** Zustand
- **Data Viz:** Recharts
- **Icons:** Lucide React
- **HTTP Client:** Axios

## 🚀 Getting Started

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

Server runs on `http://localhost:3000` with auto-reload (HMR).

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Button.jsx      # Button primitive (4 variants)
│   ├── Input.jsx       # Form input with validation
│   ├── Card.jsx        # Base card component
│   ├── KPICard.jsx     # Dashboard KPI card
│   ├── Navbar.jsx      # Fixed header with user menu
│   ├── Sidebar.jsx     # Persistent navigation
│   └── index.js        # Barrel exports
├── pages/              # Page components (11 total)
│   ├── LandingPage.jsx # Public homepage
│   ├── LoginPage.jsx   # Authentication
│   ├── RegisterPage.jsx
│   ├── Dashboard.jsx   # Main app dashboard (KPIs + charts)
│   ├── Scenarios.jsx   # Scenario planning
│   ├── Decisions.jsx   # Strategic decisions
│   ├── Chat.jsx        # AI CFO chat
│   ├── Settings.jsx    # User settings
│   └── onboarding/     # 4-step signup flow
│       ├── Welcome.jsx
│       ├── Company.jsx
│       ├── Upload.jsx
│       └── Validate.jsx
├── App.jsx            # Router setup (11 routes)
├── main.jsx           # React entry point
└── index.css          # Global styles + Tailwind

```

## 🎯 Pages & Routes

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | LandingPage | Public homepage with features & pricing |
| `/login` | LoginPage | User authentication |
| `/register` | RegisterPage | New user signup |
| `/onboarding/welcome` | Welcome | Onboarding step 1 |
| `/onboarding/company` | Company | Onboarding step 2 |
| `/onboarding/upload` | Upload | Onboarding step 3 |
| `/onboarding/validate` | Validate | Onboarding step 4 |
| `/dashboard` | Dashboard | Main app (KPIs, charts, alerts) |
| `/scenarios` | Scenarios | Scenario planning & projections |
| `/decisions` | Decisions | Strategic decision analysis |
| `/chat` | Chat | AI CFO conversational interface |
| `/settings` | Settings | User account & preferences |

## 🎨 Color System

### Base Palette
- **base-900:** #0A0E27 (darkest background)
- **base-800:** #1A1F3A (card backgrounds)
- **base-700:** #2D3250 (borders, tertiary)
- **base-500:** #4A5578 (hover states)

### Accent Colors
- **electric-500:** #3B82F6 (primary action)
- **electric-400:** #60A5FA (hover state)
- **emerald-500:** #10B981 (success)
- **rose-500:** #F43F5E (danger)
- **amber-500:** #F59E0B (warning)
- **cyan-500:** #06B6D4 (info)

## 🔌 Backend Integration

API calls should target `http://localhost:8001` (ZephyBloom backend).

**Example integration points to add:**
1. **POST `/auth/login`** - User authentication
2. **POST `/auth/register`** - New user signup
3. **GET `/dashboard`** - Dashboard KPIs and data
4. **GET `/scenarios`** - Scenario planning data
5. **POST `/chat`** - AI CFO chat endpoint

See `api.js` setup in utils for Axios client configuration.

## 📋 Component Library

### Pre-built Components (Ready to Use)

- **Button** - 4 variants (primary, secondary, ghost, danger) + 4 sizes
- **Input** - Form input with icons, error states, validation
- **Card** - Base card with hover effects
- **KPICard** - Dashboard metric card with trend indicators
- **Navbar** - Fixed header with logo, user menu, mobile toggle
- **Sidebar** - Persistent navigation with active states

All components are fully responsive and follow the design system exactly.

## 🎬 Next Steps

1. **npm install** - Install all dependencies
2. **npm run dev** - Start dev server
3. **Backend integration** - Wire forms to API endpoints
4. **Authentication** - Implement JWT token flow
5. **State management** - Setup Zustand stores for auth, user
6. **Error handling** - Add error boundary + toast notifications

## 📝 Environment Variables

Create `.env.local` for local development:

```env
VITE_API_URL=http://localhost:8001
VITE_APP_NAME=ZephyBloom
```

## 🧪 Testing

Manual testing checklist:
- [ ] Landing page loads and is responsive
- [ ] Navigation between all 11 pages works
- [ ] Colors match design system exactly
- [ ] Responsive design works on mobile/tablet/desktop
- [ ] Forms are interactive (buttons clickable, inputs focusable)
- [ ] Sidebar toggle works on mobile

## 🚢 Production Build

```bash
npm run build

# Creates optimized dist/ folder ready for deployment
# Example: deploy to Netlify, Vercel, AWS S3 + CloudFront
```

## 📄 License

Proprietary - ZephyBloom
