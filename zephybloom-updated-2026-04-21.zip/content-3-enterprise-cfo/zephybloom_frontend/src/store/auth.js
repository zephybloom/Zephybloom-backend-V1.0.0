import { create } from 'zustand'
import { auth } from '../utils/api'

// Helper to safely access localStorage (only in browser)
const getToken = () => {
  if (typeof window === 'undefined') return null
  try {
    return localStorage.getItem('token') || null
  } catch {
    return null
  }
}

const getUser = () => {
  if (typeof window === 'undefined') return null
  try {
    const user = localStorage.getItem('user')
    return user ? JSON.parse(user) : null
  } catch {
    return null
  }
}

export const useAuthStore = create((set) => ({
  user: getUser(),
  token: getToken(),
  loading: false,
  error: null,

  login: async (email, password) => {
    set({ loading: true, error: null })
    try {
      const response = await auth.login(email, password)
      const { access_token, user_id, tenant_id } = response.data

      localStorage.setItem('token', access_token)
      localStorage.setItem('user', JSON.stringify({ email, user_id, tenant_id }))

      set({ token: access_token, user: { email, user_id, tenant_id }, loading: false })
      return { success: true }
    } catch (error) {
      const errorMsg = error.response?.data?.detail || 'Login failed'
      set({ error: errorMsg, loading: false })
      return { success: false, error: errorMsg }
    }
  },

  register: async (name, email, password, company) => {
    set({ loading: true, error: null })
    try {
      const response = await auth.register(name, email, password, company)
      const { access_token, user_id, tenant_id } = response.data

      localStorage.setItem('token', access_token)
      localStorage.setItem('user', JSON.stringify({ email, user_id, tenant_id }))

      set({ token: access_token, user: { email, user_id, tenant_id }, loading: false })
      return { success: true }
    } catch (error) {
      const errorMsg = error.response?.data?.detail || 'Registration failed'
      set({ error: errorMsg, loading: false })
      return { success: false, error: errorMsg }
    }
  },

  logout: () => {
    auth.logout()
    set({ user: null, token: null, error: null })
  },

  clearError: () => set({ error: null }),
}))
