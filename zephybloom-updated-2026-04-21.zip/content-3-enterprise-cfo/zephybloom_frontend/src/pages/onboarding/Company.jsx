import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, ArrowRight, Building2, Euro, Users } from 'lucide-react'
import { Button, Input } from '../../components'
import { dataRoom } from '../../utils/api'
import { defaultOnboardingState, loadOnboardingState, normalizeFieldValue, saveOnboardingState } from './onboardingState'

const sectors = [
  { value: 'restaurant', label: 'Restaurant' },
  { value: 'ecommerce', label: 'Ecommerce' },
  { value: 'construction', label: 'Construction' },
  { value: 'hotel', label: 'Hotel' },
  { value: 'services', label: 'Services' },
]

const sectorHints = {
  restaurant: 'Menu, food cost, personale di sala/cucina, turni e scontrino medio.',
  ecommerce: 'SKU, costi acquisto, ads, resi, ordini e AOV.',
  construction: 'Commesse, materiali, avanzamento, fatturato maturato e incassi.',
  hotel: 'Camere, occupancy, ADR, OTA e struttura staff.',
  services: 'Pacchetti, prezzo medio, delivery cost e marginalità per cliente.',
}

export default function OnboardingCompany() {
  const navigate = useNavigate()
  const [state, setState] = useState(defaultOnboardingState)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    setState(loadOnboardingState())
  }, [])

  const companyData = state.companyData
  const activeSector = companyData.settore || state.activeSector || 'restaurant'

  useEffect(() => {
    saveOnboardingState(state)
  }, [state])

  const isValid = useMemo(
    () => Boolean(companyData.company_name && companyData.settore && companyData.annual_revenue),
    [companyData],
  )

  const updateField = (field, value) => {
    const normalized = normalizeFieldValue(field, value)
    setState((current) => ({
      ...current,
      activeSector: field === 'settore' ? value : current.activeSector,
      companyData: {
        ...current.companyData,
        [field]: value,
        ...(field === 'settore' ? { settore: value } : {}),
      },
      operationalDataBySector: {
        ...current.operationalDataBySector,
        [field === 'settore' ? value : current.activeSector]: current.operationalDataBySector[field === 'settore' ? value : current.activeSector] || {},
      },
      normalizedPreview: {
        ...current.normalizedPreview,
        [field]: normalized,
      },
    }))
  }

  const saveAndContinue = async () => {
    if (!isValid) {
      setError('Compila almeno nome azienda, settore e fatturato annuo.')
      return
    }
    setSaving(true)
    setError('')

    const payloadCompanyData = {
      company_name: companyData.company_name,
      settore: activeSector,
      annual_revenue: normalizeFieldValue('annual_revenue', companyData.annual_revenue),
      business_model: companyData.business_model,
      employee_count: normalizeFieldValue('employee_count', companyData.employee_count),
      payroll_costs: normalizeFieldValue('payroll_costs', companyData.payroll_costs),
      average_ticket: normalizeFieldValue('average_ticket', companyData.average_ticket),
      cash_on_hand: normalizeFieldValue('cash_on_hand', companyData.cash_on_hand),
    }

    try {
      await dataRoom.build({
        company_id: state.companyId,
        active_sector: activeSector,
        save: true,
        merge: true,
        company_data: payloadCompanyData,
        operational_data_by_sector: state.operationalDataBySector,
      })

      saveOnboardingState({
        ...state,
        activeSector,
        companyData: {
          ...companyData,
          settore: activeSector,
        },
      })
      navigate('/onboarding/upload')
    } catch (requestError) {
      setError(requestError.response?.data?.detail || 'Non sono riuscito a salvare il profilo aziendale.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 px-6 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Fase 2 · Profilo azienda</p>
            <h1 className="mt-2 text-4xl font-bold text-text-primary">Costruiamo il contesto economico di partenza</h1>
            <p className="mt-3 max-w-3xl text-text-secondary">
              Qui raccogliamo il minimo intelligente: abbastanza per smettere di dare risposte generiche, non così tanto da rallentarti.
            </p>
          </div>
          <div className="hidden rounded-lg border border-base-600 bg-base-800 px-4 py-3 text-right lg:block">
            <p className="text-xs uppercase tracking-wide text-text-tertiary">Step</p>
            <p className="mt-1 text-xl font-bold text-text-primary">1 / 3</p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <section className="rounded-lg border border-base-500 bg-base-800 p-8">
            <div className="grid gap-5 md:grid-cols-2">
              <Input
                label="Nome azienda"
                value={companyData.company_name}
                onChange={(event) => updateField('company_name', event.target.value)}
                placeholder="Ristorante Milano Centro"
                icon={<Building2 className="h-4 w-4" />}
              />

              <div>
                <label className="mb-2 block text-sm font-medium text-text-secondary">Settore</label>
                <select
                  value={activeSector}
                  onChange={(event) => updateField('settore', event.target.value)}
                  className="w-full rounded-md border border-base-500 bg-base-900 px-3 py-3 text-text-primary focus:border-electric-500 focus:outline-none"
                >
                  {sectors.map((sector) => (
                    <option key={sector.value} value={sector.value}>{sector.label}</option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-text-tertiary">{sectorHints[activeSector]}</p>
              </div>

              <Input
                label="Fatturato annuo"
                value={companyData.annual_revenue}
                onChange={(event) => updateField('annual_revenue', event.target.value)}
                placeholder="1200000"
                icon={<Euro className="h-4 w-4" />}
              />

              <Input
                label="Modello di business"
                value={companyData.business_model}
                onChange={(event) => updateField('business_model', event.target.value)}
                placeholder="Sala + delivery + eventi"
              />

              <Input
                label="Numero dipendenti"
                value={companyData.employee_count}
                onChange={(event) => updateField('employee_count', event.target.value)}
                placeholder="18"
                icon={<Users className="h-4 w-4" />}
              />

              <Input
                label="Costo personale mensile"
                value={companyData.payroll_costs}
                onChange={(event) => updateField('payroll_costs', event.target.value)}
                placeholder="38000"
              />

              <Input
                label={activeSector === 'restaurant' ? 'Scontrino medio' : 'Ticket medio'}
                value={companyData.average_ticket}
                onChange={(event) => updateField('average_ticket', event.target.value)}
                placeholder="36"
              />

              <Input
                label="Cassa disponibile"
                value={companyData.cash_on_hand}
                onChange={(event) => updateField('cash_on_hand', event.target.value)}
                placeholder="85000"
              />
            </div>

            {error && (
              <div className="mt-5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
                {error}
              </div>
            )}

            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/onboarding/welcome">
                <Button variant="secondary" className="gap-2">
                  <ArrowLeft className="h-5 w-5" />
                  Indietro
                </Button>
              </Link>
              <Button className="gap-2" onClick={saveAndContinue} disabled={saving}>
                {saving ? 'Salvataggio in corso...' : 'Salva e continua'}
                <ArrowRight className="h-5 w-5" />
              </Button>
            </div>
          </section>

          <aside className="space-y-6">
            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Perché questi dati</p>
              <div className="mt-4 space-y-4 text-sm text-text-secondary">
                <p>Il settore cambia benchmark, KPI e simulazioni attive.</p>
                <p>Fatturato e personale servono per capire se il problema è margine, struttura o scala.</p>
                <p>Ticket medio e cassa disponibile aiutano il CFO a separare crescita da pressione finanziaria.</p>
              </div>
            </div>

            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Subito dopo</p>
              <div className="mt-4 space-y-3 text-sm text-text-secondary">
                <p>• Ti mostro i blocchi dati prioritari per il tuo settore.</p>
                <p>• Salviamo personale, canali, fornitori e dati verticali.</p>
                <p>• Chiudiamo con una validazione vera della readiness CFO.</p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}
