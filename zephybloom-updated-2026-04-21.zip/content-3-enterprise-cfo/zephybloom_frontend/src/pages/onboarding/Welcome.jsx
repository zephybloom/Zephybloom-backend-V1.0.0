import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { ArrowRight, Database, LineChart, ShieldCheck } from 'lucide-react'
import { Button } from '../../components'
import { dataRoom } from '../../utils/api'

function readinessTone(level) {
  if (level === 'cfo_ready') return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
  if (level === 'analysis_ready') return 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10'
  if (level === 'guided_collection_needed') return 'text-amber-300 border-amber-400/30 bg-amber-500/10'
  return 'text-text-secondary border-base-500 bg-base-800'
}

export default function OnboardingWelcome() {
  const [context, setContext] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    dataRoom.getContext('default')
      .then((response) => {
        if (mounted) setContext(response.data)
      })
      .catch(() => {
        if (mounted) setContext(null)
      })
      .finally(() => {
        if (mounted) setLoading(false)
      })
    return () => {
      mounted = false
    }
  }, [])

  const roomContext = context?.context
  const hasStarted = context?.has_saved_data_room

  return (
    <div className="min-h-screen bg-base-900 px-6 py-12">
      <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="rounded-lg border border-base-500 bg-base-800 p-8 lg:p-10">
          <div className="inline-flex items-center rounded-full border border-electric-500/30 bg-electric-500/10 px-3 py-1 text-sm font-medium text-electric-300">
            Onboarding CFO guidato
          </div>
          <h1 className="mt-6 max-w-3xl text-4xl font-bold text-text-primary">
            Costruiamo la tua Data Room come farebbe un CFO, non come un form qualsiasi.
          </h1>
          <p className="mt-4 max-w-3xl text-lg text-text-secondary">
            In questa fase raccogliamo solo i dati che aumentano davvero precisione, qualità delle simulazioni e priorità operative.
          </p>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border border-base-600 bg-base-900 p-5">
              <Database className="h-6 w-6 text-electric-400" />
              <p className="mt-4 font-semibold text-text-primary">Profilo azienda</p>
              <p className="mt-2 text-sm text-text-tertiary">Settore, struttura ricavi, cassa e dimensione del business.</p>
            </div>
            <div className="rounded-lg border border-base-600 bg-base-900 p-5">
              <LineChart className="h-6 w-6 text-cyan-400" />
              <p className="mt-4 font-semibold text-text-primary">Leve economiche</p>
              <p className="mt-2 text-sm text-text-tertiary">Margini, personale, prezzi, canali e costi unitari.</p>
            </div>
            <div className="rounded-lg border border-base-600 bg-base-900 p-5">
              <ShieldCheck className="h-6 w-6 text-emerald-400" />
              <p className="mt-4 font-semibold text-text-primary">Risposte affidabili</p>
              <p className="mt-2 text-sm text-text-tertiary">Meno risposte casuali, più diagnosi precise e War Room utile.</p>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link to="/onboarding/company">
              <Button className="gap-2">
                {hasStarted ? 'Riprendi onboarding' : 'Inizia la Data Room'}
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/dashboard">
              <Button variant="secondary">Vai alla dashboard</Button>
            </Link>
          </div>
        </section>

        <aside className="space-y-6">
          <div className="rounded-lg border border-base-500 bg-base-800 p-6">
            <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Stato attuale</p>
            {loading ? (
              <p className="mt-4 text-text-secondary">Sto caricando il contesto della Data Room...</p>
            ) : (
              <>
                <div className={`mt-4 rounded-lg border px-4 py-4 ${readinessTone(roomContext?.readiness_level)}`}>
                  <p className="text-sm">Readiness dati</p>
                  <p className="mt-2 text-3xl font-bold">{roomContext?.readiness_score_pct ?? 0}%</p>
                  <p className="mt-2 text-sm">
                    {roomContext?.readiness_level === 'cfo_ready' ? 'Il CFO può già ragionare con alta precisione.' :
                      roomContext?.readiness_level === 'analysis_ready' ? 'Le analisi sono buone, ma ci sono ancora buchi da chiudere.' :
                      roomContext?.readiness_level === 'guided_collection_needed' ? 'Il prodotto sa dove andare, ma ha bisogno di più dati guidati.' :
                      'Partiamo dalle basi aziendali per sbloccare analisi sensate.'}
                  </p>
                </div>

                <div className="mt-5 rounded-lg border border-base-600 bg-base-900 p-4">
                  <p className="text-sm font-medium text-text-primary">Prossime domande CFO</p>
                  <div className="mt-3 space-y-2 text-sm text-text-secondary">
                    {(roomContext?.next_questions || ['Inserisci i primi dati aziendali per iniziare.']).slice(0, 3).map((item) => (
                      <p key={item}>• {item}</p>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="rounded-lg border border-base-500 bg-base-800 p-6">
            <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Percorso</p>
            <div className="mt-4 space-y-4">
              {[
                ['1', 'Profilo e numeri base', 'Capisco settore, scala, ricavi e struttura iniziale.'],
                ['2', 'Blocchi prioritari', 'Ti chiedo personale, costi, canali e dati verticali.'],
                ['3', 'Validazione CFO', 'Ti mostro quanto siamo pronti per diagnosi, simulazioni e War Room.'],
              ].map(([step, title, copy]) => (
                <div key={step} className="flex gap-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-base-700 text-sm font-bold text-text-primary">
                    {step}
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">{title}</p>
                    <p className="text-sm text-text-tertiary">{copy}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}
