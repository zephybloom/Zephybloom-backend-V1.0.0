import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, ArrowRight, Briefcase, Coins, ShoppingBag, Users } from 'lucide-react'
import { Button, Input } from '../../components'
import { dataRoom } from '../../utils/api'
import { loadOnboardingState, normalizeFieldValue, saveOnboardingState } from './onboardingState'

const quickFieldsBySector = {
  restaurant: [
    { key: 'opening_days_per_month', label: 'Giorni di apertura al mese', placeholder: '26' },
    { key: 'target_margin_pct', label: 'Margine netto obiettivo %', placeholder: '18' },
    { key: 'payment_terms_days', label: 'Giorni medi pagamento fornitori', placeholder: '30' },
  ],
  ecommerce: [
    { key: 'monthly_orders', label: 'Ordini mensili', placeholder: '850' },
    { key: 'average_order_value', label: 'Valore medio ordine', placeholder: '78' },
    { key: 'customer_acquisition_cost', label: 'CAC medio', placeholder: '18' },
    { key: 'return_rate_pct', label: 'Tasso resi %', placeholder: '5' },
  ],
  construction: [
    { key: 'materials_cost', label: 'Costo materiali mensile', placeholder: '65000' },
    { key: 'labor_cost', label: 'Costo manodopera mensile', placeholder: '42000' },
    { key: 'progress_pct', label: 'Avanzamento medio commesse %', placeholder: '60' },
    { key: 'collected_pct', label: 'Percentuale già incassata %', placeholder: '45' },
  ],
  hotel: [
    { key: 'rooms', label: 'Numero camere', placeholder: '42' },
    { key: 'occupancy_rate', label: 'Occupancy %', placeholder: '74' },
    { key: 'adr', label: 'ADR', placeholder: '118' },
    { key: 'ota_commissions', label: 'Commissioni OTA %', placeholder: '17' },
  ],
  services: [
    { key: 'monthly_orders', label: 'Clienti/progetti mensili', placeholder: '24' },
    { key: 'average_order_value', label: 'Ticket medio', placeholder: '2600' },
    { key: 'target_margin_pct', label: 'Margine obiettivo %', placeholder: '25' },
  ],
}

export default function OnboardingUpload() {
  const navigate = useNavigate()
  const [state, setState] = useState(() => loadOnboardingState())
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    employee_count: '',
    payroll_costs: '',
    average_ticket: '',
    cash_on_hand: '',
    payment_terms_days: '',
    monthly_orders: '',
    average_order_value: '',
    customer_acquisition_cost: '',
    return_rate_pct: '',
    opening_days_per_month: '',
    target_margin_pct: '',
    materials_cost: '',
    labor_cost: '',
    progress_pct: '',
    collected_pct: '',
    rooms: '',
    occupancy_rate: '',
    adr: '',
    ota_commissions: '',
  })

  useEffect(() => {
    const loaded = loadOnboardingState()
    setState(loaded)
    const activeSector = loaded.activeSector || loaded.companyData?.settore || 'restaurant'
    const sectorData = loaded.operationalDataBySector?.[activeSector] || {}
    setFormData((current) => ({
      ...current,
      employee_count: loaded.companyData?.employee_count || '',
      payroll_costs: loaded.companyData?.payroll_costs || '',
      average_ticket: loaded.companyData?.average_ticket || '',
      cash_on_hand: loaded.companyData?.cash_on_hand || '',
      payment_terms_days: loaded.companyData?.payment_terms_days || sectorData.payment_terms_days || '',
      monthly_orders: sectorData.monthly_orders || '',
      average_order_value: sectorData.average_order_value || '',
      customer_acquisition_cost: sectorData.customer_acquisition_cost || '',
      return_rate_pct: sectorData.return_rate_pct || '',
      opening_days_per_month: sectorData.opening_days_per_month || '',
      target_margin_pct: sectorData.target_margin_pct || '',
      materials_cost: sectorData.materials_cost || '',
      labor_cost: sectorData.labor_cost || '',
      progress_pct: sectorData.progress_pct || '',
      collected_pct: sectorData.collected_pct || '',
      rooms: sectorData.rooms || '',
      occupancy_rate: sectorData.occupancy_rate || '',
      adr: sectorData.adr || '',
      ota_commissions: sectorData.ota_commissions || '',
    }))
  }, [])

  const activeSector = state.activeSector || state.companyData?.settore || 'restaurant'
  const sectorFields = useMemo(() => quickFieldsBySector[activeSector] || quickFieldsBySector.restaurant, [activeSector])

  const updateField = (key, value) => {
    setFormData((current) => ({ ...current, [key]: value }))
  }

  const saveAndContinue = async () => {
    setSaving(true)
    setError('')
    try {
      const companyUpdates = {
        employee_count: normalizeFieldValue('employee_count', formData.employee_count),
        payroll_costs: normalizeFieldValue('payroll_costs', formData.payroll_costs),
        average_ticket: normalizeFieldValue('average_ticket', formData.average_ticket),
        cash_on_hand: normalizeFieldValue('cash_on_hand', formData.cash_on_hand),
        payment_terms_days: normalizeFieldValue('payment_terms_days', formData.payment_terms_days),
      }

      const sectorUpdates = {}
      sectorFields.forEach((field) => {
        sectorUpdates[field.key] = normalizeFieldValue(field.key, formData[field.key])
      })

      const nextState = {
        ...state,
        companyData: {
          ...state.companyData,
          ...Object.fromEntries(Object.entries(companyUpdates).filter(([, value]) => value !== null)),
        },
        operationalDataBySector: {
          ...state.operationalDataBySector,
          [activeSector]: {
            ...(state.operationalDataBySector?.[activeSector] || {}),
            ...Object.fromEntries(Object.entries(sectorUpdates).filter(([, value]) => value !== null)),
          },
        },
      }

      await dataRoom.build({
        company_id: nextState.companyId,
        active_sector: activeSector,
        save: true,
        merge: true,
        company_data: nextState.companyData,
        operational_data_by_sector: nextState.operationalDataBySector,
      })

      saveOnboardingState(nextState)
      setState(nextState)
      navigate('/onboarding/validate')
    } catch (requestError) {
      setError(requestError.response?.data?.detail || 'Non sono riuscito a salvare questi dati.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 px-6 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Fase 2 · Inserimento veloce</p>
          <h1 className="mt-2 text-4xl font-bold text-text-primary">Ti chiedo poche cose, ma giuste</h1>
          <p className="mt-3 max-w-3xl text-text-secondary">
            Nessun inserimento pesante. Chiudiamo i dati base in pochi blocchi, così il CFO può iniziare a ragionare bene senza stressarti.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-electric-500/10 text-electric-300">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-text-primary">Persone e struttura</h2>
                <p className="text-sm text-text-tertiary">Capisco quanto pesa la struttura prima di parlare di crescita.</p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Input label="Numero persone" value={formData.employee_count} onChange={(e) => updateField('employee_count', e.target.value)} placeholder="18" />
              <Input label="Costo personale mensile" value={formData.payroll_costs} onChange={(e) => updateField('payroll_costs', e.target.value)} placeholder="38000" />
            </div>
          </section>

          <section className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-300">
                <Coins className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-text-primary">Cassa e flusso</h2>
                <p className="text-sm text-text-tertiary">Mi serve per capire pressione finanziaria e margine reale.</p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Input label="Cassa disponibile" value={formData.cash_on_hand} onChange={(e) => updateField('cash_on_hand', e.target.value)} placeholder="85000" />
              <Input label="Giorni pagamento fornitori" value={formData.payment_terms_days} onChange={(e) => updateField('payment_terms_days', e.target.value)} placeholder="30" />
            </div>
          </section>

          <section className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-300">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-text-primary">Vendite</h2>
                <p className="text-sm text-text-tertiary">Pochi numeri per distinguere volume, ticket e qualità ricavi.</p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Input label={activeSector === 'restaurant' ? 'Scontrino medio' : 'Ticket medio'} value={formData.average_ticket} onChange={(e) => updateField('average_ticket', e.target.value)} placeholder="36" />
              {(activeSector === 'ecommerce' || activeSector === 'services') && (
                <>
                  <Input label="Ordini / clienti mensili" value={formData.monthly_orders} onChange={(e) => updateField('monthly_orders', e.target.value)} placeholder="850" />
                  <Input label="Valore medio ordine" value={formData.average_order_value} onChange={(e) => updateField('average_order_value', e.target.value)} placeholder="78" />
                </>
              )}
            </div>
          </section>

          <section className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/10 text-violet-300">
                <Briefcase className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-text-primary">Dati chiave del tuo settore</h2>
                <p className="text-sm text-text-tertiary">Solo i numeri che sbloccano analisi verticali davvero utili.</p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {sectorFields.map((field) => (
                <Input
                  key={field.key}
                  label={field.label}
                  value={formData[field.key] ?? ''}
                  onChange={(e) => updateField(field.key, e.target.value)}
                  placeholder={field.placeholder}
                />
              ))}
            </div>
          </section>
        </div>

        {error && (
          <div className="mt-6 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
            {error}
          </div>
        )}

        <div className="mt-8 flex flex-wrap gap-4">
          <Link to="/onboarding/company">
            <Button variant="secondary" className="gap-2">
              <ArrowLeft className="h-5 w-5" />
              Indietro
            </Button>
          </Link>
          <Link to="/dashboard">
            <Button variant="secondary">Salta e vai alla dashboard</Button>
          </Link>
          <Button className="gap-2" onClick={saveAndContinue} disabled={saving}>
            {saving ? 'Salvataggio...' : 'Salva e continua'}
            <ArrowRight className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
