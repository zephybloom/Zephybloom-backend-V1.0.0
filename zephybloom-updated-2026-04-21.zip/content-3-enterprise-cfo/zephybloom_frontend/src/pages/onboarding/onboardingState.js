const STORAGE_KEY = 'zb_onboarding_state'

export const defaultOnboardingState = {
  companyId: 'default',
  activeSector: 'restaurant',
  companyData: {
    company_name: '',
    settore: 'restaurant',
    annual_revenue: '',
    business_model: '',
    employee_count: '',
    payroll_costs: '',
    average_ticket: '',
    cash_on_hand: '',
  },
  operationalDataBySector: {
    restaurant: {},
  },
}

export function loadOnboardingState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultOnboardingState
    const parsed = JSON.parse(raw)
    return {
      ...defaultOnboardingState,
      ...parsed,
      companyData: {
        ...defaultOnboardingState.companyData,
        ...(parsed.companyData || {}),
      },
      operationalDataBySector: {
        ...defaultOnboardingState.operationalDataBySector,
        ...(parsed.operationalDataBySector || {}),
      },
    }
  } catch (error) {
    console.error('Failed to load onboarding state', error)
    return defaultOnboardingState
  }
}

export function saveOnboardingState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
}

export function normalizeNumber(value) {
  if (value === '' || value === null || value === undefined) return null
  const normalized = Number(String(value).replace(',', '.'))
  return Number.isNaN(normalized) ? null : normalized
}

export function normalizeFieldValue(field, value) {
  if (value === '' || value === null || value === undefined) {
    return null
  }
  const numericFields = new Set([
    'annual_revenue',
    'employee_count',
    'payroll_costs',
    'average_ticket',
    'cash_on_hand',
    'monthly_orders',
    'average_order_value',
    'customer_acquisition_cost',
    'return_rate_pct',
    'stock_value',
    'stock_turnover',
    'materials_cost',
    'labor_cost',
    'progress_pct',
    'billed_pct',
    'collected_pct',
    'adr',
    'occupancy_rate',
    'rooms',
    'ota_commissions',
    'opening_days_per_month',
    'target_margin_pct',
    'payment_terms_days',
    'receivables',
    'payables',
  ])

  if (numericFields.has(field)) {
    return normalizeNumber(value)
  }

  return value
}

