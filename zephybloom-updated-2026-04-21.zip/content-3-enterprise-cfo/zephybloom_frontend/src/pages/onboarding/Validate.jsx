import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { AlertCircle, ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react'
import { Button } from '../../components'
import { dataRoom } from '../../utils/api'

function statusTone(status) {
  if (status === 'complete') return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
  if (status === 'usable') return 'border-cyan-500/30 bg-cyan-500/10 text-cyan-300'
  if (status === 'partial') return 'border-amber-500/30 bg-amber-500/10 text-amber-300'
  return 'border-rose-500/30 bg-rose-500/10 text-rose-300'
}

function readinessCopy(level) {
  if (level === 'cfo_ready') return 'Ottimo livello: il CFO può già dare risposte affidabili su analisi, simulazioni e priorità.'
  if (level === 'analysis_ready') return 'Base buona: puoi già usare il prodotto, ma ci sono ancora blocchi che migliorano molto la precisione.'
  if (level === 'guided_collection_needed') return 'La logica è attiva, però servono ancora dati strutturati per evitare risposte generiche.'
  return 'Siamo all’inizio: serve ancora la base dati per trasformare la chat in un vero CFO operativo.'
}

export default function OnboardingValidate() {
  const [payload, setPayload] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let mounted = true
    dataRoom.get('default')
      .then((response) => {
        if (mounted) setPayload(response.data)
      })
      .catch((requestError) => {
        if (mounted) setError(requestError.response?.data?.detail || 'Non riesco a leggere la validazione della Data Room.')
      })
      .finally(() => {
        if (mounted) setLoading(false)
      })
    return () => {
      mounted = false
    }
  }, [])

  const room = payload?.data_room
  const areas = room?.areas || []

  return (
    <div className="min-h-screen bg-base-900 px-6 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Fase 2 · Validazione finale</p>
          <h1 className="mt-2 text-4xl font-bold text-text-primary">Vediamo quanto il prodotto è pronto a ragionare come CFO</h1>
          <p className="mt-3 max-w-3xl text-text-secondary">
            Qui chiudiamo l’onboarding dati: aree coperte, readiness, domande ancora aperte e prossimo passo operativo.
          </p>
        </div>

        {loading ? (
          <div className="rounded-lg border border-base-500 bg-base-800 p-8 text-text-secondary">
            Sto validando la Data Room salvata...
          </div>
        ) : error ? (
          <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 p-8 text-rose-300">
            {error}
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
            <section className="space-y-6">
              <div className="rounded-lg border border-base-500 bg-base-800 p-8">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Readiness dati</p>
                    <h2 className="mt-2 text-5xl font-bold text-text-primary">{room?.readiness_score_pct ?? 0}%</h2>
                    <p className="mt-3 max-w-2xl text-text-secondary">{readinessCopy(room?.readiness_level)}</p>
                  </div>
                  <div className={`rounded-lg border px-4 py-3 ${room?.readiness_level === 'cfo_ready' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-base-600 bg-base-900 text-text-secondary'}`}>
                    <p className="text-xs uppercase tracking-wide">Livello</p>
                    <p className="mt-1 font-semibold">{room?.readiness_level || 'not_started'}</p>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-base-500 bg-base-800 p-8">
                <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Aree della Data Room</p>
                <div className="mt-5 grid gap-3">
                  {areas.map((area) => (
                    <div key={area.area} className={`rounded-lg border p-4 ${statusTone(area.status)}`}>
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="font-semibold">{area.label}</p>
                          <p className="mt-1 text-sm opacity-80">{area.why}</p>
                        </div>
                        <p className="text-lg font-bold">{area.coverage_pct}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            <aside className="space-y-6">
              <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Prossime domande</p>
                <div className="mt-4 space-y-3">
                  {(room?.next_questions || []).slice(0, 5).map((question) => (
                    <div key={question} className="flex gap-3 rounded-lg border border-base-600 bg-base-900 p-4">
                      <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-amber-300" />
                      <p className="text-sm text-text-secondary">{question}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Cosa hai sbloccato</p>
                <div className="mt-4 space-y-3">
                  {[
                    'Contesto aziendale persistente per chat e dashboard',
                    'Guided collection per settore e blocchi prioritari',
                    'Base dati strutturata per diagnosi, simulazioni e War Room',
                  ].map((item) => (
                    <div key={item} className="flex gap-3 rounded-lg border border-base-600 bg-base-900 p-4">
                      <CheckCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-300" />
                      <p className="text-sm text-text-secondary">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <Link to="/onboarding/upload">
                  <Button variant="secondary" className="gap-2">
                    <ArrowLeft className="h-5 w-5" />
                    Torna ai blocchi dati
                  </Button>
                </Link>
                <Link to="/dashboard">
                  <Button className="gap-2">
                    Apri dashboard
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  )
}
