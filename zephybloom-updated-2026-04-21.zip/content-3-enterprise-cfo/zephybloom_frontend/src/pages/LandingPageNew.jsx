export default function LandingPage() {
  return (
    <div className="min-h-screen bg-base-900">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 bg-base-900 bg-opacity-80 backdrop-blur border-b border-base-500 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <h1 className="text-xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent">
            ZephyBloom
          </h1>
          <div className="flex items-center gap-4">
            <a href="#" className="text-text-secondary hover:text-text-primary transition-colors">
              Sign In
            </a>
            <a
              href="#"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-4 py-2 hover:bg-electric-600 transition-colors"
            >
              Get Started
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-electric-500 bg-opacity-10 border border-electric-500 border-opacity-30 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="text-sm text-electric-400 font-medium">Now available for early access</span>
          </div>

          {/* Headline */}
          <h1 className="text-5xl font-bold text-text-primary mb-6">
            Your AI CFO, Always On Duty
          </h1>

          {/* Subheading */}
          <p className="text-xl text-text-secondary mb-8 mx-auto">
            ZephyBloom analyzes your financial data, forecasts scenarios, and guides strategic decisions with world-class CFO expertise.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <a
              href="#"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-6 py-3 hover:bg-electric-600 transition-colors"
            >
              Start Free Trial
            </a>
            <a
              href="#"
              className="border border-base-400 text-electric-500 font-semibold rounded-md px-6 py-3 hover:bg-base-700 transition-colors"
            >
              Learn More
            </a>
          </div>

          {/* Trust indicators */}
          <p className="text-text-tertiary text-sm">
            No credit card required. 14-day free trial. Premium support included.
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            Enterprise Financial Intelligence
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-electric-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Instant KPI Diagnosis</h3>
              <p className="text-text-secondary">
                Upload your financials and get a complete 7-area health scorecard in minutes.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-emerald-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">📈</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Scenario Planning</h3>
              <p className="text-text-secondary">
                Project financial scenarios with probability weighting for strategic decisions.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-violet-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Decision Analysis</h3>
              <p className="text-text-secondary">
                Evaluate strategic decisions with ROI analysis and impact modeling.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-rose-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">🤖</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">AI CFO Chat</h3>
              <p className="text-text-secondary">
                Ask questions about your business and get expert financial guidance instantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            Simple, Transparent Pricing
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Starter */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-text-primary mb-2">Starter</h3>
              <p className="text-text-secondary mb-6">For early-stage companies</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">€99<span className="text-lg text-text-secondary">/month</span></div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ KPI Analysis</li>
                <li>✓ Basic Scenarios</li>
                <li>✓ Email Support</li>
              </ul>
              <button className="w-full bg-base-700 text-text-primary font-semibold rounded-md py-2 hover:bg-base-600 transition-colors">
                Start Free Trial
              </button>
            </div>

            {/* Professional */}
            <div className="bg-electric-500 bg-opacity-10 border border-electric-500 rounded-xl p-8">
              <div className="inline-block bg-electric-500 text-base-900 text-xs font-bold px-3 py-1 rounded-full mb-4">
                POPULAR
              </div>
              <h3 className="text-2xl font-bold text-text-primary mb-2">Professional</h3>
              <p className="text-text-secondary mb-6">For growth companies</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">€299<span className="text-lg text-text-secondary">/month</span></div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ All Starter features</li>
                <li>✓ Advanced Scenarios</li>
                <li>✓ AI CFO Chat</li>
                <li>✓ Priority Support</li>
              </ul>
              <button className="w-full bg-electric-500 text-base-900 font-semibold rounded-md py-2 hover:bg-electric-600 transition-colors">
                Start Free Trial
              </button>
            </div>

            {/* Enterprise */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-text-primary mb-2">Enterprise</h3>
              <p className="text-text-secondary mb-6">For large organizations</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">Custom</div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ All Professional features</li>
                <li>✓ Custom Integrations</li>
                <li>✓ Dedicated Support</li>
                <li>✓ SLA Guarantee</li>
              </ul>
              <button className="w-full bg-base-700 text-text-primary font-semibold rounded-md py-2 hover:bg-base-600 transition-colors">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-text-primary mb-6">
            Ready to Transform Your Finance?
          </h2>
          <p className="text-xl text-text-secondary mb-8">
            Join hundreds of companies trusting ZephyBloom for strategic financial intelligence.
          </p>
          <a
            href="#"
            className="inline-block bg-electric-500 text-base-900 font-semibold rounded-md px-8 py-3 hover:bg-electric-600 transition-colors"
          >
            Get Started Free
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-base-800 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-text-primary mb-4">ZephyBloom</h4>
              <p className="text-text-tertiary text-sm">Enterprise financial intelligence powered by AI</p>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Product</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">Features</a></li>
                <li><a href="#" className="hover:text-electric-400">Pricing</a></li>
                <li><a href="#" className="hover:text-electric-400">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Company</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">About</a></li>
                <li><a href="#" className="hover:text-electric-400">Blog</a></li>
                <li><a href="#" className="hover:text-electric-400">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Legal</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">Privacy</a></li>
                <li><a href="#" className="hover:text-electric-400">Terms</a></li>
                <li><a href="#" className="hover:text-electric-400">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-base-700 pt-8 text-center text-text-tertiary text-sm">
            <p>&copy; 2026 ZephyBloom. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
