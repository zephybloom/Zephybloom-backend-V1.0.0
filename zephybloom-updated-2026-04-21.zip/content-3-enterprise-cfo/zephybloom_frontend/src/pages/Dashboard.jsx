import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { Navbar, Sidebar } from '../components'
import { AlertTriangle, ArrowRight, BarChart3, Bot, Briefcase, Database, LineChart, Target } from 'lucide-react'
import { dataRoom } from '../utils/api'
import { loadOnboardingState, normalizeFieldValue } from './onboarding/onboardingState'

function formatCurrency(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return 'N/A'
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value))
}

function formatPercent(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return 'N/A'
  return `${Number(value).toFixed(1)}%`
}

function buildMetrics(companyData) {
  const revenue = normalizeFieldValue('annual_revenue', companyData.annual_revenue) || 0
  const variableCosts = normalizeFieldValue('variable_costs', companyData.variable_costs) || 0
  const fixedCosts = normalizeFieldValue('fixed_costs', companyData.fixed_costs) || 0
  const investedCapital = normalizeFieldValue('invested_capital', companyData.invested_capital) || 0
  const grossProfit = revenue - variableCosts
  const netProfit = revenue - variableCosts - fixedCosts
  const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0
  const netMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0
  const roi = investedCapital > 0 ? (netProfit / investedCapital) * 100 : null
  return { revenue, variableCosts, fixedCosts, investedCapital, grossProfit, netProfit, grossMargin, netMargin, roi }
}

function toneForReadiness(level) {
  if (level === 'cfo_ready') return 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10'
  if (level === 'analysis_ready') return 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10'
  if (level === 'guided_collection_needed') return 'text-amber-300 border-amber-500/30 bg-amber-500/10'
  return 'text-rose-300 border-rose-500/30 bg-rose-500/10'
}

export default function Dashboard() {
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [user, setUser] = useState(null)
  const onboardingState = useMemo(() => loadOnboardingState(), [])
  const metrics = useMemo(() => buildMetrics(onboardingState.companyData || {}), [onboardingState])
  const [roomContext, setRoomContext] = useState(null)

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userStr = localStorage.getItem('user')
    if (!token) {
      navigate('/login')
      return
    }
    if (userStr) {
      try {
        setUser(JSON.parse(userStr))
      } catch (error) {
        console.error('Failed to parse user', error)
      }
    }
    dataRoom.getContext('default')
      .then((response) => setRoomContext(response.data.context))
      .catch(() => setRoomContext(null))
  }, [navigate])

  const topActions = [
    {
      title: 'Parla con il CFO',
      description: 'Apri la chat e chiedi subito dove stai perdendo margine o cassa.',
      to: '/chat',
      icon: Bot,
    },
    {
      title: 'Simula uno scenario',
      description: 'Testa prezzo, volume, costi o personale prima di muoverti.',
      to: '/scenarios',
      icon: LineChart,
    },
    {
      title: 'Completa la Data Room',
      description: 'Chiudi i dati mancanti per avere diagnosi e priorità più forti.',
      to: '/onboarding/welcome',
      icon: Database,
    },
    {
      title: 'Apri il workbench',
      description: 'Usa il brief operativo quando vuoi lavorare sui numeri in dettaglio.',
      to: '/brief',
      icon: Briefcase,
    },
  ]

  const companyName = onboardingState.companyData?.company_name || 'La tua azienda'
  const sector = onboardingState.companyData?.settore || onboardingState.activeSector || 'business'

  return (
    <div className="min-h-screen bg-base-900">
      <Navbar onMenuClick={() => setSidebarOpen(true)} user={user} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="pt-16 lg:pl-64">
        <div className="space-y-8 p-6">
          <section className="rounded-lg border border-base-500 bg-base-800 p-8">
            <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Dashboard CFO</p>
            <div className="mt-4 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <h1 className="text-4xl font-bold text-text-primary">{companyName}</h1>
                <p className="mt-3 max-w-3xl text-text-secondary">
                  Questa deve essere la tua home vera: numeri chiave, priorità, qualità dati e accesso rapido a chat, simulate e decisioni.
                </p>
              </div>
              <div className={`rounded-lg border px-4 py-4 ${toneForReadiness(roomContext?.readiness_level)}`}>
                <p className="text-xs uppercase tracking-wide">Readiness Data Room</p>
                <p className="mt-2 text-3xl font-bold">{roomContext?.readiness_score_pct ?? 0}%</p>
                <p className="mt-2 text-sm">{roomContext?.readiness_level || 'not_started'}</p>
              </div>
            </div>
          </section>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="rounded-lg border border-base-500 bg-base-800 p-5">
              <p className="text-sm text-text-tertiary">Fatturato</p>
              <p className="mt-2 text-3xl font-bold text-text-primary">{formatCurrency(metrics.revenue)}</p>
              <p className="mt-2 text-sm text-text-secondary">Base attuale letta dal profilo azienda</p>
            </div>
            <div className="rounded-lg border border-base-500 bg-base-800 p-5">
              <p className="text-sm text-text-tertiary">Margine lordo</p>
              <p className="mt-2 text-3xl font-bold text-cyan-300">{formatPercent(metrics.grossMargin)}</p>
              <p className="mt-2 text-sm text-text-secondary">Serve per capire se ogni vendita crea abbastanza contribuzione</p>
            </div>
            <div className="rounded-lg border border-base-500 bg-base-800 p-5">
              <p className="text-sm text-text-tertiary">Utile netto</p>
              <p className={`mt-2 text-3xl font-bold ${metrics.netProfit >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>{formatCurrency(metrics.netProfit)}</p>
              <p className="mt-2 text-sm text-text-secondary">Quello che resta dopo costi variabili e fissi</p>
            </div>
            <div className="rounded-lg border border-base-500 bg-base-800 p-5">
              <p className="text-sm text-text-tertiary">ROI</p>
              <p className="mt-2 text-3xl font-bold text-electric-300">{metrics.roi === null ? 'N/A' : formatPercent(metrics.roi)}</p>
              <p className="mt-2 text-sm text-text-secondary">Rendimento del capitale se hai inserito investimenti</p>
            </div>
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-center gap-3">
                <Target className="h-5 w-5 text-electric-400" />
                <h2 className="text-xl font-bold text-text-primary">Le 4 azioni da avere sempre a portata di mano</h2>
              </div>
              <div className="mt-6 grid gap-4 md:grid-cols-2">
                {topActions.map((item) => {
                  const Icon = item.icon
                  return (
                    <Link key={item.title} to={item.to} className="rounded-lg border border-base-600 bg-base-900 p-5 transition-colors hover:border-electric-400 hover:bg-base-700">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold text-text-primary">{item.title}</p>
                          <p className="mt-2 text-sm text-text-tertiary">{item.description}</p>
                        </div>
                        <Icon className="h-5 w-5 text-electric-400" />
                      </div>
                    </Link>
                  )
                })}
              </div>
            </div>

            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-300" />
                <h2 className="text-xl font-bold text-text-primary">Punto da sbloccare adesso</h2>
              </div>
              <div className="mt-5 rounded-lg border border-base-600 bg-base-900 p-5">
                <p className="text-sm font-medium text-text-primary">Settore attivo</p>
                <p className="mt-2 text-lg text-text-secondary">{sector}</p>
              </div>
              <div className="mt-4 rounded-lg border border-base-600 bg-base-900 p-5">
                <p className="text-sm font-medium text-text-primary">Prossima domanda utile</p>
                <p className="mt-2 text-sm text-text-secondary">
                  {(roomContext?.next_questions || [])[0] || 'Completa il profilo economico e i dati verticali per avere una lettura da CFO più forte.'}
                </p>
              </div>
              <div className="mt-5">
                <Link to="/onboarding/welcome" className="inline-flex items-center gap-2 text-sm font-semibold text-electric-400">
                  Vai alla Data Room
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </section>

          <section className="grid gap-6 lg:grid-cols-3">
            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-center gap-3">
                <BarChart3 className="h-5 w-5 text-cyan-300" />
                <h3 className="text-lg font-bold text-text-primary">Panoramica</h3>
              </div>
              <p className="mt-3 text-sm text-text-secondary">
                Questa dashboard deve restituirti in 10 secondi: dove sei, cosa conta e dove cliccare dopo.
              </p>
            </div>
            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-center gap-3">
                <Bot className="h-5 w-5 text-electric-300" />
                <h3 className="text-lg font-bold text-text-primary">Chat</h3>
              </div>
              <p className="mt-3 text-sm text-text-secondary">
                Se vuoi capire margine, crescita, costi o cassa, la chat è la via più veloce.
              </p>
            </div>
            <div className="rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-center gap-3">
                <LineChart className="h-5 w-5 text-emerald-300" />
                <h3 className="text-lg font-bold text-text-primary">Simulazioni</h3>
              </div>
              <p className="mt-3 text-sm text-text-secondary">
                Lo step successivo è collegare questa home agli scenari e alle decisioni reali del backend.
              </p>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
