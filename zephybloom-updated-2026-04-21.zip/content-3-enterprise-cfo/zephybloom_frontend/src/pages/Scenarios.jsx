import { useState } from 'react'
import { Navbar, Sidebar, Card, Button, KPICard } from '../components'
import { TrendingUp, AlertCircle, CheckCircle } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function Scenarios() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const scenarioData = [
    { month: 'Jan', pessimistic: 80000, realistic: 100000, optimistic: 120000 },
    { month: 'Feb', pessimistic: 82000, realistic: 110000, optimistic: 140000 },
    { month: 'Mar', pessimistic: 85000, realistic: 120000, optimistic: 160000 },
    { month: 'Apr', pessimistic: 88000, realistic: 130000, optimistic: 180000 },
    { month: 'May', pessimistic: 90000, realistic: 145000, optimistic: 200000 },
    { month: 'Jun', pessimistic: 95000, realistic: 160000, optimistic: 220000 },
  ]

  return (
    <div className="min-h-screen bg-base-900">
      <Navbar onMenuClick={() => setSidebarOpen(true)} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="pt-16 lg:pl-64">
        <div className="p-6 space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Financial Scenarios</h1>
            <p className="text-text-secondary">Project 12-month revenue under 3 scenarios with probability weighting</p>
          </div>

          {/* Scenario Comparison Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            {/* Pessimistic */}
            <Card className="relative border-rose-500 border-opacity-30 bg-rose-500 bg-opacity-5">
              <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-rose-500 opacity-10" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-6">
                  <AlertCircle className="w-6 h-6 text-rose-400" />
                  <h3 className="text-lg font-semibold text-rose-400">Pessimistic</h3>
                  <span className="text-xs text-rose-400 bg-rose-500 bg-opacity-20 px-2 py-1 rounded">20% Probability</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Year 1 Revenue</p>
                    <p className="text-2xl font-bold text-rose-400">€1.14M</p>
                  </div>
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Margin</p>
                    <p className="text-2xl font-bold text-rose-400">28%</p>
                  </div>
                  <p className="text-sm text-text-secondary border-t border-rose-500 border-opacity-20 pt-4">Market contraction, higher customer churn</p>
                </div>
              </div>
            </Card>

            {/* Realistic */}
            <Card className="relative border-electric-500 border-opacity-30 bg-electric-500 bg-opacity-5 ring-2 ring-electric-500 ring-opacity-30">
              <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-electric-500 opacity-10" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-6">
                  <CheckCircle className="w-6 h-6 text-electric-400" />
                  <h3 className="text-lg font-semibold text-electric-400">Realistic</h3>
                  <span className="text-xs text-electric-400 bg-electric-500 bg-opacity-20 px-2 py-1 rounded">50% Probability</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Year 1 Revenue</p>
                    <p className="text-2xl font-bold text-electric-400">€1.92M</p>
                  </div>
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Margin</p>
                    <p className="text-2xl font-bold text-electric-400">38%</p>
                  </div>
                  <p className="text-sm text-text-secondary border-t border-electric-500 border-opacity-20 pt-4">Steady growth, executing plan as planned</p>
                </div>
              </div>
            </Card>

            {/* Optimistic */}
            <Card className="relative border-emerald-500 border-opacity-30 bg-emerald-500 bg-opacity-5">
              <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-emerald-500 opacity-10" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp className="w-6 h-6 text-emerald-400" />
                  <h3 className="text-lg font-semibold text-emerald-400">Optimistic</h3>
                  <span className="text-xs text-emerald-400 bg-emerald-500 bg-opacity-20 px-2 py-1 rounded">30% Probability</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Year 1 Revenue</p>
                    <p className="text-2xl font-bold text-emerald-400">€2.64M</p>
                  </div>
                  <div>
                    <p className="text-text-tertiary text-sm mb-1">Margin</p>
                    <p className="text-2xl font-bold text-emerald-400">42%</p>
                  </div>
                  <p className="text-sm text-text-secondary border-t border-emerald-500 border-opacity-20 pt-4">Market expansion, premium pricing power</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Expected Value Summary */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-4">Expected Value Analysis</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Expected Revenue (Probability-Weighted)</p>
                <p className="text-3xl font-bold text-electric-400">€1.89M</p>
              </div>
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Range (Pessimistic → Optimistic)</p>
                <p className="text-3xl font-bold text-text-primary">€1.14M — €2.64M</p>
              </div>
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Recommended Planning Base</p>
                <p className="text-3xl font-bold text-violet-400">Realistic</p>
              </div>
            </div>
          </Card>

          {/* Chart */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">12-Month Revenue Projection</h3>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={scenarioData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2D3454" />
                <XAxis dataKey="month" stroke="#94A3B8" />
                <YAxis stroke="#94A3B8" />
                <Tooltip contentStyle={{ backgroundColor: '#1A1F3A', border: '1px solid #2D3454', borderRadius: '8px' }} />
                <Legend />
                <Line type="monotone" dataKey="pessimistic" stroke="#F43F5E" name="Pessimistic (20%)" strokeWidth={2} />
                <Line type="monotone" dataKey="realistic" stroke="#0EA5E9" name="Realistic (50%)" strokeWidth={2} />
                <Line type="monotone" dataKey="optimistic" stroke="#10B981" name="Optimistic (30%)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Actions */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-4">Next Steps</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <Button variant="secondary">Create Custom Scenario</Button>
              <Button variant="secondary">Compare with Competitors</Button>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}
