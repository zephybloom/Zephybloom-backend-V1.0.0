import { useEffect, useMemo, useState } from 'react'
import { Navbar, Sidebar, Button, Input } from '../components'
import { Loader, MessageCircle, Send } from 'lucide-react'
import { chat, dataRoom } from '../utils/api'
import { loadOnboardingState, normalizeFieldValue } from './onboarding/onboardingState'

function buildCompanyData(state) {
  const company = state.companyData || {}
  return {
    company_name: company.company_name || 'Azienda',
    settore: company.settore || state.activeSector || 'restaurant',
    fatturato: normalizeFieldValue('annual_revenue', company.annual_revenue) || 0,
    costi_variabili: normalizeFieldValue('variable_costs', company.variable_costs) || 0,
    costi_fissi: normalizeFieldValue('fixed_costs', company.fixed_costs) || 0,
    investimenti: normalizeFieldValue('invested_capital', company.invested_capital) || 0,
    employee_count: normalizeFieldValue('employee_count', company.employee_count),
    payroll_costs: normalizeFieldValue('payroll_costs', company.payroll_costs),
    average_ticket: normalizeFieldValue('average_ticket', company.average_ticket),
    cash_on_hand: normalizeFieldValue('cash_on_hand', company.cash_on_hand),
  }
}

export default function Chat() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const onboardingState = useMemo(() => loadOnboardingState(), [])
  const [companyData, setCompanyData] = useState(() => buildCompanyData(onboardingState))
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'ai',
      text: `Ciao. Ho preso come base ${buildCompanyData(onboardingState).company_name} nel settore ${buildCompanyData(onboardingState).settore}. Fammi una domanda su margine, crescita, costi, cassa o simulazioni e ti rispondo come CFO.`,
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    let mounted = true
    dataRoom.get('default')
      .then((response) => {
        if (!mounted) return
        const snapshot = response.data?.snapshot || {}
        const savedCompany = snapshot.company_data || {}
        const nextCompanyData = {
          ...buildCompanyData(onboardingState),
          company_name: savedCompany.company_name || savedCompany.name || buildCompanyData(onboardingState).company_name,
          settore: savedCompany.settore || savedCompany.sector || snapshot.active_sector || buildCompanyData(onboardingState).settore,
          fatturato: savedCompany.fatturato ?? savedCompany.annual_revenue ?? buildCompanyData(onboardingState).fatturato,
          costi_variabili: savedCompany.costi_variabili ?? savedCompany.variable_costs ?? buildCompanyData(onboardingState).costi_variabili,
          costi_fissi: savedCompany.costi_fissi ?? savedCompany.fixed_costs ?? buildCompanyData(onboardingState).costi_fissi,
          investimenti: savedCompany.investimenti ?? savedCompany.invested_capital ?? buildCompanyData(onboardingState).investimenti,
          employee_count: savedCompany.employee_count ?? buildCompanyData(onboardingState).employee_count,
          payroll_costs: savedCompany.payroll_costs ?? buildCompanyData(onboardingState).payroll_costs,
          average_ticket: savedCompany.average_ticket ?? buildCompanyData(onboardingState).average_ticket,
          cash_on_hand: savedCompany.cash_on_hand ?? buildCompanyData(onboardingState).cash_on_hand,
        }
        setCompanyData(nextCompanyData)
        setMessages([
          {
            id: 1,
            type: 'ai',
            text: `Ciao. Ho preso come base ${nextCompanyData.company_name} nel settore ${nextCompanyData.settore}. Fammi una domanda su margine, crescita, costi, cassa o simulazioni e ti rispondo come CFO.`,
          },
        ])
      })
      .catch(() => {
        setCompanyData(buildCompanyData(onboardingState))
      })
    return () => {
      mounted = false
    }
  }, [onboardingState])

  const suggestions = [
    'Quali sono i miei punti deboli?',
    'Come posso aumentare il fatturato?',
    'Dove conviene tagliare i costi?',
    'Simula +5% prezzo e +10% volume',
  ]

  const handleSend = async (presetMessage) => {
    const messageToSend = (presetMessage ?? input).trim()
    if (!messageToSend || loading) return

    const nextUserMessage = { id: Date.now(), type: 'user', text: messageToSend }
    const nextMessages = [...messages, nextUserMessage]
    setMessages(nextMessages)
    setInput('')
    setLoading(true)
    setError('')

    try {
      const history = nextMessages.map((message) => ({
        role: message.type === 'user' ? 'user' : 'assistant',
        content: message.text,
      }))

      const response = await chat.sendMessage(messageToSend, companyData, history)
      const body = response.data

      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          type: 'ai',
          text: body.response || 'Non ho ricevuto una risposta valida dal CFO.',
        },
      ])
    } catch (requestError) {
      const detail = requestError.response?.data?.detail || requestError.message || 'Errore di rete'
      setError(String(detail))
      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          type: 'ai',
          text: 'C’è stato un problema nel collegamento con il CFO. Riprova tra poco.',
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base-900">
      <Navbar onMenuClick={() => setSidebarOpen(true)} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="flex h-screen flex-col pt-16 lg:pl-64">
        <div className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-4xl">
            <div className="mb-6 rounded-lg border border-base-500 bg-base-800 p-6">
              <div className="flex items-start gap-3">
                <MessageCircle className="mt-1 h-6 w-6 text-electric-400" />
                <div>
                  <h1 className="text-3xl font-bold text-text-primary">Chat CFO</h1>
                  <p className="mt-2 text-text-secondary">
                    Qui non dovresti più vedere testo finto. La chat è collegata al backend e usa i dati aziendali salvati come base di lettura.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-3xl rounded-lg p-4 ${
                      msg.type === 'user'
                        ? 'bg-electric-500 text-base-900'
                        : 'border border-base-500 bg-base-800 text-text-primary'
                    }`}
                  >
                    <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</p>
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex justify-start">
                  <div className="rounded-lg border border-base-500 bg-base-800 p-4">
                    <Loader className="h-5 w-5 animate-spin text-electric-400" />
                  </div>
                </div>
              )}
            </div>

            {messages.length === 1 && !loading && (
              <div className="mt-8 rounded-lg border border-base-500 bg-base-800 p-6">
                <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Domande rapide</p>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  {suggestions.map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => handleSend(suggestion)}
                      className="rounded-lg border border-base-500 bg-base-900 p-4 text-left text-sm text-text-secondary transition-colors hover:border-electric-400 hover:text-text-primary"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-base-800 bg-base-900 p-6">
          <div className="mx-auto max-w-4xl">
            {error && (
              <div className="mb-4 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
                {error}
              </div>
            )}

            <div className="flex gap-4">
              <Input
                placeholder="Scrivi una domanda al CFO..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    handleSend()
                  }
                }}
                className="flex-1"
              />
              <Button onClick={() => handleSend()} disabled={!input.trim() || loading}>
                <Send className="h-5 w-5" />
              </Button>
            </div>
            <p className="mt-2 text-xs text-text-tertiary">
              Esempi: “come aumento il margine”, “dove perdo soldi”, “simula +5% prezzo”, “quali sono i miei punti deboli”.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
