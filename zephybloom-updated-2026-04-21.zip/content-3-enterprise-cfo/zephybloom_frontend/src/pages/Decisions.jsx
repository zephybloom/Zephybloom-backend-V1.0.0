import { useState } from 'react'
import { Navbar, Sidebar, Card, Button } from '../components'
import { TrendingUp, DollarSign, Users, Zap, ArrowRight } from 'lucide-react'

export default function Decisions() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const decisions = [
    { icon: DollarSign, title: 'Increase Pricing +2%', metric: '€18.7K', roi: '1,200%', payback: '1 month', color: 'electric' },
    { icon: Zap, title: 'Reduce Costs -10%', metric: '€105K', roi: '2,000%', payback: '0.6 months', color: 'emerald' },
    { icon: Users, title: 'Hire 2 Sales Engineers', metric: '€109K', roi: '109%', payback: '11 months', color: 'violet' },
    { icon: TrendingUp, title: 'Market Expansion €100K', metric: '€25K', roi: '25%', payback: '48 months', color: 'cyan' },
  ]

  return (
    <div className="min-h-screen bg-base-900">
      <Navbar onMenuClick={() => setSidebarOpen(true)} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="pt-16 lg:pl-64">
        <div className="p-6 space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Strategic Decisions</h1>
            <p className="text-text-secondary">Evaluate ROI, payback, and impact of critical decisions</p>
          </div>

          {/* Decision Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            {decisions.map((decision, idx) => {
              const Icon = decision.icon
              const colorMap = {
                electric: { bg: 'bg-electric-500', bgOpacity: 'bg-opacity-10', text: 'text-electric-400' },
                emerald: { bg: 'bg-emerald-500', bgOpacity: 'bg-opacity-10', text: 'text-emerald-400' },
                violet: { bg: 'bg-violet-500', bgOpacity: 'bg-opacity-10', text: 'text-violet-400' },
                cyan: { bg: 'bg-cyan-500', bgOpacity: 'bg-opacity-10', text: 'text-cyan-400' },
              }
              const color = colorMap[decision.color]
              
              return (
                <Card key={idx} className={`${color.bg} ${color.bgOpacity} border-opacity-30`}>
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className={`w-12 h-12 rounded-lg ${color.bg} ${color.bgOpacity} flex items-center justify-center mb-4`}>
                        <Icon className={`w-6 h-6 ${color.text}`} />
                      </div>
                      <h3 className="font-semibold text-text-primary">{decision.title}</h3>
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full ${color.bg} ${color.bgOpacity} ${color.text} font-medium`}>
                      Recommended
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 py-6 border-t border-base-500 border-opacity-50">
                    <div>
                      <p className="text-text-tertiary text-xs mb-1">Profit Uplift</p>
                      <p className={`font-bold ${color.text}`}>{decision.metric}</p>
                    </div>
                    <div>
                      <p className="text-text-tertiary text-xs mb-1">ROI</p>
                      <p className={`font-bold ${color.text}`}>{decision.roi}</p>
                    </div>
                    <div>
                      <p className="text-text-tertiary text-xs mb-1">Payback</p>
                      <p className={`font-bold ${color.text}`}>{decision.payback}</p>
                    </div>
                  </div>

                  <Button variant="secondary" className="w-full mt-4">
                    Analyze <ArrowRight className="w-4 h-4" />
                  </Button>
                </Card>
              )
            })}
          </div>

          {/* Portfolio summary */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">Decision Portfolio</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Total Profit Uplift</p>
                <p className="text-2xl font-bold text-electric-400">€257.7K</p>
              </div>
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Portfolio ROI</p>
                <p className="text-2xl font-bold text-emerald-400">124%</p>
              </div>
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Total Investment</p>
                <p className="text-2xl font-bold text-text-primary">€206K</p>
              </div>
              <div className="bg-base-700 rounded-lg p-4">
                <p className="text-text-tertiary text-sm mb-2">Avg Payback</p>
                <p className="text-2xl font-bold text-violet-400">15 months</p>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}
