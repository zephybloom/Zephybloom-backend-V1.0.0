import { Link } from 'react-router-dom'
import { Button } from '../components'
import { ArrowRight, Check, BarChart3, TrendingUp, Zap, Shield } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-base-900">
      {/* Navbar (landing) */}
      <nav className="fixed top-0 left-0 right-0 bg-base-900 bg-opacity-80 backdrop-blur border-b border-base-500 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <h1 className="text-xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent">
            ZephyBloom
          </h1>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-text-secondary hover:text-text-primary transition-colors">
              Sign In
            </Link>
            <Link 
              to="/register"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-4 py-3 hover:bg-electric-600 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-electric-500 bg-opacity-10 border border-electric-500 border-opacity-30 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="text-sm text-electric-400 font-medium">Now available for early access</span>
          </div>

          {/* Headline */}
          <h1 className="text-display-1 font-bold text-text-primary mb-6 leading-tight">
            Your AI CFO, Always On Duty
          </h1>

          {/* Subheading */}
          <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto leading-relaxed">
            ZephyBloom analyzes your financial data, forecasts scenarios, evaluates strategic decisions, and guides hiring—all with the expertise of a world-class CFO.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Link 
              to="/register"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-6 py-3 text-lg hover:bg-electric-600 transition-colors flex items-center justify-center gap-2"
            >
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link 
              to="/features"
              className="border border-base-400 text-electric-500 font-semibold rounded-md px-6 py-3 text-lg hover:bg-base-700 transition-colors"
            >
              View Features
            </Link>
          </div>

          {/* Trust indicators */}
          <p className="text-text-tertiary text-sm">
            No credit card required. Deploy in 5 minutes. Enterprise support included.
          </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            The CFO You've Always Needed
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8 hover:border-electric-500 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-electric-500 bg-opacity-10 flex items-center justify-center mb-6 group-hover:bg-opacity-20 transition-colors">
                <BarChart3 className="w-6 h-6 text-electric-500" />
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Instant KPI Diagnosis</h3>
              <p className="text-text-secondary">
                Upload your financials. Get a complete 7-area health scorecard in minutes. Know exactly where your business stands.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8 hover:border-electric-500 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-emerald-500 bg-opacity-10 flex items-center justify-center mb-6 group-hover:bg-opacity-20 transition-colors">
                <TrendingUp className="w-6 h-6 text-emerald-500" />
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Scenario Planning</h3>
              <p className="text-text-secondary">
                Project 3 financial scenarios—pessimistic, realistic, optimistic—with probability weighting for informed strategic decisions.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8 hover:border-electric-500 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-violet-500 bg-opacity-10 flex items-center justify-center mb-6 group-hover:bg-opacity-20 transition-colors">
                <Zap className="w-6 h-6 text-violet-500" />
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Decision Impact Analysis</h3>
              <p className="text-text-secondary">
                Evaluate any strategic move—pricing, costs, hiring, investment. See ROI, payback period, and risk before committing capital.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8 hover:border-electric-500 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-cyan-500 bg-opacity-10 flex items-center justify-center mb-6 group-hover:bg-opacity-20 transition-colors">
                <Shield className="w-6 h-6 text-cyan-500" />
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">AI CFO Assistant</h3>
              <p className="text-text-secondary">
                Chat with your CFO. Ask strategic questions, explore alternatives, get actionable recommendations backed by data.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            Simple, Transparent Pricing
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Starter */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-xl font-semibold text-text-primary mb-2">Starter</h3>
              <p className="text-text-tertiary text-sm mb-6">For individuals and small teams</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-text-primary">€99</span>
                <span className="text-text-tertiary">/month</span>
              </div>
              <Button variant="secondary" className="w-full mb-8">
                Start Free Trial
              </Button>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  Up to 5 companies
                </li>
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  KPI Diagnosis
                </li>
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  Basic scenarios
                </li>
              </ul>
            </div>

            {/* Professional (Featured) */}
            <div className="bg-gradient-to-br from-electric-500 to-cyan-500 rounded-xl p-px">
              <div className="bg-base-800 rounded-xl p-8 relative">
                <span className="absolute -top-4 left-4 bg-electric-500 text-base-900 px-3 py-1 rounded-full text-xs font-bold">
                  MOST POPULAR
                </span>
                <h3 className="text-xl font-semibold text-text-primary mb-2 mt-2">Professional</h3>
                <p className="text-text-tertiary text-sm mb-6">For growing businesses</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-text-primary">€299</span>
                  <span className="text-text-tertiary">/month</span>
                </div>
                <Button className="w-full mb-8">
                  Start Free Trial
                </Button>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-text-secondary">
                    <Check className="w-5 h-5 text-emerald-400" />
                    Unlimited companies
                  </li>
                  <li className="flex items-center gap-3 text-text-secondary">
                    <Check className="w-5 h-5 text-emerald-400" />
                    Decision Analysis
                  </li>
                  <li className="flex items-center gap-3 text-text-secondary">
                    <Check className="w-5 h-5 text-emerald-400" />
                    AI CFO Chat
                  </li>
                </ul>
              </div>
            </div>

            {/* Enterprise */}
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-xl font-semibold text-text-primary mb-2">Enterprise</h3>
              <p className="text-text-tertiary text-sm mb-6">For large organizations</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-text-primary">Custom</span>
              </div>
              <Button variant="secondary" className="w-full mb-8">
                Contact Sales
              </Button>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  Everything in Pro
                </li>
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  SSO & advanced security
                </li>
                <li className="flex items-center gap-3 text-text-secondary">
                  <Check className="w-5 h-5 text-emerald-400" />
                  Dedicated support
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-text-primary mb-6">
            Ready to Transform Your Finance?
          </h2>
          <p className="text-xl text-text-secondary mb-8">
            Join hundreds of companies trusting ZephyBloom for strategic financial intelligence.
          </p>
          <Link 
            to="/register"
            className="bg-electric-500 text-base-900 font-semibold rounded-md px-6 py-3 text-lg hover:bg-electric-600 transition-colors inline-flex items-center justify-center gap-2"
          >
            Get Started Free
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-base-800 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <p className="text-text-tertiary">©2026 ZephyBloom. All rights reserved.</p>
          <div className="flex items-center gap-8 text-text-tertiary text-sm">
            <a href="#" className="hover:text-text-primary transition-colors">Documentation</a>
            <a href="#" className="hover:text-text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-text-primary transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-text-primary transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
