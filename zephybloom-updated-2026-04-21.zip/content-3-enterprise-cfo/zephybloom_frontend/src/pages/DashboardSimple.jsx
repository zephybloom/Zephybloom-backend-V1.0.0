import { Link, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { dashboard, dataRoom } from '../utils/api'
import { MessageCircle, PlayCircle, LayoutDashboard, Database, ArrowRightLeft, BarChart3 } from 'lucide-react'

const initialCompany = {
  fatturato: 1000000,
  costi_variabili: 420000,
  costi_fissi: 360000,
  investimenti: 60000,
  settore: 'saas',
  company_name: 'Demo Company',
}

const sectorOptions = ['saas', 'retail', 'manufacturing', 'services', 'ecommerce', 'default']

function formatCurrency(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return 'N/A'
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value))
}

function formatPercent(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return 'N/A'
  return `${Number(value).toFixed(1)}%`
}

function Field({ label, name, value, onChange, type = 'number' }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-text-secondary">{label}</span>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        className="mt-2 w-full rounded-md border border-base-500 bg-base-900 px-3 py-2 text-text-primary outline-none focus:border-electric-400"
      />
    </label>
  )
}

function Metric({ label, value, tone = 'text-text-primary' }) {
  return (
    <div className="rounded-lg border border-base-600 bg-base-800 p-4">
      <p className="text-sm text-text-tertiary">{label}</p>
      <p className={`mt-2 text-2xl font-bold ${tone}`}>{value}</p>
    </div>
  )
}

export default function DashboardSimple() {
  const navigate = useNavigate()
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [company, setCompany] = useState(initialCompany)
  const [specificQuestion, setSpecificQuestion] = useState("Cos'è il ROI?")
  const [useMock, setUseMock] = useState(true)
  const [brief, setBrief] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [error, setError] = useState('')
  const [dataRoomContext, setDataRoomContext] = useState(null)

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userStr = localStorage.getItem('user')

    if (!token) {
      navigate('/login')
      return
    }

    if (userStr) {
      try {
        setUser(JSON.parse(userStr))
      } catch (e) {
        console.error('Failed to parse user:', e)
      }
    }

    dataRoom.getContext('default')
      .then((response) => {
        setDataRoomContext(response.data.context)
      })
      .catch(() => {
        setDataRoomContext(null)
      })

    setLoading(false)
  }, [navigate])

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    navigate('/login')
  }

  const handleCompanyChange = (event) => {
    const { name, value, type } = event.target
    setCompany((current) => ({
      ...current,
      [name]: type === 'number' ? Number(value) : value,
    }))
  }

  const runBrief = async (event) => {
    event.preventDefault()
    setAnalyzing(true)
    setError('')

    try {
      const response = await dashboard.aiAnalyze(company, specificQuestion, useMock)
      setBrief(response.data)
    } catch (err) {
      const detail = err.response?.data?.detail || err.message || 'Analisi non riuscita'
      setError(String(detail))
    } finally {
      setAnalyzing(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-base-900">
        <div className="text-text-secondary">Loading...</div>
      </div>
    )
  }

  const insight = brief?.industry_insight
  const primary = insight?.primary_constraint
  const nextMove = insight?.next_best_move
  const validation = brief?.answer_validation
  const kpi = brief?.base_analysis?.kpi_snapshot
  const ai = brief?.ai_response

  return (
    <div className="min-h-screen bg-base-900">
      <div className="sticky top-0 z-50 border-b border-base-500 bg-base-800">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div>
            <h1 className="text-2xl font-bold text-electric-400">ZephyBloom</h1>
            <p className="text-sm text-text-tertiary">CFO Brief</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden text-right sm:block">
              <p className="font-medium text-text-primary">{user?.email}</p>
              <p className="text-sm text-text-tertiary">Tenant: {user?.tenant_id}</p>
            </div>
            <button
              onClick={handleLogout}
              className="rounded-md bg-rose-600 px-4 py-2 text-white transition-colors hover:bg-rose-700"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-10">
        <div className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Executive control room</p>
          <h2 className="mt-2 text-4xl font-bold text-text-primary">Trova il vincolo. Decidi la prossima mossa.</h2>
          <p className="mt-3 max-w-3xl text-text-secondary">
            Il brief combina analisi CFO, benchmark settoriali, FAQ verificata e validazione anti-risposte incoerenti.
          </p>
        </div>

        <div className="mb-6 grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          {[
            { to: '/chat', label: 'Chat CFO', copy: 'Parla con il CFO AI', icon: MessageCircle },
            { to: '/scenarios', label: 'Simulate', copy: 'Lavora sugli scenari', icon: PlayCircle },
            { to: '/decisions', label: 'Decisioni', copy: 'Valuta priorità e ROI', icon: ArrowRightLeft },
            { to: '/onboarding/welcome', label: 'Data Room', copy: 'Completa i dati aziendali', icon: Database },
            { to: '/dashboard', label: 'Dashboard', copy: 'Resta sul quadro generale', icon: LayoutDashboard },
          ].map((item) => {
            const Icon = item.icon
            return (
              <Link key={item.label} to={item.to} className="rounded-lg border border-base-500 bg-base-800 p-4 transition-colors hover:border-electric-400 hover:bg-base-700">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-text-primary">{item.label}</p>
                    <p className="mt-1 text-sm text-text-tertiary">{item.copy}</p>
                  </div>
                  <Icon className="h-5 w-5 text-electric-400" />
                </div>
              </Link>
            )
          })}
        </div>

        {dataRoomContext && (
          <div className="mb-6 rounded-lg border border-base-500 bg-base-800 p-5">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Data Room</p>
                <p className="mt-2 text-text-primary">
                  Readiness {dataRoomContext.readiness_score_pct}% · livello {dataRoomContext.readiness_level}
                </p>
                <p className="mt-2 max-w-2xl text-sm text-text-secondary">
                  {(dataRoomContext.next_questions || [])[0] || 'La Data Room è pronta per essere approfondita.'}
                </p>
              </div>
              <button
                onClick={() => navigate('/onboarding/welcome')}
                className="rounded-md border border-base-400 px-4 py-2 text-electric-400 transition-colors hover:bg-base-700"
              >
                Apri onboarding CFO
              </button>
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
          <form onSubmit={runBrief} className="rounded-lg border border-base-500 bg-base-800 p-6">
            <h3 className="text-xl font-bold text-text-primary">Dati azienda</h3>
            <p className="mt-1 text-sm text-text-tertiary">Usa il mock per demo veloci senza chiamata OpenAI.</p>

            <div className="mt-6 grid gap-4">
              <Field label="Nome azienda" name="company_name" value={company.company_name} onChange={handleCompanyChange} type="text" />
              <label className="block">
                <span className="text-sm font-medium text-text-secondary">Settore</span>
                <select
                  name="settore"
                  value={company.settore}
                  onChange={handleCompanyChange}
                  className="mt-2 w-full rounded-md border border-base-500 bg-base-900 px-3 py-2 text-text-primary outline-none focus:border-electric-400"
                >
                  {sectorOptions.map((sector) => (
                    <option key={sector} value={sector}>{sector}</option>
                  ))}
                </select>
              </label>
              <Field label="Fatturato" name="fatturato" value={company.fatturato} onChange={handleCompanyChange} />
              <Field label="Costi variabili" name="costi_variabili" value={company.costi_variabili} onChange={handleCompanyChange} />
              <Field label="Costi fissi" name="costi_fissi" value={company.costi_fissi} onChange={handleCompanyChange} />
              <Field label="Investimenti" name="investimenti" value={company.investimenti} onChange={handleCompanyChange} />
              <label className="block">
                <span className="text-sm font-medium text-text-secondary">Domanda CFO</span>
                <textarea
                  value={specificQuestion}
                  onChange={(event) => setSpecificQuestion(event.target.value)}
                  rows={3}
                  className="mt-2 w-full rounded-md border border-base-500 bg-base-900 px-3 py-2 text-text-primary outline-none focus:border-electric-400"
                />
              </label>
              <label className="flex items-center gap-3 text-sm text-text-secondary">
                <input
                  type="checkbox"
                  checked={useMock}
                  onChange={(event) => setUseMock(event.target.checked)}
                  className="h-4 w-4"
                />
                Usa provider mock
              </label>
            </div>

            {error && (
              <div className="mt-4 rounded-md border border-rose-500 bg-rose-950 px-4 py-3 text-sm text-rose-100">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={analyzing}
              className="mt-6 w-full rounded-md bg-electric-500 px-4 py-3 font-semibold text-base-900 transition-colors hover:bg-electric-600 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {analyzing ? 'Analisi in corso...' : 'Genera CFO Brief'}
            </button>
          </form>

          <section className="space-y-6">
            {!brief ? (
              <div className="flex min-h-[520px] items-center rounded-lg border border-base-500 bg-base-800 p-8">
                <div>
                  <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">Pronto</p>
                  <h3 className="mt-2 text-3xl font-bold text-text-primary">Il prossimo brief parte dai dati reali.</h3>
                  <p className="mt-3 max-w-2xl text-text-secondary">
                    L'output mostrerà vincolo principale, finestra di rischio, benchmark, risposta AI validata e FAQ usata come fonte.
                  </p>
                </div>
              </div>
            ) : (
              <>
                <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-wide text-electric-400">CFO verdict</p>
                      <h3 className="mt-2 text-3xl font-bold text-text-primary">{insight?.health_label || brief.base_analysis?.headline}</h3>
                      <p className="mt-3 max-w-3xl text-text-secondary">{primary?.summary || brief.base_analysis?.summary}</p>
                    </div>
                    <div className="rounded-md border border-base-600 bg-base-900 px-4 py-3">
                      <p className="text-xs uppercase tracking-wide text-text-tertiary">Fonte risposta</p>
                      <p className="mt-1 font-semibold text-emerald-400">{validation?.response_source || 'N/A'}</p>
                    </div>
                  </div>

                  <div className="mt-6 grid gap-4 md:grid-cols-4">
                    <Metric label="Fatturato" value={formatCurrency(company.fatturato)} tone="text-electric-400" />
                    <Metric label="Gross margin" value={formatPercent(kpi?.gross_margin_pct)} tone="text-cyan-400" />
                    <Metric label="Net margin" value={formatPercent(kpi?.net_margin_pct)} tone={kpi?.net_margin_pct < 0 ? 'text-rose-400' : 'text-emerald-400'} />
                    <Metric label="ROI" value={formatPercent(kpi?.roi_pct)} tone={kpi?.roi_pct < 0 ? 'text-rose-400' : 'text-emerald-400'} />
                  </div>
                </div>

                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                    <h4 className="text-lg font-bold text-text-primary">Vincolo principale</h4>
                    <p className="mt-2 text-2xl font-bold text-electric-400">{primary?.type || 'N/A'}</p>
                    <div className="mt-4 grid grid-cols-2 gap-3">
                      <div className="rounded-md bg-base-900 p-3">
                        <p className="text-xs text-text-tertiary">Risk window</p>
                        <p className="mt-1 font-semibold text-text-primary">{primary?.risk_window || 'N/A'}</p>
                      </div>
                      <div className="rounded-md bg-base-900 p-3">
                        <p className="text-xs text-text-tertiary">Postura</p>
                        <p className="mt-1 font-semibold text-text-primary">{insight?.strategic_posture || 'N/A'}</p>
                      </div>
                    </div>
                    <p className="mt-4 text-text-secondary">{nextMove?.move}</p>
                  </div>

                  <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                    <h4 className="text-lg font-bold text-text-primary">Validazione risposta</h4>
                    <p className={`mt-2 text-2xl font-bold ${validation?.is_valid ? 'text-emerald-400' : 'text-amber-300'}`}>
                      {validation?.is_valid ? 'Coerente' : 'Fallback attivato'}
                    </p>
                    <div className="mt-4 space-y-2">
                      {(validation?.warnings?.length ? validation.warnings : ['Nessuna deviazione critica rilevata.']).map((warning) => (
                        <p key={warning} className="rounded-md bg-base-900 px-3 py-2 text-sm text-text-secondary">{warning}</p>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                  <h4 className="text-lg font-bold text-text-primary">Next best move</h4>
                  <p className="mt-3 text-xl font-semibold text-electric-400">{ai?.priority_action || nextMove?.move}</p>
                  <div className="mt-5 grid gap-3 md:grid-cols-3">
                    {(ai?.other_actions || insight?.watch_metrics || []).slice(0, 3).map((action) => (
                      <div key={action} className="rounded-md border border-base-600 bg-base-900 p-4 text-sm text-text-secondary">
                        {action}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                    <h4 className="text-lg font-bold text-text-primary">Benchmark gap</h4>
                    <div className="mt-4 space-y-3">
                      {(insight?.benchmark_gaps || []).slice(0, 4).map((gap) => (
                        <div key={gap.metric} className="rounded-md bg-base-900 p-3">
                          <div className="flex items-center justify-between gap-3">
                            <p className="font-semibold text-text-primary">{gap.metric}</p>
                            <p className="text-sm text-text-tertiary">{gap.peer_position}</p>
                          </div>
                          <p className="mt-1 text-sm text-text-secondary">
                            {gap.current_pct}% vs mediana {gap.median_pct}% ({gap.gap_to_median_points} punti)
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                    <h4 className="text-lg font-bold text-text-primary">FAQ knowledge</h4>
                    {brief.faq_context ? (
                      <div className="mt-4 rounded-md bg-base-900 p-4">
                        <p className="text-sm font-semibold text-electric-400">{brief.faq_context.matched_question}</p>
                        <p className="mt-2 max-h-40 overflow-auto text-sm text-text-secondary">{brief.faq_context.answer}</p>
                      </div>
                    ) : (
                      <p className="mt-4 text-text-secondary">Nessuna FAQ agganciata alla domanda.</p>
                    )}
                  </div>
                </div>

                <div className="rounded-lg border border-base-500 bg-base-800 p-6">
                  <h4 className="text-lg font-bold text-text-primary">Sintesi AI governata</h4>
                  <div className="mt-4 whitespace-pre-line rounded-md bg-base-900 p-4 text-sm leading-6 text-text-secondary">
                    {brief.formatted_text}
                  </div>
                </div>
              </>
            )}
          </section>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="flex items-center gap-3">
              <MessageCircle className="h-5 w-5 text-electric-400" />
              <h3 className="text-lg font-bold text-text-primary">Vai in chat</h3>
            </div>
            <p className="mt-3 text-sm text-text-secondary">
              Fai domande tipo: dove perdo soldi, come cresco, cosa taglio, quale leva spingere.
            </p>
            <Link to="/chat" className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-electric-400">
              Apri Chat CFO
              <BarChart3 className="h-4 w-4" />
            </Link>
          </div>

          <div className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="flex items-center gap-3">
              <PlayCircle className="h-5 w-5 text-cyan-400" />
              <h3 className="text-lg font-bold text-text-primary">Simula gli scenari</h3>
            </div>
            <p className="mt-3 text-sm text-text-secondary">
              Prova prezzo, volume, costi, personale o investimenti prima di prendere decisioni.
            </p>
            <Link to="/scenarios" className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-cyan-400">
              Apri Simulate
              <BarChart3 className="h-4 w-4" />
            </Link>
          </div>

          <div className="rounded-lg border border-base-500 bg-base-800 p-6">
            <div className="flex items-center gap-3">
              <Database className="h-5 w-5 text-emerald-400" />
              <h3 className="text-lg font-bold text-text-primary">Completa i dati</h3>
            </div>
            <p className="mt-3 text-sm text-text-secondary">
              Se vuoi risposte più forti, chiudiamo i blocchi dati mancanti senza complicarti la vita.
            </p>
            <Link to="/onboarding/welcome" className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-emerald-400">
              Apri Data Room
              <BarChart3 className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
