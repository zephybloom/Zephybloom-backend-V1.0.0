import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { auth } from '../utils/api'

export default function RegisterPageSimple() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    // Validation
    if (!formData.name || !formData.email || !formData.password) {
      setError('All fields are required')
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match')
      return
    }

    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters')
      return
    }

    // Backend requires: uppercase letter + digit
    if (!/[A-Z]/.test(formData.password)) {
      setError('Password must contain at least one uppercase letter')
      return
    }

    if (!/[0-9]/.test(formData.password)) {
      setError('Password must contain at least one digit')
      return
    }

    setLoading(true)

    try {
      await auth.register(formData.name, formData.email, formData.password)

      // Registration successful - redirect to login
      // Registration does NOT return access_token, so user must login
      localStorage.setItem('registered_email', formData.email)
      
      // Show success message and redirect
      setError('')
      
      // Wait a moment then redirect to login
      setTimeout(() => {
        navigate('/login', { state: { email: formData.email } })
      }, 1000)
    } catch (err) {
      const errorMessage = err.response?.data?.detail || 'Registration failed'
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent block mb-12 text-center">
          ZephyBloom
        </Link>

        <div className="bg-base-800 border border-base-500 rounded-xl p-8">
          <h1 className="text-2xl font-bold text-text-primary mb-2">Get Started Free</h1>
          <p className="text-text-secondary mb-8">Create your ZephyBloom account and start analyzing your business</p>

          {error && (
            <div className="bg-rose-500 bg-opacity-10 border border-rose-500 text-rose-400 rounded-lg p-4 mb-6 text-sm">
              {error}
            </div>
          )}

          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Full Name</label>
              <input
                type="text"
                name="name"
                placeholder="John Doe"
                value={formData.name}
                onChange={handleChange}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Email Address</label>
              <input
                type="email"
                name="email"
                placeholder="you@company.com"
                value={formData.email}
                onChange={handleChange}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Password</label>
              <input
                type="password"
                name="password"
                placeholder="At least 8 characters"
                value={formData.password}
                onChange={handleChange}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm your password"
                value={formData.confirmPassword}
                onChange={handleChange}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <div className="bg-base-700 rounded-lg p-4 my-6">
              <p className="text-sm font-medium text-text-secondary mb-3">Your free trial includes:</p>
              <ul className="space-y-2">
                <li className="text-sm text-text-tertiary">✓ Full access to all features</li>
                <li className="text-sm text-text-tertiary">✓ 14-day free trial</li>
                <li className="text-sm text-text-tertiary">✓ No credit card required</li>
              </ul>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-electric-500 text-base-900 font-semibold rounded-md py-3 hover:bg-electric-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>

            <p className="text-center text-text-tertiary text-xs">
              By creating an account, you agree to our Terms of Service and Privacy Policy
            </p>
          </form>

          <p className="text-center text-text-secondary mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-electric-400 hover:text-electric-300 font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
