import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { auth } from '../utils/api'

export default function LoginPageSimple() {
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [successMessage, setSuccessMessage] = useState('')

  // Pre-fill email from registration redirect
  useEffect(() => {
    if (location.state?.email) {
      setEmail(location.state.email)
      setSuccessMessage('Registration successful! Please log in with your credentials.')
      setTimeout(() => setSuccessMessage(''), 5000)
    }
  }, [location])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const response = await auth.login(email, password)

      const { access_token, user_id, tenant_id } = response.data
      localStorage.setItem('token', access_token)
      localStorage.setItem('user', JSON.stringify({ email, user_id, tenant_id }))

      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.detail || 'Invalid email or password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent block mb-12 text-center">
          ZephyBloom
        </Link>

        <div className="bg-base-800 border border-base-500 rounded-xl p-8">
          <h1 className="text-2xl font-bold text-text-primary mb-2">Welcome Back</h1>
          <p className="text-text-secondary mb-8">Sign in to your ZephyBloom account</p>

          {successMessage && (
            <div className="bg-emerald-500 bg-opacity-10 border border-emerald-500 text-emerald-400 rounded-lg p-4 mb-6 text-sm">
              ✓ {successMessage}
            </div>
          )}

          {error && (
            <div className="bg-rose-500 bg-opacity-10 border border-rose-500 text-rose-400 rounded-lg p-4 mb-6 text-sm">
              {error}
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Email</label>
              <input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">Password</label>
              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                className="w-full bg-base-700 border border-base-500 text-text-primary rounded-md px-4 py-3 focus:outline-none focus:border-electric-500 disabled:opacity-50"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-electric-500 text-base-900 font-semibold rounded-md py-3 hover:bg-electric-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-text-secondary mt-6">
            Don't have an account?{' '}
            <Link to="/register" className="text-electric-400 hover:text-electric-300 font-medium">
              Sign up
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
