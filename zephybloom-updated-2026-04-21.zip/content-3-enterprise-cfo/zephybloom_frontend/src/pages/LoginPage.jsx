import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { Button, Input } from '../components'
import { Mail, Lock, ArrowRight, AlertCircle } from 'lucide-react'
import { useAuthStore } from '../store/auth'

export default function LoginPage() {
  const navigate = useNavigate()
  const { login, loading, error, clearError } = useAuthStore()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [localError, setLocalError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLocalError('')
    clearError()

    if (!email || !password) {
      setLocalError('Email and password are required')
      return
    }

    const result = await login(email, password)

    if (result.success) {
      navigate('/dashboard')
    } else {
      setLocalError(result.error)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent block mb-12 text-center">
          ZephyBloom
        </Link>

        {/* Card */}
        <div className="bg-base-800 border border-base-500 rounded-xl p-8">
          <h1 className="text-2xl font-bold text-text-primary mb-2">Welcome Back</h1>
          <p className="text-text-secondary mb-8">Sign in to your ZephyBloom account</p>

          {/* Error Alert */}
          {(localError || error) && (
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg p-4 flex gap-3 mb-6">
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-rose-300">{localError || error}</p>
            </div>
          )}

          {/* Form */}
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input
              type="email"
              label="Email Address"
              placeholder="you@company.com"
              icon={<Mail className="w-5 h-5" />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
            />

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-text-secondary">Password</label>
                <Link to="/auth/forgot-password" className="text-sm text-electric-400 hover:text-electric-300">
                  Forgot?
                </Link>
              </div>
              <Input
                type="password"
                placeholder="Enter your password"
                icon={<Lock className="w-5 h-5" />}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full gap-2">
              {loading ? 'Signing In...' : 'Sign In'}
              {!loading && <ArrowRight className="w-5 h-5" />}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-base-500"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-base-800 text-text-tertiary">Or continue with</span>
            </div>
          </div>

          {/* SSO Options */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <Button variant="secondary">Google</Button>
            <Button variant="secondary">Microsoft</Button>
          </div>

          {/* Sign up link */}
          <p className="text-center text-text-secondary">
            Don't have an account?{' '}
            <Link to="/register" className="text-electric-400 hover:text-electric-300 font-medium">
              Sign up
            </Link>
          </p>
        </div>

        {/* Trust footer */}
        <p className="text-center text-text-tertiary text-xs mt-8">
          By signing in, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  )
}
