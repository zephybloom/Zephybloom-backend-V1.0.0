import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { Button, Input } from '../components'
import { Mail, Lock, User, ArrowRight, Check, AlertCircle } from 'lucide-react'
import { useAuthStore } from '../store/auth'

export default function RegisterPage() {
  const navigate = useNavigate()
  const { register, loading, error, clearError } = useAuthStore()

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    company: '',
  })

  const [localError, setLocalError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLocalError('')
    clearError()

    // Validation
    if (!formData.name || !formData.email || !formData.password || !formData.company) {
      setLocalError('All fields are required')
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setLocalError('Passwords do not match')
      return
    }

    if (formData.password.length < 8) {
      setLocalError('Password must be at least 8 characters')
      return
    }

    // Call register
    const result = await register(formData.name, formData.email, formData.password, formData.company)

    if (result.success) {
      navigate('/dashboard')
    } else {
      setLocalError(result.error)
    }
  }

  return (
    <div className="min-h-screen bg-base-900 flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent block mb-12 text-center">
          ZephyBloom
        </Link>

        {/* Card */}
        <div className="bg-base-800 border border-base-500 rounded-xl p-8">
          <h1 className="text-2xl font-bold text-text-primary mb-2">Get Started Free</h1>
          <p className="text-text-secondary mb-8">Create your ZephyBloom account and start analyzing your business in minutes</p>

          {/* Error Alert */}
          {(localError || error) && (
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg p-4 flex gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-rose-300">{localError || error}</p>
            </div>
          )}

          {/* Form */}
          <form className="space-y-4" onSubmit={handleSubmit}>
            <Input
              label="Full Name"
              placeholder="John Doe"
              icon={<User className="w-5 h-5" />}
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              disabled={loading}
            />

            <Input
              label="Company Name"
              placeholder="Your Company"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              disabled={loading}
            />

            <Input
              type="email"
              label="Email Address"
              placeholder="you@company.com"
              icon={<Mail className="w-5 h-5" />}
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              disabled={loading}
            />

            <Input
              type="password"
              label="Password"
              placeholder="At least 8 characters"
              icon={<Lock className="w-5 h-5" />}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              disabled={loading}
            />

            <Input
              type="password"
              label="Confirm Password"
              placeholder="Confirm your password"
              icon={<Lock className="w-5 h-5" />}
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              disabled={loading}
            />

            {/* Features included */}
            <div className="bg-base-700 rounded-lg p-4 my-6">
              <p className="text-sm font-medium text-text-secondary mb-3">Your free trial includes:</p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-text-tertiary">
                  <Check className="w-4 h-4 text-emerald-400" />
                  Full access to all features
                </li>
                <li className="flex items-center gap-2 text-sm text-text-tertiary">
                  <Check className="w-4 h-4 text-emerald-400" />
                  14-day free trial
                </li>
                <li className="flex items-center gap-2 text-sm text-text-tertiary">
                  <Check className="w-4 h-4 text-emerald-400" />
                  No credit card required
                </li>
              </ul>
            </div>

            <Button type="submit" disabled={loading} className="w-full gap-2">
              {loading ? 'Creating Account...' : 'Create Account'}
              {!loading && <ArrowRight className="w-5 h-5" />}
            </Button>

            {/* Terms */}
            <p className="text-center text-text-tertiary text-xs">
              By creating an account, you agree to our{' '}
              <a href="#" className="text-electric-400 hover:text-electric-300">Terms of Service</a> and{' '}
              <a href="#" className="text-electric-400 hover:text-electric-300">Privacy Policy</a>
            </p>
          </form>

          {/* Sign in link */}
          <p className="text-center text-text-secondary mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-electric-400 hover:text-electric-300 font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
