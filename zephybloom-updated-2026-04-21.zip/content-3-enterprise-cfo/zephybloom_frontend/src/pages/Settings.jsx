import { useState } from 'react'
import { Navbar, Sidebar, Card, Button, Input } from '../components'
import { Save, Eye, EyeOff } from 'lucide-react'

export default function Settings() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  return (
    <div className="min-h-screen bg-base-900">
      <Navbar onMenuClick={() => setSidebarOpen(true)} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="pt-16 lg:pl-64">
        <div className="p-6 space-y-8 max-w-2xl">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Settings</h1>
            <p className="text-text-secondary">Manage your account and preferences</p>
          </div>

          {/* Account Settings */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">Account Information</h3>
            <div className="space-y-6">
              <Input label="Full Name" placeholder="John Doe" />
              <Input label="Email Address" type="email" placeholder="john@company.com" />
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Company Name</label>
                <Input placeholder="Your Company" />
              </div>
              <Button>
                <Save className="w-5 h-5" />
                Save Changes
              </Button>
            </div>
          </Card>

          {/* Password */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">Security</h3>
            <div className="space-y-6">
              <Button variant="secondary" className="w-full">Change Password</Button>
              <div className="p-4 bg-base-700 rounded-lg">
                <p className="text-text-secondary text-sm mb-4">Two-Factor Authentication</p>
                <Button variant="secondary" className="w-full">Enable 2FA</Button>
              </div>
            </div>
          </Card>

          {/* Billing */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">Billing & Subscription</h3>
            <div className="space-y-4">
              <div className="p-4 bg-base-700 rounded-lg flex items-center justify-between">
                <div>
                  <p className="text-text-primary font-medium">Professional Plan</p>
                  <p className="text-text-tertiary text-sm">€299/month • Annual renewal on April 15</p>
                </div>
                <Button variant="secondary">Manage</Button>
              </div>
            </div>
          </Card>

          {/* Integrations */}
          <Card>
            <h3 className="text-lg font-semibold text-text-primary mb-6">Data & Integrations</h3>
            <div className="space-y-4">
              <Button variant="secondary" className="w-full">Upload New Financial Data</Button>
              <Button variant="secondary" className="w-full">Configure Accounting Software Integration</Button>
            </div>
          </Card>

          {/* Danger Zone */}
          <Card className="border-rose-500 border-opacity-20 bg-rose-500 bg-opacity-5">
            <h3 className="text-lg font-semibold text-rose-400 mb-4">Danger Zone</h3>
            <Button variant="danger" className="w-full">Delete Account & All Data</Button>
          </Card>
        </div>
      </main>
    </div>
  )
}
