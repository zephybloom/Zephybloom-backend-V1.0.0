import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import LandingPageNew from './pages/LandingPageNew'
import LoginPageSimple from './pages/LoginPageSimple'
import RegisterPageSimple from './pages/RegisterPageSimple'
import DashboardSimple from './pages/DashboardSimple'
import Dashboard from './pages/Dashboard'
import Chat from './pages/Chat'
import Scenarios from './pages/Scenarios'
import Decisions from './pages/Decisions'
import OnboardingWelcome from './pages/onboarding/Welcome'
import OnboardingCompany from './pages/onboarding/Company'
import OnboardingUpload from './pages/onboarding/Upload'
import OnboardingValidate from './pages/onboarding/Validate'

// Wrapper per LandingPage con Link (per il routing)
function LandingPageWithRouting() {
  return (
    <div className="min-h-screen bg-base-900">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 bg-base-900 bg-opacity-80 backdrop-blur border-b border-base-500 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="text-xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent">
            ZephyBloom
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-text-secondary hover:text-text-primary transition-colors">
              Sign In
            </Link>
            <Link
              to="/register"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-4 py-2 hover:bg-electric-600 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-electric-500 bg-opacity-10 border border-electric-500 border-opacity-30 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="text-sm text-electric-400 font-medium">Now available for early access</span>
          </div>

          {/* Headline */}
          <h1 className="text-5xl font-bold text-text-primary mb-6">
            Your AI CFO, Always On Duty
          </h1>

          {/* Subheading */}
          <p className="text-xl text-text-secondary mb-8 mx-auto">
            ZephyBloom analyzes your financial data, forecasts scenarios, and guides strategic decisions with world-class CFO expertise.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Link
              to="/register"
              className="bg-electric-500 text-base-900 font-semibold rounded-md px-6 py-3 hover:bg-electric-600 transition-colors"
            >
              Start Free Trial
            </Link>
            <a
              href="#features"
              className="border border-base-400 text-electric-500 font-semibold rounded-md px-6 py-3 hover:bg-base-700 transition-colors"
            >
              Learn More
            </a>
          </div>

          {/* Trust indicators */}
          <p className="text-text-tertiary text-sm">
            No credit card required. 14-day free trial. Premium support included.
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            Enterprise Financial Intelligence
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-electric-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Instant KPI Diagnosis</h3>
              <p className="text-text-secondary">
                Upload your financials and get a complete 7-area health scorecard in minutes.
              </p>
            </div>

            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-emerald-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">📈</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Scenario Planning</h3>
              <p className="text-text-secondary">
                Project financial scenarios with probability weighting for strategic decisions.
              </p>
            </div>

            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-violet-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">Decision Analysis</h3>
              <p className="text-text-secondary">
                Evaluate strategic decisions with ROI analysis and impact modeling.
              </p>
            </div>

            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-rose-500 bg-opacity-10 flex items-center justify-center mb-6">
                <span className="text-2xl">🤖</span>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-3">AI CFO Chat</h3>
              <p className="text-text-secondary">
                Ask questions about your business and get expert financial guidance instantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-text-primary mb-16 text-center">
            Simple, Transparent Pricing
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-text-primary mb-2">Starter</h3>
              <p className="text-text-secondary mb-6">For early-stage companies</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">€99<span className="text-lg text-text-secondary">/month</span></div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ KPI Analysis</li>
                <li>✓ Basic Scenarios</li>
                <li>✓ Email Support</li>
              </ul>
              <Link to="/register" className="block w-full text-center bg-base-700 text-text-primary font-semibold rounded-md py-2 hover:bg-base-600 transition-colors">
                Start Free Trial
              </Link>
            </div>

            <div className="bg-electric-500 bg-opacity-10 border border-electric-500 rounded-xl p-8">
              <div className="inline-block bg-electric-500 text-base-900 text-xs font-bold px-3 py-1 rounded-full mb-4">
                POPULAR
              </div>
              <h3 className="text-2xl font-bold text-text-primary mb-2">Professional</h3>
              <p className="text-text-secondary mb-6">For growth companies</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">€299<span className="text-lg text-text-secondary">/month</span></div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ All Starter features</li>
                <li>✓ Advanced Scenarios</li>
                <li>✓ AI CFO Chat</li>
                <li>✓ Priority Support</li>
              </ul>
              <Link to="/register" className="block w-full text-center bg-electric-500 text-base-900 font-semibold rounded-md py-2 hover:bg-electric-600 transition-colors">
                Start Free Trial
              </Link>
            </div>

            <div className="bg-base-800 border border-base-500 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-text-primary mb-2">Enterprise</h3>
              <p className="text-text-secondary mb-6">For large organizations</p>
              <div className="text-4xl font-bold text-electric-400 mb-6">Custom</div>
              <ul className="space-y-3 text-text-secondary mb-8">
                <li>✓ All Professional features</li>
                <li>✓ Custom Integrations</li>
                <li>✓ Dedicated Support</li>
                <li>✓ SLA Guarantee</li>
              </ul>
              <button className="w-full bg-base-700 text-text-primary font-semibold rounded-md py-2 hover:bg-base-600 transition-colors">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 px-6 border-t border-base-800">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-text-primary mb-6">
            Ready to Transform Your Finance?
          </h2>
          <p className="text-xl text-text-secondary mb-8">
            Join hundreds of companies trusting ZephyBloom for strategic financial intelligence.
          </p>
          <Link
            to="/register"
            className="inline-block bg-electric-500 text-base-900 font-semibold rounded-md px-8 py-3 hover:bg-electric-600 transition-colors"
          >
            Get Started Free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-base-800 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-text-primary mb-4">ZephyBloom</h4>
              <p className="text-text-tertiary text-sm">Enterprise financial intelligence powered by AI</p>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Product</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">Features</a></li>
                <li><a href="#" className="hover:text-electric-400">Pricing</a></li>
                <li><a href="#" className="hover:text-electric-400">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Company</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">About</a></li>
                <li><a href="#" className="hover:text-electric-400">Blog</a></li>
                <li><a href="#" className="hover:text-electric-400">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-text-primary mb-4">Legal</h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li><a href="#" className="hover:text-electric-400">Privacy</a></li>
                <li><a href="#" className="hover:text-electric-400">Terms</a></li>
                <li><a href="#" className="hover:text-electric-400">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-base-700 pt-8 text-center text-text-tertiary text-sm">
            <p>&copy; 2026 ZephyBloom. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public */}
        <Route path="/" element={<LandingPageWithRouting />} />
        <Route path="/login" element={<LoginPageSimple />} />
        <Route path="/register" element={<RegisterPageSimple />} />
        <Route path="/onboarding/welcome" element={<OnboardingWelcome />} />
        <Route path="/onboarding/company" element={<OnboardingCompany />} />
        <Route path="/onboarding/upload" element={<OnboardingUpload />} />
        <Route path="/onboarding/validate" element={<OnboardingValidate />} />
        {/* Protected */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/brief" element={<DashboardSimple />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/scenarios" element={<Scenarios />} />
        <Route path="/decisions" element={<Decisions />} />
      </Routes>
    </Router>
  )
}
