import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add authorization token if it exists
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle 401 - clear token and redirect to login
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api

// Auth endpoints
export const auth = {
  register: (name, email, password, company) =>
    api.post('/auth/register', { full_name: name, email, password }),

  login: (email, password) =>
    api.post('/auth/login', { email, password }),

  logout: () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
  },
}

// Dashboard endpoints
export const dashboard = {
  analyze: (data) => api.post('/cfo/analyze', data),
  aiAnalyze: (data, specificQuestion = '', useMock = false) =>
    api.post('/cfo/ai-analyze', data, {
      params: {
        specific_question: specificQuestion || undefined,
        use_mock: useMock,
      },
    }),
  getTrends: (companyId = 'default') =>
    api.get(`/cfo/trends?company_id=${encodeURIComponent(companyId)}`),
}

export const dataRoom = {
  build: (payload) => api.post('/cfo/data-room', payload),
  get: (companyId = 'default') =>
    api.get(`/cfo/data-room?company_id=${encodeURIComponent(companyId)}`),
  getContext: (companyId = 'default') =>
    api.get(`/cfo/data-room/context?company_id=${encodeURIComponent(companyId)}`),
  getHistory: (companyId = 'default', limit = 12) =>
    api.get(`/cfo/data-room/history?company_id=${encodeURIComponent(companyId)}&limit=${limit}`),
  importRows: (payload) => api.post('/cfo/data-room/import', payload),
}

// Scenarios endpoints
export const scenarios = {
  simulate: (data) => api.post('/cfo/simulate', data),
}

// Decisions endpoints
export const decisions = {
  analyze: (data) => api.post('/cfo/analyze-decision', data),
}

// Chat endpoints
export const chat = {
  sendMessage: (message, companyData, chatHistory = []) =>
    api.post('/cfo/chat', {
      message,
      company_data: companyData,
      chat_history: chatHistory,
    }),
}
