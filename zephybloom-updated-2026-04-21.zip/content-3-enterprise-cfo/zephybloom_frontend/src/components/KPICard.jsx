import Card from './Card'
import { TrendingUp, TrendingDown } from 'lucide-react'

export default function KPICard({ title, value, unit, trend, trendDirection = 'up', icon: Icon, color = 'electric' }) {
  const colorMap = {
    electric: 'from-electric-500 to-electric-400',
    emerald: 'from-emerald-500 to-emerald-400',
    violet: 'from-violet-500 to-violet-400',
    rose: 'from-rose-500 to-rose-400',
    cyan: 'from-cyan-500 to-cyan-400',
  }

  return (
    <Card className="relative overflow-hidden group">
      <div className={`absolute -right-8 -top-8 w-24 h-24 rounded-full bg-gradient-to-br ${colorMap[color]} opacity-10 group-hover:opacity-20 transition-opacity`} />
      
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-text-tertiary text-sm font-medium mb-1">{title}</p>
          </div>
          {Icon && (
            <div className={`p-2 rounded-lg bg-${color}-500 bg-opacity-10`}>
              <Icon className={`w-5 h-5 text-${color}-500`} />
            </div>
          )}
        </div>

        {/* Value */}
        <div className="mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-text-primary">{value}</span>
            {unit && <span className="text-text-tertiary text-sm">{unit}</span>}
          </div>
        </div>

        {/* Trend */}
        {trend !== undefined && (
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1 px-2 py-1 rounded text-sm font-medium ${trendDirection === 'up' ? 'bg-emerald-500 bg-opacity-10 text-emerald-400' : 'bg-rose-500 bg-opacity-10 text-rose-400'}`}>
              {trendDirection === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span>{trend}%</span>
            </div>
            <span className="text-text-tertiary text-xs">vs last period</span>
          </div>
        )}
      </div>
    </Card>
  )
}
