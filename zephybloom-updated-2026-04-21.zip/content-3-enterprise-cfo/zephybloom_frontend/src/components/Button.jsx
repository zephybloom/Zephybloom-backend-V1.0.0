import clsx from 'clsx'

export default function Button({ variant = 'primary', size = 'md', className, children, disabled, ...props }) {
  const baseStyles = 'font-semibold rounded-md transition-colors duration-150 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed'
  
  const variantStyles = {
    primary: 'bg-electric-500 text-base-900 hover:bg-electric-600 active:bg-electric-700',
    secondary: 'border border-base-400 text-electric-500 hover:bg-base-700 active:bg-base-600',
    ghost: 'text-text-secondary hover:text-text-primary hover:bg-base-700 active:bg-base-600',
    danger: 'bg-rose-500 text-white hover:bg-rose-600 active:bg-rose-700',
  }

  const sizeStyles = {
    sm: 'px-3 py-2 text-sm',
    md: 'px-4 py-3 text-base',
    lg: 'px-6 py-3 text-lg',
    icon: 'p-2 w-10 h-10',
  }

  return (
    <button
      className={clsx(
        baseStyles,
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  )
}
