import clsx from 'clsx'

export default function Card({ className, children, ...props }) {
  return (
    <div
      className={clsx(
        'bg-base-800 border border-base-500 rounded-lg p-6 shadow-md hover:border-base-400 transition-all duration-200',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}
