import { Link } from 'react-router-dom'
import { Menu, LogOut, Settings, ChevronDown } from 'lucide-react'
import { useState } from 'react'

export default function Navbar({ onMenuClick }) {
  const [showUserMenu, setShowUserMenu] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 bg-base-800 border-b border-base-500 z-50 h-16">
      <div className="h-full px-6 flex items-center justify-between">
        {/* Left */}
        <div className="flex items-center gap-4">
          <button onClick={onMenuClick} className="lg:hidden p-2 hover:bg-base-700 rounded-lg">
            <Menu className="w-5 h-5 text-text-secondary" />
          </button>
          <Link to="/dashboard" className="text-xl font-bold bg-gradient-to-r from-electric-400 to-cyan-400 bg-clip-text text-transparent">
            ZephyBloom
          </Link>
        </div>

        {/* Right */}
        <div className="flex items-center gap-4">
          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-2 hover:bg-base-700 rounded-lg transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-electric-500 to-cyan-500 flex items-center justify-center text-white text-sm font-bold">
                JD
              </div>
              <ChevronDown className="w-4 h-4 text-text-tertiary" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-base-700 border border-base-500 rounded-lg shadow-lg overflow-hidden">
                <div className="px-4 py-3 border-b border-base-500">
                  <p className="font-semibold text-text-primary">John Doe</p>
                  <p className="text-xs text-text-tertiary">john@company.com</p>
                </div>
                <Link to="/settings" className="flex items-center gap-3 px-4 py-2 hover:bg-base-600 text-text-secondary hover:text-text-primary">
                  <Settings className="w-4 h-4" />
                  Settings
                </Link>
                <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-base-600 text-text-secondary hover:text-text-primary border-t border-base-500">
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
