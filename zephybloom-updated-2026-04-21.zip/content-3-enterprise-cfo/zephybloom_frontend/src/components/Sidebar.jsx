import { Link, useLocation } from 'react-router-dom'
import { BarChart3, TrendingUp, Calculator, MessageCircle, Settings, X, Briefcase } from 'lucide-react'
import clsx from 'clsx'

export default function Sidebar({ isOpen, onClose }) {
  const location = useLocation()

  const navItems = [
    { icon: BarChart3, label: 'Dashboard', path: '/dashboard' },
    { icon: TrendingUp, label: 'Scenarios', path: '/scenarios' },
    { icon: Calculator, label: 'Decisions', path: '/decisions' },
    { icon: MessageCircle, label: 'Chat CFO', path: '/chat' },
    { icon: Briefcase, label: 'Workbench', path: '/brief' },
  ]

  const isActive = (path) => location.pathname === path

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 lg:hidden z-40" onClick={onClose} />
      )}

      {/* Sidebar */}
      <aside className={clsx(
        'fixed left-0 top-16 bottom-0 w-64 bg-base-800 border-r border-base-500 p-6',
        'transform transition-transform duration-300 z-40',
        'lg:translate-x-0',
        isOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        {/* Close button (mobile) */}
        <button onClick={onClose} className="lg:hidden absolute top-4 right-4 p-2 hover:bg-base-700 rounded-lg">
          <X className="w-5 h-5" />
        </button>

        {/* Navigation */}
        <nav className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const active = isActive(item.path)
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={clsx(
                  'flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-colors',
                  active
                    ? 'bg-electric-500 text-base-900'
                    : 'text-text-secondary hover:text-text-primary hover:bg-base-700'
                )}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Settings (bottom) */}
        <div className="absolute bottom-6 left-6 right-6">
          <Link
            to="/settings"
            className="flex items-center gap-3 px-4 py-3 rounded-lg font-medium text-text-secondary hover:text-text-primary hover:bg-base-700 transition-colors"
          >
            <Settings className="w-5 h-5" />
            Settings
          </Link>
        </div>
      </aside>
    </>
  )
}
