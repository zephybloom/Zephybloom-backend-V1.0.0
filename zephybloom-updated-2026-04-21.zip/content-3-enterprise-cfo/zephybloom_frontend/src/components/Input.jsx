import clsx from 'clsx'

export default function Input({ label, error, helperText, icon, className, ...props }) {
  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium text-text-secondary mb-2">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-tertiary">
            {icon}
          </span>
        )}
        <input
          className={clsx(
            'w-full bg-base-800 border border-base-500 text-text-primary rounded-md',
            'px-3 py-3 text-base placeholder-text-tertiary',
            'focus:outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500 focus:ring-opacity-20',
            'disabled:bg-base-900 disabled:opacity-50',
            error && 'border-rose-500 focus:ring-rose-500',
            icon && 'pl-10',
            className
          )}
          {...props}
        />
      </div>
      {error && (
        <p className="text-xs text-rose-500 mt-1">{error}</p>
      )}
      {helperText && !error && (
        <p className="text-xs text-text-tertiary mt-1">{helperText}</p>
      )}
    </div>
  )
}
