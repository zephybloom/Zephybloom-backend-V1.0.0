# -*- coding: utf-8 -*-

from typing import Dict, Any, List


def zephytheory_logic_v2(kpi: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    sector = (context.get("sector") or "generic").lower()

    fatturato = float(kpi.get("fatturato", 0))
    mc_rate = float(kpi.get("mc_rate", 0))
    utile = float(kpi.get("utile", 0))

    problem = ""
    lever = ""
    actions: List[str] = []
    impact = ""

    # =========================
    # DIAGNOSI BASE (NUMERI)
    # =========================

    if mc_rate < 0.5:
        problem = "Marginalità troppo bassa"
    elif utile < fatturato * 0.1:
        problem = "Bassa redditività"
    else:
        problem = "Struttura migliorabile"

    # =========================
    # LOGICA PER SETTORE
    # =========================

    if sector == "dentista":
        lever = "Aumento LTV paziente"

        actions = [
            "Creare pacchetti ad alto ticket (500€–3000€)",
            "Inserire pagamenti rateizzati",
            "Upsell trattamenti ad alta marginalità",
            "Sistema di recall automatico pazienti",
        ]

        impact = "+30-50% utile potenziale"

    elif sector == "ristorante":
        lever = "Marginalità per coperto"

        actions = [
            "Aumentare prezzi sui prodotti ad alta domanda",
            "Ridurre food cost del 5-10%",
            "Ottimizzare menu (menu engineering)",
            "Aumentare scontrino medio",
        ]

        impact = "+15-25% utile"

    elif sector == "ecommerce":
        lever = "Aumento LTV/CAC"

        actions = [
            "Bundle prodotti per aumentare AOV",
            "Email marketing per retention",
            "Upsell post-acquisto",
            "Ridurre CAC con campagne più mirate",
        ]

        impact = "+20-40% profitto"

    elif sector == "servizi":
        lever = "Aumento ticket medio"

        actions = [
            "Eliminare offerte low-ticket",
            "Creare pacchetti premium",
            "Aumentare prezzi del 20-50%",
            "Strutturare processo di vendita",
        ]

        impact = "+30% fatturato a parità di clienti"

    else:
        lever = "Ottimizzazione generale"

        actions = [
            "Ridurre costi variabili",
            "Aumentare prezzi dove possibile",
            "Migliorare efficienza operativa",
        ]

        impact = "+10-20% utile"

    # =========================
    # DECISIONE FINALE
    # =========================

    decision = f"Implementare immediatamente: {actions[0]}"

    return {
        "problem": problem,
        "lever": lever,
        "actions": actions,
        "impact": impact,
        "decision": decision,
    }