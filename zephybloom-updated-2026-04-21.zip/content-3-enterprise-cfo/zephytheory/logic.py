# -*- coding: utf-8 -*-
# content/zephytheory/logic.py

from __future__ import annotations

from typing import Any, Dict, List


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _safe_str(x: Any, default: str = "") -> str:
    try:
        s = str(x).strip()
        return s if s else default
    except Exception:
        return default


def _pick_first_number(d: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    for k in keys:
        if k in d:
            try:
                return float(d[k])
            except Exception:
                continue
    return default


def _normalize_sector(context: Dict[str, Any]) -> str:
    sector = _safe_str(context.get("sector", "default"), "default").lower()

    aliases = {
        "ristorante": "restaurant",
        "ristoranti": "restaurant",
        "restaurant": "restaurant",
        "pizzeria": "restaurant",
        "bar": "restaurant",
        "hotel": "hotel",
        "albergo": "hotel",
        "saas": "saas",
        "software": "saas",
        "ecommerce": "ecommerce",
        "e-commerce": "ecommerce",
        "retail": "retail",
    }

    return aliases.get(sector, sector or "default")


def _sector_thresholds(sector: str) -> Dict[str, float]:
    if sector == "restaurant":
        return {
            "mc_rate_good": 0.45,
            "roi_good": 0.15,
            "ccc_max": 20.0,
        }

    if sector == "hotel":
        return {
            "mc_rate_good": 0.50,
            "roi_good": 0.15,
            "ccc_max": 25.0,
        }

    if sector == "saas":
        return {
            "mc_rate_good": 0.70,
            "roi_good": 0.20,
            "ccc_max": 45.0,
        }

    return {
        "mc_rate_good": 0.35,
        "roi_good": 0.12,
        "ccc_max": 60.0,
    }


def _build_scorecard(kpi: Dict[str, Any]) -> Dict[str, float]:
    return {
        "fatturato": _pick_first_number(kpi, ["fatturato", "sales", "ricavi"], 0.0),
        "utile": _pick_first_number(kpi, ["utile", "net_profit", "net_income"], 0.0),
        "ebitda": _pick_first_number(kpi, ["ebitda"], 0.0),
        "mc_rate": _pick_first_number(kpi, ["mc_rate", "gross_margin_rate"], 0.0),
        "roi": _pick_first_number(kpi, ["roi", "roi_pct"], 0.0),
        "ccc": _pick_first_number(kpi, ["ccc", "ccc_days"], 0.0),
        "break_even": _pick_first_number(kpi, ["break_even"], 0.0),
    }


def _classify_problem(
    *,
    scorecard: Dict[str, float],
    thresholds: Dict[str, float],
) -> Dict[str, str]:
    utile = scorecard["utile"]
    mc_rate = scorecard["mc_rate"]
    roi = scorecard["roi"]
    ccc = scorecard["ccc"]

    if utile <= 0:
        return {
            "problem": "Profitto insufficiente o negativo",
            "priority": "profit_recovery",
            "lever": "Aumentare la contribuzione e alleggerire la struttura",
        }

    if mc_rate < thresholds["mc_rate_good"]:
        return {
            "problem": "Marginalità troppo bassa rispetto al livello atteso",
            "priority": "margin_expansion",
            "lever": "Agire su pricing, mix e costi variabili",
        }

    if roi < thresholds["roi_good"]:
        return {
            "problem": "Rendimento del capitale investito troppo basso",
            "priority": "capital_efficiency",
            "lever": "Riallocare investimenti e aumentare efficienza",
        }

    if ccc > thresholds["ccc_max"]:
        return {
            "problem": "Ciclo di cassa troppo lungo",
            "priority": "cash_acceleration",
            "lever": "Accelerare incassi e liberare capitale circolante",
        }

    return {
        "problem": "Base economica sana ma scalata ancora migliorabile",
        "priority": "scaling",
        "lever": "Crescita profittevole e difesa del margine",
    }


def _build_rationale(
    *,
    priority: str,
    scorecard: Dict[str, float],
    thresholds: Dict[str, float],
    sector: str,
) -> List[str]:
    utile = scorecard["utile"]
    mc_rate = scorecard["mc_rate"]
    roi = scorecard["roi"]
    ccc = scorecard["ccc"]

    if priority == "profit_recovery":
        return [
            "L’azienda sta trattenendo troppo poco valore dopo costi variabili e costi fissi.",
            "Prima di spingere crescita, va ripristinata una base economica profittevole.",
            f"Con utile attuale pari a {utile:,.2f}, la priorità è fermare dispersione di margine.".replace(",", "_").replace(".", ",").replace("_", "."),
        ]

    if priority == "margin_expansion":
        return [
            f"Il margine di contribuzione attuale è sotto la soglia target del settore ({thresholds['mc_rate_good'] * 100:.0f}%).",
            "Se la contribuzione per vendita è debole, anche la crescita commerciale rischia di distruggere valore.",
            f"Nel settore {sector}, pricing e costo del venduto sono spesso le leve più rapide da correggere.",
        ]

    if priority == "capital_efficiency":
        return [
            f"Il ROI attuale è sotto la soglia desiderata ({thresholds['roi_good'] * 100:.0f}%).",
            "Questo segnala che il capitale investito non sta producendo abbastanza ritorno.",
            "Serve concentrare risorse sulle attività con payback più rapido.",
        ]

    if priority == "cash_acceleration":
        return [
            f"Il ciclo di cassa attuale è superiore al livello obiettivo ({thresholds['ccc_max']:.0f} giorni).",
            "Anche con un buon utile, una cassa lenta rallenta tutta la capacità di scalare.",
            "La liquidità va trattata come leva strategica, non solo operativa.",
        ]

    return [
        "La base numerica è abbastanza solida da supportare una nuova fase di crescita.",
        "Ora il rischio principale non è il deficit economico, ma una crescita senza disciplina.",
        "Bisogna scalare proteggendo margine, ritorno sul capitale e velocità di cassa.",
    ]


def _build_actions(
    *,
    priority: str,
    sector: str,
) -> List[str]:
    if priority == "profit_recovery":
        return [
            "Tagliare costi fissi non strategici entro 30 giorni.",
            "Eliminare clienti, servizi o linee a bassa marginalità.",
            "Aumentare il prezzo medio sui segmenti meno sensibili.",
        ]

    if priority == "margin_expansion":
        if sector == "restaurant":
            return [
                "Rinegoziare fornitori e ridurre il food cost sulle categorie più pesanti.",
                "Rialzare il prezzo medio sui prodotti con alta domanda e buona percezione di valore.",
                "Ridurre sprechi operativi e standardizzare acquisti e porzioni.",
            ]
        return [
            "Rinegoziare fornitori e abbassare i costi variabili più pesanti.",
            "Spingere prodotti o servizi ad alta contribuzione.",
            "Rivedere pricing e scontistica dove il mercato lo consente.",
        ]

    if priority == "capital_efficiency":
        return [
            "Bloccare investimenti a ritorno basso o non misurabile.",
            "Riallocare budget su attività con impatto diretto su utile e cash flow.",
            "Misurare ogni euro investito con una soglia minima di ritorno atteso.",
        ]

    if priority == "cash_acceleration":
        return [
            "Ridurre DSO con procedure di incasso più forti e più rapide.",
            "Ottimizzare scorte, rotazione e assorbimento di capitale circolante.",
            "Rinegoziare termini di pagamento dove sostenibile senza rompere i fornitori chiave.",
        ]

    return [
        "Aumentare acquisition sui canali già profittevoli.",
        "Spingere upsell e cross-sell sui clienti esistenti.",
        "Testare aumento di prezzo con controllo stretto di conversione e churn.",
    ]


def _build_impact_lines(actions: List[str], priority: str) -> List[str]:
    out: List[str] = []

    for a in actions[:3]:
        if priority == "profit_recovery":
            out.append(f"{a} → impatto atteso: recupero utile e stabilità economica.")
        elif priority == "margin_expansion":
            out.append(f"{a} → impatto atteso: aumento contribuzione per vendita.")
        elif priority == "capital_efficiency":
            out.append(f"{a} → impatto atteso: ROI più alto e minore dispersione di capitale.")
        elif priority == "cash_acceleration":
            out.append(f"{a} → impatto atteso: più liquidità disponibile e minore tensione di cassa.")
        else:
            out.append(f"{a} → impatto atteso: crescita più rapida senza comprimere il margine.")

    return out


def zephytheory_logic(kpi: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Layer strategico ZephyTheory:
    - interpreta i KPI
    - individua il problema principale
    - sceglie la leva prioritaria
    - propone azioni operative ad alto impatto
    """

    kpi = kpi if isinstance(kpi, dict) else {}
    context = context if isinstance(context, dict) else {}

    sector = _normalize_sector(context)
    thresholds = _sector_thresholds(sector)
    scorecard = _build_scorecard(kpi)

    diagnosis = _classify_problem(
        scorecard=scorecard,
        thresholds=thresholds,
    )

    problem = diagnosis["problem"]
    priority = diagnosis["priority"]
    lever = diagnosis["lever"]

    rationale = _build_rationale(
        priority=priority,
        scorecard=scorecard,
        thresholds=thresholds,
        sector=sector,
    )

    actions = _build_actions(
        priority=priority,
        sector=sector,
    )

    impact = _build_impact_lines(actions, priority)

    summary = f"{problem}. Leva prioritaria: {lever}."

    return {
        "problem": problem,
        "priority": priority,
        "lever": lever,
        "actions": actions,
        "impact": impact,
        "rationale": rationale,
        "summary": summary,
        "sector": sector,
        "scorecard": scorecard,
        "thresholds": thresholds,
    }