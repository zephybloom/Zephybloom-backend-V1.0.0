# ZephyBloom CFO

ZephyBloom CFO e un prodotto AI CFO per analisi finanziaria, simulazioni, decisioni strategiche e supporto operativo per aziende.

Il prodotto canonico e:

- Backend: FastAPI in `api/main.py`
- Motore CFO: moduli in `core/`
- Auth, tenancy e database: `api/auth_service.py`, `api/tenant_context.py`, `db/`
- Frontend da consolidare: `zephybloom_frontend/` come UI principale Vite/React
- Frontend legacy: `frontend_react/`, da usare solo come riferimento fino a migrazione completata

## Avvio Rapido

### Backend

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m uvicorn api.main:app --host 127.0.0.1 --port 8001 --reload
```

Endpoint utili:

- API: `http://127.0.0.1:8001`
- Swagger: `http://127.0.0.1:8001/docs`
- Health: `http://127.0.0.1:8001/health`
- Routes debug: `http://127.0.0.1:8001/__routes__`

### Frontend Principale

```bash
cd zephybloom_frontend
npm install
VITE_API_URL=http://127.0.0.1:8001 npm run dev
```

## Configurazione

Usare variabili con prefisso `ZB_`.

Minimo locale:

```bash
ZB_ENV=development
ZB_DEMO_MODE=true
ZB_DATABASE_URL=sqlite:///./zephytheory.db
ZB_LLM_PROVIDER=mock
```

Produzione:

```bash
ZB_ENV=production
ZB_DEMO_MODE=false
ZB_JWT_REQUIRED=true
ZB_JWT_SECRET=<secret-forte>
ZB_DATABASE_URL=postgresql+psycopg2://...
ZB_OPENAI_API_KEY=<openai-key>
ZB_LLM_PROVIDER=openai
ZB_CORS_ORIGINS=https://app.example.com
```

## Sicurezza

In sviluppo/demo il backend resta permissivo per facilitare test e pilot.

In staging/production, oppure quando `ZB_JWT_REQUIRED=true`, le rotte protette richiedono identita verificata e tenant attivo. Se `ZB_APP_API_KEY` e impostata, il middleware globale accetta solo richieste con `X-API-Key` valido, tranne health/docs/metrics.

## Test

Esecuzione mirata:

```bash
python3 -m pytest test/test_unit_validators.py -q
```

Esecuzione suite:

```bash
python3 -m pytest test -q
```

## Struttura

- `api/`: FastAPI, router, middleware, auth, tenancy, schemi
- `core/`: logica CFO, KPI, decisioni, simulazioni, forecasting, pricing, learning
- `db/`: modelli SQLAlchemy e session factory
- `infra/`: AI provider, cache, circuit breaker, metriche
- `nlp/`: chatbot, intent routing, reasoning pipeline
- `rag/`: retrieval e indexing
- `knowledge/`: regole, playbook e knowledge base
- `zephybloom_frontend/`: UI React principale
- `frontend_react/`: UI legacy
- `test/`: suite pytest

## Stato Del Prodotto

Priorita corrente:

1. Consolidare `zephybloom_frontend` come unico frontend.
2. Allineare tutti gli endpoint frontend al backend canonico.
3. Tenere `api/main.py` come unico entrypoint server.
4. Mantenere dev/demo fluido e produzione protetta.
5. Stabilizzare i test prima di scalare nuova logica CFO.

## Deploy

Railway usa:

```bash
python3 -m uvicorn api.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

Il `Procfile` e mantenuto per compatibilita, ma il comando raccomandato e quello Uvicorn sopra.
