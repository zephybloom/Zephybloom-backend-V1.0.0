# Playbook Working Capital (MVP)

## Obiettivi
- Ridurre CCC = DSO + DIO − DPO
- Liberare cassa senza impatto su servizio

## Azioni
- **DSO**: reminder automatici, sconto 1–2% per pagamento a 10 gg, credit check light.
- **DIO**: Kanban top SKU, min-max policy, forecast rolling mensile.
- **DPO**: rinegoziazioni su fornitori core, pagamento elettronico con termini estesi.

## KPI
- CCC (giorni) · Scaduto >30gg · Rotazione magazzino

## Esperimenti
- Pilot di 30 gg su 10 clienti con sconto per anticipo.
