# Playbook Pricing (MVP)

## Obiettivi
- Massimizzare l’utile mantenendo volumi sostenibili.
- Aumentare MC% senza erodere conversione.

## Azioni
1. **Segmenta clienti** (size/value) e mappa willingness-to-pay.
2. **A/B test listino** con step ±2% su top SKU/servizi.
3. **Price ladder**: esplora ±10% (step 2%) e seleziona fascia migliore per utile.
4. **Bundle & versioning**: pacchetti “good/better/best”.
5. **Sconti condizionati**: sconto a fronte di prepagato o upsell.

## Metriche chiave
- MC% (frazione) · Net margin% · Conversione · Churn (se SaaS)

## Checklist
- [ ] Elasticità stimata per categoria
- [ ] Soglie ROI/MC per settore allineate
- [ ] Monitoraggio settimanale post-rollout
