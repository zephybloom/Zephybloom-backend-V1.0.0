# content/knowledge/ingest_schemas.py
from __future__ import annotations
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator

class IngestDoc(BaseModel):
    id: Optional[str] = None
    text: str = Field(..., min_length=1)
    title: Optional[str] = None
    url: Optional[str] = None
    sector: Optional[str] = Field(None, description="es. retail, restaurant, default")
    language: Optional[str] = Field(None, description="it, en, ...")
    level: Optional[str] = Field(None, description="how-to, strategy, reference")
    meta: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("sector", mode="before")
    def _norm_sector(cls, v):
        return (str(v).strip().lower() or None) if v else None

    @field_validator("language", mode="before")
    def _norm_lang(cls, v):
        return (str(v).strip().lower() or None) if v else None

    @field_validator("level", mode="before")
    def _norm_level(cls, v):
        return (str(v).strip().lower() or None) if v else None

class IngestRequest(BaseModel):
    docs: List[IngestDoc] = Field(default_factory=list)
    knowledge_dir: Optional[str] = Field(None, description="Se non mandi docs espliciti, usa FS")
    mode: str = Field("build", description="build|add")
    chunk_size: int = 350
    overlap: int = 50
