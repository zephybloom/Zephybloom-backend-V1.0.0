# content/knowledge/index.py
from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
import math
import re

from knowledge.ingest_schemas import IngestRequest, IngestDoc
from rag.indexer import (
    Doc as RagDoc,
    build_from_knowledge,
    add_from_knowledge,
    ensure_vector_backend,
    InMemoryIndex,
)
from rag.retriever import retrieve

_WORD = re.compile(r"[A-Za-zÀ-ÿ0-9']+")

def _bm25_scores(query: str, texts: List[str], k1: float = 1.2, b: float = 0.75) -> List[float]:
    toks = [t.lower() for t in _WORD.findall(query or "")]
    if not toks or not texts:
        return [0.0] * len(texts)
    docs = [[w.lower() for w in _WORD.findall(x)] for x in texts]
    N = float(len(docs))
    df = {}
    for d in docs:
        for w in set(d):
            df[w] = df.get(w, 0) + 1
    idf = {w: math.log((N - df.get(w, 0) + 0.5) / (df.get(w, 0) + 0.5) + 1.0) for w in set(toks)}
    avdl = sum(len(d) for d in docs) / N
    scores = []
    for d in docs:
        dl = len(d) or 1
        tf = {}
        for w in d:
            tf[w] = tf.get(w, 0) + 1
        s = 0.0
        for w in toks:
            if w not in idf:
                continue
            num = tf.get(w, 0) * (k1 + 1)
            den = tf.get(w, 0) + k1 * (1.0 - b + b * (dl / avdl))
            s += idf[w] * (num / den if den else 0.0)
        scores.append(float(s))
    return scores

def _minmax(vs: List[float]) -> List[float]:
    if not vs:
        return []
    lo, hi = min(vs), max(vs)
    if hi <= lo + 1e-12:
        return [0.0 for _ in vs]
    return [(x - lo) / (hi - lo) for x in vs]

def ingest(req: IngestRequest) -> Dict[str, Any]:
    """
    - Se req.docs è presente, indicizza i testi passati (in RAM o Qdrant a seconda del backend).
    - Altrimenti usa il filesystem (content/knowledge).
    Ritorna stats dall'indexer.
    """
    ensure_vector_backend(force=True)
    if req.docs:
        # Converte IngestDoc -> RagDoc
        docs = []
        for d in req.docs:
            meta = dict(d.meta or {})
            if d.sector: meta["sector"] = d.sector
            if d.language: meta["language"] = d.language
            if d.level: meta["level"] = d.level
            docs.append(RagDoc(id=d.id or d.title or f"doc:{len(docs)}", text=d.text, title=d.title, url=d.url, meta=meta))
        idx = ensure_vector_backend(force=True)
        if req.mode == "add":
            return idx.add_docs(docs, chunk_size=req.chunk_size, overlap=req.overlap)
        else:
            return idx.build(docs, chunk_size=req.chunk_size, overlap=req.overlap)
    # FS ingest
    if req.mode == "add":
        return add_from_knowledge(req.knowledge_dir or "content/knowledge", chunk_size=req.chunk_size, overlap=req.overlap)
    return build_from_knowledge(req.knowledge_dir or "content/knowledge", chunk_size=req.chunk_size, overlap=req.overlap)

def search(
    query: str,
    *,
    top_k: int = 6,
    sector: Optional[str] = None,
    level: Optional[str] = None,
    language: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    1) Recupero vettoriale (cosine)
    2) Filtri meta (sector/level/language) se presenti
    3) Rerank ibrido (cosine 60% + BM25 40%)
    """
    hits = retrieve(query, top_k=max(20, top_k))  # prendi più candidati per rerank
    # filtra meta
    def _ok(h: Dict[str, Any]) -> bool:
        m = h.get("meta", {}) or {}
        if sector and (m.get("sector") or "").lower() != sector.lower(): return False
        if level and (m.get("level") or "").lower() != level.lower(): return False
        if language and (m.get("language") or "").lower() != language.lower(): return False
        return True
    filt = [h for h in hits if _ok(h)] if any([sector, level, language]) else hits
    texts = [h["text"] for h in filt]
    bm25 = _bm25_scores(query, texts)
    bm25_n = _minmax(bm25)
    cos_n  = _minmax([h["score"] for h in filt])
    reranked = []
    for h, b, c in zip(filt, bm25_n, cos_n):
        score = 0.40 * b + 0.60 * c
        hh = dict(h)
        hh["score"] = float(score)
        reranked.append(hh)
    reranked.sort(key=lambda x: x["score"], reverse=True)
    return reranked[:top_k]
