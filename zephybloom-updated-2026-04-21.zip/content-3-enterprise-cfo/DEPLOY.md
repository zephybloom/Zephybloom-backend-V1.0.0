# 🚀 Guida al Deploy su Railway

ZephyBloom CFO Platform con Deploy Automatico

## Prerequisiti

- Account GitHub (✅ Hai il repo)
- Account Railway (creane uno: https://railway.app)
- Secrets di GitHub configurati

## 1️⃣ Crea il Repo su GitHub

```bash
# Opzione A: Da command line (se hai GitHub CLI)
gh repo create zephybloom-cfo --private --source=. --remote=origin --push

# Opzione B: Manuale
# 1. Vai a github.com/new
# 2. Nome: "zephybloom-cfo"
# 3. Scegli "Private"
# 4. Crea il repo
# 5. Copia il comando git e eseguilo:
# git remote add origin https://github.com/YOU/zephybloom-cfo.git
# git branch -M main
# git push -u origin main
```

## 2️⃣ Setup Secret su GitHub

1. Vai al tuo repo GitHub → **Settings** → **Secrets and variables** → **Actions**
2. Crea un nuovo secret:
   - Nome: `RAILWAY_TOKEN`
   - Valore: Il tuo Railway API token (vedi step 3)

## 3️⃣ Setup Railway

1. Vai a https://railway.app
2. Sign up / Login con il tuo account GitHub
3. Crea un nuovo progetto:
   - Click "Create New" → "New Project"
   - Scegli "Deploy from GitHub repo"
   - Seleziona il repo `zephybloom-cfo`
   - Railway fa il deploy automatico!

## 4️⃣ Genera Railway Token

1. Account Settings (icona profilo in alto a destra)
2. API Tokens
3. Click "Create New Token"
4. Copia il token
5. Aggiungi come secret su GitHub (vedi step 2)

## 5️⃣ Configura le Variabili di Ambiente

Su Railway, nel pannello del progetto:
- `ENVIRONMENT`: `production`
- `JWT_SECRET`: Genera una key sicura (128+ caratteri)
- `API_KEY`: Genera una chiave API
- Database automatico (Railway crea PostgreSQL)

## 6️⃣ Deploy!

Tutto è automatico ora:

1. **Fai push su GitHub:**
   ```bash
   git add .
   git commit -m "Setup deploy su Railway"
   git push origin main
   ```

2. **GitHub Actions** avvia automaticamente:
   - Testa il codice
   - Compila il frontend
   - Deploya su Railway

3. **Vedi il status:**
   - GitHub: Actions tab
   - Railway: Dashboard del progetto

## 📊 Stack di Deploy

```
┌─────────────────┐
│   GitHub        │ (Repo del codice)
│   (Main Branch) │
└────────┬────────┘
         │ Git Push
         ▼
┌─────────────────┐
│ GitHub Actions  │ (CI/CD Pipeline)
│ (Test + Build)  │
└────────┬────────┘
         │ Deploy
         ▼
┌─────────────────┐
│    Railway      │ (Hosting)
│ (App + DB)      │
└─────────────────┘
```

## 🔍 Troubleshooting

### "Build fallito"
- Verifica `requirements.txt` completo
- Verifica che Node.js build funziona localmente

### "PostgreSQL non trovato"
- Railway crea automaticamente il DB
- Verifica `DATABASE_URL` nelle variabili di ambiente

### "Frontend non carica"
- Verifica che React buildsi correttamente
- Controlla le environment variables API

## 📝 Note Importanti

- **Database locale (SQLite)**: Non persiste su Railway!
  - Railway usa PostgreSQL automaticamente
  - Aggiorna `db.py` per usare `DATABASE_URL` da env
  
- **File uploads**: Non persistono su Railway meno che non usi S3/storage esterno

- **Logs**: Usa `railway logs` o il dashboard Railway per debuggare

## 🎯 Prossimi Step

1. ✅ Setup GitHub + Railway
2. ⏳ Deploy il progetto
3. ⏳ Configura il dominio personalizzato (optional)
4. ⏳ Setup monitoring e alerting

