#!/usr/bin/env python3
"""
Create 10 beta test users for ZephyBloom CFO platform.
Generates credentials file for distribution to beta testers.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.session import get_session_sync
from db.models import User, Tenant
import bcrypt
import json
from datetime import datetime

def create_beta_users():
    """Create 10 beta test users with different company profiles"""
    
    # Beta tester data
    beta_users = [
        {
            "email": "sara.russo@techspa.it",
            "company": "TechSPA",
            "sector": "SaaS",
            "full_name": "Sara Russo",
        },
        {
            "email": "marco.colombo@acmeindustriale.it",
            "company": "Acme Industriale",
            "sector": "Manufacturing",
            "full_name": "Marco Colombo",
        },
        {
            "email": "lisa.martini@retailgroup.it",
            "company": "RetailGroup",
            "sector": "Retail",
            "full_name": "Lisa Martini",
        },
        {
            "email": "andrea.rossi@financecorp.it",
            "company": "FinanceCorp",
            "sector": "Finance",
            "full_name": "Andrea Rossi",
        },
        {
            "email": "giulia.bianchi@healthtech.it",
            "company": "HealthTech",
            "sector": "Healthcare",
            "full_name": "Giulia Bianchi",
        },
        {
            "email": "davide.verdi@ecommerce.it",
            "company": "EcommercePro",
            "sector": "Retail",
            "full_name": "Davide Verdi",
        },
        {
            "email": "francesca.neri@consulting.it",
            "company": "Consulting Plus",
            "sector": "Services",
            "full_name": "Francesca Neri",
        },
        {
            "email": "lorenzo.ferrari@logistics.it",
            "company": "LogisticsHub",
            "sector": "Transportation",
            "full_name": "Lorenzo Ferrari",
        },
        {
            "email": "alessandra.romano@media.it",
            "company": "MediaStream",
            "sector": "Media",
            "full_name": "Alessandra Romano",
        },
        {
            "email": "roberto.gallo@energy.it",
            "company": "EnergyPlus",
            "sector": "Energy",
            "full_name": "Roberto Gallo",
        },
    ]
    
    session = get_session_sync()
    credentials = []
    
    temporary_password = "BetaTest.2026!Secure"
    
    try:
        for user_data in beta_users:
            email = user_data["email"]
            company = user_data["company"]
            sector = user_data["sector"]
            full_name = user_data["full_name"]
            
            # Check if user already exists
            existing = session.query(User).filter(User.email == email).first()
            if existing:
                print(f"⏭️  User {email} already exists, skipping")
                credentials.append({
                    "email": email,
                    "password": temporary_password,
                    "company": company,
                    "created": False
                })
                continue
            
            # Create user
            password_hash = bcrypt.hashpw(temporary_password.encode(), bcrypt.gensalt()).decode()
            user = User(
                email=email,
                password_hash=password_hash,
                full_name=full_name,
                role="user",
                is_active=True,
            )
            session.add(user)
            session.commit()
            session.refresh(user)
            
            # Create tenant (company workspace)
            tenant_id = company.lower().replace(" ", "-")
            tenant = Tenant(
                id=tenant_id,
                name=company,
                description=f"{company} - {sector} sector",
                owner_id=user.id,
                is_active=True,
            )
            session.add(tenant)
            session.commit()
            
            credentials.append({
                "email": email,
                "password": temporary_password,
                "company": company,
                "sector": sector,
                "full_name": full_name,
                "user_id": user.id,
                "tenant_id": tenant_id,
                "created": True
            })
            
            print(f"✅ Created: {email} ({company})")
        
        session.close()
        
        # Generate credentials file
        credentials_text = "ZephyBloom CFO Platform - Beta Tester Credentials\n"
        credentials_text += "=" * 70 + "\n"
        credentials_text += f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        credentials_text += f"Platform: http://localhost:3000\n"
        credentials_text += "=" * 70 + "\n\n"
        credentials_text += "IMPORTANT: Change your password on first login!\n\n"
        
        for i, cred in enumerate(credentials, 1):
            if cred.get("created"):
                credentials_text += f"{i}. {cred['full_name']} ({cred['company']} - {cred['sector']})\n"
                credentials_text += f"   Email:    {cred['email']}\n"
                credentials_text += f"   Password: {cred['password']}\n"
                credentials_text += f"   Tenant:   {cred['tenant_id']}\n\n"
        
        # Save credentials file
        with open("BETA_CREDENTIALS.txt", "w") as f:
            f.write(credentials_text)
        
        print("\n" + "=" * 70)
        print(f"✅ Created {sum(1 for c in credentials if c.get('created'))} beta accounts")
        print(f"✅ Credentials saved to: BETA_CREDENTIALS.txt")
        print("=" * 70)
        
        return credentials
        
    except Exception as e:
        print(f"❌ Error: {e}")
        session.close()
        raise

if __name__ == "__main__":
    create_beta_users()
