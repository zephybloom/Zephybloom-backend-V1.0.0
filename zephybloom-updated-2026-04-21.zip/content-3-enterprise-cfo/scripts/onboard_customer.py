#!/usr/bin/env python3
"""
Customer onboarding automation.

Automatically create tenant, user, and API keys for new customers.

Usage:
    python3 scripts/onboard_customer.py --company "ACME Corp" --email admin@acme.com
"""

import sys
import argparse
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Add project to path
project_root = "/Users/thestar23/Downloads/content-3-enterprise-cfo"
sys.path.insert(0, project_root)

from db.models import Base, User, Tenant, APIKey, TenantSettings
from api.auth_service import AuthService
from api.config import settings


def onboard_customer(company_name: str, admin_email: str, admin_password: str = None):
    """
    Onboard a new customer.
    
    Creates:
    1. User account (admin)
    2. Tenant organization
    3. API key
    4. Tenant settings
    """
    
    # Generate password if not provided
    if not admin_password:
        import secrets
        admin_password = secrets.token_urlsafe(16)
    
    # Setup database
    engine = create_engine(settings.DATABASE_URL)
    SessionLocal = sessionmaker(bind=engine)
    session = SessionLocal()
    
    try:
        print(f"🚀 Onboarding customer: {company_name}")
        print("━" * 60)
        
        # Step 1: Create user
        print(f"👤 Creating admin user...")
        user = User(
            email=admin_email,
            password_hash=AuthService.hash_password(admin_password),
            full_name=f"{company_name} Admin",
            role="admin",
            is_active=True,
        )
        session.add(user)
        session.flush()  # Get user ID
        print(f"   ✅ User created: {user.email}")
        
        # Step 2: Create tenant
        print(f"🏢 Creating tenant...")
        tenant_id = company_name.lower().replace(" ", "-")
        tenant = Tenant(
            id=tenant_id,
            name=company_name,
            description=f"Tenant for {company_name}",
            owner_id=user.id,
            is_active=True,
        )
        session.add(tenant)
        session.flush()
        print(f"   ✅ Tenant created: {tenant_id}")
        
        # Step 3: Create API key
        print(f"🔑 Creating API key...")
        api_key_value = secrets.token_urlsafe(32)
        api_key = APIKey(
            key=AuthService.hash_password(api_key_value),
            name=f"{company_name} Default Key",
            user_id=user.id,
            tenant_id=tenant_id,
            rate_limit_per_minute=100,
            is_active=True,
        )
        session.add(api_key)
        session.flush()
        print(f"   ✅ API key created: {api_key_value[:20]}...")
        
        # Step 4: Create tenant settings
        print(f"⚙️  Creating tenant settings...")
        settings_obj = TenantSettings(
            tenant_id=tenant_id,
            rate_limit_per_minute=1000,
            max_concurrent_requests=50,
            enable_kpi_engine=True,
            enable_simulation=True,
            enable_valuation=True,
        )
        session.add(settings_obj)
        
        # Commit all changes
        session.commit()
        
        print("\n" + "✅ " * 15)
        print(f"\n🎉 Customer onboarded successfully!\n")
        print("Credentials for admin:")
        print(f"  Email:    {admin_email}")
        print(f"  Password: {admin_password}")
        print(f"  Tenant:   {tenant_id}")
        print(f"\nAPI Integration:")
        print(f"  Header:   X-API-Key: {api_key_value}")
        print(f"  Tenant:   X-Tenant-Id: {tenant_id}")
        print("\n" + "=" * 60)
        
        return {
            "user_id": user.id,
            "tenant_id": tenant_id,
            "email": admin_email,
            "password": admin_password,
            "api_key": api_key_value,
        }
        
    except Exception as e:
        session.rollback()
        print(f"❌ Error: {e}")
        raise
    finally:
        session.close()


def main():
    parser = argparse.ArgumentParser(description="Onboard a new customer")
    parser.add_argument("--company", required=True, help="Company name")
    parser.add_argument("--email", required=True, help="Admin email")
    parser.add_argument("--password", help="Admin password (generated if not provided)")
    
    args = parser.parse_args()
    
    result = onboard_customer(
        company_name=args.company,
        admin_email=args.email,
        admin_password=args.password,
    )
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
