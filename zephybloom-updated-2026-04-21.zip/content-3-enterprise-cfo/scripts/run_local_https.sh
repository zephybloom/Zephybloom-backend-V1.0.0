#!/usr/bin/env bash
# Run ZephyBloom API locally with HTTPS (self-signed certs)

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🚀 ZephyBloom CFO API - Local HTTPS Server${NC}"
echo "=================================================="

# Check certificates exist
if [ ! -f "certs/cert.pem" ] || [ ! -f "certs/key.pem" ]; then
    echo -e "${YELLOW}⚠️  SSL certificates not found, generating...${NC}"
    mkdir -p certs
    openssl req -x509 -newkey rsa:2048 -keyout certs/key.pem -out certs/cert.pem \
        -days 365 -nodes -subj "/C=IT/ST=Italy/L=Milan/O=ZephyBloom/CN=localhost"
    echo -e "${GREEN}✅ Certificates created${NC}"
fi

# Check OpenAI API key
if [ -z "$ZB_OPENAI_API_KEY" ]; then
    echo -e "${YELLOW}⚠️  ZB_OPENAI_API_KEY not set. Set with:${NC}"
    echo "   export ZB_OPENAI_API_KEY='sk-...'"
    echo ""
    echo "Continuing with test key..."
    export ZB_OPENAI_API_KEY="sk-proj-test"
fi

# Install uvicorn if needed
if ! python3 -c "import uvicorn" 2>/dev/null; then
    echo "Installing uvicorn..."
    pip install uvicorn[standard] -q
fi

# Kill any existing server on port 8443
pkill -f "uvicorn.*8443" || true
sleep 1

# Start server with HTTPS
echo ""
echo -e "${GREEN}Starting API with HTTPS...${NC}"
echo "📍 Access at: https://localhost:8443"
echo "📚 Swagger:  https://localhost:8443/docs"
echo "🏥 Health:   https://localhost:8443/health"
echo ""
echo "Press CTRL+C to stop"
echo "=================================================="
echo ""

python3 -m uvicorn api.main:app \
    --host 0.0.0.0 \
    --port 8443 \
    --ssl-certfile=certs/cert.pem \
    --ssl-keyfile=certs/key.pem \
    --reload
