# content/launcher.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import socket
import time
import threading
import pathlib
from typing import Callable, Optional, Dict, Any

# ====== PATH PROGETTO ======
HERE = pathlib.Path(__file__).resolve()
ROOT = HERE.parent               # /content/content
PROJECT = ROOT.parent            # /content
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))

# ====== LOGGING PRIMA DI TUTTO ======
# Configurazione del root logger *subito* per evitare errori di extra kwargs
try:
    from utils.logging_utils import configure_root_logging, get_logger, with_extra
    configure_root_logging()
    _log = get_logger("launcher")
except Exception:
    # Fallback minimale se il modulo logging_utils non fosse disponibile
    import logging as _logging
    _logging.basicConfig(level=_logging.INFO, stream=sys.stdout, format="%(levelname)s %(name)s: %(message)s")
    _log = _logging.getLogger("launcher")
    def with_extra(logger, **extra):  # type: ignore
        class _Proxy:
            def __init__(self, logger, base): self._logger, self._base = logger, base
            def _emit(self, lvl, msg, **kv): self._logger.log(lvl, f"{msg} | extra={dict(self._base, **kv)}")
            def info(self, msg, **kv): self._emit(20, msg, **kv)
            def warning(self, msg, **kv): self._emit(30, msg, **kv)
            def error(self, msg, **kv): self._emit(40, msg, **kv)
            def critical(self, msg, **kv): self._emit(50, msg, **kv)
            def debug(self, msg, **kv): self._emit(10, msg, **kv)
        return _Proxy(logger, extra)

__all__ = ["launch"]

# ====== ENV DI BASE ======
os.environ.setdefault("ZB_ENV", "development")
openai_key = os.getenv("ZB_OPENAI_API_KEY", "").strip()
if (not openai_key) or ("..." in openai_key):
    os.environ["ZB_LLM_PROVIDER"] = "mock"
else:
    os.environ.setdefault("ZB_LLM_PROVIDER", "openai")
    os.environ["ZB_OPENAI_API_KEY"] = openai_key

# disattiva auth app per test
for k in ("APP_API_KEY", "ZB_APP_API_KEY"):
    os.environ.pop(k, None)

# ====== HELPERS ======
def _free_port(start: int) -> int:
    p = start
    while True:
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                p += 1
                if p > start + 200:
                    raise RuntimeError("Nessuna porta libera trovata")

def _wait_health(base: str, timeout_s: int = 30) -> None:
    import requests
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        try:
            r = requests.get(f"{base}/health", timeout=1.5)
            if r.ok:
                return
        except Exception:
            pass
        time.sleep(0.25)
    raise RuntimeError(f"Backend non raggiungibile su {base}/health")

def _resolve_ui_factory() -> Callable[..., Any]:
    """
    Ritorna una funzione create_demo(backend_base_url: str) -> gr.Blocks.
    Ordine: ZB_UI_MODULE override -> gradio_app -> gradio_pretty -> gradio_minimal -> auto_minimal.
    """
    modspec = os.getenv("ZB_UI_MODULE", "").strip()
    if modspec:
        mod, _, attr = modspec.partition(":")
        if not attr:
            attr = "create_demo"
        m = __import__(mod, fromlist=[attr])
        return getattr(m, attr)

    try:
        from frontend.gradio_app import create_demo as _create
        return _create
    except Exception:
        pass
    try:
        from frontend.gradio_pretty import create_demo as _create
        return _create
    except Exception:
        pass
    try:
        from frontend.gradio_minimal import create_demo as _create
        return _create
    except Exception:
        pass

    # Auto-minimal fallback
    ui_dir = ROOT / "frontend"
    ui_dir.mkdir(parents=True, exist_ok=True)
    auto_path = ui_dir / "_auto_minimal.py"
    if not auto_path.exists():
        auto_path.write_text(r'''
from __future__ import annotations
import os, requests
from typing import Optional, Tuple, Any, List
import gradio as gr

def _normalize(url:str)->str:
    u=(url or "").strip() or "http://127.0.0.1:8001"
    if u.startswith(("http://0.0.0.0","https://0.0.0.0")): u=u.replace("0.0.0.0","127.0.0.1",1)
    if not (u.startswith("http://") or u.startswith("https://")): u="http://"+u
    return u.rstrip("/")

def _call(base:str, method:str, path:str, payload:Optional[dict]=None, timeout:float=15.0)->Tuple[bool,Any]:
    url=f"{_normalize(base)}{path}"
    try:
        r = requests.get(url, timeout=timeout) if method=="GET" else requests.post(url, json=payload or {}, timeout=timeout)
        ok = 200 <= r.status_code < 300
        data = r.json() if "application/json" in (r.headers.get("content-type","")) else r.text
        return (True,data) if ok else (False,{"status_code":r.status_code,"target":url,"body":data})
    except Exception as e:
        return False, {"error": str(e), "target": url}

def create_demo(backend_base_url: Optional[str]=None)->gr.Blocks:
    base0 = _normalize(backend_base_url or os.getenv("BACKEND_BASE_URL","http://127.0.0.1:8001"))
    with gr.Blocks(title="ZephyBloom – UI (auto)") as demo:
        gr.Markdown(f"### ZephyBloom — UI di emergenza  \n**Backend:** `{base0}`")
        chat = gr.Chatbot(label="CFO Virtuale", type="messages", height=380)
        msg  = gr.Textbox(label="Messaggio", placeholder="Es: 'Qual è il mio utile?'")
        send = gr.Button("Invia")
        raw  = gr.JSON(label="Raw")
        def on_send(m:str, hist:List[dict]):
            if not (m or "").strip(): return hist, {"error":"msg vuoto"}
            ok,data = _call(base0,"POST","/chat",{
                "text": m, "session_id":"demo", "remember": True, "use_tools": True,
                "context": {"fatturato":1200000,"costi_variabili":840000,"costi_fissi":180000,"investimenti":200000}
            })
            bot = (data.get("narrative") if ok and isinstance(data,dict) else str(data)) or "(nessuna risposta)"
            return (hist or []) + [{"role":"user","content":m},{"role":"assistant","content":bot}], data
        send.click(on_send, inputs=[msg, chat], outputs=[chat, raw])
        msg.submit(on_send, inputs=[msg, chat], outputs=[chat, raw])
    return demo
''', encoding="utf-8")

    from frontend._auto_minimal import create_demo as _create
    return _create

# ====== API + UI LAUNCHER ======
def launch(
    share: bool = False,
    api_port: Optional[int] = None,
    ui_port: Optional[int] = None,
    ui_module: Optional[str] = None,
) -> Dict[str, Optional[str]]:
    """
    Avvia FastAPI + (opzionale) UI Gradio e ritorna i link.
    """
    # Porte
    api_port = api_port or _free_port(int(os.getenv("API_PORT", "8001")))
    ui_port  = ui_port  or _free_port(int(os.getenv("UI_PORT", "7860")))
    backend_base = f"http://127.0.0.1:{api_port}"
    os.environ["BACKEND_BASE_URL"] = backend_base

    # Backend thread
    def _run_api():
        try:
            import uvicorn
            # Importa *dopo* il logging per ereditare la config corretta
            from api.main import app as fastapi_app  # type: ignore
            with_extra(_log, component="launcher", part="api").info("Starting uvicorn", host="127.0.0.1", port=api_port)
            uvicorn.run(fastapi_app, host="127.0.0.1", port=api_port, log_level="info")
        except Exception as e:
            with_extra(_log, component="launcher", part="api").critical("API crashed", error=str(e))

    t_api = threading.Thread(target=_run_api, daemon=True)
    t_api.start()

    # Attesa health
    try:
        _wait_health(backend_base)
        with_extra(_log, component="launcher").info("Backend online", url=backend_base)
        print(f"✅ Backend online su: {backend_base}", flush=True)
    except Exception as e:
        with_extra(_log, component="launcher").critical("Backend non raggiungibile", url=backend_base, error=str(e))
        raise

    # Self-test (best-effort)
    try:
        import requests
        r1 = requests.get(f"{backend_base}/_selftest", timeout=5)
        with_extra(_log, component="launcher", step="_selftest").info("Selftest", status=r1.status_code)
        print(f"_selftest: {r1.status_code}", flush=True)
        r2 = requests.post(
            f"{backend_base}/kpi/compute",
            json={"fatturato": 1_200_000, "costi_variabili": 840_000, "costi_fissi": 180_000, "investimenti": 200_000},
            timeout=5,
        )
        with_extra(_log, component="launcher", step="kpi").info("KPI smoke", status=r2.status_code)
        print(f"kpi: {r2.status_code}", flush=True)
    except Exception as e:
        with_extra(_log, component="launcher").warning("Self-test non riuscito", error=str(e))
        print(f"⚠️  Self-test non riuscito: {e}", flush=True)

    # UI (opzionale)
    ui_url: Optional[str] = None
    share_url: Optional[str] = None

    try:
        if ui_module:
            os.environ["ZB_UI_MODULE"] = ui_module

        UIFactory = _resolve_ui_factory()

        try:
            from gradio import __version__ as _gr_v  # noqa: F401
        except Exception as e:
            with_extra(_log, component="launcher", part="ui").warning("Gradio non disponibile", error=str(e))
            return {"backend_url": backend_base, "ui_url": None, "share_url": None}

        demo = UIFactory(backend_base_url=backend_base)
        result = demo.queue(api_open=False).launch(server_name="0.0.0.0", server_port=ui_port, share=share)
        share_url = getattr(result, "share_url", None) if share else None
        ui_url = f"http://127.0.0.1:{ui_port}"
        print(f"🌐 UI Gradio su: {ui_url}  (share={'on' if share else 'off'})", flush=True)
        if share and share_url:
            print(f"🔗 Share URL: {share_url}", flush=True)
        with_extra(_log, component="launcher", part="ui").info("UI ready", url=ui_url, share=bool(share), share_url=share_url or "")
    except Exception as e:
        with_extra(_log, component="launcher", part="ui").warning("UI non avviata", error=str(e))
        print(f"⚠️  UI non avviata: {e}", flush=True)

    return {"backend_url": backend_base, "ui_url": ui_url, "share_url": share_url}

# ====== CLI ======
if __name__ == "__main__":
    do_share = os.getenv("GRADIO_SHARE", "0").lower() in ("1", "true", "yes")
    urls = launch(share=do_share)
    print(f"Links → backend: {urls['backend_url']}  ui: {urls['ui_url']}  share: {urls.get('share_url')}", flush=True)
