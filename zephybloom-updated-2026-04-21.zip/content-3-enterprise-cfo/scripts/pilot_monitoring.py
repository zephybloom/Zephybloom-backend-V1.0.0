#!/usr/bin/env python3
"""
ZephyBloom CFO Enterprise - Pilot Monitoring Dashboard
======================================================

Real-time monitoring for pilot deployment metrics.
Tracks: API performance, errors, fallback triggers, user activity.

Usage:
    python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log
"""

import json
import time
import statistics
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass, asdict
import argparse
import sys


@dataclass
class RequestMetric:
    """Single API request metric"""
    timestamp: str
    endpoint: str
    method: str
    response_time_ms: float
    status_code: int
    error: str = None
    fallback_triggered: bool = False
    tenant_id: str = None


class PilotMonitor:
    """Monitor and analyze pilot deployment metrics"""
    
    def __init__(self, log_file: str):
        self.log_file = Path(log_file)
        self.metrics = []
        self.errors = defaultdict(int)
        self.endpoint_stats = defaultdict(list)
        self.fallback_events = []
        self.load()
    
    def load(self):
        """Load metrics from log file"""
        if not self.log_file.exists():
            print(f"⚠️  Log file not found: {self.log_file}")
            return
        
        try:
            with open(self.log_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line.strip())
                        # Assume structured logging format
                        if self._is_request_metric(data):
                            metric = RequestMetric(
                                timestamp=data.get('timestamp'),
                                endpoint=data.get('endpoint'),
                                method=data.get('method'),
                                response_time_ms=data.get('response_time_ms', 0),
                                status_code=data.get('status_code'),
                                error=data.get('error'),
                                fallback_triggered=data.get('fallback_triggered', False),
                                tenant_id=data.get('tenant_id')
                            )
                            self.metrics.append(metric)
                            
                            # Track by endpoint
                            self.endpoint_stats[metric.endpoint].append(metric.response_time_ms)
                            
                            # Track errors
                            if metric.error:
                                self.errors[metric.error] += 1
                            
                            # Track fallback events
                            if metric.fallback_triggered:
                                self.fallback_events.append(metric)
                    except (json.JSONDecodeError, KeyError):
                        # Skip malformed lines
                        pass
        except Exception as e:
            print(f"❌ Error loading metrics: {e}")
    
    def _is_request_metric(self, data):
        """Check if JSON line is a request metric"""
        return all(k in data for k in ['endpoint', 'method', 'response_time_ms', 'status_code'])
    
    def get_health_summary(self):
        """Return health summary for current session"""
        if not self.metrics:
            return {
                "total_requests": 0,
                "health": "NO_DATA"
            }
        
        recent_metrics = self.metrics[-1000:]  # Last 1000 requests
        error_rate = len([m for m in recent_metrics if m.status_code >= 400]) / len(recent_metrics)
        
        response_times = [m.response_time_ms for m in recent_metrics]
        avg_response_time = statistics.mean(response_times)
        p95_response_time = statistics.quantiles(response_times, n=20)[18] if len(response_times) > 1 else 0
        
        fallback_rate = len([m for m in recent_metrics if m.fallback_triggered]) / len(recent_metrics)
        
        # Determine health status
        if error_rate > 0.05 or p95_response_time > 500:
            status = "🔴 CRITICAL"
        elif error_rate > 0.01 or p95_response_time > 200 or fallback_rate > 0.10:
            status = "🟡 WARNING"
        else:
            status = "🟢 HEALTHY"
        
        return {
            "timestamp": datetime.now().isoformat(),
            "health": status,
            "total_requests": len(self.metrics),
            "recent_requests": len(recent_metrics),
            "error_rate_pct": round(error_rate * 100, 2),
            "avg_response_time_ms": round(avg_response_time, 2),
            "p95_response_time_ms": round(p95_response_time, 2),
            "fallback_rate_pct": round(fallback_rate * 100, 2),
            "unique_errors": len(self.errors),
            "fallback_events": len(self.fallback_events),
        }
    
    def get_endpoint_stats(self):
        """Return stats per endpoint"""
        stats = {}
        for endpoint, times in self.endpoint_stats.items():
            if times:
                stats[endpoint] = {
                    "requests": len(times),
                    "avg_ms": round(statistics.mean(times), 2),
                    "p95_ms": round(statistics.quantiles(times, n=20)[18] if len(times) > 1 else 0, 2),
                    "min_ms": round(min(times), 2),
                    "max_ms": round(max(times), 2),
                }
        return stats
    
    def get_error_summary(self):
        """Return top errors"""
        sorted_errors = sorted(self.errors.items(), key=lambda x: x[1], reverse=True)
        return {
            "total_unique_errors": len(sorted_errors),
            "top_10_errors": dict(sorted_errors[:10])
        }
    
    def get_fallback_summary(self):
        """Return fallback trigger analysis"""
        return {
            "total_fallback_events": len(self.fallback_events),
            "recent_fallback_events": len([e for e in self.fallback_events 
                                          if datetime.fromisoformat(e.timestamp) > 
                                             datetime.now() - timedelta(hours=1)]),
            "affected_endpoints": list(set(e.endpoint for e in self.fallback_events)),
        }
    
    def print_dashboard(self):
        """Print formatted dashboard"""
        print("\n" + "="*80)
        print("🔍 ZephyBloom CFO Enterprise - Pilot Monitoring Dashboard")
        print("="*80)
        
        # Health Summary
        health = self.get_health_summary()
        print(f"\n📊 HEALTH SUMMARY")
        print(f"  Status:                {health['health']}")
        print(f"  Timestamp:             {health['timestamp']}")
        print(f"  Total Requests:        {health['total_requests']}")
        print(f"  Recent (1000 req):     {health['recent_requests']}")
        print(f"  Error Rate:            {health['error_rate_pct']}%")
        print(f"  Avg Response Time:     {health['avg_response_time_ms']}ms")
        print(f"  P95 Response Time:     {health['p95_response_time_ms']}ms")
        print(f"  Fallback Rate:         {health['fallback_rate_pct']}%")
        
        # Endpoint Stats
        print(f"\n🔗 ENDPOINT PERFORMANCE (Top 10)")
        endpoint_stats = self.get_endpoint_stats()
        for i, (endpoint, stats) in enumerate(sorted(endpoint_stats.items(), 
                                                      key=lambda x: x[1]['requests'], 
                                                      reverse=True)[:10], 1):
            print(f"  {i}. {endpoint}")
            print(f"     Requests: {stats['requests']:5} | Avg: {stats['avg_ms']:7.2f}ms | P95: {stats['p95_ms']:7.2f}ms | Range: {stats['min_ms']:7.2f}-{stats['max_ms']:7.2f}ms")
        
        # Error Summary
        print(f"\n⚠️  ERROR SUMMARY")
        error_summary = self.get_error_summary()
        print(f"  Total Unique Errors: {error_summary['total_unique_errors']}")
        if error_summary['top_10_errors']:
            print(f"  Top 10 Errors:")
            for error, count in list(error_summary['top_10_errors'].items())[:10]:
                print(f"    • {error}: {count} occurrences")
        else:
            print(f"  No errors detected! ✅")
        
        # Fallback Summary
        print(f"\n🔄 FALLBACK SUMMARY")
        fallback_summary = self.get_fallback_summary()
        print(f"  Total Fallback Events:  {fallback_summary['total_fallback_events']}")
        print(f"  Recent (last hour):     {fallback_summary['recent_fallback_events']}")
        if fallback_summary['affected_endpoints']:
            print(f"  Affected Endpoints:     {', '.join(fallback_summary['affected_endpoints'])}")
        
        # Alerts
        print(f"\n🚨 ALERTS")
        alerts = self._generate_alerts(health, error_summary, fallback_summary)
        if alerts:
            for alert in alerts:
                print(f"  {alert}")
        else:
            print(f"  ✅ No alerts - system operating normally")
        
        print("\n" + "="*80 + "\n")
    
    def _generate_alerts(self, health, errors, fallbacks):
        """Generate alerts based on metrics"""
        alerts = []
        
        if health['error_rate_pct'] > 5:
            alerts.append(f"🔴 CRITICAL: Error rate {health['error_rate_pct']}% > 5%")
        elif health['error_rate_pct'] > 1:
            alerts.append(f"🟡 WARNING: Error rate {health['error_rate_pct']}% > 1%")
        
        if health['p95_response_time_ms'] > 500:
            alerts.append(f"🔴 CRITICAL: P95 response {health['p95_response_time_ms']}ms > 500ms")
        elif health['p95_response_time_ms'] > 200:
            alerts.append(f"🟡 WARNING: P95 response {health['p95_response_time_ms']}ms > 200ms")
        
        if health['fallback_rate_pct'] > 10:
            alerts.append(f"🟡 WARNING: Fallback rate {health['fallback_rate_pct']}% > 10%")
        
        if errors['total_unique_errors'] > 5:
            alerts.append(f"🟡 WARNING: {errors['total_unique_errors']} unique error types detected")
        
        return alerts
    
    def export_json(self, output_file: str):
        """Export metrics to JSON file"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "health": self.get_health_summary(),
            "endpoints": self.get_endpoint_stats(),
            "errors": self.get_error_summary(),
            "fallbacks": self.get_fallback_summary(),
        }
        
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"✅ Metrics exported to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Pilot deployment monitoring")
    parser.add_argument('--log-file', required=True, help='Path to pilot.log')
    parser.add_argument('--export', help='Export metrics to JSON file')
    parser.add_argument('--watch', type=int, default=0, help='Watch mode (refresh every N seconds)')
    
    args = parser.parse_args()
    
    monitor = PilotMonitor(args.log_file)
    
    if args.watch:
        try:
            while True:
                monitor.load()  # Reload metrics
                monitor.print_dashboard()
                time.sleep(args.watch)
        except KeyboardInterrupt:
            print("\n👋 Exiting monitor...")
            sys.exit(0)
    else:
        monitor.print_dashboard()
        
        if args.export:
            monitor.export_json(args.export)


if __name__ == '__main__':
    main()
