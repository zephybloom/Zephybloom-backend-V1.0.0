#!/usr/bin/env python3
"""
Simple load test for ZephyBloom API using Python requests.
Tests:
- Health endpoint (baseline - should be <100ms)
- Docs endpoint (should be <500ms)
- Routes endpoint (should be <500ms)
"""

import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from statistics import mean, stdev

BASE_URL = "http://localhost:8003"
NUM_WORKERS = 20  # concurrent threads
REQUESTS_PER_WORKER = 5
TOTAL_REQUESTS = NUM_WORKERS * REQUESTS_PER_WORKER

# Test endpoints
ENDPOINTS = [
    ("/health", "Health Check"),
    ("/docs", "Swagger UI"),
    ("/__routes__", "Route List"),
]

results = {
    "health": [],
    "docs": [],
    "routes": [],
}

errors = {
    "health": 0,
    "docs": 0,
    "routes": 0,
}

def make_request(endpoint_key, endpoint, name):
    """Make a single request and record result."""
    try:
        start = time.time()
        resp = requests.get(f"{BASE_URL}{endpoint}", timeout=5, verify=False)
        elapsed_ms = (time.time() - start) * 1000
        
        if resp.status_code < 400:
            results[endpoint_key].append(elapsed_ms)
            return (endpoint, elapsed_ms, True)
        else:
            errors[endpoint_key] += 1
            return (endpoint, elapsed_ms, False)
    except Exception as e:
        errors[endpoint_key] += 1
        return (endpoint, None, False)

def run_load_test():
    """Run load test with concurrent requests."""
    print(f"🔄 Starting load test...")
    print(f"   Workers: {NUM_WORKERS}")
    print(f"   Requests per worker: {REQUESTS_PER_WORKER}")
    print(f"   Total requests: {TOTAL_REQUESTS}")
    print("")
    
    start_time = time.time()
    
    with ThreadPoolExecutor(max_workers=NUM_WORKERS) as executor:
        futures = []
        for _ in range(NUM_WORKERS):
            for endpoint_key, endpoint in ENDPOINTS:
                for _ in range(REQUESTS_PER_WORKER):
                    future = executor.submit(make_request, endpoint_key, endpoint, _)
                    futures.append(future)
        
        completed = 0
        for future in as_completed(futures):
            completed += 1
            if completed % 20 == 0:
                print(f"   {completed}/{TOTAL_REQUESTS} requests completed...")
    
    total_time = time.time() - start_time
    
    # Print results
    print("\n" + "=" * 60)
    print("📊 LOAD TEST RESULTS")
    print("=" * 60)
    print(f"Total Time: {total_time:.2f}s")
    print(f"Requests/sec: {TOTAL_REQUESTS / total_time:.1f}")
    print("")
    
    for endpoint_key, endpoint_list in results.items():
        endpoint_name = [name for key, name in ENDPOINTS if key == endpoint_key][0]
        
        if endpoint_list:
            min_time = min(endpoint_list)
            max_time = max(endpoint_list)
            avg_time = mean(endpoint_list)
            std = stdev(endpoint_list) if len(endpoint_list) > 1 else 0
            
            print(f"📍 {endpoint_name}")
            print(f"   Requests: {len(endpoint_list)}")
            print(f"   Errors: {errors[endpoint_key]}")
            print(f"   Min: {min_time:.1f}ms | Max: {max_time:.1f}ms")
            print(f"   Avg: {avg_time:.1f}ms (±{std:.1f}ms)")
            
            # SLA check
            if avg_time < 500:
                print(f"   ✅ SLA OK (avg < 500ms)")
            else:
                print(f"   ⚠️  SLA warning (avg >= 500ms)")
            print("")
    
    # Summary
    total_requests = sum(len(v) for v in results.values())
    total_errors = sum(errors.values())
    error_rate = (total_errors / (total_requests + total_errors)) * 100 if total_requests > 0 else 0
    
    print("=" * 60)
    print(f"✅ Total Successful: {total_requests}")
    print(f"⚠️  Total Errors: {total_errors}")
    print(f"📈 Error Rate: {error_rate:.1f}%")
    
    if error_rate < 10:
        print("✅ Load test PASSED (error rate < 10%)")
    else:
        print("❌ Load test FAILED (error rate >= 10%)")
    
    print("=" * 60)

if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings()
    
    try:
        # Check if server is running
        requests.get(f"{BASE_URL}/health", timeout=2)
        run_load_test()
    except Exception as e:
        print(f"❌ Cannot connect to API at {BASE_URL}")
        print(f"   Error: {e}")
        print(f"\n   Start server with:")
        print(f"   python3 -m uvicorn api.main:app --host 127.0.0.1 --port 8003")
