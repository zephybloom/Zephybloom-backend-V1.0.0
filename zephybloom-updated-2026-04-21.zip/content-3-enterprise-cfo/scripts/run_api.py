#!/usr/bin/env python3
"""
Helper script to run the API.
Handles path setup automatically.
"""

import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

if __name__ == "__main__":
    import uvicorn
    
    # Run the API
    uvicorn.run(
        "api.main:app",
        host="127.0.0.1",
        port=8888,
        reload=True,
        log_level="info"
    )
