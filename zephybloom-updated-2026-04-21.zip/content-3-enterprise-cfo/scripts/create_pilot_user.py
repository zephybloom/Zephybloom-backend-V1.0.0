#!/usr/bin/env python3
"""
ZephyBloom Pilot User Manager

Create and manage pilot user accounts easily.

Usage:
    python3 scripts/create_pilot_user.py --email mario@acme.it --company "Acme Inc"
    python3 scripts/create_pilot_user.py --list
    python3 scripts/create_pilot_user.py --delete mario@acme.it
"""

import sys
import os
import argparse
import secrets
import string
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from db.models import Base, User, Tenant
from datetime import datetime


def get_db_session():
    """Get database session."""
    db_path = Path(__file__).parent.parent / "zephytheory.db"
    engine = create_engine(f"sqlite:///{db_path}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    return Session()


def generate_temp_password(length=12):
    """Generate random temporary password."""
    alphabet = string.ascii_letters + string.digits + "!@#$%"
    return ''.join(secrets.choice(alphabet) for i in range(length))


def hash_password(password):
    """Hash password using bcrypt."""
    try:
        import bcrypt
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    except:
        # Fallback if bcrypt not available
        import hashlib
        return hashlib.sha256(password.encode()).hexdigest()


def create_user(email, company=None, sector=None):
    """Create a new pilot user."""
    session = get_db_session()
    
    try:
        # Check if user already exists
        existing = session.query(User).filter(User.email == email).first()
        if existing:
            print(f"❌ User {email} already exists")
            return False
        
        # Create admin user if doesn't exist (for tenant ownership)
        admin_user = session.query(User).filter(User.email == "admin@zephybloom.local").first()
        if not admin_user:
            admin_user = User(
                email="admin@zephybloom.local",
                password_hash=hash_password("AdminPassword123"),
                full_name="ZephyBloom Admin",
                role="admin",
                is_active=True
            )
            session.add(admin_user)
            session.flush()
        
        # Get or create tenant
        tenant_name = (company or email.split('@')[1]).lower().replace(" ", "-")
        tenant = session.query(Tenant).filter(Tenant.name == tenant_name).first()
        if not tenant:
            tenant = Tenant(
                id=tenant_name,
                name=company or tenant_name,
                description=f"Sector: {sector or 'Unknown'}",
                owner_id=admin_user.id
            )
            session.add(tenant)
            session.flush()
        
        # Generate temporary password
        temp_password = generate_temp_password()
        hashed_password = hash_password(temp_password)
        
        # Create user
        user = User(
            email=email,
            password_hash=hashed_password,
            full_name=company or email.split('@')[0],
            role="user",
            is_active=True
        )
        session.add(user)
        session.commit()
        
        print("\n" + "="*60)
        print("✅ PILOT USER CREATED")
        print("="*60)
        print(f"Email:              {email}")
        print(f"Company:            {company or 'N/A'}")
        print(f"Sector:             {sector or 'Unknown'}")
        print(f"Tenant:             {tenant_name}")
        print(f"\nTemporary Password: {temp_password}")
        print(f"                    (User must change on first login)")
        print("="*60 + "\n")
        
        return True
        
    except Exception as e:
        print(f"❌ Error creating user: {e}")
        session.rollback()
        return False
    finally:
        session.close()


def list_users():
    """List all pilot users."""
    session = get_db_session()
    
    try:
        users = session.query(User).filter(
            (User.metadata_.contains('pilot')) | 
            (User.metadata_.contains('"pilot": true'))
        ).all()
        
        if not users:
            # Fallback: show all users if filtering by pilot didn't work
            users = session.query(User).all()
        
        if not users:
            print("No users found")
            return
        
        print("\n" + "="*80)
        print("PILOT USERS")
        print("="*80)
        print(f"{'Email':<30} {'Company':<25} {'Created':<15}")
        print("-"*80)
        
        for user in users:
            company = "N/A"
            if user.metadata_:
                company = user.metadata_.get('company', 'N/A')
            created = user.created_at.strftime("%Y-%m-%d") if user.created_at else "?"
            print(f"{user.email:<30} {company:<25} {created:<15}")
        
        print("="*80 + "\n")
        
    except Exception as e:
        print(f"❌ Error listing users: {e}")
    finally:
        session.close()


def delete_user(email):
    """Delete a pilot user."""
    session = get_db_session()
    
    try:
        user = session.query(User).filter(User.email == email).first()
        
        if not user:
            print(f"❌ User {email} not found")
            return False
        
        session.delete(user)
        session.commit()
        print(f"✅ User {email} deleted")
        return True
        
    except Exception as e:
        print(f"❌ Error deleting user: {e}")
        session.rollback()
        return False
    finally:
        session.close()


def main():
    """CLI interface."""
    parser = argparse.ArgumentParser(
        description="ZephyBloom Pilot User Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 scripts/create_pilot_user.py --email mario@acme.it --company "Acme Inc" --sector "Manufacturing"
  python3 scripts/create_pilot_user.py --list
  python3 scripts/create_pilot_user.py --delete mario@acme.it
        """
    )
    
    parser.add_argument('--email', help='Email address of pilot user')
    parser.add_argument('--company', help='Company name')
    parser.add_argument('--sector', help='Business sector (e.g., SaaS, Manufacturing, Retail)')
    parser.add_argument('--list', action='store_true', help='List all pilot users')
    parser.add_argument('--delete', metavar='EMAIL', help='Delete a pilot user')
    
    args = parser.parse_args()
    
    if args.list:
        list_users()
    elif args.delete:
        delete_user(args.delete)
    elif args.email:
        create_user(args.email, args.company, args.sector)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
