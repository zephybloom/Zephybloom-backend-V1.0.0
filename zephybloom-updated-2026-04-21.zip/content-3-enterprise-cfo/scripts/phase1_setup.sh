#!/usr/bin/env bash
# ==============================================================================
# ZephyBloom Phase 1 Setup Script - Automated initialization for 100 clients
# ==============================================================================
#
# This script automates the setup of:
# 1. PostgreSQL database (local with docker-compose)
# 2. Database migrations
# 3. Environment configuration
# 4. Initial testing
#
# Usage:
#   bash scripts/phase1_setup.sh
#   bash scripts/phase1_setup.sh --skip-docker  # if using existing PostgreSQL
#

set -e  # Exit on any error

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

# ==============================================================================
# 1. Check prerequisites
# ==============================================================================
log_info "Phase 1 Setup: Checking prerequisites..."

if ! command -v docker &> /dev/null; then
    log_error "Docker not found. Please install Docker Desktop for macOS."
    exit 1
fi
log_success "Docker found"

if ! command -v python3 &> /dev/null; then
    log_error "Python 3 not found. Please install Python 3.11+"
    exit 1
fi
log_success "Python 3 found"

PYTHON_VERSION=$(python3 --version | awk '{print $2}')
log_success "Python version: $PYTHON_VERSION"

# ==============================================================================
# 2. Setup .env file
# ==============================================================================
log_info "Setting up .env file..."

if [ -f "$PROJECT_ROOT/.env" ]; then
    log_warning ".env already exists, backing up to .env.backup"
    cp "$PROJECT_ROOT/.env" "$PROJECT_ROOT/.env.backup"
else
    log_info "Creating .env from .env.example"
    cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
fi

# Update .env with PostgreSQL connection
sed -i '' 's|^ZB_DATABASE_URL=sqlite|# ZB_DATABASE_URL=sqlite|g' "$PROJECT_ROOT/.env"
sed -i '' '/^# For PostgreSQL with docker-compose/a\
ZB_DATABASE_URL=postgresql://zephybloom:zephybloom_dev_password_change_in_prod@localhost:5432/zephybloom_dev\
' "$PROJECT_ROOT/.env"

log_success ".env configured for PostgreSQL"

# ==============================================================================
# 3. Start PostgreSQL with docker-compose
# ==============================================================================
SKIP_DOCKER="${1:---skip-docker}"

if [ "$SKIP_DOCKER" != "--skip-docker" ]; then
    log_info "Starting PostgreSQL and Redis with docker-compose..."
    
    cd "$PROJECT_ROOT"
    docker-compose up -d postgres redis
    
    # Wait for PostgreSQL to be healthy
    log_info "Waiting for PostgreSQL to be ready..."
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U zephybloom 2>/dev/null; then
            log_success "PostgreSQL is ready"
            break
        fi
        echo -n "."
        sleep 1
    done
else
    log_warning "Skipping docker-compose. Make sure PostgreSQL is running on localhost:5432"
fi

# ==============================================================================
# 4. Install Python dependencies
# ==============================================================================
log_info "Installing Python dependencies..."

cd "$PROJECT_ROOT"
python3 -m venv venv 2>/dev/null || true

if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    log_success "Virtual environment activated"
fi

pip install --upgrade pip setuptools wheel -q
pip install -r requirements.txt -q

log_success "Dependencies installed"

# ==============================================================================
# 5. Run database migrations
# ==============================================================================
log_info "Running database migrations..."

# Option A: If using Alembic
if [ -d "alembic" ]; then
    log_info "Using Alembic for migrations"
    export DATABASE_URL="${DATABASE_URL:-postgresql://zephybloom:zephybloom_dev_password_change_in_prod@localhost:5432/zephybloom_dev}"
    alembic upgrade head 2>/dev/null || log_warning "Alembic migration failed or no migrations found"
else
    log_info "Using auto-migration from SQLAlchemy models"
    # FastAPI will create tables automatically on startup
fi

log_success "Database migration completed"

# ==============================================================================
# 6. Create initial admin user (optional)
# ==============================================================================
log_info "Creating initial test data..."

python3 << 'EOF'
import os
import sys
from datetime import datetime, timezone

# Setup path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/..')

from db.session import init_session_factory
from db.models import User, Tenant
from api.config import settings

# Initialize session
try:
    session_factory = init_session_factory()
    session = session_factory()
    
    # Check if admin exists
    admin = session.query(User).filter(User.email == "admin@zephybloom.com").first()
    
    if not admin:
        # Create admin user
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        
        admin = User(
            email="admin@zephybloom.com",
            password_hash=pwd_context.hash("admin123"),  # CHANGE THIS!
            full_name="Admin User",
            role="admin",
            is_active=True
        )
        session.add(admin)
        
        # Create default tenant
        tenant = Tenant(
            id="default",
            name="Default Tenant",
            description="Default development tenant",
            owner_id=admin.id,
            is_active=True
        )
        session.add(tenant)
        session.commit()
        
        print("✅ Created admin user (email: admin@zephybloom.com, password: admin123)")
        print("   ⚠️  CHANGE THIS PASSWORD IN PRODUCTION!")
    else:
        print("ℹ️  Admin user already exists")
    
    session.close()
except Exception as e:
    print(f"⚠️  Could not create initial user: {e}")
    pass
EOF

log_success "Initial data setup completed"

# ==============================================================================
# 7. Verify setup
# ==============================================================================
log_info "Verifying setup..."

# Test database connection
python3 << 'EOF'
import os
from sqlalchemy import create_engine, text

db_url = os.getenv("DATABASE_URL", "postgresql://zephybloom:zephybloom_dev_password_change_in_prod@localhost:5432/zephybloom_dev")

try:
    engine = create_engine(db_url)
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1"))
        print("✅ Database connection verified")
        
        # Count tables
        result = conn.execute(text("""
            SELECT COUNT(*) FROM information_schema.tables 
            WHERE table_schema = 'public'
        """))
        table_count = result.scalar()
        print(f"✅ Found {table_count} tables in database")
except Exception as e:
    print(f"❌ Database connection failed: {e}")
    exit(1)
EOF

# ==============================================================================
# 8. Summary and next steps
# ==============================================================================
echo ""
echo "==========================================================================="
log_success "Phase 1 Setup Complete! 🎉"
echo "==========================================================================="
echo ""
log_info "PostgreSQL Connection Details:"
echo "  Host:     localhost"
echo "  Port:     5432"
echo "  Database: zephybloom_dev"
echo "  User:     zephybloom"
echo "  Password: zephybloom_dev_password_change_in_prod"
echo ""
log_info "Next steps:"
echo "  1. Update .env file with your OpenAI API key:"
echo "     export ZB_OPENAI_API_KEY='sk-proj-...'"
echo ""
echo "  2. Start the API server:"
echo "     python -m uvicorn api.main:app --host 127.0.0.1 --port 8002 --reload"
echo ""
echo "  3. Start the frontend (in another terminal):"
echo "     cd frontend_react && npm start"
echo ""
echo "  4. Access the API:"
echo "     http://localhost:8002/docs (Swagger UI)"
echo ""
echo "  5. View Adminer (database browser):"
echo "     http://localhost:8081"
echo ""
echo "==========================================================================="
