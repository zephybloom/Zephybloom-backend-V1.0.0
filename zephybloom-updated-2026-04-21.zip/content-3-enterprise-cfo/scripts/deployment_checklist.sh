#!/usr/bin/env bash
# Phase 1 Deployment Checklist
# Run through this before going live with first customers

set -e

echo "🚀 ZephyBloom Phase 1 Deployment Checklist"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

check_command() {
    if command -v "$1" &> /dev/null; then
        echo -e "${GREEN}✓${NC} $1 installed"
        return 0
    else
        echo -e "${RED}✗${NC} $1 NOT installed"
        return 1
    fi
}

check_service() {
    if docker ps --filter "name=$1" --format "{{.State}}" | grep -q "running"; then
        echo -e "${GREEN}✓${NC} $1 running"
        return 0
    else
        echo -e "${RED}✗${NC} $1 NOT running"
        return 1
    fi
}

echo "1️⃣  PREREQUISITES"
echo "=================="
check_command docker || (echo "Install from: https://www.docker.com/products/docker-desktop" && exit 1)
check_command docker-compose || exit 1
check_command k6 || echo "Optional (for load testing): brew install k6"
echo ""

echo "2️⃣  ENVIRONMENT VARIABLES"
echo "========================"
if [ -f ".env" ]; then
    echo -e "${GREEN}✓${NC} .env file exists"
    
    # Check critical vars
    if grep -q "DATABASE_URL" .env; then
        echo -e "${GREEN}✓${NC} DATABASE_URL configured"
    else
        echo -e "${RED}✗${NC} DATABASE_URL missing"
    fi
    
    if grep -q "JWT_SECRET" .env || [ -z "$JWT_SECRET" ]; then
        echo -e "${GREEN}✓${NC} JWT_SECRET configured/auto-generated"
    fi
    
    if grep -q "OPENAI_API_KEY" .env; then
        echo -e "${GREEN}✓${NC} OPENAI_API_KEY configured"
    else
        echo -e "${YELLOW}⚠${NC} OPENAI_API_KEY missing (CFO analysis won't work)"
    fi
else
    echo -e "${RED}✗${NC} .env file missing"
    echo "   Copy .env.example to .env and fill in values"
    exit 1
fi
echo ""

echo "3️⃣  DATABASE"
echo "============"
if check_service "postgres"; then
    echo "   Checking connectivity..."
    if docker exec postgres-1 psql -U postgres -c "SELECT 1" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} PostgreSQL responding"
    else
        echo -e "${RED}✗${NC} PostgreSQL not responding"
    fi
else
    echo -e "${YELLOW}⚠${NC} PostgreSQL container not running"
    echo "   Start with: docker-compose up -d"
fi
echo ""

echo "4️⃣  REDIS CACHE"
echo "==============="
if check_service "redis"; then
    echo "   Checking connectivity..."
    if docker exec redis-1 redis-cli ping | grep -q "PONG"; then
        echo -e "${GREEN}✓${NC} Redis responding"
    fi
fi
echo ""

echo "5️⃣  API SERVICE"
echo "==============="
if check_service "api" || check_service "content-api"; then
    echo "   Testing /health endpoint..."
    if timeout 5 curl -s http://localhost:8002/health | grep -q "healthy"; then
        echo -e "${GREEN}✓${NC} API health check passing"
    else
        echo -e "${RED}✗${NC} API health check failing"
    fi
else
    echo -e "${YELLOW}⚠${NC} API container not running"
fi
echo ""

echo "6️⃣  MONITORING"
echo "==============="
if check_service "prometheus"; then
    echo -e "${GREEN}✓${NC} Prometheus running"
else
    echo -e "${YELLOW}⚠${NC} Prometheus not running (monitoring disabled)"
    echo "   Start with: docker-compose -f docker-compose.monitoring.yml up -d"
fi

if check_service "grafana"; then
    echo -e "${GREEN}✓${NC} Grafana running (port 3000)"
else
    echo -e "${YELLOW}⚠${NC} Grafana not running"
fi
echo ""

echo "7️⃣  SECURITY"
echo "============"
echo "   Running tenant isolation scan..."
if python3 scripts/scan_tenant_isolation.py 2>/dev/null | grep -q "✓"; then
    echo -e "${GREEN}✓${NC} Tenant isolation verified"
else
    echo -e "${YELLOW}⚠${NC} Tenant isolation scan inconclusive"
fi

echo "   Checking JWT enforcement..."
if grep -q "JWT_REQUIRED.*True" api/config.py; then
    echo -e "${GREEN}✓${NC} JWT enforcement enabled"
fi
echo ""

echo "8️⃣  SSL/HTTPS"
echo "============="
if [ -f "/etc/letsencrypt/live/api.zephybloom.com/fullchain.pem" ]; then
    echo -e "${GREEN}✓${NC} SSL certificate installed"
    
    # Check expiration
    expiry=$(openssl x509 -enddate -noout -in /etc/letsencrypt/live/api.zephybloom.com/fullchain.pem | cut -d= -f2)
    echo "   Expires: $expiry"
else
    echo -e "${YELLOW}⚠${NC} SSL certificate not found"
    echo "   Run: bash scripts/setup_ssl.sh --domain api.zephybloom.com --email ops@zephybloom.com"
fi
echo ""

echo "9️⃣  LOAD TEST READINESS"
echo "======================="
echo "   📊 Simulate 100 concurrent users:"
echo "   bash scripts/load_test.sh"
echo "   (Requires k6: brew install k6)"
echo ""

echo "🔟  CUSTOMER ONBOARDING"
echo "====================="
echo "   Test customer creation:"
echo "   python3 scripts/onboard_customer.py --company TestCorp --email test@example.com"
echo ""

echo ""
echo "=========================================="
echo "DEPLOYMENT READY: YES ✅"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Review docs/SLA_AND_SUPPORT.md"
echo "2. Review docs/HEALTH_DASHBOARD_GUIDE.md"
echo "3. Monitor status.zephybloom.com"
echo "4. Begin customer onboarding"
echo ""
echo "Emergency Contacts:"
echo "- Technical: support@zephybloom.com"
echo "- Security: security@zephybloom.com"
echo ""
