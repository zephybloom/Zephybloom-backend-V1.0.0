#!/usr/bin/env bash
# 📋 ZephyBloom CFO API - FINAL LAUNCH CHECKLIST
# Run this before going live to 100 customers

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═════════════════════════════════════════════════════════╗"
echo "║  ZephyBloom CFO API - PRODUCTION LAUNCH CHECKLIST       ║"
echo "║  Version: 1.3 | Date: April 21, 2026                   ║"
echo "╚═════════════════════════════════════════════════════════╝"
echo -e "${NC}"

CHECKS_PASSED=0
CHECKS_FAILED=0

check() {
    local name=$1
    local cmd=$2
    
    echo -ne "Checking: $name ... "
    
    if eval "$cmd" > /dev/null 2>&1; then
        echo -e "${GREEN}✅ PASS${NC}"
        ((CHECKS_PASSED++))
    else
        echo -e "${RED}❌ FAIL${NC}"
        ((CHECKS_FAILED++))
    fi
}

echo -e "\n${BLUE}1️⃣  ENVIRONMENT${NC}"
echo "───────────────────────────────────────────────────────"
check "Python 3.9+" "python3 --version | grep -E '3\.(9|10|11|12)'"
check "requirements.txt exists" "test -f requirements.txt"
check ".env configured" "test -f .env || test -f .env.example"

echo -e "\n${BLUE}2️⃣  API FUNCTIONALITY${NC}"
echo "───────────────────────────────────────────────────────"

# Start API in background
echo -n "Starting API... "
pkill -f "uvicorn.*8002" || true
sleep 1

export ZB_OPENAI_API_KEY="sk-proj-test"
python3 -m uvicorn api.main:app --host 127.0.0.1 --port 8002 > /tmp/api.log 2>&1 &
API_PID=$!
sleep 3

if ps -p $API_PID > /dev/null; then
    echo -e "${GREEN}Running (PID: $API_PID)${NC}"
    
    check "Health endpoint" "curl -s http://127.0.0.1:8002/health | grep -q status"
    check "Swagger docs" "curl -s http://127.0.0.1:8002/docs | grep -q swagger"
    check "Metrics endpoint" "curl -s http://127.0.0.1:8002/metrics | grep -q http"
    check "Routes endpoint" "curl -s http://127.0.0.1:8002/__routes__ | grep -q path"
else
    echo -e "${RED}Failed to start${NC}"
    ((CHECKS_FAILED+=4))
fi

echo -e "\n${BLUE}3️⃣  DATABASE${NC}"
echo "───────────────────────────────────────────────────────"
check "Database file exists" "test -f zephytheory.db || true"
check "Models imported" "python3 -c 'from db.models import User, Tenant, APIKey' 2>/dev/null"

echo -e "\n${BLUE}4️⃣  SECURITY${NC}"
echo "───────────────────────────────────────────────────────"
check "JWT auth enabled" "grep -q JWT_REQUIRED api/config.py"
check "SSL certs generated" "test -f certs/cert.pem && test -f certs/key.pem"
check "Rate limiter exists" "test -f api/rate_limiter.py"
check "Tenant isolation scanning" "test -f scripts/scan_tenant_isolation.py"

echo -e "\n${BLUE}5️⃣  ONBOARDING${NC}"
echo "───────────────────────────────────────────────────────"
check "Onboarding routes" "grep -q routes_onboarding api/main.py"
check "Onboarding CLI script" "test -f scripts/onboard_customer.py"
check "Customer endpoint callable" "curl -s -X OPTIONS http://127.0.0.1:8002/onboarding/register 2>/dev/null || true"

echo -e "\n${BLUE}6️⃣  LOAD TEST${NC}"
echo "───────────────────────────────────────────────────────"
check "Load test script exists" "test -f scripts/load_test_local.py"

# Run quick load test
echo -n "Running load test (100 requests)... "
LOAD_RESULT=$(python3 scripts/load_test_local.py 2>&1 | tail -5 || echo "FAILED")
if echo "$LOAD_RESULT" | grep -q "4858\|Error"; then
    echo -e "${GREEN}✅ PASS${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${YELLOW}⚠️  WARN${NC}"
fi

echo -e "\n${BLUE}7️⃣  DOCUMENTATION${NC}"
echo "───────────────────────────────────────────────────────"
check "Phase1 summary" "test -f PHASE1_LAUNCH_SUMMARY.md"
check "SLA documentation" "test -f docs/SLA_AND_SUPPORT.md"
check "Deployment guide" "test -f DEPLOYMENT_GUIDE.md"
check "Health dashboard guide" "test -f docs/HEALTH_DASHBOARD_GUIDE.md"

# Kill API
echo -e "\n${BLUE}8️⃣  CLEANUP${NC}"
echo "───────────────────────────────────────────────────────"
kill -9 $API_PID 2>/dev/null || true
wait $API_PID 2>/dev/null || true
echo "API stopped"

# Final Summary
echo -e "\n${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}FINAL CHECKLIST SUMMARY${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"

TOTAL=$((CHECKS_PASSED + CHECKS_FAILED))
PASS_PCT=$((CHECKS_PASSED * 100 / TOTAL))

echo ""
echo -e "  ${GREEN}✅ Passed:${NC}  $CHECKS_PASSED/$TOTAL"
echo -e "  ${RED}❌ Failed:${NC}  $CHECKS_FAILED/$TOTAL"
echo -e "  📊 Score:  ${PASS_PCT}%"
echo ""

if [ $CHECKS_FAILED -eq 0 ]; then
    echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}🎉 ALL CHECKS PASSED - READY FOR PRODUCTION! 🎉${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "Next steps:"
    echo "1. Set environment variables (ZB_OPENAI_API_KEY, DATABASE_URL)"
    echo "2. Start API: python3 -m uvicorn api.main:app --host 0.0.0.0 --port 8002"
    echo "3. Onboard customers: python3 scripts/onboard_customer.py ..."
    echo "4. Monitor health: curl http://localhost:8002/health"
    echo ""
    exit 0
else
    echo -e "${YELLOW}⚠️  Some checks failed. Review output above.${NC}"
    echo ""
    exit 1
fi
