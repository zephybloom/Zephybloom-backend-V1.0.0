#!/usr/bin/env python3
"""
Scan for SQL queries that don't filter by tenant_id (potential security vulnerability).

This script helps identify routes that need tenant isolation fixes.

Usage:
    python3 scripts/scan_tenant_isolation.py
"""

import os
import re
from pathlib import Path
from typing import List, Tuple

# Patterns that indicate a query without tenant filtering
RISK_PATTERNS = [
    r'db\.query\([^)]+\)\.(?:all|first|filter)',  # db.query(Model).filter(...) without tenant check
    r'db\.execute\(.*SELECT.*FROM',               # Raw SQL SELECT
]

SAFE_PATTERNS = [
    r'tenant_id.*=' ,                              # Has tenant_id filter
    r'Tenant\.id',                                 # Tenant-specific query
    r'AuditLog|APIKey',                            # These are tenant-scoped
]

IGNORE_PATTERNS = [
    r'test_',                                      # Test files
    r'__pycache__',                                # Cache
    r'\.pyc',                                      # Compiled
    r'alembic',                                    # Migrations
]


def is_risky_query(line: str, context_lines: List[str], line_no: int) -> bool:
    """Check if a line contains a risky query without tenant isolation."""
    
    # Check if commented out
    if line.strip().startswith('#'):
        return False
    
    # Check for tenant filtering in current line
    if any(re.search(p, line) for p in SAFE_PATTERNS):
        return False
    
    # Check for risky patterns
    if not any(re.search(p, line, re.IGNORECASE) for p in RISK_PATTERNS):
        return False
    
    # Check context (next 3 lines) for tenant filtering
    for i in range(line_no + 1, min(line_no + 4, len(context_lines))):
        if any(re.search(p, context_lines[i]) for p in SAFE_PATTERNS):
            return False
    
    return True


def scan_file(filepath: Path) -> List[Tuple[int, str]]:
    """Scan a file for risky queries."""
    
    # Skip certain files
    if any(re.search(p, str(filepath)) for p in IGNORE_PATTERNS):
        return []
    
    if filepath.suffix != '.py':
        return []
    
    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
        
        risky_lines = []
        for i, line in enumerate(lines):
            if is_risky_query(line, lines, i):
                risky_lines.append((i + 1, line.strip()))
        
        return risky_lines
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return []


def main():
    project_root = Path(__file__).parent.parent
    
    # Scan api/ and core/ directories
    scan_dirs = [
        project_root / 'api',
        project_root / 'core',
    ]
    
    all_issues = {}
    
    print("🔍 Scanning for tenant isolation vulnerabilities...\n")
    
    for scan_dir in scan_dirs:
        if not scan_dir.exists():
            continue
        
        for py_file in scan_dir.rglob('*.py'):
            risky_lines = scan_file(py_file)
            if risky_lines:
                rel_path = py_file.relative_to(project_root)
                all_issues[rel_path] = risky_lines
    
    # Print results
    if all_issues:
        print(f"⚠️  Found {sum(len(v) for v in all_issues.values())} potential issues:\n")
        
        for filepath, issues in sorted(all_issues.items()):
            print(f"\n📄 {filepath}")
            print("   " + "=" * 60)
            for line_no, line_text in issues:
                print(f"   Line {line_no}: {line_text[:70]}")
                print(f"   ☝️  ADD: .filter({filepath.stem}_model.tenant_id == tenant_id)")
            print()
        
        print("\n" + "=" * 70)
        print("FIX TEMPLATE:")
        print("=" * 70)
        print("""
# BEFORE (❌ Unsafe)
query = db.query(CompanyMetrics).filter(CompanyMetrics.name == "ACME").all()

# AFTER (✅ Safe)
query = db.query(CompanyMetrics).filter(
    CompanyMetrics.tenant_id == tenant_id,    # ← Add this!
    CompanyMetrics.name == "ACME"
).all()
""")
    else:
        print("✅ No obvious tenant isolation issues found!")
    
    return len(all_issues)


if __name__ == "__main__":
    issue_count = main()
    exit(0 if issue_count == 0 else 1)
