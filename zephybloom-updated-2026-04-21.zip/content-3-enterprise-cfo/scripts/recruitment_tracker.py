#!/usr/bin/env python3
"""
Pilot Recruitment Tracker
=========================

Simple command-line tool to track recruitment progress.

Usage:
    python3 scripts/recruitment_tracker.py --add "Alice Rossi" "TechStartup" "alice@tech.it"
    python3 scripts/recruitment_tracker.py --update "Alice Rossi" --status "Interested"
    python3 scripts/recruitment_tracker.py --report
    python3 scripts/recruitment_tracker.py --list
"""

import csv
import json
from datetime import datetime
from pathlib import Path
import argparse
from dataclasses import dataclass, asdict
import sys


@dataclass
class Contact:
    """A recruitment contact"""
    name: str
    company: str
    sector: str = ""
    email: str = ""
    phone: str = ""
    linkedin: str = ""
    revenue_est: str = ""
    contact_date: str = ""
    status: str = "New"  # New, Contacted, Interested, Accepted, Declined, No_Response
    response_date: str = ""
    decision: str = "Pending"  # Pending, Yes, No, Maybe
    onboarding_date: str = ""
    notes: str = ""
    
    def __post_init__(self):
        if not self.contact_date and self.status != "New":
            self.contact_date = datetime.now().strftime("%Y-%m-%d")


class RecruitmentTracker:
    """Track pilot recruitment progress"""
    
    def __init__(self, csv_file: str = "pilot_recruitment.csv"):
        self.csv_file = Path(csv_file)
        self.contacts = []
        self.load()
    
    def load(self):
        """Load contacts from CSV"""
        if self.csv_file.exists():
            try:
                with open(self.csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        if row.get('name'):
                            contact = Contact(
                                name=row.get('name'),
                                company=row.get('company'),
                                sector=row.get('sector', ''),
                                email=row.get('email', ''),
                                phone=row.get('phone', ''),
                                linkedin=row.get('linkedin', ''),
                                revenue_est=row.get('revenue_est', ''),
                                contact_date=row.get('contact_date', ''),
                                status=row.get('status', 'New'),
                                response_date=row.get('response_date', ''),
                                decision=row.get('decision', 'Pending'),
                                onboarding_date=row.get('onboarding_date', ''),
                                notes=row.get('notes', '')
                            )
                            self.contacts.append(contact)
            except Exception as e:
                print(f"❌ Error loading CSV: {e}")
    
    def save(self):
        """Save contacts to CSV"""
        try:
            fieldnames = [
                'name', 'company', 'sector', 'email', 'phone', 'linkedin',
                'revenue_est', 'contact_date', 'status', 'response_date',
                'decision', 'onboarding_date', 'notes'
            ]
            
            with open(self.csv_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for contact in self.contacts:
                    writer.writerow(asdict(contact))
            
            print(f"✅ Saved {len(self.contacts)} contacts to {self.csv_file}")
        except Exception as e:
            print(f"❌ Error saving CSV: {e}")
    
    def add(self, name: str, company: str, sector: str = "", email: str = "", 
            phone: str = "", notes: str = ""):
        """Add a new contact"""
        # Check if already exists
        if any(c.name.lower() == name.lower() for c in self.contacts):
            print(f"⚠️  {name} already in database")
            return False
        
        contact = Contact(
            name=name,
            company=company,
            sector=sector,
            email=email,
            phone=phone,
            contact_date=datetime.now().strftime("%Y-%m-%d"),
            status="Contacted",
            notes=notes
        )
        self.contacts.append(contact)
        self.save()
        print(f"✅ Added: {name} ({company})")
        return True
    
    def update(self, name: str, **kwargs):
        """Update a contact"""
        for contact in self.contacts:
            if contact.name.lower() == name.lower():
                for key, value in kwargs.items():
                    if hasattr(contact, key):
                        setattr(contact, key, value)
                        if key == 'response_date' and not value:
                            contact.response_date = datetime.now().strftime("%Y-%m-%d")
                
                self.save()
                print(f"✅ Updated: {name}")
                return True
        
        print(f"❌ Contact not found: {name}")
        return False
    
    def get_status_count(self):
        """Count contacts by status"""
        counts = {}
        for contact in self.contacts:
            status = contact.status
            counts[status] = counts.get(status, 0) + 1
        
        return counts
    
    def get_decision_count(self):
        """Count contacts by decision"""
        counts = {}
        for contact in self.contacts:
            decision = contact.decision
            counts[decision] = counts.get(decision, 0) + 1
        
        return counts
    
    def print_report(self):
        """Print recruitment progress report"""
        print("\n" + "="*80)
        print("📊 PILOT RECRUITMENT REPORT")
        print("="*80 + "\n")
        
        # Summary
        total = len(self.contacts)
        status_counts = self.get_status_count()
        decision_counts = self.get_decision_count()
        
        accepted = decision_counts.get('Yes', 0)
        
        print(f"Total Contacts: {total}")
        print(f"Accepted (Yes): {accepted} {'✅' if accepted >= 5 else '🔄'}")
        print(f"Target: 10 companies\n")
        
        # Status breakdown
        print("Status Breakdown:")
        statuses = ['New', 'Contacted', 'Interested', 'Accepted', 'Declined', 'No_Response']
        for status in statuses:
            count = status_counts.get(status, 0)
            pct = (count / total * 100) if total > 0 else 0
            bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
            print(f"  {status:15} {count:3} ({pct:5.1f}%) {bar}")
        
        # Decision breakdown
        print("\nDecision Breakdown:")
        decisions = ['Pending', 'Yes', 'No', 'Maybe']
        for decision in decisions:
            count = decision_counts.get(decision, 0)
            pct = (count / total * 100) if total > 0 else 0
            emoji = "✅" if decision == "Yes" else "⏳" if decision == "Pending" else "❌" if decision == "No" else "🤔"
            print(f"  {decision:10} {count:3} ({pct:5.1f}%) {emoji}")
        
        # Progress
        print("\nProgress Metrics:")
        contacted = status_counts.get('Contacted', 0) + status_counts.get('Interested', 0) + accepted
        response_rate = (contacted / total * 100) if total > 0 else 0
        conversion_rate = (accepted / contacted * 100) if contacted > 0 else 0
        
        print(f"  Outreach Rate: {response_rate:.0f}% ({contacted}/{total})")
        print(f"  Conversion Rate: {conversion_rate:.0f}% ({accepted}/{contacted})")
        print(f"  Target Conversion: 50% (5-6 from {total-accepted} pending)")
        
        # By sector (if data)
        sectors = set(c.sector for c in self.contacts if c.sector)
        if sectors:
            print("\nBy Sector:")
            for sector in sorted(sectors):
                count = len([c for c in self.contacts if c.sector == sector])
                sector_accepted = len([c for c in self.contacts if c.sector == sector and c.decision == 'Yes'])
                print(f"  {sector:15} {count:3} contacts, {sector_accepted} accepted")
        
        print("\n" + "="*80 + "\n")
    
    def print_list(self, filter_status: str = None, filter_decision: str = None):
        """Print formatted contact list"""
        filtered = self.contacts
        
        if filter_status:
            filtered = [c for c in filtered if c.status == filter_status]
        if filter_decision:
            filtered = [c for c in filtered if c.decision == filter_decision]
        
        print(f"\n{'Name':<20} {'Company':<25} {'Sector':<15} {'Status':<12} {'Decision':<10} {'Notes':<30}")
        print("-" * 130)
        
        for contact in filtered:
            notes = contact.notes[:27] + "..." if len(contact.notes) > 30 else contact.notes
            status_emoji = {
                'New': '🆕',
                'Contacted': '📧',
                'Interested': '🤔',
                'Accepted': '✅',
                'Declined': '❌',
                'No_Response': '❓'
            }.get(contact.status, '  ')
            
            decision_emoji = {
                'Pending': '⏳',
                'Yes': '✅',
                'No': '❌',
                'Maybe': '🤔'
            }.get(contact.decision, '  ')
            
            print(f"{contact.name:<20} {contact.company:<25} {contact.sector:<15} {contact.status:<12} {contact.decision:<10} {notes:<30}")
        
        print()
    
    def next_to_follow_up(self):
        """Show contacts that need follow-up"""
        to_followup = [c for c in self.contacts if c.status in ['New', 'No_Response'] or 
                      (c.status == 'Interested' and c.decision == 'Pending')]
        
        if not to_followup:
            print("✅ No follow-ups needed! Everyone has been contacted.")
            return
        
        print("\n🔔 Follow-up Needed:\n")
        for contact in to_followup[:10]:  # Show top 10
            days_since = ""
            if contact.contact_date:
                contact_dt = datetime.strptime(contact.contact_date, "%Y-%m-%d")
                days = (datetime.now() - contact_dt).days
                days_since = f" ({days} days ago)"
            
            print(f"  • {contact.name:20} - {contact.company:25} - {contact.status}{days_since}")
            if contact.email:
                print(f"    Email: {contact.email}")
            if contact.notes:
                print(f"    Note: {contact.notes}")
        
        print()


def main():
    parser = argparse.ArgumentParser(description="Pilot Recruitment Tracker")
    parser.add_argument('--csv', default='pilot_recruitment.csv', help='CSV file path')
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add new contact')
    add_parser.add_argument('name', help='Contact name')
    add_parser.add_argument('company', help='Company name')
    add_parser.add_argument('--sector', default='', help='Sector (SaaS/Manufacturing/Retail)')
    add_parser.add_argument('--email', default='', help='Email address')
    add_parser.add_argument('--phone', default='', help='Phone number')
    add_parser.add_argument('--notes', default='', help='Notes')
    
    # Update command
    update_parser = subparsers.add_parser('update', help='Update contact')
    update_parser.add_argument('name', help='Contact name')
    update_parser.add_argument('--status', help='Status (Contacted/Interested/Accepted/Declined/No_Response)')
    update_parser.add_argument('--decision', help='Decision (Yes/No/Maybe/Pending)')
    update_parser.add_argument('--notes', help='Update notes')
    update_parser.add_argument('--email', help='Update email')
    
    # Report command
    subparsers.add_parser('report', help='Show recruitment report')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List contacts')
    list_parser.add_argument('--status', help='Filter by status')
    list_parser.add_argument('--decision', help='Filter by decision')
    
    # Follow-up command
    subparsers.add_parser('followup', help='Show who needs follow-up')
    
    args = parser.parse_args()
    
    tracker = RecruitmentTracker(args.csv)
    
    if args.command == 'add':
        tracker.add(args.name, args.company, args.sector, args.email, args.phone, args.notes)
    
    elif args.command == 'update':
        kwargs = {}
        if args.status:
            kwargs['status'] = args.status
        if args.decision:
            kwargs['decision'] = args.decision
        if args.notes:
            kwargs['notes'] = args.notes
        if args.email:
            kwargs['email'] = args.email
        
        tracker.update(args.name, **kwargs)
    
    elif args.command == 'report':
        tracker.print_report()
    
    elif args.command == 'list':
        tracker.print_list(filter_status=args.status, filter_decision=args.decision)
    
    elif args.command == 'followup':
        tracker.next_to_follow_up()
    
    else:
        # Default: show report
        tracker.print_report()


if __name__ == '__main__':
    main()
