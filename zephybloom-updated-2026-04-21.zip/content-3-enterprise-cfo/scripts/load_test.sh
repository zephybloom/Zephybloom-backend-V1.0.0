#!/usr/bin/env bash
# Load testing for ZephyBloom CFO API
# Tests performance with 100 concurrent users
#
# Prerequisites:
#   brew install k6  (macOS)
#   
# Usage:
#   bash scripts/load_test.sh
#   bash scripts/load_test.sh http://api.zephybloom.com

set -e

# Configuration
API_URL="${1:-http://localhost:8002}"
DURATION="${2:-5m}"  # 5 minutes default

echo "🔥 Load Testing ZephyBloom CFO API"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "API URL:  $API_URL"
echo "Duration: $DURATION"
echo "VUs:      100 concurrent users"
echo ""

# Check if k6 is installed
if ! command -v k6 &> /dev/null; then
    echo "❌ k6 not found. Install with:"
    echo "   brew install k6"
    exit 1
fi

PROJECT_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TEST_FILE="$PROJECT_ROOT/k6_load_test.js"

if [ ! -f "$TEST_FILE" ]; then
    echo "❌ Test file not found: $TEST_FILE"
    exit 1
fi

echo "📊 Running k6 load test..."
echo ""

# Run k6 test
k6 run \
    --vus 100 \
    --duration "$DURATION" \
    -e API_URL="$API_URL" \
    "$TEST_FILE"

echo ""
echo "✅ Load test complete!"
echo ""
echo "📈 Check results at http://localhost:8002/metrics"
