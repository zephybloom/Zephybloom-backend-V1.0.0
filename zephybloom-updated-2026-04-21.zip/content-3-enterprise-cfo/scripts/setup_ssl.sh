#!/usr/bin/env bash
# Setup SSL/HTTPS with Let's Encrypt and Certbot
#
# Prerequisites:
# - Domain name (e.g., api.zephybloom.com)
# - DNS A record pointing to your server
# - Ports 80 and 443 open on firewall
#
# Usage:
#   bash scripts/setup_ssl.sh api.zephybloom.com
#   bash scripts/setup_ssl.sh api.zephybloom.com your-email@company.com

set -e

DOMAIN="${1:-api.zephybloom.com}"
EMAIL="${2:-admin@zephybloom.com}"

echo "🔒 Setting up SSL/HTTPS for ZephyBloom CFO API"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Domain: $DOMAIN"
echo "Email:  $EMAIL"
echo ""

# ==============================================================================
# STEP 1: Install Certbot
# ==============================================================================
echo "📦 Step 1: Installing Certbot..."

if command -v certbot &> /dev/null; then
    echo "✅ Certbot already installed"
else
    # macOS
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "Installing via Homebrew..."
        brew install certbot
    # Ubuntu/Debian
    elif [ -f /etc/debian_version ]; then
        echo "Installing via apt..."
        sudo apt-get update
        sudo apt-get install -y certbot python3-certbot-nginx
    else
        echo "❌ Unsupported OS. Please install certbot manually:"
        echo "   https://certbot.eff.org/instructions"
        exit 1
    fi
fi

echo "✅ Certbot installed"
echo ""

# ==============================================================================
# STEP 2: Install Nginx (if not present)
# ==============================================================================
echo "📦 Step 2: Installing Nginx..."

if command -v nginx &> /dev/null; then
    echo "✅ Nginx already installed"
else
    # macOS
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install nginx
    # Ubuntu/Debian
    elif [ -f /etc/debian_version ]; then
        sudo apt-get install -y nginx
    fi
fi

echo "✅ Nginx installed"
echo ""

# ==============================================================================
# STEP 3: Setup Nginx Configuration
# ==============================================================================
echo "🔧 Step 3: Configuring Nginx..."

# Copy Nginx config
PROJECT_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
NGINX_CONFIG="$PROJECT_ROOT/nginx.conf"

# Replace domain placeholder
TEMP_CONFIG="/tmp/zephybloom_nginx_$$.conf"
cp "$NGINX_CONFIG" "$TEMP_CONFIG"
sed -i '' "s/api.zephybloom.com/$DOMAIN/g" "$TEMP_CONFIG"

# Backup existing Nginx config if it exists
if [ -f /etc/nginx/sites-available/zephybloom ]; then
    sudo cp /etc/nginx/sites-available/zephybloom /etc/nginx/sites-available/zephybloom.backup
fi

# Install the new config
sudo cp "$TEMP_CONFIG" /etc/nginx/sites-available/zephybloom
sudo mkdir -p /etc/nginx/sites-enabled
sudo ln -sf /etc/nginx/sites-available/zephybloom /etc/nginx/sites-enabled/zephybloom
rm "$TEMP_CONFIG"

# Test Nginx config
echo "Testing Nginx configuration..."
sudo nginx -t

echo "✅ Nginx configured"
echo ""

# ==============================================================================
# STEP 4: Obtain Let's Encrypt Certificate
# ==============================================================================
echo "🔐 Step 4: Obtaining SSL certificate from Let's Encrypt..."
echo "   (This may take a few seconds...)"
echo ""

# Create certbot directory
sudo mkdir -p /var/www/certbot

# Obtain certificate with standalone authentication
# (stops Nginx, gets cert, starts Nginx)
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS: certbot usually installed via Homebrew
    CERTBOT_CMD="certbot"
else
    # Linux: may need sudo
    CERTBOT_CMD="sudo certbot"
fi

# Use HTTP-01 challenge (requires port 80 open)
$CERTBOT_CMD certonly \
    --standalone \
    --preferred-challenges http \
    -d "$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --non-interactive \
    --rsa-key-size 4096

if [ $? -eq 0 ]; then
    echo "✅ SSL certificate obtained successfully!"
else
    echo "❌ Failed to obtain certificate. Check:"
    echo "   - Domain DNS is pointing to this server"
    echo "   - Port 80 is open on firewall"
    echo "   - Email address is valid"
    exit 1
fi

echo ""

# ==============================================================================
# STEP 5: Setup Auto-Renewal
# ==============================================================================
echo "🔄 Step 5: Setting up automatic renewal..."

# Add to crontab for automatic renewal
CRON_ENTRY="0 0 * * * $CERTBOT_CMD renew --quiet --post-hook 'nginx -s reload'"

if ! (crontab -l 2>/dev/null | grep -q "certbot renew"); then
    echo "$CRON_ENTRY" | crontab -
    echo "✅ Automatic renewal scheduled (daily at midnight)"
else
    echo "✅ Renewal already in crontab"
fi

echo ""

# ==============================================================================
# STEP 6: Start/Reload Nginx
# ==============================================================================
echo "🚀 Step 6: Starting Nginx..."

if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS: start Nginx service
    brew services start nginx 2>/dev/null || true
else
    # Linux
    sudo systemctl start nginx
    sudo systemctl enable nginx
fi

# Reload Nginx with new config
sudo nginx -s reload

echo "✅ Nginx started"
echo ""

# ==============================================================================
# STEP 7: Verify Setup
# ==============================================================================
echo "✅ Verification:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Test HTTPS
echo "Testing HTTPS connection..."
sleep 2

if curl -s --cacert /etc/letsencrypt/live/$DOMAIN/chain.pem \
    https://$DOMAIN/health > /dev/null 2>&1; then
    echo "✅ HTTPS connection working"
else
    echo "⚠️  HTTPS test failed (backend may not be running yet)"
fi

echo ""
echo "🎉 SSL/HTTPS Setup Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Certificate Details:"
echo "  Location:  /etc/letsencrypt/live/$DOMAIN/"
echo "  Expires:   $(openssl x509 -enddate -noout -in /etc/letsencrypt/live/$DOMAIN/cert.pem | cut -d= -f2)"
echo ""
echo "Next Steps:"
echo "  1. Start your FastAPI backend:"
echo "     python -m uvicorn api.main:app --port 8002"
echo ""
echo "  2. Test HTTPS:"
echo "     curl https://$DOMAIN/health"
echo ""
echo "  3. View Nginx logs:"
echo "     sudo tail -f /var/log/nginx/zephybloom_error.log"
echo ""
echo "  4. Monitor certificate expiry:"
echo "     sudo certbot certificates"
echo ""
echo "═══════════════════════════════════════════════════════════"
