#!/usr/bin/env python3
"""
Migrate database from SQLite to PostgreSQL.

Usage:
    export DATABASE_URL_SQLITE="sqlite:///./zephytheory.db"
    export DATABASE_URL_POSTGRES="postgresql://user:password@localhost:5432/zephybloom_prod"
    python3 scripts/migrate_sqlite_to_postgres.py
"""

import sys
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import create_engine, inspect, MetaData, Table, select
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def migrate_database(
    sqlite_url: str,
    postgres_url: str,
    dry_run: bool = False,
) -> bool:
    """
    Migrate all data from SQLite to PostgreSQL.
    
    Args:
        sqlite_url: SQLite connection string
        postgres_url: PostgreSQL connection string
        dry_run: If True, validates but doesn't write
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Connect to both databases
        logger.info(f"🔌 Connecting to SQLite: {sqlite_url}")
        sqlite_engine = create_engine(sqlite_url)
        
        logger.info(f"🔌 Connecting to PostgreSQL: {postgres_url}")
        postgres_engine = create_engine(postgres_url)
        
        # Test connections
        with sqlite_engine.connect() as conn:
            conn.execute("SELECT 1")
        logger.info("✅ SQLite connection OK")
        
        with postgres_engine.connect() as conn:
            conn.execute("SELECT 1")
        logger.info("✅ PostgreSQL connection OK")
        
        # Get metadata from both databases
        sqlite_metadata = MetaData()
        sqlite_metadata.reflect(bind=sqlite_engine)
        
        postgres_metadata = MetaData()
        postgres_metadata.reflect(bind=postgres_engine)
        
        logger.info(f"\n📊 Found {len(sqlite_metadata.tables)} tables in SQLite")
        logger.info(f"📊 Found {len(postgres_metadata.tables)} tables in PostgreSQL")
        
        # Get table list
        tables_to_migrate = [
            "users",
            "tenants",
            "api_keys",
            "audit_logs",
            "tenant_settings",
            "decisions",
            "decision_accuracy",
            "war_room_decision_memory",
            "company_metrics_history",
        ]
        
        sqlite_session = sessionmaker(bind=sqlite_engine)()
        postgres_session = sessionmaker(bind=postgres_engine)()
        
        total_records = 0
        
        try:
            # Migrate each table
            for table_name in tables_to_migrate:
                if table_name not in sqlite_metadata.tables:
                    logger.warning(f"⚠️  Table {table_name} not found in SQLite, skipping")
                    continue
                
                sqlite_table = sqlite_metadata.tables[table_name]
                
                # Read all records from SQLite
                logger.info(f"\n📥 Reading {table_name}...")
                
                # Use raw SQL to bypass ORM complexity
                with sqlite_engine.connect() as conn:
                    result = conn.execute(f"SELECT COUNT(*) as count FROM {table_name}")
                    count = result.scalar()
                    logger.info(f"   Found {count} records")
                
                # Disable foreign key checks temporarily (for PostgreSQL)
                if not dry_run:
                    with postgres_engine.connect() as conn:
                        conn.execute("SET CONSTRAINTS ALL DEFERRED")
                        conn.commit()
                
                # Copy data using raw SQL (faster than ORM)
                logger.info(f"📤 Copying {table_name} to PostgreSQL...")
                
                # Build INSERT statement
                with sqlite_engine.connect() as src_conn:
                    result = src_conn.execute(f"SELECT * FROM {table_name}")
                    rows = result.fetchall()
                    
                    if rows:
                        # Get column names
                        cols = [col[0] for col in result.cursor.description]
                        col_str = ", ".join(f'"{col}"' for col in cols)
                        
                        if not dry_run and len(rows) > 0:
                            # Use PostgreSQL COPY for bulk insert (fastest)
                            import io
                            import csv
                            
                            buffer = io.StringIO()
                            writer = csv.writer(buffer)
                            writer.writerows(rows)
                            
                            with postgres_engine.connect() as tgt_conn:
                                copy_sql = f"COPY {table_name} ({col_str}) FROM STDIN WITH (FORMAT csv)"
                                with tgt_conn.connection.cursor() as cursor:
                                    cursor.copy_expert(copy_sql, buffer)
                                    tgt_conn.commit()
                    
                total_records += len(rows) if rows else 0
                logger.info(f"   ✅ {len(rows) if rows else 0} records copied")
        
        finally:
            sqlite_session.close()
            postgres_session.close()
        
        if not dry_run:
            # Re-enable constraints
            with postgres_engine.connect() as conn:
                conn.execute("SET CONSTRAINTS ALL IMMEDIATE")
                conn.commit()
            
            logger.info(f"\n🎉 Migration complete! Total records: {total_records}")
            return True
        else:
            logger.info(f"\n📋 DRY RUN complete. Would migrate {total_records} records")
            return True
    
    except SQLAlchemyError as e:
        logger.error(f"❌ Database error: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    import os
    
    sqlite_url = os.getenv("DATABASE_URL_SQLITE", "sqlite:///./zephytheory.db")
    postgres_url = os.getenv("DATABASE_URL_POSTGRES", "postgresql://postgres:password@localhost:5432/zephybloom_dev")
    
    dry_run = "--dry-run" in sys.argv or "-n" in sys.argv
    
    if dry_run:
        logger.info("🔍 Running in DRY RUN mode (no data will be written)")
    
    success = migrate_database(sqlite_url, postgres_url, dry_run=dry_run)
    sys.exit(0 if success else 1)
