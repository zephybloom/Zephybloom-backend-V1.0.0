# -*- coding: utf-8 -*-
# content/core/montecarlo.py — Monte Carlo robusto (seed, guard-rails, summary)
from __future__ import annotations

from typing import Dict, List, Literal, Tuple, Callable, Any, Optional
import random
import math
import statistics

from core.scenario import simulate

DistName = Literal["normal", "lognormal", "uniform", "triangular"]


# -----------------------------
# Samplers distribuzioni (robusti)
# -----------------------------
def _normal(mu: float, sigma: float) -> float:
    return random.gauss(mu, max(0.0, sigma))


def _lognormal(mu: float, sigma: float) -> float:
    # random.lognormvariate usa mu/sigma della normale sottostante
    return random.lognormvariate(mu, max(0.0, sigma))


def _uniform(a: float, b: float) -> float:
    if b < a:
        a, b = b, a
    return random.uniform(a, b)


def _triangular(a: float, b: float, c: float) -> float:
    lo, hi = (a, b) if a <= b else (b, a)
    mode = min(max(c, lo), hi)
    return random.triangular(lo, hi, mode)


def _get(p: Dict[str, Any], key: str, default: float) -> float:
    try:
        v = float(p.get(key, default))
        if math.isnan(v) or math.isinf(v):
            return default
        return v
    except Exception:
        return default


def _sampler(name: DistName, p: dict) -> Callable[[], float]:
    name = str(name).lower().strip()  # type: ignore[arg-type]
    if name == "normal":
        mu = _get(p, "mu", 0.0)
        sigma = _get(p, "sigma", 1.0)
        return lambda: _normal(mu, sigma)
    if name == "lognormal":
        mu = _get(p, "mu", 0.0)
        sigma = _get(p, "sigma", 1.0)
        return lambda: _lognormal(mu, sigma)
    if name == "uniform":
        a = _get(p, "a", 0.0)
        b = _get(p, "b", 1.0)
        return lambda: _uniform(a, b)
    if name == "triangular":
        a = _get(p, "a", 0.0)
        b = _get(p, "b", 1.0)
        c = _get(p, "c", (a + b) / 2.0)
        return lambda: _triangular(a, b, c)
    raise ValueError(f"Distribuzione non supportata: {name}")
def as_percent(stats: dict) -> dict:
    out = {}
    for k, v in (stats or {}).items():
        if isinstance(v, dict):
            out[k] = {kk: (vv * 100 if k == "roi" else vv) for kk, vv in v.items()}
        else:
            out[k] = v
    return out


# -----------------------------
# Statistiche riassuntive
# -----------------------------
def summarize(arr: List[float]) -> Dict[str, float]:
    if not arr:
        return {"mean": 0.0, "std": 0.0, "p5": 0.0, "p50": 0.0, "p95": 0.0}
    a = sorted(float(x) for x in arr)
    n = len(a)

    def q(prob: float) -> float:
        k = (n - 1) * prob
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return a[int(k)]
        return a[f] * (c - k) + a[c] * (k - f)

    return {
        "mean": statistics.fmean(a),
        "std": statistics.pstdev(a) if n > 1 else 0.0,
        "p5": q(0.05),
        "p50": q(0.50),
        "p95": q(0.95),
    }


# -----------------------------
# Helper clamp per delta percentuali
# -----------------------------
def _clamp_pct_key(key: str, value: float) -> float:
    """
    Applica clamp morbidi ai delta in percentuale per evitare code esplosive:
      - chiavi "*_pct" (incl. price_pct): [-80%, +200%]
    Altri delta (assoluti) non vengono clampati qui.
    """
    if key.endswith("_pct") or key == "price_pct":
        v = float(value)
        if v < -80.0:
            return -80.0
        if v > 200.0:
            return 200.0
        return v
    return float(value)


# -----------------------------
# Monte Carlo
# -----------------------------
def mc_scenarios(
    base: Dict[str, float],
    uncertainties: Dict[str, Dict[str, float]],
    n: int = 1000,
    *,
    seed: Optional[int] = None,
) -> Dict[str, Dict[str, float]]:
    """
    Esegue simulazioni Monte Carlo applicando incertezze su delta supportati da `simulate()`.

    Args:
        base:               stato base (fatturato, costi_*, investimenti, prezzo_medio, etc.)
        uncertainties:      mappa { chiave_delta -> { dist, ...parametri... } }
                            Esempi:
                                {"fatturato_pct": {"dist": "normal", "mu": 5, "sigma": 2}}
                                {"costi_variabili_pct": {"dist": "triangular", "a": 0, "b": 8, "c": 3}}
                                {"price_pct": {"dist": "uniform", "a": -5, "b": 5}, "price_elasticity": {"dist":"normal","mu":-1.2,"sigma":0.2}}
        n:                  numero di iterazioni (>=10)
        seed:               seed opzionale per run ripetibili

    Returns:
        Dizionario di statistiche su: utile, roi, fatturato, break_even.
        Nota: `roi` è coerente con i KPI (frazione 0..1).
    """
    # setup RNG
    if seed is not None:
        random.seed(int(seed))

    # build samplers
    samplers: Dict[str, Callable[[], float]] = {}
    for k, spec in (uncertainties or {}).items():
        dist = spec.get("dist", "normal")
        try:
            samplers[k] = _sampler(dist, spec)
        except Exception:
            # fallback deterministico: usa il parametro "mu" o 0.0
            mu = _get(spec, "mu", 0.0)
            samplers[k] = (lambda m=mu: m)

    n_iter = max(10, int(n or 0))

    utile_vals: List[float] = []
    roi_vals: List[float] = []
    fatt_vals: List[float] = []
    bep_vals: List[float] = []

    # loop
    for _ in range(n_iter):
        # sample i delta
        delta: Dict[str, float] = {}
        for key, sfun in samplers.items():
            try:
                v = float(sfun())
            except Exception:
                v = 0.0
            delta[key] = _clamp_pct_key(key, v)

        # esegui scenario
        res = simulate(base, delta)

        # raccogli variabili principali
        utile_vals.append(float(res.get("utile", 0.0)))
        roi_vals.append(float(res.get("roi", 0.0)))               # FRAZIONE 0..1 (coerente con KPI)
        fatt_vals.append(float(res.get("fatturato", 0.0)))
        bep_vals.append(float(res.get("break_even", 0.0)))

    return {
        "utile": summarize(utile_vals),
        "roi": summarize(roi_vals),
        "fatturato": summarize(fatt_vals),
        "break_even": summarize(bep_vals),
    }
