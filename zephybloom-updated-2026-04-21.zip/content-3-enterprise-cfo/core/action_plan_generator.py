"""
Action Plan Generator

Create 24h-7gg-30gg actionable plans.
"""

from typing import List
from dataclasses import dataclass


@dataclass
class Action:
    """Single action to take"""
    description: str
    timeframe: str  # "24h", "7gg", "30gg"
    priority: int  # 1=most urgent
    expected_outcome: str
    success_metric: str



class ActionPlanGenerator:
    """Generate step-by-step action plans"""
    
    def generate_margin_improvement_plan(
        self,
        current_margin: float,
        target_margin: float,
        company_revenue: float,
        primary_lever: str,  # "pricing", "cost_reduction", "mix_shift"
    ) -> dict:
        """
        Generate 24h-7gg-30gg plan to improve margin.
        """
        
        gap = target_margin - current_margin
        monthly_potential = (company_revenue / 12) * (gap / 100)
        
        plans = {
            "24_hours": [
                Action(
                    description="Analyze customer profitability - segment into tiers (A/B/C by margin)",
                    timeframe="24h",
                    priority=1,
                    expected_outcome="Understand which customers are profitable",
                    success_metric="Data extracted, segmentation complete",
                ),
                Action(
                    description="Calculate current margin by product/service line",
                    timeframe="24h",
                    priority=2,
                    expected_outcome="Identify low-margin lines",
                    success_metric="Line-by-line margin report ready",
                ),
            ],
            
            "7_days": [],
            
            "30_days": [],
        }
        
        # Pricing strategy
        if primary_lever == "pricing":
            plans["7_days"] = [
                Action(
                    description=f"Test price increase on top-margin customers (A tier)",
                    timeframe="7gg",
                    priority=1,
                    expected_outcome=f"Validate if 5-8% increase sticks",
                    success_metric="Customer response tracked, elasticity measured",
                ),
                Action(
                    description="Prepare new pricing model for announcement",
                    timeframe="7gg",
                    priority=2,
                    expected_outcome="Value narrative ready",
                    success_metric="Talking points documented",
                ),
            ]
            
            plans["30_days"] = [
                Action(
                    description=f"Roll out new pricing (target: +{gap}pp margin)",
                    timeframe="30gg",
                    priority=1,
                    expected_outcome=f"Margin improves to ~{target_margin}%",
                    success_metric=f"Actual margin hits {target_margin-2}%+ (conservative)",
                ),
                Action(
                    description="Monitor churn closely (watch for price sensitivity)",
                    timeframe="30gg",
                    priority=2,
                    expected_outcome="Early warning if margin gains come from customer loss",
                    success_metric="Churn <5% in month 1",
                ),
            ]
        
        # Cost reduction strategy
        elif primary_lever == "cost_reduction":
            plans["7_days"] = [
                Action(
                    description="Identify top 3 cost drivers (COGS, labor, overhead)",
                    timeframe="7gg",
                    priority=1,
                    expected_outcome="Know where money goes",
                    success_metric="Cost breakdown by category complete",
                ),
                Action(
                    description="Talk to ops - where are the inefficiencies?",
                    timeframe="7gg",
                    priority=2,
                    expected_outcome="Get on-the-ground perspective",
                    success_metric="Team input documented",
                ),
            ]
            
            plans["30_days"] = [
                Action(
                    description=f"Implement cost reductions (target: €{monthly_potential:,.0f}/month savings)",
                    timeframe="30gg",
                    priority=1,
                    expected_outcome="Margin improves through efficiency",
                    success_metric="Hit 60%+ of savings target",
                ),
                Action(
                    description="Verify cost reduction didn't impact quality",
                    timeframe="30gg",
                    priority=2,
                    expected_outcome="Margin gains are durable, not illusory",
                    success_metric="Customer satisfaction stays same or improves",
                ),
            ]
        
        # Product mix strategy
        else:  # mix_shift
            plans["7_days"] = [
                Action(
                    description="Identify high-margin products/services",
                    timeframe="7gg",
                    priority=1,
                    expected_outcome="Know what to push",
                    success_metric="Top 5 high-margin offerings listed",
                ),
                Action(
                    description="Assess sales capacity - can you sell more high-margin?",
                    timeframe="7gg",
                    priority=2,
                    expected_outcome="Understand constraints",
                    success_metric="Sales capacity vs demand gap quantified",
                ),
            ]
            
            plans["30_days"] = [
                Action(
                    description="Shift sales focus to high-margin offerings",
                    timeframe="30gg",
                    priority=1,
                    expected_outcome="Mix shifts toward profitability",
                    success_metric="High-margin % of revenue increases by 10pp",
                ),
                Action(
                    description="Gradually de-emphasize (or exit) low-margin options",
                    timeframe="30gg",
                    priority=2,
                    expected_outcome="Mix continues improving",
                    success_metric="Low-margin percentage decreases",
                ),
            ]
        
        return plans
    
    def generate_hiring_plan(
        self,
        hiring_verdict: str,  # "yes", "no", "maybe", "wait"
        delay_weeks: int = 0,
    ) -> dict:
        """Generate plan for hiring decision"""
        
        if hiring_verdict == "yes":
            return {
                "24_hours": [
                    Action(
                        description="Define exact role requirements and success criteria",
                        timeframe="24h",
                        priority=1,
                        expected_outcome="Clear JD",
                        success_metric="Role spec finalized",
                    ),
                    Action(
                        description="Identify recruitment channels",
                        timeframe="24h",
                        priority=2,
                        expected_outcome="Sourcing plan",
                        success_metric="3+ channels identified",
                    ),
                ],
                "7_days": [
                    Action(
                        description="Start recruitment",
                        timeframe="7gg",
                        priority=1,
                        expected_outcome="First candidates identified",
                        success_metric="5+ applications received",
                    ),
                ],
                "30_days": [
                    Action(
                        description="Hire and onboard",
                        timeframe="30gg",
                        priority=1,
                        expected_outcome="New team member productive",
                        success_metric="Day 1 complete, 30-day plan set",
                    ),
                ],
            }
        
        elif hiring_verdict == "wait":
            return {
                "24_hours": [
                    Action(
                        description="Document why we're waiting (margin, capacity, etc)",
                        timeframe="24h",
                        priority=1,
                        expected_outcome="Clear criteria for 'go' decision",
                        success_metric="Decision memo written",
                    ),
                ],
                "7_days": [
                    Action(
                        description=f"Revisit hiring decision in {delay_weeks} weeks",
                        timeframe="7gg",
                        priority=1,
                        expected_outcome="Calendar reminder set",
                        success_metric="Meeting scheduled",
                    ),
                ],
                "30_days": [
                    Action(
                        description="Monitor leading indicators (capacity util, margin, etc)",
                        timeframe="30gg",
                        priority=1,
                        expected_outcome="See if metrics hit targets",
                        success_metric="Metrics tracked, decision revisited",
                    ),
                ],
            }
        
        else:
            return {
                "24_hours": [
                    Action(
                        description="Explore alternatives (contractor, outsourcing, process improvement)",
                        timeframe="24h",
                        priority=1,
                        expected_outcome="Alternative solutions identified",
                        success_metric="3+ options evaluated",
                    ),
                ],
                "7_days": [
                    Action(
                        description="Implement alternative solution",
                        timeframe="7gg",
                        priority=1,
                        expected_outcome="Gap filled without headcount",
                        success_metric="Solution activated",
                    ),
                ],
                "30_days": [
                    Action(
                        description="Measure alternative solution effectiveness",
                        timeframe="30gg",
                        priority=1,
                        expected_outcome="Confirm if it's better than hiring",
                        success_metric="Metrics show improvement or cost savings",
                    ),
                ],
            }
    
    def generate_custom_plan(
        self,
        action_title: str,
        current_metrics: dict,
        priority: str = "MEDIUM",
    ) -> dict:
        """Generate custom action plan for specific action"""
        
        # Base actions applicable to all
        actions_24h = [
            Action(
                description=f"Analyze {action_title.lower()} in detail - identify specific lever",
                timeframe="24h",
                priority=1,
                expected_outcome="Clear understanding of what needs to happen",
                success_metric="Analysis document prepared",
            ),
        ]
        
        actions_7gg = [
            Action(
                description=f"Develop implementation plan for {action_title.lower()}",
                timeframe="7gg",
                priority=1,
                expected_outcome="Step-by-step roadmap ready",
                success_metric="Timeline and milestones set",
            ),
        ]
        
        actions_30gg = [
            Action(
                description=f"Monitor progress on {action_title.lower()} implementation",
                timeframe="30gg",
                priority=1,
                expected_outcome="Visible progress toward goal",
                success_metric="Measurable improvement in metrics",
            ),
        ]
        
        return {
            "24h_actions": actions_24h,
            "7gg_actions": actions_7gg,
            "30gg_actions": actions_30gg,
        }


def get_generator() -> ActionPlanGenerator:
    return ActionPlanGenerator()
