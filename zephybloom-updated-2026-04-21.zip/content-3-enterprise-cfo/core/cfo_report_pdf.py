"""Dependency-free PDF renderer for premium CFO reports."""

from typing import Any, Dict, List, Tuple


PAGE_W = 595
PAGE_H = 842
LEFT = 46
RIGHT = 46
TOP = 54
BOTTOM = 48


def render_monthly_report_pdf(report: Dict[str, Any]) -> bytes:
    """Render a CFO report into a board-style PDF without external packages."""

    elements = _build_elements(report)
    pages = _layout(elements)
    return _build_pdf(pages)


def _build_elements(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    sections = report.get("sections") or {}
    executive = sections.get("executive_summary") or {}
    ceo = sections.get("ceo_brief") or {}
    finance = sections.get("finance_brief") or {}
    snapshot = sections.get("financial_snapshot") or {}
    trend = sections.get("trend_memory") or {}
    war_room = sections.get("war_room") or {}
    decision_memory = sections.get("decision_memory") or {}
    data_quality = sections.get("data_quality") or {}

    company = report.get("company_name", "Azienda")
    period = report.get("period", "n/d")
    score = executive.get("score", 0)
    priority = war_room.get("priority_decision") or {}
    memory_summary = decision_memory.get("summary") or {}

    elements: List[Dict[str, Any]] = [
        {"type": "cover", "title": "Report CFO Mensile", "company": company, "period": period, "score": score},
        {"type": "section", "title": "Executive Summary"},
        {"type": "paragraph", "text": executive.get("headline", "")},
        {"type": "paragraph", "text": executive.get("diagnosis", "")},
        {"type": "callout", "label": "Messaggio board", "text": executive.get("board_message", "")},
        {"type": "section", "title": "Sintesi CEO"},
        {"type": "paragraph", "text": ceo.get("one_liner", "")},
        {"type": "callout", "label": "Azione entro 7 giorni", "text": ceo.get("action_7_days", "")},
        {"type": "paragraph", "text": f"Rischio principale: {ceo.get('main_risk', 'n/d')}"},
        {"type": "paragraph", "text": f"Decisione: {ceo.get('decision', 'n/d')}"},
        {"type": "section", "title": "Scorecard finanziaria"},
        {
            "type": "table",
            "headers": ["KPI", "Valore", "Lettura CFO"],
            "rows": [
                ["Fatturato", _eur(snapshot.get("revenue_eur")), "Dimensione economica del mese"],
                ["Utile netto", f"{_eur(snapshot.get('net_profit_eur'))} ({snapshot.get('net_margin_pct', 0)}%)", "Cassa potenziale e reinvestimento"],
                ["EBITDA", f"{_eur(snapshot.get('ebitda_eur'))} ({snapshot.get('ebitda_margin_pct', 0)}%)", "Forza operativa"],
                ["Margine lordo", f"{snapshot.get('gross_margin_pct', 0)}%", "Qualita' pricing/costi variabili"],
                ["ROI", f"{snapshot.get('roi_pct', 0)}%", "Rendimento capitale"],
            ],
        },
        {"type": "section", "title": "Decisioni da board"},
        {
            "type": "table",
            "headers": ["Decisione", "Raccomandazione", "Perche"],
            "rows": [
                [item.get("decision"), item.get("recommendation"), item.get("why")]
                for item in sections.get("board_decisions", [])
            ],
        },
        {"type": "section", "title": "War Room"},
        {"type": "callout", "label": "Decisione prioritaria", "text": priority.get("decision", "Nessuna priorita' ancora generata")},
        {"type": "paragraph", "text": f"Perche conta: {priority.get('why', 'n/d')}"},
        {"type": "paragraph", "text": f"Prossimo passo: {priority.get('next_step', 'n/d')}"},
        {"type": "section", "title": "Prossimi 30 giorni"},
        {
            "type": "table",
            "headers": ["#", "Azione", "Owner", "KPI"],
            "rows": [
                [item.get("priority"), item.get("action"), item.get("owner"), item.get("kpi")]
                for item in sections.get("next_30_days", [])
            ],
        },
        {"type": "section", "title": "Domande CFO al team"},
        {
            "type": "table",
            "headers": ["Owner", "Domanda", "Perche"],
            "rows": [
                [item.get("owner"), item.get("question"), item.get("why")]
                for item in sections.get("team_questions", [])
            ],
        },
        {"type": "section", "title": "Memoria decisioni"},
        {
            "type": "table",
            "headers": ["Stato", "Numero", "Nota"],
            "rows": [
                ["Aperte", memory_summary.get("open_decisions", 0), memory_summary.get("next_review", "n/d")],
                ["Completate", memory_summary.get("completed_decisions", 0), "Azioni misurate"],
                ["Archiviate", memory_summary.get("archived_decisions", 0), "Azioni chiuse senza impatto"],
                ["Impatto reale", _eur(memory_summary.get("actual_impact_eur")), "Risultato misurato"],
            ],
        },
        {"type": "section", "title": "Trend e memoria KPI"},
        {"type": "paragraph", "text": trend.get("executive_memory", "Storico KPI ancora limitato.")},
        {"type": "paragraph", "text": trend.get("trend_summary", "")},
        {
            "type": "bullets",
            "items": [f"Alert: {alert}" for alert in trend.get("alerts", [])[:5]]
            or ["Nessun alert storico critico."],
        },
        {"type": "section", "title": "Sintesi Finance"},
        {"type": "paragraph", "text": finance.get("decision_status", "")},
        {"type": "paragraph", "text": finance.get("memory_status", "")},
        {"type": "bullets", "items": finance.get("kpi_watchlist", []) or ["Nessun KPI critico."]},
        {"type": "section", "title": "Qualita dati"},
        {"type": "paragraph", "text": f"Readiness media: {data_quality.get('readiness_avg_pct', 0)}%. {data_quality.get('cfo_note', '')}"},
        {
            "type": "bullets",
            "items": [
                f"{gap.get('label', gap.get('sector', 'Dato'))}: {gap.get('field', '')}"
                for gap in data_quality.get("missing_items", [])[:8]
            ] or ["Nessun dato bloccante emerso nella War Room."],
        },
    ]
    return elements


def _layout(elements: List[Dict[str, Any]]) -> List[List[Tuple[str, Any]]]:
    pages: List[List[Tuple[str, Any]]] = [[]]
    y = PAGE_H - TOP

    def need(height: float) -> None:
        nonlocal y
        if y - height < BOTTOM:
            pages.append([])
            y = PAGE_H - TOP

    for element in elements:
        kind = element["type"]
        if kind == "cover":
            need(165)
            pages[-1].extend([
                ("rect", (LEFT, y - 118, PAGE_W - LEFT - RIGHT, 118, 0.94)),
                ("text", (LEFT + 18, y - 34, 24, element["title"])),
                ("text", (LEFT + 18, y - 62, 15, element["company"])),
                ("text", (LEFT + 18, y - 86, 11, f"Periodo: {element['period']} | Score report: {element['score']}/100")),
                ("line", (LEFT + 18, y - 100, PAGE_W - RIGHT - 18, y - 100)),
            ])
            y -= 140
        elif kind == "section":
            need(34)
            pages[-1].append(("section", (LEFT, y, element["title"])))
            y -= 32
        elif kind == "paragraph":
            lines = _wrap(str(element.get("text") or ""), 98)
            need(max(18, len(lines) * 13 + 8))
            for line in lines:
                pages[-1].append(("text", (LEFT, y, 10, line)))
                y -= 13
            y -= 8
        elif kind == "callout":
            lines = _wrap(f"{element.get('label')}: {element.get('text')}", 92)
            height = len(lines) * 13 + 20
            need(height)
            pages[-1].append(("rect", (LEFT, y - height + 8, PAGE_W - LEFT - RIGHT, height, 0.88)))
            cursor = y - 13
            for line in lines:
                pages[-1].append(("text", (LEFT + 12, cursor, 10, line)))
                cursor -= 13
            y -= height + 8
        elif kind == "table":
            headers = [str(item or "") for item in element.get("headers", [])]
            rows = [[str(cell or "") for cell in row] for row in element.get("rows", [])]
            for chunk in _table_chunks(headers, rows):
                height = 24 + len(chunk["rows"]) * 30 + 12
                need(height)
                pages[-1].extend(_table_ops(LEFT, y, PAGE_W - LEFT - RIGHT, chunk["headers"], chunk["rows"]))
                y -= height
        elif kind == "bullets":
            items = element.get("items", [])
            bullet_lines: List[str] = []
            for item in items:
                wrapped = _wrap(str(item), 92)
                bullet_lines.append(f"- {wrapped[0]}" if wrapped else "-")
                bullet_lines.extend(f"  {line}" for line in wrapped[1:])
            need(max(18, len(bullet_lines) * 13 + 8))
            for line in bullet_lines:
                pages[-1].append(("text", (LEFT, y, 10, line)))
                y -= 13
            y -= 8

    for index, page in enumerate(pages, start=1):
        page.append(("footer", (index, len(pages))))
    return pages


def _table_chunks(headers: List[str], rows: List[List[str]], rows_per_chunk: int = 8) -> List[Dict[str, Any]]:
    chunks = []
    for index in range(0, len(rows), rows_per_chunk):
        chunks.append({"headers": headers, "rows": rows[index:index + rows_per_chunk]})
    return chunks or [{"headers": headers, "rows": []}]


def _table_ops(x: float, y: float, width: float, headers: List[str], rows: List[List[str]]) -> List[Tuple[str, Any]]:
    ops: List[Tuple[str, Any]] = []
    cols = len(headers) or 1
    col_w = width / cols
    ops.append(("rect", (x, y - 22, width, 22, 0.9)))
    for index, header in enumerate(headers):
        ops.append(("text", (x + index * col_w + 6, y - 15, 9, header[:26])))
    cursor = y - 24
    for row in rows:
        ops.append(("rect", (x, cursor - 28, width, 28, 0.98)))
        for index, cell in enumerate(row[:cols]):
            text = _wrap(str(cell), max(14, int(col_w / 5.2)))[0] if str(cell) else ""
            ops.append(("text", (x + index * col_w + 6, cursor - 18, 8, text[:38])))
        cursor -= 30
    return ops


def _build_pdf(pages: List[List[Tuple[str, Any]]]) -> bytes:
    objects: List[bytes] = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    page_refs = " ".join(f"{3 + index * 2} 0 R" for index in range(len(pages)))
    objects.append(f"<< /Type /Pages /Kids [{page_refs}] /Count {len(pages)} >>".encode("ascii"))

    font_object_id = 3 + len(pages) * 2
    for index, ops in enumerate(pages):
        page_object_id = 3 + index * 2
        content_object_id = page_object_id + 1
        content = _page_content(ops)
        objects.append(
            (
                f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_W} {PAGE_H}] "
                f"/Resources << /Font << /F1 {font_object_id} 0 R >> >> "
                f"/Contents {content_object_id} 0 R >>"
            ).encode("ascii")
        )
        objects.append(f"<< /Length {len(content)} >>\nstream\n".encode("ascii") + content + b"\nendstream")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    return _assemble_pdf(objects)


def _page_content(ops: List[Tuple[str, Any]]) -> bytes:
    commands: List[str] = []
    for kind, args in ops:
        if kind == "text":
            x, y, size, text = args
            commands.append(f"BT /F1 {size} Tf {x:.1f} {y:.1f} Td ({_pdf_text(text)}) Tj ET")
        elif kind == "section":
            x, y, title = args
            commands.append(f"0.12 0.12 0.12 rg {x:.1f} {y - 5:.1f} {PAGE_W - LEFT - RIGHT:.1f} 1.2 re f")
            commands.append(f"BT /F1 13 Tf {x:.1f} {y + 5:.1f} Td ({_pdf_text(title)}) Tj ET")
        elif kind == "rect":
            x, y, w, h, shade = args
            commands.append(f"{shade:.2f} {shade:.2f} {shade:.2f} rg {x:.1f} {y:.1f} {w:.1f} {h:.1f} re f")
        elif kind == "line":
            x1, y1, x2, y2 = args
            commands.append(f"0.2 0.2 0.2 RG {x1:.1f} {y1:.1f} m {x2:.1f} {y2:.1f} l S")
        elif kind == "footer":
            page, total = args
            commands.append(f"0.2 0.2 0.2 RG {LEFT:.1f} 36 m {PAGE_W - RIGHT:.1f} 36 l S")
            commands.append(f"BT /F1 8 Tf {LEFT:.1f} 24 Td (CFO AI Report) Tj ET")
            commands.append(f"BT /F1 8 Tf {PAGE_W - RIGHT - 45:.1f} 24 Td (Pag. {page}/{total}) Tj ET")
    return "\n".join(commands).encode("latin-1", errors="replace")


def _assemble_pdf(objects: List[bytes]) -> bytes:
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for object_id, body in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf.extend(f"{object_id} 0 obj\n".encode("ascii"))
        pdf.extend(body)
        pdf.extend(b"\nendobj\n")
    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    pdf.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    pdf.extend(
        (
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        ).encode("ascii")
    )
    return bytes(pdf)


def _wrap(text: str, width: int) -> List[str]:
    text = str(text or "").replace("\n", " ").strip()
    if not text:
        return []
    lines: List[str] = []
    while len(text) > width:
        cut = text.rfind(" ", 0, width)
        if cut <= 0:
            cut = width
        lines.append(text[:cut].strip())
        text = text[cut:].strip()
    lines.append(text)
    return lines


def _pdf_text(value: Any) -> str:
    text = str(value or "").encode("latin-1", errors="replace").decode("latin-1")
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _eur(value: Any) -> str:
    return f"EUR {float(value or 0):,.0f}".replace(",", ".")
