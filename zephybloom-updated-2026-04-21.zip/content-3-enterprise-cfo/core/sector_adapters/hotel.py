"""Hotel business model adapter."""

from core.business_model_schema import DataField, SectorAdapterSpec
from core.sector_adapters.base import COMMON_OPTIONAL_FIELDS, COMMON_REQUIRED_FIELDS


HOTEL_SPEC = SectorAdapterSpec(
    sector="hotel",
    name="Hotel",
    description="Legge occupazione, ADR, RevPAR, OTA, housekeeping, stagionalita' e GOPPAR.",
    required_fields=COMMON_REQUIRED_FIELDS + [
        DataField("available_rooms", "Camere disponibili", "capacita", "Serve per occupazione, RevPAR e break-even.", "42", "rooms"),
        DataField("occupancy_rate_pct", "Tasso occupazione", "ricavi", "Serve per leggere saturazione e potenziale prezzo.", "71", "%"),
        DataField("average_daily_rate", "ADR", "ricavi", "Serve per collegare prezzo, posizionamento e ricavi camera.", "118", "EUR"),
        DataField("ota_commissions_pct", "Commissioni OTA", "canali", "Serve per capire margine per canale.", "18", "%"),
        DataField("housekeeping_cost_per_room", "Costo pulizia per camera", "operazioni", "Serve per margine operativo camera.", "14", "EUR"),
        DataField("staff_roles", "Personale per ruolo e costo", "personale", "Serve per labour cost e servizio per camera occupata.", "reception, housekeeping, F&B"),
    ],
    optional_fields=COMMON_OPTIONAL_FIELDS + [
        DataField("seasonality_by_month", "Stagionalita' mensile", "ricavi", "Serve per pricing dinamico e cash planning.", "agosto 92%, gennaio 38%"),
        DataField("ancillary_revenue_per_guest", "Ricavi extra per ospite", "ricavi", "Serve per upsell e GOPPAR.", "22", "EUR"),
    ],
    key_kpis=["occupancy_rate_pct", "adr", "revpar", "goppar", "direct_booking_share", "housekeeping_cost_per_occupied_room"],
    decision_rules=[
        "Non ottimizzare solo occupazione: prezzo medio e canale possono valere piu' dei pieni.",
        "OTA utili per riempire, ma la crescita sana aumenta quota diretta e margine.",
        "Stagionalita' va gestita con pricing, personale flessibile e cash reserve.",
    ],
    simulation_templates=["+5% ADR", "+10 punti booking diretto", "-3 punti OTA", "+8% occupazione bassa stagione"],
    supported_questions=[
        "Meglio aumentare prezzo o occupazione?",
        "Quanto mi costano le OTA?",
        "Qual e' il mio break-even di camere occupate?",
        "Dove posso aumentare ricavi extra?",
    ],
)
