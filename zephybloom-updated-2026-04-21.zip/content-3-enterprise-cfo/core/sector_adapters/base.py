"""Universal sector adapter registry."""

from typing import Dict

from core.business_model_schema import DataField, SectorAdapterSpec


COMMON_REQUIRED_FIELDS = [
    DataField(
        key="annual_revenue",
        label="Fatturato annuo",
        category="ricavi",
        why_needed="Serve come base per margini, break-even, crescita e sostenibilita'.",
        example="1000000",
        unit="EUR",
    ),
    DataField(
        key="variable_costs",
        label="Costi variabili annui",
        category="costi",
        why_needed="Serve per calcolare margine lordo e capire se la crescita crea utile.",
        example="400000",
        unit="EUR",
    ),
    DataField(
        key="fixed_costs",
        label="Costi fissi annui",
        category="costi",
        why_needed="Serve per capire break-even, leva operativa e rischio di struttura.",
        example="300000",
        unit="EUR",
    ),
    DataField(
        key="invested_capital",
        label="Capitale investito",
        category="capitale",
        why_needed="Serve per calcolare ROI e qualita' del capitale impiegato.",
        example="100000",
        unit="EUR",
    ),
]


COMMON_OPTIONAL_FIELDS = [
    DataField(
        key="cash_on_hand",
        label="Liquidita' disponibile",
        category="cassa",
        why_needed="Serve per capire autonomia, rischio e capacita' di investimento.",
        example="75000",
        unit="EUR",
    ),
    DataField(
        key="payment_terms_days",
        label="Giorni medi di incasso e pagamento",
        category="cassa",
        why_needed="Serve per leggere il cash conversion cycle, non solo l'utile.",
        example="incasso 30, pagamento 60",
        unit="days",
    ),
    DataField(
        key="staff_roles",
        label="Ruoli, costo e numero persone",
        category="personale",
        why_needed="Serve per capire se il personale scala con ricavi, qualita' e capacita'.",
        example="2 sales x 35000, 1 operations x 42000",
    ),
    DataField(
        key="sales_channels",
        label="Canali di vendita",
        category="vendite",
        why_needed="Serve per capire quali canali portano fatturato profittevole.",
        example="negozio, online, referral, agenti",
    ),
]


DEFAULT_SECTOR_SPEC = SectorAdapterSpec(
    sector="default",
    name="Azienda generica",
    description="Schema universale per leggere ricavi, costi, cassa e capitale.",
    required_fields=COMMON_REQUIRED_FIELDS,
    optional_fields=COMMON_OPTIONAL_FIELDS,
    key_kpis=[
        "gross_margin_pct",
        "ebitda_margin_pct",
        "net_margin_pct",
        "roi_pct",
        "break_even_revenue",
        "cash_runway_months",
    ],
    decision_rules=[
        "Non spingere crescita se il margine netto scende sotto la soglia target.",
        "Separare ricavi sani da ricavi tossici: volume senza margine non e' crescita.",
        "Ogni investimento deve avere ROI atteso, tempo di rientro e impatto sulla cassa.",
    ],
    simulation_templates=[
        "+5% prezzo",
        "+10% volume",
        "-5% costi variabili",
        "+1 ruolo operativo",
        "ritardo incassi +15 giorni",
    ],
    supported_questions=[
        "Quanto utile mi rimane?",
        "Dove perdo margine?",
        "Quanto posso investire senza stressare la cassa?",
        "Quale scenario migliora di piu' il ROI?",
    ],
)


def _build_registry() -> Dict[str, SectorAdapterSpec]:
    from core.sector_adapters.construction import CONSTRUCTION_SPEC
    from core.sector_adapters.ecommerce import ECOMMERCE_SPEC
    from core.sector_adapters.hotel import HOTEL_SPEC
    from core.sector_adapters.restaurant import RESTAURANT_SPEC

    specs = [
        DEFAULT_SECTOR_SPEC,
        RESTAURANT_SPEC,
        ECOMMERCE_SPEC,
        HOTEL_SPEC,
        CONSTRUCTION_SPEC,
    ]
    registry = {spec.sector: spec for spec in specs}
    registry.update({
        "ristorante": RESTAURANT_SPEC,
        "ristoranti": RESTAURANT_SPEC,
        "restaurant": RESTAURANT_SPEC,
        "e-commerce": ECOMMERCE_SPEC,
        "online_store": ECOMMERCE_SPEC,
        "albergo": HOTEL_SPEC,
        "hotels": HOTEL_SPEC,
        "costruzioni": CONSTRUCTION_SPEC,
        "construction": CONSTRUCTION_SPEC,
        "edilizia": CONSTRUCTION_SPEC,
    })
    return registry


def get_sector_spec(sector: str) -> SectorAdapterSpec:
    registry = _build_registry()
    normalized = (sector or "default").strip().lower().replace(" ", "_")
    return registry.get(normalized, DEFAULT_SECTOR_SPEC)
