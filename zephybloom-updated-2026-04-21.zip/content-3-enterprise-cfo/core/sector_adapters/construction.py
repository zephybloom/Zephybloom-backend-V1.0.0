"""Construction business model adapter."""

from core.business_model_schema import DataField, SectorAdapterSpec
from core.sector_adapters.base import COMMON_OPTIONAL_FIELDS, COMMON_REQUIRED_FIELDS


CONSTRUCTION_SPEC = SectorAdapterSpec(
    sector="construction",
    name="Costruzioni",
    description="Legge margine per commessa, materiali, manodopera, subappalti, SAL e cassa.",
    required_fields=COMMON_REQUIRED_FIELDS + [
        DataField("projects", "Commesse attive", "commesse", "Serve per leggere margine, rischio e cassa per progetto.", "cantiere A: valore 240000"),
        DataField("materials_cost_by_project", "Materiali per commessa", "costi", "Serve per margine industriale e rischio rincari.", "cantiere A: 82000 EUR"),
        DataField("labor_cost_by_project", "Manodopera per commessa", "personale", "Serve per capire costo reale e saturazione squadre.", "cantiere A: 46000 EUR"),
        DataField("subcontractor_costs", "Subappalti", "costi", "Serve per margine e rischio dipendenza esterna.", "impianti: 28000 EUR"),
        DataField("project_progress_pct", "Avanzamento lavori", "commesse", "Serve per SAL, cash flow e rischio ritardi.", "65", "%"),
        DataField("payment_milestones", "SAL e scadenze incasso", "cassa", "Serve per evitare utile contabile senza cassa.", "30%-40%-30%"),
    ],
    optional_fields=COMMON_OPTIONAL_FIELDS + [
        DataField("delay_penalties", "Penali ritardo", "rischio", "Serve per stimare margine a rischio.", "0.5% a settimana"),
        DataField("change_orders", "Varianti approvate/non approvate", "ricavi", "Serve per recuperare margine non fatturato.", "variante extra 12000 EUR"),
    ],
    key_kpis=["gross_margin_by_project", "wip", "cash_gap_by_project", "labor_productivity", "change_order_recovery"],
    decision_rules=[
        "Ogni commessa va letta separando margine previsto, margine consuntivo e cassa.",
        "Crescere con piu' cantieri puo' peggiorare la cassa se SAL e fornitori non sono allineati.",
        "Varianti non approvate e ritardi sono spesso margine perso prima ancora della contabilita'.",
    ],
    simulation_templates=["+10% costo materiali", "ritardo incasso SAL 30 giorni", "+5% variante approvata", "+1 squadra esterna"],
    supported_questions=[
        "Quale commessa mi sta mangiando margine?",
        "Quanto capitale mi serve per aprire un nuovo cantiere?",
        "Dove rischio di restare senza cassa?",
        "Conviene internalizzare o subappaltare?",
    ],
)
