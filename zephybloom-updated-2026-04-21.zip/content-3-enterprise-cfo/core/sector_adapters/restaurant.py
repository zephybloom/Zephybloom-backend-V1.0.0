"""Restaurant business model adapter."""

from core.business_model_schema import DataField, SectorAdapterSpec
from core.sector_adapters.base import COMMON_OPTIONAL_FIELDS, COMMON_REQUIRED_FIELDS


RESTAURANT_SPEC = SectorAdapterSpec(
    sector="restaurant",
    name="Ristorante",
    description="Legge food cost, personale, coperti, menu engineering, break-even e prezzo target.",
    required_fields=COMMON_REQUIRED_FIELDS + [
        DataField(
            key="opening_days_per_month",
            label="Giorni di apertura al mese",
            category="capacita",
            why_needed="Serve per calcolare coperti medi, break-even giornaliero e sostenibilita' turni.",
            example="26",
            unit="days",
        ),
        DataField(
            key="average_daily_covers",
            label="Coperti medi giornalieri",
            category="capacita",
            why_needed="Serve per capire volume reale e saturazione del locale.",
            example="85",
            unit="covers",
        ),
        DataField(
            key="average_ticket",
            label="Scontrino medio",
            category="ricavi",
            why_needed="Serve per collegare fatturato a prezzo, mix menu e numero coperti.",
            example="38",
            unit="EUR",
        ),
        DataField(
            key="menu_items",
            label="Piatti/prodotti venduti con prezzo e quantita'",
            category="prodotti",
            why_needed="Serve per capire quali piatti creano margine, traffico o perdita.",
            example="pizza margherita: prezzo 9, vendite 1200/mese",
        ),
        DataField(
            key="ingredient_costs",
            label="Ingredienti/merce acquistata con costo unitario",
            category="acquisti",
            why_needed="Serve per calcolare food cost reale e prezzo minimo di vendita per margine target.",
            example="mozzarella 6 EUR/kg, farina 1.2 EUR/kg",
        ),
        DataField(
            key="recipe_quantities",
            label="Quantita' ingredienti per ricetta",
            category="prodotti",
            why_needed="Serve per calcolare costo unitario per piatto invece di stimare a percentuale.",
            example="margherita: 120g mozzarella, 180g impasto",
        ),
        DataField(
            key="staff_roles",
            label="Personale per ruolo, costo e ore",
            category="personale",
            why_needed="Serve per calcolare labour cost, prime cost e costo per coperto.",
            example="2 cuochi x 2400/mese, 3 sala x 1600/mese",
        ),
    ],
    optional_fields=COMMON_OPTIONAL_FIELDS + [
        DataField(
            key="waste_pct",
            label="Scarto/spreco medio",
            category="acquisti",
            why_needed="Serve per capire margine perso su invenduto, preparazioni e porzioni.",
            example="4",
            unit="%",
        ),
        DataField(
            key="delivery_commissions_pct",
            label="Commissioni delivery",
            category="canali",
            why_needed="Serve per capire se il delivery porta utile o solo fatturato.",
            example="28",
            unit="%",
        ),
        DataField(
            key="rent_monthly",
            label="Affitto mensile",
            category="costi_fissi",
            why_needed="Serve per calcolare break-even e costo struttura per coperto.",
            example="4500",
            unit="EUR/month",
        ),
    ],
    key_kpis=[
        "food_cost_pct",
        "labour_cost_pct",
        "prime_cost_pct",
        "contribution_margin_per_dish",
        "break_even_covers_per_day",
        "revenue_per_cover",
        "recommended_price_for_target_margin",
    ],
    decision_rules=[
        "Un piatto non va spinto solo per margine: conta anche volume, ruolo nel menu e capacita' di attirare clienti.",
        "Se prime cost supera la soglia target, prima correggere menu mix, porzioni, sprechi e turni.",
        "Delivery va separato dal consumo in sala: commissioni e packaging possono trasformare fatturato in perdita.",
        "Il prezzo consigliato va calcolato da costo ricetta, margine target, IVA/commissioni e posizionamento.",
    ],
    simulation_templates=[
        "+5% prezzo su piatti ad alta domanda",
        "-3% costo ingredienti tramite fornitori alternativi",
        "-2% spreco alimentare",
        "+10 coperti al giorno",
        "delivery con commissione 28%",
    ],
    supported_questions=[
        "Quali piatti mi fanno guadagnare davvero?",
        "A che prezzo devo vendere questo piatto per avere il margine target?",
        "Quanti coperti devo fare per coprire i costi?",
        "Quanto pesa il personale sul fatturato?",
        "Il delivery mi conviene?",
    ],
)
