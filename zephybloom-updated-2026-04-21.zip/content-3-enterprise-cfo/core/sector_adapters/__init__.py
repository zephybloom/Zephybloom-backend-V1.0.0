"""Sector adapters for the CFO data foundation."""

from core.sector_adapters.base import DEFAULT_SECTOR_SPEC, get_sector_spec

__all__ = ["DEFAULT_SECTOR_SPEC", "get_sector_spec"]
