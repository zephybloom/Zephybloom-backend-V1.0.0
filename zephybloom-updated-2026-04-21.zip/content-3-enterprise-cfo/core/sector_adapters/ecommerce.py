"""Ecommerce business model adapter."""

from core.business_model_schema import DataField, SectorAdapterSpec
from core.sector_adapters.base import COMMON_OPTIONAL_FIELDS, COMMON_REQUIRED_FIELDS


ECOMMERCE_SPEC = SectorAdapterSpec(
    sector="ecommerce",
    name="Ecommerce",
    description="Legge SKU margin, CAC, AOV, ritorni, stock, ROAS e marginalita' per canale.",
    required_fields=COMMON_REQUIRED_FIELDS + [
        DataField("sku_sales", "Vendite per SKU", "prodotti", "Serve per capire margine e volume per prodotto.", "SKU A: 500 unita/mese"),
        DataField("sku_purchase_costs", "Costo acquisto per SKU", "acquisti", "Serve per calcolare margine unitario reale.", "SKU A: 18 EUR"),
        DataField("average_order_value", "Valore medio ordine", "ricavi", "Serve per leggere economia ordine e soglia spedizione.", "72", "EUR"),
        DataField("customer_acquisition_cost", "CAC per canale", "marketing", "Serve per capire se la crescita comprata e' profittevole.", "Meta Ads: 24 EUR"),
        DataField("return_rate_pct", "Tasso resi", "operazioni", "Serve per correggere margine e cash flow.", "8", "%"),
        DataField("shipping_cost_per_order", "Costo spedizione per ordine", "operazioni", "Serve per calcolare margine netto ordine.", "6.5", "EUR"),
    ],
    optional_fields=COMMON_OPTIONAL_FIELDS + [
        DataField("conversion_rate_pct", "Conversion rate", "marketing", "Serve per capire se scalare traffico o migliorare funnel.", "2.1", "%"),
        DataField("inventory_days", "Giorni medi stock", "magazzino", "Serve per leggere capitale bloccato e rischio invenduto.", "65", "days"),
        DataField("payment_fees_pct", "Commissioni pagamento", "costi", "Serve per margine netto ordine.", "1.8", "%"),
    ],
    key_kpis=["contribution_margin_per_order", "cac_payback", "roas", "return_adjusted_margin", "inventory_turnover"],
    decision_rules=[
        "Scalare advertising solo dove margine post-resi e CAC stanno in piedi.",
        "SKU con alto fatturato ma margine basso vanno riprezzati, bundleizzati o ridotti.",
        "Stock lento consuma cassa anche quando il conto economico sembra sano.",
    ],
    simulation_templates=["+10% AOV", "-2% resi", "+15% CAC", "+5% prezzo SKU top", "-10 giorni stock"],
    supported_questions=[
        "Quali SKU devo spingere?",
        "Quale canale marketing mi conviene?",
        "Quanto posso spendere per acquisire un cliente?",
        "I resi mi stanno mangiando margine?",
    ],
)
