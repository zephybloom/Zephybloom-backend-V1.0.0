# -*- coding: utf-8 -*-
# content/core/validators.py — Shim robusto: re-export dal modulo centralizzato
from __future__ import annotations

"""
Layer di compatibilità per i validator numerici.

Obiettivo:
- mantenere invariata l'API storica di `content.core.validators`
- delegare la logica vera a `content.utils.validators`
- evitare rotture nei moduli legacy che importano da qui
"""

from typing import Any, Dict

# ============================================================
# Import centralizzato
# ============================================================
try:
    from utils.validators import (
        normalize_context_numeric,
        clamp_rate01,
        clamp_pct100,
        clamp_nonneg,
        validate_kpi_invariants,
        PERCENT_KEYS,
        FRACTION_RATE_KEYS,
    )
except Exception as e:  # pragma: no cover
    raise ImportError(
        "Impossibile importare content.utils.validators da content.core.validators"
    ) from e


# ============================================================
# Alias legacy / compat
# ============================================================
def normalize_numeric_context(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Alias legacy di normalize_context_numeric.
    """
    return normalize_context_numeric(data)


def validate_numeric_context(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Alias semantico legacy: normalizza il context numerico.
    """
    return normalize_context_numeric(data)


def clamp_rate(v: float) -> float:
    """
    Alias legacy di clamp_rate01.
    """
    return clamp_rate01(v)


def clamp_pct(v: float) -> float:
    """
    Alias legacy di clamp_pct100.
    """
    return clamp_pct100(v)


# ============================================================
# API pubblica
# ============================================================
__all__ = [
    # export principali
    "normalize_context_numeric",
    "clamp_rate01",
    "clamp_pct100",
    "clamp_nonneg",
    "validate_kpi_invariants",
    "PERCENT_KEYS",
    "FRACTION_RATE_KEYS",
    # alias legacy
    "normalize_numeric_context",
    "validate_numeric_context",
    "clamp_rate",
    "clamp_pct",
]