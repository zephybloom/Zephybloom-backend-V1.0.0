"""
Human Value Calculator

Calculate the true ROI of hiring specific people.
"""

from typing import Dict, Optional, Any
from dataclasses import dataclass
from enum import Enum


class HireVerdict(str, Enum):
    """Hiring recommendation"""
    YES = "yes"
    MAYBE = "maybe"
    NO = "no"
    WAIT = "wait"


@dataclass
class HireThreshold:
    """Thresholds for a specific hire"""
    minimum_revenue_generation: float  # EUR/year needed
    breakeven_months: int
    cash_impact_negative_peak: float  # EUR needed to cover
    roi_minimum: float  # ROI % threshold
    recommendation: HireVerdict


class HumanValueCalculator:
    """Calculate hiring ROI"""
    
    def calculate(
        self,
        role: str,
        salary: float,
        company_revenue: float,
        company_margin: float,
        growth_phase: str = "growth",  # "early", "growth", "mature"
        is_critical_function: bool = False,
    ) -> HireThreshold:
        """
        Calculate true value of a hire.
        
        Args:
            role: Job title
            salary: Annual salary EUR
            company_revenue: Annual revenue EUR
            company_margin: Profit margin %
            growth_phase: Company phase
            is_critical_function: Is this a critical role?
        
        Returns:
            Thresholds for hiring decision
        """
        
        # Real fully-loaded cost
        overhead = 0.30  # 30% overhead (benefits, space, systems, training)
        fully_loaded_cost = salary * (1 + overhead)
        
        # Industry role multipliers
        role_multipliers = {
            "sales": 4.0,           # Sales should generate 4x their cost
            "engineer": 5.0,        # Engineers should generate 5x
            "product": 3.5,
            "operations": 2.0,
            "management": 1.5,
            "default": 2.5,
        }
        
        multiplier = role_multipliers.get(role.lower(), role_multipliers["default"])
        
        # Minimum revenue they need to generate (to cover their cost + margin)
        minimum_revenue = fully_loaded_cost / (company_margin / 100) if company_margin > 0 else fully_loaded_cost * 5
        
        # Realistic revenue (account for ramp-up)
        # First 2 months: 30% productivity
        # Months 3-4: 70% productivity
        # Month 5+: 100% productivity
        ramp_adjusted = minimum_revenue * 0.9  # Assume 90% of full revenue potential in realistic
        
        # Break-even month
        monthly_cost = fully_loaded_cost / 12
        monthly_profit = ramp_adjusted / 12 * company_margin / 100
        if monthly_profit > 0:
            breakeven_months = int(fully_loaded_cost / monthly_profit)
        else:
            breakeven_months = 999
        
        # Cash impact (peak negative)
        # Worst case: full cost for 6 months, slow ramp
        cash_impact = fully_loaded_cost * 1.5
        
        # ROI minimum for decision
        roi_minimum = 100 if growth_phase == "mature" else 150 if growth_phase == "growth" else 200
        
        # Verdict logic
        if company_margin < 15:
            verdict = HireVerdict.WAIT
            # "Margin too fragile for new fixed costs"
        elif breakeven_months > 18:
            verdict = HireVerdict.NO
            # "Payback too long"
        elif is_critical_function and breakeven_months < 12:
            verdict = HireVerdict.YES
            # "Critical function, good payback"
        elif breakeven_months < 12:
            verdict = HireVerdict.MAYBE
            # "OK payback, but watch cash"
        else:
            verdict = HireVerdict.WAIT
        
        return HireThreshold(
            minimum_revenue_generation=minimum_revenue,
            breakeven_months=breakeven_months,
            cash_impact_negative_peak=cash_impact,
            roi_minimum=roi_minimum,
            recommendation=verdict,
        )
    
    def calculate_team_impact(
        self,
        team_size: int,
        average_salary: float,
        team_role: str,
        company_revenue: float,
        company_margin: float,
    ) -> Dict[str, Any]:
        """
        Calculate impact of entire team.
        """
        
        team_cost = team_size * average_salary * 1.3
        team_cost_pct = (team_cost / company_revenue) * 100
        
        # Ideal ratio depends on role
        ideal_ratios = {
            "engineering": {"min": 8, "max": 15},   # 8-15% of revenue
            "sales": {"min": 5, "max": 10},
            "operations": {"min": 10, "max": 20},
            "default": {"min": 10, "max": 20},
        }
        
        ideal_min, ideal_max = ideal_ratios.get(team_role.lower(), ideal_ratios["default"]).values()
        
        status = "healthy"
        if team_cost_pct < ideal_min:
            status = "understaffed"
        elif team_cost_pct > ideal_max:
            status = "overstaffed"
        
        return {
            "team_size": team_size,
            "total_cost": team_cost,
            "pct_of_revenue": team_cost_pct,
            "status": status,
            "ideal_range": f"{ideal_min}%-{ideal_max}%",
            "recommendation": self._team_recommendation(team_cost_pct, ideal_min, ideal_max),
        }
    
    def _team_recommendation(self, pct: float, min_: float, max_: float) -> str:
        if pct < min_:
            return f"Hire more - you're {min_ - pct:.1f}pp below ideal"
        elif pct > max_:
            return f"Consider reduction - you're {pct - max_:.1f}pp above ideal"
        else:
            return "Team size is healthy"


def get_calculator() -> HumanValueCalculator:
    return HumanValueCalculator()
