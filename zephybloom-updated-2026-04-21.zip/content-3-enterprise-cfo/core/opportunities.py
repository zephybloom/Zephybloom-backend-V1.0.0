# content/advice/opportunities.py
from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass

# Import tollerante: usa i tuoi validator (core) o, se li sposti, quelli in utils
try:
    from core.validators import normalize_context_numeric  # alias/%, k-mln-mld
except Exception:  # pragma: no cover
    from utils.validators import normalize_context_numeric

# Per coerenza con il motore KPI (CCC/WC)
try:
    from core.kpi_engine import compute_ccc_and_wc
except Exception:  # pragma: no cover
    # fallback minimo, identico alla formula del motore
    def compute_ccc_and_wc(sales: float, cogs: float, dso: float, dio: float, dpo: float,
                           *, days_in_year: int = 365, wc_on_sales_share: float = 1.0, wc_on_cogs_share: float = 1.0):
        dso = max(0.0, float(dso or 0.0))
        dio = max(0.0, float(dio or 0.0))
        dpo = max(0.0, float(dpo or 0.0))
        ccc = dso + dio - dpo
        sales_day = sales / float(days_in_year) if sales > 0 else 0.0
        cogs_day = cogs / float(days_in_year) if cogs > 0 else 0.0
        wc_need = (
            wc_on_sales_share * sales_day * dso
            + wc_on_cogs_share * cogs_day * dio
            - wc_on_cogs_share * cogs_day * dpo
        )
        return ccc, max(0.0, wc_need)

# ----------------- helpers -----------------
def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        return 0.0 if (v != v) else v  # NaN → 0.0
    except Exception:
        return default

def _clamp_nonneg(x: float) -> float:
    return x if x >= 0.0 else 0.0

def _isoelastic_q(q0: float, p0: float, p: float, eps: float) -> float:
    """Q = Q0 * (p/p0)^ε, con guard-rail p0<=0 → ritorna q0; min 0."""
    if p0 <= 0 or q0 < 0:
        return max(0.0, q0)
    return max(0.0, q0 * ((p / p0) ** eps))

def _safe_roi(delta_profit: float, invest: float) -> float:
    if invest and invest > 0:
        return (delta_profit / invest) * 100.0
    return 0.0

def _round2(x: float) -> float:
    return round(float(x or 0.0), 2)

# ----------------- modelli -----------------
@dataclass
class Opportunity:
    code: str
    title: str
    delta_profit: float
    delta_roi_pct: float
    steps: List[str]

# ----------------- engine -----------------
class OpportunityEngine:
    def __init__(self, sector: str | None = None):
        self.sector = (sector or "").lower().strip()

    def generate(self, base: Dict[str, Any], elasticity: float = -1.2) -> List[Opportunity]:
        """
        Genera un set di opportunità standardizzate su:
        - Prezzo +1% (isoelastica)
        - CV -2%
        - CF -5%
        - CCC -15gg (impatto su cassa, non su utile) calcolato con la formula del motore KPI
        """
        # 1) normalizza input (alias chiave, %, k/mln/mld, frazioni)
        b = normalize_context_numeric(base or {})

        # 2) basi economiche
        rev = _clamp_nonneg(_asf(b.get("fatturato") or b.get("sales")))
        cv  = _clamp_nonneg(_asf(b.get("costi_variabili") or b.get("cogs")))
        cf  = _clamp_nonneg(_asf(b.get("costi_fissi")))
        invest = _clamp_nonneg(_asf(b.get("investimenti")))
        p0  = _clamp_nonneg(_asf(b.get("prezzo_medio")))
        cvu = _clamp_nonneg(_asf(b.get("costo_variabile_unitario")))

        # 3) utile base (semplice, coerente con la tua versione)
        utile0 = max(0.0, rev - cv - cf)

        out: List[Opportunity] = []

        # ---- (1) Prezzo +1% (isoelastica) ----
        # Preconditions: prezzo>0, ricavi>0, CVU definito e < prezzo finale
        if p0 > 0.0 and rev > 0.0 and cvu >= 0.0:
            q0 = rev / max(p0, 1e-9)
            p1 = p0 * 1.01
            if p1 > cvu:  # BE raggiungibile
                q1 = _isoelastic_q(q0, p0, p1, elasticity)
                profit1 = q1 * (p1 - cvu) - cf  # (ricavi - CV) - CF
                delta = max(0.0, profit1 - utile0)
                out.append(Opportunity(
                    code="PRICE_UP_1",
                    title="Aumenta prezzo medio dell’1%",
                    delta_profit=_round2(delta),
                    delta_roi_pct=_round2(_safe_roi(delta, invest)),
                    steps=["Segmenta clienti", "AB test listino", "Roll-out graduale"]
                ))

        # ---- (2) CV -2% ----
        if cv > 0.0:
            benefit = 0.02 * cv  # riduzione costi = beneficio su utile
            benefit = max(0.0, benefit)
            out.append(Opportunity(
                code="CVAR_DOWN_2",
                title="Riduci costi variabili del 2%",
                delta_profit=_round2(benefit),
                delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                steps=["RFP fornitori", "Standardizza processi", "Controllo scarti"]
            ))

        # ---- (3) CF -5% ----
        if cf > 0.0:
            benefit = 0.05 * cf
            benefit = max(0.0, benefit)
            out.append(Opportunity(
                code="CFIX_DOWN_5",
                title="Taglia costi fissi del 5%",
                delta_profit=_round2(benefit),
                delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                steps=["Audit CF", "Rinegozia contratti", "Ottimizza turni"]
            ))

        # ---- (4) CCC -15 giorni (cassa, non utile) ----
        # Calcolo coerente con il motore KPI:
        #   wc_need ≈ sales_day*DSO + cogs_day*DIO − cogs_day*DPO
        dso = _clamp_nonneg(_asf(b.get("dso")))
        dio = _clamp_nonneg(_asf(b.get("dio")))
        dpo = _clamp_nonneg(_asf(b.get("dpo")))
        if (dso + dio + dpo) > 0.0:
            ccc0, wc0 = compute_ccc_and_wc(rev, cv, dso, dio, dpo)
            # Applichiamo un miglioramento lato incassi: DSO -15 (≥0)
            dso1 = max(0.0, dso - 15.0)
            ccc1, wc1 = compute_ccc_and_wc(rev, cv, dso1, dio, dpo)
            delta_cash = max(0.0, wc0 - wc1)  # cassa liberata
            # Nota: delta_profit resta 0.0 per coerenza (impatto di cassa, non P&L)
            out.append(Opportunity(
                code="CCC_DOWN_15",
                title="Riduci ciclo cassa (CCC) di 15 giorni",
                delta_profit=0.0,
                delta_roi_pct=0.0,
                steps=["Sconti incasso anticipato", "Kanban top SKU", "Estendi DPO se sostenibile"]
            ))
            # Potresti voler riportare delta_cash da qualche parte; qui manteniamo la tua API.
            # Se serve, puoi esporlo a livello rotta come meta.

        # Ordina per impatto profitto decrescente
        out.sort(key=lambda o: o.delta_profit, reverse=True)
        return out

# ----------------- formatter -----------------
def format_opportunity(o: Opportunity) -> str:
    return (
        f"{o.title} — ΔUtile atteso € {o.delta_profit:,.0f}, ΔROI {o.delta_roi_pct:.1f}% | "
        f"Passi: { '; '.join(o.steps) }"
    )
