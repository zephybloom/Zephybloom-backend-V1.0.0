"""
Entrepreneur Profiler - Infer entrepreneur characteristics from company metrics

Generates dynamic profile based on:
- Growth trajectory
- Financial health
- Risk tolerance (inferred)
- Decision-making style
- Expertise level
"""

from typing import Optional
from dataclasses import dataclass
from enum import Enum


class RiskTolerance(str, Enum):
    """Entrepreneur's risk tolerance"""
    CONSERVATIVE = "conservative"  # Prefers safe, proven strategies
    MODERATE = "moderate"          # Balanced risk/reward
    AGGRESSIVE = "aggressive"      # High risk for high reward


class GrowthAppetite(str, Enum):
    """Desired growth pace"""
    SLOW = "slow"                  # Profitable, sustainable growth
    STEADY = "steady"              # Consistent 20-30% annual growth
    HYPERGROWTH = "hypergrowth"    # 50%+ annual, willing to sacrifice profit


class ExpertiseLevel(str, Enum):
    """Entrepreneur's business experience"""
    NOVICE = "novice"              # First-time founder
    INTERMEDIATE = "intermediate"  # 5-10 years experience
    EXPERT = "expert"              # 15+ years, multiple exits


class DecisionStyle(str, Enum):
    """How entrepreneur makes decisions"""
    DATA_DRIVEN = "data-driven"    # Wants metrics and proof
    INTUITIVE = "intuitive"        # Goes with gut feeling
    MIXED = "mixed"                # Balanced


class PainTolerance(str, Enum):
    """How much pain tolerated before action"""
    LOW = "low"                    # Acts immediately on problems
    MEDIUM = "medium"              # Waits for confirmation
    HIGH = "high"                  # Only acts when critical


@dataclass
class EntrepreneurProfile:
    """Comprehensive entrepreneur profile"""
    risk_tolerance: RiskTolerance
    growth_appetite: GrowthAppetite
    expertise_level: ExpertiseLevel
    decision_style: DecisionStyle
    pain_tolerance: PainTolerance
    
    # Context
    company_size_eur: float
    industry: str
    company_stage: str  # startup, growth, scale, mature
    
    # Confidence of profile (0-1)
    profile_confidence: float = 0.5


class EntrepreneurProfiler:
    """Infer entrepreneur profile from company metrics"""
    
    @staticmethod
    def profile_from_metrics(
        fatturato: float,
        ebitda_margin_pct: float,
        gross_margin_pct: float,
        growth_rate_pct: float,
        company_age_years: float,
        industry: str,
        ccc_days: Optional[int] = None,
        investimenti_pct_revenue: float = 0.0,
    ) -> EntrepreneurProfile:
        """
        Infer entrepreneur profile from financial metrics.
        
        Args:
            fatturato: Annual revenue in EUR
            ebitda_margin_pct: EBITDA margin (%)
            gross_margin_pct: Gross margin (%)
            growth_rate_pct: YoY growth rate (%)
            company_age_years: Years in business
            industry: Industry sector
            ccc_days: Cash conversion cycle days
            investimenti_pct_revenue: Capital investments as % of revenue
        
        Returns:
            EntrepreneurProfile with inferred characteristics
        """
        
        # ===== RISK TOLERANCE =====
        # Conservative: Stable, high profitability, low growth
        # Aggressive: High growth, willing to sacrifice margin
        
        if growth_rate_pct > 50 or investimenti_pct_revenue > 0.15:
            risk_tolerance = RiskTolerance.AGGRESSIVE
        elif ebitda_margin_pct > 20 and growth_rate_pct < 15:
            risk_tolerance = RiskTolerance.CONSERVATIVE
        else:
            risk_tolerance = RiskTolerance.MODERATE
        
        # ===== GROWTH APPETITE =====
        # Hypergrowth: >50% YoY growth
        # Steady: 20-50% YoY growth
        # Slow: <20% YoY growth
        
        if growth_rate_pct > 50:
            growth_appetite = GrowthAppetite.HYPERGROWTH
        elif growth_rate_pct > 20:
            growth_appetite = GrowthAppetite.STEADY
        else:
            growth_appetite = GrowthAppetite.SLOW
        
        # ===== EXPERTISE LEVEL =====
        # Expert: >15 years or recovering from crisis
        # Intermediate: 5-15 years
        # Novice: <5 years
        
        if company_age_years > 15:
            expertise = ExpertiseLevel.EXPERT
        elif company_age_years > 5:
            expertise = ExpertiseLevel.INTERMEDIATE
        else:
            expertise = ExpertiseLevel.NOVICE
        
        # ===== DECISION STYLE =====
        # Data-driven: Profitable, optimized operations
        # Intuitive: High growth, lower profitability (acting on gut)
        # Mixed: Medium growth, medium profitability
        
        if ebitda_margin_pct > 25 and growth_rate_pct < 30:
            decision_style = DecisionStyle.DATA_DRIVEN
        elif growth_rate_pct > 40 and ebitda_margin_pct < 10:
            decision_style = DecisionStyle.INTUITIVE
        else:
            decision_style = DecisionStyle.MIXED
        
        # ===== PAIN TOLERANCE =====
        # High: Company surviving despite issues (good resilience)
        # Medium: Some financial health issues
        # Low: Acute financial stress
        
        if ebitda_margin_pct < 5:
            pain_tolerance = PainTolerance.HIGH  # Surviving despite low margin
        elif ebitda_margin_pct < 10:
            pain_tolerance = PainTolerance.MEDIUM
        else:
            pain_tolerance = PainTolerance.LOW  # Healthy, low pain
        
        # ===== COMPANY STAGE =====
        stage = EntrepreneurProfiler._infer_stage(
            company_age_years, fatturato, growth_rate_pct
        )
        
        # ===== PROFILE CONFIDENCE =====
        # Higher confidence if metrics are consistent
        confidence = 0.5
        if (ebitda_margin_pct > 15) or (growth_rate_pct > 50):
            confidence = 0.8  # Clear signal
        elif (ebitda_margin_pct > 5 and growth_rate_pct > 15):
            confidence = 0.7  # Consistent moderate metrics
        
        return EntrepreneurProfile(
            risk_tolerance=risk_tolerance,
            growth_appetite=growth_appetite,
            expertise_level=expertise,
            decision_style=decision_style,
            pain_tolerance=pain_tolerance,
            company_size_eur=fatturato,
            industry=industry,
            company_stage=stage,
            profile_confidence=confidence,
        )
    
    @staticmethod
    def _infer_stage(
        company_age_years: float,
        fatturato: float,
        growth_rate_pct: float,
    ) -> str:
        """Infer company stage: startup, growth, scale, mature"""
        
        if company_age_years < 3:
            return "startup"
        elif growth_rate_pct > 40:
            return "growth"
        elif fatturato > 10_000_000:
            return "scale"
        else:
            return "mature"


def get_entrepreneur_profiler() -> EntrepreneurProfiler:
    """Get the profiler singleton"""
    return EntrepreneurProfiler()
