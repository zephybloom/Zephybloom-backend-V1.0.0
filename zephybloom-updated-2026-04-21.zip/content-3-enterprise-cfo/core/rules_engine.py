# -*- coding: utf-8 -*-
# content/core/rules_engine.py — Valutazione regole sicura (expr/metriche), cache & gerarchie tenant/settore
from __future__ import annotations

import pathlib
import yaml
import ast
import operator
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple, Iterable, Union

# -----------------------------
# Operatori e helper base
# -----------------------------
OPS = {
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
    "==": operator.eq,
    "!=": operator.ne,
    "between": lambda x, ab: (ab[0] <= x <= ab[1]),
    "not_between": lambda x, ab: not (ab[0] <= x <= ab[1]),
}


def pct(x: float) -> float:
    """Converte frazione→% (0.2 -> 20). Se già in %, lo lascia passare."""
    try:
        v = float(x)
    except Exception:
        return 0.0
    return v * 100.0 if abs(v) <= 1.0 else v


def clamp(x: float, lo: float, hi: float) -> float:
    """Limita x nell'intervallo [lo, hi]."""
    try:
        return max(float(lo), min(float(hi), float(x)))
    except Exception:
        return 0.0


SAFE_FUNCS = {"abs": abs, "min": min, "max": max, "round": round, "pct": pct, "clamp": clamp}

SEVERITY_ORDER = {"info": 10, "low": 20, "medium": 30, "high": 40, "critical": 50}

# Metriche interne espresse come frazioni 0..1
FRACTION_METRICS = {
    "roi",
    "mc_rate",
    "gross_margin_rate",
    "net_margin_rate",
    "churn_rate",
}

# Metriche che spesso vogliamo anche in formato percentuale lato regole/UI
PCT_ALIAS_MAP = {
    "roi": "roi_pct",
    "mc_rate": "mc_rate_pct",
    "gross_margin_rate": "gross_margin_rate_pct",
    "net_margin_rate": "net_margin_rate_pct",
    "churn_rate": "churn_rate_pct",
}


# AST sicuro: niente attributi, niente comprensioni, niente assegnazioni.
ALLOWED_AST = {
    ast.Expression,
    ast.BoolOp,
    ast.BinOp,
    ast.UnaryOp,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Num,
    ast.And,
    ast.Or,
    ast.NotEq,
    ast.Eq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Mod,
    ast.USub,
    ast.Call,  # limitato a SAFE_FUNCS
}


# -----------------------------
# Eval espressioni sicuro (con cache)
# -----------------------------
def _validate_ast(tree: ast.AST) -> None:
    for n in ast.walk(tree):
        t = type(n)
        if t not in ALLOWED_AST:
            raise ValueError(f"Nodo AST non permesso: {t.__name__}")
        if isinstance(n, ast.Call):
            if not isinstance(n.func, ast.Name) or n.func.id not in SAFE_FUNCS:
                raise ValueError("Funzione non permessa in espressione.")


@lru_cache(maxsize=2048)
def _compile_expr(expr: str) -> object:
    tree = ast.parse(expr, mode="eval")
    _validate_ast(tree)
    return compile(tree, "<expr>", "eval")


def _safe_eval(expr: str, vars: Dict[str, Any]) -> bool:
    code = _compile_expr(expr)
    env = {"__builtins__": {}}
    env.update(SAFE_FUNCS)
    return bool(eval(code, env, dict(vars)))


# -----------------------------
# IO & cache regole
# -----------------------------
def _read_yaml_file(path: pathlib.Path) -> List[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or []
        return data if isinstance(data, list) else [data]
    except Exception:
        return []


def _list_rule_files(base_dir: pathlib.Path, sector: str | None, tenant_id: str | None) -> List[pathlib.Path]:
    files: List[pathlib.Path] = []

    base_yml = base_dir / "base.yml"
    if base_yml.exists():
        files.append(base_yml)

    sector = (sector or "").strip()
    if sector:
        sec_yml = base_dir / "sectors" / f"{sector}.yml"
        if sec_yml.exists():
            files.append(sec_yml)

    tenant_id = (tenant_id or "").strip()
    if tenant_id:
        ten_yml = base_dir / "tenants" / f"{tenant_id}.yml"
        if ten_yml.exists():
            files.append(ten_yml)

    for y in sorted(list(base_dir.glob("*.yml")) + list(base_dir.glob("*.yaml"))):
        if y != base_yml and y.is_file():
            files.append(y)

    return files


@lru_cache(maxsize=256)
def _load_rules_cached(key: str) -> List[Dict[str, Any]]:
    """Cache su chiave astratta base_dir|sector|tenant."""
    base_dir, sector, tenant = key.split("|", 2)
    base = pathlib.Path(base_dir)
    rules: List[Dict[str, Any]] = []
    if not base.exists():
        return rules

    for f in _list_rule_files(base, sector or None, tenant or None):
        rules += _read_yaml_file(f)

    return rules


def load_rules(path: str | pathlib.Path) -> List[Dict[str, Any]]:
    """Compat: carica da singolo file o directory piatta (senza gerarchie)."""
    p = pathlib.Path(path)
    rules: List[Dict[str, Any]] = []

    if p.is_dir():
        ymls = sorted(list(p.glob("*.yml")) + list(p.glob("*.yaml")))
        for y in ymls:
            rules += _read_yaml_file(y)
    elif p.exists():
        rules += _read_yaml_file(p)

    return rules


def load_rules_hierarchical(
    base_dir: str | pathlib.Path,
    *,
    tenant_id: str | None = None,
    sector: str | None = None,
) -> List[Dict[str, Any]]:
    """
    Carica e unisce regole da: base.yml → sectors/{sector}.yml → tenants/{tenant_id}.yml
    + ogni .yml in root come “pacchetti” aggiuntivi.
    """
    b = pathlib.Path(base_dir)
    key = f"{b.resolve()}|{sector or ''}|{tenant_id or ''}"
    return _load_rules_cached(key)


# -----------------------------
# Validazione & merge
# -----------------------------
def _coerce_payload(kpi: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge kpi+context; cast dolce dei numeri, lascia passare anche stringhe utili.
    Aggiunge anche alias *_pct per le metriche frazionali più comuni.
    """
    out: Dict[str, Any] = {}

    for src in (kpi or {}, ctx or {}):
        for k, v in src.items():
            try:
                out[k] = float(v)
            except Exception:
                out[k] = v

    # Alias percentuali automatici
    for frac_key, pct_key in PCT_ALIAS_MAP.items():
        if frac_key in out:
            try:
                out[pct_key] = pct(out[frac_key])
            except Exception:
                pass

    return out


def _norm_severity(s: Any) -> str:
    sv = str(s or "info").lower().strip()
    return sv if sv in SEVERITY_ORDER else "info"


def _safe_template(msg: str, payload: Dict[str, Any]) -> str:
    try:
        return msg.format(**{k: payload.get(k, "") for k in payload.keys()})
    except Exception:
        return msg


def _as_range(thr: Any) -> Optional[Tuple[float, float]]:
    try:
        lo, hi = float(thr[0]), float(thr[1])  # type: ignore[index]
        if lo > hi:
            lo, hi = hi, lo
        return lo, hi
    except Exception:
        return None


def _validate_rule(r: Dict[str, Any]) -> bool:
    if not isinstance(r, dict):
        return False
    if "expr" in r:
        return isinstance(r["expr"], str)
    return ("metric" in r and "op" in r and "threshold" in r)


def _merge_rules(rule_lists: Iterable[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []

    for rules in rule_lists:
        for r in rules or []:
            if not _validate_rule(r):
                continue

            code = str(r.get("code", f"RULE_{len(order)}"))
            if code not in merged:
                order.append(code)
            merged[code] = r

    return [merged[c] for c in order]


# -----------------------------
# Normalizzazione confronto metriche
# -----------------------------
def _normalize_metric_value_for_threshold(metric: str, value: float, threshold: Any) -> float:
    """
    Se la metrica interna è frazionale (es. roi=0.92) ma la soglia sembra percentuale (es. 5),
    converte il value in % prima del confronto.
    """
    try:
        thr = float(threshold)
    except Exception:
        return float(value)

    if metric in FRACTION_METRICS and abs(float(value)) <= 1.0 and abs(thr) > 1.0:
        return pct(float(value))

    return float(value)


def _normalize_range_for_metric(metric: str, value: float, threshold_range: Tuple[float, float]) -> Tuple[float, Tuple[float, float]]:
    lo, hi = threshold_range
    norm_value = float(value)

    if metric in FRACTION_METRICS and abs(norm_value) <= 1.0 and (abs(lo) > 1.0 or abs(hi) > 1.0):
        norm_value = pct(norm_value)

    return norm_value, (lo, hi)


# -----------------------------
# Valutazione
# -----------------------------
def evaluate_rules(
    kpi: Dict[str, Any],
    rules: List[Dict[str, Any]],
    context: Optional[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """
    Ogni regola può essere:
      - expr: stringa Python-safe (es. "pct(mc_rate) < 35 and fatturato > 500000")
      - oppure: metric/op/threshold
        * op in {<,<=,>,>=,==,!=,between,not_between}
        * per between/not_between usare threshold: [min, max]
    """
    payload = _coerce_payload(kpi, context or {})
    alerts: List[Dict[str, Any]] = []

    for r in rules or []:
        try:
            code = r.get("code", "RULE")
            message = r.get("message", "")
            severity = _norm_severity(r.get("severity", "info"))
            priority = int(r.get("priority", 50))
            action = r.get("action", {})
            tags = r.get("tags", [])

            ok = False
            details: Dict[str, Any] = {}

            if r.get("expr"):
                expr = str(r["expr"])
                ok = _safe_eval(expr, payload)
                details = {"type": "expr", "expr": expr}
            else:
                metric = r.get("metric")
                op_key = str(r.get("op", ">=")).lower().strip()
                thr = r.get("threshold", 0)

                if metric in payload and op_key in OPS:
                    raw_val = payload[metric]

                    if op_key in {"between", "not_between"}:
                        ab = _as_range(thr)
                        if ab is not None:
                            norm_val, norm_ab = _normalize_range_for_metric(metric, float(raw_val), ab)
                            ok = OPS[op_key](norm_val, norm_ab)
                            details = {
                                "type": "range",
                                "metric": metric,
                                "value": norm_val,
                                "raw_value": float(raw_val),
                                "op": op_key,
                                "threshold": norm_ab,
                            }
                    else:
                        norm_val = _normalize_metric_value_for_threshold(metric, float(raw_val), thr)
                        norm_thr = float(thr)
                        ok = OPS[op_key](norm_val, norm_thr)
                        details = {
                            "type": "cmp",
                            "metric": metric,
                            "value": norm_val,
                            "raw_value": float(raw_val),
                            "op": op_key,
                            "threshold": norm_thr,
                        }

            if ok:
                alerts.append({
                    "code": code,
                    "message": _safe_template(message, payload),
                    "severity": severity,
                    "priority": priority,
                    "action": action,
                    "tags": tags,
                    "details": details,
                })

        except Exception:
            continue

    alerts.sort(
        key=lambda a: (
            a.get("priority", 50),
            -SEVERITY_ORDER.get(a.get("severity", "info"), 10),
        )
    )
    return alerts


# -----------------------------
# Facade ad alto livello (tenant/settore)
# -----------------------------
def evaluate_ruleset(
    rules_path_or_dir: Union[str, pathlib.Path],
    kpi: Dict[str, Any],
    *,
    context: Optional[Dict[str, Any]] = None,
    tenant_id: Optional[str] = None,
    sector: Optional[str] = None,
    hierarchical: bool = True,
) -> List[Dict[str, Any]]:
    """
    Valuta direttamente partendo da un path:
      - se hierarchical=True → usa gerarchia base/sectors/tenants
      - altrimenti carica tutti i .yml della cartella
    """
    p = pathlib.Path(rules_path_or_dir)

    if hierarchical and p.is_dir():
        rules = load_rules_hierarchical(p, tenant_id=tenant_id, sector=sector)
    else:
        rules = load_rules(p)

    rules = _merge_rules([rules])
    return evaluate_rules(kpi, rules, context)