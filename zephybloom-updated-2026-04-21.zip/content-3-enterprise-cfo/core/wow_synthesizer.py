"""
WOW Moment Synthesizer

Extract the 2-3 most memorable insights - now with industry benchmarks.
"""

from typing import List, Dict, Any
from dataclasses import dataclass
from core.industry_adapter import get_industry_adapter


@dataclass
class WowMoment:
    """A memorable insight"""
    moment: str
    impact_eur: float
    timeframe: str
    memorability_score: int  # 1-10
    industry_context: str = ""  # e.g., "vs industry avg 35%"


class WowSynthesizer:
    """Extract memorable insights with industry context"""
    
    def synthesize(
        self,
        analysis_dict: Dict[str, Any],
        decisions_dict: Dict[str, Any],
        cost_of_inaction_dict: Dict[str, float],
        settore: str = "default",
    ) -> List[WowMoment]:
        """
        Extract 2-3 WOW moments from analysis with industry benchmarks.
        
        Args:
            analysis_dict: Analysis results with headline, margin_issue, cash_issue, growth_issue
            decisions_dict: Dict mapping decision title to impact EUR
            cost_of_inaction_dict: Dict mapping decision title to monthly cost
            settore: Industry code for benchmark context
        """
        
        moments = []
        industry_adapter = get_industry_adapter(settore)
        profile = industry_adapter.profile
        
        # ===== WOW #1: Cost of Non-Action (Highest Impact) =====
        total_inaction_cost_monthly = sum(cost_of_inaction_dict.values()) if cost_of_inaction_dict else 0
        if total_inaction_cost_monthly > 5000:
            annual_inaction_cost = total_inaction_cost_monthly * 12
            moments.append(WowMoment(
                moment=f"Every month you wait costs €{total_inaction_cost_monthly:,.0f} in lost profit. In a year, that's €{annual_inaction_cost:,.0f}.",
                impact_eur=annual_inaction_cost,
                timeframe="12 months",
                memorability_score=10,
                industry_context=f"For {profile.name}, this is catastrophic.",
            ))
        
        # ===== WOW #2: Money Left on Table =====
        total_impact = sum(decisions_dict.values()) if decisions_dict else 0
        if total_impact > 100000:
            moments.append(WowMoment(
                moment=f"You could improve profitability by €{total_impact:,.0f} in the next 90 days.",
                impact_eur=total_impact,
                timeframe="90 days",
                memorability_score=9,
                industry_context=f"This is 2-3x the typical {profile.name} company improvement.",
            ))
        
        # ===== WOW #3: Growth Quality =====
        if analysis_dict.get("growth_issue", False):
            moments.append(WowMoment(
                moment="You're growing but margins are eroding. This isn't growth - it's liability.",
                impact_eur=0,
                timeframe="next quarter",
                memorability_score=9,
                industry_context=f"For {profile.name}, margin stability is critical at this stage.",
            ))
        
        # ===== WOW #4: Margin Crisis =====
        if analysis_dict.get("margin_issue", False):
            current_margin = analysis_dict.get("current_margin", 0)
            healthy_margin = profile.healthy_gross_margin_pct
            gap = healthy_margin - current_margin
            moments.append(WowMoment(
                moment="Margin pressure is your #1 problem right now. Fix it before anything else.",
                impact_eur=0,
                timeframe="immediate",
                memorability_score=8,
                industry_context=f"You're at {current_margin:.1f}%, but {profile.name} industry is at {healthy_margin:.1f}% - gap of {gap:.1f}%.",
            ))
        
        # ===== WOW #5: Cash Crisis =====
        if analysis_dict.get("cash_issue", False):
            moments.append(WowMoment(
                moment="Cash position is at risk. This could become a crisis in 30-60 days.",
                impact_eur=0,
                timeframe="30-60 days",
                memorability_score=9,
                industry_context=f"Your cycle is too long for {profile.name} company - typical is 30 days faster.",
            ))
        
        # Sort by memorability and return top 3
        moments.sort(key=lambda x: x.memorability_score, reverse=True)
        return moments[:3]


def get_synthesizer() -> WowSynthesizer:
    return WowSynthesizer()
