# -*- coding: utf-8 -*-
# content/core/kpi_engine.py — Motore KPI unificato (compatibile smoke) + estensioni CFO
from __future__ import annotations
from typing import Dict, Any, Tuple, Optional
from dataclasses import dataclass

from utils.validators import (
    clamp_rate01, clamp_pct100, clamp_nonneg, validate_kpi_invariants
)

# =======================
# Config & sector presets
# =======================

@dataclass
class KPIOptions:
    """Opzioni per tarare formule/assunzioni."""
    # ⚠️ Default impostati per MATCHARE i tuoi test verdi
    wc_on_sales_share: float = 0.0          # di default NON conteggiamo DSO su vendite
    wc_on_cogs_share: float = 1.0           # di default sì DIO/DPO su COGS (come smoke)
    days_in_year: int = 365

    # Fisco & FCF (opt-in: non influenzano i test se non li setti)
    tax_cap_at_ebit: bool = True
    use_tax_rate_if_missing_taxes: bool = True
    capex_key: str = "investimenti"
    wc_delta_key: str = "wc_delta"
    interest_expense_key: str = "interest"

    sector: str = "default"

SECTOR_BENCHMARKS: Dict[str, Dict[str, float]] = {
    "default": {
        "gross_margin_rate_min": 0.35,
        "ebitda_margin_rate_min": 0.12,
        "net_margin_rate_min": 0.06,
        "roi_pct_min": 10.0,
        "ccc_days_max": 70.0,
        "zscore_min": 1.8,
    },
    "manufacturing": {
        "gross_margin_rate_min": 0.30,
        "ebitda_margin_rate_min": 0.12,
        "net_margin_rate_min": 0.05,
        "roi_pct_min": 12.0,
        "ccc_days_max": 80.0,
        "zscore_min": 1.8,
    },
    "saas": {
        "gross_margin_rate_min": 0.70,
        "ebitda_margin_rate_min": 0.15,
        "net_margin_rate_min": 0.05,
        "roi_pct_min": 20.0,
        "ccc_days_max": 30.0,
        "zscore_min": 1.8,
    },
}

# ============
# Num helpers
# ============
def _num(x: Any, default: float = 0.0) -> float:
    try:
        return float(x if x is not None else default)
    except Exception:
        return default

def _pp_to_rate(pp: Optional[float]) -> float:
    if pp is None:
        return 0.0
    try:
        v = float(pp)
    except Exception:
        return 0.0
    return max(0.0, v / 100.0)

# ==============================
# Working capital & break-even
# ==============================
def compute_ccc_and_wc(
    sales: float,
    cogs: float,
    dso: float,
    dio: float,
    dpo: float,
    *,
    days_in_year: int = 365,
    wc_on_sales_share: float = 0.0,  # default per smoke
    wc_on_cogs_share: float = 1.0,   # default per smoke
) -> Tuple[float, float]:
    """
    CCC = DSO + DIO − DPO
    WCN ≈ sales_day*DSO*share_sales + cogs_day*(DIO−DPO)*share_cogs
    Con i default (0, 1) replichi i report verdi (es. CCC=55, WC≈376,4k).
    """
    dso = max(0.0, float(dso or 0.0))
    dio = max(0.0, float(dio or 0.0))
    dpo = max(0.0, float(dpo or 0.0))
    ccc = dso + dio - dpo

    sales_day = sales / float(days_in_year) if sales > 0 else 0.0
    cogs_day  = cogs  / float(days_in_year) if cogs  > 0 else 0.0

    wc_need = (
        wc_on_sales_share * sales_day * dso
        + wc_on_cogs_share * cogs_day * dio
        - wc_on_cogs_share * cogs_day * dpo
    )
    return ccc, max(0.0, wc_need)

def compute_break_even(prezzo_medio: float, cvu: float, fixed_costs: float) -> Tuple[float, float]:
    prezzo = _num(prezzo_medio)
    cvu    = _num(cvu)
    cf     = max(0.0, _num(fixed_costs))
    if prezzo <= cvu or prezzo <= 0.0:
        return 0.0, 0.0
    be_qty = cf / (prezzo - cvu)
    be_rev = be_qty * prezzo
    return be_qty, be_rev

# ===============
# Altman Z-score
# ===============
def compute_altman_z(
    wc: Optional[float],
    re: Optional[float],
    ebit: Optional[float],
    mve: Optional[float],
    sales: Optional[float],
    ta: Optional[float],
    tl: Optional[float],
) -> Optional[float]:
    ta = _num(ta); tl = _num(tl)
    if ta <= 0 or tl <= 0:
        return None
    wc = _num(wc); re = _num(re); ebit = _num(ebit); mve = _num(mve); sales = _num(sales)
    x1 = wc / ta
    x2 = re / ta
    x3 = ebit / ta
    x4 = mve / tl
    x5 = sales / ta
    return 1.2*x1 + 1.4*x2 + 3.3*x3 + 0.6*x4 + 1.0*x5

# ==========
# SaaS KPIs
# ==========
def compute_saas_kpis(
    mrr: Optional[float],
    churn_rate: Optional[float],
    arpu: Optional[float],
    cac: Optional[float],
    gross_margin_rate: Optional[float],
    nrr: Optional[float] = None,
) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    mrr_f = _num(mrr)
    churn_f = clamp_rate01(float(churn_rate) if churn_rate is not None else 0.0) or 0.0
    arpu_f = _num(arpu)
    cac_f  = _num(cac)
    gm_f   = clamp_rate01(gross_margin_rate or 0.0) or 0.0

    if mrr is not None: out["mrr"] = max(0.0, mrr_f)
    if arpu is not None: out["arpu"] = max(0.0, arpu_f)
    if churn_rate is not None: out["churn_rate"] = churn_f
    if nrr is not None:
        nrr_f = float(nrr)
        out["nrr"] = nrr_f if nrr_f <= 1.0 else nrr_f / 100.0

    if arpu is not None and churn_f > 0.0:
        out["ltv"] = max(0.0, arpu_f * gm_f / churn_f)
    if arpu is not None and (arpu_f * gm_f) > 0 and cac is not None:
        out["cac_payback_months"] = max(0.0, cac_f / (arpu_f * gm_f))
    return out

# ===========
# Benchmarks
# ===========
def _score_min(value: float, min_target: float) -> float:
    if min_target <= 0: return 100.0
    if value >= min_target: return 100.0
    return max(0.0, 100.0 * (value / min_target))

def _score_max(value: float, max_target: float) -> float:
    if max_target <= 0: return 0.0 if value > 0 else 100.0
    if value <= max_target: return 100.0
    over = value - max_target
    return max(0.0, 100.0 * (1.0 - over / max_target))

def benchmark_scores(sector: str, kpi: Dict[str, float]) -> Dict[str, Any]:
    b = SECTOR_BENCHMARKS.get(sector, SECTOR_BENCHMARKS["default"])
    scores = {
        "gross_margin_rate": _score_min(kpi.get("gross_margin_rate", 0.0), b["gross_margin_rate_min"]),
        "ebitda_margin_rate": _score_min(kpi.get("ebitda_margin_rate", 0.0), b["ebitda_margin_rate_min"]),
        "net_margin_rate": _score_min(kpi.get("net_margin_rate", 0.0), b["net_margin_rate_min"]),
        "roi_pct": _score_min(kpi.get("roi_pct", 0.0), b["roi_pct_min"]),
        "ccc_days": _score_max(kpi.get("ccc_days", 0.0), b["ccc_days_max"]),
        "altman_z": _score_min(kpi.get("altman_z", 0.0), b["zscore_min"]),
    }
    weights = {
        "gross_margin_rate": 0.25,
        "ebitda_margin_rate": 0.20,
        "net_margin_rate": 0.15,
        "roi_pct": 0.15,
        "ccc_days": 0.15,
        "altman_z": 0.10,
    }
    composite = sum(scores[k] * w for k, w in weights.items())
    return {"scores": scores, "composite": round(composite, 1), "benchmarks": b}

# =========================
# Calcolo KPI “fonte unica”
# =========================
def compute_kpi(payload: Dict[str, Any], *, options: Optional[KPIOptions] = None) -> Dict[str, Any]:
    """
    Compatibile con i tuoi smoke:
    - EBITDA = GM − CF + Amm
    - Utile “pre-tax” (= utile dei tuoi report) = GM − CF
    - ROI calcolato su utile pre-tax / investimenti
    - Alias chiave: ccc (== ccc_days), break_even (== break_even_revenue), net_profit (== utile pre-tax)
    """
    opt = options or KPIOptions(sector=str(payload.get("sector") or "default"))

    # --- input ---
    sales   = _num(payload.get("fatturato") or payload.get("sales"))
    cogs    = _num(payload.get("costi_variabili") or payload.get("cogs"))
    prezzo  = _num(payload.get("prezzo_medio"))
    cvu     = _num(payload.get("costo_variabile_unitario"))
    cf      = _num(payload.get("costi_fissi"))
    amm     = _num(payload.get("ammortamenti"))
    inv     = _num(payload.get("investimenti"))
    capex   = _num(payload.get(opt.capex_key))
    wc_delta = _num(payload.get(opt.wc_delta_key))

    dso     = _num(payload.get("dso"))
    dio     = _num(payload.get("dio"))
    dpo     = _num(payload.get("dpo"))
    wc_in   = payload.get("wc")

    # tasse/interest opzionali (non influenzano i test se non valorizzati)
    taxes_in   = payload.get("tasse")
    tax_rate_pp = payload.get("tax_rate")
    interest   = _num(payload.get(opt.interest_expense_key))

    # Saas opzionale
    mrr = payload.get("mrr"); churn = payload.get("churn_rate")
    arpu = payload.get("arpu"); cac = payload.get("cac"); nrr = payload.get("nrr")
    ltv_in = payload.get("ltv")

    # Altman inputs
    re = payload.get("re"); mve = payload.get("mve"); ta = payload.get("ta"); tl = payload.get("tl")

    # --- calcoli base coerenti con smoke ---
    gross_margin = max(0.0, sales - cogs)
    gross_margin_rate = clamp_rate01((gross_margin / sales) if sales > 0 else 0.0) or 0.0

    # ✅ EBITDA come nei tuoi report
    ebitda = max(0.0, gross_margin - cf + amm)
    ebitda_margin_rate = clamp_rate01((ebitda / sales) if sales > 0 else 0.0) or 0.0

    # ✅ Utile pre-tax (alias “net_profit” dei tuoi smoke) = GM − CF
    net_profit = max(0.0, gross_margin - cf)

    # EBIT e (opzionale) tassazione/interest per uso CFO
    ebit = max(0.0, ebitda - amm)               # = GM − CF
    ebt  = max(0.0, ebit - max(0.0, interest))  # se interest passato
    if taxes_in is not None:
        taxes = max(0.0, _num(taxes_in))
    else:
        tr = _pp_to_rate(tax_rate_pp) if (opt.use_tax_rate_if_missing_taxes and tax_rate_pp is not None) else 0.0
        base_tax = ebt if interest > 0 else ebit
        taxes = max(0.0, base_tax * tr)
        if opt.tax_cap_at_ebit:
            taxes = min(taxes, base_tax)
    net_income = max(0.0, (ebt if interest > 0 else ebit) - taxes)  # post-tax (solo informativo)

    # ROI su investimenti (coerente con smoke: usa utile pre-tax)
    roi_pct = (net_profit / inv * 100.0) if inv > 0 else 0.0
    roi_pct = clamp_pct100(roi_pct)

    # CCC & WC (default COGS-based)
    ccc_days, wc_need = compute_ccc_and_wc(
        sales, cogs, dso, dio, dpo,
        days_in_year=opt.days_in_year,
        wc_on_sales_share=opt.wc_on_sales_share,
        wc_on_cogs_share=opt.wc_on_cogs_share,
    )

    # Break-even
    be_qty, be_rev = compute_break_even(prezzo, cvu, cf)

    # CFO/FCF (pro, non richiesti dai test ma utili)
    cfo = max(0.0, (ebt if interest > 0 else ebit) + amm - taxes)
    fcf = max(0.0, cfo - capex - wc_delta)

    out: Dict[str, Any] = {
        # input normalizzati
        "sales": sales, "cogs": cogs, "fixed_costs": max(0.0, cf),
        "depreciation": max(0.0, amm), "investments": inv,
        "price": prezzo, "cvu": cvu,
        "dso": max(0.0, dso), "dio": max(0.0, dio), "dpo": max(0.0, dpo),

        # margini
        "gross_margin": gross_margin,
        "gross_margin_rate": gross_margin_rate,

        # compatibilità smoke
        "ebitda": ebitda,
        "ebitda_margin_rate": ebitda_margin_rate,
        "net_profit": net_profit,               # ✅ utile pre-tax (GM − CF)
        "break_even_qty": max(0.0, be_qty),
        "break_even_revenue": max(0.0, be_rev),
        "break_even": max(0.0, be_rev),         # ✅ alias richiesto da alcuni report
        "ccc_days": max(0.0, ccc_days),
        "ccc": max(0.0, ccc_days),              # ✅ alias richiesto dagli smoke
        "wc_need": max(0.0, wc_need),

        # pro (informativi)
        "ebit": ebit,
        "ebt": ebt,
        "taxes": taxes,
        "net_income": net_income,               # post-tax
        "net_margin_rate": clamp_rate01((net_income / sales) if sales > 0 else 0.0) or 0.0,
        "roi_pct": roi_pct,
        "cfo": cfo,
        "fcf": fcf,
    }

    # --- EXTRAS: SaaS ---
    extras: Dict[str, Any] = {}
    saas = compute_saas_kpis(
        mrr=mrr, churn_rate=churn, arpu=arpu, cac=cac,
        gross_margin_rate=gross_margin_rate, nrr=nrr,
    )
    if saas:
        if ltv_in is not None and "ltv" not in saas:
            try: saas["ltv"] = float(ltv_in)
            except Exception: pass
        extras["saas"] = saas

    # --- EXTRAS: Altman Z ---
    z = compute_altman_z(wc=wc_in if wc_in is not None else None, re=re,
                         ebit=ebit, mve=mve, sales=sales, ta=ta, tl=tl)
    if z is not None:
        extras.setdefault("risk", {})["altman_z"] = float(z)
        out["altman_z"] = float(z)

    # --- EXTRAS: Benchmarks & scoring ---
    bench = benchmark_scores(opt.sector, {
        "gross_margin_rate": out["gross_margin_rate"],
        "ebitda_margin_rate": out["ebitda_margin_rate"],
        "net_margin_rate": out["net_margin_rate"],
        "roi_pct": out["roi_pct"],
        "ccc_days": out["ccc_days"],
        "altman_z": out.get("altman_z", 0.0),
    })
    extras["benchmarks"] = bench

    # --- Diagnostica & red flags ---
    ok, diag = validate_kpi_invariants(out)
    red_flags: Dict[str, Any] = {}
    if not ok: red_flags["invariants"] = diag
    if sales <= 0 and (out["gross_margin"] > 0 or out["net_profit"] > 0):
        red_flags["sales_zero_but_profit_positive"] = True
    if out["gross_margin_rate"] == 1.0 and cogs > 0:
        red_flags["gm_rate_impossible"] = True
    if prezzo > 0 and cvu >= prezzo and be_qty == 0:
        red_flags["be_unreachable_price_leq_cvu"] = {"prezzo": prezzo, "cvu": cvu}

    if extras or red_flags:
        out["_extras"] = extras
        if red_flags:
            out.setdefault("_diag", {})["red_flags"] = red_flags

    return out
