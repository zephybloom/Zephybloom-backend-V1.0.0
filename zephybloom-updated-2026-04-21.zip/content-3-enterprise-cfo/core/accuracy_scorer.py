"""
Accuracy Scorer - Calculate decision quality metrics

Measures:
- Implementation rate (how many recommended decisions were actually done)
- Accuracy rate (of those implemented, how many hit target impact)
- Variance from target (average % deviation)
- Success/failure patterns by decision type
"""

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import json


@dataclass
class DecisionRecord:
    """A decision record from DB"""
    decision_id: str
    decision_title: str
    decision_verdict: str  # GO, MAYBE, WAIT
    expected_impact_eur: float
    was_implemented: Optional[bool]
    actual_impact_eur: Optional[float]
    created_at: datetime
    feedback_received_at: Optional[datetime] = None


@dataclass
class AccuracyMetrics:
    """Calculated accuracy metrics"""
    total_decisions: int
    decisions_with_feedback: int
    implemented_count: int
    implementation_rate: float  # 0-1, percentage of decisions actually done
    
    # Of those implemented:
    target_hit_count: int  # Within 20% of expected impact
    accuracy_rate: float  # 0-1, percentage that hit target
    
    # Variance
    average_variance_pct: float  # Average % deviation from target
    max_positive_variance_pct: float  # Best case over-performance
    max_negative_variance_pct: float  # Worst case under-performance
    
    # Patterns
    success_patterns: List[str]  # Decision types that tend to work
    failure_patterns: List[str]  # Decision types that tend to fail
    
    # Health
    is_healthy: bool  # accuracy_rate > 0.7 and implementation_rate > 0.6


class AccuracyScorer:
    """Score and analyze decision accuracy"""
    
    @staticmethod
    def calculate_implementation_rate(decisions: List[DecisionRecord]) -> Tuple[int, float]:
        """
        What percentage of decisions were actually implemented?
        
        Returns: (implemented_count, implementation_rate 0-1)
        """
        if not decisions:
            return 0, 0.0
        
        implemented = sum(1 for d in decisions if d.was_implemented is True)
        rate = implemented / len(decisions)
        
        return implemented, rate
    
    @staticmethod
    def calculate_accuracy_rate(decisions: List[DecisionRecord]) -> Tuple[int, float, float]:
        """
        Of decisions that were implemented, how many hit target?
        Target = within 20% of expected impact
        
        Returns: (target_hit_count, accuracy_rate 0-1, average_variance_pct)
        """
        implemented = [d for d in decisions if d.was_implemented is True and d.actual_impact_eur is not None]
        
        if not implemented:
            return 0, 0.0, 0.0
        
        target_hits = 0
        variances = []
        
        for decision in implemented:
            expected = decision.expected_impact_eur
            actual = decision.actual_impact_eur
            
            if expected == 0:
                # Can't calculate variance if no expected impact
                continue
            
            variance_pct = ((actual - expected) / abs(expected)) * 100
            variances.append(variance_pct)
            
            # Target hit: within 20% of expected
            if abs(variance_pct) <= 20:
                target_hits += 1
        
        accuracy_rate = target_hits / len(implemented) if implemented else 0.0
        average_variance = sum(variances) / len(variances) if variances else 0.0
        
        return target_hits, accuracy_rate, average_variance
    
    @staticmethod
    def find_variance_bounds(decisions: List[DecisionRecord]) -> Tuple[float, float]:
        """
        Find best and worst case performance vs target
        
        Returns: (max_positive_variance_pct, max_negative_variance_pct)
        """
        implemented = [d for d in decisions if d.was_implemented is True and d.actual_impact_eur is not None]
        
        if not implemented:
            return 0.0, 0.0
        
        variances = []
        
        for decision in implemented:
            expected = decision.expected_impact_eur
            actual = decision.actual_impact_eur
            
            if expected == 0:
                continue
            
            variance_pct = ((actual - expected) / abs(expected)) * 100
            variances.append(variance_pct)
        
        if not variances:
            return 0.0, 0.0
        
        max_positive = max(v for v in variances if v > 0) if any(v > 0 for v in variances) else 0.0
        max_negative = min(v for v in variances if v < 0) if any(v < 0 for v in variances) else 0.0
        
        return max_positive, max_negative
    
    @staticmethod
    def identify_patterns(decisions: List[DecisionRecord]) -> Tuple[List[str], List[str]]:
        """
        What decision types tend to work? Which tend to fail?
        
        Success = implemented AND actual within 20% of expected
        Failure = implemented BUT actual < 50% of expected
        
        Returns: (success_patterns, failure_patterns)
        """
        success_types: Dict[str, int] = {}
        failure_types: Dict[str, int] = {}
        type_counts: Dict[str, int] = {}
        
        for decision in decisions:
            if decision.was_implemented is not True:
                continue
            
            if decision.actual_impact_eur is None:
                continue
            
            dtype = decision.decision_title  # e.g., "Increase Gross Margin"
            type_counts[dtype] = type_counts.get(dtype, 0) + 1
            
            expected = decision.expected_impact_eur
            actual = decision.actual_impact_eur
            
            if expected == 0:
                continue
            
            variance_pct = ((actual - expected) / abs(expected)) * 100
            
            # Success pattern: within 20%
            if abs(variance_pct) <= 20:
                success_types[dtype] = success_types.get(dtype, 0) + 1
            
            # Failure pattern: less than 50% of expected
            elif actual < expected * 0.5:
                failure_types[dtype] = failure_types.get(dtype, 0) + 1
        
        # Extract types with high success/failure rate
        success_patterns = [
            dtype for dtype, count in success_types.items()
            if count >= type_counts.get(dtype, 1) * 0.7  # 70%+ success rate
        ]
        
        failure_patterns = [
            dtype for dtype, count in failure_types.items()
            if count >= type_counts.get(dtype, 1) * 0.5  # 50%+ failure rate
        ]
        
        return success_patterns, failure_patterns
    
    @staticmethod
    def score(decisions: List[DecisionRecord]) -> AccuracyMetrics:
        """
        Calculate complete accuracy metrics for a set of decisions.
        
        Args:
            decisions: List of decision records from last N days/month
        
        Returns:
            AccuracyMetrics with complete assessment
        """
        
        # Filter: only decisions with feedback
        decisions_with_feedback = [d for d in decisions if d.feedback_received_at is not None]
        
        # Implementation rate
        implemented_count, impl_rate = AccuracyScorer.calculate_implementation_rate(
            decisions_with_feedback
        )
        
        # Accuracy rate
        target_hits, accuracy_rate, avg_variance = AccuracyScorer.calculate_accuracy_rate(
            decisions_with_feedback
        )
        
        # Variance bounds
        max_positive, max_negative = AccuracyScorer.find_variance_bounds(
            decisions_with_feedback
        )
        
        # Patterns
        success_patterns, failure_patterns = AccuracyScorer.identify_patterns(
            decisions_with_feedback
        )
        
        # Health check
        is_healthy = accuracy_rate > 0.7 and impl_rate > 0.6
        
        return AccuracyMetrics(
            total_decisions=len(decisions),
            decisions_with_feedback=len(decisions_with_feedback),
            implemented_count=implemented_count,
            implementation_rate=impl_rate,
            target_hit_count=target_hits,
            accuracy_rate=accuracy_rate,
            average_variance_pct=avg_variance,
            max_positive_variance_pct=max_positive,
            max_negative_variance_pct=max_negative,
            success_patterns=success_patterns,
            failure_patterns=failure_patterns,
            is_healthy=is_healthy,
        )


def score_decisions_by_period(
    decisions: List[DecisionRecord],
    period_days: int = 30,
) -> Dict[str, AccuracyMetrics]:
    """
    Score decisions grouped by time period.
    
    Args:
        decisions: All decisions
        period_days: Group by this many days (30 for monthly)
    
    Returns:
        Dict mapping period_name (e.g., "2026-04") to AccuracyMetrics
    """
    
    if not decisions:
        return {}
    
    # Group by period
    periods: Dict[str, List[DecisionRecord]] = {}
    
    for decision in decisions:
        # Round to period boundary
        period_start = decision.created_at.replace(day=1) if period_days == 30 else \
                       decision.created_at - timedelta(days=decision.created_at.weekday())
        
        period_key = period_start.strftime("%Y-%m") if period_days == 30 else period_start.strftime("%Y-W%U")
        
        if period_key not in periods:
            periods[period_key] = []
        
        periods[period_key].append(decision)
    
    # Score each period
    result = {}
    for period_key, period_decisions in periods.items():
        result[period_key] = AccuracyScorer.score(period_decisions)
    
    return result
