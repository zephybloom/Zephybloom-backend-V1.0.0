"""
CFO Sensitivity Analysis Engine - Single variable impact analysis

Analyzes how key metrics respond to changes in input variables:
- Revenue growth ±5%/10%/15%
- Cost changes ±2%/5%/10%
- Price changes ±3%/5%/10%

Helps answer: "What if X changes by Y%? What happens to profit?"
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


# ============================================
# DATA MODELS
# ============================================

@dataclass
class SensitivityResult:
    """Result of sensitivity analysis for one variable"""
    
    variable: str  # "revenue", "variable_cost", "fixed_cost", "price"
    change_pct: float  # Change percentage (e.g., +10.0)
    
    # Original metrics
    base_value: float
    new_value: float
    
    # Impact on key metrics
    base_profit: float
    new_profit: float
    profit_impact_eur: float  # Absolute change
    profit_impact_pct: float  # Percentage change
    
    # Interpretation
    interpretation: str  # "High sensitivity", "Low sensitivity", etc


@dataclass
class TornadoData:
    """Data point for tornado chart"""
    
    variable: str
    upside_impact_eur: float  # Impact of +% change
    downside_impact_eur: float  # Impact of -% change
    total_range: float  # Upside + downside


# ============================================
# SENSITIVITY ENGINE
# ============================================

class SensitivityAnalysis:
    """Analyzes how metrics respond to variable changes"""
    
    @staticmethod
    def simulate_revenue_change(
        base_revenue: float,
        change_pct: float,
        costi_variabili: float,
        costi_fissi: float,
        gross_margin_rate: Optional[float] = None,
    ) -> Dict:
        """
        Simulate impact of revenue change
        
        Assumes:
        - Variable costs scale with revenue (same %)
        - Fixed costs stay constant
        
        Args:
            base_revenue: Current revenue
            change_pct: Change percentage (e.g., +10.0)
            costi_variabili: Current variable costs
            costi_fissi: Current fixed costs
            gross_margin_rate: Optional if known
        
        Returns:
            Dict with base and scenario metrics
        """
        
        new_revenue = base_revenue * (1 + change_pct / 100)
        
        # Variable costs scale proportionally
        if base_revenue > 0:
            vc_rate = costi_variabili / base_revenue
        else:
            vc_rate = 0.5  # Default assumption
        
        new_vc = new_revenue * vc_rate
        new_fc = costi_fissi  # Fixed costs unchanged
        
        # Base case
        base_profit = base_revenue - costi_variabili - costi_fissi
        
        # New case
        new_profit = new_revenue - new_vc - new_fc
        
        # Impact
        profit_impact = new_profit - base_profit
        profit_impact_pct = (profit_impact / abs(base_profit) * 100) if base_profit != 0 else 0
        
        return {
            "scenario": f"Revenue {change_pct:+.1f}%",
            "revenue": new_revenue,
            "variable_costs": new_vc,
            "fixed_costs": new_fc,
            "profit": new_profit,
            "profit_impact_eur": profit_impact,
            "profit_impact_pct": profit_impact_pct,
        }
    
    @staticmethod
    def simulate_cost_change(
        base_revenue: float,
        base_variable_costs: float,
        base_fixed_costs: float,
        cost_type: str,  # "variable" or "fixed"
        change_pct: float,
    ) -> Dict:
        """
        Simulate impact of cost change
        
        Args:
            cost_type: "variable" or "fixed"
            change_pct: Change percentage (e.g., -5.0 for 5% reduction)
        
        Returns:
            Dict with impact
        """
        
        new_vc = base_variable_costs
        new_fc = base_fixed_costs
        
        if cost_type == "variable":
            new_vc = base_variable_costs * (1 + change_pct / 100)
            scenario_label = f"Variable Cost {change_pct:+.1f}%"
        else:  # fixed
            new_fc = base_fixed_costs * (1 + change_pct / 100)
            scenario_label = f"Fixed Cost {change_pct:+.1f}%"
        
        # Base and new profit
        base_profit = base_revenue - base_variable_costs - base_fixed_costs
        new_profit = base_revenue - new_vc - new_fc
        
        profit_impact = new_profit - base_profit
        profit_impact_pct = (profit_impact / abs(base_profit) * 100) if base_profit != 0 else 0
        
        return {
            "scenario": scenario_label,
            "revenue": base_revenue,
            "variable_costs": new_vc,
            "fixed_costs": new_fc,
            "profit": new_profit,
            "profit_impact_eur": profit_impact,
            "profit_impact_pct": profit_impact_pct,
        }
    
    @staticmethod
    def simulate_price_change(
        base_revenue: float,
        change_pct: float,
        costi_variabili: float,
        costi_fissi: float,
        price_elasticity: float = -0.5,  # Demand elasticity (typical for B2B: -0.5 to -1.5)
    ) -> Dict:
        """
        Simulate impact of average price change
        
        Assumes demand elasticity (volume drops when price increases)
        
        Args:
            change_pct: Price change (e.g., +5.0 for 5% price increase)
            price_elasticity: Demand elasticity (negative, typical: -0.5 to -1.5)
                              Example: -1.0 means 1% price increase → 1% volume decrease
        
        Returns:
            Dict with impact
        """
        
        # Price increase → volume decrease (or vice versa)
        volume_change_pct = change_pct * price_elasticity
        
        # Revenue change (price effect + volume effect)
        price_multiplier = 1 + (change_pct / 100)
        volume_multiplier = 1 + (volume_change_pct / 100)
        new_revenue = base_revenue * price_multiplier * volume_multiplier
        
        # Variable costs scale with volume
        if base_revenue > 0:
            vc_rate = costi_variabili / base_revenue
        else:
            vc_rate = 0.5
        
        new_vc = new_revenue * vc_rate
        new_fc = costi_fissi
        
        # Impact
        base_profit = base_revenue - costi_variabili - costi_fissi
        new_profit = new_revenue - new_vc - new_fc
        profit_impact = new_profit - base_profit
        profit_impact_pct = (profit_impact / abs(base_profit) * 100) if base_profit != 0 else 0
        
        return {
            "scenario": f"Price {change_pct:+.1f}% (Vol: {volume_change_pct:+.1f}%)",
            "revenue": new_revenue,
            "variable_costs": new_vc,
            "fixed_costs": new_fc,
            "profit": new_profit,
            "profit_impact_eur": profit_impact,
            "profit_impact_pct": profit_impact_pct,
            "elasticity_assumption": f"PED = {price_elasticity}",
        }
    
    @staticmethod
    def build_tornado(
        base_revenue: float,
        base_variable_costs: float,
        base_fixed_costs: float,
        variables: List[str] = None,
    ) -> Dict[str, TornadoData]:
        """
        Build tornado chart data (sensitivity ranges)
        
        Simulates ±10% change for each variable
        
        Args:
            variables: List of variables to test ["revenue", "variable_cost", "fixed_cost"]
        
        Returns:
            Dict of TornadoData for each variable
        """
        
        if variables is None:
            variables = ["revenue", "variable_cost", "fixed_cost"]
        
        base_profit = base_revenue - base_variable_costs - base_fixed_costs
        tornado_data = {}
        
        for var in variables:
            if var == "revenue":
                # Upside: +10% revenue
                upside = SensitivityAnalysis.simulate_revenue_change(
                    base_revenue, +10.0, base_variable_costs, base_fixed_costs
                )
                upside_impact = upside["profit_impact_eur"]
                
                # Downside: -10% revenue
                downside = SensitivityAnalysis.simulate_revenue_change(
                    base_revenue, -10.0, base_variable_costs, base_fixed_costs
                )
                downside_impact = downside["profit_impact_eur"]
                
            elif var == "variable_cost":
                # Upside: -5% variable costs (good thing)
                upside = SensitivityAnalysis.simulate_cost_change(
                    base_revenue, base_variable_costs, base_fixed_costs,
                    "variable", -5.0
                )
                upside_impact = upside["profit_impact_eur"]
                
                # Downside: +5% variable costs (bad thing)
                downside = SensitivityAnalysis.simulate_cost_change(
                    base_revenue, base_variable_costs, base_fixed_costs,
                    "variable", +5.0
                )
                downside_impact = downside["profit_impact_eur"]
                
            elif var == "fixed_cost":
                # Upside: -10% fixed costs
                upside = SensitivityAnalysis.simulate_cost_change(
                    base_revenue, base_variable_costs, base_fixed_costs,
                    "fixed", -10.0
                )
                upside_impact = upside["profit_impact_eur"]
                
                # Downside: +10% fixed costs
                downside = SensitivityAnalysis.simulate_cost_change(
                    base_revenue, base_variable_costs, base_fixed_costs,
                    "fixed", +10.0
                )
                downside_impact = downside["profit_impact_eur"]
            
            else:
                continue
            
            tornado_data[var] = TornadoData(
                variable=var,
                upside_impact_eur=upside_impact,
                downside_impact_eur=downside_impact,
                total_range=abs(upside_impact) + abs(downside_impact),
            )
        
        return tornado_data
    
    @staticmethod
    def rank_by_sensitivity(
        tornado_data: Dict[str, TornadoData],
    ) -> List[Tuple[str, float]]:
        """
        Rank variables by their impact on profit (sensitivity)
        
        Returns:
            List of (variable, total_range) sorted by range descending
        """
        ranked = sorted(
            tornado_data.items(),
            key=lambda x: x[1].total_range,
            reverse=True,
        )
        return [(var, data.total_range) for var, data in ranked]
    
    @staticmethod
    def get_sensitivity_insights(
        base_revenue: float,
        base_variable_costs: float,
        base_fixed_costs: float,
    ) -> List[str]:
        """
        Generate text insights from sensitivity analysis
        """
        
        base_profit = base_revenue - base_variable_costs - base_fixed_costs
        
        insights = []
        
        # Revenue sensitivity
        rev_10pct = SensitivityAnalysis.simulate_revenue_change(
            base_revenue, +10.0, base_variable_costs, base_fixed_costs
        )
        rev_elasticity = rev_10pct["profit_impact_pct"] / 10.0  # % profit change per % revenue change
        
        if rev_elasticity > 2.0:
            insights.append(f"Highly sensitive to revenue: 1% revenue change = {rev_elasticity:.1f}% profit change (high operating leverage)")
        elif rev_elasticity > 1.0:
            insights.append(f"Moderately sensitive to revenue: 1% revenue change = {rev_elasticity:.1f}% profit change")
        else:
            insights.append(f"Low revenue sensitivity: 1% revenue change = {rev_elasticity:.1f}% profit change (low operating leverage)")
        
        # Cost sensitivity
        vc_reduction = SensitivityAnalysis.simulate_cost_change(
            base_revenue, base_variable_costs, base_fixed_costs,
            "variable", -5.0
        )
        vc_impact_5pct = vc_reduction["profit_impact_pct"]
        
        if vc_impact_5pct > 5.0:
            insights.append(f"Variable costs have high leverage: 5% reduction = {vc_impact_5pct:.1f}% profit increase")
        
        # Fixed cost ratio
        if base_revenue > 0:
            fc_ratio = (base_fixed_costs / base_revenue) * 100
            if fc_ratio > 40:
                insights.append(f"⚠️ High fixed cost ratio ({fc_ratio:.0f}% of revenue): reduces flexibility, high breakeven")
            elif fc_ratio > 30:
                insights.append(f"Moderate fixed cost ratio ({fc_ratio:.0f}% of revenue): balanced structure")
            else:
                insights.append(f"Low fixed cost ratio ({fc_ratio:.0f}% of revenue): high flexibility, quick response to downturns")
        
        return insights
