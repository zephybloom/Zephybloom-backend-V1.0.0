"""
Tone & Authority Manager

Select appropriate CFO tone based on situation.
"""

from enum import Enum
from typing import Optional


class CFOTone(str, Enum):
    """Available CFO tones"""
    SOFT = "soft"              # Gentle suggestions (rare)
    COMPETENT = "competent"    # Professional advice
    FIRM = "firm"              # Direct & clear
    DIRECT = "direct"          # Very direct (entrepreneur about to err)
    HARSH = "harsh"            # Blunt (critical issue being ignored)
    MANAGER = "manager"        # Speaking to investors/managers
    MOTIVATOR = "motivator"    # Inspiring but grounded


class ToneManager:
    """Select appropriate tone"""
    
    def select_tone(
        self,
        issue_severity: str,  # "info", "warning", "critical"
        entrepreneur_profile: str,  # "data_driven", "gut_feeling", "resistive"
        previous_ignored_advice: int = 0,  # Times this person ignored advice
        audience: str = "entrepreneur",  # "entrepreneur", "investor", "team"
    ) -> CFOTone:
        """
        Select tone based on context.
        """
        
        # Severity matrix
        if issue_severity == "critical":
            if previous_ignored_advice >= 2:
                return CFOTone.HARSH
            elif entrepreneur_profile == "resistive":
                return CFOTone.DIRECT
            else:
                return CFOTone.FIRM
        
        elif issue_severity == "warning":
            if entrepreneur_profile == "data_driven":
                return CFOTone.COMPETENT
            else:
                return CFOTone.FIRM
        
        elif issue_severity == "info":
            if audience == "investor":
                return CFOTone.COMPETENT
            else:
                return CFOTone.COMPETENT
        
        return CFOTone.COMPETENT
    
    def apply_tone(self, text: str, tone: CFOTone) -> str:
        """
        Adapt message language based on tone.
        """
        
        tone_templates = {
            CFOTone.SOFT: {
                "prefix": "You might consider...",
                "connector": "Perhaps",
                "suffix": "if it feels right",
            },
            CFOTone.COMPETENT: {
                "prefix": "Recommend:",
                "connector": "The data shows",
                "suffix": "Based on financials",
            },
            CFOTone.FIRM: {
                "prefix": "You need to:",
                "connector": "The issue is",
                "suffix": "No debate here",
            },
            CFOTone.DIRECT: {
                "prefix": "Don't",
                "connector": "This will",
                "suffix": "The math doesn't support it",
            },
            CFOTone.HARSH: {
                "prefix": "Stop.",
                "connector": "You're",
                "suffix": "This is a mistake",
            },
            CFOTone.MANAGER: {
                "prefix": "From an investment perspective,",
                "connector": "The KPIs show",
                "suffix": "This improves valuation",
            },
            CFOTone.MOTIVATOR: {
                "prefix": "Here's the opportunity:",
                "connector": "You can",
                "suffix": "Let's make it happen",
            },
        }
        
        # Apply tone (simplified - in real usage, would rewrite entire message)
        template = tone_templates.get(tone, tone_templates[CFOTone.COMPETENT])
        
        return text  # In real implementation, would transform here


class MessageBuilder:
    """Build toned messages"""
    
    @staticmethod
    def build_hiring_recommendation(
        verdict: str,  # yes/no/maybe/wait
        company_margin: float,
        payback_months: int,
        tone: CFOTone,
        reason: Optional[str] = None,
    ) -> str:
        """Build hiring recommendation message"""
        
        if verdict == "yes":
            if tone == CFOTone.HARSH:
                return "Hire. The math works."
            elif tone == CFOTone.DIRECT:
                return "Yes, hire. If you're confident in the person."
            elif tone == CFOTone.FIRM:
                return "Recommendation: Hire. Payback is acceptable and margin is healthy."
            else:
                return "Based on financials, hiring makes sense here."
        
        elif verdict == "no":
            if tone == CFOTone.HARSH:
                return f"Don't hire. Margin at {company_margin}% can't support new fixed costs."
            elif tone == CFOTone.DIRECT:
                return f"No. Not yet. Your margin ({company_margin}%) is too fragile for this cost."
            elif tone == CFOTone.FIRM:
                return f"Not recommended. Payback of {payback_months} months is too long at this margin level."
            else:
                return f"The numbers don't support hiring right now. Wait 3 months."
        
        elif verdict == "maybe":
            if tone == CFOTone.HARSH:
                return "Only if you're 100% certain about this person. Otherwise, wait."
            elif tone == CFOTone.DIRECT:
                return "Maybe. But only if they're top-tier talent. Average doesn't cut it."
            elif tone == CFOTone.FIRM:
                return f"Conditional yes. Payback is {payback_months} months - requires immediate productivity."
            else:
                return "Possible, but with conditions. Monitor cash closely."
        
        else:  # wait
            if tone == CFOTone.HARSH:
                return "Not yet. Build margin first, then hire."
            elif tone == CFOTone.DIRECT:
                return "Wait. Your operating foundation isn't solid enough for this cost."
            elif tone == CFOTone.FIRM:
                return "Hold. Consolidate margin and capacity first, then revisit."
            else:
                return "Recommend waiting 2-3 months while you solidify operations."
    
    @staticmethod
    def build_margin_message(
        current_margin: float,
        target_margin: float,
        tone: CFOTone,
    ) -> str:
        """Build margin improvement message"""
        
        gap = target_margin - current_margin
        
        if tone == CFOTone.HARSH:
            return f"Your margin is {gap}pp below healthy. This is costing you significantly every month. Fix it."
        elif tone == CFOTone.DIRECT:
            return f"Margin needs to move from {current_margin}% to {target_margin}%. This is your priority #1."
        elif tone == CFOTone.FIRM:
            return f"Primary focus: Improve margin by {gap}pp. This unlocks everything else."
        elif tone == CFOTone.COMPETENT:
            return f"To reach healthy state, target {target_margin}% margin (currently {current_margin}%)."
        else:
            return f"Opportunity to improve margin from {current_margin}% to {target_margin}%."
    
    @staticmethod
    def build_wow_moment(
        moment_type: str,  # "leave_money", "assume_costs", "growth_error"
        amount: float,
        tone: CFOTone,
    ) -> str:
        """Build memorable insight"""
        
        if moment_type == "leave_money":
            if tone == CFOTone.HARSH:
                return f"You're leaving €{amount:,.0f} on the table. Every month. Fix it."
            else:
                return f"You have €{amount:,.0f} of potential revenue being left uncaptured."
        
        elif moment_type == "assume_costs":
            if tone == CFOTone.HARSH:
                return f"That hire costs €{amount:,.0f} but only generates half of that. Don't do it yet."
            else:
                return f"Payback period suggests waiting. The numbers will be better in 2 months."
        
        elif moment_type == "growth_error":
            if tone == CFOTone.HARSH:
                return f"Growing right now increases risk by €{amount:,.0f}. You're not ready."
            else:
                return f"Growth should wait. Current structure can't absorb €{amount:,.0f} more complexity."
        
        return ""


def get_manager() -> ToneManager:
    return ToneManager()
