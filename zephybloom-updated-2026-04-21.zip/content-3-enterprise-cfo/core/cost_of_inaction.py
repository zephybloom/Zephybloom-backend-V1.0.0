"""
Cost of Inaction Calculator

Quantify what it costs to do nothing.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class InactionCost:
    """Cost of not taking action"""
    monthly_cost_eur: float  # Cost per month (M)
    quarterly_cost_eur: float  # Cost per quarter (M * 3)
    annual_cost_eur: float  # Cost per year (M * 12)
    timeline_to_crisis: int  # Months until crisis
    primary_risk: str
    secondary_risks: list  # List of secondary risks


class CostOfInactionCalculator:
    """Calculate cost of inaction"""
    
    def calculate_margin_inaction(
        self,
        current_margin: float,
        healthy_margin: float,
        annual_revenue: float,
        delay_weeks: int,
    ) -> InactionCost:
        """
        What does it cost to not improve margin?
        """
        
        # Guard against zero/invalid revenue
        if not annual_revenue or annual_revenue <= 0:
            return InactionCost(
                monthly_cost_eur=0,
                quarterly_cost_eur=0,
                annual_cost_eur=0,
                timeline_to_crisis=0,
                primary_risk="Unable to calculate without valid revenue",
                secondary_risks=[],
            )
        
        margin_gap = healthy_margin - current_margin
        monthly_loss = (annual_revenue / 12) * (margin_gap / 100)
        
        return InactionCost(
            monthly_cost_eur=monthly_loss,
            quarterly_cost_eur=monthly_loss * 3,
            annual_cost_eur=monthly_loss * 12,
            timeline_to_crisis=6,  # 6 months of deterioration before major stress
            primary_risk=f"Losing €{monthly_loss:,.0f}/month in utile",
            secondary_risks=[
                f"Margin gap of {margin_gap}pp prevents strategic investments",
                "Limits ability to weather market downturn",
                "Reduces valuation if seeking investment",
            ],
        )
    
    def calculate_cash_inaction(
        self,
        current_ccc: int,  # days
        healthy_ccc: int,
        daily_cash_burn: float,
        annual_revenue: float,
    ) -> InactionCost:
        """
        What does it cost to not optimize cash?
        """
        
        # Guard against zero/invalid revenue
        if not annual_revenue or annual_revenue <= 0:
            return InactionCost(
                monthly_cost_eur=0,
                quarterly_cost_eur=0,
                annual_cost_eur=0,
                timeline_to_crisis=0,
                primary_risk="Unable to calculate without valid revenue",
                secondary_risks=[],
            )
        
        ccc_gap = current_ccc - healthy_ccc
        if ccc_gap <= 0:
            # No working capital issue
            return InactionCost(
                monthly_cost_eur=0,
                quarterly_cost_eur=0,
                annual_cost_eur=0,
                timeline_to_crisis=0,
                primary_risk="Working capital is healthy",
                secondary_risks=[],
            )
        
        cash_tied_up = (annual_revenue / 365) * ccc_gap
        
        # Monthly financing cost (assume 5% annual cost of capital)
        monthly_financing_cost = cash_tied_up * 0.05 / 12
        
        return InactionCost(
            monthly_cost_eur=monthly_financing_cost,
            quarterly_cost_eur=monthly_financing_cost * 3,
            annual_cost_eur=monthly_financing_cost * 12,
            timeline_to_crisis=12,  # Cash can become crisis in 12 months
            primary_risk=f"€{cash_tied_up:,.0f} locked in working capital (costing €{monthly_financing_cost:,.0f}/month)",
            secondary_risks=[
                f"CCC {ccc_gap} days above healthy levels",
                "Limited flexibility for growth investments",
                "Vulnerable to customer payment delays",
            ],
        )
    
    def calculate_hiring_delay_cost(
        self,
        role_revenue_generation: float,  # EUR/month they'd generate
        months_delayed: int,
    ) -> InactionCost:
        """
        What does it cost to delay hiring?
        """
        
        monthly_cost = role_revenue_generation
        
        return InactionCost(
            monthly_cost_eur=monthly_cost,
            quarterly_cost_eur=monthly_cost * 3,
            annual_cost_eur=monthly_cost * 12,
            timeline_to_crisis=6,  # Capacity constraint becomes crisis
            primary_risk=f"Losing €{monthly_cost:,.0f}/month in unrealized revenue",
            secondary_risks=[
                f"Capacity constraint if you wait {months_delayed}+ months",
                "Risk of losing deals to faster competitors",
                "Team burnout from overwork",
            ],
        )
    
    def calculate_growth_without_quality_cost(
        self,
        current_growth_rate: float,  # %/year
        quality_degradation_slope: float,  # margin loss % per 1% revenue growth
        annual_revenue: float,
        months_to_break_point: int = 12,
    ) -> InactionCost:
        """
        What does it cost to keep growing badly?
        """
        
        projected_margin_loss = current_growth_rate * quality_degradation_slope
        monthly_margin_loss = (annual_revenue / 12) * (projected_margin_loss / 100)
        
        return InactionCost(
            monthly_cost_eur=monthly_margin_loss,
            quarterly_cost_eur=monthly_margin_loss * 3,
            annual_cost_eur=monthly_margin_loss * 12,
            timeline_to_crisis=months_to_break_point,
            primary_risk=f"Eroding €{monthly_margin_loss:,.0f}/month in quality while growing",
            secondary_risks=[
                f"In {months_to_break_point} months, growth stops being profitable",
                "Cash crunch likely as you scale poorly",
                "Difficult to fix once embedded in customer base",
            ],
        )
    
    def calculate_tech_debt_cost(
        self,
        annual_revenue: float,
        productivity_loss_pct: float = 0.15,  # Tech debt causes 15% productivity loss
        months_accumulating: int = 12,
    ) -> InactionCost:
        """
        What does it cost to not address tech debt?
        """
        
        annual_productivity_loss = annual_revenue * (productivity_loss_pct / 100)
        monthly_cost = annual_productivity_loss / 12
        
        return InactionCost(
            monthly_cost_eur=monthly_cost,
            quarterly_cost_eur=monthly_cost * 3,
            annual_cost_eur=monthly_cost * 12,
            timeline_to_crisis=24,  # Gets worse over time
            primary_risk=f"Lost productivity: €{annual_productivity_loss:,.0f}/year ({productivity_loss_pct}% of revenue)",
            secondary_risks=[
                "Team velocity decreases monthly",
                "Morale issues (engineers frustrated)",
                "Defect rate increases",
                "Scaling becomes exponentially harder",
            ],
        )


def get_calculator() -> CostOfInactionCalculator:
    return CostOfInactionCalculator()
