"""Ecommerce CFO calculator."""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def analyze_ecommerce(data: Dict[str, Any]) -> Dict[str, Any]:
    revenue = _num(data.get("annual_revenue") or data.get("fatturato"), 0)
    fixed_costs = _num(data.get("fixed_costs") or data.get("costi_fissi"), 0)
    invested_capital = _num(data.get("invested_capital") or data.get("investimenti"), 0)
    payment_fees_pct = _num(data.get("payment_fees_pct"), 0)
    return_rate_pct = _num(data.get("return_rate_pct"), 0)
    average_order_value = _num(data.get("average_order_value"), 0)
    monthly_orders = _num(data.get("monthly_orders"), 0)
    customer_acquisition_cost = _num(data.get("customer_acquisition_cost"), 0)
    monthly_ad_spend = _num(data.get("monthly_ad_spend"), 0)

    skus = [
        _analyze_sku(row, payment_fees_pct, return_rate_pct)
        for row in data.get("sku_sales", [])
    ]
    skus = [sku for sku in skus if sku["sku"]]

    annual_sku_revenue = sum(sku["monthly_revenue_eur"] for sku in skus) * 12
    effective_revenue = annual_sku_revenue if annual_sku_revenue > 0 else revenue
    annual_contribution = sum(sku["monthly_contribution_eur"] for sku in skus) * 12
    annual_marketing_cost = monthly_ad_spend * 12
    net_profit = annual_contribution - fixed_costs - annual_marketing_cost
    contribution_per_order = _safe_div(annual_contribution, monthly_orders * 12)
    break_even_cac = max(0, contribution_per_order)
    roas = _safe_div(effective_revenue, annual_marketing_cost)

    skus_by_profit = sorted(skus, key=lambda item: item["monthly_contribution_eur"], reverse=True)
    skus_by_margin = sorted(skus, key=lambda item: item["contribution_margin_pct"], reverse=True)
    skus_to_fix = [
        sku for sku in sorted(skus, key=lambda item: (item["contribution_margin_pct"], item["monthly_contribution_eur"]))
        if sku["contribution_margin_pct"] < 20 or sku["monthly_contribution_eur"] < 0
    ]

    return {
        "summary": {
            "annual_revenue_eur": round(effective_revenue, 2),
            "annual_contribution_eur": round(annual_contribution, 2),
            "contribution_margin_pct": _pct(annual_contribution, effective_revenue),
            "annual_marketing_cost_eur": round(annual_marketing_cost, 2),
            "fixed_costs_eur": round(fixed_costs, 2),
            "net_profit_eur": round(net_profit, 2),
            "net_margin_pct": _pct(net_profit, effective_revenue),
            "roi_pct": _pct(net_profit, invested_capital),
            "aov_eur": round(average_order_value, 2),
            "monthly_orders": round(monthly_orders, 2),
            "cac_eur": round(customer_acquisition_cost, 2),
            "break_even_cac_eur": round(break_even_cac, 2),
            "roas": round(roas, 2),
            "return_rate_pct": round(return_rate_pct, 2),
        },
        "top_skus_by_profit": skus_by_profit[:10],
        "top_skus_by_margin": skus_by_margin[:10],
        "skus_to_fix": skus_to_fix[:10],
        "recommendations": _recommendations(
            contribution_margin_pct=_pct(annual_contribution, effective_revenue),
            net_margin_pct=_pct(net_profit, effective_revenue),
            customer_acquisition_cost=customer_acquisition_cost,
            break_even_cac=break_even_cac,
            roas=roas,
            skus_to_fix=skus_to_fix,
            top_skus=skus_by_profit,
        ),
    }


def simulate_ecommerce(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    base_data = _copy_ecommerce_data(data)
    scenario_data = _apply_ecommerce_scenario(_copy_ecommerce_data(data), scenario)
    base = analyze_ecommerce(base_data)
    simulated = analyze_ecommerce(scenario_data)
    base_summary = base["summary"]
    simulated_summary = simulated["summary"]

    return {
        "scenario_name": scenario.get("name") or "Scenario ecommerce",
        "base": base,
        "simulated": simulated,
        "delta": {
            "annual_revenue_eur": round(simulated_summary["annual_revenue_eur"] - base_summary["annual_revenue_eur"], 2),
            "net_profit_eur": round(simulated_summary["net_profit_eur"] - base_summary["net_profit_eur"], 2),
            "net_margin_pct": round(simulated_summary["net_margin_pct"] - base_summary["net_margin_pct"], 2),
            "contribution_margin_pct": round(simulated_summary["contribution_margin_pct"] - base_summary["contribution_margin_pct"], 2),
            "break_even_cac_eur": round(simulated_summary["break_even_cac_eur"] - base_summary["break_even_cac_eur"], 2),
            "roas": round(simulated_summary["roas"] - base_summary["roas"], 2),
            "roi_pct": round(simulated_summary["roi_pct"] - base_summary["roi_pct"], 2),
        },
        "decision": _scenario_decision(base_summary, simulated_summary),
        "applied_scenario": scenario,
    }


def _copy_ecommerce_data(data: Dict[str, Any]) -> Dict[str, Any]:
    copied = dict(data or {})
    copied["sku_sales"] = [dict(row) for row in data.get("sku_sales", [])]
    return copied


def _apply_ecommerce_scenario(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    price_delta_pct = _num(scenario.get("price_delta_pct"), 0)
    volume_delta_pct = _num(scenario.get("volume_delta_pct") or scenario.get("orders_delta_pct"), 0)
    purchase_cost_delta_pct = _num(scenario.get("purchase_cost_delta_pct"), 0)
    shipping_cost_delta_pct = _num(scenario.get("shipping_cost_delta_pct"), 0)
    return_rate_delta_pct = _num(scenario.get("return_rate_delta_pct"), 0)
    ad_spend_delta_pct = _num(scenario.get("ad_spend_delta_pct"), 0)
    cac_delta_pct = _num(scenario.get("cac_delta_pct"), 0)
    target_sku = str(scenario.get("target_sku") or "").strip().lower()

    if price_delta_pct:
        for sku in data.get("sku_sales", []):
            if not target_sku or str(sku.get("sku", "")).strip().lower() == target_sku:
                sku["price"] = _num(sku.get("price") or sku.get("unit_price"), 0) * (1 + price_delta_pct / 100)
        if not target_sku:
            data["annual_revenue"] = _num(data.get("annual_revenue") or data.get("fatturato"), 0) * (1 + price_delta_pct / 100)
            data["average_order_value"] = _num(data.get("average_order_value"), 0) * (1 + price_delta_pct / 100)

    if volume_delta_pct:
        data["monthly_orders"] = _num(data.get("monthly_orders"), 0) * (1 + volume_delta_pct / 100)
        data["annual_revenue"] = _num(data.get("annual_revenue") or data.get("fatturato"), 0) * (1 + volume_delta_pct / 100)
        for sku in data.get("sku_sales", []):
            sku["monthly_units"] = _num(sku.get("monthly_units") or sku.get("quantity"), 0) * (1 + volume_delta_pct / 100)

    if purchase_cost_delta_pct:
        for sku in data.get("sku_sales", []):
            sku["purchase_cost"] = _num(sku.get("purchase_cost") or sku.get("cost") or sku.get("cogs"), 0) * (1 + purchase_cost_delta_pct / 100)

    if shipping_cost_delta_pct:
        for sku in data.get("sku_sales", []):
            sku["shipping_cost"] = _num(sku.get("shipping_cost") or sku.get("shipping_cost_per_order"), 0) * (1 + shipping_cost_delta_pct / 100)

    if return_rate_delta_pct:
        data["return_rate_pct"] = max(0, _num(data.get("return_rate_pct"), 0) + return_rate_delta_pct)

    if ad_spend_delta_pct:
        data["monthly_ad_spend"] = _num(data.get("monthly_ad_spend"), 0) * (1 + ad_spend_delta_pct / 100)

    if cac_delta_pct:
        data["customer_acquisition_cost"] = _num(data.get("customer_acquisition_cost"), 0) * (1 + cac_delta_pct / 100)

    return data


def _scenario_decision(base_summary: Dict[str, Any], simulated_summary: Dict[str, Any]) -> str:
    profit_delta = simulated_summary["net_profit_eur"] - base_summary["net_profit_eur"]
    margin_delta = simulated_summary["net_margin_pct"] - base_summary["net_margin_pct"]
    cac_ok = simulated_summary["cac_eur"] <= simulated_summary["break_even_cac_eur"] if simulated_summary["cac_eur"] else True

    if profit_delta > 0 and margin_delta >= 0 and cac_ok:
        return "GO: aumenta utile, margine e CAC sostenibile."
    if profit_delta > 0 and cac_ok:
        return "TEST: utile in crescita, controlla erosione margine."
    if profit_delta > 0:
        return "CAUTION: utile cresce ma CAC sopra break-even."
    return "NO GO: scenario non crea utile incrementale."


def _analyze_sku(row: Dict[str, Any], payment_fees_pct: float, return_rate_pct: float) -> Dict[str, Any]:
    sku = str(row.get("sku") or row.get("product") or row.get("name") or "").strip()
    price = _num(row.get("price") or row.get("unit_price"), 0)
    purchase_cost = _num(row.get("purchase_cost") or row.get("cost") or row.get("cogs"), 0)
    monthly_units = _num(row.get("monthly_units") or row.get("quantity"), 0)
    shipping_cost = _num(row.get("shipping_cost") or row.get("shipping_cost_per_order"), 0)
    marketplace_fee_pct = _num(row.get("marketplace_fee_pct"), 0)
    return_override_pct = _num(row.get("return_rate_pct"), return_rate_pct)
    payment_cost = price * payment_fees_pct / 100
    marketplace_cost = price * marketplace_fee_pct / 100
    expected_return_cost = price * return_override_pct / 100
    direct_cost = purchase_cost + shipping_cost + payment_cost + marketplace_cost + expected_return_cost
    contribution = price - direct_cost

    return {
        "sku": sku,
        "price_eur": round(price, 2),
        "purchase_cost_eur": round(purchase_cost, 2),
        "shipping_cost_eur": round(shipping_cost, 2),
        "payment_cost_eur": round(payment_cost, 2),
        "marketplace_cost_eur": round(marketplace_cost, 2),
        "expected_return_cost_eur": round(expected_return_cost, 2),
        "contribution_per_unit_eur": round(contribution, 2),
        "contribution_margin_pct": _pct(contribution, price),
        "monthly_units": round(monthly_units, 2),
        "monthly_revenue_eur": round(price * monthly_units, 2),
        "monthly_contribution_eur": round(contribution * monthly_units, 2),
        "decision": _sku_decision(contribution, _pct(contribution, price), monthly_units),
    }


def _sku_decision(contribution: float, margin_pct: float, monthly_units: float) -> str:
    if contribution < 0:
        return "stop_or_reprice"
    if margin_pct < 20 and monthly_units > 0:
        return "reprice_reduce_cost_or_bundle"
    if margin_pct >= 35 and monthly_units > 0:
        return "scale_if_cac_fits"
    return "monitor"


def _recommendations(
    contribution_margin_pct: float,
    net_margin_pct: float,
    customer_acquisition_cost: float,
    break_even_cac: float,
    roas: float,
    skus_to_fix: List[Dict[str, Any]],
    top_skus: List[Dict[str, Any]],
) -> List[str]:
    recs: List[str] = []
    if customer_acquisition_cost and customer_acquisition_cost > break_even_cac:
        recs.append(f"CAC {customer_acquisition_cost:.0f} sopra break-even {break_even_cac:.0f}: riduci ads o aumenta AOV/margine.")
    if roas and roas < 2.5:
        recs.append(f"ROAS {roas:.1f}: scala solo canali con margine post-resi positivo.")
    if contribution_margin_pct < 30:
        recs.append(f"Margine contributivo {contribution_margin_pct:.1f}%: rivedi prezzo, spedizioni, fee e resi.")
    if net_margin_pct < 10:
        recs.append(f"Margine netto {net_margin_pct:.1f}%: controlla costi fissi e marketing prima di aumentare budget.")
    if skus_to_fix:
        recs.append("SKU da correggere: " + ", ".join(item["sku"] for item in skus_to_fix[:3]))
    if top_skus:
        recs.append("SKU da spingere se CAC regge: " + ", ".join(item["sku"] for item in top_skus[:3]))
    return recs[:6]


def _num(value: Optional[Any], default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _safe_div(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return numerator / denominator


def _pct(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 2)
