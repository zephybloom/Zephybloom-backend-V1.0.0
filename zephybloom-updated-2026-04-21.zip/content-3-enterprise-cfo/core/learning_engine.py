"""
Learning Engine - Improve decisions based on real outcomes

Tracks what worked, what didn't, and adjusts future decision-making.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
import json
from datetime import datetime, timedelta


@dataclass
class DecisionTypeMetric:
    """Metrics for a specific decision type (e.g., "Hiring", "Pricing")"""
    decision_type: str
    total_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    success_rate: float = 0.0  # 0-1
    average_impact_variance: float = 0.0  # % deviation from target
    adjustment_factor: float = 1.0  # Multiply estimates by this (1.0 = no adjustment)


@dataclass
class LearningState:
    """Current learning state of the system"""
    last_updated: datetime = field(default_factory=datetime.utcnow)
    decisions_analyzed: int = 0
    
    # Per decision type
    decision_metrics: Dict[str, DecisionTypeMetric] = field(default_factory=dict)
    
    # Global patterns
    most_successful_types: List[str] = field(default_factory=list)
    most_difficult_types: List[str] = field(default_factory=list)
    
    # Overall health
    overall_accuracy_rate: float = 0.0  # 0-1
    overall_implementation_rate: float = 0.0  # 0-1
    
    # Learning notes
    notes: List[str] = field(default_factory=list)


class LearningEngine:
    """Learn from decision outcomes and adjust future estimates"""
    
    def __init__(self):
        self.state = LearningState()
        self.min_decisions_per_type = 3  # Need at least 3 to learn pattern
    
    def record_decision_outcome(
        self,
        decision_type: str,
        expected_impact_eur: float,
        actual_impact_eur: float,
    ) -> None:
        """
        Record that a decision was made and here's what happened.
        
        Args:
            decision_type: "Increase Gross Margin", "Reduce Fixed Costs", etc.
            expected_impact_eur: What we predicted
            actual_impact_eur: What actually happened
        """
        
        if decision_type not in self.state.decision_metrics:
            self.state.decision_metrics[decision_type] = DecisionTypeMetric(
                decision_type=decision_type
            )
        
        metric = self.state.decision_metrics[decision_type]
        metric.total_count += 1
        
        # Check if it was a success (within 20% of target)
        if expected_impact_eur != 0:
            variance = ((actual_impact_eur - expected_impact_eur) / abs(expected_impact_eur)) * 100
            
            metric.average_impact_variance = (
                (metric.average_impact_variance * (metric.total_count - 1) + variance) /
                metric.total_count
            )
            
            if abs(variance) <= 20:
                metric.success_count += 1
            elif actual_impact_eur < expected_impact_eur * 0.5:
                metric.failure_count += 1
        
        # Recalculate metrics
        self._recalculate_metrics()
    
    def _recalculate_metrics(self) -> None:
        """Recalculate all metrics based on recorded outcomes"""
        
        # Success rates and adjustment factors
        for decision_type, metric in self.state.decision_metrics.items():
            if metric.total_count > 0:
                metric.success_rate = metric.success_count / metric.total_count
                
                # Adjustment factor: if we consistently under/over-estimate
                if metric.average_impact_variance != 0:
                    # If actual impact is +20% vs expected, future estimates should increase.
                    # If actual impact is -20% vs expected, future estimates should decrease.
                    adjustment = 1.0 + (metric.average_impact_variance / 100.0)
                    metric.adjustment_factor = max(0.5, min(1.5, adjustment))  # Clamp to 0.5-1.5
        
        # Identify patterns
        successful_types = [
            dtype for dtype, metric in self.state.decision_metrics.items()
            if metric.total_count >= self.min_decisions_per_type and metric.success_rate > 0.7
        ]
        
        difficult_types = [
            dtype for dtype, metric in self.state.decision_metrics.items()
            if metric.total_count >= self.min_decisions_per_type and metric.success_rate < 0.4
        ]
        
        self.state.most_successful_types = sorted(
            successful_types, 
            key=lambda dt: self.state.decision_metrics[dt].success_rate,
            reverse=True
        )
        
        self.state.most_difficult_types = sorted(
            difficult_types,
            key=lambda dt: self.state.decision_metrics[dt].success_rate
        )
        
        self.state.last_updated = datetime.utcnow()
    
    def get_adjustment_factor(self, decision_type: str) -> float:
        """
        What factor should we apply to estimates for this decision type?
        
        Example: If hiring decisions tend to be 30% larger than expected,
        return 0.7 to make future hiring estimates more conservative.
        
        Args:
            decision_type: The type of decision
        
        Returns:
            Adjustment factor (1.0 = no adjustment, default for unknown types)
        """
        
        if decision_type not in self.state.decision_metrics:
            return 1.0
        
        metric = self.state.decision_metrics[decision_type]
        
        # Only adjust if we have enough data
        if metric.total_count < self.min_decisions_per_type:
            return 1.0
        
        return metric.adjustment_factor
    
    def should_prioritize(self, decision_type: str) -> bool:
        """
        Should this decision type be prioritized in recommendations?
        
        Yes if: consistently successful + high success rate
        
        Args:
            decision_type: The type of decision
        
        Returns:
            True if should be prioritized
        """
        
        if decision_type not in self.state.decision_metrics:
            return False
        
        metric = self.state.decision_metrics[decision_type]
        
        return (
            metric.total_count >= self.min_decisions_per_type and
            metric.success_rate > 0.75  # 75%+ success rate
        )
    
    def should_deprioritize(self, decision_type: str) -> bool:
        """
        Should this decision type be deprioritized or flagged for review?
        
        Yes if: consistently failing or highly unpredictable
        
        Args:
            decision_type: The type of decision
        
        Returns:
            True if should be deprioritized
        """
        
        if decision_type not in self.state.decision_metrics:
            return False
        
        metric = self.state.decision_metrics[decision_type]
        
        return (
            metric.total_count >= self.min_decisions_per_type and
            metric.success_rate < 0.4  # Less than 40% success
        )
    
    def get_learning_summary(self) -> str:
        """
        Generate human-readable summary of what's been learned.
        
        Returns:
            Summary text
        """
        
        summary = []
        summary.append(f"Learning State (updated {self.state.last_updated.strftime('%Y-%m-%d')})")
        summary.append(f"Decisions analyzed: {self.state.decisions_analyzed}")
        summary.append(f"Overall accuracy: {self.state.overall_accuracy_rate:.1%}")
        summary.append(f"Overall implementation: {self.state.overall_implementation_rate:.1%}")
        summary.append("")
        
        if self.state.most_successful_types:
            summary.append(f"✅ Most successful: {', '.join(self.state.most_successful_types)}")
        
        if self.state.most_difficult_types:
            summary.append(f"⚠️ Most difficult: {', '.join(self.state.most_difficult_types)}")
        
        summary.append("")
        summary.append("Decision type metrics:")
        for dtype, metric in sorted(self.state.decision_metrics.items()):
            if metric.total_count > 0:
                summary.append(f"  {dtype}:")
                summary.append(f"    - Success rate: {metric.success_rate:.1%}")
                summary.append(f"    - Adjustment factor: {metric.adjustment_factor:.2f}x")
                summary.append(f"    - Average variance: {metric.average_impact_variance:+.1f}%")
        
        return "\n".join(summary)
    
    def export_state(self) -> str:
        """Export learning state as JSON for persistence"""
        
        state_dict = {
            "last_updated": self.state.last_updated.isoformat(),
            "decisions_analyzed": self.state.decisions_analyzed,
            "overall_accuracy_rate": self.state.overall_accuracy_rate,
            "overall_implementation_rate": self.state.overall_implementation_rate,
            "most_successful_types": self.state.most_successful_types,
            "most_difficult_types": self.state.most_difficult_types,
            "decision_metrics": {
                dtype: {
                    "total_count": m.total_count,
                    "success_count": m.success_count,
                    "failure_count": m.failure_count,
                    "success_rate": m.success_rate,
                    "average_impact_variance": m.average_impact_variance,
                    "adjustment_factor": m.adjustment_factor,
                }
                for dtype, m in self.state.decision_metrics.items()
            },
        }
        
        return json.dumps(state_dict, indent=2)
    
    def import_state(self, json_str: str) -> None:
        """Import learning state from JSON"""
        
        state_dict = json.loads(json_str)
        
        self.state.last_updated = datetime.fromisoformat(state_dict["last_updated"])
        self.state.decisions_analyzed = state_dict["decisions_analyzed"]
        self.state.overall_accuracy_rate = state_dict["overall_accuracy_rate"]
        self.state.overall_implementation_rate = state_dict["overall_implementation_rate"]
        self.state.most_successful_types = state_dict["most_successful_types"]
        self.state.most_difficult_types = state_dict["most_difficult_types"]
        
        for dtype, m_dict in state_dict["decision_metrics"].items():
            self.state.decision_metrics[dtype] = DecisionTypeMetric(
                decision_type=dtype,
                total_count=m_dict["total_count"],
                success_count=m_dict["success_count"],
                failure_count=m_dict["failure_count"],
                success_rate=m_dict["success_rate"],
                average_impact_variance=m_dict["average_impact_variance"],
                adjustment_factor=m_dict["adjustment_factor"],
            )


# Global singleton for learning state (in production, would be cached/persisted)
_learning_engine: Optional[LearningEngine] = None


def get_learning_engine() -> LearningEngine:
    """Get or create the global learning engine singleton"""
    global _learning_engine
    if _learning_engine is None:
        _learning_engine = LearningEngine()
    return _learning_engine


def set_learning_engine(engine: LearningEngine) -> None:
    """Set the global learning engine (for testing)"""
    global _learning_engine
    _learning_engine = engine
