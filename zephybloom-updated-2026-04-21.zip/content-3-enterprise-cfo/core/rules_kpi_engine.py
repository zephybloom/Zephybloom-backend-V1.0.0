# -*- coding: utf-8 -*-
# content/core/rules_kpi_engine.py — Regole/alert/benchmark sopra i KPI (compatibile con kpi_engine)
from __future__ import annotations
from typing import Dict, Any, List, Optional

# Solo per typing (nessun import di funzioni dal motore per evitare cicli)
try:
    from core.kpi_engine import KPIOptions  # type: ignore
except Exception:
    # fallback typing-light
    class KPIOptions:  # type: ignore
        sector: str = "default"

def _alert(code: str, message: str, severity: str = "info", meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {"code": code, "message": message, "severity": severity, "meta": meta or {}}

def _f(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        return 0.0 if v != v else v  # NaN -> 0
    except Exception:
        return default

def _load_dynamic_benchmarks(kpi: Dict[str, Any], sector_fallback: str) -> Dict[str, float]:
    """
    Se il motore ha già calcolato i benchmark, li recupera da:
    kpi["_extras"]["benchmarks"]["benchmarks"].
    Altrimenti usa fallback coerenti.
    """
    try:
        bm = kpi.get("_extras", {}).get("benchmarks", {}).get("benchmarks", None)
        if isinstance(bm, dict) and bm:
            # Normalizza chiavi attese
            return {
                "gross_margin_rate_min": _f(bm.get("gross_margin_rate_min"), 0.35),
                "ebitda_margin_rate_min": _f(bm.get("ebitda_margin_rate_min"), 0.12),
                "net_margin_rate_min": _f(bm.get("net_margin_rate_min"), 0.06),
                "roi_pct_min": _f(bm.get("roi_pct_min"), 10.0),
                "ccc_days_max": _f(bm.get("ccc_days_max"), 70.0),
                "zscore_min": _f(bm.get("zscore_min"), 1.8),
            }
    except Exception:
        pass

    # Fallback di sicurezza (default “generalista”)
    return {
        "gross_margin_rate_min": 0.35,
        "ebitda_margin_rate_min": 0.12,
        "net_margin_rate_min": 0.06,
        "roi_pct_min": 10.0,
        "ccc_days_max": 70.0,
        "zscore_min": 1.8,
    }

def apply_rules(kpi: Dict[str, Any], options: KPIOptions) -> Dict[str, Any]:
    """
    Arricchisce il dict KPI con una lista 'alerts' (senza mai sollevare eccezioni).
    Compatibile con i campi del motore:
      - usa alias 'ccc' o 'ccc_days'
      - considera 'net_profit' (pre-tax) e 'net_income' (post-tax) se presenti
      - sfrutta benchmark dinamici calcolati dal motore quando disponibili
    """
    alerts: List[Dict[str, Any]] = []
    try:
        # ---- Lettura KPI robusta
        roi_pct = _f(kpi.get("roi_pct"))
        net_margin_rate = _f(kpi.get("net_margin_rate"))  # post-tax (se tassazione attiva)
        # in assenza di net_margin_rate, prova una proxy su utile pre-tax:
        if net_margin_rate == 0.0 and kpi.get("net_profit") is not None and _f(kpi.get("sales")) > 0:
            net_margin_rate = max(0.0, _f(kpi.get("net_profit")) / max(1e-9, _f(kpi.get("sales"))))

        ccc = _f(kpi.get("ccc", kpi.get("ccc_days")))
        z = _f(kpi.get("altman_z"))

        # Benchmark dinamici (o fallback)
        bm = _load_dynamic_benchmarks(kpi, getattr(options, "sector", "default"))

        # ---- Regole base
        if roi_pct < bm["roi_pct_min"]:
            alerts.append(_alert(
                "ROI_LOW",
                f"ROI sotto soglia: {roi_pct:.2f}% (< {bm['roi_pct_min']:.0f}%).",
                "info",
                {"roi_pct": roi_pct, "min": bm["roi_pct_min"]}
            ))

        if net_margin_rate < bm["net_margin_rate_min"]:
            alerts.append(_alert(
                "NET_MARGIN_LOW",
                f"Net margin sotto soglia: {net_margin_rate:.2%} (< {bm['net_margin_rate_min']:.0%}).",
                "info",
                {"net_margin_rate": net_margin_rate, "min": bm["net_margin_rate_min"]}
            ))

        if ccc > bm["ccc_days_max"]:
            alerts.append(_alert(
                "CCC_HIGH",
                f"Ciclo di cassa alto: {ccc:.0f} giorni (> {bm['ccc_days_max']:.0f}).",
                "warning",
                {"ccc": ccc, "max": bm["ccc_days_max"]}
            ))

        # z==0 può voler dire “non calcolabile”; evitiamo falsi positivi
        if z > 0.0 and z < bm["zscore_min"]:
            alerts.append(_alert(
                "ZSCORE_RISK",
                "Altman Z-score in zona rossa.",
                "critical",
                {"z": z, "min": bm["zscore_min"]}
            ))

        # ---- Deduplica eventuali doppi alert (stesso code)
        dedup: Dict[str, Dict[str, Any]] = {}
        for a in alerts:
            dedup[a["code"]] = a
        kpi["alerts"] = list(dedup.values())

        # Per comodità in API
        kpi["_diag"] = kpi.get("_diag", {})
        kpi["_diag"]["alerts_count"] = len(kpi["alerts"])

    except Exception as e:
        # Non bloccare mai il calcolo per colpa delle regole
        kpi.setdefault("_diag", {})["rules_error"] = str(e)
        kpi.setdefault("alerts", [])

    return kpi
