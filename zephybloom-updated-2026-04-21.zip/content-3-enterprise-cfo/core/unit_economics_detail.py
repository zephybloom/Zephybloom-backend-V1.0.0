"""Granular customer/product profitability analysis.

This is the premium layer that moves the product from aggregate CFO advice to
actionable margin intelligence: which customers, products and suppliers create
or destroy value.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional


def analyze_unit_economics(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    normalized = [_normalize_row(row) for row in rows]
    normalized = [row for row in normalized if row["revenue"] > 0 or row["quantity"] > 0]

    product_map = defaultdict(_empty_bucket)
    customer_map = defaultdict(_empty_bucket)
    supplier_map = defaultdict(_empty_bucket)

    total_revenue = 0.0
    total_direct_cost = 0.0
    total_profit = 0.0

    for row in normalized:
        revenue = row["revenue"]
        direct_cost = row["direct_cost"]
        profit = revenue - direct_cost - row["discounts"] - row["commissions"] - row["logistics_cost"]
        quantity = row["quantity"]
        supplier_spend = row["purchase_price"] * quantity if row["purchase_price"] else direct_cost

        total_revenue += revenue
        total_direct_cost += direct_cost
        total_profit += profit

        _add_to_bucket(product_map[row["product"]], row, revenue, direct_cost, profit, supplier_spend)
        _add_to_bucket(customer_map[row["customer"]], row, revenue, direct_cost, profit, supplier_spend)
        _add_to_bucket(supplier_map[row["supplier"]], row, revenue, direct_cost, profit, supplier_spend)

    products = [_finalize_bucket(name, bucket, "product") for name, bucket in product_map.items()]
    customers = [_finalize_bucket(name, bucket, "customer") for name, bucket in customer_map.items()]
    suppliers = [_finalize_bucket(name, bucket, "supplier") for name, bucket in supplier_map.items()]

    products_by_margin = sorted(products, key=lambda item: (item["gross_margin_pct"], item["profit_eur"]), reverse=True)
    products_by_profit = sorted(products, key=lambda item: item["profit_eur"], reverse=True)
    customers_by_profit = sorted(customers, key=lambda item: item["profit_eur"], reverse=True)
    suppliers_by_spend = sorted(suppliers, key=lambda item: item["supplier_spend_eur"], reverse=True)

    return {
        "row_count": len(normalized),
        "totals": {
            "revenue_eur": round(total_revenue, 2),
            "direct_cost_eur": round(total_direct_cost, 2),
            "profit_eur": round(total_profit, 2),
            "gross_margin_pct": _pct(total_revenue - total_direct_cost, total_revenue),
            "net_contribution_pct": _pct(total_profit, total_revenue),
        },
        "top_products_by_margin": products_by_margin[:10],
        "top_products_by_profit": products_by_profit[:10],
        "top_customers_by_profit": customers_by_profit[:10],
        "products_to_fix": [
            item for item in sorted(products, key=lambda product: (product["gross_margin_pct"], product["profit_eur"]))
            if item["gross_margin_pct"] < 25 or item["profit_eur"] < 0
        ][:10],
        "suppliers_to_renegotiate": suppliers_by_spend[:10],
        "recommendations": _recommendations(products, customers, suppliers, total_revenue, total_profit),
    }


def _normalize_row(row: Dict[str, Any]) -> Dict[str, Any]:
    quantity = _num(row.get("quantity"), 1)
    unit_price = _num(row.get("unit_price"), 0)
    revenue = _num(row.get("revenue"), 0) or unit_price * quantity
    purchase_price = _num(row.get("purchase_price"), 0)
    direct_cost = _num(row.get("direct_cost"), 0) or purchase_price * quantity

    return {
        "customer": str(row.get("customer") or row.get("customer_name") or "Cliente non specificato").strip(),
        "product": str(row.get("product") or row.get("sku") or row.get("service") or "Prodotto non specificato").strip(),
        "supplier": str(row.get("supplier") or row.get("vendor") or "Fornitore non specificato").strip(),
        "quantity": quantity,
        "unit_price": unit_price,
        "purchase_price": purchase_price,
        "revenue": revenue,
        "direct_cost": direct_cost,
        "discounts": _num(row.get("discounts"), 0),
        "commissions": _num(row.get("commissions"), 0),
        "logistics_cost": _num(row.get("logistics_cost"), 0),
    }


def _empty_bucket() -> Dict[str, Any]:
    return {
        "revenue": 0.0,
        "direct_cost": 0.0,
        "profit": 0.0,
        "quantity": 0.0,
        "supplier_spend": 0.0,
        "products": set(),
        "customers": set(),
        "suppliers": set(),
    }


def _add_to_bucket(bucket: Dict[str, Any], row: Dict[str, Any], revenue: float, direct_cost: float, profit: float, supplier_spend: float) -> None:
    bucket["revenue"] += revenue
    bucket["direct_cost"] += direct_cost
    bucket["profit"] += profit
    bucket["quantity"] += row["quantity"]
    bucket["supplier_spend"] += supplier_spend
    bucket["products"].add(row["product"])
    bucket["customers"].add(row["customer"])
    bucket["suppliers"].add(row["supplier"])


def _finalize_bucket(name: str, bucket: Dict[str, Any], key_name: str) -> Dict[str, Any]:
    return {
        key_name: name,
        "revenue_eur": round(bucket["revenue"], 2),
        "direct_cost_eur": round(bucket["direct_cost"], 2),
        "profit_eur": round(bucket["profit"], 2),
        "gross_margin_pct": _pct(bucket["revenue"] - bucket["direct_cost"], bucket["revenue"]),
        "net_contribution_pct": _pct(bucket["profit"], bucket["revenue"]),
        "quantity": round(bucket["quantity"], 2),
        "supplier_spend_eur": round(bucket["supplier_spend"], 2),
        "product_count": len(bucket["products"]),
        "customer_count": len(bucket["customers"]),
        "supplier_count": len(bucket["suppliers"]),
    }


def _recommendations(products: List[Dict[str, Any]], customers: List[Dict[str, Any]], suppliers: List[Dict[str, Any]], total_revenue: float, total_profit: float) -> List[str]:
    recs: List[str] = []
    low_margin = [p for p in products if p["gross_margin_pct"] < 25]
    loss_products = [p for p in products if p["profit_eur"] < 0]
    top_customers = sorted(customers, key=lambda c: c["profit_eur"], reverse=True)[:3]
    top_suppliers = sorted(suppliers, key=lambda s: s["supplier_spend_eur"], reverse=True)[:3]

    if top_customers:
        recs.append("Spingi clienti simili ai top 3 per utile: " + ", ".join(c["customer"] for c in top_customers))
    if loss_products:
        recs.append("Rivedi o elimina prodotti in perdita: " + ", ".join(p["product"] for p in loss_products[:3]))
    elif low_margin:
        recs.append("Riprezza prodotti sotto 25% margine lordo: " + ", ".join(p["product"] for p in low_margin[:3]))
    if top_suppliers:
        recs.append("Rinegozia prima i fornitori con spesa piu' alta: " + ", ".join(s["supplier"] for s in top_suppliers))
    if total_revenue > 0:
        recs.append(f"Margine contributivo totale: {_pct(total_profit, total_revenue):.1f}%. Usa questo come baseline per nuovi clienti/prodotti.")

    return recs[:5]


def _num(value: Optional[Any], default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _pct(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 2)
