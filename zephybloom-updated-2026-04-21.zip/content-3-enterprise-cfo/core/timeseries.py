"""
CFO Time Series Analysis Engine - CAGR, trends, volatility

Analyzes historical KPI data to identify:
- Compound annual growth rate (CAGR)
- YoY growth rates
- Trend direction (improving/declining/stable)
- Volatility and stability
- Forecast (simple extrapolation)
"""

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import date, datetime
import statistics
import math


# ============================================
# DATA MODELS
# ============================================

@dataclass
class TrendPoint:
    """Single data point in time series"""
    period_date: date
    value: float
    period_days: int = 365  # Default: annual


@dataclass
class TrendResult:
    """Result of trend analysis"""
    metric_name: str
    num_periods: int
    start_value: Optional[float]
    end_value: Optional[float]
    cagr_pct: Optional[float]  # Compound annual growth rate
    latest_growth_pct: Optional[float]  # Latest YoY
    trend_direction: str  # "improving", "declining", "stable"
    volatility_pct: Optional[float]  # Standard deviation
    predicted_value: Optional[float]  # Simple forecast
    predicted_value_date: Optional[date]  # Forecast date


# ============================================
# TREND ANALYSIS ENGINE
# ============================================

class TimeSeriesAnalysis:
    """Analyze time series of financial metrics"""
    
    @staticmethod
    def calculate_cagr(
        start_value: float,
        end_value: float,
        num_years: int,
    ) -> Optional[float]:
        """
        Calculate Compound Annual Growth Rate
        
        Formula: CAGR = (EV/BV)^(1/n) - 1
        
        Args:
            start_value: Beginning value
            end_value: Ending value
            num_years: Number of years
        
        Returns:
            CAGR as percentage (e.g., 15.5 for 15.5%)
        """
        if not start_value or not end_value or num_years <= 0:
            return None
        
        if start_value < 0 or end_value < 0:
            return None
        
        try:
            ratio = end_value / start_value
            cagr = (ratio ** (1 / num_years) - 1) * 100
            return round(cagr, 2)
        except (ZeroDivisionError, ValueError):
            return None
    
    @staticmethod
    def calculate_yoy_growth(
        prior_value: float,
        current_value: float,
    ) -> Optional[float]:
        """
        Calculate Year-over-Year growth rate
        
        Formula: YoY = (Current - Prior) / Prior
        """
        if prior_value == 0:
            return None
        
        try:
            growth = ((current_value - prior_value) / abs(prior_value)) * 100
            return round(growth, 2)
        except (ZeroDivisionError, TypeError):
            return None
    
    @staticmethod
    def determine_trend(values: List[float], min_periods: int = 3) -> str:
        """
        Determine if trend is improving, declining, or stable
        
        Uses simple linear regression direction
        
        Args:
            values: List of values (in chronological order)
            min_periods: Minimum periods required
        
        Returns:
            "improving", "declining", or "stable"
        """
        if len(values) < min_periods:
            return "stable"
        
        # Simple method: compare first half vs second half
        mid = len(values) // 2
        first_half_avg = sum(values[:mid]) / len(values[:mid]) if mid > 0 else values[0]
        second_half_avg = sum(values[mid:]) / len(values[mid:]) if len(values[mid:]) > 0 else values[-1]
        
        if first_half_avg == 0:
            return "stable"
        
        change_pct = abs((second_half_avg - first_half_avg) / first_half_avg)
        
        if change_pct < 0.05:  # <5% change
            return "stable"
        elif second_half_avg > first_half_avg:
            return "improving"
        else:
            return "declining"
    
    @staticmethod
    def calculate_volatility(values: List[float]) -> Optional[float]:
        """
        Calculate volatility (standard deviation) of values
        
        Expressed as % of mean
        
        Returns:
            Coefficient of variation (%)
        """
        if len(values) < 2:
            return None
        
        try:
            mean = statistics.mean(values)
            stdev = statistics.stdev(values)
            
            if mean == 0:
                return None
            
            cv = (stdev / abs(mean)) * 100
            return round(cv, 2)
        except (ValueError, ZeroDivisionError):
            return None
    
    @staticmethod
    def forecast_next_period(
        values: List[float],
        periods_ahead: int = 1,
    ) -> Optional[float]:
        """
        Simple forecast using linear extrapolation
        
        Args:
            values: Historical values (in order)
            periods_ahead: How many periods to forecast
        
        Returns:
            Forecasted value
        """
        if len(values) < 2:
            return None
        
        try:
            # Simple linear fit: y = mx + b
            n = len(values)
            x = list(range(n))
            y = values
            
            # Calculate slope
            x_mean = sum(x) / n
            y_mean = sum(y) / n
            
            numerator = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
            denominator = sum((x[i] - x_mean) ** 2 for i in range(n))
            
            if denominator == 0:
                return y_mean
            
            slope = numerator / denominator
            intercept = y_mean - slope * x_mean
            
            # Forecast
            forecast_x = n + periods_ahead - 1
            forecast = slope * forecast_x + intercept
            
            return max(0, round(forecast, 2))
        except (ZeroDivisionError, ValueError):
            return None
    
    @staticmethod
    def analyze_metric(
        metric_name: str,
        trend_points: List[TrendPoint],
    ) -> TrendResult:
        """
        Comprehensive trend analysis for a single metric
        
        Args:
            metric_name: Name of metric being analyzed
            trend_points: List of (date, value) tuples
        
        Returns:
            TrendResult with all analysis
        """
        if not trend_points or len(trend_points) < 1:
            return TrendResult(
                metric_name=metric_name,
                num_periods=0,
                start_value=None,
                end_value=None,
                cagr_pct=None,
                latest_growth_pct=None,
                trend_direction="stable",
                volatility_pct=None,
                predicted_value=None,
                predicted_value_date=None,
            )
        
        # Sort by date
        sorted_points = sorted(trend_points, key=lambda p: p.period_date)
        values = [p.value for p in sorted_points]
        dates = [p.period_date for p in sorted_points]
        
        # Basic stats
        start_value = values[0]
        end_value = values[-1]
        num_periods = len(values)
        
        # Calculate CAGR (assume annual data)
        num_years = (dates[-1] - dates[0]).days / 365.25
        cagr = TimeSeriesAnalysis.calculate_cagr(start_value, end_value, num_years)
        
        # Latest YoY growth
        latest_growth = None
        if len(values) >= 2:
            latest_growth = TimeSeriesAnalysis.calculate_yoy_growth(values[-2], values[-1])
        
        # Trend direction
        trend_dir = TimeSeriesAnalysis.determine_trend(values)
        
        # Volatility
        volatility = TimeSeriesAnalysis.calculate_volatility(values)
        
        # Forecast next year
        forecast = TimeSeriesAnalysis.forecast_next_period(values, periods_ahead=1)
        forecast_date = None
        if dates:
            forecast_date = dates[-1]
            from datetime import timedelta
            forecast_date = forecast_date + timedelta(days=365)
        
        return TrendResult(
            metric_name=metric_name,
            num_periods=num_periods,
            start_value=round(start_value, 2),
            end_value=round(end_value, 2),
            cagr_pct=cagr,
            latest_growth_pct=latest_growth,
            trend_direction=trend_dir,
            volatility_pct=volatility,
            predicted_value=forecast,
            predicted_value_date=forecast_date,
        )
    
    @staticmethod
    def analyze_multiple_metrics(
        metrics: Dict[str, List[TrendPoint]],
    ) -> Dict[str, TrendResult]:
        """
        Analyze multiple metrics at once
        
        Args:
            metrics: Dict mapping metric_name -> list of TrendPoints
        
        Returns:
            Dict mapping metric_name -> TrendResult
        """
        results = {}
        for metric_name, trend_points in metrics.items():
            results[metric_name] = TimeSeriesAnalysis.analyze_metric(metric_name, trend_points)
        return results


# ============================================
# HELPER TO CONVERT FROM API INPUT
# ============================================

def build_trend_data_from_historicals(
    historicals: List[Dict],
    metric_key: str,
) -> List[TrendPoint]:
    """
    Convert from KPIHistorical input to TrendPoint list
    
    Args:
        historicals: List of KPIHistorical dicts
        metric_key: Key to extract (e.g., "fatturato", "ebitda")
    
    Returns:
        List of TrendPoint objects
    """
    trend_points = []
    
    for hist in historicals:
        if metric_key in hist and hist[metric_key] is not None:
            period_date = hist.get("period_date")
            if isinstance(period_date, str):
                period_date = datetime.fromisoformat(period_date).date()
            elif isinstance(period_date, datetime):
                period_date = period_date.date()
            
            value = float(hist[metric_key])
            period_type = hist.get("period_type", "annual")
            
            # Map period_type to period_days
            period_days_map = {
                "monthly": 30,
                "quarterly": 90,
                "annual": 365,
            }
            period_days = period_days_map.get(period_type, 365)
            
            trend_points.append(TrendPoint(
                period_date=period_date,
                value=value,
                period_days=period_days,
            ))
    
    return trend_points


def extract_trends_from_api_request(
    historicals: Optional[List[Dict]],
) -> Dict[str, List[TrendPoint]]:
    """
    Extract all trend data from API request
    
    Args:
        historicals: List of KPIHistorical from request
    
    Returns:
        Dict of metric_name -> TrendPoints
    """
    if not historicals:
        return {}
    
    metrics_to_extract = [
        "fatturato",
        "ebitda",
        "costi_variabili",
        "costi_fissi",
    ]
    
    trend_data = {}
    for metric in metrics_to_extract:
        trend_points = build_trend_data_from_historicals(historicals, metric)
        if trend_points:
            trend_data[metric] = trend_points
    
    return trend_data
