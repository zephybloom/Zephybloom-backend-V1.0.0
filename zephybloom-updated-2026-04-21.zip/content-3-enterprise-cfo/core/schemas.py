# -*- coding: utf-8 -*-
# content/core/schemas.py — Pydantic v2 hardened, no-recursion version
from __future__ import annotations

from typing import List, Dict, Literal, Optional, Any
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


# =========================================================
# Helpers
# =========================================================
def _safe_float(v: object, default: float = 0.0) -> float:
    try:
        x = float(v) if v is not None else default
        if x != x or x in (float("inf"), float("-inf")):
            return default
        return x
    except Exception:
        return default


def _nonneg(v: object, default: float = 0.0) -> float:
    x = _safe_float(v, default)
    return max(0.0, x)


def _cap(v: object, lo: float, hi: float, default: float = 0.0) -> float:
    x = _safe_float(v, default)
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def _soft_fraction(v: object) -> float:
    """
    Converte percentuali / frazioni in frazione 0..1.
    Esempi:
    - 0.12 -> 0.12
    - 12   -> 0.12
    - 120  -> 1.20
    - -5   -> 0.0
    """
    x = _safe_float(v, 0.0)
    if x < 0:
        return 0.0
    if x > 1.0:
        x = x / 100.0
    return x


def _soft_rate_unbounded(v: object) -> float:
    """
    Per campi come NRR che possono stare > 1.0.
    Esempi:
    - 1.05 -> 1.05
    - 105  -> 1.05
    - 80   -> 0.80
    """
    x = _safe_float(v, 0.0)
    if x < 0:
        return 0.0
    if x > 10.0:
        x = x / 100.0
    return x


def _clip01(v: object) -> float:
    x = _safe_float(v, 0.0)
    return max(0.0, min(x, 1.0))


def _to_dict(v: Any) -> Dict[str, Any]:
    if isinstance(v, dict):
        return dict(v)
    if hasattr(v, "model_dump"):
        try:
            dumped = v.model_dump()
            if isinstance(dumped, dict):
                return dumped
        except Exception:
            pass
    return {}


# =========================================================
# KPI (input + derivati)
# =========================================================
class KPI(BaseModel):
    model_config = ConfigDict(
        validate_assignment=False,
        extra="ignore",
    )

    # -----------------------------
    # INPUT base
    # -----------------------------
    fatturato: float = Field(0.0, description="Ricavi / vendite")
    costi_variabili: float = Field(0.0, description="Costi variabili totali")
    costi_fissi: float = Field(0.0, description="Costi fissi totali")
    investimenti: float = Field(0.0, description="Capex / investimenti")

    # -----------------------------
    # Unit economics
    # -----------------------------
    prezzo_medio: float = Field(0.0, description="Prezzo medio unitario")
    costo_variabile_unitario: float = Field(0.0, description="Costo variabile unitario")

    # -----------------------------
    # Extra contabili / economici
    # -----------------------------
    cogs: float = Field(0.0, description="Costo del venduto")
    ammortamenti: float = Field(0.0, description="Ammortamenti")
    tasse: float = Field(0.0, description="Tasse")
    opex: float = Field(0.0, description="Operating expenses")

    # -----------------------------
    # Working capital (giorni)
    # -----------------------------
    dso: float = Field(0.0, description="Days Sales Outstanding")
    dio: float = Field(0.0, description="Days Inventory Outstanding")
    dpo: float = Field(0.0, description="Days Payables Outstanding")

    # -----------------------------
    # Altman Z inputs
    # -----------------------------
    wc: float = Field(0.0, description="Working capital")
    re: float = Field(0.0, description="Retained earnings")
    ebit: float = Field(0.0, description="EBIT")
    mve: float = Field(0.0, description="Market value of equity")
    sales: float = Field(0.0, description="Vendite / sales alias")
    ta: float = Field(0.0, description="Total assets")
    tl: float = Field(0.0, description="Total liabilities")

    # -----------------------------
    # SaaS / subscription metrics
    # -----------------------------
    mrr: float = Field(0.0, description="Monthly recurring revenue")
    churn_rate: float = Field(0.0, description="Churn rate come frazione 0..1")
    cac: float = Field(0.0, description="Customer acquisition cost")
    ltv: float = Field(0.0, description="Lifetime value")
    arpu: float = Field(0.0, description="Average revenue per user")
    nrr: float = Field(0.0, description="Net revenue retention come rapporto (1.05 = 105%)")

    # -----------------------------
    # DERIVATI
    # -----------------------------
    utile: float = Field(0.0)
    margine_contribuzione: float = Field(0.0)
    mc_rate: float = Field(0.0, description="Frazione 0..1")
    break_even: float = Field(0.0)
    break_even_qty: float = Field(0.0)
    ebitda: float = Field(0.0)
    gross_margin_rate: float = Field(0.0, description="Frazione 0..1")
    net_margin_rate: float = Field(0.0, description="Frazione 0..1")
    roi: float = Field(0.0, description="Frazione 0..1 o superiore in casi estremi")
    ccc: float = Field(0.0)
    altman_z: float = Field(0.0)

    # =========================================================
    # Model-level normalization BEFORE validation
    # =========================================================
    @model_validator(mode="before")
    @classmethod
    def _normalize_input_dict(cls, data: Any) -> Any:
        d = _to_dict(data)
        if not d:
            return data

        # alias soft
        fatturato = _nonneg(d.get("fatturato", 0.0))
        sales = _nonneg(d.get("sales", 0.0))
        if fatturato <= 0.0 and sales > 0.0:
            d["fatturato"] = sales
        elif sales <= 0.0 and fatturato > 0.0:
            d["sales"] = fatturato

        cv = _nonneg(d.get("costi_variabili", 0.0))
        cogs = _nonneg(d.get("cogs", 0.0))
        if cv <= 0.0 and cogs > 0.0:
            d["costi_variabili"] = cogs
        elif cogs <= 0.0 and cv > 0.0:
            d["cogs"] = cv

        # rate interni
        if "churn_rate" in d:
            d["churn_rate"] = _clip01(_soft_fraction(d["churn_rate"]))
        if "mc_rate" in d:
            d["mc_rate"] = _clip01(_soft_fraction(d["mc_rate"]))
        if "gross_margin_rate" in d:
            d["gross_margin_rate"] = _clip01(_soft_fraction(d["gross_margin_rate"]))
        if "net_margin_rate" in d:
            d["net_margin_rate"] = _clip01(_soft_fraction(d["net_margin_rate"]))

        # ROI non negativo; se 12 -> 0.12
        if "roi" in d:
            roi_val = _safe_float(d["roi"], 0.0)
            if roi_val < 0:
                roi_val = 0.0
            elif roi_val > 1.0 and roi_val <= 100.0:
                roi_val = roi_val / 100.0
            d["roi"] = roi_val

        if "nrr" in d:
            d["nrr"] = max(0.0, _soft_rate_unbounded(d["nrr"]))

        # non negativi critici
        for key in (
            "fatturato",
            "costi_variabili",
            "costi_fissi",
            "investimenti",
            "prezzo_medio",
            "costo_variabile_unitario",
            "cogs",
            "ammortamenti",
            "tasse",
            "opex",
            "mrr",
            "cac",
            "ltv",
            "arpu",
            "mve",
            "ta",
            "tl",
            "break_even",
            "break_even_qty",
            "ccc",
        ):
            if key in d:
                d[key] = _nonneg(d[key], 0.0)

        # giorni
        for key in ("dso", "dio", "dpo"):
            if key in d:
                d[key] = _cap(d[key], 0.0, 3650.0, 0.0)

        # signed
        for key in ("wc", "re", "ebit", "utile", "margine_contribuzione", "ebitda", "altman_z"):
            if key in d:
                d[key] = _safe_float(d[key], 0.0)

        return d

    # =========================================================
    # Field validators
    # =========================================================
    @field_validator(
        "fatturato",
        "costi_variabili",
        "costi_fissi",
        "investimenti",
        "prezzo_medio",
        "costo_variabile_unitario",
        "cogs",
        "ammortamenti",
        "tasse",
        "opex",
        "mrr",
        "cac",
        "ltv",
        "arpu",
        "mve",
        "ta",
        "tl",
        "break_even",
        "break_even_qty",
        "ccc",
        mode="before",
    )
    @classmethod
    def _non_negative_inputs(cls, v: object) -> float:
        return _nonneg(v, 0.0)

    @field_validator("dso", "dio", "dpo", mode="before")
    @classmethod
    def _cap_days(cls, v: object) -> float:
        return _cap(v, 0.0, 3650.0, 0.0)

    @field_validator("wc", "re", "ebit", "sales", "utile", "margine_contribuzione", "ebitda", "altman_z", mode="before")
    @classmethod
    def _signed_numeric_inputs(cls, v: object) -> float:
        return _safe_float(v, 0.0)

    @field_validator("churn_rate", "mc_rate", "gross_margin_rate", "net_margin_rate", mode="before")
    @classmethod
    def _normalize_fraction_fields(cls, v: object) -> float:
        return _clip01(_soft_fraction(v))

    @field_validator("roi", mode="before")
    @classmethod
    def _normalize_roi_field(cls, v: object) -> float:
        x = _safe_float(v, 0.0)
        if x < 0:
            return 0.0
        if x > 1.0 and x <= 100.0:
            return x / 100.0
        return x

    @field_validator("nrr", mode="before")
    @classmethod
    def _normalize_nrr_soft(cls, v: object) -> float:
        return max(0.0, _soft_rate_unbounded(v))


def kpi_to_dict(kpi: KPI) -> Dict[str, Any]:
    try:
        return kpi.model_dump()
    except Exception:
        try:
            return {k: v for k, v in vars(kpi).items() if not k.startswith("_")}
        except Exception:
            return {}


# =========================================================
# Advisory
# =========================================================
class Advisory(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        extra="ignore",
    )

    code: str
    title: str
    detail: str = ""
    severity: Literal["info", "low", "medium", "high", "critical"] = "info"
    suggestions: List[str] = Field(default_factory=list)
    meta: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("code", "title", "detail", mode="before")
    @classmethod
    def _coerce_strings(cls, v: object) -> str:
        try:
            return str(v or "").strip()
        except Exception:
            return ""

    @field_validator("suggestions", mode="before")
    @classmethod
    def _normalize_suggestions(cls, v: object) -> List[str]:
        if v is None:
            return []
        if isinstance(v, list):
            out: List[str] = []
            for item in v:
                try:
                    s = str(item).strip()
                    if s:
                        out.append(s)
                except Exception:
                    continue
            return out
        try:
            s = str(v).strip()
            return [s] if s else []
        except Exception:
            return []

    @field_validator("meta", mode="before")
    @classmethod
    def _normalize_meta(cls, v: object) -> Dict[str, Any]:
        return v if isinstance(v, dict) else {}


# =========================================================
# Answer
# =========================================================
class Answer(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        extra="ignore",
    )

    intent: str
    value: Optional[float] = None
    value_str: Optional[str] = None
    narrative: str = ""
    advisories: List[Advisory] = Field(default_factory=list)
    tools_used: List[str] = Field(default_factory=list)
    sources: Optional[List[Dict[str, Any]]] = None
    meta: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("intent", "narrative", "value_str", mode="before")
    @classmethod
    def _coerce_optional_strings(cls, v: object) -> str | None:
        if v is None:
            return None
        try:
            return str(v)
        except Exception:
            return None

    @field_validator("value", mode="before")
    @classmethod
    def _coerce_value(cls, v: object) -> Optional[float]:
        if v is None:
            return None
        x = _safe_float(v, 0.0)
        if x != x or x in (float("inf"), float("-inf")):
            return None
        return x

    @field_validator("tools_used", mode="before")
    @classmethod
    def _normalize_tools_used(cls, v: object) -> List[str]:
        if v is None:
            return []
        if isinstance(v, list):
            out: List[str] = []
            for item in v:
                try:
                    s = str(item).strip()
                    if s:
                        out.append(s)
                except Exception:
                    continue
            return out
        try:
            s = str(v).strip()
            return [s] if s else []
        except Exception:
            return []

    @field_validator("advisories", mode="before")
    @classmethod
    def _normalize_advisories(cls, v: object) -> List[Advisory]:
        if v is None:
            return []

        if isinstance(v, list):
            out: List[Advisory] = []
            for item in v:
                if isinstance(item, Advisory):
                    out.append(item)
                    continue
                if isinstance(item, dict):
                    try:
                        out.append(Advisory(**item))
                    except Exception:
                        continue
                    continue
                if hasattr(item, "model_dump"):
                    try:
                        out.append(Advisory(**item.model_dump()))
                    except Exception:
                        continue
            return out

        if isinstance(v, dict):
            try:
                return [Advisory(**v)]
            except Exception:
                return []

        return []

    @field_validator("sources", mode="before")
    @classmethod
    def _normalize_sources(cls, v: object) -> Optional[List[Dict[str, Any]]]:
        if v is None:
            return None
        if not isinstance(v, list):
            return None

        out: List[Dict[str, Any]] = []
        for item in v:
            if isinstance(item, dict):
                out.append(item)
            elif hasattr(item, "model_dump"):
                try:
                    dumped = item.model_dump()
                    if isinstance(dumped, dict):
                        out.append(dumped)
                except Exception:
                    continue
        return out or None

    @field_validator("meta", mode="before")
    @classmethod
    def _normalize_meta(cls, v: object) -> Dict[str, Any]:
        return v if isinstance(v, dict) else {}

    @model_validator(mode="after")
    def _cleanup_answer(self) -> "Answer":
        object.__setattr__(self, "intent", str(self.intent or "unknown"))
        object.__setattr__(self, "narrative", "" if self.narrative is None else str(self.narrative))
        object.__setattr__(self, "tools_used", self.tools_used or [])
        object.__setattr__(self, "advisories", self.advisories or [])
        object.__setattr__(self, "meta", self.meta or {})
        return self


# =========================================================
# Company
# =========================================================
class Company(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        extra="ignore",
    )

    name: str = "Azienda"
    sector: str = "default"
    country: str = "IT"
    kpi: KPI = Field(default_factory=KPI)

    @field_validator("name", mode="before")
    @classmethod
    def _coerce_name(cls, v: object) -> str:
        try:
            s = str(v or "").strip()
            return s if s else "Azienda"
        except Exception:
            return "Azienda"

    @field_validator("sector", mode="before")
    @classmethod
    def _coerce_sector(cls, v: object) -> str:
        try:
            s = str(v or "").strip()
            return s if s else "default"
        except Exception:
            return "default"

    @field_validator("country", mode="before")
    @classmethod
    def _coerce_country(cls, v: object) -> str:
        try:
            s = str(v or "").strip()
            return s if s else "IT"
        except Exception:
            return "IT"