"""
CFO Analysis Engine - Decision Analysis & Recommendations

Core business logic for:
- Problem identification
- Root cause analysis
- Priority calculation
- Action recommendations
"""

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from api.schemas_cfo import (
    HealthStatus, PriorityLevel, Diagnosis, KPISnapshot, 
    RecommendedAction, AnalyzeResponse
)

# Try to import KPI engine
try:
    from core.kpi_engine import compute_kpi
except ImportError:
    from core.kpi_engine import compute_kpi


# ============================================
# ANALYSIS ENGINE
# ============================================

class CFOAnalysisEngine:
    """Main CFO analysis engine for financial diagnosis and recommendations"""
    
    def __init__(self, sector: str = "default"):
        self.sector = sector.lower().strip() or "default"
        # Sector-specific thresholds
        self.thresholds = self._get_sector_thresholds()
    
    def _get_sector_thresholds(self) -> Dict[str, Any]:
        """Sector-specific KPI thresholds"""
        thresholds = {
            "default": {
                "gross_margin_min_pct": 35,
                "net_margin_min_pct": 5,
                "ebitda_margin_min_pct": 12,
                "roi_min_pct": 10,
                "fixed_cost_max_pct": 40,  # Max fixed costs as % of revenue
            },
            "manufacturing": {
                "gross_margin_min_pct": 30,
                "net_margin_min_pct": 5,
                "ebitda_margin_min_pct": 12,
                "roi_min_pct": 12,
                "fixed_cost_max_pct": 35,
            },
            "saas": {
                "gross_margin_min_pct": 70,
                "net_margin_min_pct": 15,
                "ebitda_margin_min_pct": 25,
                "roi_min_pct": 25,
                "fixed_cost_max_pct": 60,
            },
            "retail": {
                "gross_margin_min_pct": 25,
                "net_margin_min_pct": 3,
                "ebitda_margin_min_pct": 8,
                "roi_min_pct": 8,
                "fixed_cost_max_pct": 50,
            },
        }
        return thresholds.get(self.sector, thresholds["default"])
    
    def analyze(
        self,
        fatturato: float,
        costi_variabili: float,
        costi_fissi: float,
        investimenti: float = 0,
        company_name: Optional[str] = None,
        **kwargs
    ) -> AnalyzeResponse:
        """
        Complete financial analysis with diagnosis and recommendations
        
        Args:
            fatturato: Revenue in EUR
            costi_variabili: Variable costs in EUR
            costi_fissi: Fixed costs in EUR
            investimenti: Investments/CapEx in EUR
            company_name: Optional company name
            **kwargs: Additional data (DSO, DIO, DPO, etc.)
            
        Returns:
            AnalyzeResponse: Complete analysis with status, diagnosis, KPIs, and actions
        """
        
        # Calculate KPIs
        kpi_snapshot = self._calculate_kpis(
            fatturato, costi_variabili, costi_fissi, investimenti, **kwargs
        )
        
        # Identify problems and diagnose
        diagnosis, estimated_loss = self._diagnose(kpi_snapshot, fatturato, costi_fissi)
        
        # Determine health status
        status = self._determine_status(kpi_snapshot, diagnosis)
        
        # Determine priority
        priority = self._determine_priority(status, estimated_loss)
        
        # Generate recommendations
        actions = self._generate_recommendations(
            kpi_snapshot, diagnosis, fatturato, 
            costi_variabili, costi_fissi, status
        )
        
        # Calculate potential recovery
        potential_recovery = sum(a.impatto_euro for a in actions)
        
        # Create headline and summary
        headline, summary = self._create_messaging(status, diagnosis, kpi_snapshot)
        
        return AnalyzeResponse(
            status=status,
            headline=headline,
            summary=summary,
            diagnosis=diagnosis,
            estimated_loss_eur=max(0, estimated_loss),
            potential_recovery_eur=potential_recovery,
            priority=priority,
            kpi_snapshot=kpi_snapshot,
            recommended_actions=actions,
        )
    
    def _calculate_kpis(
        self,
        fatturato: float,
        costi_variabili: float,
        costi_fissi: float,
        investimenti: float = 0,
        **kwargs
    ) -> KPISnapshot:
        """Calculate all KPIs"""
        
        fatturato = max(0, float(fatturato or 0))
        costi_variabili = max(0, float(costi_variabili or 0))
        costi_fissi = max(0, float(costi_fissi or 0))
        investimenti = max(0, float(investimenti or 0))
        
        # Basic calculations
        gross_profit = fatturato - costi_variabili
        gross_margin_pct = (gross_profit / fatturato * 100) if fatturato > 0 else 0
        
        ebitda = gross_profit - costi_fissi
        ebitda_margin_pct = (ebitda / fatturato * 100) if fatturato > 0 else (-1000.0 if ebitda < 0 else 0)
        
        net_profit = ebitda  # Simplified: no taxes, interest, etc.
        net_margin_pct = (net_profit / fatturato * 100) if fatturato > 0 else (-1000.0 if net_profit < 0 else 0)
        
        # ROI calculation
        roi_pct = None
        if investimenti > 0:
            roi_pct = (ebitda / investimenti * 100)
        
        # CCC calculation (if DSO/DIO/DPO provided)
        ccc_days = None
        dso = float(kwargs.get("dso_days") or 0)
        dio = float(kwargs.get("dio_days") or 0)
        dpo = float(kwargs.get("dpo_days") or 0)
        if dso >= 0 and dio >= 0 and dpo >= 0:
            ccc_days = dso + dio - dpo
        
        return KPISnapshot(
            gross_profit_eur=round(gross_profit, 2),
            gross_margin_pct=round(gross_margin_pct, 2),
            ebitda_eur=round(ebitda, 2),
            ebitda_margin_pct=round(ebitda_margin_pct, 2),
            net_profit_eur=round(net_profit, 2),
            net_margin_pct=round(net_margin_pct, 2),
            roi_pct=round(roi_pct, 2) if roi_pct else None,
            ccc_days=round(ccc_days, 1) if ccc_days else None,
        )
    
    def _diagnose(
        self,
        kpi: KPISnapshot,
        fatturato: float,
        costi_fissi: float,
    ) -> Tuple[Diagnosis, float]:
        """
        Diagnose main problems and root causes
        
        Returns:
            Diagnosis object and estimated annual loss
        """
        
        problems = []
        root_causes = []
        
        # Check profitability
        if kpi.net_profit_eur < 0:
            problems.append("Negative profitability")
            # Check if it's a margin or cost issue
            if kpi.gross_margin_pct < 20:
                root_causes.append("Low gross margin indicates pricing or COGS problem")
            else:
                root_causes.append("High fixed costs eating into profit")
        
        elif kpi.net_margin_pct < self.thresholds["net_margin_min_pct"]:
            problems.append(f"Margin below sector benchmark ({self.thresholds['net_margin_min_pct']}%)")
            root_causes.append("Operational inefficiency or pricing pressure")
        
        # Check gross margin
        if kpi.gross_margin_pct < self.thresholds["gross_margin_min_pct"]:
            problems.append("Low gross margin eroding profitability")
            root_causes.append("Price-to-cost imbalance (pricing strategy or procurement efficiency)")
        
        # Check fixed cost ratio
        if fatturato > 0:
            fixed_cost_ratio = (costi_fissi / fatturato * 100)
            if fixed_cost_ratio > self.thresholds["fixed_cost_max_pct"]:
                problems.append(f"Fixed costs too high ({fixed_cost_ratio:.1f}% of revenue)")
                root_causes.append("Structural overhead not aligned with revenue level")
        
        # Check EBITDA margin
        if kpi.ebitda_margin_pct < self.thresholds["ebitda_margin_min_pct"]:
            problems.append(f"EBITDA margin below benchmark ({self.thresholds['ebitda_margin_min_pct']}%)")
            root_causes.append("Operational leverage problem - high costs relative to revenue")
        
        # Fallback if no problems detected
        if not problems:
            if kpi.net_margin_pct < 10:
                problems.append("Profitability below potential")
                root_causes.append("Room for optimization exists")
            else:
                problems.append("Business performing adequately")
                root_causes.append("No critical issues identified")
        
        # Calculate estimated loss
        estimated_loss = abs(min(0, kpi.net_profit_eur) * 1.2)  # Annualize 20% worse
        
        diagnosis = Diagnosis(
            problema_principale=problems[0],
            causa_principale=root_causes[0],
            impatto_stimato_eur=round(estimated_loss, 2),
        )
        
        return diagnosis, estimated_loss
    
    def _determine_status(
        self,
        kpi: KPISnapshot,
        diagnosis: Diagnosis,
    ) -> HealthStatus:
        """Determine overall company health status"""
        
        # Critical: losing money
        if kpi.net_profit_eur < 0:
            return HealthStatus.CRITICAL
        
        # Critical: negative margin
        if kpi.net_margin_pct < 0:
            return HealthStatus.CRITICAL
        
        # Warning: below minimum thresholds
        if (
            kpi.net_margin_pct < self.thresholds["net_margin_min_pct"] or
            kpi.gross_margin_pct < self.thresholds["gross_margin_min_pct"]
        ):
            return HealthStatus.WARNING
        
        # Healthy
        return HealthStatus.HEALTHY
    
    def _determine_priority(
        self,
        status: HealthStatus,
        estimated_loss: float,
    ) -> PriorityLevel:
        """Determine action priority based on status and impact"""
        
        if status == HealthStatus.CRITICAL:
            return PriorityLevel.CRITICAL
        elif status == HealthStatus.WARNING:
            if estimated_loss > 100000:
                return PriorityLevel.CRITICAL
            else:
                return PriorityLevel.HIGH
        else:
            return PriorityLevel.MEDIUM if estimated_loss > 50000 else PriorityLevel.LOW
    
    def _create_messaging(
        self,
        status: HealthStatus,
        diagnosis: Diagnosis,
        kpi: KPISnapshot,
    ) -> Tuple[str, str]:
        """Create headline and executive summary"""
        
        company_context = ""
        if kpi.net_profit_eur < 0:
            company_context = f"Your company is burning {abs(kpi.net_profit_eur):,.0f} EUR annually."
        elif kpi.net_margin_pct < 5:
            company_context = f"Profitability is critically low at {kpi.net_margin_pct:.1f}% margin."
        elif kpi.net_margin_pct < 10:
            company_context = f"Profit margin is below potential at {kpi.net_margin_pct:.1f}%."
        else:
            company_context = f"Business is performing at {kpi.net_margin_pct:.1f}% margin."
        
        headline_map = {
            HealthStatus.CRITICAL: f"CRITICAL: {diagnosis.problema_principale}",
            HealthStatus.WARNING: f"WARNING: {diagnosis.problema_principale}",
            HealthStatus.HEALTHY: f"HEALTHY: {diagnosis.problema_principale} - Optimization Opportunity",
        }
        
        headline = headline_map[status]
        
        summary = f"{company_context} Root cause: {diagnosis.causa_principale}. This analysis identifies specific actions to improve profitability and cash flow."
        
        return headline, summary
    
    def _generate_recommendations(
        self,
        kpi: KPISnapshot,
        diagnosis: Diagnosis,
        fatturato: float,
        costi_variabili: float,
        costi_fissi: float,
        status: HealthStatus,
    ) -> List[RecommendedAction]:
        """Generate top 3-5 recommended actions"""
        
        actions: List[RecommendedAction] = []
        
        # ---- ACTION 1: Price optimization (if margin is weak) ----
        if kpi.gross_margin_pct < self.thresholds["gross_margin_min_pct"]:
            # Simulate 2% price increase (conservative)
            price_impact = fatturato * 0.02 * 0.7  # 2% increase, 30% volume loss
            actions.append(RecommendedAction(
                title="Price Optimization Strategy",
                description="Implement targeted price increases on lower-elasticity products. Analyze customer segments to identify pricing power.",
                impatto_euro=round(price_impact, 2),
                priorita=PriorityLevel.CRITICAL if status == HealthStatus.CRITICAL else PriorityLevel.HIGH,
                passi=[
                    "Segment customers by price sensitivity",
                    "Test price increases on 10% of customer base",
                    "Monitor volume loss and adjust",
                    "Implement across customer base over 3 months"
                ]
            ))
        
        # ---- ACTION 2: Cost reduction (if fixed costs are high) ----
        if fatturato > 0:
            fixed_cost_ratio = costi_fissi / fatturato
            if fixed_cost_ratio > 0.35:  # More than 35% of revenue
                # Identify 10% reduction opportunity
                cf_reduction = costi_fissi * 0.10
                actions.append(RecommendedAction(
                    title="Fixed Cost Optimization",
                    description="Review and reduce overhead costs through process optimization and supplier renegotiation.",
                    impatto_euro=round(cf_reduction, 2),
                    priorita=PriorityLevel.CRITICAL if kpi.net_profit_eur < 0 else PriorityLevel.HIGH,
                    passi=[
                        "Audit all overhead categories",
                        "Request RFQs from 3+ suppliers for each major contract",
                        "Implement shared services where possible",
                        "Execute savings over 6 months"
                    ]
                ))
        
        # ---- ACTION 3: Working capital optimization ----
        if kpi.ccc_days and kpi.ccc_days > 45:
            # Each day of CCC improvement = fatturato/365 * 0.5 (50% cost of capital)
            wc_improvement = (fatturato / 365) * kpi.ccc_days * 0.5 * 0.1  # 10% CCC reduction
            actions.append(RecommendedAction(
                title="Working Capital Optimization",
                description="Reduce cash conversion cycle through faster collections, inventory optimization, and better payment terms.",
                impatto_euro=round(wc_improvement, 2),
                priorita=PriorityLevel.HIGH,
                passi=[
                    "Reduce DSO by 5 days through early payment discounts",
                    "Optimize inventory turnover - target 15% DIO reduction",
                    "Negotiate extended DPO with top 10 suppliers"
                ]
            ))
        
        # ---- ACTION 4: Revenue growth (if safe margin exists) ----
        if kpi.gross_margin_pct > self.thresholds["gross_margin_min_pct"] and kpi.net_margin_pct > 5:
            # Conservative 5% revenue growth
            revenue_growth_impact = fatturato * 0.05 * kpi.net_margin_pct / 100
            actions.append(RecommendedAction(
                title="Revenue Growth Initiative",
                description="Accelerate revenue growth in profitable segments through sales team expansion and market penetration.",
                impatto_euro=round(revenue_growth_impact, 2),
                priorita=PriorityLevel.MEDIUM,
                passi=[
                    "Identify top 3 customers with expansion potential",
                    "Hire 1-2 additional sales resources",
                    "Launch targeted marketing campaign",
                    "Target 5-10% revenue growth over 12 months"
                ]
            ))
        
        # ---- ACTION 5: Margin improvement (universal) ----
        if len(actions) < 5:
            # Gross margin improvement through procurement
            cv_reduction = costi_variabili * 0.05  # 5% COGS reduction
            actions.append(RecommendedAction(
                title="Supply Chain Cost Reduction",
                description="Improve gross margin through supply chain optimization and procurement efficiency.",
                impatto_euro=round(cv_reduction, 2),
                priorita=PriorityLevel.MEDIUM,
                passi=[
                    "Analyze spend by supplier and category",
                    "Consolidate suppliers to improve negotiating power",
                    "Implement vendor management program",
                    "Target 3-5% COGS reduction"
                ]
            ))
        
        # Sort by impact descending and limit to top 5
        actions.sort(key=lambda x: x.impatto_euro, reverse=True)
        return actions[:5]


# ============================================
# HELPER FUNCTIONS
# ============================================

def create_analysis_engine(sector: str = "default") -> CFOAnalysisEngine:
    """Factory function to create analysis engine"""
    return CFOAnalysisEngine(sector)


def analyze_company(
    fatturato: float,
    costi_variabili: float,
    costi_fissi: float,
    investimenti: float = 0,
    settore: str = "default",
    company_name: Optional[str] = None,
    **kwargs
) -> AnalyzeResponse:
    """
    Convenience function for complete analysis
    
    Returns:
        AnalyzeResponse with full diagnosis and recommendations
    """
    engine = create_analysis_engine(settore)
    return engine.analyze(
        fatturato, costi_variabili, costi_fissi, investimenti, company_name, **kwargs
    )
