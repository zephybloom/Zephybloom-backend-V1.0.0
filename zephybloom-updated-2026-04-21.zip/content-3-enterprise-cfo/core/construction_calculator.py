"""Construction CFO calculator.

Reads projects/commesse through margin, WIP/SAL and cash gap. Construction
companies can be profitable on paper and still run out of cash, so this
calculator separates economic margin from payment timing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def analyze_construction(data: Dict[str, Any]) -> Dict[str, Any]:
    fixed_costs = _num(data.get("fixed_costs") or data.get("costi_fissi"), 0)
    invested_capital = _num(data.get("invested_capital") or data.get("investimenti"), 0)
    projects = [_analyze_project(row) for row in data.get("projects", [])]
    projects = [project for project in projects if project["project"]]

    total_contract_value = sum(project["contract_value_eur"] for project in projects)
    total_expected_cost = sum(project["expected_total_cost_eur"] for project in projects)
    total_expected_profit = sum(project["expected_profit_eur"] for project in projects)
    total_billed = sum(project["billed_eur"] for project in projects)
    total_collected = sum(project["collected_eur"] for project in projects)
    total_cost_incurred = sum(project["cost_incurred_eur"] for project in projects)
    total_cash_gap = sum(project["cash_gap_eur"] for project in projects)
    overhead_allocated_profit = total_expected_profit - fixed_costs

    projects_by_profit = sorted(projects, key=lambda item: item["expected_profit_eur"], reverse=True)
    projects_by_cash_risk = sorted(projects, key=lambda item: item["cash_gap_eur"], reverse=True)
    projects_to_fix = [
        project for project in sorted(projects, key=lambda item: (item["expected_margin_pct"], -item["cash_gap_eur"]))
        if project["expected_margin_pct"] < 12 or project["cash_gap_eur"] > 0 or project["delay_risk_eur"] > 0
    ]

    return {
        "summary": {
            "contract_value_eur": round(total_contract_value, 2),
            "expected_total_cost_eur": round(total_expected_cost, 2),
            "expected_profit_eur": round(total_expected_profit, 2),
            "expected_margin_pct": _pct(total_expected_profit, total_contract_value),
            "fixed_costs_eur": round(fixed_costs, 2),
            "net_profit_after_overhead_eur": round(overhead_allocated_profit, 2),
            "net_margin_after_overhead_pct": _pct(overhead_allocated_profit, total_contract_value),
            "roi_pct": _pct(overhead_allocated_profit, invested_capital),
            "billed_eur": round(total_billed, 2),
            "collected_eur": round(total_collected, 2),
            "cost_incurred_eur": round(total_cost_incurred, 2),
            "cash_gap_eur": round(total_cash_gap, 2),
            "wip_unbilled_eur": round(sum(project["wip_unbilled_eur"] for project in projects), 2),
            "project_count": len(projects),
        },
        "top_projects_by_profit": projects_by_profit[:10],
        "projects_by_cash_risk": projects_by_cash_risk[:10],
        "projects_to_fix": projects_to_fix[:10],
        "recommendations": _recommendations(projects_to_fix, projects_by_cash_risk, total_cash_gap, overhead_allocated_profit, total_contract_value),
    }


def simulate_construction(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    base_data = _copy_construction_data(data)
    scenario_data = _apply_construction_scenario(_copy_construction_data(data), scenario)
    base = analyze_construction(base_data)
    simulated = analyze_construction(scenario_data)
    base_summary = base["summary"]
    simulated_summary = simulated["summary"]

    return {
        "scenario_name": scenario.get("name") or "Scenario construction",
        "base": base,
        "simulated": simulated,
        "delta": {
            "contract_value_eur": round(simulated_summary["contract_value_eur"] - base_summary["contract_value_eur"], 2),
            "expected_profit_eur": round(simulated_summary["expected_profit_eur"] - base_summary["expected_profit_eur"], 2),
            "expected_margin_pct": round(simulated_summary["expected_margin_pct"] - base_summary["expected_margin_pct"], 2),
            "net_profit_after_overhead_eur": round(simulated_summary["net_profit_after_overhead_eur"] - base_summary["net_profit_after_overhead_eur"], 2),
            "cash_gap_eur": round(simulated_summary["cash_gap_eur"] - base_summary["cash_gap_eur"], 2),
            "wip_unbilled_eur": round(simulated_summary["wip_unbilled_eur"] - base_summary["wip_unbilled_eur"], 2),
            "roi_pct": round(simulated_summary["roi_pct"] - base_summary["roi_pct"], 2),
        },
        "decision": _scenario_decision(base_summary, simulated_summary),
        "applied_scenario": scenario,
    }


def _copy_construction_data(data: Dict[str, Any]) -> Dict[str, Any]:
    copied = dict(data or {})
    copied["projects"] = [dict(row) for row in data.get("projects", [])]
    return copied


def _apply_construction_scenario(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    materials_cost_delta_pct = _num(scenario.get("materials_cost_delta_pct"), 0)
    labor_cost_delta_pct = _num(scenario.get("labor_cost_delta_pct"), 0)
    subcontractor_cost_delta_pct = _num(scenario.get("subcontractor_cost_delta_pct"), 0)
    billed_delta_pct = _num(scenario.get("billed_delta_pct"), 0)
    collected_delta_pct = _num(scenario.get("collected_delta_pct"), 0)
    delay_weeks_delta = _num(scenario.get("delay_weeks_delta"), 0)
    change_orders_approved_delta = _num(scenario.get("change_orders_approved_delta"), 0)
    fixed_cost_delta_pct = _num(scenario.get("fixed_cost_delta_pct"), 0)
    target_project = str(scenario.get("target_project") or "").strip().lower()

    for project in data.get("projects", []):
        if target_project and str(project.get("project", "")).strip().lower() != target_project:
            continue
        if materials_cost_delta_pct:
            project["materials_cost"] = _num(project.get("materials_cost"), 0) * (1 + materials_cost_delta_pct / 100)
        if labor_cost_delta_pct:
            project["labor_cost"] = _num(project.get("labor_cost"), 0) * (1 + labor_cost_delta_pct / 100)
        if subcontractor_cost_delta_pct:
            project["subcontractor_cost"] = _num(project.get("subcontractor_cost"), 0) * (1 + subcontractor_cost_delta_pct / 100)
        if billed_delta_pct:
            project["billed_pct"] = min(100, max(0, _num(project.get("billed_pct"), 0) + billed_delta_pct))
        if collected_delta_pct:
            project["collected_pct"] = min(100, max(0, _num(project.get("collected_pct"), 0) + collected_delta_pct))
        if delay_weeks_delta:
            project["delay_weeks"] = max(0, _num(project.get("delay_weeks"), 0) + delay_weeks_delta)
        if change_orders_approved_delta:
            project["change_orders_approved"] = _num(project.get("change_orders_approved"), 0) + change_orders_approved_delta

    if fixed_cost_delta_pct:
        data["fixed_costs"] = _num(data.get("fixed_costs") or data.get("costi_fissi"), 0) * (1 + fixed_cost_delta_pct / 100)

    return data


def _scenario_decision(base_summary: Dict[str, Any], simulated_summary: Dict[str, Any]) -> str:
    profit_delta = simulated_summary["net_profit_after_overhead_eur"] - base_summary["net_profit_after_overhead_eur"]
    cash_gap_delta = simulated_summary["cash_gap_eur"] - base_summary["cash_gap_eur"]
    margin_delta = simulated_summary["expected_margin_pct"] - base_summary["expected_margin_pct"]

    if profit_delta > 0 and cash_gap_delta <= 0 and margin_delta >= 0:
        return "GO: migliora utile, margine e cassa."
    if profit_delta > 0 and cash_gap_delta <= 0:
        return "TEST: utile e cassa migliorano, controlla margine commessa."
    if cash_gap_delta < 0:
        return "CASH GO: cassa migliora, ma verifica impatto su margine."
    if profit_delta > 0:
        return "CAUTION: utile migliora ma assorbe piu' cassa."
    return "NO GO: scenario peggiora utile o non libera cassa."


def _analyze_project(row: Dict[str, Any]) -> Dict[str, Any]:
    name = str(row.get("project") or row.get("name") or row.get("commessa") or "").strip()
    contract_value = _num(row.get("contract_value") or row.get("value") or row.get("ricavi"), 0)
    materials_cost = _num(row.get("materials_cost"), 0)
    labor_cost = _num(row.get("labor_cost"), 0)
    subcontractor_cost = _num(row.get("subcontractor_cost"), 0)
    other_cost = _num(row.get("other_cost"), 0)
    progress_pct = _num(row.get("progress_pct"), 0)
    billed_pct = _num(row.get("billed_pct"), 0)
    collected_pct = _num(row.get("collected_pct"), 0)
    delay_weeks = _num(row.get("delay_weeks"), 0)
    penalty_pct_per_week = _num(row.get("penalty_pct_per_week"), 0)
    change_orders_approved = _num(row.get("change_orders_approved"), 0)
    change_orders_unapproved = _num(row.get("change_orders_unapproved"), 0)

    adjusted_contract_value = contract_value + change_orders_approved
    expected_total_cost = materials_cost + labor_cost + subcontractor_cost + other_cost
    expected_profit = adjusted_contract_value - expected_total_cost
    billed = adjusted_contract_value * billed_pct / 100
    collected = adjusted_contract_value * collected_pct / 100
    earned_value = adjusted_contract_value * progress_pct / 100
    cost_incurred = expected_total_cost * progress_pct / 100
    cash_gap = max(0, cost_incurred - collected)
    wip_unbilled = max(0, earned_value - billed)
    delay_risk = adjusted_contract_value * (penalty_pct_per_week / 100) * delay_weeks
    profit_after_delay = expected_profit - delay_risk

    return {
        "project": name,
        "contract_value_eur": round(adjusted_contract_value, 2),
        "base_contract_value_eur": round(contract_value, 2),
        "expected_total_cost_eur": round(expected_total_cost, 2),
        "materials_cost_eur": round(materials_cost, 2),
        "labor_cost_eur": round(labor_cost, 2),
        "subcontractor_cost_eur": round(subcontractor_cost, 2),
        "expected_profit_eur": round(expected_profit, 2),
        "expected_margin_pct": _pct(expected_profit, adjusted_contract_value),
        "profit_after_delay_risk_eur": round(profit_after_delay, 2),
        "progress_pct": round(progress_pct, 2),
        "billed_eur": round(billed, 2),
        "collected_eur": round(collected, 2),
        "cost_incurred_eur": round(cost_incurred, 2),
        "cash_gap_eur": round(cash_gap, 2),
        "wip_unbilled_eur": round(wip_unbilled, 2),
        "delay_risk_eur": round(delay_risk, 2),
        "change_orders_unapproved_eur": round(change_orders_unapproved, 2),
        "decision": _project_decision(_pct(expected_profit, adjusted_contract_value), cash_gap, delay_risk, change_orders_unapproved),
    }


def _project_decision(margin_pct: float, cash_gap: float, delay_risk: float, unapproved_changes: float) -> str:
    if margin_pct < 8:
        return "renegotiate_or_stop"
    if cash_gap > 0 and delay_risk > 0:
        return "cash_and_delay_recovery"
    if cash_gap > 0:
        return "accelerate_billing_or_collection"
    if unapproved_changes > 0:
        return "approve_change_orders"
    if margin_pct >= 18:
        return "scale_similar_projects"
    return "monitor"


def _recommendations(projects_to_fix: List[Dict[str, Any]], projects_by_cash_risk: List[Dict[str, Any]], total_cash_gap: float, net_profit: float, total_contract_value: float) -> List[str]:
    recs: List[str] = []
    if total_cash_gap > 0:
        recs.append(f"Cash gap cantieri {total_cash_gap:.0f} EUR: priorita' su SAL, incassi e anticipi fornitori.")
    if net_profit < 0:
        recs.append("Utile dopo overhead negativo: non aprire nuove commesse senza riprezzare o ridurre struttura.")
    if projects_to_fix:
        recs.append("Commesse da correggere: " + ", ".join(project["project"] for project in projects_to_fix[:3]))
    risky = [project for project in projects_by_cash_risk if project["cash_gap_eur"] > 0]
    if risky:
        recs.append("Prima recupera cassa su: " + ", ".join(project["project"] for project in risky[:3]))
    if total_contract_value > 0 and _pct(net_profit, total_contract_value) < 10:
        recs.append("Margine netto dopo overhead sotto 10%: inserisci buffer materiali, penali e subappalti nei nuovi preventivi.")
    return recs[:6]


def _num(value: Optional[Any], default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _pct(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 2)
