"""
Strategic Memory Manager

Store and compare company data over time.
"""

from typing import Dict, Optional, List
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class CompanySnapshot:
    """Snapshot of company at a point in time"""
    date: datetime
    fatturato: float
    margin: float
    ebitda: float
    cash_position: float
    headcount: int
    key_decisions: List[str]
    advice_followed: List[str]
    advice_ignored: List[str]


class StrategicMemory:
    """Remember company evolution"""
    
    def __init__(self):
        self.snapshots: Dict[str, List[CompanySnapshot]] = {}
    
    def record(self, company_id: str, snapshot: CompanySnapshot):
        """Record a snapshot"""
        if company_id not in self.snapshots:
            self.snapshots[company_id] = []
        self.snapshots[company_id].append(snapshot)
    
    def compare_periods(
        self,
        company_id: str,
    ) -> Dict[str, any]:
        """Compare company over different periods"""
        
        snapshots = self.snapshots.get(company_id, [])
        if len(snapshots) < 2:
            return {}
        
        latest = snapshots[-1]
        
        # Compare with 1 month, 3 months, 12 months ago
        results = {}
        
        for months_back, period_name in [(1, "1m_ago"), (3, "3m_ago"), (12, "12m_ago")]:
            previous = self._get_snapshot_approximately(snapshots, months_back)
            if previous:
                results[period_name] = self._calculate_delta(previous, latest)
        
        return results
    
    def _get_snapshot_approximately(self, snapshots: List, months_back: int) -> Optional[CompanySnapshot]:
        """Get snapshot from approximately N months ago"""
        target_date = datetime.now() - timedelta(days=30*months_back)
        
        closest = None
        for snap in snapshots:
            if snap.date <= target_date:
                if not closest or abs((snap.date - target_date).days) < abs((closest.date - target_date).days):
                    closest = snap
        
        return closest
    
    def _calculate_delta(self, previous: CompanySnapshot, latest: CompanySnapshot) -> dict:
        """Calculate changes between two snapshots"""
        
        return {
            "revenue_change_pct": ((latest.fatturato - previous.fatturato) / previous.fatturato * 100) if previous.fatturato else 0,
            "margin_change_pp": latest.margin - previous.margin,  # percentage points
            "ebitda_change_pct": ((latest.ebitda - previous.ebitda) / previous.ebitda * 100) if previous.ebitda else 0,
            "cash_change_pct": ((latest.cash_position - previous.cash_position) / previous.cash_position * 100) if previous.cash_position else 0,
            "headcount_change": latest.headcount - previous.headcount,
            "decisions_made": latest.key_decisions,
            "advice_followed_count": len(latest.advice_followed),
        }
    
    def get_trend_narrative(self, company_id: str) -> str:
        """Narrative about company trend"""
        
        deltas = self.compare_periods(company_id)
        
        if not deltas or "3m_ago" not in deltas:
            return "Insufficient data for trend analysis"
        
        three_month_delta = deltas.get("3m_ago", {})
        
        narrative = ""
        
        if three_month_delta.get("revenue_change_pct", 0) > 15:
            narrative += "Revenue is growing nicely. "
        elif three_month_delta.get("revenue_change_pct", 0) > 0:
            narrative += "Revenue growing steadily. "
        else:
            narrative += "Revenue flat or declining. "
        
        margin_change = three_month_delta.get("margin_change_pp", 0)
        if margin_change > 1:
            narrative += "Margin improving - quality of growth is strong. "
        elif margin_change < -2:
            narrative += "⚠️ Margin deteriorating despite growth - growth quality is concerning. "
        else:
            narrative += "Margin stable. "
        
        cash_change = three_month_delta.get("cash_change_pct", 0)
        if cash_change > 10:
            narrative += "Cash position strengthening. "
        elif cash_change < -10:
            narrative += "⚠️ Cash position weakening despite growth. "
        else:
            narrative += "Cash stable. "
        
        return narrative


def get_memory() -> StrategicMemory:
    return StrategicMemory()
