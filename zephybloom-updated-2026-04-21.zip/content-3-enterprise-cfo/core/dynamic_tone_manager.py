"""
Dynamic Tone Manager - Personalize communication to entrepreneur profile

Adapts tone, language, and framing based on:
- Entrepreneur profile (risk tolerance, expertise, decision style)
- Company stage (startup vs mature)
- Severity of situation
- Previous interactions
"""

from typing import Dict, Optional
from enum import Enum
from dataclasses import dataclass
from core.entrepreneur_profiler import (
    EntrepreneurProfile,
    RiskTolerance,
    ExpertiseLevel,
    DecisionStyle,
    PainTolerance,
)


class CFOTonePersonalized(str, Enum):
    """Personalized tone options"""
    # Original basic tones
    SOFT = "soft"           # Gentle, explainatory
    COMPETENT = "competent" # Professional, balanced
    FIRM = "firm"           # Direct, data-focused
    DIRECT = "direct"       # No-nonsense, urgent
    HARSH = "harsh"         # Critical, strong urgency
    MANAGER = "manager"     # Boss-like, commanding
    MOTIVATOR = "motivator" # Inspiring, opportunity-focused


class ExplainabilityLevel(str, Enum):
    """Level of detail in explanations"""
    MINIMAL = "minimal"       # Just the recommendation
    MODERATE = "moderate"     # Recommendation + brief why
    DETAILED = "detailed"     # Full explanation with formulas
    EDUCATIONAL = "educational"  # Learning-focused


@dataclass
class TonePersonalization:
    """Complete tone and language personalization"""
    tone: CFOTonePersonalized
    explainability: ExplainabilityLevel
    language_style: str  # "formal", "casual", "conversational"
    risk_framing: str    # "conservative", "balanced", "aggressive"
    
    # Messaging templates
    recommendation_prefix: str
    action_urgency: str  # "immediate", "soon", "gradual", "optional"
    
    # Context
    show_alternatives: bool  # Should we show alternative actions?
    show_risks: bool         # Should we highlight risks?
    include_success_stories: bool  # Include examples?


class DynamicToneManager:
    """Personalize tone and messaging to entrepreneur profile"""
    
    @staticmethod
    def personalize(
        profile: EntrepreneurProfile,
        issue_severity: str,  # "healthy", "warning", "critical"
        previous_implementation_rate: float = 0.5,
    ) -> TonePersonalization:
        """
        Choose personalized tone and communication style.
        
        Args:
            profile: Entrepreneur's inferred profile
            issue_severity: How serious is the situation
            previous_implementation_rate: % of past recommendations followed (0-1)
        
        Returns:
            TonePersonalization with all settings
        """
        
        # ===== SELECT BASE TONE =====
        tone = DynamicToneManager._select_tone(
            profile=profile,
            severity=issue_severity,
        )
        
        # ===== SELECT EXPLAINABILITY =====
        explainability = DynamicToneManager._select_explainability(profile)
        
        # ===== SELECT LANGUAGE STYLE =====
        language_style = DynamicToneManager._select_language_style(profile)
        
        # ===== SELECT RISK FRAMING =====
        risk_framing = DynamicToneManager._select_risk_framing(profile)
        
        # ===== RECOMMENDATION PREFIX =====
        prefix = DynamicToneManager._recommendation_prefix(tone, profile)
        
        # ===== ACTION URGENCY =====
        urgency = DynamicToneManager._action_urgency(issue_severity, profile)
        
        # ===== SHOULD SHOW ALTERNATIVES? =====
        show_alts = (
            profile.expertise_level == ExpertiseLevel.EXPERT or
            profile.decision_style == DecisionStyle.DATA_DRIVEN
        )
        
        # ===== SHOULD SHOW RISKS? =====
        show_risks = (
            profile.risk_tolerance in [RiskTolerance.CONSERVATIVE, RiskTolerance.MODERATE] or
            issue_severity == "critical"
        )
        
        # ===== INCLUDE SUCCESS STORIES? =====
        include_stories = (
            profile.expertise_level == ExpertiseLevel.NOVICE or
            previous_implementation_rate < 0.5
        )
        
        return TonePersonalization(
            tone=tone,
            explainability=explainability,
            language_style=language_style,
            risk_framing=risk_framing,
            recommendation_prefix=prefix,
            action_urgency=urgency,
            show_alternatives=show_alts,
            show_risks=show_risks,
            include_success_stories=include_stories,
        )
    
    @staticmethod
    def _select_tone(
        profile: EntrepreneurProfile,
        severity: str,
    ) -> CFOTonePersonalized:
        """Select tone based on profile and situation"""
        
        # Critical always stern or firm
        if severity == "critical":
            if profile.risk_tolerance == RiskTolerance.AGGRESSIVE:
                return CFOTonePersonalized.DIRECT
            else:
                return CFOTonePersonalized.FIRM
        
        # Expert + Data-driven → Firm
        if (profile.expertise_level == ExpertiseLevel.EXPERT and 
            profile.decision_style == DecisionStyle.DATA_DRIVEN):
            return CFOTonePersonalized.FIRM
        
        # Novice → Soft (educational)
        if profile.expertise_level == ExpertiseLevel.NOVICE:
            return CFOTonePersonalized.SOFT
        
        # Aggressive growth → Motivator or Direct
        if profile.growth_appetite.value == "hypergrowth":
            return CFOTonePersonalized.MOTIVATOR
        
        # Conservative → Soft or Competent
        if profile.risk_tolerance == RiskTolerance.CONSERVATIVE:
            return CFOTonePersonalized.SOFT
        
        # Default: Competent (professional, balanced)
        return CFOTonePersonalized.COMPETENT
    
    @staticmethod
    def _select_explainability(profile: EntrepreneurProfile) -> ExplainabilityLevel:
        """How much detail should we explain?"""
        
        # Novice → Educational
        if profile.expertise_level == ExpertiseLevel.NOVICE:
            return ExplainabilityLevel.EDUCATIONAL
        
        # Expert + Data-driven → Minimal
        if (profile.expertise_level == ExpertiseLevel.EXPERT and
            profile.decision_style == DecisionStyle.DATA_DRIVEN):
            return ExplainabilityLevel.MINIMAL
        
        # Intuitive → Moderate (show key why, but not all formulas)
        if profile.decision_style == DecisionStyle.INTUITIVE:
            return ExplainabilityLevel.MODERATE
        
        # Default: Detailed
        return ExplainabilityLevel.DETAILED
    
    @staticmethod
    def _select_language_style(profile: EntrepreneurProfile) -> str:
        """Formal vs casual language"""
        
        # Expert, older → Formal
        if profile.expertise_level == ExpertiseLevel.EXPERT:
            return "formal"
        
        # Novice, startup → Conversational
        if (profile.expertise_level == ExpertiseLevel.NOVICE and
            profile.company_stage == "startup"):
            return "conversational"
        
        # Default: Professional
        return "professional"
    
    @staticmethod
    def _select_risk_framing(profile: EntrepreneurProfile) -> str:
        """How to frame risks and opportunities"""
        
        # Aggressive → Focus on upside
        if profile.risk_tolerance == RiskTolerance.AGGRESSIVE:
            return "aggressive"
        
        # Conservative → Focus on downside protection
        if profile.risk_tolerance == RiskTolerance.CONSERVATIVE:
            return "conservative"
        
        # Default: Balanced
        return "balanced"
    
    @staticmethod
    def _recommendation_prefix(tone: CFOTonePersonalized, profile: EntrepreneurProfile) -> str:
        """Opening phrase for recommendation"""
        
        prefixes = {
            CFOTonePersonalized.SOFT: "I'd suggest",
            CFOTonePersonalized.COMPETENT: "I recommend",
            CFOTonePersonalized.FIRM: "You should",
            CFOTonePersonalized.DIRECT: "Do this now",
            CFOTonePersonalized.HARSH: "You must",
            CFOTonePersonalized.MANAGER: "Execute",
            CFOTonePersonalized.MOTIVATOR: "This is your opportunity",
        }
        
        return prefixes.get(tone, "I recommend")
    
    @staticmethod
    def _action_urgency(severity: str, profile: EntrepreneurProfile) -> str:
        """How urgently should action be taken"""
        
        if severity == "critical":
            return "immediate"
        
        if severity == "warning":
            if profile.pain_tolerance == PainTolerance.LOW:
                return "soon"
            else:
                return "gradual"
        
        # Healthy
        if profile.growth_appetite.value == "hypergrowth":
            return "soon"  # Don't wait for opportunities
        else:
            return "optional"
    
    @staticmethod
    def humanize_number(value: float, context: str = "impact") -> str:
        """Convert numbers to readable text based on profile preference"""
        
        if context == "impact":
            if value >= 100_000:
                return f"€{value/1_000_000:.1f}M"
            elif value >= 1_000:
                return f"€{value/1_000:.0f}k"
            else:
                return f"€{value:.0f}"
        
        return str(value)


from dataclasses import dataclass


# Example usage helpers
def tone_for_entrepreneur(
    risk_tolerance: str,  # "conservative", "moderate", "aggressive"
    expertise: str,       # "novice", "intermediate", "expert"
    severity: str,        # "healthy", "warning", "critical"
) -> CFOTonePersonalized:
    """Quick tone selection without full profile"""
    
    if severity == "critical":
        if risk_tolerance == "aggressive":
            return CFOTonePersonalized.DIRECT
        else:
            return CFOTonePersonalized.FIRM
    
    if expertise == "novice":
        return CFOTonePersonalized.SOFT
    
    if expertise == "expert" and risk_tolerance == "aggressive":
        return CFOTonePersonalized.FIRM
    
    return CFOTonePersonalized.COMPETENT
