"""Persistence helpers for the CFO Company Data Room."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from core.company_data_room import build_company_data_room
from db.models import CompanyDataRoomSnapshot, CompanyDataRoomSnapshotHistory


def get_data_room_snapshot(
    session: Session,
    tenant_id: str,
    company_id: str = "default",
) -> Optional[Dict[str, Any]]:
    record = _get_record(session, tenant_id, company_id)
    if not record:
        return None
    return _record_to_dict(record)


def upsert_data_room_snapshot(
    session: Session,
    tenant_id: str,
    company_id: str,
    company_name: str,
    company_data: Optional[Dict[str, Any]] = None,
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    active_sector: Optional[str] = None,
    import_summary: Optional[Dict[str, Any]] = None,
    merge: bool = True,
    change_reason: str = "manual_save",
) -> Dict[str, Any]:
    record = _get_record(session, tenant_id, company_id)
    now = datetime.now(timezone.utc)

    next_company_data = dict(company_data or {})
    next_operational = dict(operational_data_by_sector or {})
    next_import_summary = import_summary

    if record and merge:
        next_company_data = _deep_merge(_json_loads(record.company_data_json), next_company_data)
        next_operational = _deep_merge(_json_loads(record.operational_data_by_sector_json), next_operational)
        previous_import = _json_loads(record.import_summary_json)
        next_import_summary = _deep_merge(previous_import, import_summary or {}) if import_summary else previous_import

    if record is None:
        record = CompanyDataRoomSnapshot(
            tenant_id=tenant_id,
            company_id=company_id,
            company_name=company_name or "Azienda",
            created_at=now,
        )
        session.add(record)

    record.company_name = company_name or record.company_name or "Azienda"
    record.active_sector = active_sector or next_company_data.get("settore") or record.active_sector
    record.company_data_json = json.dumps(next_company_data, ensure_ascii=False, sort_keys=True)
    record.operational_data_by_sector_json = json.dumps(next_operational, ensure_ascii=False, sort_keys=True)
    record.import_summary_json = json.dumps(next_import_summary or {}, ensure_ascii=False, sort_keys=True)
    record.updated_at = now
    _add_history_record(
        session=session,
        tenant_id=tenant_id,
        company_id=company_id,
        company_name=record.company_name,
        active_sector=record.active_sector,
        company_data=next_company_data,
        operational_data_by_sector=next_operational,
        import_summary=next_import_summary or {},
        change_reason=change_reason,
        created_at=now,
    )

    session.commit()
    session.refresh(record)
    return _record_to_dict(record)


def import_data_room_rows(
    session: Session,
    tenant_id: str,
    company_id: str,
    company_name: str,
    active_sector: str,
    entity: str,
    rows: Any,
) -> Dict[str, Any]:
    if entity not in {
        "products",
        "sku_sales",
        "menu_items",
        "suppliers",
        "staff_roles",
        "sales_channels",
        "projects",
        "customers",
        "inventory",
    }:
        raise ValueError(f"Unsupported Data Room import entity: {entity}")
    if not isinstance(rows, list):
        raise ValueError("rows must be a list")

    operational = {active_sector: {entity: rows}}
    summary = {
        "last_import": {
            "entity": entity,
            "sector": active_sector,
            "row_count": len(rows),
            "imported_at": datetime.now(timezone.utc).isoformat(),
        }
    }
    return upsert_data_room_snapshot(
        session=session,
        tenant_id=tenant_id,
        company_id=company_id,
        company_name=company_name,
        company_data={"company_name": company_name, "settore": active_sector},
        operational_data_by_sector=operational,
        active_sector=active_sector,
        import_summary=summary,
        merge=True,
        change_reason=f"import_{entity}",
    )


def get_data_room_history(
    session: Session,
    tenant_id: str,
    company_id: str = "default",
    limit: int = 12,
) -> List[Dict[str, Any]]:
    records = (
        session.query(CompanyDataRoomSnapshotHistory)
        .filter(
            CompanyDataRoomSnapshotHistory.tenant_id == tenant_id,
            CompanyDataRoomSnapshotHistory.company_id == company_id,
        )
        .order_by(CompanyDataRoomSnapshotHistory.created_at.desc())
        .limit(max(1, min(limit, 50)))
        .all()
    )
    return [_history_record_to_dict(record) for record in records]


def build_data_room_history_summary(
    session: Session,
    tenant_id: str,
    company_id: str = "default",
    limit: int = 12,
) -> Dict[str, Any]:
    history = get_data_room_history(session, tenant_id, company_id, limit=limit)
    if not history:
        return {
            "has_history": False,
            "company_id": company_id,
            "snapshot_count": 0,
            "latest": None,
            "previous": None,
            "delta": None,
            "timeline": [],
            "cfo_comment": "Nessuno storico Data Room ancora salvato.",
        }

    latest = history[0]
    previous = history[1] if len(history) > 1 else None
    delta = _history_delta(latest, previous)
    return {
        "has_history": True,
        "company_id": company_id,
        "snapshot_count": len(history),
        "latest": latest,
        "previous": previous,
        "delta": delta,
        "timeline": [
            {
                "created_at": item["created_at"],
                "readiness_score_pct": item["readiness_score_pct"],
                "sector_count": item["sector_count"],
                "row_count": item["row_count"],
                "change_reason": item["change_reason"],
            }
            for item in history
        ],
        "cfo_comment": _history_comment(delta, len(history)),
    }


def merge_saved_data_room(
    saved: Optional[Dict[str, Any]],
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
) -> Dict[str, Any]:
    if not saved:
        return {
            "company_data": company_data,
            "operational_data_by_sector": operational_data_by_sector or {},
            "active_sector": company_data.get("settore"),
        }

    merged_company = _deep_merge(saved.get("company_data") or {}, company_data or {})
    merged_operational = _deep_merge(
        saved.get("operational_data_by_sector") or {},
        operational_data_by_sector or {},
    )
    return {
        "company_data": merged_company,
        "operational_data_by_sector": merged_operational,
        "active_sector": merged_company.get("settore") or saved.get("active_sector"),
    }


def _get_record(session: Session, tenant_id: str, company_id: str) -> Optional[CompanyDataRoomSnapshot]:
    return (
        session.query(CompanyDataRoomSnapshot)
        .filter(
            CompanyDataRoomSnapshot.tenant_id == tenant_id,
            CompanyDataRoomSnapshot.company_id == company_id,
        )
        .first()
    )


def _record_to_dict(record: CompanyDataRoomSnapshot) -> Dict[str, Any]:
    return {
        "tenant_id": record.tenant_id,
        "company_id": record.company_id,
        "company_name": record.company_name,
        "active_sector": record.active_sector,
        "company_data": _json_loads(record.company_data_json),
        "operational_data_by_sector": _json_loads(record.operational_data_by_sector_json),
        "import_summary": _json_loads(record.import_summary_json),
        "created_at": record.created_at.isoformat() if record.created_at else None,
        "updated_at": record.updated_at.isoformat() if record.updated_at else None,
    }


def _history_record_to_dict(record: CompanyDataRoomSnapshotHistory) -> Dict[str, Any]:
    return {
        "id": record.id,
        "tenant_id": record.tenant_id,
        "company_id": record.company_id,
        "company_name": record.company_name,
        "active_sector": record.active_sector,
        "company_data": _json_loads(record.company_data_json),
        "operational_data_by_sector": _json_loads(record.operational_data_by_sector_json),
        "import_summary": _json_loads(record.import_summary_json),
        "readiness_score_pct": record.readiness_score_pct,
        "sector_count": record.sector_count,
        "row_count": record.row_count,
        "change_reason": record.change_reason,
        "created_at": record.created_at.isoformat() if record.created_at else None,
    }


def _add_history_record(
    session: Session,
    tenant_id: str,
    company_id: str,
    company_name: str,
    active_sector: Optional[str],
    company_data: Dict[str, Any],
    operational_data_by_sector: Dict[str, Dict[str, Any]],
    import_summary: Dict[str, Any],
    change_reason: str,
    created_at: datetime,
) -> None:
    data_room = build_company_data_room(
        company_data=company_data,
        operational_data_by_sector=operational_data_by_sector,
        active_sector=active_sector,
    )
    session.add(
        CompanyDataRoomSnapshotHistory(
            tenant_id=tenant_id,
            company_id=company_id,
            company_name=company_name,
            active_sector=active_sector,
            company_data_json=json.dumps(company_data or {}, ensure_ascii=False, sort_keys=True),
            operational_data_by_sector_json=json.dumps(operational_data_by_sector or {}, ensure_ascii=False, sort_keys=True),
            import_summary_json=json.dumps(import_summary or {}, ensure_ascii=False, sort_keys=True),
            readiness_score_pct=float(data_room.get("readiness_score_pct") or 0),
            sector_count=len(operational_data_by_sector or {}),
            row_count=_count_operational_rows(operational_data_by_sector or {}),
            change_reason=change_reason,
            created_at=created_at,
        )
    )


def _count_operational_rows(operational_data_by_sector: Dict[str, Dict[str, Any]]) -> int:
    count = 0
    for sector_data in operational_data_by_sector.values():
        if not isinstance(sector_data, dict):
            continue
        for value in sector_data.values():
            if isinstance(value, list):
                count += len(value)
            elif isinstance(value, dict):
                count += len(value)
            elif value not in (None, ""):
                count += 1
    return count


def _history_delta(latest: Dict[str, Any], previous: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not previous:
        return {
            "readiness_score_pct": latest.get("readiness_score_pct") or 0,
            "sector_count": latest.get("sector_count") or 0,
            "row_count": latest.get("row_count") or 0,
            "new_sectors": list((latest.get("operational_data_by_sector") or {}).keys()),
            "removed_sectors": [],
        }
    latest_sectors = set((latest.get("operational_data_by_sector") or {}).keys())
    previous_sectors = set((previous.get("operational_data_by_sector") or {}).keys())
    return {
        "readiness_score_pct": round((latest.get("readiness_score_pct") or 0) - (previous.get("readiness_score_pct") or 0), 1),
        "sector_count": (latest.get("sector_count") or 0) - (previous.get("sector_count") or 0),
        "row_count": (latest.get("row_count") or 0) - (previous.get("row_count") or 0),
        "new_sectors": sorted(latest_sectors - previous_sectors),
        "removed_sectors": sorted(previous_sectors - latest_sectors),
    }


def _history_comment(delta: Optional[Dict[str, Any]], count: int) -> str:
    if not delta:
        return "Storico Data Room ancora vuoto."
    readiness_delta = float(delta.get("readiness_score_pct") or 0)
    row_delta = int(delta.get("row_count") or 0)
    if count == 1:
        return "Prima versione Data Room salvata: da ora posso confrontare miglioramenti e peggioramenti."
    if readiness_delta > 0:
        return f"Readiness Data Room migliorata di {readiness_delta:.1f} punti; il CFO puo' rispondere con piu' precisione."
    if readiness_delta < 0:
        return f"Readiness Data Room peggiorata di {abs(readiness_delta):.1f} punti; controlla dati rimossi o incompleti."
    if row_delta > 0:
        return f"Dati operativi aumentati di {row_delta} righe; prossima verifica: usare questi dati in War Room."
    return "Data Room stabile: prossimo passo e' collegare le decisioni a risultati misurati."


def _json_loads(value: Optional[str]) -> Dict[str, Any]:
    if not value:
        return {}
    try:
        loaded = json.loads(value)
    except json.JSONDecodeError:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base or {})
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        elif value not in (None, "", [], {}):
            merged[key] = value
    return merged
