"""
HubSpot Integration

Connects to HubSpot CRM to sync:
- Customer data
- Churn metrics
- Customer acquisition cost
- Lifetime value
- Deals and pipeline
"""

from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, date
import requests

from core.integrations_base import (
    CRMIntegration,
    IntegrationConfig,
    IntegrationResult,
    IntegrationStatus,
    CustomerMetrics,
    AuthenticationError,
    RateLimitError,
)


class HubSpotIntegration(CRMIntegration):
    """
    Integrates with HubSpot CRM via API key or OAuth.
    
    Provides:
    - Customer metrics (count, churn, CAC, LTV)
    - Customer list (contacts with properties)
    - Deal pipeline
    - Company data
    """
    
    BASE_URL = "https://api.hubapi.com"
    
    def __init__(self, config: IntegrationConfig):
        super().__init__(config)
        self.api_key = config.api_key
    
    def authenticate(self) -> IntegrationResult:
        """
        Authenticate with HubSpot.
        
        Requires config.api_key (HubSpot API key or OAuth token).
        """
        try:
            if not self.api_key:
                raise AuthenticationError("Missing HubSpot API key")
            
            # Test authentication
            headers = self._get_headers()
            response = requests.get(
                f"{self.BASE_URL}/crm/v3/objects/companies/schema",
                headers=headers,
                timeout=self.config.timeout_seconds,
            )
            
            if response.status_code == 200:
                self.status = IntegrationStatus.AUTHENTICATED
                return IntegrationResult(
                    success=True,
                    data={"status": "authenticated"},
                )
            else:
                raise AuthenticationError(f"Authentication failed: {response.text}")
        
        except Exception as e:
            self._log_error(str(e), "AUTH_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="AUTH_ERROR",
            )
    
    def sync_data(self) -> IntegrationResult:
        """Sync customer data from HubSpot"""
        try:
            if self.status != IntegrationStatus.AUTHENTICATED:
                return IntegrationResult(
                    success=False,
                    error="Not authenticated",
                    error_code="NOT_AUTHENTICATED",
                )
            
            # Get customers and metrics
            customers_result = self.get_customers(limit=100)
            metrics_result = self.get_customer_metrics()
            
            self.last_sync = datetime.now()
            
            return IntegrationResult(
                success=True,
                data={
                    "customers_synced": len(customers_result[0] or []),
                    "metrics_synced": metrics_result[0] is not None,
                },
            )
        
        except Exception as e:
            self._log_error(str(e), "SYNC_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="SYNC_ERROR",
            )
    
    def disconnect(self) -> IntegrationResult:
        """Disconnect from HubSpot"""
        try:
            self.status = IntegrationStatus.CONNECTING
            return IntegrationResult(success=True)
        
        except Exception as e:
            self._log_error(str(e), "DISCONNECT_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="DISCONNECT_ERROR",
            )
    
    def get_customer_metrics(
        self,
        period: Optional[date] = None,
    ) -> Tuple[Optional[CustomerMetrics], Optional[str]]:
        """
        Get aggregated customer metrics from HubSpot.
        
        Calculates:
        - Customer count and active customers
        - MRR/ARR from deals
        - Churn rate
        - CAC and LTV
        """
        try:
            if period is None:
                period = date.today()
            
            # Mock implementation
            # In production: call HubSpot Contacts API + Deals API
            
            metrics = CustomerMetrics(
                total_customers=150,
                active_customers=145,
                mrr=15_000,  # $15k MRR
                arr=180_000,  # $180k ARR
                churn_rate_pct=3.3,  # 5 customers lost in month
                customer_acquisition_cost=500,
                customer_lifetime_value=5400,  # 3 year average
                period=period,
                source="hubspot",
            )
            
            return metrics, None
        
        except Exception as e:
            return None, str(e)
    
    def get_customers(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """
        Get list of customers (contacts) from HubSpot.
        
        Returns list of contacts with:
        - Name, email
        - Company
        - Lifecycle stage
        - Customer value
        """
        try:
            # Mock implementation
            # In production: call HubSpot Contacts API with pagination
            
            customers = [
                {
                    "id": "contact_001",
                    "firstname": "John",
                    "lastname": "Smith",
                    "email": "john@acme.com",
                    "company": "Acme Corp",
                    "lifecyclestage": "customer",
                    "hs_lead_status": "QUALIFIED",
                },
                {
                    "id": "contact_002",
                    "firstname": "Jane",
                    "lastname": "Doe",
                    "email": "jane@techcorp.com",
                    "company": "TechCorp",
                    "lifecyclestage": "customer",
                    "hs_lead_status": "QUALIFIED",
                },
            ]
            
            return customers[:limit], None
        
        except Exception as e:
            return None, str(e)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get HTTP headers for HubSpot API requests"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
    
    def _get_contacts(
        self,
        limit: int = 100,
        after: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get contacts from HubSpot API"""
        headers = self._get_headers()
        
        params = {"limit": limit}
        if after:
            params["after"] = after
        
        response = requests.get(
            f"{self.BASE_URL}/crm/v3/objects/contacts",
            headers=headers,
            params=params,
            timeout=self.config.timeout_seconds,
        )
        
        if response.status_code == 429:
            raise RateLimitError("HubSpot API rate limit exceeded")
        
        response.raise_for_status()
        return response.json()
