"""Restaurant CFO calculator.

Turns operational restaurant data into CFO-grade decisions: dish margin,
target price, labour cost, prime cost and break-even covers.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional


def analyze_restaurant(data: Dict[str, Any]) -> Dict[str, Any]:
    revenue = _num(data.get("annual_revenue") or data.get("fatturato"), 0)
    variable_costs = _num(data.get("variable_costs") or data.get("costi_variabili"), 0)
    fixed_costs = _num(data.get("fixed_costs") or data.get("costi_fissi"), 0)
    invested_capital = _num(data.get("invested_capital") or data.get("investimenti"), 0)
    opening_days = _num(data.get("opening_days_per_month"), 0)
    daily_covers = _num(data.get("average_daily_covers"), 0)
    average_ticket = _num(data.get("average_ticket"), 0)
    target_food_cost_pct = _num(data.get("target_food_cost_pct"), 30)
    waste_pct = _num(data.get("waste_pct"), 0)
    delivery_commissions_pct = _num(data.get("delivery_commissions_pct"), 0)

    ingredient_costs = _normalize_ingredient_costs(data.get("ingredient_costs", []))
    dishes = [
        _analyze_dish(item, ingredient_costs, target_food_cost_pct, waste_pct, delivery_commissions_pct)
        for item in data.get("menu_items", [])
    ]
    dishes = [dish for dish in dishes if dish["name"]]

    monthly_staff_cost = _staff_monthly_cost(data.get("staff_roles", []))
    annual_staff_cost = monthly_staff_cost * 12
    annual_food_cost_from_menu = sum(dish["monthly_food_cost_eur"] for dish in dishes) * 12
    food_cost_base = annual_food_cost_from_menu if annual_food_cost_from_menu > 0 else variable_costs
    gross_profit = revenue - food_cost_base
    net_profit = revenue - food_cost_base - fixed_costs - annual_staff_cost

    monthly_revenue = revenue / 12 if revenue else daily_covers * opening_days * average_ticket
    monthly_covers = daily_covers * opening_days
    contribution_per_cover = _safe_div(monthly_revenue - (food_cost_base / 12), monthly_covers)
    monthly_fixed_plus_staff = fixed_costs / 12 + monthly_staff_cost
    break_even_covers_per_month = _safe_div(monthly_fixed_plus_staff, contribution_per_cover)
    break_even_covers_per_day = _safe_div(break_even_covers_per_month, opening_days)

    dishes_by_profit = sorted(dishes, key=lambda dish: dish["monthly_profit_eur"], reverse=True)
    dishes_by_margin = sorted(dishes, key=lambda dish: dish["gross_margin_pct"], reverse=True)
    dishes_to_fix = [
        dish for dish in sorted(dishes, key=lambda dish: (dish["gross_margin_pct"], dish["monthly_profit_eur"]))
        if dish["food_cost_pct"] > target_food_cost_pct or dish["monthly_profit_eur"] < 0
    ]

    return {
        "summary": {
            "annual_revenue_eur": round(revenue, 2),
            "annual_food_cost_eur": round(food_cost_base, 2),
            "food_cost_pct": _pct(food_cost_base, revenue),
            "annual_staff_cost_eur": round(annual_staff_cost, 2),
            "labour_cost_pct": _pct(annual_staff_cost, revenue),
            "prime_cost_pct": _pct(food_cost_base + annual_staff_cost, revenue),
            "fixed_cost_pct": _pct(fixed_costs, revenue),
            "net_profit_eur": round(net_profit, 2),
            "net_margin_pct": _pct(net_profit, revenue),
            "roi_pct": _pct(net_profit, invested_capital),
            "break_even_covers_per_day": round(break_even_covers_per_day, 1),
            "break_even_covers_per_month": round(break_even_covers_per_month, 1),
            "average_ticket_eur": round(average_ticket, 2),
            "average_daily_covers": round(daily_covers, 1),
        },
        "top_dishes_by_profit": dishes_by_profit[:10],
        "top_dishes_by_margin": dishes_by_margin[:10],
        "dishes_to_fix": dishes_to_fix[:10],
        "recommendations": _restaurant_recommendations(
            food_cost_pct=_pct(food_cost_base, revenue),
            labour_cost_pct=_pct(annual_staff_cost, revenue),
            prime_cost_pct=_pct(food_cost_base + annual_staff_cost, revenue),
            break_even_covers_per_day=break_even_covers_per_day,
            daily_covers=daily_covers,
            dishes_to_fix=dishes_to_fix,
            top_dishes=dishes_by_profit,
        ),
    }


def simulate_restaurant(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    """Compare current restaurant economics with an operational scenario."""

    base_data = _copy_restaurant_data(data)
    scenario_data = _apply_restaurant_scenario(_copy_restaurant_data(data), scenario)
    base = analyze_restaurant(base_data)
    simulated = analyze_restaurant(scenario_data)
    base_summary = base["summary"]
    simulated_summary = simulated["summary"]

    return {
        "scenario_name": scenario.get("name") or "Scenario ristorante",
        "base": base,
        "simulated": simulated,
        "delta": {
            "annual_revenue_eur": round(simulated_summary["annual_revenue_eur"] - base_summary["annual_revenue_eur"], 2),
            "net_profit_eur": round(simulated_summary["net_profit_eur"] - base_summary["net_profit_eur"], 2),
            "net_margin_pct": round(simulated_summary["net_margin_pct"] - base_summary["net_margin_pct"], 2),
            "food_cost_pct": round(simulated_summary["food_cost_pct"] - base_summary["food_cost_pct"], 2),
            "labour_cost_pct": round(simulated_summary["labour_cost_pct"] - base_summary["labour_cost_pct"], 2),
            "prime_cost_pct": round(simulated_summary["prime_cost_pct"] - base_summary["prime_cost_pct"], 2),
            "break_even_covers_per_day": round(simulated_summary["break_even_covers_per_day"] - base_summary["break_even_covers_per_day"], 1),
            "roi_pct": round(simulated_summary["roi_pct"] - base_summary["roi_pct"], 2),
        },
        "decision": _scenario_decision(base_summary, simulated_summary),
        "applied_scenario": scenario,
    }


def _copy_restaurant_data(data: Dict[str, Any]) -> Dict[str, Any]:
    copied = dict(data or {})
    copied["ingredient_costs"] = [dict(row) for row in data.get("ingredient_costs", [])] if isinstance(data.get("ingredient_costs"), list) else dict(data.get("ingredient_costs", {}))
    copied["menu_items"] = [
        {**row, "recipe": [dict(recipe_row) for recipe_row in row.get("recipe", [])]}
        for row in data.get("menu_items", [])
    ]
    copied["staff_roles"] = [dict(row) for row in data.get("staff_roles", [])]
    return copied


def _apply_restaurant_scenario(data: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    price_delta_pct = _num(scenario.get("price_delta_pct"), 0)
    covers_delta_pct = _num(scenario.get("covers_delta_pct"), 0)
    ingredient_cost_delta_pct = _num(scenario.get("ingredient_cost_delta_pct"), 0)
    staff_cost_delta_pct = _num(scenario.get("staff_cost_delta_pct"), 0)
    fixed_cost_delta_pct = _num(scenario.get("fixed_cost_delta_pct"), 0)
    waste_delta_pct = _num(scenario.get("waste_delta_pct"), 0)
    target_dish = str(scenario.get("target_dish") or "").strip().lower()

    if price_delta_pct:
        for item in data.get("menu_items", []):
            if not target_dish or str(item.get("name", "")).strip().lower() == target_dish:
                item["price"] = _num(item.get("price") or item.get("unit_price"), 0) * (1 + price_delta_pct / 100)
        if not target_dish:
            data["annual_revenue"] = _num(data.get("annual_revenue") or data.get("fatturato"), 0) * (1 + price_delta_pct / 100)

    if covers_delta_pct:
        data["average_daily_covers"] = _num(data.get("average_daily_covers"), 0) * (1 + covers_delta_pct / 100)
        data["annual_revenue"] = _num(data.get("annual_revenue") or data.get("fatturato"), 0) * (1 + covers_delta_pct / 100)
        for item in data.get("menu_items", []):
            item["monthly_units"] = _num(item.get("monthly_units") or item.get("quantity") or item.get("sales_per_month"), 0) * (1 + covers_delta_pct / 100)

    if ingredient_cost_delta_pct:
        raw_costs = data.get("ingredient_costs", [])
        if isinstance(raw_costs, dict):
            data["ingredient_costs"] = {
                key: _num(value, 0) * (1 + ingredient_cost_delta_pct / 100)
                for key, value in raw_costs.items()
            }
        else:
            for row in raw_costs:
                row["unit_cost"] = _num(row.get("unit_cost") or row.get("cost") or row.get("price"), 0) * (1 + ingredient_cost_delta_pct / 100)

    if staff_cost_delta_pct:
        for row in data.get("staff_roles", []):
            row["monthly_cost"] = _num(row.get("monthly_cost") or row.get("salary") or row.get("cost"), 0) * (1 + staff_cost_delta_pct / 100)

    if fixed_cost_delta_pct:
        data["fixed_costs"] = _num(data.get("fixed_costs") or data.get("costi_fissi"), 0) * (1 + fixed_cost_delta_pct / 100)

    if waste_delta_pct:
        data["waste_pct"] = max(0, _num(data.get("waste_pct"), 0) + waste_delta_pct)

    return data


def _scenario_decision(base_summary: Dict[str, Any], simulated_summary: Dict[str, Any]) -> str:
    profit_delta = simulated_summary["net_profit_eur"] - base_summary["net_profit_eur"]
    margin_delta = simulated_summary["net_margin_pct"] - base_summary["net_margin_pct"]
    prime_delta = simulated_summary["prime_cost_pct"] - base_summary["prime_cost_pct"]

    if profit_delta > 0 and margin_delta >= 0 and prime_delta <= 0:
        return "GO: migliora utile, margine e disciplina operativa."
    if profit_delta > 0 and margin_delta >= -1:
        return "TEST: aumenta utile, ma controlla margine e capacita'."
    if profit_delta > 0:
        return "CAUTION: utile in crescita ma margine sotto pressione."
    return "NO GO: scenario non crea utile incrementale."


def _analyze_dish(
    item: Dict[str, Any],
    ingredient_costs: Dict[str, float],
    target_food_cost_pct: float,
    waste_pct: float,
    delivery_commissions_pct: float,
) -> Dict[str, Any]:
    name = str(item.get("name") or item.get("product") or item.get("dish") or "").strip()
    price = _num(item.get("price") or item.get("unit_price"), 0)
    monthly_units = _num(item.get("monthly_units") or item.get("quantity") or item.get("sales_per_month"), 0)
    channel_commission_pct = _num(item.get("commission_pct"), delivery_commissions_pct)
    recipe_cost = _recipe_cost(item.get("recipe") or item.get("ingredients") or [], ingredient_costs)
    waste_adjusted_cost = recipe_cost * (1 + waste_pct / 100)
    commission_cost = price * (channel_commission_pct / 100)
    direct_cost = waste_adjusted_cost + commission_cost
    profit_per_unit = price - direct_cost
    target_price = _safe_div(waste_adjusted_cost, target_food_cost_pct / 100)

    return {
        "name": name,
        "price_eur": round(price, 2),
        "recipe_cost_eur": round(recipe_cost, 2),
        "waste_adjusted_food_cost_eur": round(waste_adjusted_cost, 2),
        "commission_cost_eur": round(commission_cost, 2),
        "direct_cost_eur": round(direct_cost, 2),
        "profit_per_unit_eur": round(profit_per_unit, 2),
        "gross_margin_pct": _pct(profit_per_unit, price),
        "food_cost_pct": _pct(waste_adjusted_cost, price),
        "recommended_price_for_target_margin_eur": round(target_price, 2),
        "monthly_units": round(monthly_units, 2),
        "monthly_revenue_eur": round(price * monthly_units, 2),
        "monthly_food_cost_eur": round(waste_adjusted_cost * monthly_units, 2),
        "monthly_profit_eur": round(profit_per_unit * monthly_units, 2),
        "decision": _dish_decision(price, target_price, monthly_units, profit_per_unit, target_food_cost_pct, _pct(waste_adjusted_cost, price)),
    }


def _recipe_cost(recipe: Iterable[Dict[str, Any]], ingredient_costs: Dict[str, float]) -> float:
    total = 0.0
    for row in recipe or []:
        ingredient = str(row.get("ingredient") or row.get("name") or "").strip().lower()
        quantity = _num(row.get("quantity") or row.get("qty"), 0)
        unit_cost = _num(row.get("unit_cost"), 0) or ingredient_costs.get(ingredient, 0)
        total += quantity * unit_cost
    return total


def _normalize_ingredient_costs(raw: Any) -> Dict[str, float]:
    if isinstance(raw, dict):
        return {str(key).strip().lower(): _num(value, 0) for key, value in raw.items()}

    costs: Dict[str, float] = {}
    for row in raw or []:
        name = str(row.get("name") or row.get("ingredient") or "").strip().lower()
        if name:
            costs[name] = _num(row.get("unit_cost") or row.get("cost") or row.get("price"), 0)
    return costs


def _staff_monthly_cost(staff_roles: Any) -> float:
    total = 0.0
    for row in staff_roles or []:
        people = _num(row.get("count") or row.get("people") or row.get("quantity"), 1)
        monthly_cost = _num(row.get("monthly_cost") or row.get("salary") or row.get("cost"), 0)
        total += people * monthly_cost
    return total


def _dish_decision(price: float, target_price: float, monthly_units: float, profit_per_unit: float, target_food_cost_pct: float, food_cost_pct: float) -> str:
    if profit_per_unit < 0:
        return "stop_or_reprice"
    if food_cost_pct > target_food_cost_pct and monthly_units > 0:
        return "reprice_or_reduce_recipe_cost"
    if monthly_units > 0 and food_cost_pct <= target_food_cost_pct:
        return "push_if_context_fit"
    if price < target_price:
        return "reprice_before_scaling"
    return "monitor"


def _restaurant_recommendations(
    food_cost_pct: float,
    labour_cost_pct: float,
    prime_cost_pct: float,
    break_even_covers_per_day: float,
    daily_covers: float,
    dishes_to_fix: List[Dict[str, Any]],
    top_dishes: List[Dict[str, Any]],
) -> List[str]:
    recs: List[str] = []

    if prime_cost_pct > 65:
        recs.append(f"Prime cost {prime_cost_pct:.1f}%: prima correggi food cost e turni, poi spingi crescita.")
    if food_cost_pct > 35:
        recs.append(f"Food cost {food_cost_pct:.1f}%: rinegozia ingredienti, riduci sprechi o riprezza i piatti critici.")
    if labour_cost_pct > 30:
        recs.append(f"Labour cost {labour_cost_pct:.1f}%: verifica turni, coperti per ora e ruoli non saturi.")
    if daily_covers and break_even_covers_per_day > daily_covers:
        recs.append(f"Break-even {break_even_covers_per_day:.1f} coperti/giorno sopra i {daily_covers:.1f} attuali: serve prezzo, coperti o struttura costi.")
    if dishes_to_fix:
        recs.append("Riprezza o correggi ricetta dei piatti critici: " + ", ".join(dish["name"] for dish in dishes_to_fix[:3]))
    if top_dishes:
        recs.append("Piatti da spingere solo se coerenti col posizionamento: " + ", ".join(dish["name"] for dish in top_dishes[:3]))

    return recs[:6]


def _num(value: Optional[Any], default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _safe_div(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return numerator / denominator


def _pct(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 2)
