# -*- coding: utf-8 -*-
# content/core/whatif.py — Calcoli what-if coerenti con il motore KPI
from __future__ import annotations
from typing import Dict, Any

from core.kpi_engine import compute_break_even, compute_ccc_and_wc


def _num(base: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    """
    Estrae il primo valore numerico disponibile da una lista di chiavi,
    con fallback a default.
    """
    for k in keys:
        if k in base and base[k] is not None:
            try:
                return float(base[k])
            except Exception:
                continue
    return float(default)


def whatif_breakeven(base: Dict[str, Any]) -> Dict[str, Any]:
    """
    What-if sul punto di pareggio.

    Attende in input (in base):
      - prezzo_medio
      - costo_variabile_unitario
      - costi_fissi

    Ritorna:
      - mc_rate              → margine di contribuzione unitario (frazione 0..1)
      - be_qty               → quantità al break-even
      - be_revenue / break_even_revenue → ricavi al break-even
      - break_even_qty       → alias per compatibilità con altri moduli
    """
    prezzo = _num(base, "prezzo_medio", "price", default=0.0)
    cvu    = _num(base, "costo_variabile_unitario", "cvu", default=0.0)
    cf     = _num(base, "costi_fissi", "fixed_costs", default=0.0)

    be_qty, be_rev = compute_break_even(prezzo, cvu, cf)

    mc_rate = 0.0
    if prezzo > 0.0 and cvu >= 0.0 and prezzo > cvu:
        mc_rate = (prezzo - cvu) / prezzo

    return {
        # input normalizzati di comodo
        "prezzo_medio": max(0.0, prezzo),
        "costo_variabile_unitario": max(0.0, cvu),
        "costi_fissi": max(0.0, cf),

        # output principali
        "mc_rate": max(0.0, mc_rate),
        "be_qty": max(0.0, be_qty),
        "be_revenue": max(0.0, be_rev),

        # alias coerenti con il motore KPI
        "break_even_qty": max(0.0, be_qty),
        "break_even_revenue": max(0.0, be_rev),
    }


def whatif_wc_impact(base: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analisi what-if sull'impatto del capitale circolante (working capital).

    Attende (in base):
      - fatturato | sales
      - costi_variabili | cogs
      - dso, dio, dpo               (giorni attuali)
      - dso_delta, dio_delta, dpo_delta (variazioni in giorni)
      - opzionali:
          days_in_year          (default 365)
          wc_on_sales_share     (default 0.0 → non conteggiamo DSO su vendite)
          wc_on_cogs_share      (default 1.0 → conteggiamo DIO/DPO su COGS)

    Ritorna:
      - ccc_before / ccc_after / delta_ccc
      - wc_need_before / wc_need_after / delta_cash
      - ccc (alias = ccc_after)
      - notes: flag di servizio
      - assumptions: parametri usati per il calcolo
    """
    sales = _num(base, "fatturato", "sales", default=0.0)
    cogs  = _num(base, "costi_variabili", "cogs", default=0.0)

    dso   = _num(base, "dso", default=0.0)
    dio   = _num(base, "dio", default=0.0)
    dpo   = _num(base, "dpo", default=0.0)

    dso_delta = _num(base, "dso_delta", default=0.0)
    dio_delta = _num(base, "dio_delta", default=0.0)
    dpo_delta = _num(base, "dpo_delta", default=0.0)

    days_in_year = int(_num(base, "days_in_year", default=365))
    wc_on_sales_share = _num(base, "wc_on_sales_share", default=0.0)
    wc_on_cogs_share = _num(base, "wc_on_cogs_share", default=1.0)

    # Prima situazione (stato attuale)
    ccc_before, wc_before = compute_ccc_and_wc(
        sales,
        cogs,
        dso,
        dio,
        dpo,
        days_in_year=days_in_year,
        wc_on_sales_share=wc_on_sales_share,
        wc_on_cogs_share=wc_on_cogs_share,
    )

    # Dopo applicazione dei delta
    ccc_after, wc_after = compute_ccc_and_wc(
        sales,
        cogs,
        dso + dso_delta,
        dio + dio_delta,
        dpo + dpo_delta,
        days_in_year=days_in_year,
        wc_on_sales_share=wc_on_sales_share,
        wc_on_cogs_share=wc_on_cogs_share,
    )

    delta_ccc = ccc_after - ccc_before
    delta_cash = wc_before - wc_after  # cash liberata se positivo

    return {
        # metriche CCC/WC
        "ccc_before": ccc_before,
        "ccc_after": ccc_after,
        "delta_ccc": delta_ccc,
        "wc_need_before": wc_before,
        "wc_need_after": wc_after,
        "delta_cash": delta_cash,
        "ccc": ccc_after,  # alias comodo

        # info di servizio
        "notes": {
            "no_change_applied": (dso_delta == 0.0 and dio_delta == 0.0 and dpo_delta == 0.0),
        },

        # assunzioni esplicite → utili per frontend/chatbot
        "assumptions": {
            "sales": sales,
            "cogs": cogs,
            "dso": dso,
            "dio": dio,
            "dpo": dpo,
            "dso_delta": dso_delta,
            "dio_delta": dio_delta,
            "dpo_delta": dpo_delta,
            "days_in_year": days_in_year,
            "wc_on_sales_share": wc_on_sales_share,
            "wc_on_cogs_share": wc_on_cogs_share,
        },
    }
