"""
Entrepreneurial Decisions Simulator

Simulates Hiring, Pricing, Expansion, Marketing decisions
with Best/Realistic/Worst scenarios.
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class DecisionScenario(str, Enum):
    """Scenario types"""
    BEST = "best"
    REALISTIC = "realistic"
    WORST = "worst"


class DecisionVerdict(str, Enum):
    """Decision verdict"""
    YES = "yes"
    NO = "no"
    MAYBE = "maybe"
    WAIT = "wait"


@dataclass
class ScenarioResult:
    """Single scenario outcome"""
    scenario: DecisionScenario
    generates_revenue: float  # EUR
    generates_profit: float   # EUR
    payback_months: int
    cash_impact_negative: float  # Peak cash needed
    roi_pct: float
    risk_factors: list
    verdict: DecisionVerdict


@dataclass
class Decision:
    """Complete decision simulation"""
    decision_type: str  # "hiring", "pricing", "expansion", "marketing"
    description: str
    scenarios: Dict[str, ScenarioResult]
    recommendation: DecisionVerdict
    recommendation_reason: str
    minimum_threshold: Optional[float] = None  # EUR or metric minimum
    best_case_cost: float = 0
    realistic_cost: float = 0
    worst_case_cost: float = 0


class EntrepreneurialSimulator:
    """Simulate business decisions"""
    
    def simulate_hiring(
        self,
        role: str,
        salary: float,
        company_revenue: float,
        company_margin: float,
        current_capacity_utilization: float,  # 0-1
        industry: str = "default",
    ) -> Decision:
        """
        Simulate hiring decision.
        
        Args:
            role: Job title
            salary: Annual salary (EUR)
            company_revenue: Annual revenue (EUR)
            company_margin: Profit margin (%)
            current_capacity_utilization: How much capacity being used (0-1)
            
        Returns:
            Decision with scenarios
        """
        
        # Industry benchmarks
        benchmarks = {
            "sales": {"revenue_generation": 3.5, "ramp_months": 4},
            "engineering": {"revenue_generation": 4.0, "ramp_months": 3},
            "operations": {"revenue_generation": 2.0, "ramp_months": 6},
            "management": {"revenue_generation": 1.5, "ramp_months": 6},
            "default": {"revenue_generation": 2.5, "ramp_months": 4},
        }
        
        benchmark = benchmarks.get(industry.lower(), benchmarks["default"])
        revenue_multiplier = benchmark["revenue_generation"]
        ramp_months = benchmark["ramp_months"]
        
        # Real cost of employee
        real_cost = salary * 1.3  # Salary + 30% overhead
        
        # Realistic new revenue (function of company size*multiplier - but capped by capacity)
        base_generation = company_revenue * revenue_multiplier / 100  # Assumes you need this role per €100k revenue
        
        # SCENARIOS
        scenarios = {}
        
        # BEST: Top performer, fast ramp, max generation
        best = ScenarioResult(
            scenario=DecisionScenario.BEST,
            generates_revenue=base_generation * 1.4,  # 40% above average
            generates_profit=base_generation * 1.4 * company_margin / 100,
            payback_months=int(real_cost / (base_generation * 1.4 * company_margin / 100 / 12)),
            cash_impact_negative=-real_cost,
            roi_pct=((base_generation * 1.4 * company_margin / 100) - real_cost) / real_cost * 100,
            risk_factors=["Low - top quartile performer assumed"],
            verdict=DecisionVerdict.YES,
        )
        scenarios[DecisionScenario.BEST] = best
        
        # REALISTIC: Average performer, normal ramp
        realistic = ScenarioResult(
            scenario=DecisionScenario.REALISTIC,
            generates_revenue=base_generation,
            generates_profit=base_generation * company_margin / 100,
            payback_months=int(real_cost / (base_generation * company_margin / 100 / 12)) if (base_generation * company_margin / 100) > 0 else 999,
            cash_impact_negative=-real_cost,
            roi_pct=((base_generation * company_margin / 100) - real_cost) / real_cost * 100,
            risk_factors=[
                f"Average ramp-up time: {ramp_months} months",
                "Requires management attention",
                "Cash impact: negative until payback",
            ],
            verdict=DecisionVerdict.MAYBE if realistic.payback_months < 18 else DecisionVerdict.WAIT,
        )
        scenarios[DecisionScenario.REALISTIC] = realistic
        
        # WORST: Underperformer, long ramp, low generation
        worst = ScenarioResult(
            scenario=DecisionScenario.WORST,
            generates_revenue=base_generation * 0.6,  # 40% below average
            generates_profit=base_generation * 0.6 * company_margin / 100,
            payback_months=int(real_cost / (base_generation * 0.6 * company_margin / 100 / 12)) if (base_generation * 0.6 * company_margin / 100) > 0 else 999,
            cash_impact_negative=-real_cost * 1.5,  # Longer time needed
            roi_pct=((base_generation * 0.6 * company_margin / 100) - real_cost) / real_cost * 100,
            risk_factors=[
                "Poor culture fit or skill mismatch",
                "May need replacement in 12-18 months",
                "Significant cash impact",
                "Opportunity cost of management time",
            ],
            verdict=DecisionVerdict.NO,
        )
        scenarios[DecisionScenario.WORST] = worst
        
        # RECOMMENDATION
        if current_capacity_utilization < 0.7:
            recommendation = DecisionVerdict.WAIT
            reason = "You have unused capacity. Optimize first, then hire."
        elif realistic.payback_months > 18:
            recommendation = DecisionVerdict.WAIT
            reason = "Payback too long. Consolidate margins first."
        elif company_margin < 15:
            recommendation = DecisionVerdict.WAIT
            reason = "Margin too fragile. Add fixed costs only when quality is solid."
        else:
            recommendation = DecisionVerdict.YES
            reason = "Good capacity utilization + healthy margins. Hire."
        
        return Decision(
            decision_type="hiring",
            description=f"Hire {role}: €{salary:,.0f}/year",
            scenarios=scenarios,
            recommendation=recommendation,
            recommendation_reason=reason,
            minimum_threshold=base_generation,
            best_case_cost=real_cost,
            realistic_cost=real_cost,
            worst_case_cost=real_cost * 1.5,
        )
    
    def simulate_pricing(
        self,
        current_price: float,
        current_volume: int,  # Units/year
        price_elasticity: float = -1.0,  # % change in quantity / % change in price
        current_margin: float = 35,
        market_position: str = "competitive",  # "discount", "competitive", "premium"
    ) -> Decision:
        """
        Simulate pricing change.
        
        Args:
            current_price: Current price per unit
            current_volume: Current annual units sold
            price_elasticity: Elasticity of demand
            current_margin: Current profit margin %
        """
        
        current_revenue = current_price * current_volume
        current_profit = current_revenue * current_margin / 100
        
        scenarios = {}
        
        # Test different price increases
        price_increases = [0.05, 0.10, 0.15]  # 5%, 10%, 15%
        
        best = None
        realistic = None
        worst = None
        
        for i, increase in enumerate(price_increases):
            new_price = current_price * (1 + increase)
            # Volume change based on elasticity
            volume_change = increase * price_elasticity
            new_volume = int(current_volume * (1 + volume_change))
            new_revenue = new_price * new_volume
            new_profit = new_revenue * current_margin / 100
            
            scenario = ScenarioResult(
                scenario=DecisionScenario.BEST if i == 0 else (DecisionScenario.REALISTIC if i == 1 else DecisionScenario.WORST),
                generates_revenue=new_revenue,
                generates_profit=new_profit,
                payback_months=0,  # Pricing has immediate impact
                cash_impact_negative=0,
                roi_pct=((new_profit - current_profit) / current_profit) * 100,
                risk_factors=[
                    f"+{increase*100:.0f}% price increase",
                    f"{volume_change*100:.1f}% volume change",
                    f"New revenue: €{new_revenue:,.0f}",
                ] if new_profit > current_profit else [
                    "Volume drop too high - margin erodes",
                ],
                verdict=DecisionVerdict.YES if new_profit > current_profit else DecisionVerdict.NO,
            )
            
            if i == 0:
                best = scenario
            elif i == 1:
                realistic = scenario
            else:
                worst = scenario
            
            if scenario.verdict == DecisionVerdict.YES and realistic is None:
                realistic = scenario
        
        scenarios[DecisionScenario.BEST] = best
        scenarios[DecisionScenario.REALISTIC] = realistic or best
        scenarios[DecisionScenario.WORST] = worst or best
        
        # Recommendation
        if realistic and realistic.roi_pct > 5:
            recommendation = DecisionVerdict.YES
            reason = "Pricing increase is profitable with acceptable volume risk"
        else:
            recommendation = DecisionVerdict.MAYBE
            reason = "Test first with limited segment"
        
        return Decision(
            decision_type="pricing",
            description=f"Price optimization: €{current_price:.2f} → test increases",
            scenarios=scenarios,
            recommendation=recommendation,
            recommendation_reason=reason,
            minimum_threshold=current_price,
        )
    
    def simulate_expansion(
        self,
        entry_cost: float,
        year1_revenue_potential: float,
        year2_revenue_potential: float,
        required_management_time_weeks: int,
        distraction_risk_to_core: float = 0.05,  # % of core revenue at risk
    ) -> Decision:
        """Simulate market/geographic expansion"""
        
        # Impact on core business (negative)
        core_revenue_at_risk = year1_revenue_potential / 2 * distraction_risk_to_core
        
        best = ScenarioResult(
            scenario=DecisionScenario.BEST,
            generates_revenue=year1_revenue_potential + year2_revenue_potential,
            generates_profit=year1_revenue_potential * 0.20 + year2_revenue_potential * 0.25,
            payback_months=3,
            cash_impact_negative=-entry_cost,
            roi_pct=((year1_revenue_potential * 0.20 + year2_revenue_potential * 0.25) - entry_cost) / entry_cost * 100,
            risk_factors=["Optimistic market reception", "Quick team integration"],
            verdict=DecisionVerdict.YES,
        )
        
        realistic = ScenarioResult(
            scenario=DecisionScenario.REALISTIC,
            generates_revenue=year1_revenue_potential * 0.7 + year2_revenue_potential * 0.85,
            generates_profit=(year1_revenue_potential * 0.7 * 0.18) + (year2_revenue_potential * 0.85 * 0.22) - core_revenue_at_risk,
            payback_months=6,
            cash_impact_negative=-entry_cost - core_revenue_at_risk,
            roi_pct=((year1_revenue_potential * 0.7 * 0.18 + year2_revenue_potential * 0.85 * 0.22) - entry_cost) / entry_cost * 100,
            risk_factors=[
                f"Requires {required_management_time_weeks} weeks of leadership time",
                f"Core business risk: €{core_revenue_at_risk:,.0f} at risk",
                "Slower revenue ramp than expected",
            ],
            verdict=DecisionVerdict.MAYBE,
        )
        
        worst = ScenarioResult(
            scenario=DecisionScenario.WORST,
            generates_revenue=year1_revenue_potential * 0.3 + year2_revenue_potential * 0.4,
            generates_profit=(year1_revenue_potential * 0.3 * 0.15) - entry_cost - (core_revenue_at_risk * 2),
            payback_months=18,
            cash_impact_negative=-entry_cost - (core_revenue_at_risk * 2),
            roi_pct=-50,  # Loss scenario
            risk_factors=[
                "Market didn't accept offering",
                "Core business deteriorated significantly",
                "Major management distraction",
            ],
            verdict=DecisionVerdict.NO,
        )
        
        recommendation = DecisionVerdict.WAIT
        reason = "Expansion makes sense only if core is rock-solid and you can afford distraction"
        
        return Decision(
            decision_type="expansion",
            description=f"Market expansion: €{entry_cost:,.0f} investment",
            scenarios={"best": best, "realistic": realistic, "worst": worst},
            recommendation=recommendation,
            recommendation_reason=reason,
            minimum_threshold=entry_cost,
        )


def get_simulator() -> EntrepreneurialSimulator:
    return EntrepreneurialSimulator()
