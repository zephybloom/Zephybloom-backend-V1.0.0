"""
Industry Intelligence Module (FASE 2)

Defines industry profiles with specific thresholds, metrics, benchmarks, and recommendations.
Makes the system aware of industry context and adapt decisions accordingly.

Supported industries:
- SaaS (Software as a Service)
- Retail (e-commerce & traditional)
- Manufacturing (physical goods production)
- Services (professional & consulting)
- Ecommerce (direct e-commerce operations)
- Default (universal fallback)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum


class IndustryCode(str, Enum):
    """Industry identifiers"""
    SAAS = "saas"
    RETAIL = "retail"
    MANUFACTURING = "manufacturing"
    SERVICES = "services"
    ECOMMERCE = "ecommerce"
    DEFAULT = "default"


@dataclass
class IndustryProfile:
    """Complete profile for an industry"""
    
    # Identification
    code: IndustryCode
    name: str
    
    # Financial Health Thresholds (what's healthy for THIS industry)
    healthy_gross_margin_pct: float      # What % gross margin is considered healthy
    healthy_net_margin_pct: float        # What % net margin is considered healthy
    healthy_ebitda_margin_pct: float     # What % EBITDA margin is considered healthy
    healthy_roi_pct: float               # What ROI % is considered acceptable
    max_fixed_cost_pct_revenue: float    # Max % of revenue that should be fixed costs
    
    # KPI Specifics
    key_kpis: List[str]                  # Most important metrics for this industry
    seasonal_impact: bool                # Does this industry have seasonality?
    capital_intensity: str               # "low", "medium", "high"
    typical_annual_growth_rate: float    # What growth % is normal
    talent_cost_as_pct_revenue: float    # Typical team cost as % of revenue
    inventory_impact: bool               # Does inventory matter? (affects CCC)
    
    # Decision Priorities (what actions matter most)
    top_decisions: List[str]             # Top 5 decision types for this industry
    decision_focus: str                  # What's the core competitive advantage
    
    # Industry-specific risks
    common_pitfalls: List[str]           # Common mistakes in this industry
    sustainability_concern: str          # What threatens sustainability
    scaling_challenge: str               # What gets harder as you grow


@dataclass
class BenchmarkData:
    """Benchmark comparison vs peers"""
    
    industry: IndustryCode
    metric: str                          # "gross_margin", "net_margin", "roi", etc.
    your_value: float
    industry_average: float
    industry_median: float
    industry_p10: float                  # 10th percentile (bottom 10%)
    industry_p25: float                  # 25th percentile
    industry_p75: float                  # 75th percentile
    industry_p90: float                  # 90th percentile (top 10%)
    
    @property
    def percentile_rank(self) -> str:
        """Where does your value rank vs peers?"""
        if self.your_value >= self.industry_p90:
            return "Top 10%"
        elif self.your_value >= self.industry_p75:
            return "Top 25%"
        elif self.your_value >= self.industry_median:
            return "Above average"
        elif self.your_value >= self.industry_p25:
            return "Around average"
        else:
            return "Below average"
    
    @property
    def gap_to_median_pct(self) -> float:
        """How much % improvement to reach median?"""
        if self.industry_median == 0:
            return 0
        return ((self.industry_median - self.your_value) / self.industry_median) * 100


class IndustryRegistry:
    """Central registry of all industry profiles and benchmarks"""
    
    PROFILES: Dict[IndustryCode, IndustryProfile] = {
        
        # ===== SAAS =====
        IndustryCode.SAAS: IndustryProfile(
            code=IndustryCode.SAAS,
            name="Software as a Service (SaaS)",
            
            # SaaS is HIGH margin business (minimal COGS)
            healthy_gross_margin_pct=0.75,      # 75% is healthy for SaaS (low COGS)
            healthy_net_margin_pct=0.20,        # 20% is solid (accounting for customer acquisition)
            healthy_ebitda_margin_pct=0.40,     # 40% is target (high operating leverage)
            healthy_roi_pct=0.40,               # 40% ROI on investments
            max_fixed_cost_pct_revenue=0.50,    # Can sustain 50% fixed costs (recurring revenue base)
            
            key_kpis=["churn_rate", "ltv", "cac", "arr", "mrr", "expansion_rate"],
            seasonal_impact=False,
            capital_intensity="low",
            typical_annual_growth_rate=0.30,    # 30% growth is normal for SaaS
            talent_cost_as_pct_revenue=0.15,    # 15% of revenue typically goes to team
            inventory_impact=False,
            
            top_decisions=[
                "Reduce churn (retention is everything)",
                "Improve LTV (lifetime value)",
                "Optimize CAC/LTV ratio (unit economics)",
                "Pricing model optimization",
                "Expansion revenue (upsell/cross-sell)",
            ],
            decision_focus="Recurring revenue quality and expansion",
            
            common_pitfalls=[
                "High churn masked by new customer growth",
                "Focusing on ARR instead of net retention",
                "Selling to wrong customer segment",
                "Burning cash on CAC without LTV clarity",
                "Free tier cannibalizing paid upgrades",
            ],
            sustainability_concern="Customer churn eroding recurring revenue base",
            scaling_challenge="Customer acquisition cost growing faster than LTV",
        ),
        
        # ===== RETAIL =====
        IndustryCode.RETAIL: IndustryProfile(
            code=IndustryCode.RETAIL,
            name="Retail (Online & Physical)",
            
            # Retail is LOW margin, HIGH volume
            healthy_gross_margin_pct=0.35,      # 35% gross is healthy (accounts for inventory shrinkage)
            healthy_net_margin_pct=0.05,        # 5% net is solid (thin margins, volume dependent)
            healthy_ebitda_margin_pct=0.12,     # 12% EBITDA (stores, staff, operations)
            healthy_roi_pct=0.15,               # 15% ROI (low margin business)
            max_fixed_cost_pct_revenue=0.30,    # 30% max fixed costs (rent, salary, overhead)
            
            key_kpis=["inventory_turnover", "selling_price_variance", "stockout_rate", "foot_traffic", "basket_size"],
            seasonal_impact=True,
            capital_intensity="medium",
            typical_annual_growth_rate=0.10,    # 10% growth is healthy for retail
            talent_cost_as_pct_revenue=0.10,    # 10% team costs
            inventory_impact=True,
            
            top_decisions=[
                "Inventory optimization (tie-up vs stockouts)",
                "Pricing strategy and margin recovery",
                "Seasonal planning and demand forecasting",
                "Channel mix (online vs physical)",
                "Customer loyalty and repeat rate",
            ],
            decision_focus="Inventory velocity and margin protection",
            
            common_pitfalls=[
                "Over-stocking on slow-moving inventory",
                "Under-pricing to match competitors",
                "Ignoring seasonality in inventory",
                "High return rates without fixing cause",
                "Lost sales due to stockouts",
            ],
            sustainability_concern="Inventory carrying costs and shrinkage",
            scaling_challenge="Inventory complexity grows exponentially",
        ),
        
        # ===== MANUFACTURING =====
        IndustryCode.MANUFACTURING: IndustryProfile(
            code=IndustryCode.MANUFACTURING,
            name="Manufacturing (Physical Goods)",
            
            # Manufacturing is capital intensive, margin varies
            healthy_gross_margin_pct=0.40,      # 40% gross (COGS is high, quality matters)
            healthy_net_margin_pct=0.08,        # 8% net (after depreciation, interest)
            healthy_ebitda_margin_pct=0.15,     # 15% EBITDA (before capital costs)
            healthy_roi_pct=0.18,               # 18% ROI (capital intensive)
            max_fixed_cost_pct_revenue=0.35,    # 35% fixed costs (machinery, depreciation)
            
            key_kpis=["capacity_utilization", "cogs_pct", "quality_defect_rate", "lead_time", "on_time_delivery"],
            seasonal_impact=True,
            capital_intensity="high",
            typical_annual_growth_rate=0.12,    # 12% growth is solid for manufacturing
            talent_cost_as_pct_revenue=0.12,    # 12% team costs (skilled workers)
            inventory_impact=True,
            
            top_decisions=[
                "Capacity utilization and production optimization",
                "COGS reduction through supply chain",
                "Quality improvement (reduces rework/returns)",
                "Equipment investment decisions",
                "Lead time reduction",
            ],
            decision_focus="Operational efficiency and capacity management",
            
            common_pitfalls=[
                "Running below capacity but not fixing demand",
                "Over-investing in automation ROI is unclear",
                "Poor supply chain visibility leading to delays",
                "Quality issues creating customer returns",
                "Excess inventory from demand forecasting errors",
            ],
            sustainability_concern="High fixed costs and capital depreciation",
            scaling_challenge="Capacity constraints require capital, not just effort",
        ),
        
        # ===== SERVICES =====
        IndustryCode.SERVICES: IndustryProfile(
            code=IndustryCode.SERVICES,
            name="Professional Services & Consulting",
            
            # Services is people-dependent (labor arbitrage model)
            healthy_gross_margin_pct=0.60,      # 60% gross (minimal COGS, people are cost)
            healthy_net_margin_pct=0.15,        # 15% net (after people costs, overhead)
            healthy_ebitda_margin_pct=0.25,     # 25% EBITDA (high operating leverage)
            healthy_roi_pct=0.25,               # 25% ROI (people-based business)
            max_fixed_cost_pct_revenue=0.40,    # 40% fixed costs (people, office)
            
            key_kpis=["utilization_rate", "billable_rate", "bench_time", "client_satisfaction", "project_margin"],
            seasonal_impact=False,
            capital_intensity="low",
            typical_annual_growth_rate=0.20,    # 20% growth is healthy
            talent_cost_as_pct_revenue=0.35,    # 35% of revenue goes to team (key asset)
            inventory_impact=False,
            
            top_decisions=[
                "Utilization rate (% of time on billable work)",
                "Service pricing and rate increases",
                "Bench time management (people between projects)",
                "Hiring for growth (high leverage people cost)",
                "Service line profitability (some projects more profitable)",
            ],
            decision_focus="People productivity and pricing power",
            
            common_pitfalls=[
                "Hiring ahead of demand (bench time kills margin)",
                "Under-pricing services (race to bottom)",
                "Losing experienced people to competitors",
                "Projects going over budget due to scope creep",
                "Geographic arbitrage collapsing due to remote work",
            ],
            sustainability_concern="People dependency and bench time",
            scaling_challenge="Each unit of growth requires people",
        ),
        
        # ===== ECOMMERCE =====
        IndustryCode.ECOMMERCE: IndustryProfile(
            code=IndustryCode.ECOMMERCE,
            name="E-commerce (Direct to Consumer)",
            
            # Ecommerce is retail but with digital specifics
            healthy_gross_margin_pct=0.45,      # 45% gross (higher than physical retail)
            healthy_net_margin_pct=0.06,        # 6% net (digital costs, logistics)
            healthy_ebitda_margin_pct=0.15,     # 15% EBITDA
            healthy_roi_pct=0.12,               # 12% ROI (highly competitive)
            max_fixed_cost_pct_revenue=0.25,    # 25% fixed costs (digital easier to scale)
            
            key_kpis=["conversion_rate", "cac_to_ltv_ratio", "cart_abandonment", "repeat_order_rate", "aov"],
            seasonal_impact=True,
            capital_intensity="low",
            typical_annual_growth_rate=0.25,    # 25% growth is expected
            talent_cost_as_pct_revenue=0.08,    # 8% team costs (larger scale, less hands-on)
            inventory_impact=True,
            
            top_decisions=[
                "Conversion rate optimization (funnel improvements)",
                "CAC reduction (cheaper customer acquisition)",
                "Repeat order rate (lifetime value)",
                "Average order value (pricing/bundling)",
                "Logistics cost reduction (biggest pain)",
            ],
            decision_focus="Conversion efficiency and unit economics",
            
            common_pitfalls=[
                "Burning cash on customer acquisition without retention",
                "Inventory mismatched to demand (excess dead stock)",
                "Logistics costs eating profitability",
                "Chasing volume without unit economics",
                "Brand weakness (low repeat rate)",
            ],
            sustainability_concern="Customer acquisition cost vs lifetime value mismatch",
            scaling_challenge="Logistics complexity grows faster than revenue",
        ),
        
        # ===== DEFAULT (UNIVERSAL) =====
        IndustryCode.DEFAULT: IndustryProfile(
            code=IndustryCode.DEFAULT,
            name="Generic / Unknown Industry",
            
            # Conservative universal thresholds
            healthy_gross_margin_pct=0.35,
            healthy_net_margin_pct=0.10,
            healthy_ebitda_margin_pct=0.18,
            healthy_roi_pct=0.15,
            max_fixed_cost_pct_revenue=0.35,
            
            key_kpis=["revenue", "margin", "profitability", "cash_flow"],
            seasonal_impact=False,
            capital_intensity="medium",
            typical_annual_growth_rate=0.15,
            talent_cost_as_pct_revenue=0.15,
            inventory_impact=False,
            
            top_decisions=["Improve profitability", "Increase revenue", "Reduce costs", "Optimize cash flow"],
            decision_focus="Core financial health",
            
            common_pitfalls=["Ignoring unit economics", "Growing without profitability"],
            sustainability_concern="Insufficient profitability for sustainability",
            scaling_challenge="Unclear unit economics make scaling risky",
        ),
    }
    
    # ===== BENCHMARK DATA BY INDUSTRY =====
    # Real-world benchmarks (approximate medians, sourced from industry reports)
    BENCHMARKS: Dict[IndustryCode, Dict[str, Dict[str, float]]] = {
        IndustryCode.SAAS: {
            "gross_margin_pct": {
                "p10": 0.60, "p25": 0.70, "median": 0.78, "p75": 0.85, "p90": 0.90
            },
            "net_margin_pct": {
                "p10": -0.05, "p25": 0.05, "median": 0.18, "p75": 0.30, "p90": 0.45
            },
            "roi_pct": {
                "p10": 0.05, "p25": 0.15, "median": 0.35, "p75": 0.55, "p90": 0.85
            },
        },
        IndustryCode.RETAIL: {
            "gross_margin_pct": {
                "p10": 0.20, "p25": 0.25, "median": 0.35, "p75": 0.45, "p90": 0.55
            },
            "net_margin_pct": {
                "p10": -0.02, "p25": 0.01, "median": 0.05, "p75": 0.08, "p90": 0.12
            },
        },
        IndustryCode.MANUFACTURING: {
            "gross_margin_pct": {
                "p10": 0.25, "p25": 0.32, "median": 0.40, "p75": 0.50, "p90": 0.60
            },
            "net_margin_pct": {
                "p10": 0.02, "p25": 0.04, "median": 0.08, "p75": 0.12, "p90": 0.18
            },
        },
        IndustryCode.SERVICES: {
            "gross_margin_pct": {
                "p10": 0.45, "p25": 0.52, "median": 0.60, "p75": 0.68, "p90": 0.75
            },
            "net_margin_pct": {
                "p10": 0.05, "p25": 0.10, "median": 0.15, "p75": 0.22, "p90": 0.30
            },
        },
        IndustryCode.ECOMMERCE: {
            "gross_margin_pct": {
                "p10": 0.30, "p25": 0.38, "median": 0.45, "p75": 0.55, "p90": 0.65
            },
            "net_margin_pct": {
                "p10": -0.05, "p25": 0.01, "median": 0.06, "p75": 0.10, "p90": 0.15
            },
        },
    }
    
    @classmethod
    def get_profile(cls, industry_code: str) -> IndustryProfile:
        """Get industry profile by code (case-insensitive)"""
        try:
            code = IndustryCode(industry_code.lower())
            return cls.PROFILES[code]
        except (ValueError, KeyError):
            return cls.PROFILES[IndustryCode.DEFAULT]
    
    @classmethod
    def get_benchmark(
        cls,
        industry_code: str,
        metric: str,
        your_value: float,
    ) -> Optional[BenchmarkData]:
        """Get benchmark comparison for a specific metric"""
        try:
            code = IndustryCode(industry_code.lower())
        except ValueError:
            code = IndustryCode.DEFAULT
        
        benchmarks = cls.BENCHMARKS.get(code, {})
        metric_data = benchmarks.get(metric)
        
        if not metric_data:
            return None
        
        return BenchmarkData(
            industry=code,
            metric=metric,
            your_value=your_value,
            industry_average=(metric_data["p25"] + metric_data["p75"]) / 2,
            industry_median=metric_data["median"],
            industry_p10=metric_data["p10"],
            industry_p25=metric_data["p25"],
            industry_p75=metric_data["p75"],
            industry_p90=metric_data["p90"],
        )
    
    @classmethod
    def get_all_profiles(cls) -> Dict[IndustryCode, IndustryProfile]:
        """Get all industry profiles"""
        return cls.PROFILES


def get_industry_profile(industry_code: str) -> IndustryProfile:
    """Convenience function to get industry profile"""
    return IndustryRegistry.get_profile(industry_code)


def get_benchmark_comparison(
    industry_code: str,
    metric: str,
    your_value: float,
) -> Optional[BenchmarkData]:
    """Convenience function to get benchmark comparison"""
    return IndustryRegistry.get_benchmark(industry_code, metric, your_value)
