"""Monthly CFO report builder.

Creates a board-ready executive report from current company data, War Room
priorities, KPI memory and decision memory.
"""

from datetime import datetime
from types import SimpleNamespace
from typing import Any, Dict, List, Optional

from core.analysis import analyze_company
from core.cfo_memory import build_cfo_memory_summary
from core.decision_memory import build_decision_memory_summary, list_decision_memory
from core.war_room_engine import build_unified_war_room


def build_monthly_cfo_report(
    company_data: Dict[str, Any],
    operational_data_by_sector: Dict[str, Dict[str, Any]],
    tenant_id: str,
    company_id: str = "default",
    company_name: str = "Azienda",
    period: Optional[str] = None,
    session: Any = None,
) -> Dict[str, Any]:
    """Build a premium monthly CFO report."""

    period_label = period or datetime.utcnow().strftime("%Y-%m")
    metrics = _extract_metrics(company_data)
    analysis = analyze_company(
        fatturato=metrics["fatturato"],
        costi_variabili=metrics["costi_variabili"],
        costi_fissi=metrics["costi_fissi"],
        investimenti=metrics["investimenti"],
        settore=company_data.get("settore", "default"),
        company_name=company_name,
        ammortamenti=metrics["ammortamenti"],
    )
    kpis = _normalize_kpis(metrics, analysis.kpi_snapshot)
    decision_summary = build_decision_memory_summary(tenant_id, session=session)
    decisions = list_decision_memory(tenant_id, session=session)
    memory_summary = build_cfo_memory_summary(
        session=session,
        tenant_id=tenant_id,
        company_id=company_id,
        months=12,
    )
    war_room = build_unified_war_room(
        operational_data_by_sector=operational_data_by_sector,
        active_sector=company_data.get("settore"),
        decision_memory_context={
            "decisions": decisions,
            "summary": decision_summary,
        },
    )

    health = _health_label(kpis)
    score = _report_score(kpis, decision_summary, memory_summary, war_room)
    priority = war_room.get("priority_decision") or {}
    executive = war_room.get("executive_summary") or {}
    open_decisions = [item for item in decisions if item.get("status") == "todo"]
    completed_decisions = [item for item in decisions if item.get("status") == "done"]
    data_quality = _data_quality(war_room, operational_data_by_sector)
    next_30_days = _next_30_days(kpis, priority, open_decisions, memory_summary)
    board_decisions = _board_decisions(priority, decision_summary, data_quality, kpis)
    team_questions = _team_questions(data_quality, war_room, open_decisions)

    sections = {
        "executive_summary": {
            "headline": _headline(company_name, health, kpis),
            "diagnosis": _diagnosis(kpis, memory_summary, executive),
            "board_message": _board_message(priority, decision_summary),
            "score": score,
            "health": health,
        },
        "ceo_brief": _ceo_brief(company_name, health, kpis, priority, next_30_days),
        "finance_brief": _finance_brief(kpis, memory_summary, decision_summary, data_quality),
        "board_decisions": board_decisions,
        "team_questions": team_questions,
        "financial_snapshot": {
            "revenue_eur": kpis.fatturato,
            "gross_profit_eur": kpis.margine_contribuzione,
            "gross_margin_pct": round(kpis.mc_rate * 100, 1),
            "ebitda_eur": kpis.ebitda,
            "ebitda_margin_pct": _pct(kpis.ebitda, kpis.fatturato),
            "net_profit_eur": kpis.utile,
            "net_margin_pct": _pct(kpis.utile, kpis.fatturato),
            "roi_pct": round(kpis.roi * 100, 1),
        },
        "trend_memory": {
            "has_memory": memory_summary.get("has_memory", False),
            "executive_memory": memory_summary.get("executive_memory"),
            "trend_summary": memory_summary.get("trend_summary"),
            "momentum_label": memory_summary.get("momentum_label"),
            "momentum_score": memory_summary.get("momentum_score"),
            "alerts": memory_summary.get("alerts", [])[:5],
            "next_actions": memory_summary.get("next_memory_actions", [])[:5],
        },
        "war_room": {
            "priority_decision": priority,
            "weekly_agenda": war_room.get("weekly_agenda", [])[:5],
            "decision_queue": war_room.get("decision_queue", [])[:5],
            "stop_go_board": war_room.get("stop_go_board", [])[:5],
            "data_gap_board": war_room.get("data_gap_board", [])[:8],
        },
        "decision_memory": {
            "summary": decision_summary,
            "open_decisions": open_decisions[:5],
            "completed_decisions": completed_decisions[:5],
            "best_decision": decision_summary.get("best_decision"),
        },
        "next_30_days": next_30_days,
        "data_quality": data_quality,
    }

    return {
        "version": "monthly-cfo-report-v1",
        "company_id": company_id,
        "company_name": company_name,
        "period": period_label,
        "generated_at": datetime.utcnow().isoformat(),
        "sections": sections,
        "markdown": _to_markdown(company_name, period_label, sections),
        "premium_outputs": {
            "board_ready_report": True,
            "uses_war_room": True,
            "uses_kpi_memory": True,
            "uses_decision_memory": True,
            "ready_for_pdf_export": True,
            "board_decisions": True,
            "team_questions": True,
            "ceo_finance_briefs": True,
        },
    }


def _extract_metrics(company_data: Dict[str, Any]) -> Dict[str, float]:
    return {
        "fatturato": float(company_data.get("fatturato") or company_data.get("revenue") or 0),
        "costi_variabili": float(company_data.get("costi_variabili") or company_data.get("variable_costs") or 0),
        "costi_fissi": float(company_data.get("costi_fissi") or company_data.get("fixed_costs") or 0),
        "ammortamenti": float(company_data.get("ammortamenti") or company_data.get("depreciation") or 0),
        "investimenti": float(company_data.get("investimenti") or company_data.get("invested_capital") or 0),
    }


def _normalize_kpis(metrics: Dict[str, float], snapshot: Any) -> Any:
    return SimpleNamespace(
        fatturato=metrics["fatturato"],
        costi_variabili=metrics["costi_variabili"],
        costi_fissi=metrics["costi_fissi"],
        investimenti=metrics["investimenti"],
        margine_contribuzione=float(snapshot.gross_profit_eur or 0),
        mc_rate=float(snapshot.gross_margin_pct or 0) / 100,
        ebitda=float(snapshot.ebitda_eur or 0),
        utile=float(snapshot.net_profit_eur or 0),
        roi=float(snapshot.roi_pct or 0) / 100,
    )


def _pct(numerator: float, denominator: float) -> float:
    return round((float(numerator or 0) / float(denominator or 1)) * 100, 1)


def _health_label(kpis: Any) -> str:
    net_margin = _pct(kpis.utile, kpis.fatturato)
    if kpis.utile <= 0:
        return "da stabilizzare"
    if net_margin < 10:
        return "margine da proteggere"
    if net_margin >= 20 and kpis.roi >= 0.2:
        return "pronta a scalare con disciplina"
    return "solida ma da monitorare"


def _report_score(kpis: Any, decision_summary: Dict[str, Any], memory_summary: Dict[str, Any], war_room: Dict[str, Any]) -> int:
    score = 50
    net_margin = _pct(kpis.utile, kpis.fatturato)
    score += 15 if net_margin >= 20 else 5 if net_margin >= 10 else -10
    score += 10 if kpis.roi >= 0.2 else -5
    score += 10 if decision_summary.get("memory_quality") == "clean" else -5
    score += 10 if memory_summary.get("has_memory") else -5
    portfolio = war_room.get("portfolio_summary") or {}
    score += 5 if float(portfolio.get("readiness_avg_pct") or 0) >= 70 else -5
    return max(0, min(100, score))


def _headline(company_name: str, health: str, kpis: Any) -> str:
    return (
        f"{company_name}: {health}. "
        f"Utile { _eur(kpis.utile) }, margine netto {_pct(kpis.utile, kpis.fatturato)}%."
    )


def _diagnosis(kpis: Any, memory_summary: Dict[str, Any], executive: Dict[str, Any]) -> str:
    trend = memory_summary.get("trend_summary") or "Storico KPI ancora limitato."
    war_room_diagnosis = executive.get("diagnosis") or "War Room pronta per definire priorita' operative."
    return (
        f"Il conto economico mostra fatturato {_eur(kpis.fatturato)} e utile {_eur(kpis.utile)}. "
        f"{trend} {war_room_diagnosis}"
    )


def _board_message(priority: Dict[str, Any], decision_summary: Dict[str, Any]) -> str:
    if priority:
        return (
            f"Decisione principale: {priority.get('decision')}. "
            f"Prossimo passo: {priority.get('next_step') or priority.get('board_instruction')}"
        )
    if decision_summary.get("open_decisions"):
        return "Prima di aprire nuove iniziative, chiudere le decisioni War Room ancora aperte."
    return "Generare una War Room per trasformare l'analisi in agenda operativa."


def _next_30_days(
    kpis: Any,
    priority: Dict[str, Any],
    open_decisions: List[Dict[str, Any]],
    memory_summary: Dict[str, Any],
) -> List[Dict[str, str]]:
    actions: List[Dict[str, str]] = []
    if open_decisions:
        first = open_decisions[0]
        actions.append({
            "priority": "1",
            "action": first.get("next_action") or first.get("decision") or "Chiudi la prima decisione aperta",
            "owner": first.get("owner") or "CEO/CFO",
            "kpi": (first.get("success_metric") or {}).get("kpi") or "impatto reale EUR",
        })
    elif priority:
        actions.append({
            "priority": "1",
            "action": priority.get("next_step") or priority.get("decision"),
            "owner": "CEO/CFO",
            "kpi": "margine, cassa, impatto reale",
        })
    actions.append({
        "priority": "2",
        "action": "Aggiorna dati mensili e salva snapshot KPI",
        "owner": "Finance",
        "kpi": memory_summary.get("next_review") or "trend mese su mese",
    })
    actions.append({
        "priority": "3",
        "action": "Simula scenario base: +5% ricavi, +5% costi variabili, -3% costi fissi",
        "owner": "CFO",
        "kpi": f"margine netto target >= {_pct(kpis.utile, kpis.fatturato)}%",
    })
    return actions[:3]


def _ceo_brief(
    company_name: str,
    health: str,
    kpis: Any,
    priority: Dict[str, Any],
    next_actions: List[Dict[str, str]],
) -> Dict[str, Any]:
    first_action = next_actions[0]["action"] if next_actions else "Genera War Room e dati operativi completi"
    risk = (
        "Il rischio principale e' crescere perdendo margine e controllo sui costi."
        if kpis.utile > 0
        else "Il rischio principale e' continuare a operare senza recuperare utile e cassa."
    )
    return {
        "title": f"Sintesi CEO - {company_name}",
        "status": health,
        "one_liner": f"L'azienda e' {health}: utile {_eur(kpis.utile)}, margine netto {_pct(kpis.utile, kpis.fatturato)}%.",
        "main_risk": risk,
        "decision": priority.get("decision") or "Definire una priorita' War Room prima di aprire nuove iniziative.",
        "action_7_days": first_action,
        "meeting_note": "La prossima riunione deve chiudersi con owner, KPI e data di review per la decisione prioritaria.",
    }


def _finance_brief(
    kpis: Any,
    memory_summary: Dict[str, Any],
    decision_summary: Dict[str, Any],
    data_quality: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        "title": "Sintesi Finance",
        "kpi_watchlist": [
            f"Margine netto: {_pct(kpis.utile, kpis.fatturato)}%",
            f"EBITDA margin: {_pct(kpis.ebitda, kpis.fatturato)}%",
            f"ROI: {round(kpis.roi * 100, 1)}%",
            f"Readiness dati: {data_quality.get('readiness_avg_pct', 0)}%",
        ],
        "memory_status": memory_summary.get("trend_summary") or "Servono almeno 2 mesi per trend robusti.",
        "decision_status": (
            f"{decision_summary.get('open_decisions', 0)} decisioni aperte, "
            f"{decision_summary.get('completed_decisions', 0)} completate, "
            f"{decision_summary.get('archived_decisions', 0)} archiviate."
        ),
        "data_priority": data_quality.get("cfo_note"),
    }


def _board_decisions(
    priority: Dict[str, Any],
    decision_summary: Dict[str, Any],
    data_quality: Dict[str, Any],
    kpis: Any,
) -> List[Dict[str, str]]:
    approve = priority.get("decision") or "Approvare una War Room completa prima di nuove iniziative."
    block = (
        "Bloccare crescita non misurata finche' non sono chiari margine, cassa e impatto reale."
        if kpis.utile > 0
        else "Bloccare investimenti non essenziali finche' il margine non torna positivo."
    )
    monitor = (
        f"Monitorare {decision_summary.get('open_decisions', 0)} decisioni aperte e "
        f"readiness dati {data_quality.get('readiness_avg_pct', 0)}%."
    )
    ask = data_quality.get("missing_items", [])
    ask_text = (
        f"Chiedere al team il dato bloccante: {ask[0].get('field')}"
        if ask
        else "Chiedere al team aggiornamento KPI mensile e impatto delle azioni eseguite."
    )
    return [
        {"decision": "APPROVARE", "recommendation": approve, "why": "E' la leva con maggiore impatto operativo nel report."},
        {"decision": "BLOCCARE", "recommendation": block, "why": "Evita fatturato tossico, costi non controllati o cassa assorbita."},
        {"decision": "MONITORARE", "recommendation": monitor, "why": "Senza follow-up la memoria decisionale perde valore."},
        {"decision": "CHIEDERE", "recommendation": ask_text, "why": "La precisione del CFO dipende dalla qualita' dei dati."},
    ]


def _team_questions(
    data_quality: Dict[str, Any],
    war_room: Dict[str, Any],
    open_decisions: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    questions: List[Dict[str, str]] = []
    for gap in data_quality.get("missing_items", [])[:4]:
        questions.append({
            "owner": "Finance/Ops",
            "question": f"Qual e' il valore aggiornato di {gap.get('field')}?",
            "why": f"Serve per aumentare precisione su {gap.get('label', gap.get('sector', 'questo verticale'))}.",
        })
    for decision in open_decisions[:2]:
        questions.append({
            "owner": decision.get("owner") or "CEO/CFO",
            "question": decision.get("follow_up_question") or f"Qual e' l'impatto reale di {decision.get('decision_id')}?",
            "why": "Serve per chiudere la decisione e aggiornare la memoria CFO.",
        })
    if not questions:
        stop_go = (war_room.get("stop_go_board") or [{}])[0]
        questions.append({
            "owner": "CEO/CFO",
            "question": "Quale iniziativa vuoi approvare, bloccare o simulare nei prossimi 7 giorni?",
            "why": stop_go.get("kill_switch") or "Serve a trasformare il report in decisione operativa.",
        })
    return questions[:6]


def _data_quality(war_room: Dict[str, Any], operational_data_by_sector: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    portfolio = war_room.get("portfolio_summary") or {}
    gaps = war_room.get("data_gap_board") or []
    return {
        "readiness_avg_pct": portfolio.get("readiness_avg_pct", 0),
        "sectors_with_data": list((operational_data_by_sector or {}).keys()),
        "missing_items": gaps[:8],
        "cfo_note": (
            "Report ad alta precisione."
            if float(portfolio.get("readiness_avg_pct") or 0) >= 75
            else "Per aumentare precisione servono piu' dati operativi di settore."
        ),
    }


def _to_markdown(company_name: str, period: str, sections: Dict[str, Any]) -> str:
    snapshot = sections["financial_snapshot"]
    executive = sections["executive_summary"]
    ceo = sections["ceo_brief"]
    finance = sections["finance_brief"]
    memory = sections["decision_memory"]["summary"]
    actions = "\n".join(
        f"{item['priority']}. {item['action']} | Owner: {item['owner']} | KPI: {item['kpi']}"
        for item in sections["next_30_days"]
    )
    board = "\n".join(
        f"- {item['decision']}: {item['recommendation']}"
        for item in sections["board_decisions"]
    )
    questions = "\n".join(
        f"- {item['owner']}: {item['question']}"
        for item in sections["team_questions"]
    )
    return (
        f"# Report CFO Mensile - {company_name} ({period})\n\n"
        f"## Executive Summary\n{executive['headline']}\n\n{executive['diagnosis']}\n\n"
        f"## Sintesi CEO\n{ceo['one_liner']}\n\nRischio: {ceo['main_risk']}\n\n"
        f"Decisione: {ceo['decision']}\n\nAzione entro 7 giorni: {ceo['action_7_days']}\n\n"
        f"## Numeri chiave\n"
        f"- Fatturato: {_eur(snapshot['revenue_eur'])}\n"
        f"- Utile netto: {_eur(snapshot['net_profit_eur'])} ({snapshot['net_margin_pct']}%)\n"
        f"- EBITDA: {_eur(snapshot['ebitda_eur'])} ({snapshot['ebitda_margin_pct']}%)\n"
        f"- ROI: {snapshot['roi_pct']}%\n\n"
        f"## Decisioni da board\n{board}\n\n"
        f"## Domande CFO al team\n{questions}\n\n"
        f"## Sintesi Finance\n{finance['decision_status']}\n\n"
        f"## War Room\n{executive['board_message']}\n\n"
        f"## Memoria decisioni\n"
        f"Decisioni aperte: {memory.get('open_decisions', 0)}. "
        f"Completate: {memory.get('completed_decisions', 0)}. "
        f"Impatto reale: {_eur(memory.get('actual_impact_eur') or 0)}.\n\n"
        f"## Prossimi 30 giorni\n{actions}\n"
    )


def _eur(value: Any) -> str:
    return f"EUR {float(value or 0):,.0f}".replace(",", ".")
