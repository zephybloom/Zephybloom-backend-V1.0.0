"""Data completeness engine for sector-specific CFO analysis."""

from typing import Any, Dict, Iterable, List, Set

from core.business_model_schema import DataCompletenessResult, DataField, MissingField
from core.sector_adapters import get_sector_spec


EMPTY_VALUES = (None, "", [], {}, ())


def _flatten_keys(data: Dict[str, Any], prefix: str = "") -> Set[str]:
    keys: Set[str] = set()
    for key, value in (data or {}).items():
        normalized_key = str(key).strip()
        if not normalized_key:
            continue
        full_key = f"{prefix}.{normalized_key}" if prefix else normalized_key
        if value not in EMPTY_VALUES:
            keys.add(normalized_key)
            keys.add(full_key)
        if isinstance(value, dict):
            keys.update(_flatten_keys(value, full_key))
    return keys


def _field_missing(field: DataField) -> MissingField:
    return MissingField(
        key=field.key,
        label=field.label,
        category=field.category,
        why_needed=field.why_needed,
        example=field.example,
        unit=field.unit,
    )


def _coverage(present: int, total: int) -> float:
    if total <= 0:
        return 100.0
    return round((present / total) * 100, 1)


def _readiness(required_coverage: float, precision: float) -> str:
    if required_coverage >= 90 and precision >= 85:
        return "analysis_ready"
    if required_coverage >= 65:
        return "directional"
    if required_coverage >= 35:
        return "discovery_needed"
    return "insufficient_data"


def _build_next_questions(missing_required: Iterable[MissingField], limit: int = 5) -> List[str]:
    questions = []
    for field in list(missing_required)[:limit]:
        example = f" Esempio: {field.example}." if field.example else ""
        questions.append(f"Mi serve {field.label.lower()} per {field.why_needed.lower()}.{example}")
    return questions


def assess_data_completeness(sector: str, provided_data: Dict[str, Any]) -> DataCompletenessResult:
    """Assess whether the CFO has enough data to answer precisely."""

    spec = get_sector_spec(sector)
    provided_keys = _flatten_keys(provided_data or {})

    missing_required = [
        _field_missing(field)
        for field in spec.required_fields
        if field.key not in provided_keys
    ]
    missing_optional = [
        _field_missing(field)
        for field in spec.optional_fields
        if field.key not in provided_keys
    ]

    required_total = len(spec.required_fields)
    optional_total = len(spec.optional_fields)
    required_present = required_total - len(missing_required)
    optional_present = optional_total - len(missing_optional)

    required_coverage = _coverage(required_present, required_total)
    optional_coverage = _coverage(optional_present, optional_total)
    precision = round((required_coverage * 0.75) + (optional_coverage * 0.25), 1)

    return DataCompletenessResult(
        sector=spec.sector,
        sector_name=spec.name,
        required_total=required_total,
        required_present=required_present,
        optional_total=optional_total,
        optional_present=optional_present,
        required_coverage_pct=required_coverage,
        optional_coverage_pct=optional_coverage,
        answer_precision_pct=precision,
        readiness_level=_readiness(required_coverage, precision),
        missing_required=missing_required,
        missing_optional=missing_optional,
        next_questions=_build_next_questions(missing_required),
        can_answer_precisely=required_coverage >= 90,
        key_kpis=spec.key_kpis,
        decision_rules=spec.decision_rules,
        simulation_templates=spec.simulation_templates,
        supported_questions=spec.supported_questions,
    )
