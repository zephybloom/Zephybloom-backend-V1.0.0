# -*- coding: utf-8 -*-
# content/core/simulate.py — Applica delta e ricalcola KPI con il motore
from __future__ import annotations
from typing import Dict, Any, Tuple

from core.kpi_engine import compute_kpi, KPIOptions
from utils.validators import clamp_nonneg

# Delta supportati (estendibile)
#  - *_pct: variazioni percentuali (es. costi_fissi_pct = -5.0 → -5%)
#  - *_abs: delta assoluti (es. costi_fissi_abs = -50000)

# 👉 Nota: gestiamo sia "price_*" che "prezzo_*" per compatibilità con API e router.
SUPPORTED_PCT = {
    "fatturato_pct": "fatturato",
    "costi_variabili_pct": "costi_variabili",
    "costi_fissi_pct": "costi_fissi",
    # alias prezzo
    "prezzo_pct": "prezzo_medio",
    "price_pct": "prezzo_medio",
}

SUPPORTED_ABS = {
    "fatturato_abs": "fatturato",
    "costi_variabili_abs": "costi_variabili",
    "costi_fissi_abs": "costi_fissi",
    "ammortamenti_abs": "ammortamenti",
    "investimenti_abs": "investimenti",
    # alias prezzo
    "prezzo_abs": "prezzo_medio",
    "price_abs": "prezzo_medio",
}


def _apply_pct(base: Dict[str, float], key_map: Dict[str, str], delta: Dict[str, float]) -> None:
    """Applica variazioni percentuali (+/- %) ai campi indicati."""
    for dk, target in key_map.items():
        if dk in delta:
            pct = float(delta[dk] or 0.0)
            base[target] = float(base.get(target, 0.0)) * (1.0 + pct / 100.0)


def _apply_abs(base: Dict[str, float], key_map: Dict[str, str], delta: Dict[str, float]) -> None:
    """Applica delta assoluti ai campi indicati."""
    for dk, target in key_map.items():
        if dk in delta:
            base[target] = float(base.get(target, 0.0)) + float(delta[dk] or 0.0)


def _elastic_demand_adjust(base: Dict[str, float], delta: Dict[str, float], assumptions: Dict[str, Any]) -> None:
    """
    Se presente price/prezzo_pct e price_elasticity, aggiusta quantità e ricavi.
    Modello semplice a elasticità costante sulla quantità:

      dQ/Q = e * dP/P

    - e < 0 → aumento prezzo riduce quantità
    - e > 0 → aumento prezzo aumenta quantità (caso raro, premium, Veblen ecc.)
    """
    # Accettiamo sia price_pct che prezzo_pct (già mappati in SUPPORTED_PCT, ma qui ci serve il delta originale)
    if "price_pct" in delta:
        dp = float(delta.get("price_pct", 0.0)) / 100.0
    elif "prezzo_pct" in delta:
        dp = float(delta.get("prezzo_pct", 0.0)) / 100.0
    else:
        return

    elasticity = float(base.get("price_elasticity", delta.get("price_elasticity", -1.2)))
    assumptions["price_elasticity"] = elasticity

    price0 = float(base.get("prezzo_medio", 0.0))
    qty0 = float(base.get("quantity", 0.0))
    fatt0 = float(base.get("fatturato", 0.0))

    # Se la quantità non è nota, stimala: qty0 ≈ fatturato / prezzo
    if qty0 <= 0.0 and price0 > 0.0:
        qty0 = fatt0 / price0

    # Nuovo prezzo
    price1 = price0 * (1.0 + dp)

    # Elasticità prezzo-quantità
    qty1 = qty0 * (1.0 + elasticity * dp)
    qty1 = max(0.0, qty1)

    fatt1 = price1 * qty1

    # Aggiorna base
    base["prezzo_medio"] = price1
    base["fatturato"] = fatt1

    # Se abbiamo un CV unitario, scalare i costi variabili con la quantità
    cvu = float(base.get("costo_variabile_unitario", 0.0))
    if cvu > 0.0:
        base["costi_variabili"] = cvu * qty1

    # Salva ipotesi per spiegazioni al cliente
    assumptions.update(
        {
            "price_base": price0,
            "quantity_base": qty0,
            "quantity_new": qty1,
            "revenue_new": fatt1,
            "model": "constant_elasticity",
        }
    )


def simulate(base: Dict[str, float], delta: Dict[str, float], *, sector: str = "default") -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Applica delta a un set di dati base e ricalcola i KPI.

    Args:
        base: dict con almeno fatturato, costi_variabili, costi_fissi, opzionalmente
              prezzo_medio, costo_variabile_unitario, ammortamenti, investimenti, dso/dio/dpo, ecc.
        delta: dict con chiavi *_pct / *_abs (vedi SUPPORTED_PCT / SUPPORTED_ABS),
               ed eventualmente price_elasticity per il modello domanda-prezzo.
        sector: settore (default "default") → usato da KPIOptions per benchmark/scoring.

    Returns:
        (kpi, assumptions)
        - kpi: dict compatibile con content/api/schemas.SimulateResponse (es. fatturato, utile, ebitda, break_even, ecc.)
        - assumptions: dict con le ipotesi usate (es. elasticità, quantità stimate, ricavi nuovi)
    """
    b = dict(base or {})
    d = dict(delta or {})
    assumptions: Dict[str, Any] = {}

    # 1) Delta percentuali / assoluti generici
    _apply_pct(b, SUPPORTED_PCT, d)
    _apply_abs(b, SUPPORTED_ABS, d)

    # 2) Modello domanda vs prezzo (se è stato variato il prezzo)
    _elastic_demand_adjust(b, d, assumptions)

    # 3) Clamp non negativi su grandezze economiche chiave
    for k in ("fatturato", "costi_variabili", "costi_fissi", "ammortamenti", "investimenti"):
        if k in b:
            b[k] = clamp_nonneg(b.get(k))

    # 4) Ricalcolo KPI unico (usa il motore compute_kpi, con opzioni legate al settore)
    opts = KPIOptions(sector=sector or str(base.get("sector") or "default"))
    kpi = compute_kpi(b, options=opts)

    # kpi è già un dict pronto per SimulateResponse; lo ritorniamo insieme alle assumptions
    return kpi, assumptions
