# -*- coding: utf-8 -*-
# content/core/alerts.py
from __future__ import annotations
from typing import Dict, Any, List

def evaluate_alerts(kpi: Dict[str, Any], sector: str = "default") -> List[Dict[str, Any]]:
    alerts: List[Dict[str, Any]] = []
    # Altman Z
    z = kpi.get("altman_z") or kpi.get("altmanZ") or 0.0
    if z and z < 1.8:
        alerts.append({"code": "ZSCORE_RISK", "message": "Altman Z-score in zona rossa.", "severity": "critical", "meta": {}})

    # ROI
    roi_pct = kpi.get("roi_pct") or 0.0
    if roi_pct < 5.0:
        alerts.append({"code": "ROI_LOW", "message": "ROI sotto il 5%.", "severity": "info", "meta": {}})
        alerts.append({"code": "ROI_LOW", "message": f"ROI sotto soglia: {round(roi_pct,2)}%", "severity": "info", "meta": {}})

    # Net margin
    nm = kpi.get("net_margin_rate") or 0.0
    if nm < 0.05:
        alerts.append({"code": "NET_MARGIN_LOW", "message": "Net margin sotto il 5%.", "severity": "info", "meta": {}})

    return alerts
