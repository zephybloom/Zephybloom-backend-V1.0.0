"""
External Integration Framework

Base classes and patterns for integrating with external services:
- Accounting software (Xero, QuickBooks)
- Payment processors (Stripe, PayPal)
- CRM systems (HubSpot, Salesforce)
- Analytics (Google Analytics)

All integrations follow adapter pattern for consistency and testability.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, date


# ============================================================
# Integration Status & Error Types
# ============================================================

class IntegrationStatus(str, Enum):
    """Status of an external integration"""
    CONNECTING = "connecting"
    CONNECTED = "connected"
    AUTHENTICATED = "authenticated"
    ERROR = "error"
    EXPIRED = "expired"


class IntegrationError(Exception):
    """Base exception for integration errors"""
    pass


class AuthenticationError(IntegrationError):
    """Authentication failed"""
    pass


class RateLimitError(IntegrationError):
    """API rate limit exceeded"""
    pass


class DataValidationError(IntegrationError):
    """Data validation failed"""
    pass


# ============================================================
# Data Classes
# ============================================================

@dataclass
class IntegrationConfig:
    """Configuration for an integration"""
    api_key: str
    api_secret: Optional[str] = None
    api_url: Optional[str] = None
    tenant_id: Optional[str] = None
    webhook_url: Optional[str] = None
    rate_limit_per_min: int = 60
    timeout_seconds: int = 30
    

@dataclass
class IntegrationResult:
    """Result from an integration operation"""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    error_code: Optional[str] = None
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class FinancialSnapshot:
    """Financial data from external system"""
    fatturato: float
    costi_variabili: float
    costi_fissi: float
    gross_profit: float
    ebitda: float
    net_profit: float
    period_start_date: date
    period_end_date: date
    source: str  # "xero", "quickbooks", etc.
    synced_at: datetime


@dataclass
class CustomerMetrics:
    """Customer metrics from CRM"""
    total_customers: int
    active_customers: int
    mrr: float  # Monthly Recurring Revenue
    arr: float  # Annual Recurring Revenue
    churn_rate_pct: float
    customer_acquisition_cost: float
    customer_lifetime_value: float
    period: date
    source: str  # "hubspot", "salesforce", etc.


@dataclass
class TransactionData:
    """Transaction data from payment processor"""
    transactions: List[Dict[str, Any]]
    total_revenue: float
    total_fees: float
    refunds: float
    chargebacks: float
    successful_rate_pct: float
    period_start_date: date
    period_end_date: date
    source: str  # "stripe", "paypal", etc.
    synced_at: datetime


# ============================================================
# Base Integration Classes
# ============================================================

class BaseIntegration(ABC):
    """
    Abstract base class for all external integrations.
    
    Enforces consistent API across all integrations.
    """
    
    def __init__(self, config: IntegrationConfig):
        self.config = config
        self.status = IntegrationStatus.CONNECTING
        self.last_error: Optional[str] = None
        self.last_sync: Optional[datetime] = None
    
    @abstractmethod
    def authenticate(self) -> IntegrationResult:
        """Authenticate with the external service"""
        pass
    
    @abstractmethod
    def sync_data(self) -> IntegrationResult:
        """Sync data from the external service"""
        pass
    
    @abstractmethod
    def disconnect(self) -> IntegrationResult:
        """Disconnect from the external service"""
        pass
    
    def get_status(self) -> IntegrationStatus:
        """Get current connection status"""
        return self.status
    
    def get_last_error(self) -> Optional[str]:
        """Get last error message"""
        return self.last_error
    
    def get_last_sync_time(self) -> Optional[datetime]:
        """Get timestamp of last successful sync"""
        return self.last_sync
    
    def _log_error(self, error: str, error_code: Optional[str] = None):
        """Log an error"""
        self.last_error = error
        self.status = IntegrationStatus.ERROR
        # Could also send to logging service, Sentry, etc.


class AccountingIntegration(BaseIntegration):
    """
    Base class for accounting software integrations.
    
    Provides financial data:
    - Revenue
    - Costs (variable & fixed)
    - Profit/EBITDA
    - Invoices
    - Expenses
    """
    
    @abstractmethod
    def get_financial_snapshot(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[FinancialSnapshot], Optional[str]]:
        """
        Get financial data for a date range.
        
        Returns: (FinancialSnapshot, error_message)
        """
        pass
    
    @abstractmethod
    def get_invoices(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """Get list of invoices"""
        pass
    
    @abstractmethod
    def get_expenses(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """Get list of expenses"""
        pass


class PaymentIntegration(BaseIntegration):
    """
    Base class for payment processor integrations.
    
    Provides transaction data:
    - Revenue
    - Refunds
    - Chargebacks
    - Fees
    - Success rates
    """
    
    @abstractmethod
    def get_transaction_data(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[TransactionData], Optional[str]]:
        """Get transaction data"""
        pass
    
    @abstractmethod
    def get_disputes(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """Get disputed/refunded transactions"""
        pass


class CRMIntegration(BaseIntegration):
    """
    Base class for CRM integrations.
    
    Provides customer metrics:
    - Customer count
    - Churn rate
    - MRR/ARR
    - Customer acquisition cost
    - Lifetime value
    """
    
    @abstractmethod
    def get_customer_metrics(
        self,
        period: Optional[date] = None,
    ) -> Tuple[Optional[CustomerMetrics], Optional[str]]:
        """Get customer metrics"""
        pass
    
    @abstractmethod
    def get_customers(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """Get list of customers"""
        pass


class IntegrationRegistry:
    """
    Registry for managing multiple integrations.
    
    Allows combining data from multiple sources:
    - Xero for accounting
    - Stripe for payments
    - HubSpot for CRM
    """
    
    def __init__(self):
        self.integrations: Dict[str, BaseIntegration] = {}
    
    def register(self, name: str, integration: BaseIntegration):
        """Register an integration"""
        self.integrations[name.lower()] = integration
    
    def get(self, name: str) -> Optional[BaseIntegration]:
        """Get an integration by name"""
        return self.integrations.get(name.lower())
    
    def list_integrations(self) -> List[str]:
        """List all registered integrations"""
        return list(self.integrations.keys())
    
    def get_status_all(self) -> Dict[str, str]:
        """Get status of all integrations"""
        return {
            name: integ.get_status().value
            for name, integ in self.integrations.items()
        }
    
    def sync_all(self) -> Dict[str, IntegrationResult]:
        """Sync data from all integrations"""
        results = {}
        for name, integ in self.integrations.items():
            try:
                result = integ.sync_data()
                results[name] = result
            except Exception as e:
                results[name] = IntegrationResult(
                    success=False,
                    error=str(e),
                    error_code="SYNC_ERROR",
                )
        return results


# Singleton registry
_registry: Optional[IntegrationRegistry] = None


def get_integration_registry() -> IntegrationRegistry:
    """Get the global integration registry"""
    global _registry
    if _registry is None:
        _registry = IntegrationRegistry()
    return _registry
