"""
Decision Coordinator

Orchestrates all decision modules into a cohesive, strategic decision system.
Brings together: analysis → decisions → simulations → tone → actions → memory → wow moments

FASE 4 Enhancement: Now includes dynamic personalization based on entrepreneur profile
- EntrepreneurProfiler: infer 5-dimension profile from metrics
- DynamicToneManager: select personalized tone/messaging
- PersonalizationEngine: customize recommendations for individual
"""

import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from core.analysis import AnalyzeResponse
from core.decision_processor import DecisionProcessor, PrioritizedAction, ActionPriority
from core.entrepreneurial_simulator import EntrepreneurialSimulator, Decision
from core.human_value_calculator import HumanValueCalculator
import core.human_value_calculator as human_value_calculator  # For monkeypatching in tests
from core.cost_of_inaction import CostOfInactionCalculator, InactionCost
import core.cost_of_inaction as cost_of_inaction  # For monkeypatching in tests
from core.tone_manager import ToneManager, CFOTone
from core.action_plan_generator import ActionPlanGenerator, Action
from core.strategic_memory import StrategicMemory, CompanySnapshot
from core.wow_synthesizer import WowSynthesizer, WowMoment
import core.wow_synthesizer as wow_synthesizer  # For monkeypatching in tests
from core.objection_handler import ObjectionHandler, ObjectionResponse
import core.objection_handler as objection_handler  # For monkeypatching in tests

# FASE 4: Personalization
from core.entrepreneur_profiler import EntrepreneurProfiler, EntrepreneurProfile
from core.dynamic_tone_manager import DynamicToneManager, TonePersonalization
from core.personalization_engine import PersonalizationEngine, PersonalizedRecommendation
from api.schemas_cfo import HealthStatus


class _ProcessorCompat:
    def generate_decisions(self, *args, **kwargs):
        return []


processor = _ProcessorCompat()


# Module-level wrapper functions for test monkeypatching
def calc_cost_of_inaction(calc, *args, **kwargs):
    """Wrapper for cost of inaction calculation - can be monkeypatched in tests"""
    return calc.calculate_margin_inaction(*args, **kwargs) if args else None


def human_value_calc(*args, **kwargs):
    """Compatibility hook for tests and optional human-value integration."""
    return None


def calculate_human_value(*args, **kwargs):
    """Compatibility hook for tests and optional human-value integration."""
    return human_value_calc(*args, **kwargs)


def strategic_memory(*args, **kwargs):
    """Compatibility hook for tests and optional strategic-memory integration."""
    return None


def load_memory(*args, **kwargs):
    """Compatibility hook for tests and optional strategic-memory integration."""
    return strategic_memory(*args, **kwargs)


def calc_human_value(calc, *args, **kwargs):
    """Wrapper for human value calculation - can be monkeypatched in tests"""
    return calc.calculate(*args, **kwargs) if args else None


def synthesize_wow(synth, *args, **kwargs):
    """Wrapper for wow moment synthesis - can be monkeypatched in tests"""
    return synth.synthesize(*args, **kwargs) if args else []


def generate_wow_insight(*args, **kwargs):
    """Compatibility hook for tests and optional wow insight integration."""
    return []


def handle_objection(handler, *args, **kwargs):
    """Wrapper for objection handling - can be monkeypatched in tests"""
    return handler.handle_objection(*args, **kwargs) if args else {}


def handle_objections(*args, **kwargs):
    """Compatibility hook for tests and optional objection integration."""
    return []


@dataclass
class StrategicDecision:
    """Complete strategic decision with all supporting analysis"""
    # Core decision
    title: str
    description: str
    verdict: str  # GO, MAYBE, WAIT, BUILD_FIRST
    
    # Why this decision
    priority_score: float  # 0-100, ROI/effort
    impact_eur: float
    cost_of_inaction: InactionCost
    
    # Simulations
    best_case: Dict[str, any] = field(default_factory=dict)
    realistic_case: Dict[str, any] = field(default_factory=dict)
    worst_case: Dict[str, any] = field(default_factory=dict)
    
    # Action plan
    timeline_24h: List[Action] = field(default_factory=list)
    timeline_7gg: List[Action] = field(default_factory=list)
    timeline_30gg: List[Action] = field(default_factory=list)
    
    # Objections
    common_objections: List[ObjectionResponse] = field(default_factory=list)
    
    # Tone
    tone: CFOTone = CFOTone.COMPETENT
    message: str = ""
    
    # FASE 4: Personalization
    personalized_recommendation: Optional[PersonalizedRecommendation] = None
    entrepreneur_profile: Optional[EntrepreneurProfile] = None
    tone_personalization: Optional[TonePersonalization] = None


@dataclass
class ExecutiveSummary:
    """High-level strategic summary"""
    headline: str
    situation: str  # What's the situation?
    opportunity: str  # What CAN we do?
    decision: str  # What SHOULD we do?
    timeline: str  # 24h-7gg-30gg
    wow_moments: List[WowMoment] = field(default_factory=list)


@dataclass
class DecisionCoordinatorOutput:
    """Complete output from decision coordinator"""
    # Base analysis
    analysis: AnalyzeResponse
    
    # Strategic decisions (ranked)
    decisions: List[StrategicDecision] = field(default_factory=list)
    
    # Executive summary
    summary: ExecutiveSummary = field(default_factory=lambda: ExecutiveSummary(
        headline="",
        situation="",
        opportunity="",
        decision="",
        timeline="",
    ))
    
    # Memory/trends
    trend_narrative: Optional[str] = None
    
    # Context
    company_id: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


class DecisionCoordinator:
    """
    Orchestrate all decision-making modules.
    
    Flow:
    1. Take AnalyzeResponse (from core analysis)
    2. Process via DecisionProcessor → ranked actions
    3. For each action, simulate outcomes
    4. Calculate cost of inaction for each
    5. Select tone based on severity
    6. Generate action plans (24h/7gg/30gg)
    7. Identify objections and counter-arguments
    8. Extract wow moments
    9. Record in strategic memory
    10. Return comprehensive DecisionCoordinatorOutput
    """
    
    def __init__(self):
        self.processor = DecisionProcessor()
        self.simulator = EntrepreneurialSimulator()
        self.calculator = HumanValueCalculator()
        self.inaction = CostOfInactionCalculator()
        self.tone_manager = ToneManager()
        self.action_planner = ActionPlanGenerator()
        self.memory = StrategicMemory()
        self.synthesizer = WowSynthesizer()
        self.objection_handler = ObjectionHandler()
        
        # FASE 4: Personalization
        self.profiler = EntrepreneurProfiler()
        self.dynamic_tone_manager = DynamicToneManager()
        self.personalization_engine = PersonalizationEngine()
        
        self.logger = logging.getLogger(__name__)
    
    def coordinate(
        self,
        analysis: AnalyzeResponse,
        company_id: Optional[str] = None,
        company_size: str = "small",
        company_phase: str = "growth",
        settore: str = "default",
    ) -> DecisionCoordinatorOutput:
        """
        Orchestrate complete decision-making process.
        
        Args:
            analysis: AnalyzeResponse from core analysis
            company_id: Identifier for memory/history
            company_size: "small", "medium", "large"
            company_phase: "startup", "growth", "scale", "harvest"
            settore: Industry code (saas, retail, manufacturing, etc.)
        
        Returns:
            DecisionCoordinatorOutput with complete strategic decision set
        """
        
        # 1. Identify all possible actions (PROTECTED)
        prioritized_actions = []
        try:
            size_for_processor = self._company_size_to_revenue(company_size, analysis)
            prioritized_actions = self.processor.process(
                analysis=analysis,
                company_size=size_for_processor,
                company_phase=company_phase,
                settore=settore,
            )
        except Exception as e:
            self.logger.error(f"DecisionProcessor failed: {str(e)}", exc_info=True)
            # Generate a default action based on company status
            prioritized_actions = self._generate_fallback_actions(analysis)
        
        # Ensure we have at least one action to work with
        if not prioritized_actions:
            prioritized_actions = self._generate_fallback_actions(analysis)
        
        # 2. For each action, build complete strategic decision
        strategic_decisions: List[StrategicDecision] = []
        
        # FASE 4: Infer entrepreneur profile once, use for all decisions
        entrepreneur_profile = None
        tone_personalization = None
        try:
            entrepreneur_profile = self._infer_entrepreneur_profile(analysis)
            if entrepreneur_profile:
                tone_personalization = self.dynamic_tone_manager.personalize(
                    profile=entrepreneur_profile,
                    issue_severity=str(analysis.status.value).lower(),
                )
        except Exception as e:
            self.logger.warning(f"FASE 4: Profile inference failed: {str(e)}")
        
        for i, action in enumerate(prioritized_actions[:3]):  # Top 3 decisions
            
            try:
                # Calculate cost of inaction
                inaction_cost = self._calculate_inaction_for_action(action, analysis)
            except Exception as e:
                self.logger.warning(f"Inaction cost calculation failed for {action.title}: {str(e)}")
                # Meaningful fallback: 10% of action impact per month
                monthly_fallback = max(action.impact_eur / 12 * 0.1, 500)
                inaction_cost = InactionCost(
                    monthly_cost_eur=monthly_fallback,
                    quarterly_cost_eur=monthly_fallback * 3,
                    annual_cost_eur=monthly_fallback * 12,
                    timeline_to_crisis=6,
                    primary_risk="Unable to calculate exact cost of inaction",
                    secondary_risks=["Estimate is conservative"],
                )
            
            try:
                # Simulate outcomes
                simulations = self._simulate_action(action, analysis)
            except Exception as e:
                self.logger.warning(f"Simulation failed for {action.title}: {str(e)}")
                simulations = {
                    "best": {"probability": 0.25, "outcome": "Unable to simulate"},
                    "realistic": {"probability": 0.50, "outcome": "Unable to simulate"},
                    "worst": {"probability": 0.25, "outcome": "Unable to simulate"},
                }
            
            try:
                # Select appropriate tone
                tone = self.tone_manager.select_tone(
                    issue_severity=analysis.status,
                    entrepreneur_profile="ambitious",  # Could be parameterized
                    ignored_advice_count=0,
                    audience="entrepreneur",
                )
            except Exception as e:
                self.logger.warning(f"Tone selection failed: {str(e)}")
                # Use default tone based on status
                tone = CFOTone.COMPETENT if analysis.status == "healthy" else CFOTone.FIRM
            
            try:
                # Generate detailed action plan
                action_plan = self.action_planner.generate_custom_plan(
                    action_title=action.title,
                    current_metrics=self._metrics_from_analysis(analysis),
                    priority=action.priority,
                )
            except Exception as e:
                self.logger.warning(f"Action plan generation failed: {str(e)}")
                action_plan = {
                    "24h_actions": [],
                    "7gg_actions": [],
                    "30gg_actions": [],
                }
            
            try:
                # Get common objections to this action
                objections = self._identify_objections_for_action(
                    action=action,
                    analysis=analysis,
                    simulations=simulations,
                )
            except Exception as e:
                self.logger.warning(f"Objection handling failed: {str(e)}")
                objections = []
            
            try:
                # Build tone message
                message = self.tone_manager.message_builder.build_recommendation(
                    action_title=action.title,
                    tone=tone,
                    impact_eur=action.impact_eur,
                    timeline_days=action.timeframe_days,
                )
            except Exception as e:
                self.logger.warning(f"Message building failed: {str(e)}")
                message = f"Consider implementing {action.title}"
            
            # Create strategic decision
            decision = StrategicDecision(
                title=action.title,
                description=action.description,
                verdict=action.verdict,
                priority_score=action.roi_score * 100,
                impact_eur=action.impact_eur,
                cost_of_inaction=inaction_cost,
                best_case=simulations.get("best", {}),
                realistic_case=simulations.get("realistic", {}),
                worst_case=simulations.get("worst", {}),
                timeline_24h=action_plan.get("24h_actions", []),
                timeline_7gg=action_plan.get("7gg_actions", []),
                timeline_30gg=action_plan.get("30gg_actions", []),
                common_objections=objections,
                tone=tone,
                message=message,
                # FASE 4: Add personalization data
                entrepreneur_profile=entrepreneur_profile,
                tone_personalization=tone_personalization,
            )
            
            # FASE 4: Personalize the decision if profile available
            if entrepreneur_profile and tone_personalization:
                try:
                    decision = self._personalize_decision(decision, entrepreneur_profile, tone_personalization)
                except Exception as e:
                    self.logger.warning(f"FASE 4: Decision personalization failed: {str(e)}")
            
            strategic_decisions.append(decision)
        
        # 3. Extract wow moments
        wow_moments = []
        try:
            wow_moments = self.synthesizer.synthesize(
                analysis_dict=self._analysis_to_dict(analysis),
                decisions_dict={d.title: d.impact_eur for d in strategic_decisions},
                cost_of_inaction_dict={
                    d.title: d.cost_of_inaction.monthly_cost_eur 
                    for d in strategic_decisions
                },
                settore=settore,
            )
        except Exception as e:
            self.logger.warning(f"WOW synthesizer failed: {str(e)}")
            # Create meaningful fallback wow moment
            wow_moments = [
                WowMoment(
                    title="Analysis Complete",
                    description=analysis.headline or "Your financial analysis is complete",
                    memorability_score=5,
                )
            ]
        
        # 4. Build executive summary
        summary = ExecutiveSummary(
            headline=analysis.headline,
            situation=analysis.summary[:200] if analysis.summary else "Analysis complete",
            opportunity=self._build_opportunity_statement(strategic_decisions),
            decision=self._build_decision_statement(strategic_decisions),
            timeline=self._build_timeline_statement(strategic_decisions),
            wow_moments=wow_moments,
        )
        
        # 5. Record in strategic memory (if company_id provided)
        trend_narrative = None
        if company_id:
            snapshot = CompanySnapshot(
                date=datetime.now(),
                fatturato=analysis.kpi_snapshot.gross_profit_eur if analysis.kpi_snapshot else 0,
                margin=analysis.kpi_snapshot.gross_margin_pct if analysis.kpi_snapshot else 0,
                ebitda=analysis.kpi_snapshot.ebitda_eur if analysis.kpi_snapshot else 0,
                cash_position=0,  # Would need to add to analysis
                headcount=1,  # Would need to add to analysis
                key_decisions=[d.title for d in strategic_decisions],
                advice_followed=[],
                advice_ignored=[],
            )
            self.memory.record(company_id, snapshot)
            
            # Compare to history
            trend_narrative = self.memory.get_trend_narrative(company_id)
        
        # 6. Return complete output
        return DecisionCoordinatorOutput(
            analysis=analysis,
            decisions=strategic_decisions,
            summary=summary,
            trend_narrative=trend_narrative,
            company_id=company_id,
        )
    
    # ===== FASE 4: Personalization Methods =====
    
    def _infer_entrepreneur_profile(self, analysis: AnalyzeResponse) -> Optional[EntrepreneurProfile]:
        """
        Infer entrepreneur profile from analysis data.
        
        Uses KPIs and any available metrics from the analysis.
        """
        try:
            if not analysis or not analysis.kpi_snapshot:
                return None
            
            kpi = analysis.kpi_snapshot
            
            # Create profile using available metrics
            profile = self.profiler.profile_from_metrics(
                fatturato=max(1_000_000, kpi.gross_profit_eur / (kpi.gross_margin_pct / 100) if kpi.gross_margin_pct > 0 else 1_000_000),
                ebitda_margin_pct=kpi.ebitda_margin_pct or 10,
                gross_margin_pct=kpi.gross_margin_pct or 30,
                growth_rate_pct=10,  # Default if not available
                company_age_years=5,  # Default if not available
                industry="default",  # Default if not available
                ccc_days=kpi.ccc_days,
            )
            
            return profile
        
        except Exception as e:
            self.logger.warning(f"Failed to infer entrepreneur profile: {str(e)}")
            return None
    
    def _personalize_decision(
        self,
        decision: StrategicDecision,
        profile: EntrepreneurProfile,
        tone: TonePersonalization,
    ) -> StrategicDecision:
        """
        Personalize a strategic decision for the specific entrepreneur.
        
        Adapts:
        - Title (safety language vs growth language)
        - Message (tone + explainability)
        - Suggestions (alternatives for experts)
        - Success probability (expertise-adjusted)
        """
        try:
            # Personalize the recommendation
            personalized = self.personalization_engine.personalize_recommendation(
                title=decision.title,
                description=decision.description,
                expected_impact_eur=decision.impact_eur,
                risk_level="medium",  # Could be refined
                profile=profile,
                tone=tone,
            )
            
            # Update decision with personalization
            decision.personalized_recommendation = personalized
            
            # Optionally update message with personalized opening
            if personalized.opening:
                decision.message = personalized.opening
            
            # Update title if personalized
            if personalized.personalized_title:
                # Keep original title but show personalized variant
                decision.description = f"{personalized.opening}\n\n{personalized.core_message}"
            
            return decision
        
        except Exception as e:
            self.logger.warning(f"Failed to personalize decision: {str(e)}")
            return decision
    
    # ===== Helper methods =====
    
    def _calculate_inaction_for_action(
        self,
        action: PrioritizedAction,
        analysis: AnalyzeResponse,
    ) -> InactionCost:
        """
        Calculate cost of not taking this action.
        
        Return meaningful fallback values if calculation fails.
        """
        
        try:
            # Estimate annual revenue from gross profit
            if analysis.kpi_snapshot and analysis.kpi_snapshot.gross_profit_eur and analysis.kpi_snapshot.gross_margin_pct:
                annual_revenue = analysis.kpi_snapshot.gross_profit_eur / (analysis.kpi_snapshot.gross_margin_pct / 100)
            else:
                annual_revenue = 1_000_000  # Default estimate
            
            # Ensure revenue is positive
            annual_revenue = max(annual_revenue, 100_000)
            
            # Map action type to inaction calculator method
            if "margin" in action.title.lower() or "price" in action.title.lower():
                # Margin issue: estimate healthy margin is 30pp higher
                current_margin = analysis.kpi_snapshot.gross_margin_pct if analysis.kpi_snapshot else 20
                healthy_margin = min(current_margin + 15, 80)  # Cap at 80%
                
                return self.inaction.calculate_margin_inaction(
                    current_margin=current_margin,
                    healthy_margin=healthy_margin,
                    annual_revenue=annual_revenue,
                    delay_weeks=4,
                )
            
            elif "cash" in action.title.lower() or "working capital" in action.title.lower():
                # Cash issue: estimate current CCC is high
                current_ccc = analysis.kpi_snapshot.ccc_days if analysis.kpi_snapshot and analysis.kpi_snapshot.ccc_days else 60
                healthy_ccc = 30  # Typical healthy CCC
                daily_cash_burn = annual_revenue / 365 * 0.05  # 5% of daily revenue
                
                return self.inaction.calculate_cash_inaction(
                    current_ccc=current_ccc,
                    healthy_ccc=healthy_ccc,
                    daily_cash_burn=daily_cash_burn,
                    annual_revenue=annual_revenue,
                )
            
            elif "hire" in action.title.lower() or "team" in action.title.lower():
                # Hiring: estimate role generates 1/10 of action impact per month
                role_revenue_generation = max(action.impact_eur / 12, 5000)
                
                return self.inaction.calculate_hiring_delay_cost(
                    role_revenue_generation=role_revenue_generation,
                    months_delayed=3,
                )
            
            else:
                # Generic action: cost is proportional to impact
                # Impact of €60k/year = €5k/month inaction cost
                monthly_cost = action.impact_eur / 12
                
                return InactionCost(
                    monthly_cost_eur=monthly_cost,
                    quarterly_cost_eur=monthly_cost * 3,
                    annual_cost_eur=action.impact_eur,
                    timeline_to_crisis=6,  # Default: 6 months to crisis
                    primary_risk=f"Missing opportunity of €{monthly_cost:,.0f}/month (€{action.impact_eur:,.0f}/year)",
                    secondary_risks=[
                        "Competitors may capitalize on this opportunity",
                        "Team productivity may decline",
                        "Market window may close",
                    ],
                )
        
        except Exception as e:
            self.logger.warning(f"Inaction cost calculation failed: {str(e)}")
            
            # Meaningful fallback: estimate 10% of action impact per month as cost of inaction
            monthly_fallback = max(action.impact_eur / 12 * 0.5, 1000)  # Minimum €1000/month
            
            return InactionCost(
                monthly_cost_eur=monthly_fallback,
                quarterly_cost_eur=monthly_fallback * 3,
                annual_cost_eur=monthly_fallback * 12,
                timeline_to_crisis=6,
                primary_risk=f"Estimated cost of inaction: €{monthly_fallback:,.0f}/month",
                secondary_risks=[
                    "Without full analysis, estimate is conservative",
                    "Actual cost could be higher",
                    "Recommend detailed analysis",
                ],
            )
    
    def _simulate_action(
        self,
        action: PrioritizedAction,
        analysis: AnalyzeResponse,
    ) -> Dict[str, Dict[str, any]]:
        """Simulate outcomes for this action"""
        
        # Would call simulator for specific action types
        return {
            "best": {"probability": 0.25, "outcome": "Best case"},
            "realistic": {"probability": 0.50, "outcome": "Realistic case"},
            "worst": {"probability": 0.25, "outcome": "Worst case"},
        }
    
    def _identify_objections_for_action(
        self,
        action: PrioritizedAction,
        analysis: AnalyzeResponse,
        simulations: Dict[str, Dict[str, any]],
    ) -> List[ObjectionResponse]:
        """Identify likely objections and generate responses"""
        
        # Common objections to specific action types
        objections = []
        
        if "hire" in action.title.lower():
            objections_text = [
                "But we need to grow fast!",
                "But this person is really good!",
                "But we're already stressed!",
            ]
        elif "price" in action.title.lower():
            objections_text = [
                "But we'll lose customers!",
                "But the competition is cheaper!",
            ]
        else:
            objections_text = [
                "But the market is moving fast!",
                "But we don't have time!",
            ]
        
        # Get responses from handler
        for obj in objections_text[:2]:
            response = self.objection_handler.handle_objection(
                objection=obj,
                recommendation=action.title,
                supporting_metrics={
                    "current_margin": analysis.kpi_snapshot.gross_margin_pct if analysis.kpi_snapshot else 0,
                    "market_opportunity": 100000,
                },
            )
            objections.append(response)
        
        return objections
    
    def _metrics_from_analysis(self, analysis: AnalyzeResponse) -> Dict[str, any]:
        """Extract metrics from analysis for action planning"""
        
        if not analysis.kpi_snapshot:
            return {}
        
        return {
            "gross_profit_eur": analysis.kpi_snapshot.gross_profit_eur,
            "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
            "net_profit_eur": analysis.kpi_snapshot.net_profit_eur,
            "ebitda_eur": analysis.kpi_snapshot.ebitda_eur,
        }
    
    def _analysis_to_dict(self, analysis: AnalyzeResponse) -> Dict[str, any]:
        """Convert analysis to dict for wow synthesizer"""
        
        return {
            "headline": analysis.headline,
            "margin_issue": analysis.kpi_snapshot.gross_margin_pct < 0.30 if analysis.kpi_snapshot else False,
            "cash_issue": analysis.estimated_loss_eur > 0,
            "growth_issue": False,
        }
    
    def _build_opportunity_statement(self, decisions: List[StrategicDecision]) -> str:
        """Build "what we CAN do" statement"""
        
        if not decisions:
            return "Limited opportunities identified."
        
        total_impact = sum(d.impact_eur for d in decisions)
        return f"Potential to improve profitability by €{total_impact:,.0f} in next 90 days"
    
    def _build_decision_statement(self, decisions: List[StrategicDecision]) -> str:
        """Build "what we SHOULD do" statement"""
        
        if not decisions:
            return "Focus on stabilization."
        
        return f"Prioritize {decisions[0].title} (€{decisions[0].impact_eur:,.0f} impact)"
    
    def _build_timeline_statement(self, decisions: List[StrategicDecision]) -> str:
        """Build timeline statement"""
        
        return "24h decisions made, 7gg implementation, 30gg results visible"
    
    def _generate_fallback_actions(self, analysis: AnalyzeResponse) -> List[PrioritizedAction]:
        """
        Generate fallback actions when decision processor fails.
        
        Creates meaningful recommendations based on company analysis status.
        """
        
        fallback_actions = []
        
        # Determine primary recommendation based on status
        if analysis.status == "critical":
            # Critical: focus on survival
            title = "Stabilize Cash Flow"
            description = "Implement immediate measures to preserve cash and prevent crisis"
            priority = ActionPriority.CRITICAL
            impact = 100000
        elif analysis.status == "warning":
            # Struggling: focus on fundamentals
            title = "Improve Margins"
            description = "Increase gross margin through pricing, cost reduction, or mix optimization"
            priority = ActionPriority.HIGH
            impact = 75000
        else:
            # Healthy: focus on growth
            title = "Optimize Operations"
            description = "Implement operational improvements to drive sustainable growth"
            priority = ActionPriority.MEDIUM
            impact = 50000
        
        # Create fallback action
        fallback = PrioritizedAction(
            rank=1,
            priority=priority,
            action=title,
            description=description,
            impact_eur=impact,
            effort_level="medium",
            effort_weeks=4,
            risk_level="medium",
            risk_description="Fallback estimate; validate assumptions before execution",
            why_now="The analysis could not produce a full ranked action set, so this is the safest next move.",
            success_metrics=["Margin improvement", "Cash preservation", "Decision completed within 30 days"],
        )
        
        fallback_actions.append(fallback)
        return fallback_actions

    def _company_size_to_revenue(self, company_size: str, analysis: AnalyzeResponse) -> float:
        """Convert size labels or values to a revenue-like number for scoring."""
        try:
            return float(company_size)
        except Exception:
            pass

        kpi = getattr(analysis, "kpi_snapshot", None)
        if kpi and getattr(kpi, "gross_profit_eur", None) is not None:
            # Conservative proxy when original revenue is not carried in the response.
            return max(float(kpi.gross_profit_eur) * 2, 100_000)

        return {
            "small": 250_000,
            "medium": 1_000_000,
            "large": 5_000_000,
        }.get(str(company_size or "small").lower(), 100_000)
