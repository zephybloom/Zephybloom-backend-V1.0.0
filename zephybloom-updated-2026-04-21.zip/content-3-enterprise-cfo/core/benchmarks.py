# -*- coding: utf-8 -*-
# content/core/benchmarks.py — Benchmark settoriali (bench in %, KPI in frazione)
from __future__ import annotations

from functools import lru_cache
import pathlib
from typing import Dict, Any

import yaml

# Valori benchmark espressi in % (non frazioni)
DEFAULT: Dict[str, Dict[str, float]] = {
    "default":    {"mc_rate": 40.0, "net_margin_rate": 8.0,  "roi": 10.0},
    "restaurant": {"mc_rate": 65.0, "net_margin_rate": 5.0,  "roi": 12.0},
    "hotel":      {"mc_rate": 60.0, "net_margin_rate": 7.0,  "roi": 12.0},
    "retail":     {"mc_rate": 45.0, "net_margin_rate": 6.0,  "roi": 10.0},
    "saas":       {"mc_rate": 80.0, "net_margin_rate": 15.0, "roi": 25.0},
    "bakery":     {"mc_rate": 58.0, "net_margin_rate": 6.0,  "roi": 12.0},
    "ecommerce":  {"mc_rate": 48.0, "net_margin_rate": 7.0,  "roi": 15.0},
}


def _coerce_bench_map(data: Any) -> Dict[str, Dict[str, float]]:
    """
    Garantisce che la mappa caricata sia {sector: {mc_rate, net_margin_rate, roi} in %}.
    Ignora settori non validi/strutture non conformi.
    """
    out: Dict[str, Dict[str, float]] = {}
    if not isinstance(data, dict):
        return {}
    for sec, rec in data.items():
        if not isinstance(sec, str) or not isinstance(rec, dict):
            continue
        try:
            out[sec.strip().lower()] = {
                "mc_rate": float(rec.get("mc_rate", DEFAULT["default"]["mc_rate"])),
                "net_margin_rate": float(rec.get("net_margin_rate", DEFAULT["default"]["net_margin_rate"])),
                "roi": float(rec.get("roi", DEFAULT["default"]["roi"])),
            }
        except Exception:
            continue
    return out


@lru_cache(maxsize=8)
def load_benchmarks(path: str | pathlib.Path | None = None) -> Dict[str, Dict[str, float]]:
    """
    Carica benchmark da YAML (se presente) e li unisce ai DEFAULT (soft-merge).
    Ritorna sempre valori in **percentuale**.
    """
    if path is None:
        return dict(DEFAULT)

    p = pathlib.Path(path)
    if not p.exists():
        return dict(DEFAULT)

    try:
        with open(p, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    except Exception:
        return dict(DEFAULT)

    loaded = _coerce_bench_map(data)
    # soft-merge (i default riempiono i buchi)
    out = dict(DEFAULT)
    out.update(loaded)
    return out


def _as_percent(x: float) -> float:
    """Converte frazione→% se necessario (accetta già %)."""
    try:
        v = float(x)
    except Exception:
        return 0.0
    return v * 100.0 if v <= 1.0 else v


def sector_gap_analysis(sector: str, kpi: dict, benchmarks: dict | None = None) -> Dict[str, float]:
    """
    Confronta KPI (frazioni 0..1) con benchmark (in %).
    Ritorna gap in punti percentuali: positivo = sopra benchmark, negativo = sotto.
    """
    bm_map = benchmarks or load_benchmarks(None)
    sec = (sector or "default").strip().lower()
    bm = bm_map.get(sec, bm_map["default"])

    # KPI potrebbero essere frazioni (0..1) o %: normalizziamo a %.
    kpi_mc = _as_percent(kpi.get("mc_rate", 0.0))
    kpi_nm = _as_percent(kpi.get("net_margin_rate", 0.0))
    kpi_roi = _as_percent(kpi.get("roi", 0.0))

    return {
        "mc_rate": kpi_mc - float(bm["mc_rate"]),
        "net_margin_rate": kpi_nm - float(bm["net_margin_rate"]),
        "roi": kpi_roi - float(bm["roi"]),
    }
