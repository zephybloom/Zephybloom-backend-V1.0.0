"""
CFO DuPont Analysis Engine - Profitability decomposition

Decomposes Return on Assets (ROA) and Return on Equity (ROE) into components:
- ROA = Net Margin × Asset Turnover
- ROE = ROA × Financial Leverage

Helps identify WHERE profitability is coming from (margin vs efficiency)
"""

from typing import Dict, Optional
from dataclasses import dataclass
from enum import Enum


# ============================================
# DATA MODELS
# ============================================

@dataclass
class DupontAnalysis:
    """DuPont decomposition results"""
    
    # Top level metrics
    roa_pct: Optional[float]  # Return on Assets %
    roe_pct: Optional[float]  # Return on Equity %
    
    # Components
    net_margin_pct: float  # Profitability component
    asset_turnover: float  # Efficiency component
    financial_leverage: Optional[float]  # Leverage component
    
    # What's driving the returns?
    margin_contribution_pct: float  # % of ROA from margin
    turnover_contribution_pct: float  # % of ROA from turnover
    
    # Diagnosis
    primary_driver: str  # "margin", "efficiency", "leverage", "balanced"
    leverage_contribution_pct: Optional[float] = None  # % of ROE from leverage
    weakness: Optional[str] = None  # "low_margin", "low_turnover", "high_leverage", None


# ============================================
# DUPONT ENGINE
# ============================================

class DupontEngine:
    """Decomposes profitability into components"""
    
    @staticmethod
    def calculate_roa(
        net_profit: float,
        total_assets: float,
    ) -> Optional[float]:
        """
        Calculate Return on Assets
        
        ROA = Net Profit / Total Assets
        
        Args:
            net_profit: Net profit in EUR
            total_assets: Total assets in EUR
        
        Returns:
            ROA as percentage (e.g., 15.0 for 15%)
        """
        if not total_assets or total_assets <= 0:
            return None
        
        roa = (net_profit / total_assets) * 100
        return round(roa, 2)
    
    @staticmethod
    def calculate_roe(
        net_profit: float,
        equity: float,
    ) -> Optional[float]:
        """
        Calculate Return on Equity
        
        ROE = Net Profit / Equity
        """
        if not equity or equity <= 0:
            return None
        
        roe = (net_profit / equity) * 100
        return round(roe, 2)
    
    @staticmethod
    def calculate_net_margin(
        net_profit: float,
        revenue: float,
    ) -> Optional[float]:
        """
        Calculate Net Profit Margin
        
        Net Margin = Net Profit / Revenue
        """
        if not revenue or revenue <= 0:
            return None
        
        margin = (net_profit / revenue) * 100
        return round(margin, 2)
    
    @staticmethod
    def calculate_asset_turnover(
        revenue: float,
        total_assets: float,
    ) -> Optional[float]:
        """
        Calculate Asset Turnover
        
        Asset Turnover = Revenue / Total Assets
        
        Shows how efficiently assets are used to generate revenue
        Higher = more efficient
        """
        if not total_assets or total_assets <= 0:
            return None
        
        turnover = revenue / total_assets
        return round(turnover, 2)
    
    @staticmethod
    def calculate_financial_leverage(
        total_assets: float,
        equity: float,
    ) -> Optional[float]:
        """
        Calculate Financial Leverage (DuPont multiplier)
        
        Leverage = Total Assets / Equity
        
        Shows how much debt is used to finance assets
        Higher = more leveraged (more risky)
        """
        if not equity or equity <= 0:
            return None
        
        leverage = total_assets / equity
        return round(leverage, 2)
    
    @staticmethod
    def decompose(
        net_profit: float,
        revenue: float,
        total_assets: float,
        equity: float,
    ) -> DupontAnalysis:
        """
        Full DuPont decomposition
        
        Args:
            net_profit: Net profit in EUR
            revenue: Total revenue in EUR
            total_assets: Total assets in EUR
            equity: Shareholders' equity in EUR
        
        Returns:
            DupontAnalysis with all components and diagnosis
        """
        
        # Calculate components
        net_margin = DupontEngine.calculate_net_margin(net_profit, revenue)
        asset_turnover = DupontEngine.calculate_asset_turnover(revenue, total_assets)
        financial_leverage = DupontEngine.calculate_financial_leverage(total_assets, equity)
        
        # Calculate top-level metrics
        roa = DupontEngine.calculate_roa(net_profit, total_assets)
        roe = DupontEngine.calculate_roe(net_profit, equity)
        
        # Contribution analysis (what drives ROA)
        margin_contribution_pct = 0.0
        turnover_contribution_pct = 0.0
        leverage_contribution_pct = None
        
        if roa and roa != 0:
            # ROA = Margin × Turnover
            if net_margin is not None and asset_turnover is not None and asset_turnover != 0:
                calculated_roa = (net_margin / 100) * asset_turnover * 100
                
                # Relative contribution
                if calculated_roa != 0:
                    margin_contribution_pct = (net_margin / 100 * asset_turnover * 100) / roa * 100
                    turnover_contribution_pct = 100 - margin_contribution_pct
        
        # Contribution to ROE from leverage
        if roe and roa and roa != 0 and financial_leverage:
            leverage_contribution_pct = ((financial_leverage - 1) / financial_leverage) * 100
        
        # Determine primary driver
        primary_driver = "balanced"
        weakness = None
        
        if net_margin is None:
            net_margin = 0.0
        if asset_turnover is None:
            asset_turnover = 0.0
        
        margin_score = net_margin if net_margin > 0 else 0
        turnover_score = asset_turnover if asset_turnover > 0 else 0
        
        if margin_score > turnover_score * 3:
            primary_driver = "margin"
        elif turnover_score > margin_score * 3:
            primary_driver = "efficiency"
        elif financial_leverage and financial_leverage > 2.0:
            primary_driver = "leverage"
        else:
            primary_driver = "balanced"
        
        # Identify weaknesses
        if net_margin is not None and net_margin < 10.0:
            weakness = "low_margin"
        elif asset_turnover is not None and asset_turnover < 0.5:
            weakness = "low_turnover"
        elif financial_leverage and financial_leverage > 3.0:
            weakness = "high_leverage"
        
        return DupontAnalysis(
            roa_pct=roa,
            roe_pct=roe,
            net_margin_pct=round(net_margin, 2),
            asset_turnover=asset_turnover,
            financial_leverage=financial_leverage,
            margin_contribution_pct=round(margin_contribution_pct, 1),
            turnover_contribution_pct=round(turnover_contribution_pct, 1),
            leverage_contribution_pct=round(leverage_contribution_pct, 1) if leverage_contribution_pct else None,
            primary_driver=primary_driver,
            weakness=weakness,
        )
    
    @staticmethod
    def diagnose_driver(dupont: DupontAnalysis) -> str:
        """
        Generate diagnostic text about what's driving profitability
        
        Returns:
            One-liner diagnosis
        """
        if dupont.weakness == "low_margin":
            return f"Profitability is weak due to low margin ({dupont.net_margin_pct:.1f}%). Focus on pricing or cost reduction."
        elif dupont.weakness == "low_turnover":
            return f"Assets are underutilized (turnover: {dupont.asset_turnover:.2f}x). Focus on revenue growth or asset optimization."
        elif dupont.weakness == "high_leverage":
            return f"High financial leverage ({dupont.financial_leverage:.2f}x). Risk of debt burden; consider deleveraging."
        elif dupont.primary_driver == "margin":
            return f"Profitability driven by strong margins ({dupont.net_margin_pct:.1f}%). Maintain pricing power."
        elif dupont.primary_driver == "efficiency":
            return f"Profitability driven by operational efficiency (turnover: {dupont.asset_turnover:.2f}x). Scale for growth."
        elif dupont.primary_driver == "leverage":
            return f"Profitability enhanced by financial leverage ({dupont.financial_leverage:.2f}x). Ensure sustainable debt levels."
        else:
            return "Profitability is balanced across multiple drivers. Monitor all areas."


# ============================================
# EXTENDED DUPONT (3-FACTOR)
# ============================================

class ExtendedDupontEngine:
    """Extended 5-factor DuPont analysis (includes tax and interest)"""
    
    @staticmethod
    def compute_extended(
        ebit: float,
        net_profit: float,
        revenue: float,
        total_assets: float,
        equity: float,
    ) -> Dict:
        """
        5-factor DuPont:
        ROE = (NI/EBT) × (EBT/EBIT) × (EBIT/Sales) × (Sales/Assets) × (Assets/Equity)
        
        Factors:
        1. Tax burden (NI/EBT)
        2. Interest burden (EBT/EBIT)
        3. Operating margin (EBIT/Sales)
        4. Asset turnover (Sales/Assets)
        5. Leverage (Assets/Equity)
        """
        
        # Simplified (assuming EBT ≈ EBIT for now)
        # This would require more detailed income statement data
        
        # Basic 3-factor for now
        dupont = DupontEngine.decompose(net_profit, revenue, total_assets, equity)
        
        return {
            "roe": dupont.roe_pct,
            "net_profit_margin": dupont.net_margin_pct,
            "asset_turnover": dupont.asset_turnover,
            "financial_leverage": dupont.financial_leverage,
            "primary_driver": dupont.primary_driver,
        }
