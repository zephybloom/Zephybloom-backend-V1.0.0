"""
Objection Handler

Handle entrepreneur objections to recommendations.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class ObjectionResponse:
    """Response to an objection"""
    objection: str
    response: str
    supporting_data: Dict[str, any]
    recommendation: str


class ObjectionHandler:
    """Handle entrepreneur pushback"""
    
    def handle_objection(
        self,
        objection: str,
        recommendation: str,
        supporting_metrics: Dict[str, any],
    ) -> ObjectionResponse:
        """
        Answer an objection with data.
        """
        
        objection_lower = objection.lower()
        
        # ===== Objection: "But I'll lose that opportunity!" =====
        if "opportunity" in objection_lower or "lose" in objection_lower:
            market_opportunity = supporting_metrics.get("market_opportunity", 0)
            cost_if_wrong = supporting_metrics.get("cost_if_hire_wrong", 0)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"If you hire now and it goes wrong, you're out €{cost_if_wrong:,.0f}. "
                    f"Waiting 3 months and then hiring right costs nothing. "
                    f"The opportunity will still be there when you're ready."
                ),
                supporting_data={
                    "opportunity_size": market_opportunity,
                    "cost_of_error": cost_if_wrong,
                    "probability_error": 0.40,  # 40% chance hire underperforms
                },
                recommendation="Wait 3 months. Build the foundation first.",
            )
        
        # ===== Objection: "But we need growth!" =====
        elif "growth" in objection_lower:
            current_margin = supporting_metrics.get("current_margin", 0)
            break_even_revenue = supporting_metrics.get("break_even_new_revenue", 0)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"You DO need growth. But not until margin is {current_margin + 4}%. "
                    f"Right now, new growth at {current_margin}% margin requires a person to generate "
                    f"€{break_even_revenue:,.0f} just to cover their cost. That's unrealistic. "
                    f"Get margin healthy FIRST, then growth becomes much easier."
                ),
                supporting_data={
                    "current_margin": current_margin,
                    "healthy_margin": current_margin + 4,
                    "breakeven_new_revenue": break_even_revenue,
                },
                recommendation="Fix margin first, then grow.",
            )
        
        # ===== Objection: "But we're already stressed!" =====
        elif "stress" in objection_lower or "overworked" in objection_lower:
            capacity_util = supporting_metrics.get("capacity_utilization", 0)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"Exactly. You're at {capacity_util*100:.0f}% utilization. "
                    f"Adding a person won't fix stress - it'll add complexity. "
                    f"First: Process improvement and automation. "
                    f"Second: Once you hit 100% utilization WITH good processes, THEN hire."
                ),
                supporting_data={
                    "capacity_utilization": capacity_util,
                    "process_improvement_potential": 0.20,  # 20% improvement possible
                },
                recommendation="Optimize before hiring.",
            )
        
        # ===== Objection: "But my competitor is hiring!" =====
        elif "competitor" in objection_lower:
            your_margin = supporting_metrics.get("your_margin", 0)
            competitor_margin = supporting_metrics.get("competitor_margin", 15)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"Your competitor probably has {competitor_margin}% margin. You have {your_margin}%. "
                    f"They can afford to be aggressive. You can't yet. "
                    f"Don't compete on speed - compete on profitability. Win when they run out of money."
                ),
                supporting_data={
                    "your_margin": your_margin,
                    "competitor_margin": competitor_margin,
                    "margin_gap_cost": (competitor_margin - your_margin) * supporting_metrics.get("annual_revenue", 0) / 100,
                },
                recommendation="Build sustainable business, not fast-moving one.",
            )
        
        # ===== Objection: "But the market moves fast!" =====
        elif "fast" in objection_lower or "market" in objection_lower:
            payback_months = supporting_metrics.get("payback_months", 0)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"Speed matters. So does profitability. "
                    f"A hire with {payback_months}-month payback is a bet, not an investment. "
                    f"Win the market AND keep money. Don't trade one for the other."
                ),
                supporting_data={
                    "payback_months": payback_months,
                    "acceptable_payback": 12,
                },
                recommendation="Move fast AND smart.",
            )
        
        # ===== Objection: "But this person is really good!" =====
        elif "good" in objection_lower or "talent" in objection_lower or "person" in objection_lower:
            base_scenario_payback = supporting_metrics.get("realistic_payback", 0)
            best_scenario_payback = supporting_metrics.get("best_payback", 0)
            
            return ObjectionResponse(
                objection=objection,
                response=(
                    f"Even a great person has a payback period. "
                    f"Best case: {best_scenario_payback} months. Realistic: {base_scenario_payback} months. "
                    f"That's a long time to wait for a fixed cost to pay off. "
                    f"But if you're SURE they're top-tier (not just good), then maybe. "
                    f"Get a second opinion."
                ),
                supporting_data={
                    "best_payback": best_scenario_payback,
                    "realistic_payback": base_scenario_payback,
                    "confidence_required": "95%+",
                },
                recommendation="Only if you're 100% certain.",
            )
        
        # ===== Default: Unknown objection =====
        else:
            return ObjectionResponse(
                objection=objection,
                response="That's a fair point. Let me think through it with the data...",
                supporting_data=supporting_metrics,
                recommendation="More analysis needed.",
            )


def get_handler() -> ObjectionHandler:
    return ObjectionHandler()
