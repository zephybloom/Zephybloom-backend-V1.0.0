# -*- coding: utf-8 -*-
"""
Multi-Scenario Engine - Genera 3 scenari finanziari (pessimista/realista/ottimista)
con forecasting 12 mesi e impact analysis
"""
from __future__ import annotations

from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, asdict
import math

from core.metrics import compute_kpis
from utils.math_utils import safe_div

__all__ = [
    "Scenario",
    "ScenarioComparison",
    "MultiScenarioEngine",
    "generate_scenarios",
]


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class Scenario:
    """Singolo scenario con KPI proiettati"""
    nome: str  # "Pessimista", "Realista", "Ottimista"
    tipo: str  # "pessimistic", "realistic", "optimistic"
    probabilita: float  # 0-1 (20%, 50%, 30%)

    # Base year metrics
    fatturato_anno0: float
    utile_anno0: float
    roi_anno0: float

    # 12-month projection
    fatturato_anno1: float  # End of year projection
    utile_anno1: float
    roi_anno1: float
    ebitda_anno1: float

    # Key drivers
    revenue_growth_pct: float  # Growth rate %
    margin_evolution_pct: float  # Margin change in %
    capex_needed: float  # Investment required
    cash_impact: float  # Projected cash flow impact

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ScenarioComparison:
    """Comparison tra 3 scenari con metriche sintetiche"""
    scenarios: List[Scenario]
    expected_value_revenue: float  # Probability-weighted revenue
    expected_value_profit: float  # Probability-weighted profit
    range_low: float  # Pessimistic revenue
    range_high: float  # Optimistic revenue
    range_delta: float  # Differenza high-low
    recommended_scenario: str  # "pessimistic", "realistic", "optimistic"
    decision_rationale: str  # Spiegazione della raccomandazione
    key_risks: List[str]  # Top 3 rischi
    key_opportunities: List[str]  # Top 3 opportunità

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenarios": [s.to_dict() for s in self.scenarios],
            "expected_value_revenue": self.expected_value_revenue,
            "expected_value_profit": self.expected_value_profit,
            "range_low": self.range_low,
            "range_high": self.range_high,
            "range_delta": self.range_delta,
            "recommended_scenario": self.recommended_scenario,
            "decision_rationale": self.decision_rationale,
            "key_risks": self.key_risks,
            "key_opportunities": self.key_opportunities,
        }


# =============================================================================
# Helpers
# =============================================================================

def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _apply_growth_scenario(
    base_value: float,
    scenario_type: str,
    volatility: float = 0.1,
) -> float:
    """
    Applica crescita scenario-specifica.
    volatility: 0.1 = 10% standard deviation
    """
    base = _asf(base_value, 0.0)

    if scenario_type == "pessimistic":
        # -volatility% (es. -10%)
        return base * (1.0 - volatility)
    elif scenario_type == "optimistic":
        # +volatility% (es. +10%)
        return base * (1.0 + volatility)
    else:  # realistic
        return base


def _project_revenue_12m(
    base_revenue: float,
    scenario_type: str,
    sector: str = "default",
) -> Tuple[float, float]:
    """
    Project 12-month revenue con crescita scenario-specifica
    
    Returns: (projected_revenue, growth_rate_pct)
    """
    base = _asf(base_revenue, 0.0)

    # Market growth rates by sector
    sector_growth = {
        "tech": 0.25,  # 25% annual growth
        "saas": 0.20,  # 20%
        "manufacturing": 0.05,  # 5%
        "retail": 0.02,  # 2%
        "default": 0.08,  # 8%
    }

    base_growth = sector_growth.get(sector.lower(), 0.08)

    # Apply scenario multiplier
    if scenario_type == "pessimistic":
        growth = base_growth * 0.5  # Half the base growth
    elif scenario_type == "optimistic":
        growth = base_growth * 1.5  # 1.5x the base growth
    else:  # realistic
        growth = base_growth

    projected = base * (1.0 + growth)
    return projected, growth * 100.0


def _project_margin_evolution(
    base_margin_pct: float,
    scenario_type: str,
    sector: str = "default",
) -> float:
    """
    Project margin evoluzione año 1
    """
    base_margin = _asf(base_margin_pct, 0.0) / 100.0

    if scenario_type == "pessimistic":
        # Margi comprimono: -1-3% punti
        return max(0.0, (base_margin - 0.02) * 100.0)
    elif scenario_type == "optimistic":
        # Margini si espandono: +1-2% punti
        return min(1.0, (base_margin + 0.015)) * 100.0
    else:  # realistic
        # Slight improvement
        return min(1.0, (base_margin + 0.005)) * 100.0


# =============================================================================
# Multi-Scenario Engine
# =============================================================================

class MultiScenarioEngine:
    """
    Genera 3 scenari finanziari (pessimista, realista, ottimista)
    con proiezioni 12 mesi e comparison analysis
    """

    def generate_scenarios(
        self,
        fatturato: float,
        utile: float,
        roi: float = 0.0,
        ebitda: float = 0.0,
        investimenti: float = 0.0,
        sector: str = "default",
    ) -> ScenarioComparison:
        """
        Genera 3 scenari e ritorna comparison
        """

        # Calcola metrica base (net margin)
        net_margin = safe_div(_asf(utile), _asf(fatturato), 0.0)

        # Scenario 1: Pessimistic (20% probability)
        pes_revenue, pes_growth = _project_revenue_12m(fatturato, "pessimistic", sector)
        pes_margin_pct = _project_margin_evolution(net_margin * 100.0, "pessimistic", sector)
        pes_utile = pes_revenue * (pes_margin_pct / 100.0)
        pes_ebitda = pes_utile + (_asf(ebitda) * 0.95)  # EBITDA down 5%
        pes_roi = safe_div(pes_utile, max(_asf(investimenti), 1.0), 0.0) * 100.0
        pes_capex = _asf(investimenti) * 1.2  # Need 20% more investment

        scenario_pessimistic = Scenario(
            nome="Pessimista",
            tipo="pessimistic",
            probabilita=0.20,
            fatturato_anno0=fatturato,
            utile_anno0=utile,
            roi_anno0=roi,
            fatturato_anno1=pes_revenue,
            utile_anno1=pes_utile,
            roi_anno1=pes_roi,
            ebitda_anno1=pes_ebitda,
            revenue_growth_pct=pes_growth,
            margin_evolution_pct=pes_margin_pct - (net_margin * 100.0),
            capex_needed=pes_capex,
            cash_impact=pes_utile - utile,  # Delta profit
        )

        # Scenario 2: Realistic (50% probability)
        rea_revenue, rea_growth = _project_revenue_12m(fatturato, "realistic", sector)
        rea_margin_pct = _project_margin_evolution(net_margin * 100.0, "realistic", sector)
        rea_utile = rea_revenue * (rea_margin_pct / 100.0)
        rea_ebitda = rea_utile + (_asf(ebitda) * 1.05)
        rea_roi = safe_div(rea_utile, max(_asf(investimenti), 1.0), 0.0) * 100.0
        rea_capex = _asf(investimenti)

        scenario_realistic = Scenario(
            nome="Realista",
            tipo="realistic",
            probabilita=0.50,
            fatturato_anno0=fatturato,
            utile_anno0=utile,
            roi_anno0=roi,
            fatturato_anno1=rea_revenue,
            utile_anno1=rea_utile,
            roi_anno1=rea_roi,
            ebitda_anno1=rea_ebitda,
            revenue_growth_pct=rea_growth,
            margin_evolution_pct=rea_margin_pct - (net_margin * 100.0),
            capex_needed=rea_capex,
            cash_impact=rea_utile - utile,
        )

        # Scenario 3: Optimistic (30% probability)
        opt_revenue, opt_growth = _project_revenue_12m(fatturato, "optimistic", sector)
        opt_margin_pct = _project_margin_evolution(net_margin * 100.0, "optimistic", sector)
        opt_utile = opt_revenue * (opt_margin_pct / 100.0)
        opt_ebitda = opt_utile + (_asf(ebitda) * 1.15)
        opt_roi = safe_div(opt_utile, max(_asf(investimenti), 1.0), 0.0) * 100.0
        opt_capex = _asf(investimenti) * 0.8  # Need less investment

        scenario_optimistic = Scenario(
            nome="Ottimista",
            tipo="optimistic",
            probabilita=0.30,
            fatturato_anno0=fatturato,
            utile_anno0=utile,
            roi_anno0=roi,
            fatturato_anno1=opt_revenue,
            utile_anno1=opt_utile,
            roi_anno1=opt_roi,
            ebitda_anno1=opt_ebitda,
            revenue_growth_pct=opt_growth,
            margin_evolution_pct=opt_margin_pct - (net_margin * 100.0),
            capex_needed=opt_capex,
            cash_impact=opt_utile - utile,
        )

        scenarios = [scenario_pessimistic, scenario_realistic, scenario_optimistic]

        # Calcola expected value (probability-weighted)
        exp_revenue = (
            pes_revenue * 0.20 +
            rea_revenue * 0.50 +
            opt_revenue * 0.30
        )
        exp_profit = (
            pes_utile * 0.20 +
            rea_utile * 0.50 +
            opt_utile * 0.30
        )

        # Recommendation logic
        # If optimistic is significantly better than realistic, recommend it
        if opt_utile > rea_utile * 1.15:
            recommended = "optimistic"
            rationale = "Lo scenario ottimista offre >15% di opportunità di profitto zusätzlich con rischi gestibili"
        elif pes_utile < 0:
            recommended = "realistic"
            rationale = "Lo scenario pessimista mostra rischio di perdita. Raccomandare il realista come base di planning."
        else:
            recommended = "realistic"
            rationale = "Lo scenario realista bilanancia crescita e rischio. Tracciare progress vs. realistic per alert precoci."

        # Identifica key risks
        key_risks = []
        if pes_utile < 0:
            key_risks.append("Rischio di perdita nello scenario pessimista - cash runway limitato")
        if pes_revenue < fatturato:
            key_risks.append("Contrazione fatturato oltre il 10% eroderebbe profittabilità")
        if opt_capex > _asf(investimenti) * 2:
            key_risks.append("CAPEX richiesto potrebbe impattare liquidità")

        # Identifica key opportunities
        key_opportunities = []
        if opt_utile > rea_utile * 1.2:
            key_opportunities.append("Upside significativo (+20%) se si accelera crescita con investimenti mirati")
        if opt_margin_pct > rea_margin_pct + 2:
            key_opportunities.append("Miglioramento margini di 2-3 punti % attraverso operazioni efficienti")
        if opt_revenue > fatturato * 1.3:
            key_opportunities.append("Potenziale crescita >30% se si ottimizzano canali acquisition")

        return ScenarioComparison(
            scenarios=scenarios,
            expected_value_revenue=exp_revenue,
            expected_value_profit=exp_profit,
            range_low=pes_revenue,
            range_high=opt_revenue,
            range_delta=opt_revenue - pes_revenue,
            recommended_scenario=recommended,
            decision_rationale=rationale,
            key_risks=key_risks,
            key_opportunities=key_opportunities,
        )


def generate_scenarios(
    fatturato: float,
    utile: float,
    roi: float = 0.0,
    ebitda: float = 0.0,
    investimenti: float = 0.0,
    sector: str = "default",
) -> ScenarioComparison:
    """Wrapper pubblico per scenario generation"""
    return MultiScenarioEngine().generate_scenarios(
        fatturato=fatturato,
        utile=utile,
        roi=roi,
        ebitda=ebitda,
        investimenti=investimenti,
        sector=sector,
    )
