# -*- coding: utf-8 -*-
# content/core/metrics.py — KPI deterministici (rate come frazioni 0..1) + Sensitivity/Tornado
from __future__ import annotations

"""
Motore KPI basato su content.core.schemas.KPI.

CONVENZIONI IMPORTANTI
----------------------
- Tutte le percentuali qui dentro sono espresse come FRAZIONI 0..1:
    - mc_rate
    - gross_margin_rate
    - net_margin_rate
    - roi
- Il layer API/router può poi convertirle in punti percentuali dove serve.
- compute_kpis(...) è la facciata pubblica usata dal router e dagli endpoint.
"""

from typing import Dict, List, Tuple, Iterable, Any

from core.schemas import KPI
from utils.math_utils import safe_div

__all__ = [
    "margine_contribuzione",
    "mc_rate",
    "break_even_value",
    "break_even_qty",
    "utile",
    "roi_fraction",
    "ebitda",
    "gross_margin_rate_fraction",
    "net_margin_rate_fraction",
    "cash_conversion_cycle",
    "altman_z",
    "ltv_saas",
    "MetricsEngine",
    "compute_kpis",
    "kpi_to_dict",
    "sensitivity_analysis",
    "tornado_data",
]

# =====================================================================================
# Helpers
# =====================================================================================


def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _clamp_nonneg(x: float) -> float:
    return max(0.0, _asf(x, 0.0))


def _clamp_rate01(x: float) -> float:
    return max(0.0, min(1.0, _asf(x, 0.0)))


def _coerce_fraction(x: Any) -> float:
    """
    Converte valori percentuali/frazioni in una frazione 0..1.
    Esempi:
      0.12 -> 0.12
      12   -> 0.12
      120  -> 1.20
    """
    v = _asf(x, 0.0)
    if abs(v) > 1.0:
        v = v / 100.0
    return v


def _model_to_dict(obj: Any) -> Dict[str, Any]:
    if hasattr(obj, "model_dump"):
        try:
            dumped = obj.model_dump()
            if isinstance(dumped, dict):
                return dumped
        except Exception:
            pass
    if isinstance(obj, dict):
        return dict(obj)
    return {}


def kpi_to_dict(kpi: KPI) -> Dict[str, Any]:
    md = _model_to_dict(kpi)
    if md:
        return md
    try:
        return {
            k: v
            for k, v in vars(kpi).items()
            if not k.startswith("_")
        }
    except Exception:
        return {}


def _build_kpi_safe(**data: Any) -> KPI:
    """
    Costruisce KPI evitando recursion legate a validator / post-init / serializer.
    Prima prova model_construct (Pydantic v2), poi construct, poi fallback classico.
    """
    try:
        if hasattr(KPI, "model_construct"):
            return KPI.model_construct(**data)  # type: ignore[attr-defined]
    except Exception:
        pass

    try:
        if hasattr(KPI, "construct"):
            return KPI.construct(**data)  # type: ignore[attr-defined]
    except Exception:
        pass

    return KPI(**data)


# =====================================================================================
# Primitive
# =====================================================================================


def margine_contribuzione(fatturato: float, costi_variabili: float) -> float:
    return _asf(fatturato) - _asf(costi_variabili)


def mc_rate(fatturato: float, mc: float) -> float:
    return _clamp_rate01(safe_div(_asf(mc), _asf(fatturato), 0.0))


def break_even_value(costi_fissi: float, mc_rate_: float) -> float:
    cf = _clamp_nonneg(costi_fissi)
    mcr = _asf(mc_rate_, 0.0)
    return safe_div(cf, mcr, 0.0) if mcr > 0 else 0.0


def break_even_qty(costi_fissi: float, prezzo_medio: float, costo_variabile_unitario: float) -> float:
    cf = _clamp_nonneg(costi_fissi)
    p = _clamp_nonneg(prezzo_medio)
    cvu = _clamp_nonneg(costo_variabile_unitario)
    contrib_unit = p - cvu
    return safe_div(cf, contrib_unit, 0.0) if contrib_unit > 0 else 0.0


def utile(mc: float, costi_fissi: float) -> float:
    return _asf(mc) - _asf(costi_fissi)


def roi_fraction(utile_: float, investimenti: float) -> float:
    inv = _clamp_nonneg(investimenti)
    if inv <= 0:
        return 0.0
    return safe_div(_asf(utile_), inv, 0.0)


def ebitda(utile_: float, ammortamenti: float = 0.0) -> float:
    return _asf(utile_) + _asf(ammortamenti)


def gross_margin_rate_fraction(fatturato: float, cogs: float) -> float:
    f = _asf(fatturato)
    c = _asf(cogs)
    gm = f - c
    return _clamp_rate01(safe_div(gm, f, 0.0))


def net_margin_rate_fraction(utile_: float, fatturato: float) -> float:
    return _clamp_rate01(safe_div(_asf(utile_), _asf(fatturato), 0.0))


def cash_conversion_cycle(dso: float, dio: float, dpo: float) -> float:
    return max(0.0, _asf(dso) + _asf(dio) - _asf(dpo))


def altman_z(wc: float, re: float, ebit: float, mve: float, sales: float, ta: float, tl: float) -> float:
    ta_ = _asf(ta)
    tl_ = _asf(tl)

    if ta_ <= 0:
        return 0.0

    try:
        x1 = safe_div(_asf(wc), ta_, 0.0)
        x2 = safe_div(_asf(re), ta_, 0.0)
        x3 = safe_div(_asf(ebit), ta_, 0.0)
        x4 = safe_div(_asf(mve), tl_, 0.0) if tl_ > 0 else 0.0
        x5 = safe_div(_asf(sales), ta_, 0.0)
        return 1.2 * x1 + 1.4 * x2 + 3.3 * x3 + 0.6 * x4 + 1.0 * x5
    except Exception:
        return 0.0


def ltv_saas(arpu: float, gross_margin_frac: float, churn_frac: float) -> float:
    a = _clamp_nonneg(arpu)
    g = _clamp_rate01(gross_margin_frac)
    c = max(0.0, _asf(churn_frac, 0.0))
    return safe_div(a * g, c, 0.0) if c > 0 else 0.0


# =====================================================================================
# Engine
# =====================================================================================

_INPUT_FIELDS: tuple[str, ...] = (
    "fatturato",
    "costi_variabili",
    "costi_fissi",
    "investimenti",
    "prezzo_medio",
    "costo_variabile_unitario",
    "cogs",
    "ammortamenti",
    "dso",
    "dio",
    "dpo",
    "wc",
    "re",
    "ebit",
    "mve",
    "sales",
    "ta",
    "tl",
    "arpu",
    "churn_rate",
    "ltv",
    "mrr",
    "cac",
    "nrr",
)


def _extract_inputs_from_kpi(kpi: KPI) -> Dict[str, float]:
    data: Dict[str, float] = {}
    md = _model_to_dict(kpi)
    for k in _INPUT_FIELDS:
        data[k] = _asf(md.get(k, 0.0), 0.0)
    return data


class MetricsEngine:
    def compute(self, **kw: Any) -> KPI:
        f = _clamp_nonneg(kw.get("fatturato", 0.0))
        sales_kw = _clamp_nonneg(kw.get("sales", 0.0))
        if f <= 0.0 and sales_kw > 0.0:
            f = sales_kw

        cv = _clamp_nonneg(kw.get("costi_variabili", 0.0))
        cogs = _clamp_nonneg(kw.get("cogs", 0.0))
        if cv <= 0.0 and cogs > 0.0:
            cv = cogs
        if cogs <= 0.0 and cv > 0.0:
            cogs = cv

        cf = _clamp_nonneg(kw.get("costi_fissi", 0.0))
        inv = _clamp_nonneg(kw.get("investimenti", 0.0))

        pm = _clamp_nonneg(kw.get("prezzo_medio", 0.0))
        cvu = _clamp_nonneg(kw.get("costo_variabile_unitario", 0.0))

        amm = _clamp_nonneg(kw.get("ammortamenti", 0.0))

        dso = _clamp_nonneg(kw.get("dso", 0.0))
        dio = _clamp_nonneg(kw.get("dio", 0.0))
        dpo = _clamp_nonneg(kw.get("dpo", 0.0))

        wc = _asf(kw.get("wc", 0.0), 0.0)
        re = _asf(kw.get("re", 0.0), 0.0)
        ebit_in = _asf(kw.get("ebit", 0.0), 0.0)
        mve = _clamp_nonneg(kw.get("mve", 0.0))
        sales = f if f > 0 else sales_kw
        ta = _clamp_nonneg(kw.get("ta", 0.0))
        tl = _clamp_nonneg(kw.get("tl", 0.0))

        arpu = _clamp_nonneg(kw.get("arpu", 0.0))
        churn = _coerce_fraction(kw.get("churn_rate", 0.0))
        churn = _clamp_rate01(churn)
        ltv = _clamp_nonneg(kw.get("ltv", 0.0))

        mrr = _clamp_nonneg(kw.get("mrr", 0.0))
        cac = _clamp_nonneg(kw.get("cac", 0.0))
        nrr = _coerce_fraction(kw.get("nrr", 0.0))
        nrr = max(0.0, _asf(nrr, 0.0))

        mc = margine_contribuzione(f, cv)
        mcr = mc_rate(f, mc)

        bep_val = break_even_value(cf, mcr) if mcr > 0 else 0.0
        bep_qty = break_even_qty(cf, pm, cvu) if (pm > 0 and cvu >= 0) else 0.0

        u = utile(mc, cf)
        _roi = roi_fraction(u, inv) if inv > 0 else 0.0

        _ebitda = ebitda(u, amm)

        _gmr = gross_margin_rate_fraction(f, cogs) if f > 0 else 0.0
        _nmr = net_margin_rate_fraction(u, f) if f > 0 else 0.0

        _ccc = cash_conversion_cycle(dso, dio, dpo) if (dso or dio or dpo) else 0.0

        ebit_for_z = ebit_in if ebit_in != 0.0 else (u - amm)
        _z = altman_z(wc, re, ebit_for_z, mve, sales, ta, tl) if ta > 0 else 0.0

        if ltv <= 0 and arpu > 0 and churn > 0:
            ltv = ltv_saas(arpu, _gmr if _gmr > 0 else mcr, churn)

        data = {
            "fatturato": f,
            "costi_variabili": cv,
            "costi_fissi": cf,
            "investimenti": inv,
            "prezzo_medio": pm,
            "costo_variabile_unitario": cvu,
            "cogs": cogs,
            "ammortamenti": amm,
            "dso": dso,
            "dio": dio,
            "dpo": dpo,
            "wc": wc,
            "re": re,
            "ebit": ebit_for_z,
            "mve": mve,
            "sales": sales,
            "ta": ta,
            "tl": tl,
            "arpu": arpu,
            "churn_rate": churn,
            "ltv": ltv,
            "mrr": mrr,
            "cac": cac,
            "nrr": nrr,
            "utile": u,
            "margine_contribuzione": mc,
            "mc_rate": mcr,
            "break_even": bep_val,
            "break_even_qty": bep_qty,
            "ebitda": _ebitda,
            "gross_margin_rate": _gmr,
            "net_margin_rate": _nmr,
            "roi": _roi,
            "ccc": _ccc,
            "altman_z": _z,
        }

        return _build_kpi_safe(**data)

    def recompute_from_kpi(self, kpi: KPI, **overrides: float) -> KPI:
        base = _extract_inputs_from_kpi(kpi)
        for k, v in overrides.items():
            base[k] = _asf(v, 0.0)
        return self.compute(**base)


def compute_kpis(**kwargs: Any) -> KPI:
    return MetricsEngine().compute(**kwargs)


# =====================================================================================
# Sensitivity & Tornado
# =====================================================================================


def _linspace(start: float, stop: float, steps: int) -> List[float]:
    if steps <= 1:
        return [float(stop)]
    step = (float(stop) - float(start)) / float(steps - 1)
    return [float(start) + i * step for i in range(steps)]


def _metric_snapshot(kpi: KPI, keys: Iterable[str]) -> Dict[str, float]:
    md = _model_to_dict(kpi)
    out: Dict[str, float] = {}
    for k in keys:
        out[k] = _asf(md.get(k, 0.0), 0.0)
    return out


def sensitivity_analysis(
    kpi: KPI,
    params: Dict[str, Tuple[float, float]],
    *,
    steps: int = 5,
    metric_keys: Iterable[str] = ("utile", "roi", "mc_rate", "ebitda"),
) -> List[Dict[str, Any]]:
    eng = MetricsEngine()
    base_inputs = _extract_inputs_from_kpi(kpi)
    base_metrics = _metric_snapshot(kpi, metric_keys)
    rows: List[Dict[str, Any]] = []

    steps = max(2, int(steps))

    for p, bounds in (params or {}).items():
        if p not in base_inputs:
            continue
        if not isinstance(bounds, (tuple, list)) or len(bounds) != 2:
            continue

        dmin = _asf(bounds[0], 0.0)
        dmax = _asf(bounds[1], 0.0)

        baseline_val = _asf(base_inputs[p], 0.0)
        scale = baseline_val if baseline_val != 0.0 else 1.0

        vmin = baseline_val * (1.0 + dmin)
        vmax = baseline_val * (1.0 + dmax)

        for v in _linspace(vmin, vmax, steps):
            new_kpi = eng.recompute_from_kpi(kpi, **{p: v})
            snap = _metric_snapshot(new_kpi, metric_keys)

            rows.append(
                {
                    "param": p,
                    "value": v,
                    "baseline_value": baseline_val,
                    "delta_frac": safe_div(v - baseline_val, scale, 0.0),
                    "metrics": snap,
                    "baseline_metrics": base_metrics,
                }
            )

    return rows


def tornado_data(
    kpi: KPI,
    deltas: Dict[str, float],
    *,
    metric: str = "utile",
) -> List[Dict[str, Any]]:
    eng = MetricsEngine()
    base_inputs = _extract_inputs_from_kpi(kpi)
    base_metrics = _metric_snapshot(kpi, (metric,))
    baseline_metric = _asf(base_metrics.get(metric, 0.0), 0.0)

    out: List[Dict[str, Any]] = []

    for p, d in (deltas or {}).items():
        if p not in base_inputs:
            continue

        d = abs(_asf(d, 0.0))
        baseline_val = _asf(base_inputs[p], 0.0)

        low_v = baseline_val * (1.0 - d)
        high_v = baseline_val * (1.0 + d)

        kpi_low = eng.recompute_from_kpi(kpi, **{p: low_v})
        kpi_high = eng.recompute_from_kpi(kpi, **{p: high_v})

        m_low = _asf(_metric_snapshot(kpi_low, (metric,)).get(metric, 0.0), 0.0)
        m_high = _asf(_metric_snapshot(kpi_high, (metric,)).get(metric, 0.0), 0.0)

        delta_low = m_low - baseline_metric
        delta_high = m_high - baseline_metric
        range_abs = abs(m_high - m_low)

        out.append(
            {
                "param": p,
                "baseline": baseline_metric,
                "baseline_value": baseline_val,
                "low_value": low_v,
                "high_value": high_v,
                "metric_low": m_low,
                "metric_high": m_high,
                "delta_low": delta_low,
                "delta_high": delta_high,
                "range_abs": range_abs,
                "delta_frac": d,
            }
        )

    out.sort(key=lambda r: r["range_abs"], reverse=True)
    return out