"""
Personalization Engine - Customize recommendations to entrepreneur profile

Takes generic decisions and adapts them for:
- Risk appetite matching
- Expertise level explanation
- Growth ambition alignment
- Language customization
"""

from typing import List, Dict, Optional
from dataclasses import dataclass
from core.entrepreneur_profiler import (
    EntrepreneurProfile,
    RiskTolerance,
    ExpertiseLevel,
    GrowthAppetite,
)
from core.dynamic_tone_manager import (
    TonePersonalization,
    ExplainabilityLevel,
)


@dataclass
class PersonalizedRecommendation:
    """A recommendation adapted for specific entrepreneur"""
    original_title: str
    personalized_title: str  # Title adapted for profile
    
    # Messaging
    opening: str             # Personalized opening
    core_message: str        # Main recommendation
    why_now: str            # Why this matters now
    
    # Context
    risk_assessment: str     # Risk level for THIS entrepreneur
    success_probability: float  # 0-1, for this entrepreneur
    
    # Alternatives
    alternatives: List[str] = None  # Other options to consider
    
    # Explainability
    explanation_short: str = ""  # One sentence
    explanation_detailed: str = ""  # Full explanation with formulas
    
    # Success stories
    similar_company_example: Optional[str] = None


class PersonalizationEngine:
    """Customize decisions to entrepreneur profile"""
    
    @staticmethod
    def personalize_recommendation(
        title: str,
        description: str,
        expected_impact_eur: float,
        risk_level: str,  # "low", "medium", "high"
        profile: EntrepreneurProfile,
        tone: TonePersonalization,
    ) -> PersonalizedRecommendation:
        """
        Customize a recommendation for a specific entrepreneur.
        
        Args:
            title: Original recommendation title
            description: What to do
            expected_impact_eur: Expected financial impact
            risk_level: Inherent risk of this decision
            profile: Entrepreneur's profile
            tone: Tone/messaging settings
        
        Returns:
            PersonalizedRecommendation
        """
        
        # ===== ADAPT TITLE =====
        personalized_title = PersonalizationEngine._adapt_title(
            title, profile, tone.tone
        )
        
        # ===== OPENING =====
        opening = PersonalizationEngine._generate_opening(
            tone.recommendation_prefix,
            title,
            tone.tone,
        )
        
        # ===== CORE MESSAGE =====
        core = PersonalizationEngine._tailor_description(
            description,
            profile,
            tone.explainability,
        )
        
        # ===== WHY NOW =====
        why_now = PersonalizationEngine._why_now(
            title,
            expected_impact_eur,
            profile.pain_tolerance,
            tone.action_urgency,
        )
        
        # ===== RISK ASSESSMENT =====
        risk_assessment = PersonalizationEngine._risk_assessment(
            risk_level,
            profile.risk_tolerance,
            tone.risk_framing,
        )
        
        # ===== SUCCESS PROBABILITY =====
        # For this entrepreneur, how likely to succeed?
        success_prob = PersonalizationEngine._success_probability(
            title,
            profile,
            risk_level,
        )
        
        # ===== GENERATE ALTERNATIVES =====
        alternatives = None
        if tone.show_alternatives:
            alternatives = PersonalizationEngine._generate_alternatives(
                title, profile
            )
        
        # ===== EXPLANATIONS =====
        exp_short = PersonalizationEngine._explain_short(
            title, expected_impact_eur, profile
        )
        exp_detailed = PersonalizationEngine._explain_detailed(
            title, description, profile
        )
        
        # ===== SIMILAR COMPANY EXAMPLE =====
        example = None
        if tone.include_success_stories:
            example = PersonalizationEngine._generate_example(
                title, profile
            )
        
        return PersonalizedRecommendation(
            original_title=title,
            personalized_title=personalized_title,
            opening=opening,
            core_message=core,
            why_now=why_now,
            risk_assessment=risk_assessment,
            success_probability=success_prob,
            alternatives=alternatives,
            explanation_short=exp_short,
            explanation_detailed=exp_detailed,
            similar_company_example=example,
        )
    
    @staticmethod
    def _adapt_title(
        title: str,
        profile: EntrepreneurProfile,
        tone,
    ) -> str:
        """Adapt title to entrepreneur's context"""
        
        # Conservative + high risk decision → Add safety language
        if (profile.risk_tolerance == RiskTolerance.CONSERVATIVE and
            "pricing" in title.lower()):
            return f"Strategic: {title}"
        
        # Aggressive + safe decision → Emphasize upside
        if (profile.risk_tolerance == RiskTolerance.AGGRESSIVE and
            "cost" in title.lower()):
            return f"Growth lever: {title}"
        
        # Novice → Make more concrete
        if profile.expertise_level == ExpertiseLevel.NOVICE:
            return f"Actionable: {title}"
        
        return title
    
    @staticmethod
    def _generate_opening(prefix: str, title: str, tone) -> str:
        """Generate personalized opening phrase"""
        return f"{prefix} focusing on {title.lower()} as your next priority."
    
    @staticmethod
    def _tailor_description(
        description: str,
        profile: EntrepreneurProfile,
        explainability: ExplainabilityLevel,
    ) -> str:
        """Tailor description to profile's explainability preference"""
        
        if explainability == ExplainabilityLevel.MINIMAL:
            # Just the action
            return description.split(".")[0] + "."
        
        elif explainability == ExplainabilityLevel.EDUCATIONAL:
            # Add educational framing
            return (
                f"Here's how: {description}\n"
                f"Why this works: Because it directly addresses both your revenue and margin."
            )
        
        elif explainability == ExplainabilityLevel.DETAILED:
            # Full explanation
            return description
        
        else:  # MODERATE
            # Description + brief why
            return f"{description}\n\nKey insight: This works because margins are your #1 bottleneck."
    
    @staticmethod
    def _why_now(
        title: str,
        impact_eur: float,
        pain_tolerance,
        urgency: str,
    ) -> str:
        """Why this decision should be made now"""
        
        if urgency == "immediate":
            return f"Every week you wait costs €{impact_eur/52:,.0f} in lost opportunity."
        elif urgency == "soon":
            return f"Implement in next 2-4 weeks to capture €{impact_eur:,.0f} benefit."
        elif urgency == "gradual":
            return f"Plan for implementation over next quarter (€{impact_eur:,.0f} impact)."
        else:
            return f"When ready: €{impact_eur:,.0f} opportunity available."
    
    @staticmethod
    def _risk_assessment(risk_level: str, tolerance, framing: str) -> str:
        """Explain risk in language matching entrepreneur's tolerance"""
        
        if tolerance == RiskTolerance.CONSERVATIVE:
            if risk_level == "high":
                return "This has significant downside risk. Consider phased approach."
            elif risk_level == "medium":
                return "Moderate risk with good safety net if things go wrong."
            else:
                return "Low risk, proven approach."
        
        elif tolerance == RiskTolerance.AGGRESSIVE:
            if risk_level == "high":
                return "High upside potential, worth the risk."
            elif risk_level == "medium":
                return "Balanced risk/reward with growth potential."
            else:
                return "Safe bet, but consider bolder alternatives."
        
        else:  # MODERATE
            if risk_level == "high":
                return f"Significant risk. Proceed only with proper safeguards."
            elif risk_level == "medium":
                return "Reasonable risk with mitigations in place."
            else:
                return "Low risk opportunity."
    
    @staticmethod
    def _success_probability(
        title: str,
        profile: EntrepreneurProfile,
        risk_level: str,
    ) -> float:
        """Estimate success probability for this entrepreneur"""
        
        base_prob = {
            "low": 0.85,
            "medium": 0.70,
            "high": 0.50,
        }.get(risk_level, 0.60)
        
        # Expert + right decision style → higher success
        if profile.expertise_level == ExpertiseLevel.EXPERT:
            base_prob += 0.15
        
        # Novice → slightly lower
        if profile.expertise_level == ExpertiseLevel.NOVICE:
            base_prob -= 0.10
        
        # Return clamped to 0-1
        return max(0.0, min(1.0, base_prob))
    
    @staticmethod
    def _generate_alternatives(title: str, profile: EntrepreneurProfile) -> List[str]:
        """Generate alternative approaches"""
        
        alternatives = []
        
        if "pricing" in title.lower():
            alternatives = [
                "Volume increase (instead of price increase)",
                "Product bundling (capture value differently)",
                "Tiered pricing (extract max from each segment)",
            ]
        
        elif "cost" in title.lower():
            alternatives = [
                "Automation (reduce headcount impact)",
                "Outsourcing (transfer to vendor)",
                "Renegotiate (keep quality, reduce cost)",
            ]
        
        elif "hiring" in title.lower():
            alternatives = [
                "Contract/freelance (test before hiring)",
                "Offshore (lower cost workforce)",
                "Defer (optimize existing team first)",
            ]
        
        # If conservative, add "do nothing" alternative
        if profile.risk_tolerance == RiskTolerance.CONSERVATIVE:
            alternatives.append("Delay decision (monitor situation longer)")
        
        return alternatives
    
    @staticmethod
    def _explain_short(title: str, impact: float, profile) -> str:
        """One-sentence explanation"""
        return f"{title} could generate €{impact:,.0f} additional profit in 90 days."
    
    @staticmethod
    def _explain_detailed(title: str, description: str, profile) -> str:
        """Full detailed explanation"""
        
        if profile.expertise_level == ExpertiseLevel.NOVICE:
            return (
                f"Why this works:\n"
                f"1. {description}\n"
                f"2. No major dependencies\n"
                f"3. Returns visible in 30-60 days"
            )
        else:
            return description
    
    @staticmethod
    def _generate_example(title: str, profile) -> str:
        """Generate relevant case example"""
        
        if "pricing" in title.lower():
            if profile.industry == "saas":
                return "Similar SaaS companies increased pricing 10-15% YoY with <5% churn"
            elif profile.industry == "retail":
                return "Retailers in your category successfully raised prices during inflation"
        
        elif "cost" in title.lower():
            if profile.company_size_eur > 1_000_000:
                return "Companies your size reduced OpEx by 15-20% through lean initiatives"
        
        return None


def personalize_list_recommendations(
    recommendations: List[Dict],
    profile: EntrepreneurProfile,
    tone: TonePersonalization,
) -> List[PersonalizedRecommendation]:
    """Personalize a list of recommendations"""
    
    personalized = []
    
    for rec in recommendations:
        personalized.append(
            PersonalizationEngine.personalize_recommendation(
                title=rec.get("title", ""),
                description=rec.get("description", ""),
                expected_impact_eur=rec.get("impact_eur", 0),
                risk_level=rec.get("risk_level", "medium"),
                profile=profile,
                tone=tone,
            )
        )
    
    return personalized
