# -*- coding: utf-8 -*-
"""
CFO Diagnosis Engine - Interpreta KPI e genera report strategico
autore: CFO AI
"""
from __future__ import annotations

from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, asdict

from core.schemas import KPI
from utils.math_utils import safe_div

__all__ = [
    "DiagnosisReport",
    "DiagnosisScorecard",
    "CFODiagnosisEngine",
    "diagnose",
]


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class DiagnosisScorecard:
    """Scorecard con score per area (0-1)"""
    marginalita: float  # Gross margin %
    profittabilita: float  # Net margin %
    efficienza_capitale: float  # ROI, asset turnover
    disciplina_cassa: float  # CCC, working capital
    acquisizione_clienti: float  # CAC, conversion rate
    retention_clienti: float  # Churn rate, LTV/CAC
    espansione_base: float  # NRR, MRR growth

    def to_dict(self) -> Dict[str, float]:
        return asdict(self)

    def media(self) -> float:
        values = [
            self.marginalita,
            self.profittabilita,
            self.efficienza_capitale,
            self.disciplina_cassa,
            self.acquisizione_clienti,
            self.retention_clienti,
            self.espansione_base,
        ]
        return sum(values) / len(values) if values else 0.0


@dataclass
class DiagnosisReport:
    """Report diagnostico completo"""
    verdict: str  # "HEALTHY", "ATTENZIONE", "CRITICO"
    spiegazione: str
    scorecard: DiagnosisScorecard
    aree_forti: List[str]
    aree_deboli: List[str]
    bottleneck: str  # Il vero collo di bottiglia
    azione_1: str
    azione_2: str
    azione_3: str
    metriche_chiave: Dict[str, str]  # Per visualizzazione

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.verdict,
            "spiegazione": self.spiegazione,
            "scorecard": self.scorecard.to_dict(),
            "aree_forti": self.aree_forti,
            "aree_deboli": self.aree_deboli,
            "bottleneck": self.bottleneck,
            "azioni_prioritarie": [self.azione_1, self.azione_2, self.azione_3],
            "metriche_chiave": self.metriche_chiave,
        }


# =============================================================================
# Helpers
# =============================================================================

def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, _asf(x, 0.0)))


def _fmt_eur(x: float) -> str:
    try:
        v = float(x)
    except Exception:
        return "-"
    sign = "-" if v < 0 else ""
    v = abs(v)

    if v >= 1_000_000_000:
        return f"{sign}{v/1_000_000_000:.2f}M€"
    if v >= 1_000_000:
        return f"{sign}{v/1_000_000:.2f}M€"
    if v >= 1_000:
        return f"{sign}{v/1_000:.1f}k€"
    return f"{sign}€{v:,.0f}".replace(",", ".")


def _fmt_pct(x: float) -> str:
    try:
        return f"{float(x)*100:.1f}%"
    except Exception:
        return "-"


# =============================================================================
# Scoring Functions
# =============================================================================

def _score_marginalita(kpi: KPI) -> float:
    """
    Gross margin health
    Target: >50% per B2B, >70% per SaaS, >35-40% per manifattura
    """
    gmr = _asf(getattr(kpi, "gross_margin_rate", 0.0), 0.0)
    
    # Normalizza a score 0-1
    if gmr >= 0.50:
        return 1.0
    elif gmr >= 0.35:
        return 0.85
    elif gmr >= 0.25:
        return 0.60
    else:
        return 0.30


def _score_profittabilita(kpi: KPI) -> float:
    """
    Net margin health
    Target: >20% eccellente, >15% buono, >10% ok, <10% margine
    """
    nmr = _asf(getattr(kpi, "net_margin_rate", 0.0), 0.0)
    
    if nmr >= 0.25:
        return 1.0
    elif nmr >= 0.20:
        return 0.95
    elif nmr >= 0.15:
        return 0.85
    elif nmr >= 0.10:
        return 0.70
    elif nmr >= 0.05:
        return 0.45
    else:
        return 0.20


def _score_efficienza_capitale(kpi: KPI) -> float:
    """
    ROI + Capital Turnover
    Target ROI: >30% eccellente, >20% buono, >10% ok, <10% lento
    """
    roi = _asf(getattr(kpi, "roi", 0.0), 0.0)
    investimenti = _asf(getattr(kpi, "investimenti", 0.0), 0.0)
    
    # Se non ci sono investimenti, score neutro
    if investimenti <= 0:
        return 0.65
    
    if roi >= 0.30:
        return 1.0
    elif roi >= 0.20:
        return 0.90
    elif roi >= 0.10:
        return 0.75
    elif roi >= 0.05:
        return 0.50
    else:
        return 0.25


def _score_disciplina_cassa(kpi: KPI) -> float:
    """
    Cash Conversion Cycle (CCC)
    Basso = buono (meno giorni di cash bloccato)
    Target: <30 giorni eccellente, <45 buono, <60 ok, >90 critico
    """
    ccc = _asf(getattr(kpi, "ccc", 0.0), 0.0)
    
    if ccc <= 30:
        return 1.0
    elif ccc <= 45:
        return 0.90
    elif ccc <= 60:
        return 0.75
    elif ccc <= 90:
        return 0.50
    else:
        return 0.25


def _score_acquisizione_clienti(kpi: KPI) -> float:
    """
    CAC efficiency
    Basato su CAC, conversion, traffic quality
    Senza dati specifici, inferisce da operatività
    """
    cac = _asf(getattr(kpi, "cac", 0.0), 0.0)
    fatturato = _asf(getattr(kpi, "fatturato", 0.0), 0.0)
    
    # Se CAC è 0 o fatturato è basso, ritorna score neutro
    if fatturato <= 0:
        return 0.65
    
    # Ratio CAC/Fatturato (idealmente <5% del fatturato)
    cac_ratio = safe_div(cac, fatturato, 0.0)
    
    if cac_ratio <= 0.02:
        return 1.0
    elif cac_ratio <= 0.05:
        return 0.85
    elif cac_ratio <= 0.10:
        return 0.65
    else:
        return 0.40


def _score_retention_clienti(kpi: KPI) -> float:
    """
    Retention health (churn, LTV/CAC ratio)
    """
    churn = _asf(getattr(kpi, "churn_rate", 0.0), 0.0)
    ltv = _asf(getattr(kpi, "ltv", 0.0), 0.0)
    cac = _asf(getattr(kpi, "cac", 0.0), 0.0)
    
    # Se non ci sono dati, ritorna score neutro
    if churn == 0 and ltv == 0:
        return 0.65
    
    # LTV/CAC ratio (target >3)
    ltv_cac_ratio = safe_div(ltv, cac, 0.0) if cac > 0 else 0.0
    
    # Churn (target <5%, ok <10%)
    churn_score = max(0.0, min(1.0, 1.0 - (churn * 10)))
    ltv_score = 1.0 if ltv_cac_ratio >= 3.0 else 0.6 if ltv_cac_ratio >= 1.5 else 0.3
    
    return (churn_score + ltv_score) / 2


def _score_espansione_base(kpi: KPI) -> float:
    """
    Expansion health (NRR, MRR growth, cross-sell)
    """
    nrr = _asf(getattr(kpi, "nrr", 0.0), 0.0)
    mrr = _asf(getattr(kpi, "mrr", 0.0), 0.0)
    
    # Se non ci sono dati, ritorna score neutro
    if nrr == 0 and mrr == 0:
        return 0.65
    
    # NRR >100% = espansione, >110% = ottimo
    if nrr >= 1.10:
        return 1.0
    elif nrr >= 1.00:
        return 0.85
    elif nrr >= 0.90:
        return 0.60
    else:
        return 0.30


# =============================================================================
# Diagnosis Logic
# =============================================================================

class CFODiagnosisEngine:
    """
    Analizza KPI e genera report strategico con:
    - Scorecard per area
    - Verdict su salute aziendale
    - Identificazione bottleneck
    - Top 3 azioni prioritarie
    """

    def diagnose(self, kpi: KPI) -> DiagnosisReport:
        """Genera report diagnostico completo"""
        
        # 1. Calcola scorecard
        scorecard = DiagnosisScorecard(
            marginalita=_score_marginalita(kpi),
            profittabilita=_score_profittabilita(kpi),
            efficienza_capitale=_score_efficienza_capitale(kpi),
            disciplina_cassa=_score_disciplina_cassa(kpi),
            acquisizione_clienti=_score_acquisizione_clienti(kpi),
            retention_clienti=_score_retention_clienti(kpi),
            espansione_base=_score_espansione_base(kpi),
        )
        
        # 2. Identifica aree forti e deboli
        aree_forti, aree_deboli = self._classify_areas(scorecard)
        
        # 3. Determina verdict
        media_score = scorecard.media()
        if media_score >= 0.80:
            verdict = "HEALTHY"
        elif media_score >= 0.60:
            verdict = "ATTENZIONE"
        else:
            verdict = "CRITICO"
        
        # 4. Identifica bottleneck reale
        bottleneck = self._identify_bottleneck(scorecard, kpi)
        
        # 5. Genera azioni prioritarie
        azioni = self._generate_actions(scorecard, kpi, bottleneck)
        
        # 6. Spiegazione
        spiegazione = self._generate_explanation(verdict, scorecard, bottleneck)
        
        # 7. Metriche chiave per dashboard
        metriche_chiave = self._extract_key_metrics(kpi, scorecard)
        
        return DiagnosisReport(
            verdict=verdict,
            spiegazione=spiegazione,
            scorecard=scorecard,
            aree_forti=aree_forti,
            aree_deboli=aree_deboli,
            bottleneck=bottleneck,
            azione_1=azioni[0],
            azione_2=azioni[1],
            azione_3=azioni[2],
            metriche_chiave=metriche_chiave,
        )

    def _classify_areas(self, scorecard: DiagnosisScorecard) -> Tuple[List[str], List[str]]:
        """Classifica aree forti (>0.85) e deboli (<0.65)"""
        aree = {
            "Marginalità": scorecard.marginalita,
            "Profittabilità": scorecard.profittabilita,
            "Efficienza Capitale": scorecard.efficienza_capitale,
            "Disciplina di Cassa": scorecard.disciplina_cassa,
            "Acquisizione Clienti": scorecard.acquisizione_clienti,
            "Retention Clienti": scorecard.retention_clienti,
            "Espansione Base": scorecard.espansione_base,
        }
        
        forti = [k for k, v in aree.items() if v >= 0.85]
        deboli = [k for k, v in aree.items() if v < 0.65]
        
        return forti, deboli

    def _identify_bottleneck(self, scorecard: DiagnosisScorecard, kpi: KPI) -> str:
        """
        Identifica il VERO collo di bottiglia
        (area con score più basso, che impatta di più)
        """
        aree = {
            "Marginalità lorda": scorecard.marginalita,
            "Profittabilità netta": scorecard.profittabilita,
            "Efficienza del capitale": scorecard.efficienza_capitale,
            "Disciplina di cassa": scorecard.disciplina_cassa,
            "Acquisizione clienti": scorecard.acquisizione_clienti,
            "Retention clienti": scorecard.retention_clienti,
            "Espansione base clienti": scorecard.espansione_base,
        }
        
        bottleneck_name = min(aree.items(), key=lambda x: x[1])[0]
        return bottleneck_name

    def _generate_actions(
        self,
        scorecard: DiagnosisScorecard,
        kpi: KPI,
        bottleneck: str,
    ) -> List[str]:
        """Genera top 3 azioni prioritarie"""
        
        fatturato = _asf(getattr(kpi, "fatturato", 0.0), 0.0)
        utile = _asf(getattr(kpi, "utile", 0.0), 0.0)
        ccc = _asf(getattr(kpi, "ccc", 0.0), 0.0)
        roi = _asf(getattr(kpi, "roi", 0.0), 0.0)
        
        azioni_candidate = []
        
        # Azione 1: Sul bottleneck
        if "Marginalità" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Alzare margine lordo - valutare incremento prezzi (+2-3%), "
                f"negoziazione fornitori, mix prodotti"
            )
        elif "Profittabilità" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Migliorare profitto netto - ridurre costi fissi, "
                f"eliminare attività non-core, ottimizzare headcount"
            )
        elif "Efficienza" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Aumentare ROI capitale - reallocate investimenti verso "
                f"progetti >25% ROI, divestire asset a basso rendimento"
            )
        elif "Disciplina" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Accelerare ciclo di cassa - ridurre DSO (incassi) a {max(15, ccc/2):.0f}gg, "
                f"negoziare DPO con fornitori, ottimizzare inventory"
            )
        elif "Acquisizione" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Migliorare CAC - testare nuovi canali acquisition, "
                f"aumentare conversion sales, ridurre CAC di 15-20%"
            )
        elif "Retention" in bottleneck:
            azioni_candidate.append(
                f"🎯 PRIMARIO: Aumentare retention - implementare programma customer success, "
                f"ridurre churn di 5-10%, aumentare NPS"
            )
        else:  # Espansione
            azioni_candidate.append(
                f"🎯 PRIMARIO: Espandere base clienti - cross-sell, upsell, "
                f"aumentare NRR >110%, implementare expansion revenue"
            )
        
        # Azione 2: Sulla seconda area più debole
        aree_sortedate = sorted(
            [
                ("Marginalità", scorecard.marginalita),
                ("Profittabilità", scorecard.profittabilita),
                ("Efficienza", scorecard.efficienza_capitale),
                ("Cassa", scorecard.disciplina_cassa),
                ("Acquisizione", scorecard.acquisizione_clienti),
                ("Retention", scorecard.retention_clienti),
                ("Espansione", scorecard.espansione_base),
            ],
            key=lambda x: x[1],
        )
        
        area2 = aree_sortedate[1][0] if len(aree_sortedate) > 1 else "Operatività"
        azioni_candidate.append(
            f"📊 SECONDARIO: Monitorare {area2} - "
            f"implementare dashboard real-time, alert su KPI critici"
        )
        
        # Azione 3: Azione trasversale (data/processo)
        azioni_candidate.append(
            f"🔄 SISTEMA: Implementare planning mensile - forecast 12 mesi, "
            f"scenario analysis (pessimista/realista/ottimista), aggiornare KPI"
        )
        
        return azioni_candidate[:3]

    def _generate_explanation(
        self,
        verdict: str,
        scorecard: DiagnosisScorecard,
        bottleneck: str,
    ) -> str:
        """Genera spiegazione narrata del verdict"""
        
        media = scorecard.media()
        
        if verdict == "HEALTHY":
            return (
                f"Azienda in buona salute (score {media:.0%}). "
                f"Fondamentali solidi su margini e profitto. "
                f"Focus: mantenere slancio e perseguire crescita profittevole. "
                f"Monitorare {bottleneck} per mantenere vantaggio competitivo."
            )
        elif verdict == "ATTENZIONE":
            return (
                f"Azienda in fase di consolidamento (score {media:.0%}). "
                f"Fondamentali acceptable ma margini e/o profitto sotto ottimale. "
                f"Collo di bottiglia rilevato: {bottleneck}. "
                f"Richiede intervento tattico nei prossimi 60-90 giorni per evitare deterioramento."
            )
        else:  # CRITICO
            return (
                f"Azienda in stress (score {media:.0%}). "
                f"Uno o più KPI critici. Collo di bottiglia principale: {bottleneck}. "
                f"Richiede intervento strategico immediato (30 giorni). "
                f"Priorità: stabilizzare cash flow e profittabilità."
            )

    def _extract_key_metrics(
        self,
        kpi: KPI,
        scorecard: DiagnosisScorecard,
    ) -> Dict[str, str]:
        """Estrae metriche chiave per visualizzazione dashboard"""
        
        fatturato = _asf(getattr(kpi, "fatturato", 0.0), 0.0)
        utile = _asf(getattr(kpi, "utile", 0.0), 0.0)
        gmr = _asf(getattr(kpi, "gross_margin_rate", 0.0), 0.0)
        nmr = _asf(getattr(kpi, "net_margin_rate", 0.0), 0.0)
        ccc = _asf(getattr(kpi, "ccc", 0.0), 0.0)
        roi = _asf(getattr(kpi, "roi", 0.0), 0.0)
        break_even = _asf(getattr(kpi, "break_even", 0.0), 0.0)
        
        return {
            "fatturato": _fmt_eur(fatturato),
            "utile_netto": _fmt_eur(utile),
            "margine_lordo": _fmt_pct(gmr),
            "margine_netto": _fmt_pct(nmr),
            "roi": _fmt_pct(roi),
            "ccc_giorni": f"{ccc:.0f} giorni",
            "break_even": _fmt_eur(break_even),
            "score_salute": f"{scorecard.media():.0%}",
        }


def diagnose(kpi: KPI) -> DiagnosisReport:
    """Wrapper pubblico per diagnosis"""
    return CFODiagnosisEngine().diagnose(kpi)
