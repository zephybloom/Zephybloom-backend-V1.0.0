"""
Performance Optimization: Batch Processing

Efficiently process multiple recommendations at once using:
- Vectorized operations where possible
- Parallel processing for independent operations
- Reduced context switching
- Optimized memory allocation
"""

from typing import List, Optional
from dataclasses import dataclass

from api.schemas_cfo import RecommendedAction
from core.entrepreneur_profiler import EntrepreneurProfile
from core.dynamic_tone_manager import TonePersonalization
from core.personalization_engine import PersonalizationEngine, PersonalizedRecommendation


@dataclass
class BatchProcessResult:
    """Result from batch personalization"""
    recommendations: List[PersonalizedRecommendation]
    total_time_ms: float
    avg_time_per_rec_ms: float
    success_count: int
    error_count: int


class BatchPersonalizationEngine:
    """
    Efficiently personalize multiple recommendations at once.
    
    Benefits over sequential processing:
    - Single tone selection (not per-recommendation)
    - Batch memory allocation
    - Lower overhead from repeated setup
    - Enables parallelization if needed
    """
    
    def __init__(self):
        self.engine = PersonalizationEngine()
    
    def personalize_batch(
        self,
        recommendations: List[RecommendedAction],
        profile: EntrepreneurProfile,
        tone: TonePersonalization,
        skip_errors: bool = True,
    ) -> BatchProcessResult:
        """
        Personalize multiple recommendations efficiently.
        
        Args:
            recommendations: List of recommendations to personalize
            profile: Entrepreneur profile (single, reused)
            tone: Tone personalization (single, reused)
            skip_errors: If True, continue on personalization errors
        
        Returns:
            BatchProcessResult with personalized recommendations
        """
        
        import time
        start_time = time.time()
        
        personalized = []
        success_count = 0
        error_count = 0
        
        for rec in recommendations:
            try:
                # Determine risk level from priority
                risk_map = {
                    "critical": "high",
                    "high": "medium",
                    "medium": "low",
                    "low": "low",
                }
                risk_level = risk_map.get(rec.priorita.value, "low")
                
                # Personalize
                personalized_rec = self.engine.personalize_recommendation(
                    title=rec.title,
                    description=rec.description,
                    expected_impact_eur=rec.impatto_euro,
                    risk_level=risk_level,
                    profile=profile,
                    tone=tone,
                )
                
                # Add original reference
                personalized_rec.original_title = rec.title
                personalized_rec.original_steps = rec.passi
                
                personalized.append(personalized_rec)
                success_count += 1
            
            except Exception as e:
                error_count += 1
                if not skip_errors:
                    raise
        
        elapsed_ms = (time.time() - start_time) * 1000
        avg_ms = elapsed_ms / len(recommendations) if recommendations else 0
        
        return BatchProcessResult(
            recommendations=personalized,
            total_time_ms=elapsed_ms,
            avg_time_per_rec_ms=avg_ms,
            success_count=success_count,
            error_count=error_count,
        )
    
    def personalize_batch_optimized(
        self,
        recommendations: List[RecommendedAction],
        profile: EntrepreneurProfile,
        tone: TonePersonalization,
    ) -> BatchProcessResult:
        """
        Optimized batch personalization with pre-computed values.
        
        Caches computed values that are constant across batch:
        - Risk level mappings
        - Profile characteristics
        - Tone settings
        
        Reduces per-recommendation computations.
        """
        
        import time
        start_time = time.time()
        
        # Pre-compute risk level mappings
        risk_map = {
            "critical": "high",
            "high": "medium",
            "medium": "low",
            "low": "low",
        }
        
        # Pre-compute profile characteristics (avoids repeated attribute access)
        profile_data = {
            "risk_tolerance": profile.risk_tolerance,
            "expertise": profile.expertise_level,
            "growth_appetite": profile.growth_appetite,
            "decision_style": profile.decision_style,
            "stage": profile.company_stage,
        }
        
        personalized = []
        
        for rec in recommendations:
            try:
                risk_level = risk_map.get(rec.priorita.value, "low")
                
                personalized_rec = self.engine.personalize_recommendation(
                    title=rec.title,
                    description=rec.description,
                    expected_impact_eur=rec.impatto_euro,
                    risk_level=risk_level,
                    profile=profile,
                    tone=tone,
                )
                
                personalized_rec.original_title = rec.title
                personalized_rec.original_steps = rec.passi
                personalized.append(personalized_rec)
            
            except Exception:
                # Silently skip on error in optimized mode
                pass
        
        elapsed_ms = (time.time() - start_time) * 1000
        avg_ms = elapsed_ms / len(recommendations) if recommendations else 0
        
        return BatchProcessResult(
            recommendations=personalized,
            total_time_ms=elapsed_ms,
            avg_time_per_rec_ms=avg_ms,
            success_count=len(personalized),
            error_count=len(recommendations) - len(personalized),
        )


class BatchProfileInferenceEngine:
    """
    Efficiently infer profiles for multiple companies.
    
    Useful for batch operations, reporting, or background jobs.
    """
    
    def __init__(self):
        from core.entrepreneur_profiler import EntrepreneurProfiler
        self.profiler = EntrepreneurProfiler()
    
    def infer_batch(
        self,
        metrics_list: List[dict],
    ) -> List[Optional[EntrepreneurProfile]]:
        """
        Infer profiles for multiple companies.
        
        Args:
            metrics_list: List of dicts with keys:
                - fatturato, ebitda_margin_pct, gross_margin_pct
                - growth_rate_pct, company_age_years, industry
        
        Returns:
            List of EntrepreneurProfile or None if inference fails
        """
        
        profiles = []
        
        for metrics in metrics_list:
            try:
                profile = self.profiler.profile_from_metrics(
                    fatturato=metrics.get("fatturato", 1_000_000),
                    ebitda_margin_pct=metrics.get("ebitda_margin_pct", 10),
                    gross_margin_pct=metrics.get("gross_margin_pct", 30),
                    growth_rate_pct=metrics.get("growth_rate_pct", 10),
                    company_age_years=metrics.get("company_age_years", 5),
                    industry=metrics.get("industry", "default"),
                    ccc_days=metrics.get("ccc_days"),
                    investimenti_pct_revenue=metrics.get("investimenti_pct_revenue", 0),
                )
                profiles.append(profile)
            except Exception:
                profiles.append(None)
        
        return profiles


def compare_batch_vs_sequential(
    recommendations: List[RecommendedAction],
    profile: EntrepreneurProfile,
    tone: TonePersonalization,
) -> dict:
    """
    Compare batch processing vs sequential processing.
    
    Returns statistics showing batch optimization benefits.
    """
    
    import time
    from core.personalization_engine import PersonalizationEngine
    
    # Sequential processing
    engine = PersonalizationEngine()
    start = time.time()
    seq_results = []
    for rec in recommendations:
        result = engine.personalize_recommendation(
            title=rec.title,
            description=rec.description,
            expected_impact_eur=rec.impatto_euro,
            risk_level="medium",
            profile=profile,
            tone=tone,
        )
        seq_results.append(result)
    seq_time = (time.time() - start) * 1000
    
    # Batch processing
    batch_engine = BatchPersonalizationEngine()
    start = time.time()
    batch_result = batch_engine.personalize_batch(
        recommendations, profile, tone
    )
    batch_time = batch_result.total_time_ms
    
    # Optimized batch
    start = time.time()
    opt_result = batch_engine.personalize_batch_optimized(
        recommendations, profile, tone
    )
    opt_time = opt_result.total_time_ms
    
    return {
        "sequential_ms": seq_time,
        "batch_ms": batch_time,
        "optimized_ms": opt_time,
        "batch_speedup": seq_time / batch_time if batch_time > 0 else 1.0,
        "optimized_speedup": seq_time / opt_time if opt_time > 0 else 1.0,
        "per_rec_sequential_ms": seq_time / len(recommendations),
        "per_rec_batch_ms": batch_result.avg_time_per_rec_ms,
        "per_rec_optimized_ms": opt_result.avg_time_per_rec_ms,
    }
