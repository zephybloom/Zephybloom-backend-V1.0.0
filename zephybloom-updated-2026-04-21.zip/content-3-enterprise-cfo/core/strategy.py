"""
CFO Strategy Engine - Multi-framework strategic analysis for enterprise

Frameworks:
1. Porter 5 Forces - Competitive intensity analysis
2. Ansoff Matrix - Growth strategy options
3. Balanced Scorecard - KPI framework (Financial, Customer, Internal, Learning)
4. Value Chain - Where value is created vs cost

Generates strategic recommendations and 3-5 year roadmap
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import date, timedelta


# ============================================
# DATA MODELS - PORTER 5 FORCES
# ============================================

class PorterForce(str, Enum):
    """Porter 5 Forces"""
    THREAT_OF_NEW_ENTRANTS = "threat_of_new_entrants"
    BARGAINING_POWER_OF_SUPPLIERS = "bargaining_power_suppliers"
    BARGAINING_POWER_OF_BUYERS = "bargaining_power_buyers"
    THREAT_OF_SUBSTITUTES = "threat_of_substitutes"
    COMPETITIVE_RIVALRY = "competitive_rivalry"


@dataclass
class PorterForceAnalysis:
    """Single force analysis"""
    force: PorterForce
    intensity_score: float  # 0-10 (0=low threat, 10=high threat)
    drivers: List[str]  # Why is this intense/weak?
    implications: str  # What it means for strategy
    recommendations: List[str]  # What to do about it


@dataclass
class Porter5Analysis:
    """Complete Porter 5 Forces analysis"""
    forces: List[PorterForceAnalysis]
    overall_attractiveness_score: float  # 0-10 (10=very attractive market)
    industry_verdict: str  # "Attractive", "Moderate", "Challenging", "Hostile"
    strategic_implication: str  # What this means for the company


# ============================================
# DATA MODELS - ANSOFF MATRIX
# ============================================

class AnsoffStrategy(str, Enum):
    """Ansoff matrix quadrants"""
    MARKET_PENETRATION = "market_penetration"  # Sell more to existing customers
    PRODUCT_DEVELOPMENT = "product_development"  # New products to existing markets
    MARKET_DEVELOPMENT = "market_development"  # New markets with existing products
    DIVERSIFICATION = "diversification"  # New products to new markets


@dataclass
class AnsoffOption:
    """Single growth strategy option"""
    strategy: AnsoffStrategy
    description: str  # What is it?
    market_opportunity: str  # TAM, accessible market
    risk_level: str  # "Low", "Medium", "High"
    investment_required: str  # "Low", "Medium", "High"
    timeline_months: int  # How long to execute
    expected_revenue_impact_pct: float  # Impact on revenue in first 2-3 years
    success_factors: List[str]  # What's needed to succeed
    example_actions: List[str]  # Concrete what to do


@dataclass
class AnsoffAnalysis:
    """Complete Ansoff matrix analysis"""
    current_position: AnsoffStrategy  # Where are you now
    options: List[AnsoffOption]  # All 4 quadrants analyzed
    recommended_priority: List[AnsoffStrategy]  # Order of pursuit
    rationale: str  # Why this order


# ============================================
# DATA MODELS - BALANCED SCORECARD
# ============================================

class ScoreCardPerspective(str, Enum):
    """BSC perspectives"""
    FINANCIAL = "financial"
    CUSTOMER = "customer"
    INTERNAL_PROCESS = "internal_process"
    LEARNING_GROWTH = "learning_growth"


@dataclass
class BalancedScoreCardMetric:
    """Single BSC metric"""
    perspective: ScoreCardPerspective
    metric_name: str  # e.g., "Revenue Growth", "Customer Satisfaction"
    baseline_value: float  # Current value
    target_value: float  # Target in 1-3 years
    unit: str  # %, EUR, NPS, days, etc
    initiative: str  # What initiative drives this?
    owner: Optional[str] = None  # Who is responsible


@dataclass
class BalancedScorecard:
    """Complete balanced scorecard"""
    metrics: List[BalancedScoreCardMetric]
    financial_metrics: List[BalancedScoreCardMetric]
    customer_metrics: List[BalancedScoreCardMetric]
    internal_metrics: List[BalancedScoreCardMetric]
    learning_metrics: List[BalancedScoreCardMetric]


# ============================================
# STRATEGY ENGINE
# ============================================

class StrategyEngine:
    """Analyze and recommend strategy"""
    
    @staticmethod
    def analyze_porter_5(
        sector: str,
        your_market_position: str,  # "Incumbent", "Challenger", "Niche", "Startup"
        revenue_size: float,  # EUR
        competitive_context: Optional[Dict] = None,
    ) -> Porter5Analysis:
        """
        Analyze Porter 5 Forces
        
        Args:
            sector: Industry sector
            market_position: Your position in market
            revenue_size: Your revenue (for context)
            competitive_context: Optional dict with market data
        
        Returns:
            Complete 5 Forces analysis
        """
        
        forces_analysis = []
        
        # FORCE 1: Threat of New Entrants
        barriers_to_entry = _assess_barriers_to_entry(sector, revenue_size)
        forces_analysis.append(PorterForceAnalysis(
            force=PorterForce.THREAT_OF_NEW_ENTRANTS,
            intensity_score=barriers_to_entry["threat_score"],
            drivers=barriers_to_entry["drivers"],
            implications=barriers_to_entry["implications"],
            recommendations=barriers_to_entry["recommendations"],
        ))
        
        # FORCE 2: Bargaining Power of Suppliers
        supplier_power = _assess_supplier_power(sector)
        forces_analysis.append(PorterForceAnalysis(
            force=PorterForce.BARGAINING_POWER_OF_SUPPLIERS,
            intensity_score=supplier_power["threat_score"],
            drivers=supplier_power["drivers"],
            implications=supplier_power["implications"],
            recommendations=supplier_power["recommendations"],
        ))
        
        # FORCE 3: Bargaining Power of Buyers
        buyer_power = _assess_buyer_power(sector, your_market_position)
        forces_analysis.append(PorterForceAnalysis(
            force=PorterForce.BARGAINING_POWER_OF_BUYERS,
            intensity_score=buyer_power["threat_score"],
            drivers=buyer_power["drivers"],
            implications=buyer_power["implications"],
            recommendations=buyer_power["recommendations"],
        ))
        
        # FORCE 4: Threat of Substitutes
        substitute_threat = _assess_substitute_threat(sector)
        forces_analysis.append(PorterForceAnalysis(
            force=PorterForce.THREAT_OF_SUBSTITUTES,
            intensity_score=substitute_threat["threat_score"],
            drivers=substitute_threat["drivers"],
            implications=substitute_threat["implications"],
            recommendations=substitute_threat["recommendations"],
        ))
        
        # FORCE 5: Competitive Rivalry
        rivalry = _assess_competitive_rivalry(sector, your_market_position)
        forces_analysis.append(PorterForceAnalysis(
            force=PorterForce.COMPETITIVE_RIVALRY,
            intensity_score=rivalry["threat_score"],
            drivers=rivalry["drivers"],
            implications=rivalry["implications"],
            recommendations=rivalry["recommendations"],
        ))
        
        # Calculate overall attractiveness
        avg_threat = sum(f.intensity_score for f in forces_analysis) / 5
        overall_score = 10 - avg_threat  # Higher is more attractive
        
        if overall_score >= 7:
            verdict = "Attractive - Market is favorable"
        elif overall_score >= 5:
            verdict = "Moderate - Mixed competitive dynamics"
        elif overall_score >= 3:
            verdict = "Challenging - High competitive pressure"
        else:
            verdict = "Hostile - Consider niche/exit strategy"
        
        return Porter5Analysis(
            forces=forces_analysis,
            overall_attractiveness_score=round(overall_score, 1),
            industry_verdict=verdict,
            strategic_implication=_derive_strategy_from_porter(forces_analysis),
        )
    
    @staticmethod
    def analyze_ansoff(
        revenue: float,
        gross_margin_pct: float,
        growth_rate_pct: float,
        market_position: str,
        product_portfolio_count: int,
        geographic_footprint: List[str],
    ) -> AnsoffAnalysis:
        """
        Ansoff matrix analysis: 4 growth strategies
        
        Args:
            revenue: Current revenue
            gross_margin_pct: Current gross margin
            growth_rate_pct: Current YoY growth
            market_position: "Incumbent", "Challenger", "Niche", "Startup"
            product_portfolio_count: Number of products/services
            geographic_footprint: List of geographies served
        
        Returns:
            AnsoffAnalysis with all 4 quadrants
        """
        
        options = []
        
        # QUADRANT 1: Market Penetration (existing product, existing market)
        options.append(AnsoffOption(
            strategy=AnsoffStrategy.MARKET_PENETRATION,
            description="Grow market share by selling more of existing products to current market",
            market_opportunity="Accessible: you know this market already",
            risk_level="Low",
            investment_required="Medium",
            timeline_months=6,
            expected_revenue_impact_pct=15.0,  # Conservative 15% growth possible
            success_factors=[
                "Aggressive sales & marketing",
                "Price optimization",
                "Improve conversion rates",
                "Expand distribution channels"
            ],
            example_actions=[
                "Increase marketing spend by 30-50%",
                "Hire 2-3x sales team",
                "Launch partnership/channel programs",
                "Optimize pricing on low-penetration segments"
            ],
        ))
        
        # QUADRANT 2: Product Development (new product, existing market)
        options.append(AnsoffOption(
            strategy=AnsoffStrategy.PRODUCT_DEVELOPMENT,
            description="Develop new products/services for customers you already serve",
            market_opportunity="Medium: existing customer base reduces go-to-market friction",
            risk_level="Medium",
            investment_required="Medium",
            timeline_months=12,
            expected_revenue_impact_pct=25.0,
            success_factors=[
                "R&D capability of team",
                "Customer validation",
                "Production/delivery scalability",
                "Sales readiness"
            ],
            example_actions=[
                "Interview customers on unmet needs",
                "Run MVP/pilot with 10-20 key customers",
                "Allocate R&D budget (10-15% of revenue)",
                "Cross-sell new product to existing base"
            ],
        ))
        
        # QUADRANT 3: Market Development (existing product, new market)
        options.append(AnsoffOption(
            strategy=AnsoffStrategy.MARKET_DEVELOPMENT,
            description="Enter new markets/geographies with products you already sell",
            market_opportunity="Medium-High: product is proven, new TAM",
            risk_level="Medium",
            investment_required="High",
            timeline_months=18,
            expected_revenue_impact_pct=30.0,
            success_factors=[
                "Market research & local partnerships",
                "Localization (language, compliance, sales model)",
                "Distribution network setup",
                "Capital for expansion"
            ],
            example_actions=[
                "Select 1-2 adjacent geographies with high demand",
                "Partner with local distributor/reseller",
                "Adapt product for local needs",
                "Hire local sales/support team"
            ],
        ))
        
        # QUADRANT 4: Diversification (new product, new market) - Highest risk
        options.append(AnsoffOption(
            strategy=AnsoffStrategy.DIVERSIFICATION,
            description="Enter entirely new markets with new products",
            market_opportunity="Unknown: highest risk/reward",
            risk_level="High",
            investment_required="High",
            timeline_months=24,
            expected_revenue_impact_pct=40.0,  # If it works
            success_factors=[
                "Core competency transfer",
                "Significant capital",
                "Experienced new market team",
                "Patience (3-5 year horizon)"
            ],
            example_actions=[
                "Identify adjacey with transferable capabilities",
                "Acquire or partner with domain expert",
                "Run dedicated business unit",
                "Plan for 3-5 year breakeven"
            ],
        ))
        
        # Determine recommended priority based on company profile
        recommended_priority = _prioritize_ansoff_strategies(
            market_position=market_position,
            growth_rate=growth_rate_pct,
            margin=gross_margin_pct,
        )
        
        return AnsoffAnalysis(
            current_position=AnsoffStrategy.MARKET_PENETRATION,  # Assume current
            options=options,
            recommended_priority=recommended_priority,
            rationale=_create_ansoff_rationale(recommended_priority, market_position),
        )
    
    @staticmethod
    def build_balanced_scorecard(
        revenue: float,
        net_margin_pct: float,
        employee_count: int,
        nps_score: Optional[float] = None,
        customer_churn_pct: Optional[float] = None,
    ) -> BalancedScorecard:
        """
        Build balanced scorecard with targets for 3-year horizon
        
        Returns:
            BalancedScorecard with metrics across 4 perspectives
        """
        
        all_metrics = []
        
        # FINANCIAL PERSPECTIVE (strategic objectives)
        financial_metrics = [
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.FINANCIAL,
                metric_name="Revenue Growth",
                baseline_value=revenue,
                target_value=revenue * 1.8,  # 3-year: 80% growth
                unit="EUR",
                initiative="Market penetration + Product development",
                owner="CEO/CFO",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.FINANCIAL,
                metric_name="Net Margin %",
                baseline_value=net_margin_pct,
                target_value=min(net_margin_pct * 1.3, 25.0),  # Improve margin but realistic
                unit="%",
                initiative="Operational excellence + Pricing optimization",
                owner="CFO/COO",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.FINANCIAL,
                metric_name="ROIC (Return on Invested Capital)",
                baseline_value=18.0,  # Assumed 18%
                target_value=22.0,
                unit="%",
                initiative="Capital allocation discipline",
                owner="CFO",
            ),
        ]
        all_metrics.extend(financial_metrics)
        
        # CUSTOMER PERSPECTIVE
        customer_metrics = [
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.CUSTOMER,
                metric_name="NPS Score",
                baseline_value=nps_score or 45.0,
                target_value=65.0,
                unit="points",
                initiative="Customer success program",
                owner="Chief Customer Officer",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.CUSTOMER,
                metric_name="Customer Retention Rate",
                baseline_value=100 - (customer_churn_pct or 5.0),
                target_value=97.0,
                unit="%",
                initiative="Reduce churn via product improvements",
                owner="VP Customer Success",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.CUSTOMER,
                metric_name="Market Share in Target Segment",
                baseline_value=5.0,
                target_value=12.0,
                unit="%",
                initiative="Competitive differentiation",
                owner="VP Product/Marketing",
            ),
        ]
        all_metrics.extend(customer_metrics)
        
        # INTERNAL PROCESS PERSPECTIVE
        internal_metrics = [
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.INTERNAL_PROCESS,
                metric_name="Time to Market (New Product)",
                baseline_value=12.0,
                target_value=6.0,
                unit="months",
                initiative="Agile/DevOps transformation",
                owner="VP Product/Engineering",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.INTERNAL_PROCESS,
                metric_name="Operational Efficiency Ratio",
                baseline_value=0.65,  # Opex / Revenue
                target_value=0.55,
                unit="ratio",
                initiative="Automation + Process optimization",
                owner="COO",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.INTERNAL_PROCESS,
                metric_name="Product Quality (Defect Rate)",
                baseline_value=2.5,
                target_value=0.5,
                unit="%",
                initiative="QA automation + Testing",
                owner="VP Engineering",
            ),
        ]
        all_metrics.extend(internal_metrics)
        
        # LEARNING & GROWTH PERSPECTIVE
        learning_metrics = [
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.LEARNING_GROWTH,
                metric_name="Employee Engagement Score",
                baseline_value=70.0,
                target_value=80.0,
                unit="NPS-like points",
                initiative="Culture + Career development",
                owner="Chief People Officer",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.LEARNING_GROWTH,
                metric_name="R&D Investment %",
                baseline_value=8.0,
                target_value=12.0,
                unit="% of revenue",
                initiative="Innovation fund setup",
                owner="CTO",
            ),
            BalancedScoreCardMetric(
                perspective=ScoreCardPerspective.LEARNING_GROWTH,
                metric_name="Key Talent Retention Rate",
                baseline_value=90.0,
                target_value=95.0,
                unit="%",
                initiative="Comp review + Equity refresh",
                owner="Chief People Officer",
            ),
        ]
        all_metrics.extend(learning_metrics)
        
        return BalancedScorecard(
            metrics=all_metrics,
            financial_metrics=financial_metrics,
            customer_metrics=customer_metrics,
            internal_metrics=internal_metrics,
            learning_metrics=learning_metrics,
        )


# ============================================
# HELPER FUNCTIONS
# ============================================

def _assess_barriers_to_entry(sector: str, revenue_size: float) -> Dict:
    """Assess barriers to entry for sector"""
    
    # Sector-specific barriers
    barriers_map = {
        "saas": {
            "threat_score": 6.0,  # Moderate - low upfront cost but competitive
            "drivers": [
                "Low barrier to entry (just code + AWS)",
                "High customer acquisition costs (CAC) are real barrier",
                "Network effects in some segments",
                "Talent scarcity in specialized areas"
            ],
            "implications": "New competitors enter regularly; differentiation is key",
            "recommendations": [
                "Invest in customer moat (switching costs, integrations)",
                "Build network effects if possible",
                "Focus on niche/underserved segments",
                "Maintain product innovation speed"
            ],
        },
        "manufacturing": {
            "threat_score": 4.0,  # Low-moderate
            "drivers": [
                "Capital intensity: high entry cost",
                "Economies of scale: advantage to incumbents",
                "Supply chain: takes time to build",
                "Regulatory compliance: permits, certifications"
            ],
            "implications": "Stable competitive set; fewer new entrants",
            "recommendations": [
                "Protect capital intensity as moat",
                "Invest in supply chain efficiency",
                "Build switching costs via customization",
                "Explore niches too small for incumbents"
            ],
        },
        "retail": {
            "threat_score": 7.5,  # High
            "drivers": [
                "Low barrier: can start online/small format",
                "E-commerce disruption: accelerating entry",
                "Private label/DTC: many can copy",
                "Location/rent: only barrier for physical stores"
            ],
            "implications": "Hyper-competitive, constant entry, margin pressure",
            "recommendations": [
                "Build brand/loyalty moat",
                "Obsess on unit economics",
                "Leverage data/personalization",
                "Develop exclusive/proprietary products"
            ],
        },
        "default": {
            "threat_score": 5.0,
            "drivers": ["Market-dependent", "Varies by segment"],
            "implications": "Moderate competitive threat",
            "recommendations": ["Analyze specific competitive dynamics", "Focus on differentiation"],
        },
    }
    
    return barriers_map.get(sector.lower(), barriers_map["default"])


def _assess_supplier_power(sector: str) -> Dict:
    """Assess supplier bargaining power"""
    
    supplier_map = {
        "saas": {
            "threat_score": 4.0,  # Moderate
            "drivers": [
                "Cloud providers (AWS, Azure) are quasi-monopolies",
                "Developer talent: high bargaining power, can leave",
                "Third-party tools: many alternatives available",
                "Content/data: may be critical"
            ],
            "implications": "Cloud costs rising; talent retention critical",
            "recommendations": [
                "Multi-cloud strategy to reduce lock-in",
                "Invest in training/comp for engineers",
                "Build own tools instead of relying on third-party",
                "Data licensing agreements with suppliers"
            ],
        },
        "manufacturing": {
            "threat_score": 6.5,  # High
            "drivers": [
                "Raw material suppliers: concentrated",
                "Component suppliers: often single-source",
                "Logistics: transportation cost inflation",
                "Specialized machines/tools: limited suppliers"
            ],
            "implications": "Margin pressure from supplier costs; supply chain risk",
            "recommendations": [
                "Vertical integration or long-term contracts",
                "Diversify supplier base",
                "Invest in supplier relationships",
                "Automate/reduce material usage"
            ],
        },
        "retail": {
            "threat_score": 5.0,
            "drivers": [
                "Brands/suppliers have direct-to-consumer options",
                "Freight/logistics: variable but critical",
                "Private label reduces supplier power",
                "Multiple sourcing often available"
            ],
            "implications": "Moderate; can shift to imports or alternatives",
            "recommendations": [
                "Private label development",
                "Supplier diversification across geographies",
                "Negotiate volume contracts",
                "Automation in logistics"
            ],
        },
        "default": {
            "threat_score": 5.0,
            "drivers": ["Industry-dependent"],
            "implications": "Assess supplier concentration",
            "recommendations": ["Build alternative sourcing", "Long-term contracts"],
        },
    }
    
    return supplier_map.get(sector.lower(), supplier_map["default"])


def _assess_buyer_power(sector: str, position: str) -> Dict:
    """Assess buyer bargaining power"""
    
    # Higher power = more threatening to your margins
    buyer_map = {
        "saas": {
            "threat_score": 7.0,  # High - customers can switch
            "drivers": [
                "Enterprise customers have leverage (multi-tool evaluation)",
                "Low switching costs (software is easy to replace)",
                "Cloud commoditization",
                "Open source alternatives rising"
            ],
            "implications": "Price pressure; need strong differentiation and switching costs",
            "recommendations": [
                "Build switching costs (integrations, data lock-in)",
                "Increase customer success/stickiness",
                "Create unique value proposition",
                "Vertical/niche focus to reduce buyer alternatives"
            ],
        },
        "manufacturing": {
            "threat_score": 6.0,  # Moderate-high
            "drivers": [
                "Large customers have leverage",
                "However, customization creates stickiness",
                "Supplier alternatives limited",
                "Quality/reliability breed loyalty"
            ],
            "implications": "Moderate margin pressure; quality + service matter",
            "recommendations": [
                "Customization/integration (switching costs)",
                "Long-term contracts",
                "Service/support differentiation",
                "Build brand preference"
            ],
        },
        "retail": {
            "threat_score": 8.0,  # Very high - customers have many options
            "drivers": [
                "Abundant options (online, competitors, private label)",
                "Price transparency (easy to compare)",
                "Low switching costs",
                "Return expectations rising"
            ],
            "implications": "Intense price competition; brand/loyalty critical",
            "recommendations": [
                "Build brand loyalty (emotional connection)",
                "Exclusive products (private label, partnerships)",
                "Omnichannel experience",
                "Personalization/data leverage"
            ],
        },
        "default": {
            "threat_score": 6.0,
            "drivers": ["Customer-dependent"],
            "implications": "Assess your customer concentration",
            "recommendations": ["Build customer lock-in", "Diversify customer base"],
        },
    }
    
    return buyer_map.get(sector.lower(), buyer_map["default"])


def _assess_substitute_threat(sector: str) -> Dict:
    """Assess threat of substitutes"""
    
    substitute_map = {
        "saas": {
            "threat_score": 7.0,  # High - open source, DIY, manual processes
            "drivers": [
                "Open source alternatives (free but less polished)",
                "Build-vs-buy decisions always open",
                "Manual processes still used",
                "New entrants with different approach"
            ],
            "implications": "Must offer superior UX/integration to justify cost",
            "recommendations": [
                "Focus on ease of use",
                "Speed to value",
                "Native integrations",
                "Ongoing innovation"
            ],
        },
        "manufacturing": {
            "threat_score": 3.0,  # Low - hard to substitute material goods
            "drivers": [
                "Substitutes exist (different materials) but not direct",
                "Consumer preferences changing slowly",
                "Regulatory/safety: locks in certain materials"
            ],
            "implications": "Stable; focus on efficiency and customer service",
            "recommendations": [
                "Monitor material science breakthroughs",
                "Invest in adjacent materials",
                "Build switching costs through integration"
            ],
        },
        "retail": {
            "threat_score": 7.5,  # High - e-commerce, direct, alternatives
            "drivers": [
                "E-commerce: always an alternative",
                "Direct-to-consumer: brands bypass retailers",
                "Private label: customer substitutes",
                "Marketplaces: new way to shop"
            ],
            "implications": "Channel under pressure; must offer unique value",
            "recommendations": [
                "Omnichannel capabilities",
                "Experience (service, environment)",
                "Curation and expertise",
                "Exclusive products"
            ],
        },
        "default": {
            "threat_score": 5.0,
            "drivers": ["Industry-dependent"],
            "implications": "Assess alternative solutions",
            "recommendations": ["Continuous innovation", "Customer stickiness"],
        },
    }
    
    return substitute_map.get(sector.lower(), substitute_map["default"])


def _assess_competitive_rivalry(sector: str, position: str) -> Dict:
    """Assess competitive rivalry intensity"""
    
    rivalry_map = {
        "saas": {
            "threat_score": 8.0,  # Very high - lots of competitors
            "drivers": [
                "Low barriers = many competitors",
                "VC-backed companies fighting hard",
                "Feature parity achieved quickly",
                "Price pressure from competition"
            ],
            "implications": "Must differentiate and grow fast",
            "recommendations": [
                "Focus on one persona/problem deeply",
                "Build product differentiation",
                "Create network effects if possible",
                "Grow faster than competitors"
            ],
        },
        "manufacturing": {
            "threat_score": 5.5,  # Moderate
            "drivers": [
                "Mature market: stable competitor set",
                "Capital intensity: limits new entrants",
                "Brand/relationships matter",
                "Price competition in commodities"
            ],
            "implications": "Compete on cost/quality/service",
            "recommendations": [
                "Operational excellence (cost)",
                "Quality certification/standards",
                "Customer service differentiation",
                "Product innovation"
            ],
        },
        "retail": {
            "threat_score": 8.5,  # Extreme
            "drivers": [
                "Fragmented (many competitors)",
                "E-commerce = unlimited competition",
                "Race to convenience",
                "Margin pressure from all sides"
            ],
            "implications": "Only survive with scale, differentiation, or niche",
            "recommendations": [
                "Scale (multi-location, multi-channel)",
                "Niche/specific customer focus",
                "Exclusive/proprietary products",
                "Operational efficiency (SasS model?)"
            ],
        },
        "default": {
            "threat_score": 6.0,
            "drivers": ["Varies by market concentration"],
            "implications": "Assess competitive landscape",
            "recommendations": ["Find defensible position", "Build moats"],
        },
    }
    
    return rivalry_map.get(sector.lower(), rivalry_map["default"])


def _derive_strategy_from_porter(forces: List[PorterForceAnalysis]) -> str:
    """Translate Porter forces into strategic implication"""
    
    avg_threat = sum(f.intensity_score for f in forces) / len(forces)
    
    if avg_threat >= 7:
        return "DEFENSIVE STRATEGY: Market is highly competitive. Focus on differentiation, niche dominance, cost leadership, or consider exit/sale."
    elif avg_threat >= 5:
        return "BALANCED STRATEGY: Moderate competitive intensity. Compete on product, service, or operational excellence."
    else:
        return "OFFENSIVE STRATEGY: Market is attractive. Invest for growth, market share, and scale."


def _prioritize_ansoff_strategies(
    market_position: str,
    growth_rate: float,
    margin: float,
) -> List[AnsoffStrategy]:
    """Prioritize Ansoff strategies based on company profile"""
    
    # Logic: if market penetration isn't working (low growth), diversify
    # If margin is good, invest in product/market development
    
    if market_position == "Startup" or growth_rate < 5:
        # Struggling: market penetration first
        return [
            AnsoffStrategy.MARKET_PENETRATION,
            AnsoffStrategy.PRODUCT_DEVELOPMENT,
            AnsoffStrategy.MARKET_DEVELOPMENT,
            AnsoffStrategy.DIVERSIFICATION,
        ]
    elif growth_rate > 20 and margin > 20:
        # Strong position: can afford to diversify
        return [
            AnsoffStrategy.MARKET_DEVELOPMENT,
            AnsoffStrategy.PRODUCT_DEVELOPMENT,
            AnsoffStrategy.MARKET_PENETRATION,
            AnsoffStrategy.DIVERSIFICATION,
        ]
    else:
        # Typical: balanced approach
        return [
            AnsoffStrategy.PRODUCT_DEVELOPMENT,
            AnsoffStrategy.MARKET_PENETRATION,
            AnsoffStrategy.MARKET_DEVELOPMENT,
            AnsoffStrategy.DIVERSIFICATION,
        ]


def _create_ansoff_rationale(strategies: List[AnsoffStrategy], position: str) -> str:
    """Explain why this Ansoff priority"""
    
    order_str = " → ".join([s.value.replace("_", " ").title() for s in strategies])
    
    return f"Recommended sequence: {order_str}. This balances risk (start with proven markets/products) with growth opportunity (expand systematically)."
