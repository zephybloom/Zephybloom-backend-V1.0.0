"""Intent router for CFO chat questions.

The router keeps wording variants out of API routes. It is intentionally
deterministic: product-critical financial answers should be explainable and
stable before any generative fallback is used.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from difflib import get_close_matches
from typing import Dict, Optional, Set


class CFOIntent(str, Enum):
    KPI_ROI = "kpi_roi"
    KPI_PROFIT = "kpi_profit"
    KPI_EBITDA = "kpi_ebitda"
    GROWTH_STRATEGY = "growth_strategy"
    COST_OPTIMIZATION = "cost_optimization"
    WEAKNESS_DIAGNOSIS = "weakness_diagnosis"
    CUSTOMER_PROFITABILITY = "customer_profitability"
    PRODUCT_MARGIN = "product_margin"
    PROCUREMENT_BENCHMARK = "procurement_benchmark"
    DEFINITION = "definition"
    UNKNOWN = "unknown"


class MessageKind(str, Enum):
    QUESTION = "question"
    DATA_INPUT = "data_input"
    FOLLOW_UP = "follow_up"
    SIMULATION_REQUEST = "simulation_request"
    DEFINITION_REQUEST = "definition_request"
    ACTION_REQUEST = "action_request"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class IntentResult:
    intent: CFOIntent
    confidence: float
    normalized_words: Set[str]
    reason: str = ""
    message_kind: MessageKind = MessageKind.QUESTION


STOPWORDS = {
    "l",
    "il",
    "lo",
    "la",
    "i",
    "gli",
    "le",
    "un",
    "una",
    "uno",
    "di",
    "del",
    "della",
    "dei",
    "degli",
    "che",
    "cosa",
    "cos",
    "e",
    "è",
    "mi",
    "mio",
    "mia",
    "miei",
    "mie",
    "posso",
    "come",
    "quale",
    "quali",
    "dove",
}

TYPO_ALIASES: Dict[str, str] = {
    "osa": "cosa",
    "os": "cos",
    "ose": "cose",
    "cose": "cose",
    "fatt": "fatturato",
    "fattuato": "fatturato",
    "fattuarato": "fatturato",
    "fatturatto": "fatturato",
    "fatturat": "fatturato",
    "venddere": "vendere",
    "vedere": "vendere",
    "vendre": "vendere",
    "vendoo": "vendere",
    "attivita": "attivita",
    "attività": "attivita",
    "clientee": "clienti",
    "cllienti": "clienti",
    "converebbe": "conviene",
    "converrebbe": "conviene",
    "abbasare": "abbassare",
    "abassare": "abbassare",
    "abbasaree": "abbassare",
    "diminuiree": "diminuire",
    "diminuir": "diminuire",
    "marggine": "margine",
    "marginee": "margine",
    "margni": "margine",
    "prodoto": "prodotto",
    "prodotti": "prodotti",
    "prodotii": "prodotti",
    "fornitore": "fornitore",
    "fornitroi": "fornitori",
    "fornitori": "fornitori",
    "cassa": "cassa",
    "casssa": "cassa",
    "commesa": "commessa",
    "commesse": "commesse",
    "cantierre": "cantiere",
    "cantieri": "cantiere",
    "ebitd": "ebitda",
    "bitda": "ebitda",
    "ebit": "ebitda",
    "utilee": "utile",
    "utle": "utile",
    "carenti": "debolezze",
    "carente": "debolezze",
    "migliorare": "migliorare",
    "miglioro": "migliorare",
    "acquisisco": "acquisire",
    "acquisiree": "acquisire",
    "acquisizione": "acquisire",
    "guadagnare": "utile",
}


ROI_WORDS = {"roi", "ritorno", "investimento", "investimenti"}
PROFIT_WORDS = {"utile", "profitto", "netto", "guadagno", "guadagni"}
EBITDA_WORDS = {"ebitda", "margine operativo", "redditivita", "redditività"}
GROWTH_WORDS = {
    "aumentare",
    "aumento",
    "aumenta",
    "aumentarlo",
    "crescere",
    "scalare",
    "fatturato",
    "ricavi",
    "vendite",
    "vendere",
    "piu",
    "più",
    "clienti",
    "attivita",
    "attività",
    "commerciale",
    "scontrino",
    "ticket",
    "aov",
    "ordini",
}
COST_WORDS = {
    "abbassare",
    "diminuire",
    "ridurre",
    "tagliare",
    "ottimizzare",
    "costi",
    "costo",
    "spese",
    "fornitori",
    "conviene",
    "converebbe",
    "margine",
    "margini",
}
CUSTOMER_WORDS = {"cliente", "clienti", "customer"}
PRODUCT_WORDS = {
    "prodotto",
    "prodotti",
    "sku",
    "articoli",
    "servizi",
    "servizio",
    "piatto",
    "piatti",
    "menu",
    "ricetta",
    "ricette",
    "ingredienti",
    "merce",
}
MARGIN_WORDS = {"margine", "margini", "profittevoli", "redditivita", "redditività"}
PROCUREMENT_WORDS = {"compro", "comprare", "prendo", "acquisto", "acquistare", "fornitore", "fornitori", "prezzo", "prezzi", "pagando"}
BENCHMARK_WORDS = {"settore", "mercato", "benchmark", "meno", "costano", "costa", "attualmente"}
WEAKNESS_WORDS = {
    "deboli",
    "debolezze",
    "problemi",
    "migliorare",
    "miglioramento",
    "criticita",
    "criticità",
    "rischi",
    "perdendo",
    "perdo",
    "soldi",
    "carenti",
    "carente",
    "blocca",
    "bloccando",
}
DEFINITION_WORDS = {"definizione", "significa", "cos", "cosa"}

ALL_DOMAIN_WORDS = (
    ROI_WORDS
    | PROFIT_WORDS
    | EBITDA_WORDS
    | GROWTH_WORDS
    | COST_WORDS
    | CUSTOMER_WORDS
    | PRODUCT_WORDS
    | MARGIN_WORDS
    | PROCUREMENT_WORDS
    | BENCHMARK_WORDS
    | WEAKNESS_WORDS
    | DEFINITION_WORDS
    | {"commessa", "commesse", "cantiere", "cantieri", "sal", "wip", "cassa", "cash", "roas", "cac"}
)


def normalize_question_words(question: Optional[str]) -> Set[str]:
    if not question:
        return set()

    text = question.strip().lower()
    text = text.replace("'", " ").replace("’", " ")
    text = text.replace("ù", "u")
    text = _normalize_common_phrases(text)
    text = re.sub(r"[^\w\sàèéìòù]", " ", text)
    return {_normalize_token(word) for word in text.split() if word and word not in STOPWORDS}


def _normalize_common_phrases(text: str) -> str:
    phrase_aliases = {
        "os e": "cos e",
        "os è": "cos e",
        "osa e": "cosa e",
        "osa è": "cosa e",
        "osa il": "cosa il",
        "osa l": "cosa l",
        "piu clienti": "clienti",
        "piu vendite": "vendite",
        "vendere di piu": "vendere piu",
        "aumentare le vendite": "aumentare vendite",
        "aumentare il fatturato": "aumentare fatturato",
        "abbassare i costi": "abbassare costi",
        "ridurre i costi": "ridurre costi",
        "punti deboli": "debolezze",
        "punti carenti": "debolezze",
        "acquisire clienti": "clienti acquisire",
        "fare piu soldi": "utile",
        "guadagnare di piu": "utile",
    }
    normalized = f" {text} "
    for source, target in phrase_aliases.items():
        normalized = normalized.replace(f" {source} ", f" {target} ")
    return normalized.strip()


def _normalize_token(word: str) -> str:
    token = TYPO_ALIASES.get(word, word)
    if token in ALL_DOMAIN_WORDS or len(token) <= 4:
        return token
    match = get_close_matches(token, ALL_DOMAIN_WORDS, n=1, cutoff=0.84)
    return match[0] if match else token


def route_cfo_intent(question: Optional[str]) -> IntentResult:
    words = normalize_question_words(question)
    raw = _normalize_common_phrases((question or "").strip().lower())
    message_kind = classify_message_kind(question)

    if not words:
        return IntentResult(CFOIntent.UNKNOWN, 0.0, words, "empty_question", message_kind)

    is_definition = bool(DEFINITION_WORDS & words) or raw.startswith(("cos'", "cosa ", "che cos"))

    if {"clienti", "acquisire"} <= words or "acquisire clienti" in raw:
        return IntentResult(CFOIntent.GROWTH_STRATEGY, 0.92, words, "customer_acquisition_phrase", message_kind)

    if {"migliorare", "vendite"} <= words or {"migliorare", "vendere"} <= words:
        return IntentResult(CFOIntent.GROWTH_STRATEGY, 0.92, words, "sales_improvement_phrase", message_kind)

    if {"punti", "debolezze"} <= words or {"punti", "carenti"} <= words:
        return IntentResult(CFOIntent.WEAKNESS_DIAGNOSIS, 0.92, words, "weakness_points_phrase", message_kind)

    if "dove posso migliorare" in raw or "dove migliorare" in raw:
        return IntentResult(CFOIntent.WEAKNESS_DIAGNOSIS, 0.9, words, "where_improve_phrase", message_kind)

    if {"perdo", "soldi"} <= words or {"perdendo", "soldi"} <= words:
        return IntentResult(CFOIntent.WEAKNESS_DIAGNOSIS, 0.9, words, "money_leak_keyword", message_kind)

    if {"commessa", "blocca"} <= words or {"commesse", "blocca"} <= words or {"cassa", "blocca"} <= words:
        return IntentResult(CFOIntent.WEAKNESS_DIAGNOSIS, 0.9, words, "cash_block_keyword", message_kind)

    if "roi" in words:
        return IntentResult(CFOIntent.KPI_ROI if not is_definition else CFOIntent.DEFINITION, 0.98, words, "roi_keyword", message_kind)

    if "ebitda" in words:
        return IntentResult(CFOIntent.KPI_EBITDA if not is_definition else CFOIntent.DEFINITION, 0.98, words, "ebitda_keyword", message_kind)

    if words & PROFIT_WORDS:
        if words & CUSTOMER_WORDS:
            return IntentResult(CFOIntent.CUSTOMER_PROFITABILITY, 0.92, words, "customer_profit_keyword", message_kind)
        return IntentResult(CFOIntent.KPI_PROFIT, 0.94, words, "profit_keyword", message_kind)

    if (words & PRODUCT_WORDS) and (words & MARGIN_WORDS):
        return IntentResult(CFOIntent.PRODUCT_MARGIN, 0.92, words, "product_margin_keyword", message_kind)

    if (words & PRODUCT_WORDS) and {"prezzo", "prezzi", "vendere", "venderlo", "venderla"} & words:
        return IntentResult(CFOIntent.PRODUCT_MARGIN, 0.9, words, "product_price_keyword", message_kind)

    if (words & PRODUCT_WORDS) and (words & PROCUREMENT_WORDS) and (words & BENCHMARK_WORDS):
        return IntentResult(CFOIntent.PROCUREMENT_BENCHMARK, 0.9, words, "procurement_benchmark_keyword", message_kind)

    if words & COST_WORDS:
        return IntentResult(CFOIntent.COST_OPTIMIZATION, 0.9, words, "cost_keyword", message_kind)

    if words & WEAKNESS_WORDS:
        return IntentResult(CFOIntent.WEAKNESS_DIAGNOSIS, 0.88, words, "weakness_keyword", message_kind)

    if words & GROWTH_WORDS:
        return IntentResult(CFOIntent.GROWTH_STRATEGY, 0.88, words, "growth_keyword", message_kind)

    return IntentResult(CFOIntent.UNKNOWN, 0.2, words, "no_rule_match", message_kind)


def classify_message_kind(question: Optional[str]) -> MessageKind:
    raw = (question or "").strip().lower()
    if not raw:
        return MessageKind.UNKNOWN

    compact = raw.replace("’", "'")
    if compact in {"ok", "ok.", "vai", "vai.", "fallo", "fammi", "procedi", "continua"}:
        return MessageKind.FOLLOW_UP

    if raw.startswith(("cos'è", "cos e", "cosa è", "cosa e", "osa è", "osa e", "che cos", "significa", "definisci", "spiegami")):
        return MessageKind.DEFINITION_REQUEST

    if raw.startswith("per ") and "mi servono" in raw:
        return MessageKind.DATA_INPUT

    if any(token in raw for token in ["simula", "scenario", "cosa succede se", "se aumento", "se riduco", "+5%", "+10%", "-5%", "-10%"]):
        return MessageKind.SIMULATION_REQUEST

    if any(phrase in raw for phrase in ["cosa devo fare", "fammi un piano", "dammi un piano", "da dove parto", "prossima mossa", "questa settimana"]):
        return MessageKind.ACTION_REQUEST

    if "?" in raw or any(token in raw for token in ["come", "quale", "quali", "quanto", "dove", "perché", "perche"]):
        return MessageKind.QUESTION

    return MessageKind.QUESTION


def is_single_kpi_intent(result: IntentResult) -> bool:
    return result.intent in {CFOIntent.KPI_ROI, CFOIntent.KPI_PROFIT, CFOIntent.KPI_EBITDA} and len(result.normalized_words) <= 4
