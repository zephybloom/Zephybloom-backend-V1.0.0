"""
Industry-Aware Decision Adapter (FASE 2)

Adapts decision recommendations, rankings, and actions based on industry context.
Makes the DecisionProcessor industry-aware and provides sector-specific insights.
"""

import logging
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass

from core.industry_intelligence import (
    IndustryRegistry,
    IndustryProfile,
    BenchmarkData,
    IndustryCode,
    get_industry_profile,
    get_benchmark_comparison,
)
from core.analysis import KPISnapshot

logger = logging.getLogger(__name__)


@dataclass
class IndustryInsight:
    """Industry-specific insight and comparison"""
    industry_code: str
    industry_name: str
    health_status: str  # "excellent", "healthy", "warning", "critical"
    key_assessment: str  # What's the main issue for THIS industry
    benchmark_comparisons: List[BenchmarkData]
    industry_specific_actions: List[str]  # Top actions for this industry
    common_pitfalls_to_avoid: List[str]
    competitive_position: str  # "leading", "competitive", "lagging", "unknown"


class IndustryAdapter:
    """Adapt decisions, thresholds, and recommendations by industry"""
    
    @staticmethod
    def get_adjusted_thresholds(
        industry_code: str,
    ) -> Dict[str, float]:
        """Get industry-specific thresholds for evaluating health"""
        profile = get_industry_profile(industry_code)
        
        return {
            "gross_margin_healthy": profile.healthy_gross_margin_pct,
            "net_margin_healthy": profile.healthy_net_margin_pct,
            "ebitda_margin_healthy": profile.healthy_ebitda_margin_pct,
            "roi_healthy": profile.healthy_roi_pct,
            "max_fixed_cost_pct": profile.max_fixed_cost_pct_revenue,
        }
    
    @staticmethod
    def assess_health_by_industry(
        industry_code: str,
        gross_margin_pct: Optional[float],
        net_margin_pct: Optional[float],
        ebitda_margin_pct: Optional[float],
        roi_pct: Optional[float],
        fixed_cost_pct: Optional[float],
    ) -> Tuple[str, List[str]]:
        """
        Assess company health using industry-specific thresholds.
        
        Returns: (overall_status, issues_list)
        Status: "excellent", "healthy", "warning", "critical"
        """
        
        profile = get_industry_profile(industry_code)
        issues = []
        
        # Evaluate each metric against industry thresholds
        if net_margin_pct is not None:
            if net_margin_pct < 0:
                issues.append(f"Loss-making (net margin {net_margin_pct:.1%})")
            elif net_margin_pct < profile.healthy_net_margin_pct * 0.5:
                issues.append(
                    f"Net margin critically low "
                    f"({net_margin_pct:.1%} vs healthy {profile.healthy_net_margin_pct:.1%})"
                )
            elif net_margin_pct < profile.healthy_net_margin_pct:
                issues.append(
                    f"Net margin below industry standard "
                    f"({net_margin_pct:.1%} vs {profile.healthy_net_margin_pct:.1%})"
                )
        
        if gross_margin_pct is not None:
            if gross_margin_pct < profile.healthy_gross_margin_pct * 0.75:
                issues.append(
                    f"Gross margin weak for {profile.name} "
                    f"({gross_margin_pct:.1%})"
                )
        
        if fixed_cost_pct and fixed_cost_pct > profile.max_fixed_cost_pct_revenue:
            gap = fixed_cost_pct - profile.max_fixed_cost_pct_revenue
            issues.append(
                f"Fixed costs {gap:.0%} above industry sustainable level"
            )
        
        # Determine overall status
        if not issues:
            return "excellent", []
        elif len(issues) == 1 and "below industry standard" in issues[0]:
            return "healthy", issues
        elif len(issues) <= 2:
            return "warning", issues
        else:
            return "critical", issues
    
    @staticmethod
    def prioritize_actions_by_industry(
        industry_code: str,
        available_actions: List[str],  # Generic actions available
        kpi_snapshot: Optional[KPISnapshot],
    ) -> List[str]:
        """
        Rerank actions based on industry priorities.
        
        Example:
        - SaaS company: Churn reduction before pricing optimization
        - Retail: Inventory optimization before customer acquisition
        - Manufacturing: Capacity utilization before COGS reduction
        """
        
        profile = get_industry_profile(industry_code)
        
        # Map generic actions to industry-specific versions
        industry_action_priority = {
            action: idx for idx, action in enumerate(profile.top_decisions)
        }
        
        # Rerank available actions
        ranked = []
        for action in available_actions:
            # Check if action matches industry priority
            for priority_action in profile.top_decisions:
                if priority_action.lower() in action.lower() or action.lower() in priority_action.lower():
                    ranked.append((action, industry_action_priority[priority_action]))
                    break
            else:
                # Action not in industry priorities, rank lower
                ranked.append((action, len(profile.top_decisions) + 1))
        
        # Sort by priority
        ranked.sort(key=lambda x: x[1])
        return [action for action, _ in ranked]
    
    @staticmethod
    def generate_industry_insight(
        industry_code: str,
        gross_margin_pct: Optional[float],
        net_margin_pct: Optional[float],
        ebitda_margin_pct: Optional[float],
        roi_pct: Optional[float],
        available_actions: List[str],
    ) -> IndustryInsight:
        """Generate comprehensive industry-specific insight"""
        
        profile = get_industry_profile(industry_code)
        
        # Assess health by industry standard
        status, issues = IndustryAdapter.assess_health_by_industry(
            industry_code=industry_code,
            gross_margin_pct=gross_margin_pct,
            net_margin_pct=net_margin_pct,
            ebitda_margin_pct=ebitda_margin_pct,
            roi_pct=roi_pct,
            fixed_cost_pct=None,  # TODO: calculate from data
        )
        
        # Get benchmark comparisons
        benchmark_comparisons = []
        
        if net_margin_pct is not None:
            bench = get_benchmark_comparison(
                industry_code=industry_code,
                metric="net_margin_pct",
                your_value=net_margin_pct,
            )
            if bench:
                benchmark_comparisons.append(bench)
        
        if gross_margin_pct is not None:
            bench = get_benchmark_comparison(
                industry_code=industry_code,
                metric="gross_margin_pct",
                your_value=gross_margin_pct,
            )
            if bench:
                benchmark_comparisons.append(bench)
        
        # Determine competitive position
        if benchmark_comparisons:
            percentiles = [b.percentile_rank for b in benchmark_comparisons]
            if any("Top 10%" in p or "Top 25%" in p for p in percentiles):
                competitive_position = "leading"
            elif any("average" in p.lower() for p in percentiles):
                competitive_position = "competitive"
            else:
                competitive_position = "lagging"
        else:
            competitive_position = "unknown"
        
        # Key assessment for this industry
        key_assessment = IndustryAdapter._generate_key_assessment(
            profile=profile,
            status=status,
            issues=issues,
        )
        
        return IndustryInsight(
            industry_code=industry_code,
            industry_name=profile.name,
            health_status=status,
            key_assessment=key_assessment,
            benchmark_comparisons=benchmark_comparisons,
            industry_specific_actions=profile.top_decisions[:3],
            common_pitfalls_to_avoid=profile.common_pitfalls,
            competitive_position=competitive_position,
        )
    
    @staticmethod
    def _generate_key_assessment(
        profile: IndustryProfile,
        status: str,
        issues: List[str],
    ) -> str:
        """Generate a concise key assessment for the industry"""
        
        if status == "excellent":
            return f"Operating at or above {profile.name} standards. Focus on competitive differentiation and growth."
        
        if not issues:
            return f"Healthy financial state for {profile.name}."
        
        # Focus on most pressing industry-specific issue
        main_issue = issues[0]
        
        if "net margin" in main_issue.lower():
            return f"Profitability below {profile.name} standards. {profile.decision_focus} needs attention."
        
        if "fixed cost" in main_issue.lower():
            return f"Cost structure unsustainable for {profile.name}. Need to right-size fixed costs."
        
        if "gross margin" in main_issue.lower():
            return f"Pricing or cost of goods issue affecting margins. Core unit economics need review."
        
        return f"{profile.sustainability_concern} - address immediately."


class IndustryAdapterService:
    """High-level service for industry-aware analysis"""
    
    def __init__(self, industry_code: str):
        self.industry_code = industry_code
        self.profile = get_industry_profile(industry_code)
        self.thresholds = IndustryAdapter.get_adjusted_thresholds(industry_code)
    
    def is_healthy(
        self,
        gross_margin_pct: Optional[float],
        net_margin_pct: Optional[float],
    ) -> bool:
        """Is company financially healthy by industry standards?"""
        
        if net_margin_pct is not None:
            return net_margin_pct >= self.profile.healthy_net_margin_pct * 0.75
        
        if gross_margin_pct is not None:
            return gross_margin_pct >= self.profile.healthy_gross_margin_pct * 0.75
        
        return False
    
    def get_urgency_factor(
        self,
        net_margin_pct: Optional[float],
    ) -> float:
        """
        Get urgency multiplier for actions (1.0 = normal, 2.0 = very urgent).
        Industries with thin margins need more urgent action.
        """
        
        if net_margin_pct is None:
            return 1.0
        
        threshold = self.profile.healthy_net_margin_pct
        
        if net_margin_pct < 0:
            return 3.0  # Critical
        elif net_margin_pct < threshold * 0.5:
            return 2.5  # Very urgent
        elif net_margin_pct < threshold * 0.75:
            return 2.0  # Urgent
        elif net_margin_pct < threshold:
            return 1.5  # Important
        else:
            return 1.0  # Normal pace


def get_industry_adapter(industry_code: str) -> IndustryAdapterService:
    """Factory for industry adapter service"""
    return IndustryAdapterService(industry_code)
