"""
Performance Optimization: Caching Layer

Reduces latency through:
- LRU cache for profile inference
- Tone selection caching
- Hash-based profile matching
- TTL-based cache invalidation
"""

import hashlib
import json
from typing import Optional, Dict, Tuple
from functools import lru_cache
from dataclasses import dataclass
from datetime import datetime, timedelta

from core.entrepreneur_profiler import EntrepreneurProfile
from core.dynamic_tone_manager import TonePersonalization


@dataclass
class CacheStats:
    """Cache performance statistics"""
    hits: int = 0
    misses: int = 0
    total_calls: int = 0
    avg_hit_time_ms: float = 0.0
    avg_miss_time_ms: float = 0.0
    
    @property
    def hit_rate(self) -> float:
        """Cache hit rate (0-1)"""
        if self.total_calls == 0:
            return 0.0
        return self.hits / self.total_calls


class ProfileCache:
    """
    LRU cache for entrepreneur profiles.
    
    Caches EntrepreneurProfile by metrics hash to avoid re-inference.
    Each profile cached for 24h before invalidation.
    """
    
    def __init__(self, maxsize: int = 1000):
        self.cache: Dict[str, Tuple[EntrepreneurProfile, datetime]] = {}
        self.maxsize = maxsize
        self.stats = CacheStats()
    
    @staticmethod
    def _hash_metrics(
        fatturato: float,
        ebitda_margin_pct: float,
        gross_margin_pct: float,
        growth_rate_pct: float,
        company_age_years: float,
        industry: str,
    ) -> str:
        """
        Hash metrics to create cache key.
        
        Rounds values to reduce cache misses from floating point differences.
        """
        # Round to reduce precision artifacts
        rounded = {
            "f": round(fatturato, -3),  # Round to nearest 1000
            "e": round(ebitda_margin_pct, 1),
            "g": round(gross_margin_pct, 1),
            "r": round(growth_rate_pct, 0),
            "a": round(company_age_years, 0),
            "i": industry.lower(),
        }
        
        key = json.dumps(rounded, sort_keys=True)
        return hashlib.md5(key.encode()).hexdigest()[:16]
    
    def get(
        self,
        profile: Optional[EntrepreneurProfile],
        fatturato: float,
        ebitda_margin_pct: float,
        gross_margin_pct: float,
        growth_rate_pct: float,
        company_age_years: float,
        industry: str,
    ) -> bool:
        """
        Check if profile is cached and not expired.
        
        Returns: True if found in cache (profile already cached)
        """
        key = self._hash_metrics(
            fatturato, ebitda_margin_pct, gross_margin_pct,
            growth_rate_pct, company_age_years, industry
        )
        
        self.stats.total_calls += 1
        
        if key in self.cache:
            cached_profile, timestamp = self.cache[key]
            
            # Check if expired (24h TTL)
            if datetime.now() - timestamp < timedelta(hours=24):
                self.stats.hits += 1
                return True
            else:
                # Expired, remove
                del self.cache[key]
        
        self.stats.misses += 1
        return False
    
    def put(
        self,
        profile: EntrepreneurProfile,
        fatturato: float,
        ebitda_margin_pct: float,
        gross_margin_pct: float,
        growth_rate_pct: float,
        company_age_years: float,
        industry: str,
    ):
        """Store profile in cache"""
        
        key = self._hash_metrics(
            fatturato, ebitda_margin_pct, gross_margin_pct,
            growth_rate_pct, company_age_years, industry
        )
        
        # Enforce size limit
        if len(self.cache) >= self.maxsize:
            # Remove oldest entry
            oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k][1])
            del self.cache[oldest_key]
        
        self.cache[key] = (profile, datetime.now())
    
    def clear(self):
        """Clear entire cache"""
        self.cache.clear()
        self.stats = CacheStats()
    
    def get_stats(self) -> CacheStats:
        """Get cache performance statistics"""
        # Calculate hit rate in return, don't set it
        return self.stats


class ToneCache:
    """
    Cache for tone selection results.
    
    Caches TonePersonalization by (profile_hash, severity) key.
    TTL: 24h
    """
    
    def __init__(self, maxsize: int = 500):
        self.cache: Dict[str, Tuple[TonePersonalization, datetime]] = {}
        self.maxsize = maxsize
        self.stats = CacheStats()
    
    @staticmethod
    def _hash_key(profile_id: str, severity: str) -> str:
        """Create cache key from profile and severity"""
        key = f"{profile_id}:{severity}"
        return hashlib.md5(key.encode()).hexdigest()[:16]
    
    def get(self, profile_id: str, severity: str) -> Optional[TonePersonalization]:
        """Get cached tone if available and not expired"""
        
        key = self._hash_key(profile_id, severity)
        self.stats.total_calls += 1
        
        if key in self.cache:
            tone, timestamp = self.cache[key]
            
            if datetime.now() - timestamp < timedelta(hours=24):
                self.stats.hits += 1
                return tone
            else:
                del self.cache[key]
        
        self.stats.misses += 1
        return None
    
    def put(self, profile_id: str, severity: str, tone: TonePersonalization):
        """Store tone in cache"""
        
        key = self._hash_key(profile_id, severity)
        
        if len(self.cache) >= self.maxsize:
            oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k][1])
            del self.cache[oldest_key]
        
        self.cache[key] = (tone, datetime.now())
    
    def clear(self):
        """Clear entire cache"""
        self.cache.clear()
        self.stats = CacheStats()
    
    def get_stats(self) -> CacheStats:
        """Get cache statistics"""
        # Return stats with hit_rate calculated dynamically
        return self.stats


class CacheManager:
    """
    Unified cache manager for FASE 4+5 components.
    
    Manages:
    - Profile cache
    - Tone cache
    - Cache statistics
    - Cache invalidation
    """
    
    def __init__(self):
        self.profile_cache = ProfileCache(maxsize=1000)
        self.tone_cache = ToneCache(maxsize=500)
    
    def get_stats(self) -> Dict[str, CacheStats]:
        """Get statistics for all caches"""
        return {
            "profile_cache": self.profile_cache.get_stats(),
            "tone_cache": self.tone_cache.get_stats(),
        }
    
    def clear_all(self):
        """Clear all caches"""
        self.profile_cache.clear()
        self.tone_cache.clear()
    
    def print_stats(self):
        """Print cache statistics"""
        stats = self.get_stats()
        print("\n=== CACHE STATISTICS ===")
        for cache_name, cache_stats in stats.items():
            print(f"\n{cache_name}:")
            print(f"  Hits: {cache_stats.hits}")
            print(f"  Misses: {cache_stats.misses}")
            print(f"  Total calls: {cache_stats.total_calls}")
            print(f"  Hit rate: {cache_stats.hit_rate:.1%}")


# Global cache manager instance
_cache_manager: Optional[CacheManager] = None


def get_cache_manager() -> CacheManager:
    """Get or create the global cache manager"""
    global _cache_manager
    if _cache_manager is None:
        _cache_manager = CacheManager()
    return _cache_manager
