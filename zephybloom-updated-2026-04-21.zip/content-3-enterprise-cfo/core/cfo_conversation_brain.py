"""Conversation brain for CFO chat orchestration.

This module does not write the answer. It decides which answer engine should
handle the question: FAQ/KPI, missing-data gate, vertical calculation,
simulation, decision playbook, or fallback.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Set

from core.business_model_schema import DataCompletenessResult
from core.cfo_intent_router import CFOIntent, IntentResult, MessageKind, route_cfo_intent


class ConversationAction(str, Enum):
    FAQ_OR_KPI = "faq_or_kpi"
    ASK_FOR_DATA = "ask_for_data"
    RUN_SIMULATION = "run_simulation"
    VERTICAL_ANALYSIS = "vertical_analysis"
    DECISION_PLAYBOOK = "decision_playbook"
    WAR_ROOM = "war_room"
    FALLBACK_ENGINE = "fallback_engine"


@dataclass(frozen=True)
class ConversationDecision:
    action: ConversationAction
    intent_result: IntentResult
    confidence: float
    reason: str
    should_use_operational_data: bool = False
    next_best_prompt: str = ""


SIMULATION_WORDS = {
    "se",
    "simula",
    "simulazione",
    "scenario",
    "cosa",
    "succede",
    "aumento",
    "aumentassi",
    "riduco",
    "ridurre",
    "abbasso",
}

VERTICAL_WORDS = {
    "piatti",
    "piatto",
    "menu",
    "ingredienti",
    "sku",
    "cac",
    "roas",
    "commessa",
    "commesse",
    "cantiere",
    "cantieri",
    "sal",
    "wip",
}

DATA_WORDS = {
    "dati",
    "manca",
    "mancano",
    "serve",
    "servono",
    "analizzare",
    "preciso",
    "precisione",
}

STRATEGIC_INTENTS = {
    CFOIntent.GROWTH_STRATEGY,
    CFOIntent.COST_OPTIMIZATION,
    CFOIntent.WEAKNESS_DIAGNOSIS,
    CFOIntent.PRODUCT_MARGIN,
    CFOIntent.PROCUREMENT_BENCHMARK,
}

WAR_ROOM_PHRASES = [
    "cosa devo fare",
    "da dove parto",
    "da dove iniziare",
    "prossima mossa",
    "prossime mosse",
    "questa settimana",
    "war room",
    "priorita",
    "priorità",
]


def decide_conversation_action(
    question: Optional[str],
    sector: str,
    readiness: Optional[DataCompletenessResult] = None,
    has_operational_data: bool = False,
) -> ConversationDecision:
    """Choose the most suitable answer engine for a CFO chat message."""

    intent_result = route_cfo_intent(question)
    words = intent_result.normalized_words
    lower = (question or "").lower()

    if any(phrase in lower for phrase in WAR_ROOM_PHRASES):
        return ConversationDecision(
            action=ConversationAction.WAR_ROOM,
            intent_result=intent_result,
            confidence=max(intent_result.confidence, 0.88),
            reason="war_room_priority_request",
            should_use_operational_data=True,
            next_best_prompt=_next_prompt(ConversationAction.WAR_ROOM, intent_result, readiness, has_operational_data),
        )

    if intent_result.message_kind == MessageKind.FOLLOW_UP:
        return ConversationDecision(
            action=ConversationAction.DECISION_PLAYBOOK,
            intent_result=intent_result,
            confidence=max(intent_result.confidence, 0.82),
            reason="follow_up_message_kind",
            should_use_operational_data=has_operational_data,
            next_best_prompt=_next_prompt(ConversationAction.DECISION_PLAYBOOK, intent_result, readiness, has_operational_data),
        )

    if intent_result.intent in {CFOIntent.KPI_ROI, CFOIntent.KPI_PROFIT, CFOIntent.KPI_EBITDA, CFOIntent.DEFINITION}:
        return ConversationDecision(
            action=ConversationAction.FAQ_OR_KPI,
            intent_result=intent_result,
            confidence=max(intent_result.confidence, 0.9),
            reason="single_kpi_or_definition",
            next_best_prompt=_next_prompt(ConversationAction.FAQ_OR_KPI, intent_result, readiness, has_operational_data),
        )

    if intent_result.message_kind == MessageKind.SIMULATION_REQUEST or _looks_like_simulation(words, lower):
        return ConversationDecision(
            action=ConversationAction.RUN_SIMULATION,
            intent_result=intent_result,
            confidence=0.88,
            reason="scenario_language_detected",
            should_use_operational_data=True,
            next_best_prompt=_next_prompt(ConversationAction.RUN_SIMULATION, intent_result, readiness, has_operational_data),
        )

    if intent_result.message_kind == MessageKind.DATA_INPUT:
        return ConversationDecision(
            action=ConversationAction.ASK_FOR_DATA,
            intent_result=intent_result,
            confidence=0.9,
            reason="structured_data_input_message",
            next_best_prompt=_next_prompt(ConversationAction.ASK_FOR_DATA, intent_result, readiness, has_operational_data),
        )

    if _asks_for_data(words, lower):
        return ConversationDecision(
            action=ConversationAction.ASK_FOR_DATA,
            intent_result=intent_result,
            confidence=0.9,
            reason="data_roadmap_requested",
            next_best_prompt=_next_prompt(ConversationAction.ASK_FOR_DATA, intent_result, readiness, has_operational_data),
        )

    if _requires_precise_data(intent_result, words) and readiness and not readiness.can_answer_precisely:
        return ConversationDecision(
            action=ConversationAction.ASK_FOR_DATA,
            intent_result=intent_result,
            confidence=0.92,
            reason="precision_guardrail_missing_data",
            should_use_operational_data=True,
            next_best_prompt=_next_prompt(ConversationAction.ASK_FOR_DATA, intent_result, readiness, has_operational_data),
        )

    if has_operational_data and (words & VERTICAL_WORDS):
        return ConversationDecision(
            action=ConversationAction.VERTICAL_ANALYSIS,
            intent_result=intent_result,
            confidence=0.86,
            reason=f"vertical_terms_for_{sector}",
            should_use_operational_data=True,
            next_best_prompt=_next_prompt(ConversationAction.VERTICAL_ANALYSIS, intent_result, readiness, has_operational_data),
        )

    if intent_result.intent in STRATEGIC_INTENTS:
        return ConversationDecision(
            action=ConversationAction.DECISION_PLAYBOOK,
            intent_result=intent_result,
            confidence=max(intent_result.confidence, 0.84),
            reason="strategic_intent",
            should_use_operational_data=has_operational_data,
            next_best_prompt=_next_prompt(ConversationAction.DECISION_PLAYBOOK, intent_result, readiness, has_operational_data),
        )

    return ConversationDecision(
        action=ConversationAction.FALLBACK_ENGINE,
        intent_result=intent_result,
        confidence=intent_result.confidence,
        reason="no_controlled_route",
        should_use_operational_data=has_operational_data,
        next_best_prompt=_next_prompt(ConversationAction.FALLBACK_ENGINE, intent_result, readiness, has_operational_data),
    )


def _looks_like_simulation(words: Set[str], lower: str) -> bool:
    return bool(words & SIMULATION_WORDS) and any(char.isdigit() for char in lower)


def _asks_for_data(words: Set[str], lower: str) -> bool:
    return bool(words & DATA_WORDS) or any(
        phrase in lower
        for phrase in [
            "che dati",
            "quali dati",
            "cosa ti serve",
            "cosa manca",
            "analizzare meglio",
        ]
    )


def _requires_precise_data(intent_result: IntentResult, words: Set[str]) -> bool:
    if intent_result.intent in {CFOIntent.PRODUCT_MARGIN, CFOIntent.PROCUREMENT_BENCHMARK, CFOIntent.CUSTOMER_PROFITABILITY}:
        return True
    return bool(words & VERTICAL_WORDS)


def _next_prompt(
    action: ConversationAction,
    intent_result: IntentResult,
    readiness: Optional[DataCompletenessResult],
    has_operational_data: bool,
) -> str:
    if action == ConversationAction.ASK_FOR_DATA:
        if readiness and readiness.next_questions:
            return readiness.next_questions[0]
        return "Inserisci prodotto/cliente/costo diretto: poi posso calcolare margine reale e priorita'."

    if action == ConversationAction.RUN_SIMULATION:
        return "Vuoi che confronti anche uno scenario conservativo e uno aggressivo?"

    if action == ConversationAction.VERTICAL_ANALYSIS:
        return "Vuoi che trasformi questa analisi in un piano 30/60/90 giorni?"

    if action == ConversationAction.DECISION_PLAYBOOK:
        if intent_result.intent == CFOIntent.GROWTH_STRATEGY:
            return "Vuoi che simuli +5% prezzo, +10% volume e +5% costi variabili?"
        if intent_result.intent == CFOIntent.COST_OPTIMIZATION:
            return "Vuoi che separi tagli sicuri, tagli rischiosi e costi da rinegoziare?"
        if intent_result.intent == CFOIntent.WEAKNESS_DIAGNOSIS:
            return "Vuoi che ordini i punti deboli per impatto economico e urgenza?"
        return "Vuoi che lo trasformi in priorita' settimanali con owner e KPI?"

    if action == ConversationAction.WAR_ROOM:
        return "Vuoi che apra la War Room e ordini le decisioni per impatto, dati mancanti e stop/go?"

    if action == ConversationAction.FAQ_OR_KPI:
        return "Vuoi che colleghi questo KPI a una decisione operativa?"

    if has_operational_data:
        return "Vuoi che analizzi i dati operativi gia' inseriti?"
    return "Vuoi che ti dica quali dati mi servono per rispondere con precisione?"
