"""
CFO Strategic Roadmap Engine - 3-5 year plan with milestones, initiatives, and resource allocation

Generates:
- Phase-based roadmap (discovery, build, scale, mature)
- Key initiatives per phase
- Resource requirements (team, budget)
- Milestones and success metrics
- Risk mitigation
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import date, timedelta


# ============================================
# DATA MODELS
# ============================================

class RoadmapPhase(str, Enum):
    """Strategic roadmap phases"""
    DISCOVERY = "discovery"  # 0-3 months: validate opportunity
    BUILD = "build"  # 3-12 months: develop capability/product
    SCALE = "scale"  # 12-24 months: grow revenue aggressively
    MATURE = "mature"  # 24+ months: optimize and expand


@dataclass
class StrategicInitiative:
    """Single strategic initiative"""
    name: str
    description: str
    phase: str
    starts_month: int
    duration_months: int
    owned_by: str  # Department/person
    
    # Resourcing
    team_size: int  # How many FTE needed
    budget_eur: float  # Annual budget for initiative
    
    # Metrics
    success_metric: str  # KPI to track success
    target_value: float
    unit: str
    
    # Impact
    revenue_impact_eur: float  # Potential revenue contribution (year full run-rate)
    risk_level: str  # "Low", "Medium", "High"
    dependencies: List[str] = None  # Initiatives that must complete first


@dataclass
class RoadmapPhaseDetail:
    """Detailed roadmap phase"""
    phase: RoadmapPhase
    duration_months: int
    start_month: int
    end_month: int
    
    # What we're doing
    initiatives: List[StrategicInitiative]
    
    # Investments
    total_headcount: int
    total_budget_eur: float
    capital_expenditure_eur: float
    
    # Expected outcomes
    revenue_target_eur: float
    key_milestones: List[str]
    
    # Risks and mitigations
    top_risks: List[str]
    mitigations: List[str]


@dataclass
class StrategicRoadmap:
    """5-year strategic roadmap"""
    company_name: str
    mission: str  # 5-year vision statement
    phases: List[RoadmapPhaseDetail]
    
    # Overall financial projections
    year_1_revenue_projection: float
    year_3_revenue_projection: float
    year_5_revenue_projection: float
    
    # Annual breakdown
    annual_budget_allocation: Dict[int, float]  # Year -> Budget
    annual_headcount_plan: Dict[int, int]  # Year -> Headcount


# ============================================
# ROADMAP ENGINE
# ============================================

class RoadmapEngine:
    """Generate 3-5 year strategic roadmap"""
    
    @staticmethod
    def build_roadmap(
        company_name: str,
        current_revenue: float,
        growth_target_pct: float,  # e.g., 100% in 5 years
        ansoff_strategy: str,  # "market_penetration", "product_development", etc
        market_size_eur: float,
        target_market_share_pct: float,
    ) -> StrategicRoadmap:
        """
        Build 5-year strategic roadmap
        
        Args:
            growth_target_pct: Target growth % over 5 years (e.g., 100 for 2x)
            ansoff_strategy: Primary growth strategy
            market_size_eur: TAM (Total Addressable Market)
            target_market_share_pct: Market share goal (%)
        
        Returns:
            StrategicRoadmap with all phases and initiatives
        """
        
        # Calculate year-by-year projections
        target_revenue_5yr = current_revenue * (1 + growth_target_pct / 100)
        cagr_5yr = (target_revenue_5yr / current_revenue) ** (1 / 5) - 1
        
        year_1_revenue = current_revenue * (1 + cagr_5yr)
        year_3_revenue = current_revenue * (1 + cagr_5yr) ** 3
        year_5_revenue = target_revenue_5yr
        
        # Build phases
        phases = []
        
        # PHASE 1: DISCOVERY (Months 1-3)
        discovery_initiatives = [
            StrategicInitiative(
                name="Market Research & Validation",
                description="Validate assumptions about opportunity, competition, customer needs",
                phase="discovery",
                starts_month=1,
                duration_months=3,
                owned_by="Product/Strategy",
                team_size=2,
                budget_eur=50_000,
                success_metric="Research report completed with 50+ customer interviews",
                target_value=50,
                unit="interviews",
                revenue_impact_eur=0,
                risk_level="Low",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Competitive Analysis",
                description="Understand competitive landscape, differentiation opportunities",
                phase="discovery",
                starts_month=1,
                duration_months=3,
                owned_by="Strategy/Marketing",
                team_size=1,
                budget_eur=25_000,
                success_metric="Competitive positioning matrix completed",
                target_value=1,
                unit="analysis",
                revenue_impact_eur=0,
                risk_level="Low",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Business Case & Financial Model",
                description="Build 5-year financial projections for strategy",
                phase="discovery",
                starts_month=2,
                duration_months=2,
                owned_by="Finance/Strategy",
                team_size=1,
                budget_eur=20_000,
                success_metric="Financial model approved by board",
                target_value=1,
                unit="model",
                revenue_impact_eur=0,
                risk_level="Low",
                dependencies=["Market Research & Validation"],
            ),
        ]
        
        phases.append(RoadmapPhaseDetail(
            phase=RoadmapPhase.DISCOVERY,
            duration_months=3,
            start_month=1,
            end_month=3,
            initiatives=discovery_initiatives,
            total_headcount=3,
            total_budget_eur=95_000,
            capital_expenditure_eur=0,
            revenue_target_eur=current_revenue,  # No new revenue yet
            key_milestones=[
                "Market opportunity validated",
                "Competitive positioning clear",
                "Financial model approved",
                "Board alignment on strategy"
            ],
            top_risks=[
                "Market assumptions prove wrong",
                "Competition stronger than expected",
                "Financial projections too optimistic"
            ],
            mitigations=[
                "Deep customer research (not just surveys)",
                "War-game competitive scenarios",
                "Conservative financial assumptions",
                "Monthly board check-ins"
            ],
        ))
        
        # PHASE 2: BUILD (Months 4-12)
        build_initiatives = _generate_build_initiatives(ansoff_strategy, current_revenue)
        
        phases.append(RoadmapPhaseDetail(
            phase=RoadmapPhase.BUILD,
            duration_months=9,
            start_month=4,
            end_month=12,
            initiatives=build_initiatives,
            total_headcount=10,
            total_budget_eur=500_000,
            capital_expenditure_eur=200_000,
            revenue_target_eur=current_revenue * 1.15,  # 15% growth year 1
            key_milestones=[
                "Product/capability built and tested",
                "Pilot customers signed (5-10)",
                "Go-to-market playbook validated",
                "Team in place (sales, product, ops)"
            ],
            top_risks=[
                "Build takes longer than planned",
                "Product doesn't match customer needs",
                "Team hiring delays",
                "Budget overruns"
            ],
            mitigations=[
                "Agile delivery with monthly releases",
                "Customer co-creation (build with, not for)",
                "Start recruiting month 4",
                "Monthly budget tracking"
            ],
        ))
        
        # PHASE 3: SCALE (Months 13-24)
        scale_initiatives = _generate_scale_initiatives(ansoff_strategy, year_1_revenue)
        
        phases.append(RoadmapPhaseDetail(
            phase=RoadmapPhase.SCALE,
            duration_months=12,
            start_month=13,
            end_month=24,
            initiatives=scale_initiatives,
            total_headcount=25,
            total_budget_eur=1_500_000,
            capital_expenditure_eur=500_000,
            revenue_target_eur=year_3_revenue,  # Target end of year 2
            key_milestones=[
                "Revenue ARR $500K+",
                "50+ enterprise customers (if B2B)",
                "Geographic or product expansion launched",
                "Market share gained vs competitors"
            ],
            top_risks=[
                "Growth slower than projected",
                "Churn higher than modeled",
                "Competition responds aggressively",
                "Talent/culture issues at scale"
            ],
            mitigations=[
                "Monthly customer health checks",
                "Product differentiation deepening",
                "Aggressive talent development",
                "Invest in company culture"
            ],
        ))
        
        # PHASE 4: MATURE (Months 25+)
        mature_initiatives = [
            StrategicInitiative(
                name="Operational Excellence",
                description="Optimize unit economics, CAC payback, retention",
                phase="mature",
                starts_month=25,
                duration_months=12,
                owned_by="COO/CFO",
                team_size=5,
                budget_eur=400_000,
                success_metric="Gross margin +5% points, CAC payback <12 months",
                target_value=5.0,
                unit="margin %",
                revenue_impact_eur=100_000,
                risk_level="Low",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Platform/Ecosystem Development",
                description="Build APIs, partner network, ecosystem",
                phase="mature",
                starts_month=25,
                duration_months=12,
                owned_by="VP Product/Partnerships",
                team_size=8,
                budget_eur=600_000,
                success_metric="20+ integrations live, 30% revenue from partners",
                target_value=30.0,
                unit="partner revenue %",
                revenue_impact_eur=300_000,
                risk_level="Medium",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Geographic or Vertical Expansion",
                description="Enter new markets (geography, vertical, customer segment)",
                phase="mature",
                starts_month=28,
                duration_months=12,
                owned_by="VP Sales/Product",
                team_size=10,
                budget_eur=800_000,
                success_metric="New market contributing 20% of revenue",
                target_value=20.0,
                unit="revenue %",
                revenue_impact_eur=500_000,
                risk_level="Medium",
                dependencies=[],
            ),
        ]
        
        phases.append(RoadmapPhaseDetail(
            phase=RoadmapPhase.MATURE,
            duration_months=12,
            start_month=25,
            end_month=36,
            initiatives=mature_initiatives,
            total_headcount=50,
            total_budget_eur=2_500_000,
            capital_expenditure_eur=800_000,
            revenue_target_eur=year_5_revenue,
            key_milestones=[
                "Revenue ARR $5M+",
                "Market leader in segment",
                "Ecosystem/platform live",
                "Potential IPO/acquisition target",
                "Profitability achieved"
            ],
            top_risks=[
                "Market saturation",
                "New competitor disruption",
                "Retention challenges",
                "Talent retention at scale"
            ],
            mitigations=[
                "Continuous innovation",
                "Customer loyalty programs",
                "Stock options refresh for key talent",
                "Regular strategy reassessment"
            ],
        ))
        
        # Build annual budget and headcount plans
        annual_budget = {
            1: phases[0].total_budget_eur + phases[1].total_budget_eur,  # Year 1
            2: phases[1].total_budget_eur + phases[2].total_budget_eur,  # Year 2
            3: phases[2].total_budget_eur + phases[3].total_budget_eur,  # Year 3
            4: phases[3].total_budget_eur,
            5: phases[3].total_budget_eur * 1.1,
        }
        
        annual_headcount = {
            1: 10,
            2: 20,
            3: 40,
            4: 60,
            5: 80,
        }
        
        mission = f"Grow revenue to €{target_revenue_5yr:,.0f} (+{growth_target_pct:.0f}%) by scaling {ansoff_strategy.replace('_', ' ')}, targeting {target_market_share_pct:.0f}% market share"
        
        return StrategicRoadmap(
            company_name=company_name,
            mission=mission,
            phases=phases,
            year_1_revenue_projection=year_1_revenue,
            year_3_revenue_projection=year_3_revenue,
            year_5_revenue_projection=year_5_revenue,
            annual_budget_allocation=annual_budget,
            annual_headcount_plan=annual_headcount,
        )


def _generate_build_initiatives(ansoff_strategy: str, current_revenue: float) -> List[StrategicInitiative]:
    """Generate BUILD phase initiatives based on Ansoff strategy"""
    
    initiatives = []
    
    if ansoff_strategy == "market_penetration":
        initiatives = [
            StrategicInitiative(
                name="Sales Productivity Program",
                description="Improve sales team efficiency, process, tooling",
                phase="build",
                starts_month=4,
                duration_months=6,
                owned_by="VP Sales",
                team_size=3,
                budget_eur=150_000,
                success_metric="Sales cycle reduced by 25%, close rate +15%",
                target_value=25.0,
                unit="cycle days reduction %",
                revenue_impact_eur=200_000,
                risk_level="Low",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Marketing Campaign Overhaul",
                description="New messaging, channels, ICP targeting",
                phase="build",
                starts_month=4,
                duration_months=9,
                owned_by="VP Marketing",
                team_size=4,
                budget_eur=200_000,
                success_metric="CAC -30%, conversion rate +40%",
                target_value=30.0,
                unit="CAC reduction %",
                revenue_impact_eur=300_000,
                risk_level="Medium",
                dependencies=[],
            ),
        ]
    
    elif ansoff_strategy == "product_development":
        initiatives = [
            StrategicInitiative(
                name="New Product Development",
                description="Build product for existing customer base",
                phase="build",
                starts_month=4,
                duration_months=9,
                owned_by="VP Product",
                team_size=5,
                budget_eur=250_000,
                success_metric="MVP launched, 10 alpha customers",
                target_value=10,
                unit="alpha customers",
                revenue_impact_eur=150_000,
                risk_level="High",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Cross-Sell Program",
                description="Enable account teams to sell new product to existing customers",
                phase="build",
                starts_month=7,
                duration_months=6,
                owned_by="VP Sales",
                team_size=2,
                budget_eur=100_000,
                success_metric="20% of existing customers upgrade",
                target_value=20.0,
                unit="upgrade %",
                revenue_impact_eur=250_000,
                risk_level="Low",
                dependencies=["New Product Development"],
            ),
        ]
    
    elif ansoff_strategy == "market_development":
        initiatives = [
            StrategicInitiative(
                name="Geographic Expansion (New Country)",
                description="Set up in new geography with local team",
                phase="build",
                starts_month=4,
                duration_months=12,
                owned_by="VP Sales",
                team_size=4,
                budget_eur=300_000,
                success_metric="Local team hired, first customers signed",
                target_value=5,
                unit="customers",
                revenue_impact_eur=200_000,
                risk_level="Medium",
                dependencies=[],
            ),
            StrategicInitiative(
                name="Localization & Compliance",
                description="Adapt product, legal, operations for new market",
                phase="build",
                starts_month=4,
                duration_months=6,
                owned_by="Product/Legal/Ops",
                team_size=3,
                budget_eur=150_000,
                success_metric="Product localized, legal compliance done",
                target_value=1,
                unit="market",
                revenue_impact_eur=0,
                risk_level="Medium",
                dependencies=[],
            ),
        ]
    
    else:  # diversification or default
        initiatives = [
            StrategicInitiative(
                name="Acquisition or Partnership",
                description="Acquire or partner with company in new market/product",
                phase="build",
                starts_month=4,
                duration_months=6,
                owned_by="CEO/Strategy",
                team_size=2,
                budget_eur=100_000,
                success_metric="Deal closed",
                target_value=1,
                unit="deal",
                revenue_impact_eur=500_000,
                risk_level="High",
                dependencies=[],
            ),
        ]
    
    return initiatives


def _generate_scale_initiatives(ansoff_strategy: str, current_revenue: float) -> List[StrategicInitiative]:
    """Generate SCALE phase initiatives"""
    
    # Common scale initiatives
    initiatives = [
        StrategicInitiative(
            name="Customer Success & Retention",
            description="Build CS team, playbooks, tech to reduce churn",
            phase="scale",
            starts_month=13,
            duration_months=12,
            owned_by="VP Customer Success",
            team_size=6,
            budget_eur=400_000,
            success_metric="Churn reduced to <5%, NRR >120%",
            target_value=5.0,
            unit="churn %",
            revenue_impact_eur=300_000,
            risk_level="Low",
            dependencies=[],
        ),
        StrategicInitiative(
            name="Upsell & Expansion Revenue",
            description="Build playbooks to expand within existing customers",
            phase="scale",
            starts_month=13,
            duration_months=12,
            owned_by="VP Sales/CS",
            team_size=3,
            budget_eur=200_000,
            success_metric="25% of revenue from upsell/expansion",
            target_value=25.0,
            unit="expansion %",
            revenue_impact_eur=500_000,
            risk_level="Low",
            dependencies=[],
        ),
        StrategicInitiative(
            name="Data & Analytics Platform",
            description="Build data infrastructure, dashboards, insights",
            phase="scale",
            starts_month=13,
            duration_months=12,
            owned_by="VP Engineering/Data",
            team_size=4,
            budget_eur=300_000,
            success_metric="Self-service dashboards live, data-driven decisions",
            target_value=1,
            unit="platform",
            revenue_impact_eur=200_000,
            risk_level="Medium",
            dependencies=[],
        ),
    ]
    
    return initiatives
