# -*- coding: utf-8 -*-
# content/core/pricing.py — Ottimizzazione prezzo & ladder con elasticità costante
from __future__ import annotations
from typing import Dict, Any, List, Tuple
import math

def _num(x, d=0.0) -> float:
    try:
        return float(x if x is not None else d)
    except Exception:
        return d

def _safe_qty(fatturato: float, prezzo: float) -> float:
    if prezzo > 0.0:
        return max(0.0, fatturato / prezzo)
    return 0.0

def _quantity_with_elasticity(q0: float, dp: float, elasticity: float) -> float:
    """q1 = q0 * (1 + e*dp), con dp espresso in frazione (es. +3% → 0.03)."""
    q1 = q0 * (1.0 + elasticity * dp)
    return max(0.0, q1)

def _profit(price: float, qty: float, cvu: float, cf: float) -> float:
    revenue = price * qty
    var_cost = cvu * qty
    return revenue - var_cost - cf

def price_ladder(
    base: Dict[str, float],
    pct_min: float,
    pct_max: float,
    pct_step: float,
) -> Tuple[List[Dict[str, float]], Dict[str, float], Dict[str, Any]]:
    """
    Costruisce la ladder da pct_min..pct_max (step in pp), e identifica il best.
    Assumptions restituisce: elasticity, price_base, quantity_base.
    """
    fatt = _num(base.get("fatturato"))
    cf   = _num(base.get("costi_fissi"))
    price0 = _num(base.get("prezzo_medio"))
    cvu  = _num(base.get("costo_variabile_unitario"))
    e    = float(base.get("price_elasticity", -1.2))

    qty0 = _num(base.get("quantity"))
    if qty0 <= 0.0:
        qty0 = _safe_qty(fatt, price0)

    # Normalizza range/step
    pmin, pmax, step = float(pct_min), float(pct_max), float(pct_step)
    if step <= 0:
        step = 1.0
    if pmin > pmax:
        pmin, pmax = pmax, pmin

    rows: List[Dict[str, float]] = []
    best = {"pct": 0.0, "price": price0, "quantity": qty0, "revenue": price0 * qty0, "profit": _profit(price0, qty0, cvu, cf)}

    # build grid inclusiva
    n_steps = int(round((pmax - pmin) / step))
    grid = [pmin + i * step for i in range(n_steps + 1)]
    if grid[-1] < pmax - 1e-9:
        grid.append(pmax)

    for pct in grid:
        dp = pct / 100.0
        p1 = price0 * (1.0 + dp)
        q1 = _quantity_with_elasticity(qty0, dp, e)
        rev = p1 * q1
        prf = _profit(p1, q1, cvu, cf)
        row = {"pct": float(pct), "price": p1, "quantity": q1, "revenue": rev, "profit": prf}
        rows.append(row)
        if prf > best["profit"]:
            best = row

    assumptions = {
        "price_elasticity": e,
        "price_base": price0,
        "quantity_base": qty0,
        "explored_pct": {"min": pmin, "max": pmax, "step": step},
        "model": "constant_elasticity",
    }
    return rows, best, assumptions

def optimize_price(base: Dict[str, float]) -> Tuple[Dict[str, float], Dict[str, Any]]:
    """
    Trova il best con una griglia 'fine' (default: -30..+30 step 0.5pp).
    """
    rows, best, assumptions = price_ladder(base, pct_min=-30.0, pct_max=30.0, pct_step=0.5)
    assumptions["grid"] = "fine(-30..+30 step 0.5)"
    return {
        "best_pct": best["pct"],
        "best_price": best["price"],
        "best_profit": best["profit"],
    }, assumptions
