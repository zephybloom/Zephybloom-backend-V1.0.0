"""
Answer policy for CFO AI responses.

The deterministic CFO engine is the source of truth. This module checks that
generative answers do not contradict the financial diagnosis, and can build a
safe fallback answer from the structured insight pack.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from infra.ai_provider import CFOAnalysisAI


@dataclass
class AnswerValidation:
    """Result of validating an AI answer against deterministic CFO insight."""

    is_valid: bool
    warnings: List[str] = field(default_factory=list)
    blocked_terms: List[str] = field(default_factory=list)
    confidence_adjustment: float = 0.0


SURVIVAL_TERMS = (
    "stabil",
    "margine",
    "profit",
    "costi",
    "cash",
    "cassa",
    "turnaround",
    "break-even",
    "pareggio",
)

AGGRESSIVE_GROWTH_PATTERNS = (
    r"\bscal\w*\s+aggressiv",
    r"\bcresc\w*\s+aggressiv",
    r"\bespansion\w*\s+aggressiv",
    r"\bacquisire\s+clienti\s+a\s+tutti\s+i\s+costi",
    r"\bgrowth\s+at\s+all\s+costs",
)


def validate_cfo_answer(
    answer: CFOAnalysisAI,
    insight: Dict[str, Any],
) -> AnswerValidation:
    """Validate an AI answer against the CFO insight pack."""

    text = _answer_text(answer)
    lower_text = text.lower()
    warnings: List[str] = []
    blocked_terms: List[str] = []
    hard_failures: List[str] = []

    primary_constraint = insight.get("primary_constraint", {}).get("type")
    posture = insight.get("strategic_posture")
    health_label = insight.get("health_label")

    if posture == "stabilize" or primary_constraint == "profitability":
        for pattern in AGGRESSIVE_GROWTH_PATTERNS:
            match = re.search(pattern, lower_text)
            if match:
                blocked_terms.append(match.group(0))
        if not any(term in lower_text for term in SURVIVAL_TERMS):
            hard_failures.append("Critical/profitability case must mention stabilization, margin, profit, costs, or cash.")

    if primary_constraint == "unit_economics" and not any(
        term in lower_text for term in ("unit economic", "gross margin", "margine lordo", "prezz", "cogs", "contribution")
    ):
        hard_failures.append("Unit economics constraint is not reflected in the answer.")

    if primary_constraint == "cash_cycle" and not any(
        term in lower_text for term in ("cash", "cassa", "dso", "dio", "dpo", "incass", "magazzino", "working capital")
    ):
        hard_failures.append("Cash cycle constraint is not reflected in the answer.")

    if posture == "scale_selectively" and _sounds_like_crisis(lower_text):
        warnings.append("Healthy company answer uses crisis language.")

    if health_label and health_label.lower() not in lower_text:
        warnings.append("Health label is not explicitly carried into the answer.")

    return AnswerValidation(
        is_valid=not blocked_terms and not hard_failures,
        warnings=hard_failures + warnings,
        blocked_terms=blocked_terms,
        confidence_adjustment=-0.12 if (hard_failures or warnings) else 0.0,
    )


def build_safe_cfo_answer(
    insight: Dict[str, Any],
    base_analysis: Dict[str, Any],
    specific_question: Optional[str] = None,
) -> CFOAnalysisAI:
    """Build a deterministic fallback answer from validated CFO data."""

    primary = insight.get("primary_constraint", {})
    next_move = insight.get("next_best_move", {})
    capital = insight.get("capital_efficiency", {})
    benchmark_gaps = insight.get("benchmark_gaps", [])
    kpi = base_analysis.get("kpi_snapshot", {})

    key_number = _key_number(kpi, benchmark_gaps)
    diagnostic = (
        f"{insight.get('health_label', 'Needs CFO review')}: "
        f"{primary.get('summary', 'Financial model requires review')}"
    )
    if specific_question:
        diagnostic += f" Domanda trattata: {specific_question}"

    risk = (
        f"Finestra rischio: {primary.get('risk_window', 'da verificare')}. "
        f"ROI attuale {capital.get('roi_pct', 'N/A')}%, target settore {capital.get('target_roi_pct', 'N/A')}%."
    )

    actions = [
        f"Monitorare {metric}" for metric in insight.get("watch_metrics", [])[:3]
    ]
    if not actions:
        actions = ["Aggiornare i dati CFO chiave", "Ricalcolare benchmark", "Validare priorita operative"]

    return CFOAnalysisAI(
        key_number=key_number,
        headline=f"{insight.get('health_label', 'CFO review')}: {next_move.get('focus', 'financial focus')}",
        diagnostic=diagnostic,
        risk_assessment=risk,
        priority_action=next_move.get("move", "Improve profitability."),
        other_actions=actions,
        estimated_impact=_estimated_impact(base_analysis),
        why_it_matters=(
            "La raccomandazione deriva dal motore CFO deterministico: KPI, benchmark e vincolo principale "
            "sono allineati prima della narrazione."
        ),
        strategic_advice=(
            f"Postura consigliata: {insight.get('strategic_posture', 'review')}. "
            f"Azione di supporto: {next_move.get('supporting_action', 'Improve profitability')}."
        ),
    )


def _answer_text(answer: CFOAnalysisAI) -> str:
    return " ".join(
        [
            answer.key_number or "",
            answer.headline or "",
            answer.diagnostic or "",
            answer.risk_assessment or "",
            answer.priority_action or "",
            " ".join(answer.other_actions or []),
            answer.estimated_impact or "",
            answer.why_it_matters or "",
            answer.strategic_advice or "",
        ]
    )


def _sounds_like_crisis(text: str) -> bool:
    return any(term in text for term in ("crisi", "critico", "sopravvivenza", "turnaround urgente", "fallimento"))


def _key_number(kpi: Dict[str, Any], benchmark_gaps: List[Dict[str, Any]]) -> str:
    net_margin = kpi.get("net_margin_pct")
    gross_margin = kpi.get("gross_margin_pct")
    if benchmark_gaps:
        main_gap = max(benchmark_gaps, key=lambda gap: abs(gap.get("gap_to_median_points", 0)))
        return (
            f"{main_gap['metric']}: {main_gap['current_pct']}% "
            f"vs mediana settore {main_gap['median_pct']}%"
        )
    if net_margin is not None:
        return f"Net margin: {net_margin:.1f}%"
    if gross_margin is not None:
        return f"Gross margin: {gross_margin:.1f}%"
    return "KPI CFO da completare"


def _estimated_impact(base_analysis: Dict[str, Any]) -> str:
    recovery = base_analysis.get("potential_recovery_eur")
    loss = base_analysis.get("estimated_loss_eur")
    if recovery is not None:
        return f"Recovery potenziale stimata dal motore: EUR {recovery:,.0f}"
    if loss is not None:
        return f"Rischio stimato se non si interviene: EUR {loss:,.0f}"
    return "Impatto da stimare con scenario dedicato."
