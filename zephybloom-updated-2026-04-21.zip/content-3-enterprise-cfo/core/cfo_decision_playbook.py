"""CFO Decision Playbook.

Turns company data and intent into an execution plan: what to do, why, in what
order, which KPI to watch, and which simulation to run next.
"""

from typing import Any, Dict, List, Optional

from core.cfo_intent_router import CFOIntent, route_cfo_intent
from core.company_operating_model import build_company_operating_model


def build_decision_playbook(
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    active_sector: Optional[str] = None,
    question: Optional[str] = None,
) -> Dict[str, Any]:
    """Build a deterministic CFO action playbook."""

    operating_model = build_company_operating_model(
        company_data=company_data or {},
        operational_data_by_sector=operational_data_by_sector or {},
        active_sector=active_sector,
    )
    intent = route_cfo_intent(question or "")
    selected_intent = intent.intent if intent.intent != CFOIntent.UNKNOWN else _infer_intent_from_model(operating_model)
    sector = operating_model.get("active_sector") or "default"

    if selected_intent == CFOIntent.GROWTH_STRATEGY:
        plan = _growth_playbook(operating_model, sector)
    elif selected_intent == CFOIntent.COST_OPTIMIZATION:
        plan = _cost_playbook(operating_model, sector)
    elif selected_intent == CFOIntent.PRODUCT_MARGIN:
        plan = _product_margin_playbook(operating_model, sector)
    elif selected_intent == CFOIntent.WEAKNESS_DIAGNOSIS:
        plan = _weakness_playbook(operating_model, sector)
    elif selected_intent == CFOIntent.PROCUREMENT_BENCHMARK:
        plan = _procurement_playbook(operating_model, sector)
    else:
        plan = _general_playbook(operating_model, sector)

    return {
        "version": "cfo-decision-playbook-v1",
        "intent": selected_intent.value,
        "intent_confidence": intent.confidence,
        "sector": sector,
        "data_quality": operating_model["data_quality"],
        "operating_readiness_pct": operating_model["overall_readiness_pct"],
        "decision": plan,
        "operating_model_summary": {
            "next_questions": operating_model["next_questions"][:5],
            "signals": operating_model["cfo_signals"][:4],
            "missing_entities": operating_model["data_quality"]["missing_entities"][:6],
        },
        "premium_outputs": {
            "actions_30_60_90": True,
            "kpi_control_plan": True,
            "risk_and_inaction": True,
            "simulation_recommendation": True,
            "owner_recommendation": True,
        },
    }


def _growth_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    sector_actions = {
        "restaurant": [
            "Segmenta il menu per margine, velocita' cucina e domanda reale.",
            "Crea 3 offerte: entry, consigliata e premium senza basarti solo su sconti.",
            "Aumenta coperti solo nelle fasce dove personale e cucina non creano sprechi.",
        ],
        "ecommerce": [
            "Scala solo SKU con margine contributivo positivo dopo CAC, resi e spedizione.",
            "Sposta budget dai canali con CAC sopra break-even ai canali profittevoli.",
            "Testa bundle e aumento AOV prima di aumentare budget ads.",
        ],
        "construction": [
            "Accetta nuove commesse solo se SAL, incassi e varianti sono contrattualizzati.",
            "Dai priorita' a lavori con cash gap basso e margine protetto.",
            "Blocca crescita se il WIP non fatturato sta assorbendo cassa.",
        ],
    }
    sector_kpis = {
        "restaurant": ["fatturato", "margine netto", "food cost", "prime cost", "coperti", "ticket medio"],
        "ecommerce": ["fatturato", "margine netto", "CAC", "break-even CAC", "ROAS", "return rate"],
        "construction": ["fatturato", "margine atteso", "cash gap", "WIP non fatturato", "SAL incassato"],
    }
    return _plan(
        title="Crescita disciplinata",
        priority="high",
        decision="Cresci solo dove ogni euro di fatturato mantiene margine e cassa.",
        why="Il rischio premium non e' non crescere: e' comprare ricavi che abbassano utile, cassa o capacita' operativa.",
        actions_30=sector_actions.get(sector, [
            "Dividi clienti/prodotti/canali in alta, media e bassa redditivita'.",
            "Spingi solo segmenti dove margine e incasso sono difendibili.",
            "Definisci un test di crescita con stop-loss su margine netto.",
        ]),
        actions_60=[
            "Rialloca budget commerciale sui canali con margine migliore.",
            "Costruisci una dashboard settimanale su ricavi, margine e cassa.",
            "Rimuovi offerte o clienti che crescono volume ma distruggono utile.",
        ],
        actions_90=[
            "Standardizza il processo commerciale che ha prodotto crescita sana.",
            "Assumi o automatizza solo dopo aver validato payback e capacita'.",
            "Crea un piano trimestrale con obiettivi per margine, cassa e ricavi.",
        ],
        kpis=sector_kpis.get(sector, ["fatturato", "margine netto", "gross margin", "cash conversion", "ROI"]),
        simulation="+5% prezzo, +10% volume, +5% costi variabili",
        owner="CEO + Responsabile vendite",
        economic_impact="Incremento utile stimabile solo dopo segmentazione; primo target: +3/+8 punti di margine sui ricavi incrementali.",
        risk="Crescere su canali/clienti sbagliati puo' aumentare fatturato e ridurre cassa.",
        inaction_cost="Se non separi crescita sana da crescita tossica, il fatturato puo' salire mentre utile e liquidita' peggiorano.",
    )


def _cost_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    return _plan(
        title="Riduzione costi senza danneggiare crescita",
        priority="high",
        decision="Taglia prima costi non strategici e costi variabili negoziabili, non capacita' commerciale sana.",
        why="Il taglio giusto aumenta utile; il taglio cieco riduce qualita', domanda o velocita' operativa.",
        actions_30=[
            "Classifica costi in: essenziali, negoziabili, eliminabili.",
            "Rinegozia i primi 5 fornitori per spesa annua o impatto sul margine.",
            "Blocca costi ricorrenti senza owner, KPI o utilita' chiara.",
        ],
        actions_60=[
            "Sposta budget marketing verso canali con CAC/margine migliore.",
            "Automatizza attivita' ripetitive prima di assumere nuovo personale.",
            "Crea soglie di approvazione per nuovi costi fissi.",
        ],
        actions_90=[
            "Ridisegna il conto economico per centro di costo o linea prodotto.",
            "Crea benchmark fornitori e alternative negoziali.",
            "Trasforma risparmi ricorrenti in cassa o investimenti ad alto ROI.",
        ],
        kpis=["costi variabili %", "costi fissi", "margine lordo", "EBITDA margin", "cash runway"],
        simulation="-5% costi variabili, -5% costi fissi, ricavi invariati",
        owner="CFO/Founder + Operations",
        economic_impact="Obiettivo iniziale: recuperare 2-5% del fatturato in utile senza frenare vendite.",
        risk="Tagliare costi che proteggono qualita', vendita o incasso puo' peggiorare il business.",
        inaction_cost="Costi fissi e fornitori non controllati aumentano il break-even e riducono margine di sicurezza.",
    )


def _product_margin_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    sector_specific = {
        "restaurant": "Ricalcola prezzo target per piatto usando ingredienti, ricetta, sprechi e tempo cucina.",
        "ecommerce": "Classifica SKU per contributo dopo acquisto, spedizione, fee, resi e CAC.",
        "construction": "Classifica commesse per margine atteso, WIP, SAL, incassi e varianti.",
    }
    return _plan(
        title="Margine per prodotto/servizio",
        priority="high",
        decision="Spingi solo cio' che crea contributo reale dopo costi diretti, cassa e capacita'.",
        why="Non tutti i ricavi valgono uguale: prodotto, cliente o commessa sbagliata possono assorbire cassa e tempo.",
        actions_30=[
            sector_specific.get(sector, "Calcola prezzo, costo diretto, volume e margine per prodotto/servizio."),
            "Separa top performer, medi e prodotti da correggere.",
            "Definisci prezzo minimo e margine target per ogni linea.",
        ],
        actions_60=[
            "Rivedi bundle, sconti e mix vendita per aumentare margine medio.",
            "Rinegozia i costi diretti dei prodotti con maggior volume.",
            "Togli focus commerciale da prodotti con volume alto ma contributo basso.",
        ],
        actions_90=[
            "Costruisci una policy di pricing per evitare vendite sotto soglia.",
            "Aggiorna listino e offerte commerciali in base a margine e domanda.",
            "Controlla mensilmente variazioni costo unitario e margine.",
        ],
        kpis=["margine per prodotto", "contributo unitario", "volume", "prezzo medio", "costo unitario"],
        simulation="+5% prezzo sui prodotti top, -3% costo unitario, -10% prodotti basso margine",
        owner="CEO + Commerciale + Operations",
        economic_impact="Target: spostare mix verso prodotti con margine superiore e recuperare 3-10 punti di contribuzione.",
        risk="Vendere di piu' prodotti sbagliati aumenta complessita' senza aumentare utile.",
        inaction_cost="Senza margine per prodotto continuerai a confondere fatturato con profitto.",
    )


def _weakness_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    weakest = _weakest_area(model)
    return _plan(
        title="Diagnosi punti deboli",
        priority="medium",
        decision=f"Parti dall'area piu' debole: {weakest}.",
        why="Un CFO non corregge tutto insieme: trova il vincolo principale e lo sblocca prima.",
        actions_30=[
            f"Completa dati e KPI dell'area {weakest}.",
            "Confronta margine, cassa e capacita' operativa prima/dopo intervento.",
            "Definisci una sola metrica di successo per la settimana.",
        ],
        actions_60=[
            "Collega il punto debole a una causa: prezzo, costo, volume, personale, cassa o mix.",
            "Esegui due simulazioni alternative e scegli quella con miglior rapporto rischio/impatto.",
            "Trasforma la correzione in processo ricorrente.",
        ],
        actions_90=[
            "Crea rituale mensile CFO: dati, diagnosi, decisione, follow-up.",
            "Misura se la decisione presa ha migliorato KPI e cassa.",
            "Aggiorna budget e obiettivi in base ai risultati.",
        ],
        kpis=["data quality", "margine netto", "cash gap", "ROI", "trend mensile"],
        simulation="scenario migliore vs scenario conservativo sul vincolo principale",
        owner="Founder/CEO",
        economic_impact="Impatto da stimare dopo aver completato il dato del vincolo principale.",
        risk="Intervenire su troppe aree insieme diluisce focus e rende impossibile capire cosa funziona.",
        inaction_cost="Il punto debole continuera' a limitare crescita anche se aumenti fatturato.",
    )


def _procurement_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    return _plan(
        title="Fornitori e costo merce",
        priority="high",
        decision="Rinegozia dove hai volume, alternative e impatto diretto sul margine.",
        why="I fornitori incidono subito su food cost, costo prodotto, materiali e margine commessa.",
        actions_30=[
            "Ordina fornitori per spesa annua, criticita' e possibilita' di alternativa.",
            "Calcola impatto di -3/-5/-8% sui primi fornitori.",
            "Chiedi listini alternativi senza compromettere qualita' o continuita'.",
        ],
        actions_60=[
            "Contratta termini di pagamento migliori dove il cash gap e' critico.",
            "Accorpa volumi sui fornitori migliori e sostituisci quelli fuori benchmark.",
            "Crea controllo mensile variazione prezzi.",
        ],
        actions_90=[
            "Definisci una supplier scorecard: prezzo, qualita', puntualita', termini.",
            "Costruisci doppia fonte per materiali/prodotti critici.",
            "Integra costo fornitore nel prezzo target e nella marginalita'.",
        ],
        kpis=["costo unitario", "gross margin", "termini pagamento", "spesa fornitore", "variazione prezzo"],
        simulation="-5% costo fornitore, +15 giorni DPO, stesso volume",
        owner="Operations/Procurement",
        economic_impact="Obiettivo iniziale: recuperare 1-4% del fatturato in margine lordo sui costi negoziabili.",
        risk="Cambiare fornitore solo per prezzo puo' creare difetti, ritardi e perdita clienti.",
        inaction_cost="Listini non controllati mangiano margine lentamente e rendono i prezzi target sbagliati.",
    )


def _general_playbook(model: Dict[str, Any], sector: str) -> Dict[str, Any]:
    if model["data_quality"]["score_pct"] < 55:
        return _plan(
            title="Prima precisione dati, poi decisioni",
            priority="high",
            decision="Completa i dati operativi prima di prendere decisioni definitive.",
            why=model["data_quality"]["answer_policy"],
            actions_30=model["next_questions"][:3] or ["Completa dati prodotti, costi, clienti e cassa."],
            actions_60=[
                "Collega dati raccolti a margine, cassa e capacita' operativa.",
                "Costruisci dashboard minima dei KPI che cambiano decisioni.",
                "Rifai War Room con dati aggiornati.",
            ],
            actions_90=[
                "Crea storico mensile e confronta trend.",
                "Definisci playbook ricorrenti per crescita, costi e cassa.",
                "Prepara report CFO mensile.",
            ],
            kpis=["data quality", "readiness dati", "margine netto", "cassa", "ROI"],
            simulation="nessuna simulazione fine finche' mancano dati critici",
            owner="Founder/CEO",
            economic_impact="Aumenta precisione decisionale; impatto economico da calcolare dopo raccolta dati.",
            risk="Decisioni con dati parziali possono sembrare corrette ma colpire il vincolo sbagliato.",
            inaction_cost="Il CFO resta generico e il prodotto perde valore percepito.",
        )
    return _growth_playbook(model, sector)


def _plan(
    title: str,
    priority: str,
    decision: str,
    why: str,
    actions_30: List[str],
    actions_60: List[str],
    actions_90: List[str],
    kpis: List[str],
    simulation: str,
    owner: str,
    economic_impact: str,
    risk: str,
    inaction_cost: str,
) -> Dict[str, Any]:
    return {
        "title": title,
        "priority": priority,
        "decision": decision,
        "why": why,
        "economic_impact": economic_impact,
        "owner": owner,
        "timeframe": "30/60/90 giorni",
        "actions": {
            "30_days": actions_30,
            "60_days": actions_60,
            "90_days": actions_90,
        },
        "kpis_to_monitor": kpis,
        "risk": risk,
        "cost_of_inaction": inaction_cost,
        "recommended_simulation": simulation,
    }


def _infer_intent_from_model(model: Dict[str, Any]) -> CFOIntent:
    data_quality = model.get("data_quality", {})
    if data_quality.get("score_pct", 0) < 55:
        return CFOIntent.WEAKNESS_DIAGNOSIS
    signals = model.get("cfo_signals", [])
    if any(signal.get("type") == "data_gap" for signal in signals):
        return CFOIntent.WEAKNESS_DIAGNOSIS
    return CFOIntent.GROWTH_STRATEGY


def _weakest_area(model: Dict[str, Any]) -> str:
    sections = model.get("section_readiness") or []
    if not sections:
        return "dati operativi"
    weakest = sorted(sections, key=lambda item: item.get("coverage_pct", 0))[0]
    return weakest.get("label", "dati operativi")
