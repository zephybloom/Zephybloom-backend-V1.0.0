"""
Business model schema for the premium CFO data foundation.

This layer defines the operational data the CFO needs before giving precise
sector-specific advice. It keeps the product from inventing answers when the
right inputs are missing.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class DataField:
    """Single field requested by a sector adapter."""

    key: str
    label: str
    category: str
    why_needed: str
    example: Optional[str] = None
    unit: Optional[str] = None


@dataclass(frozen=True)
class SectorAdapterSpec:
    """Complete data and logic profile for a business sector."""

    sector: str
    name: str
    description: str
    required_fields: List[DataField]
    optional_fields: List[DataField] = field(default_factory=list)
    key_kpis: List[str] = field(default_factory=list)
    decision_rules: List[str] = field(default_factory=list)
    simulation_templates: List[str] = field(default_factory=list)
    supported_questions: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class MissingField:
    """Missing field with business context."""

    key: str
    label: str
    category: str
    why_needed: str
    example: Optional[str] = None
    unit: Optional[str] = None


@dataclass(frozen=True)
class DataCompletenessResult:
    """Data-readiness result for a company/sector."""

    sector: str
    sector_name: str
    required_total: int
    required_present: int
    optional_total: int
    optional_present: int
    required_coverage_pct: float
    optional_coverage_pct: float
    answer_precision_pct: float
    readiness_level: str
    missing_required: List[MissingField]
    missing_optional: List[MissingField]
    next_questions: List[str]
    can_answer_precisely: bool
    key_kpis: List[str]
    decision_rules: List[str]
    simulation_templates: List[str]
    supported_questions: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sector": self.sector,
            "sector_name": self.sector_name,
            "required_total": self.required_total,
            "required_present": self.required_present,
            "optional_total": self.optional_total,
            "optional_present": self.optional_present,
            "required_coverage_pct": self.required_coverage_pct,
            "optional_coverage_pct": self.optional_coverage_pct,
            "answer_precision_pct": self.answer_precision_pct,
            "readiness_level": self.readiness_level,
            "missing_required": [field.__dict__ for field in self.missing_required],
            "missing_optional": [field.__dict__ for field in self.missing_optional],
            "next_questions": self.next_questions,
            "can_answer_precisely": self.can_answer_precisely,
            "key_kpis": self.key_kpis,
            "decision_rules": self.decision_rules,
            "simulation_templates": self.simulation_templates,
            "supported_questions": self.supported_questions,
        }
