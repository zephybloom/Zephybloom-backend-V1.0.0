"""Company Operating Model for CFO-grade analysis.

The operating model is the shared company memory the vertical calculators,
War Room and chat can use before giving advice. It combines universal company
data with sector-specific operational data and turns both into CFO signals.
"""

from typing import Any, Dict, List, Optional, Tuple

from core.data_requirements import assess_data_completeness


UNIVERSAL_SECTIONS = {
    "financials": {
        "label": "Finanza base",
        "fields": ["annual_revenue", "variable_costs", "fixed_costs", "invested_capital", "cash_on_hand"],
    },
    "people": {
        "label": "Personale",
        "fields": ["staff_roles", "employee_count", "payroll_costs", "role_productivity", "contract_types"],
    },
    "products": {
        "label": "Prodotti e servizi",
        "fields": ["products", "services", "menu_items", "sku_sales", "projects", "unit_costs", "unit_prices"],
    },
    "suppliers": {
        "label": "Fornitori e costo merce",
        "fields": ["suppliers", "ingredient_costs", "purchase_costs", "materials_cost", "supplier_terms", "supplier_prices"],
    },
    "sales": {
        "label": "Vendite e canali",
        "fields": ["sales_channels", "average_ticket", "average_order_value", "monthly_orders", "conversion_rate", "cac_by_channel"],
    },
    "cash": {
        "label": "Cassa e incassi",
        "fields": ["cash_on_hand", "payment_terms_days", "receivables", "payables", "billed_pct", "collected_pct"],
    },
    "customers": {
        "label": "Clienti",
        "fields": ["customers", "customer_segments", "repeat_rate", "churn_rate", "customer_margin"],
    },
    "inventory": {
        "label": "Stock e magazzino",
        "fields": ["inventory", "stock_value", "stock_turnover", "waste_rate", "stockouts"],
    },
    "recurring_costs": {
        "label": "Costi ricorrenti",
        "fields": ["recurring_costs", "software_costs", "rent_costs", "utilities_costs", "insurance_costs"],
    },
}


ENTITY_ALIASES = {
    "customers": ["customers", "clienti", "customer_segments", "customer_margin"],
    "suppliers": ["suppliers", "fornitori", "supplier_prices", "supplier_terms"],
    "products": ["products", "prodotti", "services", "menu_items", "sku_sales", "projects"],
    "staff_roles": ["staff_roles", "personale", "employees", "payroll_costs"],
    "sales_channels": ["sales_channels", "canali", "channels", "cac_by_channel"],
    "inventory": ["inventory", "magazzino", "stock_value", "stock_turnover"],
    "payment_terms": ["payment_terms_days", "receivables", "payables", "dso_days", "dpo_days"],
    "recurring_costs": ["recurring_costs", "software_costs", "rent_costs", "utilities_costs"],
}


DATA_QUALITY_WEIGHTS = {
    "financials": 18,
    "products": 16,
    "suppliers": 13,
    "people": 12,
    "sales": 12,
    "cash": 11,
    "customers": 8,
    "inventory": 6,
    "recurring_costs": 4,
}


def build_company_operating_model(
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    active_sector: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the normalized operating model and CFO data roadmap."""

    normalized_company = _normalize_company_data(company_data or {})
    sector_payloads = operational_data_by_sector or {}
    selected_sector = _normalize_sector(active_sector or normalized_company.get("sector"))

    sector_models = [
        _build_sector_model(sector, data)
        for sector, data in sector_payloads.items()
    ]
    sector_models.sort(key=lambda item: item["priority_score"], reverse=True)

    active_sector_model = next(
        (item for item in sector_models if item["sector"] == selected_sector),
        None,
    )
    if not active_sector_model and selected_sector:
        active_sector_model = _build_sector_model(selected_sector, normalized_company)
        sector_models.append(active_sector_model)

    entity_catalog = _build_entity_catalog(normalized_company, sector_payloads)
    section_readiness = _assess_universal_sections(normalized_company, sector_payloads)
    data_quality = _build_data_quality(section_readiness, sector_models, entity_catalog)
    cfo_signals = _build_cfo_signals(normalized_company, section_readiness, sector_models, data_quality)
    next_questions = _build_next_questions(section_readiness, sector_models, data_quality)

    return {
        "version": "company-operating-model-v1",
        "company": normalized_company,
        "active_sector": selected_sector or "default",
        "entity_catalog": entity_catalog,
        "section_readiness": section_readiness,
        "data_quality": data_quality,
        "sector_models": sector_models,
        "active_sector_model": active_sector_model,
        "cfo_signals": cfo_signals,
        "next_questions": next_questions,
        "overall_readiness_pct": _overall_readiness(section_readiness, sector_models),
        "premium_outputs": {
            "single_company_memory": True,
            "sector_specific_data_roadmap": True,
            "prevents_generic_cfo_answers": True,
            "ready_for_chat_context": True,
            "data_quality_score": True,
            "universal_entity_catalog": True,
        },
    }


def _normalize_company_data(data: Dict[str, Any]) -> Dict[str, Any]:
    sector = data.get("settore") or data.get("sector") or "default"
    normalized = {
        "company_name": data.get("company_name") or data.get("name"),
        "sector": _normalize_sector(sector),
        "annual_revenue": _first_number(data, ["annual_revenue", "fatturato"]),
        "variable_costs": _first_number(data, ["variable_costs", "costi_variabili"]),
        "fixed_costs": _first_number(data, ["fixed_costs", "costi_fissi"]),
        "invested_capital": _first_number(data, ["invested_capital", "investimenti"]),
        "cash_on_hand": _first_number(data, ["cash_on_hand", "liquidita"]),
        "staff_roles": data.get("staff_roles"),
        "employee_count": data.get("employee_count"),
        "payroll_costs": data.get("payroll_costs"),
        "sales_channels": data.get("sales_channels"),
        "payment_terms_days": data.get("payment_terms_days"),
        "customers": data.get("customers"),
        "suppliers": data.get("suppliers"),
        "products": data.get("products"),
        "services": data.get("services"),
        "inventory": data.get("inventory"),
        "recurring_costs": data.get("recurring_costs"),
        "receivables": data.get("receivables"),
        "payables": data.get("payables"),
    }
    return {key: value for key, value in normalized.items() if value not in (None, "", [], {})}


def _build_sector_model(sector: str, data: Dict[str, Any]) -> Dict[str, Any]:
    normalized_sector = _normalize_sector(sector)
    readiness = assess_data_completeness(normalized_sector, data or {}).to_dict()
    missing_required = readiness.get("missing_required") or []
    priority_score = round(100 - float(readiness.get("answer_precision_pct") or 0), 1)

    return {
        "sector": readiness["sector"],
        "sector_name": readiness["sector_name"],
        "readiness_level": readiness["readiness_level"],
        "answer_precision_pct": readiness["answer_precision_pct"],
        "can_answer_precisely": readiness["can_answer_precisely"],
        "missing_required_count": len(missing_required),
        "next_questions": readiness["next_questions"],
        "key_kpis": readiness["key_kpis"],
        "supported_questions": readiness["supported_questions"],
        "priority_score": priority_score,
    }


def _assess_universal_sections(
    company_data: Dict[str, Any],
    operational_data_by_sector: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    combined_keys = set(company_data.keys())
    for sector_data in operational_data_by_sector.values():
        combined_keys.update((sector_data or {}).keys())

    sections = []
    for key, spec in UNIVERSAL_SECTIONS.items():
        present = [field for field in spec["fields"] if field in combined_keys]
        missing = [field for field in spec["fields"] if field not in combined_keys]
        coverage = round((len(present) / len(spec["fields"])) * 100, 1)
        sections.append({
            "section": key,
            "label": spec["label"],
            "coverage_pct": coverage,
            "present_fields": present,
            "missing_fields": missing,
            "status": _section_status(coverage),
        })
    return sections


def _build_entity_catalog(
    company_data: Dict[str, Any],
    operational_data_by_sector: Dict[str, Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    combined = _combine_data(company_data, operational_data_by_sector)
    catalog: Dict[str, Dict[str, Any]] = {}

    for entity, aliases in ENTITY_ALIASES.items():
        value, source_key = _find_first_value(combined, aliases)
        catalog[entity] = {
            "present": value not in (None, "", [], {}),
            "source_key": source_key,
            "count": _entity_count(value),
            "quality": _entity_quality(entity, value),
            "next_detail_needed": _entity_next_detail(entity, value),
        }
    return catalog


def _build_data_quality(
    section_readiness: List[Dict[str, Any]],
    sector_models: List[Dict[str, Any]],
    entity_catalog: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    weighted_score = 0.0
    total_weight = sum(DATA_QUALITY_WEIGHTS.values())
    blockers: List[Dict[str, str]] = []

    for section in section_readiness:
        weight = DATA_QUALITY_WEIGHTS.get(section["section"], 0)
        weighted_score += section["coverage_pct"] * weight
        if section["coverage_pct"] < 40:
            blockers.append({
                "area": section["label"],
                "reason": f"Mancano {', '.join(section['missing_fields'][:3])}.",
            })

    missing_entities = [
        entity.replace("_", " ")
        for entity, detail in entity_catalog.items()
        if not detail["present"]
    ]

    entity_score = _entity_score(entity_catalog)
    sector_precision = 0.0
    if sector_models:
        sector_precision = sum(item["answer_precision_pct"] for item in sector_models) / len(sector_models)

    base_score = (weighted_score / total_weight) if total_weight else 0
    if sector_models:
        final_score = round((base_score * 0.55) + (entity_score * 0.2) + (sector_precision * 0.25), 1)
    else:
        final_score = round((base_score * 0.7) + (entity_score * 0.3), 1)

    return {
        "score_pct": final_score,
        "level": _quality_level(final_score),
        "entity_score_pct": entity_score,
        "blockers": blockers[:6],
        "missing_entities": missing_entities,
        "answer_policy": _answer_policy(final_score),
    }


def _build_cfo_signals(
    company_data: Dict[str, Any],
    section_readiness: List[Dict[str, Any]],
    sector_models: List[Dict[str, Any]],
    data_quality: Dict[str, Any],
) -> List[Dict[str, str]]:
    signals: List[Dict[str, str]] = []

    revenue = float(company_data.get("annual_revenue") or 0)
    variable_costs = float(company_data.get("variable_costs") or 0)
    fixed_costs = float(company_data.get("fixed_costs") or 0)
    invested = float(company_data.get("invested_capital") or 0)

    if revenue > 0:
        gross_margin = ((revenue - variable_costs) / revenue) * 100
        net_margin = ((revenue - variable_costs - fixed_costs) / revenue) * 100
        signals.append({
            "type": "margin",
            "severity": "watch" if net_margin < 10 else "healthy",
            "message": f"Margine lordo {gross_margin:.1f}% e margine netto {net_margin:.1f}%.",
        })
        if invested > 0:
            roi = ((revenue - variable_costs - fixed_costs) / invested) * 100
            signals.append({
                "type": "capital",
                "severity": "watch" if roi < 20 else "healthy",
                "message": f"ROI operativo {roi:.1f}% sul capitale inserito.",
            })

    weakest_section = sorted(section_readiness, key=lambda item: item["coverage_pct"])[0]
    if weakest_section["coverage_pct"] < 50:
        signals.append({
            "type": "data_gap",
            "severity": "warning",
            "message": f"Area dati piu' debole: {weakest_section['label']}. Senza questi dati la chat resta generica.",
        })

    if sector_models and not sector_models[0]["can_answer_precisely"]:
        signals.append({
            "type": "sector_precision",
            "severity": "warning",
            "message": f"Nel verticale {sector_models[0]['sector_name']} mancano dati per risposte precise.",
        })

    if data_quality["score_pct"] < 55:
        signals.append({
            "type": "data_quality",
            "severity": "warning",
            "message": f"Data quality {data_quality['score_pct']}%: {data_quality['answer_policy']}",
        })

    return signals


def _build_next_questions(
    section_readiness: List[Dict[str, Any]],
    sector_models: List[Dict[str, Any]],
    data_quality: Dict[str, Any],
) -> List[str]:
    questions: List[str] = []

    for sector in sector_models[:2]:
        questions.extend(sector.get("next_questions") or [])

    weak_sections = [item for item in section_readiness if item["coverage_pct"] < 50]
    for section in weak_sections:
        questions.append(
            f"Completa {section['label'].lower()}: mi mancano {', '.join(section['missing_fields'][:3])}."
        )

    for blocker in data_quality.get("blockers", [])[:3]:
        questions.append(f"Per sbloccare {blocker['area'].lower()}: {blocker['reason']}")

    deduped: List[str] = []
    for question in questions:
        if question and question not in deduped:
            deduped.append(question)
    return deduped[:8]


def _overall_readiness(
    section_readiness: List[Dict[str, Any]],
    sector_models: List[Dict[str, Any]],
) -> float:
    section_score = sum(item["coverage_pct"] for item in section_readiness) / len(section_readiness)
    if not sector_models:
        return round(section_score * 0.6, 1)
    sector_score = sum(item["answer_precision_pct"] for item in sector_models) / len(sector_models)
    return round((section_score * 0.45) + (sector_score * 0.55), 1)


def _section_status(coverage: float) -> str:
    if coverage >= 75:
        return "ready"
    if coverage >= 40:
        return "partial"
    return "missing"


def _combine_data(
    company_data: Dict[str, Any],
    operational_data_by_sector: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    combined = dict(company_data or {})
    for sector, payload in (operational_data_by_sector or {}).items():
        for key, value in (payload or {}).items():
            combined.setdefault(key, value)
            combined.setdefault(f"{sector}.{key}", value)
    return combined


def _find_first_value(data: Dict[str, Any], aliases: List[str]) -> Tuple[Any, Optional[str]]:
    for alias in aliases:
        if alias in data and data[alias] not in (None, "", [], {}):
            return data[alias], alias
    return None, None


def _entity_count(value: Any) -> int:
    if isinstance(value, list):
        return len(value)
    if isinstance(value, dict):
        return len(value)
    if value in (None, "", [], {}):
        return 0
    return 1


def _entity_quality(entity: str, value: Any) -> str:
    if value in (None, "", [], {}):
        return "missing"
    if isinstance(value, list) and len(value) == 0:
        return "missing"
    if isinstance(value, list) and len(value) < 3 and entity in {"customers", "products", "suppliers", "sales_channels"}:
        return "partial"
    return "usable"


def _entity_next_detail(entity: str, value: Any) -> str:
    if value in (None, "", [], {}):
        details = {
            "customers": "lista clienti/segmenti con ricavi, margine e frequenza",
            "suppliers": "fornitori con prezzi, termini e alternative",
            "products": "prodotti/servizi con prezzo, costo unitario e volumi",
            "staff_roles": "ruoli, costo mensile, ore e capacita' produttiva",
            "sales_channels": "canali con fatturato, CAC, conversione e margine",
            "inventory": "stock, rotazione, scarti e rotture",
            "payment_terms": "giorni medi di incasso, pagamento, crediti e debiti",
            "recurring_costs": "costi fissi ricorrenti per categoria e utilita'",
        }
        return details.get(entity, "dettaglio operativo")
    return "aggiungi trend mensile e margine per rendere l'analisi piu' precisa"


def _entity_score(entity_catalog: Dict[str, Dict[str, Any]]) -> float:
    if not entity_catalog:
        return 0.0
    values = []
    for detail in entity_catalog.values():
        quality = detail.get("quality")
        if quality == "usable":
            values.append(100)
        elif quality == "partial":
            values.append(55)
        else:
            values.append(0)
    return round(sum(values) / len(values), 1)


def _quality_level(score: float) -> str:
    if score >= 80:
        return "board_ready"
    if score >= 65:
        return "analysis_ready"
    if score >= 40:
        return "directional"
    return "discovery_needed"


def _answer_policy(score: float) -> str:
    if score >= 80:
        return "puoi dare raccomandazioni precise con priorita' e impatto."
    if score >= 65:
        return "puoi dare analisi solide, ma segnala le assunzioni."
    if score >= 40:
        return "dai solo direzione e chiedi i dati che mancano prima dei calcoli fini."
    return "non dare risposte operative definitive; prima raccogli dati."


def _first_number(data: Dict[str, Any], keys: List[str]) -> Optional[float]:
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return float(value)
    return None


def _normalize_sector(sector: Optional[str]) -> str:
    value = (sector or "default").strip().lower().replace(" ", "_")
    aliases = {
        "ristorante": "restaurant",
        "ristoranti": "restaurant",
        "e-commerce": "ecommerce",
        "online_store": "ecommerce",
        "costruzioni": "construction",
        "edilizia": "construction",
    }
    return aliases.get(value, value)
