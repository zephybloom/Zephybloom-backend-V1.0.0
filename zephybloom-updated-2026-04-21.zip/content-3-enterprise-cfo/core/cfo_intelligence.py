"""
Deterministic CFO intelligence layer.

Turns the base financial analysis into an operator-friendly insight pack:
what is constraining the company, how it compares with its sector, and what
the next executive move should be.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from api.schemas_cfo import AnalyzeResponse
from core.industry_intelligence import get_benchmark_comparison, get_industry_profile


def build_cfo_insight_pack(
    analysis: AnalyzeResponse,
    settore: str = "default",
    trend_narrative: Optional[str] = None,
) -> Dict[str, Any]:
    """Build a structured CFO insight pack from a completed analysis."""

    profile = get_industry_profile(settore or "default")
    kpi = analysis.kpi_snapshot

    gross_margin = kpi.gross_margin_pct
    ebitda_margin = kpi.ebitda_margin_pct
    net_margin = kpi.net_margin_pct
    roi = kpi.roi_pct
    benchmark_gaps = _benchmark_gaps(
        settore=settore,
        metrics={
            "gross_margin_pct": gross_margin,
            "net_margin_pct": net_margin,
            "roi_pct": roi,
        },
    )
    constraint_type, constraint = _find_primary_constraint(
        gross_margin_pct=gross_margin,
        ebitda_margin_pct=ebitda_margin,
        net_margin_pct=net_margin,
        roi_pct=roi,
        ccc_days=kpi.ccc_days,
        profile_net_margin_pct=profile.healthy_net_margin_pct * 100,
        profile_gross_margin_pct=profile.healthy_gross_margin_pct * 100,
    )

    health_label = _health_label(str(getattr(analysis.status, "value", analysis.status)))
    next_best_move = _next_best_move(
        constraint_type=constraint_type,
        profile_actions=profile.top_decisions,
        default_action=analysis.recommended_actions[0].title if analysis.recommended_actions else None,
    )

    return {
        "version": "cfo-intelligence-v1",
        "industry": {
            "code": profile.code.value,
            "name": profile.name,
            "decision_focus": profile.decision_focus,
            "capital_intensity": profile.capital_intensity,
            "scaling_challenge": profile.scaling_challenge,
        },
        "health_label": health_label,
        "primary_constraint": {
            "type": constraint_type,
            "summary": constraint,
            "risk_window": _risk_window(str(getattr(analysis.status, "value", analysis.status)), net_margin, kpi.ccc_days),
        },
        "benchmark_gaps": benchmark_gaps,
        "capital_efficiency": {
            "status": _capital_efficiency_status(roi),
            "roi_pct": roi,
            "target_roi_pct": round(profile.healthy_roi_pct * 100, 1),
        },
        "strategic_posture": _strategic_posture(
            status=str(getattr(analysis.status, "value", analysis.status)),
            net_margin_pct=net_margin,
            gross_margin_pct=gross_margin,
            target_gross_margin_pct=profile.healthy_gross_margin_pct * 100,
        ),
        "next_best_move": next_best_move,
        "watch_metrics": _watch_metrics(profile.key_kpis, constraint_type),
        "talking_points": _talking_points(
            health_label=health_label,
            constraint=constraint,
            next_best_move=next_best_move,
            trend_narrative=trend_narrative,
        ),
        "confidence": _confidence_score(analysis, benchmark_gaps, trend_narrative),
    }


def _benchmark_gaps(settore: str, metrics: Dict[str, Optional[float]]) -> List[Dict[str, Any]]:
    gaps = []
    for metric, value_pct in metrics.items():
        if value_pct is None:
            continue

        benchmark = get_benchmark_comparison(settore, metric, value_pct / 100)
        if not benchmark:
            continue

        median_pct = benchmark.industry_median * 100
        value = round(value_pct, 1)
        gaps.append(
            {
                "metric": metric,
                "current_pct": value,
                "median_pct": round(median_pct, 1),
                "gap_to_median_points": round(median_pct - value_pct, 1),
                "peer_position": benchmark.percentile_rank,
            }
        )

    return gaps


def _find_primary_constraint(
    gross_margin_pct: float,
    ebitda_margin_pct: float,
    net_margin_pct: float,
    roi_pct: Optional[float],
    ccc_days: Optional[float],
    profile_net_margin_pct: float,
    profile_gross_margin_pct: float,
) -> tuple[str, str]:
    if net_margin_pct < 0:
        return "profitability", "The company is losing money after fixed costs and investments."
    if gross_margin_pct < profile_gross_margin_pct * 0.85:
        return "unit_economics", "Gross margin is below the sector model, so each sale creates too little contribution."
    if ebitda_margin_pct < profile_net_margin_pct:
        return "operating_leverage", "Fixed costs are absorbing too much contribution before it reaches EBITDA."
    if ccc_days is not None and ccc_days > 75:
        return "cash_cycle", "Cash is trapped in receivables or inventory for too long."
    if roi_pct is not None and roi_pct < 0:
        return "capital_allocation", "Invested capital is not converting into profit."
    return "growth_quality", "The model is financially viable; the next constraint is scaling without margin erosion."


def _next_best_move(
    constraint_type: str,
    profile_actions: List[str],
    default_action: Optional[str],
) -> Dict[str, str]:
    action_by_constraint = {
        "profitability": "Ripristina un margine netto positivo prima di finanziare nuova crescita.",
        "unit_economics": "Rivedi prezzi, riduci il costo del venduto o spingi le offerte con piu' contribuzione.",
        "operating_leverage": "Riduci il peso dei costi fissi e proteggi il nucleo operativo che genera margine.",
        "cash_cycle": "Accorcia gli incassi e riduci capitale bloccato in stock o lavori in corso.",
        "capital_allocation": "Ferma gli investimenti a basso ritorno e rialloca capitale dove il payback e' gia' provato.",
        "growth_quality": profile_actions[0] if profile_actions else "Scala il canale con margine piu' alto.",
    }
    return {
        "focus": constraint_type,
        "move": action_by_constraint.get(constraint_type, default_action or "Proteggi il margine prima di crescere."),
        "supporting_action": default_action or (profile_actions[0] if profile_actions else "Proteggi il margine prima di crescere."),
    }


def _strategic_posture(
    status: str,
    net_margin_pct: float,
    gross_margin_pct: float,
    target_gross_margin_pct: float,
) -> str:
    if status == "critical" or net_margin_pct < 0:
        return "stabilize"
    if gross_margin_pct < target_gross_margin_pct:
        return "repair_unit_economics"
    if status == "warning":
        return "optimize"
    return "scale_selectively"


def _watch_metrics(key_kpis: List[str], constraint_type: str) -> List[str]:
    base = {
        "profitability": ["net_margin_pct", "ebitda_margin_pct", "monthly_burn"],
        "unit_economics": ["gross_margin_pct", "contribution_margin", "pricing_realization"],
        "operating_leverage": ["fixed_cost_pct", "ebitda_margin_pct", "revenue_per_employee"],
        "cash_cycle": ["ccc_days", "dso_days", "inventory_turnover"],
        "capital_allocation": ["roi_pct", "payback_period", "cash_runway"],
        "growth_quality": ["net_margin_pct", "gross_margin_pct", "revenue_growth_rate"],
    }.get(constraint_type, ["net_margin_pct", "gross_margin_pct"])

    merged = list(dict.fromkeys(base + key_kpis[:2]))
    return merged[:5]


def _talking_points(
    health_label: str,
    constraint: str,
    next_best_move: Dict[str, str],
    trend_narrative: Optional[str],
) -> List[str]:
    points = [
        f"Health: {health_label}.",
        constraint,
        f"Next move: {next_best_move['move']}",
    ]
    if trend_narrative:
        points.append(trend_narrative)
    return points


def _health_label(status: str) -> str:
    return {
        "healthy": "Financially scalable",
        "warning": "Viable but constrained",
        "critical": "Stabilization required",
    }.get(status, "Needs CFO review")


def _risk_window(status: str, net_margin_pct: float, ccc_days: Optional[float]) -> str:
    if status == "critical" or net_margin_pct < 0:
        return "0-90 days"
    if status == "warning" or (ccc_days is not None and ccc_days > 75):
        return "3-6 months"
    return "6-12 months"


def _capital_efficiency_status(roi_pct: Optional[float]) -> str:
    if roi_pct is None:
        return "unknown"
    if roi_pct < 0:
        return "destroying_value"
    if roi_pct < 15:
        return "low_yield"
    if roi_pct < 35:
        return "productive"
    return "high_yield"


def _confidence_score(
    analysis: AnalyzeResponse,
    benchmark_gaps: List[Dict[str, Any]],
    trend_narrative: Optional[str],
) -> float:
    score = 0.62
    if analysis.kpi_snapshot:
        score += 0.14
    if benchmark_gaps:
        score += 0.14
    if trend_narrative:
        score += 0.06
    if analysis.recommended_actions:
        score += 0.04
    return round(min(score, 0.95), 2)
