"""
Stripe Integration

Connects to Stripe payment processor to sync:
- Transaction data
- Revenue metrics
- Refunds and chargebacks
- Payment success rates
"""

from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, date, timedelta
import requests

from core.integrations_base import (
    PaymentIntegration,
    IntegrationConfig,
    IntegrationResult,
    IntegrationStatus,
    TransactionData,
    AuthenticationError,
    RateLimitError,
)


class StripeIntegration(PaymentIntegration):
    """
    Integrates with Stripe payment processor via API key.
    
    Provides:
    - Transaction data and metrics
    - Revenue metrics (MRR equivalent)
    - Refunds and disputes
    - Payment success rates
    - Customer metrics (if using Billing)
    """
    
    BASE_URL = "https://api.stripe.com/v1"
    
    def __init__(self, config: IntegrationConfig):
        super().__init__(config)
        self.api_key = config.api_key
    
    def authenticate(self) -> IntegrationResult:
        """
        Authenticate with Stripe.
        
        Requires config.api_key (Stripe Secret Key).
        Authentication is done via Basic Auth on every request.
        """
        try:
            if not self.api_key:
                raise AuthenticationError("Missing Stripe API key")
            
            # Test authentication by making a simple API call
            headers = self._get_headers()
            response = requests.get(
                f"{self.BASE_URL}/account",
                headers=headers,
                timeout=self.config.timeout_seconds,
            )
            
            if response.status_code == 200:
                self.status = IntegrationStatus.AUTHENTICATED
                return IntegrationResult(
                    success=True,
                    data={"account": response.json()},
                )
            else:
                raise AuthenticationError(f"Authentication failed: {response.text}")
        
        except Exception as e:
            self._log_error(str(e), "AUTH_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="AUTH_ERROR",
            )
    
    def sync_data(self) -> IntegrationResult:
        """Sync transaction data from Stripe"""
        try:
            if self.status != IntegrationStatus.AUTHENTICATED:
                return IntegrationResult(
                    success=False,
                    error="Not authenticated",
                    error_code="NOT_AUTHENTICATED",
                )
            
            # Get charges for last 30 days
            end_date = date.today()
            start_date = end_date - timedelta(days=30)
            
            charges_result = self.get_transaction_data(start_date, end_date)
            disputes_result = self.get_disputes(start_date, end_date)
            
            self.last_sync = datetime.now()
            
            return IntegrationResult(
                success=True,
                data={
                    "charges_synced": len(charges_result[0].transactions if charges_result[0] else []),
                    "disputes_synced": len(disputes_result[0] or []),
                },
            )
        
        except Exception as e:
            self._log_error(str(e), "SYNC_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="SYNC_ERROR",
            )
    
    def disconnect(self) -> IntegrationResult:
        """Disconnect from Stripe"""
        try:
            self.status = IntegrationStatus.CONNECTING
            return IntegrationResult(success=True)
        
        except Exception as e:
            self._log_error(str(e), "DISCONNECT_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="DISCONNECT_ERROR",
            )
    
    def get_transaction_data(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[TransactionData], Optional[str]]:
        """
        Get transaction data from Stripe.
        
        Returns aggregated metrics:
        - Total revenue
        - Total fees
        - Refunds
        - Chargebacks
        - Success rate
        """
        try:
            # Mock implementation
            # In production: call Stripe Charges API
            
            data = TransactionData(
                transactions=[
                    {
                        "id": "ch_001",
                        "amount": 10000,  # $100.00 in cents
                        "status": "succeeded",
                        "date": start_date,
                    },
                ],
                total_revenue=100_000,  # $1000
                total_fees=2500,  # $25 (2.5%)
                refunds=0,
                chargebacks=0,
                successful_rate_pct=99.5,
                period_start_date=start_date,
                period_end_date=end_date,
                source="stripe",
                synced_at=datetime.now(),
            )
            
            return data, None
        
        except Exception as e:
            return None, str(e)
    
    def get_disputes(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """
        Get disputed transactions (chargebacks, refund disputes).
        
        Returns list of disputes with:
        - Dispute ID, amount
        - Reason code
        - Status
        """
        try:
            # Mock implementation
            # In production: call Stripe Disputes API
            
            disputes = []  # No disputes in this example
            
            return disputes, None
        
        except Exception as e:
            return None, str(e)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get HTTP headers for Stripe API requests"""
        import base64
        
        # Stripe uses Basic Auth: base64(api_key:)
        auth_str = base64.b64encode(f"{self.api_key}:".encode()).decode()
        
        return {
            "Authorization": f"Basic {auth_str}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
    
    def _get_charges(
        self,
        start_timestamp: int,
        end_timestamp: int,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get charges from Stripe API"""
        headers = self._get_headers()
        
        params = {
            "created[gte]": start_timestamp,
            "created[lte]": end_timestamp,
            "limit": limit,
        }
        
        response = requests.get(
            f"{self.BASE_URL}/charges",
            headers=headers,
            params=params,
            timeout=self.config.timeout_seconds,
        )
        
        if response.status_code == 429:
            raise RateLimitError("Stripe API rate limit exceeded")
        
        response.raise_for_status()
        data = response.json()
        
        return data.get("data", [])
