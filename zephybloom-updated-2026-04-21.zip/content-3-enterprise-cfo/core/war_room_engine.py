"""Unified CFO War Room engine.

This layer turns sector-specific operational analyses into one executive
decision view. It is intentionally deterministic: the LLM can explain the
decision later, but the numbers and priorities come from calculators.
"""

from typing import Any, Callable, Dict, List, Optional, Tuple

from core.cfo_decision_playbook import build_decision_playbook
from core.construction_calculator import analyze_construction
from core.data_requirements import assess_data_completeness
from core.ecommerce_calculator import analyze_ecommerce
from core.restaurant_calculator import analyze_restaurant


Analyzer = Callable[[Dict[str, Any]], Dict[str, Any]]


def build_unified_war_room(
    operational_data_by_sector: Dict[str, Dict[str, Any]],
    active_sector: Optional[str] = None,
    decision_memory_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a cross-sector CFO decision room from saved operational data."""

    sector_cards: List[Dict[str, Any]] = []
    skipped_sectors: List[Dict[str, str]] = []

    for raw_sector, data in (operational_data_by_sector or {}).items():
        sector = _normalize_sector(raw_sector)
        analyzer = _ANALYZERS.get(sector)
        if not analyzer:
            skipped_sectors.append({
                "sector": raw_sector,
                "reason": "Settore non ancora supportato dalla War Room.",
            })
            continue

        provided_data = data or {}
        readiness = assess_data_completeness(sector, provided_data).to_dict()
        analysis = analyzer(provided_data)
        sector_cards.append(_build_sector_card(sector, provided_data, analysis, readiness, active_sector))

    sector_cards.sort(key=lambda card: card["priority_score"], reverse=True)

    decision_queue = _build_decision_queue(sector_cards)
    weekly_agenda = _build_weekly_agenda(decision_queue)
    execution_tracker = _build_execution_tracker(decision_queue)
    data_gaps = _build_data_gap_board(sector_cards)
    stop_go = _build_stop_go_board(sector_cards)
    priority = _build_priority_decision(sector_cards, decision_queue)
    portfolio = _build_portfolio_summary(sector_cards)
    memory_context = _build_memory_context(decision_memory_context or {})
    executive_summary = _build_executive_summary(priority, decision_queue, data_gaps, stop_go, portfolio, memory_context)

    return {
        "version": "unified-cfo-war-room-v2",
        "status": "ready" if sector_cards else "needs_operational_data",
        "active_sector": _normalize_sector(active_sector),
        "sector_count": len(sector_cards),
        "sector_cards": sector_cards,
        "priority_decision": priority,
        "decision_queue": decision_queue,
        "weekly_agenda": weekly_agenda,
        "execution_tracker": execution_tracker,
        "executive_summary": executive_summary,
        "memory_context": memory_context,
        "data_gap_board": data_gaps,
        "stop_go_board": stop_go,
        "portfolio_summary": portfolio,
        "skipped_sectors": skipped_sectors,
        "premium_outputs": {
            "single_executive_view": True,
            "cross_sector_prioritization": True,
            "data_readiness_guardrails": True,
            "deterministic_cfo_decision": True,
            "execution_playbook": True,
            "weekly_cfo_agenda": True,
            "stop_go_control": True,
            "missing_data_board": True,
            "decision_tracking": True,
            "executive_summary": True,
            "uses_decision_memory": True,
        },
    }


def _build_sector_card(
    sector: str,
    provided_data: Dict[str, Any],
    analysis: Dict[str, Any],
    readiness: Dict[str, Any],
    active_sector: Optional[str],
) -> Dict[str, Any]:
    if sector == "restaurant":
        card = _restaurant_card(analysis)
    elif sector == "ecommerce":
        card = _ecommerce_card(analysis)
    elif sector == "construction":
        card = _construction_card(analysis)
    else:
        card = {
            "label": sector.title(),
            "key_metric_label": "Dati operativi",
            "key_metric": "Da completare",
            "score_label": "Non disponibile",
            "risk": "Settore non ancora mappato.",
            "opportunity": "Completa il verticale prima di inserirlo in War Room.",
            "action": "Raccogli dati operativi minimi.",
        }

    readiness_gap = 100 - float(readiness.get("answer_precision_pct") or 0)
    sector_boost = 15 if sector == _normalize_sector(active_sector) else 0
    risk_boost = _risk_boost(sector, analysis)
    priority_score = round(readiness_gap + sector_boost + risk_boost, 1)
    playbook = build_decision_playbook(
        company_data=_company_data_from_operational(sector, provided_data),
        operational_data_by_sector={sector: provided_data},
        active_sector=sector,
        question=_playbook_question(sector, analysis, readiness),
    )

    return {
        "sector": sector,
        "readiness": readiness,
        "analysis": analysis,
        "playbook": playbook["decision"],
        "priority_score": priority_score,
        "decision_theme": _decision_theme(sector, analysis, readiness),
        "economic_lever": _economic_lever(sector, analysis),
        "go_no_go": _go_no_go(sector, analysis, readiness),
        **card,
    }


def _restaurant_card(analysis: Dict[str, Any]) -> Dict[str, Any]:
    summary = analysis.get("summary", {})
    prime_cost = float(summary.get("prime_cost_pct") or 0)
    break_even = summary.get("break_even_covers_per_day")
    top_dish = (analysis.get("top_dishes_by_profit") or [{}])[0].get("name")
    action = (analysis.get("recommendations") or ["Analizza menu, ingredienti e turni prima di scalare."])[0]

    return {
        "label": "Restaurant CFO",
        "key_metric_label": "Break-even coperti/giorno",
        "key_metric": break_even,
        "score_label": f"Prime cost {prime_cost:.1f}%",
        "risk": (
            "Prime cost sopra soglia: prima correggere food cost, sprechi e turni."
            if prime_cost > 65
            else "Crescita possibile, ma solo se coperti extra non aumentano sprechi e personale non saturo."
        ),
        "opportunity": (
            f"Usa {top_dish} come prodotto guida solo se domanda, velocita' di cucina e posizionamento lo supportano."
            if top_dish
            else "Completa menu e ricette per capire cosa spingere e cosa correggere."
        ),
        "action": action,
    }


def _ecommerce_card(analysis: Dict[str, Any]) -> Dict[str, Any]:
    summary = analysis.get("summary", {})
    cac = float(summary.get("cac_eur") or 0)
    break_even_cac = float(summary.get("break_even_cac_eur") or 0)
    top_sku = (analysis.get("top_skus_by_profit") or [{}])[0].get("sku")
    action = (analysis.get("recommendations") or ["Segmenta SKU per margine, volume, resi e CAC sostenibile."])[0]

    return {
        "label": "Ecommerce CFO",
        "key_metric_label": "Break-even CAC",
        "key_metric": round(break_even_cac, 2),
        "score_label": f"ROAS {summary.get('roas')}",
        "risk": (
            "CAC sopra break-even: ogni nuovo cliente rischia di comprare fatturato a perdita."
            if cac > break_even_cac > 0
            else "CAC sostenibile: verifica resi, logistica e marginalita' SKU prima di scalare ads."
        ),
        "opportunity": (
            f"Scala {top_sku} sui canali dove CAC, resi e tempi di incasso restano sotto controllo."
            if top_sku
            else "Completa SKU, costi, resi e canali per trovare i prodotti da spingere."
        ),
        "action": action,
    }


def _construction_card(analysis: Dict[str, Any]) -> Dict[str, Any]:
    summary = analysis.get("summary", {})
    cash_gap = float(summary.get("cash_gap_eur") or 0)
    wip = float(summary.get("wip_unbilled_eur") or 0)
    project = (analysis.get("projects_by_cash_risk") or [{}])[0].get("project")
    action = (analysis.get("recommendations") or ["Allinea avanzamento lavori, fatturazione SAL e incassi."])[0]

    return {
        "label": "Construction CFO",
        "key_metric_label": "WIP non fatturato",
        "key_metric": round(wip, 2),
        "score_label": f"Cash gap EUR {cash_gap:,.0f}",
        "risk": (
            "Cash gap attivo: recupera SAL e incassi prima di aprire nuove commesse."
            if cash_gap > 0
            else "Cassa sotto controllo: monitora ritardi, varianti non approvate e materiali."
        ),
        "opportunity": (
            f"Prima azione su {project}: riduci cash gap, fattura WIP o approva varianti."
            if project
            else "Completa avanzamento, SAL e incassi per vedere le commesse critiche."
        ),
        "action": action,
    }


def _build_priority_decision(cards: List[Dict[str, Any]], decision_queue: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    if not cards:
        return {
            "title": "Inserisci dati operativi",
            "sector": None,
            "decision": "La War Room non deve inventare: serve almeno un verticale con dati operativi.",
            "why": "Senza dettaglio su prodotti, costi, personale, commesse o canali, il CFO puo' solo dare consigli generici.",
            "next_step": "Compila Restaurant, Ecommerce o Construction CFO e poi riapri la War Room.",
            "board_instruction": "Prima dati, poi decisione.",
        }

    top = cards[0]
    queue = decision_queue or _build_decision_queue(cards)
    missing = top.get("readiness", {}).get("missing_required") or []
    if missing:
        first_missing = missing[0].get("label") or missing[0].get("key") or "dato operativo mancante"
        decision = f"Prima completa {first_missing} su {top['label']}."
        why = "E' il punto che oggi limita di piu' la precisione delle risposte CFO."
    else:
        decision = top["action"]
        why = top["risk"]

    return {
        "title": "Decisione prioritaria",
        "sector": top["sector"],
        "decision": decision,
        "why": why,
        "next_step": top["opportunity"],
        "execution_plan": _weekly_execution_plan(top),
        "board_instruction": _board_instruction(queue),
        "priority_score": top["priority_score"],
    }


def _build_decision_queue(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    queue: List[Dict[str, Any]] = []
    for index, card in enumerate(cards, start=1):
        playbook = card.get("playbook") or {}
        missing = card.get("readiness", {}).get("missing_required") or []
        if missing:
            first_missing = missing[0].get("label") or missing[0].get("key") or "dato operativo mancante"
            decision = f"Completa {first_missing} prima di decidere su {card['label']}."
            action = f"Raccogli {first_missing} e aggiorna il verticale."
            reason = "Dato critico mancante: la War Room blocca decisioni troppo deboli."
            type_ = "data_blocker"
        else:
            decision = playbook.get("decision") or card.get("action")
            action = card.get("action")
            reason = card.get("risk")
            type_ = card.get("decision_theme", "operational")

        queue.append({
            "decision_id": _decision_id(index, card["sector"], type_),
            "rank": index,
            "sector": card["sector"],
            "label": card["label"],
            "type": type_,
            "decision": decision,
            "why": reason,
            "next_action": action,
            "owner": playbook.get("owner") or "Founder/CEO",
            "economic_lever": card.get("economic_lever"),
            "priority_score": card["priority_score"],
            "go_no_go": card.get("go_no_go"),
            "recommended_simulation": playbook.get("recommended_simulation"),
            "kpis": (playbook.get("kpis_to_monitor") or [])[:4],
            "success_metric": _success_metric(card, playbook),
            "evidence_needed": _evidence_needed(card),
            "review_cadence": "weekly",
        })
    return queue


def _build_weekly_agenda(queue: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    agenda: List[Dict[str, Any]] = []
    for item in queue[:3]:
        agenda.append({
            "decision_id": item["decision_id"],
            "day": _agenda_day(item["rank"]),
            "sector": item["sector"],
            "owner": item["owner"],
            "action": item["next_action"],
            "why": item["why"],
            "kpi": (item.get("kpis") or ["data quality"])[0],
            "simulation": item.get("recommended_simulation"),
        })
    return agenda


def _build_execution_tracker(queue: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "decision_id": item["decision_id"],
            "rank": item["rank"],
            "sector": item["sector"],
            "owner": item["owner"],
            "status": "todo",
            "decision": item["decision"],
            "next_action": item["next_action"],
            "success_metric": item["success_metric"],
            "evidence_needed": item["evidence_needed"],
            "review_cadence": item["review_cadence"],
            "follow_up_question": _follow_up_question(item),
        }
        for item in queue[:5]
    ]


def _build_executive_summary(
    priority: Dict[str, Any],
    queue: List[Dict[str, Any]],
    data_gaps: List[Dict[str, Any]],
    stop_go: List[Dict[str, Any]],
    portfolio: Dict[str, Any],
    memory_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not queue:
        return {
            "headline": "War Room non pronta: mancano dati operativi.",
            "diagnosis": "Il CFO AI non deve inventare priorita' senza dati su costi, ricavi, prodotti, commesse o canali.",
            "decision": "Compila almeno un verticale operativo.",
            "do_now": ["Inserisci dati operativi minimi", "Rilancia la War Room", "Poi decidi le prime 3 azioni"],
            "do_not_do": ["Non scalare budget o costi fissi senza margine e cassa misurabili"],
            "cfo_note": "Prima precisione, poi crescita.",
        }

    top = queue[0]
    hold_count = sum(1 for rule in stop_go if rule.get("status") in {"HOLD", "FIX_FIRST", "CASH_FIRST"})
    readiness = portfolio.get("readiness_avg_pct", 0)
    data_warning = (
        f"Ci sono {len(data_gaps)} dati che limitano precisione."
        if data_gaps
        else "I dati principali sono sufficienti per decidere."
    )
    stop_warning = (
        f"{hold_count} area/e richiedono stop o correzione prima di scalare."
        if hold_count
        else "Nessun blocco Stop/Go critico emerso."
    )

    memory_context = memory_context or {}
    memory_note = memory_context.get("war_room_note")

    return {
        "headline": f"Priorita' settimana: {top['label']} - {top['type'].replace('_', ' ')}.",
        "diagnosis": f"{priority.get('why')} {data_warning} Readiness media dati: {readiness}%. {memory_note or ''}".strip(),
        "decision": priority.get("decision"),
        "do_now": [item.get("next_action") for item in queue[:3] if item.get("next_action")],
        "do_not_do": [
            "Non aumentare costi fissi prima di validare margine e cassa.",
            "Non scalare canali/prodotti con Stop/Go negativo.",
            "Non considerare completata una decisione senza KPI misurato.",
        ],
        "watch": stop_warning,
        "cfo_note": priority.get("board_instruction") or "Esegui la prima azione e aggiorna i dati.",
    }


def _build_memory_context(context: Dict[str, Any]) -> Dict[str, Any]:
    summary = context.get("summary") or {}
    decisions = context.get("decisions") or []
    open_decisions = [item for item in decisions if item.get("status") == "todo"][:3]
    completed = [item for item in decisions if item.get("status") == "done"][:3]
    below_target = [
        item for item in completed
        if (item.get("outcome_review") or {}).get("status") in {"below_target", "negative"}
    ][:3]
    best = summary.get("best_decision")

    if not decisions:
        note = "Nessuno storico decisionale ancora disponibile."
    elif open_decisions:
        note = f"Hai {len(open_decisions)} decisione/i aperte: chiudile prima di aggiungerne troppe nuove."
    elif below_target:
        note = f"Rivedi {below_target[0]['decision_id']}: ultima esecuzione sotto target."
    elif best:
        note = f"Replica il pattern vincente di {best['decision_id']} se il contesto e' simile."
    else:
        note = "Storico decisionale presente, ma senza pattern forte da replicare."

    return {
        "summary": summary,
        "open_decisions": open_decisions,
        "completed_decisions": completed,
        "below_target_decisions": below_target,
        "best_decision": best,
        "war_room_note": note,
        "recommended_memory_action": _memory_recommendation(open_decisions, below_target, best),
        "quality": {
            "status": summary.get("memory_quality", "unknown"),
            "stale_open_decisions": summary.get("stale_open_decisions", 0),
            "duplicate_open_groups": summary.get("duplicate_open_groups", 0),
            "notes": summary.get("memory_quality_notes", []),
        },
    }


def _memory_recommendation(open_decisions: List[Dict[str, Any]], below_target: List[Dict[str, Any]], best: Optional[Dict[str, Any]]) -> str:
    if open_decisions:
        return f"Chiudi o aggiorna {open_decisions[0]['decision_id']} prima di aprire una nuova iniziativa."
    if below_target:
        return f"Fai post-mortem su {below_target[0]['decision_id']} prima di replicare quella leva."
    if best:
        return f"Valuta replica controllata di {best['decision_id']}."
    return "Genera nuove decisioni e registra feedback per creare memoria utile."


def _build_data_gap_board(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    gaps: List[Dict[str, Any]] = []
    for card in cards:
        missing = card.get("readiness", {}).get("missing_required") or []
        for field in missing[:4]:
            gaps.append({
                "sector": card["sector"],
                "label": card["label"],
                "field": field.get("label") or field.get("key"),
                "key": field.get("key"),
                "why_it_matters": field.get("why_it_matters") or "Questo dato aumenta precisione di diagnosi e simulazioni.",
                "priority_score": card["priority_score"],
            })
    gaps.sort(key=lambda item: item["priority_score"], reverse=True)
    return gaps[:8]


def _build_stop_go_board(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "sector": card["sector"],
            "label": card["label"],
            "status": card.get("go_no_go", {}).get("status"),
            "rule": card.get("go_no_go", {}).get("rule"),
            "kill_switch": card.get("go_no_go", {}).get("kill_switch"),
        }
        for card in cards
    ]


def _decision_id(rank: int, sector: str, type_: str) -> str:
    clean_sector = "".join(char for char in sector.lower() if char.isalnum()) or "sector"
    clean_type = "".join(char for char in type_.lower() if char.isalnum()) or "decision"
    return f"wr-{rank:02d}-{clean_sector}-{clean_type}"


def _success_metric(card: Dict[str, Any], playbook: Dict[str, Any]) -> Dict[str, Any]:
    kpi = (playbook.get("kpis_to_monitor") or ["data quality"])[0]
    lever = card.get("economic_lever") or {}
    return {
        "kpi": kpi,
        "baseline": lever.get("current"),
        "target": lever.get("target") or "trend positivo",
        "rule": _metric_rule(card["sector"], lever.get("name")),
    }


def _metric_rule(sector: str, lever_name: Optional[str]) -> str:
    if sector == "restaurant" and lever_name == "prime_cost":
        return "Successo se prime cost scende o resta <= 65% senza calo ticket medio."
    if sector == "ecommerce" and lever_name == "break_even_cac":
        return "Successo se CAC resta sotto break-even CAC e il contributo per ordine resta positivo."
    if sector == "construction" and lever_name == "cash_gap":
        return "Successo se cash gap e WIP non fatturato diminuiscono."
    return "Successo se migliora il KPI scelto senza peggiorare margine o cassa."


def _evidence_needed(card: Dict[str, Any]) -> List[str]:
    sector = card["sector"]
    if sector == "restaurant":
        return ["vendite per piatto", "food cost aggiornato", "turni/personale", "scontrino medio"]
    if sector == "ecommerce":
        return ["ordini", "CAC per canale", "resi", "margine per SKU"]
    if sector == "construction":
        return ["SAL emessi", "incassi", "WIP aggiornato", "varianti approvate"]
    return ["ricavi", "costi", "margine", "cassa"]


def _follow_up_question(item: Dict[str, Any]) -> str:
    metric = item.get("success_metric") or {}
    return (
        f"Hai eseguito '{item.get('next_action')}'? "
        f"Come e' cambiato {metric.get('kpi', 'il KPI')} rispetto al baseline?"
    )


def _weekly_execution_plan(card: Dict[str, Any]) -> Dict[str, Any]:
    playbook = card.get("playbook") or {}
    actions = playbook.get("actions") or {}
    return {
        "owner": playbook.get("owner"),
        "this_week": (actions.get("30_days") or [])[:3],
        "kpis": (playbook.get("kpis_to_monitor") or [])[:5],
        "risk": playbook.get("risk"),
        "cost_of_inaction": playbook.get("cost_of_inaction"),
        "recommended_simulation": playbook.get("recommended_simulation"),
    }


def _decision_theme(sector: str, analysis: Dict[str, Any], readiness: Dict[str, Any]) -> str:
    if not readiness.get("can_answer_precisely"):
        return "data_blocker"
    summary = analysis.get("summary", {})
    if sector == "restaurant" and float(summary.get("prime_cost_pct") or 0) > 65:
        return "margin_recovery"
    if sector == "ecommerce":
        cac = float(summary.get("cac_eur") or 0)
        break_even = float(summary.get("break_even_cac_eur") or 0)
        if cac > break_even > 0:
            return "paid_growth_blocker"
        return "profitable_growth"
    if sector == "construction" and float(summary.get("cash_gap_eur") or 0) > 0:
        return "cash_recovery"
    return "profitable_growth"


def _economic_lever(sector: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
    summary = analysis.get("summary", {})
    if sector == "restaurant":
        return {
            "name": "prime_cost",
            "label": "Prime cost",
            "current": round(float(summary.get("prime_cost_pct") or 0), 1),
            "target": "<= 65%",
            "money_logic": "Ogni punto recuperato tra food cost e personale libera margine ricorrente.",
        }
    if sector == "ecommerce":
        return {
            "name": "break_even_cac",
            "label": "CAC vs break-even CAC",
            "current": round(float(summary.get("cac_eur") or 0), 2),
            "target": f"<= EUR {float(summary.get('break_even_cac_eur') or 0):.2f}",
            "money_logic": "Se il CAC supera il break-even, la crescita ads brucia utile.",
        }
    if sector == "construction":
        return {
            "name": "cash_gap",
            "label": "Cash gap",
            "current": round(float(summary.get("cash_gap_eur") or 0), 2),
            "target": "<= EUR 0",
            "money_logic": "Il WIP non fatturato e gli incassi lenti bloccano cassa e nuove commesse.",
        }
    return {
        "name": "margin_cash",
        "label": "Margine e cassa",
        "current": None,
        "target": "trend positivo",
        "money_logic": "La decisione deve migliorare utile o liquidita', non solo volume.",
    }


def _go_no_go(sector: str, analysis: Dict[str, Any], readiness: Dict[str, Any]) -> Dict[str, str]:
    if not readiness.get("can_answer_precisely"):
        return {
            "status": "HOLD",
            "rule": "Non decidere senza dati critici completi.",
            "kill_switch": "Se mancano costi diretti, volumi o incassi, blocca simulazioni definitive.",
        }
    summary = analysis.get("summary", {})
    if sector == "restaurant":
        prime_cost = float(summary.get("prime_cost_pct") or 0)
        status = "GO" if prime_cost <= 65 else "FIX_FIRST"
        return {
            "status": status,
            "rule": "Scala coperti e offerte solo se prime cost resta entro soglia.",
            "kill_switch": "Se prime cost supera 65%, fermare crescita e correggere food cost/personale.",
        }
    if sector == "ecommerce":
        cac = float(summary.get("cac_eur") or 0)
        break_even = float(summary.get("break_even_cac_eur") or 0)
        status = "GO" if break_even <= 0 or cac <= break_even else "FIX_FIRST"
        return {
            "status": status,
            "rule": "Scala ads solo quando CAC e resi lasciano contributo positivo.",
            "kill_switch": "Se CAC supera break-even CAC, fermare aumento budget e correggere offerta/canale.",
        }
    if sector == "construction":
        cash_gap = float(summary.get("cash_gap_eur") or 0)
        status = "GO" if cash_gap <= 0 else "CASH_FIRST"
        return {
            "status": status,
            "rule": "Apri nuove commesse solo se SAL, WIP e incassi non assorbono cassa.",
            "kill_switch": "Se cash gap e WIP non fatturato crescono, bloccare nuove commesse non prefinanziate.",
        }
    return {
        "status": "TEST",
        "rule": "Testa crescita con soglie su margine e cassa.",
        "kill_switch": "Blocca azione se peggiora margine netto o liquidita'.",
    }


def _board_instruction(queue: List[Dict[str, Any]]) -> str:
    if not queue:
        return "Raccogli dati operativi prima di costruire la priorita'."
    top = queue[0]
    return (
        f"Questa settimana parti da {top['label']}: {top['next_action']} "
        f"Misura {', '.join(top.get('kpis') or ['data quality'])}."
    )


def _agenda_day(rank: int) -> str:
    return {
        1: "Lunedi",
        2: "Mercoledi",
        3: "Venerdi",
    }.get(rank, "Questa settimana")


def _build_portfolio_summary(cards: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not cards:
        return {
            "readiness_avg_pct": 0,
            "main_constraint": "dati_operativi_mancanti",
            "sectors_ready": 0,
            "sectors_needing_data": 0,
        }

    readiness_values = [float(card["readiness"].get("answer_precision_pct") or 0) for card in cards]
    sectors_ready = sum(1 for card in cards if card["readiness"].get("can_answer_precisely"))
    sectors_needing_data = len(cards) - sectors_ready
    main_constraint = "dati_operativi" if sectors_needing_data else "scalata_con_margine_e_cassa"

    return {
        "readiness_avg_pct": round(sum(readiness_values) / len(readiness_values), 1),
        "main_constraint": main_constraint,
        "sectors_ready": sectors_ready,
        "sectors_needing_data": sectors_needing_data,
    }


def _risk_boost(sector: str, analysis: Dict[str, Any]) -> float:
    summary = analysis.get("summary", {})
    if sector == "restaurant":
        return 25 if float(summary.get("prime_cost_pct") or 0) > 65 else 5
    if sector == "ecommerce":
        cac = float(summary.get("cac_eur") or 0)
        break_even = float(summary.get("break_even_cac_eur") or 0)
        return 25 if cac > break_even > 0 else 5
    if sector == "construction":
        return 25 if float(summary.get("cash_gap_eur") or 0) > 0 else 5
    return 0


def _company_data_from_operational(sector: str, data: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "company_name": data.get("company_name"),
        "settore": sector,
        "fatturato": data.get("annual_revenue") or data.get("contract_value") or _sum_project_contracts(data),
        "costi_variabili": data.get("variable_costs") or _estimate_variable_costs(sector, data),
        "costi_fissi": data.get("fixed_costs") or 0,
        "investimenti": data.get("invested_capital") or 0,
        "cash_on_hand": data.get("cash_on_hand"),
        "staff_roles": data.get("staff_roles"),
        "suppliers": data.get("suppliers"),
        "sales_channels": data.get("sales_channels"),
        "customers": data.get("customers"),
        "inventory": data.get("inventory"),
        "recurring_costs": data.get("recurring_costs"),
    }


def _estimate_variable_costs(sector: str, data: Dict[str, Any]) -> float:
    if sector == "construction":
        return sum(
            float(project.get("materials_cost") or 0)
            + float(project.get("labor_cost") or 0)
            + float(project.get("subcontractor_cost") or 0)
            + float(project.get("other_cost") or 0)
            for project in data.get("projects", [])
        )
    return 0.0


def _sum_project_contracts(data: Dict[str, Any]) -> float:
    return sum(float(project.get("contract_value") or 0) for project in data.get("projects", []))


def _playbook_question(sector: str, analysis: Dict[str, Any], readiness: Dict[str, Any]) -> str:
    if not readiness.get("can_answer_precisely"):
        return "quali sono i miei punti deboli e che dati devo completare?"
    summary = analysis.get("summary", {})
    if sector == "construction" and float(summary.get("cash_gap_eur") or 0) > 0:
        return "quale commessa mi blocca la cassa e cosa devo fare?"
    if sector == "ecommerce":
        return "come posso vendere di più senza perdere margine?"
    if sector == "restaurant":
        return "come posso aumentare il margine del ristorante?"
    return "dove posso migliorare l'azienda?"


def _normalize_sector(sector: Optional[str]) -> str:
    value = (sector or "").strip().lower()
    aliases: Dict[str, str] = {
        "ristorante": "restaurant",
        "ristoranti": "restaurant",
        "e-commerce": "ecommerce",
        "online_store": "ecommerce",
        "costruzioni": "construction",
        "edilizia": "construction",
        "cantieri": "construction",
    }
    return aliases.get(value, value)


_ANALYZERS: Dict[str, Analyzer] = {
    "restaurant": analyze_restaurant,
    "ecommerce": analyze_ecommerce,
    "construction": analyze_construction,
}
