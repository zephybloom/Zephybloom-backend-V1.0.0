"""
Performance Optimization: Pre-computation

Pre-computes common entrepreneur profiles and tone combinations to avoid
runtime inference for typical scenarios.

Reduces profile inference latency from ~10ms to 0ms for common cases.
Reduces tone selection latency from ~5ms to 0ms for common cases.
"""

from enum import Enum
from typing import Dict, Optional

from core.entrepreneur_profiler import (
    EntrepreneurProfile,
    RiskTolerance,
    GrowthAppetite,
    ExpertiseLevel,
    DecisionStyle,
    PainTolerance,
)
from core.dynamic_tone_manager import (
    TonePersonalization,
    CFOTonePersonalized,
    ExplainabilityLevel,
)


# ============================================================
# Pre-computed Common Profiles
# ============================================================

class CommonProfile(str, Enum):
    """Pre-computed profile templates"""
    AGGRESSIVE_STARTUP = "aggressive_startup"
    CONSERVATIVE_MATURE = "conservative_mature"
    INTERMEDIATE_GROWTH = "intermediate_growth"
    EXPERT_SCALING = "expert_scaling"
    NOVICE_WARNING = "novice_warning"


# Pre-computed profiles
PRECOMPUTED_PROFILES: Dict[CommonProfile, EntrepreneurProfile] = {
    
    CommonProfile.AGGRESSIVE_STARTUP: EntrepreneurProfile(
        risk_tolerance=RiskTolerance.AGGRESSIVE,
        growth_appetite=GrowthAppetite.HYPERGROWTH,
        expertise_level=ExpertiseLevel.NOVICE,
        decision_style=DecisionStyle.INTUITIVE,
        pain_tolerance=PainTolerance.HIGH,
        company_size_eur=1_000_000,
        industry="saas",
        company_stage="startup",
        profile_confidence=0.8,
    ),
    
    CommonProfile.CONSERVATIVE_MATURE: EntrepreneurProfile(
        risk_tolerance=RiskTolerance.CONSERVATIVE,
        growth_appetite=GrowthAppetite.SLOW,
        expertise_level=ExpertiseLevel.EXPERT,
        decision_style=DecisionStyle.DATA_DRIVEN,
        pain_tolerance=PainTolerance.LOW,
        company_size_eur=100_000_000,
        industry="manufacturing",
        company_stage="mature",
        profile_confidence=0.85,
    ),
    
    CommonProfile.INTERMEDIATE_GROWTH: EntrepreneurProfile(
        risk_tolerance=RiskTolerance.MODERATE,
        growth_appetite=GrowthAppetite.STEADY,
        expertise_level=ExpertiseLevel.INTERMEDIATE,
        decision_style=DecisionStyle.MIXED,
        pain_tolerance=PainTolerance.MEDIUM,
        company_size_eur=15_000_000,
        industry="retail",
        company_stage="growth",
        profile_confidence=0.75,
    ),
    
    CommonProfile.EXPERT_SCALING: EntrepreneurProfile(
        risk_tolerance=RiskTolerance.MODERATE,
        growth_appetite=GrowthAppetite.STEADY,
        expertise_level=ExpertiseLevel.EXPERT,
        decision_style=DecisionStyle.DATA_DRIVEN,
        pain_tolerance=PainTolerance.MEDIUM,
        company_size_eur=50_000_000,
        industry="saas",
        company_stage="scale",
        profile_confidence=0.85,
    ),
    
    CommonProfile.NOVICE_WARNING: EntrepreneurProfile(
        risk_tolerance=RiskTolerance.CONSERVATIVE,
        growth_appetite=GrowthAppetite.SLOW,
        expertise_level=ExpertiseLevel.NOVICE,
        decision_style=DecisionStyle.INTUITIVE,
        pain_tolerance=PainTolerance.LOW,
        company_size_eur=2_000_000,
        industry="ecommerce",
        company_stage="startup",
        profile_confidence=0.7,
    ),
}


# ============================================================
# Pre-computed Common Tones
# ============================================================

class CommonTone(str, Enum):
    """Pre-computed tone templates"""
    NOVICE_EDUCATIONAL = "novice_educational"
    EXPERT_MINIMAL = "expert_minimal"
    EMERGENCY_FIRM = "emergency_firm"
    GROWTH_MOTIVATOR = "growth_motivator"
    CONSERVATIVE_SOFT = "conservative_soft"


# Pre-computed tones
PRECOMPUTED_TONES: Dict[CommonTone, TonePersonalization] = {
    
    CommonTone.NOVICE_EDUCATIONAL: TonePersonalization(
        tone=CFOTonePersonalized.SOFT,
        explainability=ExplainabilityLevel.EDUCATIONAL,
        language_style="conversational",
        risk_framing="conservative",
        recommendation_prefix="I'd suggest",
        action_urgency="gradual",
        show_alternatives=False,
        show_risks=True,
        include_success_stories=True,
    ),
    
    CommonTone.EXPERT_MINIMAL: TonePersonalization(
        tone=CFOTonePersonalized.FIRM,
        explainability=ExplainabilityLevel.MINIMAL,
        language_style="formal",
        risk_framing="balanced",
        recommendation_prefix="Recommend",
        action_urgency="soon",
        show_alternatives=True,
        show_risks=True,
        include_success_stories=False,
    ),
    
    CommonTone.EMERGENCY_FIRM: TonePersonalization(
        tone=CFOTonePersonalized.FIRM,
        explainability=ExplainabilityLevel.DETAILED,
        language_style="professional",
        risk_framing="balanced",
        recommendation_prefix="Critical action required",
        action_urgency="immediate",
        show_alternatives=False,
        show_risks=True,
        include_success_stories=False,
    ),
    
    CommonTone.GROWTH_MOTIVATOR: TonePersonalization(
        tone=CFOTonePersonalized.MOTIVATOR,
        explainability=ExplainabilityLevel.MODERATE,
        language_style="professional",
        risk_framing="aggressive",
        recommendation_prefix="Opportunity to capture",
        action_urgency="soon",
        show_alternatives=True,
        show_risks=True,
        include_success_stories=True,
    ),
    
    CommonTone.CONSERVATIVE_SOFT: TonePersonalization(
        tone=CFOTonePersonalized.SOFT,
        explainability=ExplainabilityLevel.MODERATE,
        language_style="professional",
        risk_framing="conservative",
        recommendation_prefix="Consider",
        action_urgency="optional",
        show_alternatives=True,
        show_risks=True,
        include_success_stories=False,
    ),
}


class PrecomputedCache:
    """
    Access to pre-computed profiles and tones.
    
    Provides O(1) lookup for common scenarios to avoid runtime computation.
    """
    
    @staticmethod
    def get_profile(profile_type: CommonProfile) -> Optional[EntrepreneurProfile]:
        """Get pre-computed profile"""
        return PRECOMPUTED_PROFILES.get(profile_type)
    
    @staticmethod
    def get_tone(tone_type: CommonTone) -> Optional[TonePersonalization]:
        """Get pre-computed tone"""
        return PRECOMPUTED_TONES.get(tone_type)
    
    @staticmethod
    def get_all_profiles() -> Dict[CommonProfile, EntrepreneurProfile]:
        """Get all pre-computed profiles (useful for preloading)"""
        return PRECOMPUTED_PROFILES.copy()
    
    @staticmethod
    def get_all_tones() -> Dict[CommonTone, TonePersonalization]:
        """Get all pre-computed tones"""
        return PRECOMPUTED_TONES.copy()


def get_profile_for_scenario(
    fatturato: float,
    growth_rate_pct: float,
    company_age_years: float,
    ebitda_margin_pct: float,
) -> Optional[CommonProfile]:
    """
    Classify scenario to pre-computed profile if it matches common pattern.
    
    Returns CommonProfile enum if match found, None otherwise.
    """
    
    # Aggressive startup: <€5M, >50% growth, <5y old, low margin
    if fatturato < 5_000_000 and growth_rate_pct > 50 and company_age_years < 5 and ebitda_margin_pct < 10:
        return CommonProfile.AGGRESSIVE_STARTUP
    
    # Conservative mature: >€50M, <15% growth, >15y old, high margin
    if fatturato > 50_000_000 and growth_rate_pct < 15 and company_age_years > 15 and ebitda_margin_pct > 20:
        return CommonProfile.CONSERVATIVE_MATURE
    
    # Intermediate growth: €5M-€30M, 15-50% growth, 5-15y old
    if (5_000_000 <= fatturato <= 30_000_000 and
        15 < growth_rate_pct < 50 and
        5 < company_age_years < 15):
        return CommonProfile.INTERMEDIATE_GROWTH
    
    # Expert scaling: >€20M, moderate growth, >10y old, expert-level margins
    if (fatturato > 20_000_000 and
        10 < growth_rate_pct < 30 and
        company_age_years > 10 and
        ebitda_margin_pct > 15):
        return CommonProfile.EXPERT_SCALING
    
    # Novice in warning: <€5M, <20% growth, <5y old
    if fatturato < 5_000_000 and growth_rate_pct < 20 and company_age_years < 5:
        return CommonProfile.NOVICE_WARNING
    
    return None


def get_tone_for_scenario(
    expertise: str,
    severity: str,
    growth_appetite: str,
) -> Optional[CommonTone]:
    """
    Classify scenario to pre-computed tone if it matches common pattern.
    
    Args:
        expertise: "novice", "intermediate", "expert"
        severity: "healthy", "warning", "critical"
        growth_appetite: "slow", "steady", "hypergrowth"
    
    Returns CommonTone enum if match found, None otherwise.
    """
    
    # Emergency firm: critical situation
    if severity == "critical":
        return CommonTone.EMERGENCY_FIRM
    
    # Novice educational: novice expertise, any severity
    if expertise == "novice":
        return CommonTone.NOVICE_EDUCATIONAL
    
    # Expert minimal: expert + healthy
    if expertise == "expert" and severity == "healthy":
        return CommonTone.EXPERT_MINIMAL
    
    # Growth motivator: hypergrowth appetite, healthy situation
    if growth_appetite == "hypergrowth" and severity == "healthy":
        return CommonTone.GROWTH_MOTIVATOR
    
    # Conservative soft: slow growth, non-critical
    if growth_appetite == "slow" and severity in ("healthy", "warning"):
        return CommonTone.CONSERVATIVE_SOFT
    
    return None
