# -*- coding: utf-8 -*-
"""
ROI Calculator - Quantifica impatto ROI di decisioni strategiche
(pricing, costs, investments, hiring)
"""
from __future__ import annotations

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict

from utils.math_utils import safe_div

__all__ = [
    "DecisionImpact",
    "ROICalculation",
    "ROICalculator",
    "calculate_roi",
]


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class DecisionImpact:
    """Impatto finanziario di una decisione"""
    decisione: str  # "Aumento prezzo +2%", "Riduzione costi -10%", ecc.
    type: str  # "pricing", "cost_reduction", "investment", "hiring"
    
    # Base metrics
    impatto_ricavo: float  # Delta ricavo
    impatto_utile: float  # Delta utile (profit impact)
    impatto_cassa: float  # Cash flow impact
    
    # ROI metrics
    investment_required: float  # Capex/cost richiesto per implementare
    payback_months: float  # Quanti mesi per recuperare l'investimento
    roi_year1: float  # ROI primo anno %
    npv_3year: float  # Net present value 3 anni
    
    # Risk assessment
    implementation_difficulty: str  # "easy", "medium", "hard"
    probability_success: float  # 0-1 (es. 0.85 = 85%)
    risk_level: str  # "low", "medium", "high"
    
    # Recommendation
    verdict: str  # "HIGHLY_RECOMMENDED", "RECOMMENDED", "CONSIDER", "NOT_RECOMMENDED"
    rationale: str  # Spiegazione decisione

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ROICalculation:
    """Calculation output con dettaglio tecnico"""
    base_metrics: Dict[str, float]  # Metriche base (fatturato, utile, ecc.)
    decisions: List[DecisionImpact]  # Decision impacts
    total_expected_profit_uplift: float  # Somma di tutti gli impacts
    total_investment_required: float  # Total capex
    portfolio_roi: float  # ROI combinato %
    priority_rank: List[str]  # Ranking decisioni per ROI
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "base_metrics": self.base_metrics,
            "decisions": [d.to_dict() for d in self.decisions],
            "total_expected_profit_uplift": self.total_expected_profit_uplift,
            "total_investment_required": self.total_investment_required,
            "portfolio_roi": self.portfolio_roi,
            "priority_rank": self.priority_rank,
        }


# =============================================================================
# Helpers
# =============================================================================

def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _payback_months(investment: float, monthly_profit_increase: float) -> float:
    """Calcola payback period in mesi"""
    inv = _asf(investment, 0.0)
    monthly = _asf(monthly_profit_increase, 0.0001)
    
    if monthly <= 0:
        return float('inf')
    
    months = inv / monthly
    return min(months, 99.0)  # Cap at 99 months (8 years)


def _npv_calculation(
    initial_investment: float,
    annual_benefit: float,
    years: int = 3,
    discount_rate: float = 0.10,
) -> float:
    """
    Calcola NPV su N anni con discount rate
    discount_rate: 10% = 0.10
    """
    npv = -_asf(initial_investment, 0.0)
    
    for year in range(1, years + 1):
        discount_factor = 1.0 / ((1.0 + discount_rate) ** year)
        npv += _asf(annual_benefit, 0.0) * discount_factor
    
    return npv


# =============================================================================
# ROI Calculator
# =============================================================================

class ROICalculator:
    """
    Calcola ROI di decisioni strategiche:
    - Pricing optimization
    - Cost reduction
    - Investment decisions
    - Hiring/headcount optimization
    """

    def calculate(
        self,
        fatturato: float,
        utile: float,
        margine_lordo_pct: float,
        costi_fissi: float,
        **decisions: Any
    ) -> ROICalculation:
        """
        Calcola ROI per multiple decisioni
        
        Args:
            fatturato: Annual revenue
            utile: Annual profit
            margine_lordo_pct: Gross margin %
            costi_fissi: Fixed costs
            **decisions: Decision parameters
                - pricing_increase_pct: Price increase %
                - cost_reduction_pct: Cost reduction %
                - investment_amount: Capex
                - headcount_increase: New hires
        """

        base_metrics = {
            "fatturato": fatturato,
            "utile": utile,
            "margine_lordo_pct": margine_lordo_pct,
            "costi_fissi": costi_fissi,
        }

        decision_impacts = []

        # Decision 1: Pricing optimization
        pricing_increase = _asf(decisions.get("pricing_increase_pct", 0.0))
        if pricing_increase > 0:
            impact = self._calculate_pricing_impact(
                fatturato,
                utile,
                pricing_increase,
                margine_lordo_pct,
            )
            decision_impacts.append(impact)

        # Decision 2: Cost reduction
        cost_reduction = _asf(decisions.get("cost_reduction_pct", 0.0))
        if cost_reduction > 0:
            impact = self._calculate_cost_reduction_impact(
                fatturato,
                utile,
                cost_reduction,
                costi_fissi,
            )
            decision_impacts.append(impact)

        # Decision 3: Investment
        investment = _asf(decisions.get("investment_amount", 0.0))
        if investment > 0:
            impact = self._calculate_investment_impact(
                fatturato,
                utile,
                investment,
            )
            decision_impacts.append(impact)

        # Decision 4: Hiring
        headcount_increase = _asf(decisions.get("headcount_increase", 0.0))
        if headcount_increase > 0:
            impact = self._calculate_hiring_impact(
                fatturato,
                utile,
                headcount_increase,
            )
            decision_impacts.append(impact)

        # Aggregate impacts
        total_profit_uplift = sum(d.impatto_utile for d in decision_impacts)
        total_investment = sum(d.investment_required for d in decision_impacts)
        
        portfolio_roi = safe_div(total_profit_uplift * 100.0, total_investment, 0.0) if total_investment > 0 else 0.0

        # Priority rank
        priority_rank = sorted(
            [d.decisione for d in decision_impacts],
            key=lambda x: next((d.roi_year1 for d in decision_impacts if d.decisione == x), 0),
            reverse=True,
        )

        return ROICalculation(
            base_metrics=base_metrics,
            decisions=decision_impacts,
            total_expected_profit_uplift=total_profit_uplift,
            total_investment_required=total_investment,
            portfolio_roi=portfolio_roi,
            priority_rank=priority_rank,
        )

    def _calculate_pricing_impact(
        self,
        fatturato: float,
        utile: float,
        pricing_increase_pct: float,
        margin_pct: float,
    ) -> DecisionImpact:
        """Impatto aumento prezzo"""
        
        # Elasticity: every 1% price increase = -0.5% volume loss
        volume_elasticity = -0.5
        volume_loss_pct = pricing_increase_pct * volume_elasticity / 100.0
        
        # Revenue impact
        revenue_increase = fatturato * (pricing_increase_pct / 100.0) * (1.0 + volume_loss_pct)
        
        # Profit impact (assuming same margin)
        profit_increase = revenue_increase * (margin_pct / 100.0)
        
        # Implementation cost = marketing + sales training (low cost)
        implementation_cost = revenue_increase * 0.05  # 5% of uplift
        
        # Payback
        monthly_increase = profit_increase / 12.0
        payback = _payback_months(implementation_cost, monthly_increase)
        
        # Risk
        if pricing_increase_pct > 10:
            risk_level = "high"
            prob_success = 0.60
        elif pricing_increase_pct > 5:
            risk_level = "medium"
            prob_success = 0.75
        else:
            risk_level = "low"
            prob_success = 0.90

        roi_year1 = safe_div(profit_increase * 100.0, implementation_cost, 0.0) if implementation_cost > 0 else 0.0

        return DecisionImpact(
            decisione=f"Aumento prezzo +{pricing_increase_pct:.1f}%",
            type="pricing",
            impatto_ricavo=revenue_increase,
            impatto_utile=profit_increase,
            impatto_cassa=profit_increase,
            investment_required=implementation_cost,
            payback_months=payback,
            roi_year1=roi_year1,
            npv_3year=_npv_calculation(implementation_cost, profit_increase, 3),
            implementation_difficulty="easy",
            probability_success=prob_success,
            risk_level=risk_level,
            verdict="HIGHLY_RECOMMENDED" if roi_year1 > 100 else "RECOMMENDED",
            rationale=f"Aumento prezzo con elasticità -{abs(volume_elasticity)}% genera profit +€{profit_increase:.0f}, ROI {roi_year1:.0f}%",
        )

    def _calculate_cost_reduction_impact(
        self,
        fatturato: float,
        utile: float,
        cost_reduction_pct: float,
        costi_fissi: float,
    ) -> DecisionImpact:
        """Impatto riduzione costi"""
        
        # Identify where savings come from
        # Assume 60% from variable costs, 40% from fixed
        var_savings = fatturato * 0.4 * (cost_reduction_pct / 100.0)
        fixed_savings = costi_fissi * (cost_reduction_pct / 100.0)
        total_savings = var_savings + fixed_savings
        
        # Implementation cost
        if cost_reduction_pct > 20:
            implementation_cost = total_savings * 0.30  # 30% of savings for implementation
            implementation_difficulty = "hard"
            prob_success = 0.65
        elif cost_reduction_pct > 10:
            implementation_cost = total_savings * 0.15
            implementation_difficulty = "medium"
            prob_success = 0.80
        else:
            implementation_cost = total_savings * 0.05
            implementation_difficulty = "easy"
            prob_success = 0.90

        monthly_savings = total_savings / 12.0
        payback = _payback_months(implementation_cost, monthly_savings)
        roi_year1 = safe_div(total_savings * 100.0, max(implementation_cost, 1.0), 0.0)

        verdict = "HIGHLY_RECOMMENDED" if total_savings > utile * 0.1 else "RECOMMENDED"

        return DecisionImpact(
            decisione=f"Riduzione costi -{cost_reduction_pct:.1f}%",
            type="cost_reduction",
            impatto_ricavo=0.0,
            impatto_utile=total_savings,
            impatto_cassa=total_savings,
            investment_required=implementation_cost,
            payback_months=payback,
            roi_year1=roi_year1,
            npv_3year=_npv_calculation(implementation_cost, total_savings, 3),
            implementation_difficulty=implementation_difficulty,
            probability_success=prob_success,
            risk_level="low",
            verdict=verdict,
            rationale=f"Taglio costi realizza €{total_savings:.0f} profit con payback {payback:.1f} mesi",
        )

    def _calculate_investment_impact(
        self,
        fatturato: float,
        utile: float,
        investment_amount: float,
    ) -> DecisionImpact:
        """Impatto investimento strategico"""
        
        inv = _asf(investment_amount, 0.0)
        
        # Assume investment generates 25% ROI
        # Typical range: 15-40% depending on investment type
        expected_annual_return = inv * 0.25
        
        payback = _payback_months(inv, expected_annual_return / 12.0)
        roi_year1 = 25.0  # 25%

        # Multi-year NPV assuming declining returns
        npv = _npv_calculation(inv, expected_annual_return, 3)

        # Risk depends on investment size relative to profit
        inv_to_profit_ratio = safe_div(inv, utile, 0.0)
        
        if inv_to_profit_ratio > 1.0:
            risk_level = "high"
            prob_success = 0.60
            verdict = "CONSIDER"
        elif inv_to_profit_ratio > 0.5:
            risk_level = "medium"
            prob_success = 0.75
            verdict = "RECOMMENDED"
        else:
            risk_level = "low"
            prob_success = 0.85
            verdict = "HIGHLY_RECOMMENDED"

        return DecisionImpact(
            decisione=f"Investimento €{inv:.0f}",
            type="investment",
            impatto_ricavo=expected_annual_return,
            impatto_utile=expected_annual_return,
            impatto_cassa=-inv,  # Initial cash outflow
            investment_required=inv,
            payback_months=payback,
            roi_year1=roi_year1,
            npv_3year=npv,
            implementation_difficulty="medium",
            probability_success=prob_success,
            risk_level=risk_level,
            verdict=verdict,
            rationale=f"Investimento €{inv:.0f} genera ritorno €{expected_annual_return:.0f}/anno, payback {payback:.1f} mesi",
        )

    def _calculate_hiring_impact(
        self,
        fatturato: float,
        utile: float,
        headcount_increase: float,
    ) -> DecisionImpact:
        """Impatto assunzione di persone"""
        
        # Average cost per hire (salary + burden)
        avg_cost_per_person = 50_000
        total_cost = headcount_increase * avg_cost_per_person
        
        # Revenue impact per person (assuming €250k revenue per headcount)
        revenue_per_person = 250_000
        expected_revenue_increase = headcount_increase * revenue_per_person
        
        # Profit impact (assuming 25% net margin)
        expected_profit_increase = expected_revenue_increase * 0.25
        
        # Ramp-up time (first 3 months at 50% productivity)
        year1_profit_impact = expected_profit_increase * 0.875  # (3*0.5 + 9*1.0) / 12 = 0.875
        
        payback = _payback_months(total_cost, year1_profit_impact / 12.0)
        roi_year1 = safe_div(year1_profit_impact * 100.0, total_cost, 0.0)

        # Risk assessment
        if headcount_increase > 0.2 * (fatturato / 250_000):  # >20% headcount increase
            risk_level = "high"
            prob_success = 0.65
        elif headcount_increase > fatturato / 250_000:  # >100% increase
            risk_level = "medium"
            prob_success = 0.75
        else:
            risk_level = "low"
            prob_success = 0.85

        verdict = "RECOMMENDED" if roi_year1 > 100 else "CONSIDER"

        return DecisionImpact(
            decisione=f"Assunzione {headcount_increase:.1f} persone",
            type="hiring",
            impatto_ricavo=expected_revenue_increase,
            impatto_utile=year1_profit_impact,
            impatto_cassa=-total_cost,
            investment_required=total_cost,
            payback_months=payback,
            roi_year1=roi_year1,
            npv_3year=_npv_calculation(total_cost, expected_profit_increase, 3),
            implementation_difficulty="medium",
            probability_success=prob_success,
            risk_level=risk_level,
            verdict=verdict,
            rationale=f"Assunzione genera €{expected_revenue_increase:.0f} ricavi, profit anno1 €{year1_profit_impact:.0f}, payback {payback:.1f} mesi",
        )


def calculate_roi(
    fatturato: float,
    utile: float,
    margine_lordo_pct: float = 50.0,
    costi_fissi: float = 0.0,
    **decisions: Any
) -> ROICalculation:
    """Wrapper pubblico per ROI calculation"""
    return ROICalculator().calculate(
        fatturato=fatturato,
        utile=utile,
        margine_lordo_pct=margine_lordo_pct,
        costi_fissi=costi_fissi,
        **decisions,
    )
