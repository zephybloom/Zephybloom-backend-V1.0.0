# -*- coding: utf-8 -*-
# content/core/valuation.py
from __future__ import annotations
from typing import List, Tuple, Optional

def _npv(rate: float, cashflows: List[float]) -> float:
    r = rate
    return sum(cf / ((1 + r) ** t) for t, cf in enumerate(cashflows))

def _irr(cashflows: List[float], guess: float = 0.1, tol: float = 1e-7, max_iter: int = 100) -> Optional[float]:
    # Newton-Raphson semplice con safeguard
    r = guess
    for _ in range(max_iter):
        denom = [(1 + r) ** t for t in range(len(cashflows))]
        f = sum(cf / d for cf, d in zip(cashflows, denom))
        df = sum(-t * cf / ((1 + r) ** (t + 1)) for t, cf in enumerate(cashflows))
        if abs(df) < 1e-12:
            break
        new_r = r - f / df
        if abs(new_r - r) < tol:
            return new_r
        r = new_r
    return None

def project_eval(cashflows: List[float], discount_rate: float) -> Tuple[float, Optional[float], int]:
    npv = _npv(discount_rate, cashflows)
    irr = _irr(cashflows)
    cum = 0.0
    payback = -1
    for i, cf in enumerate(cashflows):
        cum += cf
        if cum >= 0 and payback < 0:
            payback = i
    return npv, irr, payback

def dcf_gordon(fcf: List[float], discount_rate: float, g: float, net_debt: float = 0.0):
    """DCF con fase esplicita + terminal Gordon su ultimo anno esplicito."""
    if not fcf:
        return 0.0, 0.0, 0.0, 0.0
    r = discount_rate
    pv_explicit = sum(cf / ((1 + r) ** (t + 1)) for t, cf in enumerate(fcf))
    last = fcf[-1]
    terminal_value = (last * (1 + g)) / max(1e-12, (r - g))  # evita div/0
    pv_terminal = terminal_value / ((1 + r) ** len(fcf))
    ev = pv_explicit + pv_terminal
    equity = ev - (net_debt or 0.0)
    return ev, equity, pv_explicit, pv_terminal
