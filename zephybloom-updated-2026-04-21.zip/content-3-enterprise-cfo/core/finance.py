# -*- coding: utf-8 -*-
# content/core/finance.py — NPV/IRR, DCF, WACC (tassi in %) + Scenari & Stress
from __future__ import annotations

from typing import List, Dict, Literal, Optional, Tuple, Any

Number = float


# =============================================================================
# Helpers
# =============================================================================
def _finite_floats(seq: List[Any]) -> List[float]:
    """Cast a float e filtra NaN/Inf preservando l'ordine."""
    out: List[float] = []
    for x in seq or []:
        try:
            v = float(x)
            if v == v and v not in (float("inf"), float("-inf")):
                out.append(v)
        except Exception:
            continue
    return out


def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _pct_to_frac(x: Number) -> float:
    return float(x) / 100.0


def _frac_to_pct(x: Number) -> float:
    return float(x) * 100.0


def _safe_positive(x: Number, fallback: float = 0.0) -> float:
    v = _asf(x, fallback)
    return v if v > 0 else fallback


def _discount_factor(rate_frac: float, t: int) -> float:
    base = 1.0 + rate_frac
    if base <= 0:
        base = 1e-9
    return base ** t


# =============================================================================
# WACC / NPV / IRR
# =============================================================================
def wacc(ke: Number, kd: Number, equity: Number, debt: Number, tax_rate: Number) -> Number:
    """
    Costo medio ponderato del capitale (in %).
    Tutti i tassi in ingresso sono % (es. 10 = 10%).
    """
    E = max(_asf(equity), 0.0)
    D = max(_asf(debt), 0.0)
    V = max(E + D, 1e-12)

    ke_v = _asf(ke)
    kd_v = _asf(kd)
    tax_v = _clamp(_asf(tax_rate), 0.0, 100.0)

    we = E / V
    wd = D / V
    return we * ke_v + wd * kd_v * (1.0 - tax_v / 100.0)


def npv(rate_pct: Number, cashflows: List[Number]) -> Number:
    """NPV di [CF0, CF1, ..., CFn] con rate in %."""
    cfs = _finite_floats(cashflows)
    if not cfs:
        return 0.0

    r = _pct_to_frac(rate_pct)
    s = 0.0
    for t, cf in enumerate(cfs):
        s += float(cf) / _discount_factor(r, t)
    return float(s)


def irr(
    cashflows: List[Number],
    guess_pct: Number = 10.0,
    tol: Number = 1e-7,
    max_iter: int = 100,
) -> Number:
    """
    IRR via Newton-Raphson con fallback a bisezione robusta.
    Ritorna in %.
    """
    cfs = _finite_floats(cashflows)
    if not cfs or all(abs(float(cf)) < 1e-12 for cf in cfs):
        return 0.0

    has_pos = any(cf > 0 for cf in cfs)
    has_neg = any(cf < 0 for cf in cfs)
    if not (has_pos and has_neg):
        return 0.0

    def _npv_frac(r: float) -> float:
        s = 0.0
        for t, cf in enumerate(cfs):
            denom = _discount_factor(r, t)
            s += float(cf) / denom
        return s

    def _dnpv_frac(r: float) -> float:
        s = 0.0
        for t, cf in enumerate(cfs[1:], start=1):
            base = 1.0 + r
            if base <= 0:
                base = 1e-9
            s += -t * float(cf) / (base ** (t + 1))
        return s

    # -------------------------
    # 1) Newton-Raphson
    # -------------------------
    r = _pct_to_frac(guess_pct)
    r = _clamp(r, -0.95, 10.0)

    for _ in range(int(max_iter)):
        try:
            f = _npv_frac(r)
            if abs(f) < tol:
                return _frac_to_pct(r)

            df = _dnpv_frac(r)
            if abs(df) < 1e-12:
                break

            r_next = r - (f / df)
            if r_next <= -0.999 or r_next > 100.0:
                break
            r = r_next
        except Exception:
            break

    # -------------------------
    # 2) Bisezione con bracket
    # -------------------------
    search_points = [
        -0.95, -0.90, -0.80, -0.70, -0.50, -0.30, -0.10,
        0.00, 0.05, 0.10, 0.20, 0.30, 0.50, 0.75,
        1.00, 1.50, 2.00, 3.00, 5.00, 10.00
    ]

    bracket: Optional[Tuple[float, float]] = None
    prev_r = search_points[0]
    prev_v = _npv_frac(prev_r)

    for curr_r in search_points[1:]:
        curr_v = _npv_frac(curr_r)
        if prev_v == 0.0:
            return _frac_to_pct(prev_r)
        if curr_v == 0.0:
            return _frac_to_pct(curr_r)
        if prev_v * curr_v < 0:
            bracket = (prev_r, curr_r)
            break
        prev_r, prev_v = curr_r, curr_v

    if bracket is not None:
        lo, hi = bracket
        f_lo = _npv_frac(lo)
        for _ in range(200):
            mid = (lo + hi) / 2.0
            f_mid = _npv_frac(mid)

            if abs(f_mid) < tol:
                return _frac_to_pct(mid)

            if f_lo * f_mid <= 0:
                hi = mid
            else:
                lo = mid
                f_lo = f_mid

        return _frac_to_pct((lo + hi) / 2.0)

    # -------------------------
    # 3) fallback ultimo: rate che minimizza |NPV|
    # -------------------------
    best_r = 0.0
    best_abs = float("inf")
    for bp in range(-900, 20001):  # -90% .. 2000% step 0.1%
        rp = bp / 1000.0
        try:
            v = abs(_npv_frac(rp))
            if v < best_abs:
                best_abs = v
                best_r = rp
        except Exception:
            continue

    return _frac_to_pct(best_r)


# =============================================================================
# DCF (Gordon/Exit Multiple) e valuation
# =============================================================================
def gordon_growth_terminal(fcf_t1: Number, g_pct: Number, wacc_pct: Number) -> Number:
    """
    Valore terminale con Gordon-Shapiro.
    fcf_t1 = FCF nel primo anno oltre l'esplicito (FCF_n * (1+g)); g e w in %.
    """
    fcf1 = _asf(fcf_t1, 0.0)
    g = _pct_to_frac(g_pct)
    w = _pct_to_frac(wacc_pct)

    if fcf1 <= 0:
        return 0.0

    if w <= g + 1e-9:
        w = g + 0.005  # guard-rail prudente

    return float(fcf1) / max(w - g, 1e-9)


def exit_multiple_terminal(ebitda_t: Number, multiple: Number) -> Number:
    """
    Valore terminale con Exit Multiple su EBITDA.
    """
    ebitda_v = max(0.0, _asf(ebitda_t, 0.0))
    mult_v = max(0.0, _asf(multiple, 0.0))
    return ebitda_v * mult_v


def _pv_series(values: List[float], rate_pct: float, start_t: int = 1) -> Tuple[float, List[float]]:
    """Ritorna (somma PV, lista PV per anno) scontando da t=start_t.."""
    r = _pct_to_frac(rate_pct)
    pvs: List[float] = []
    s = 0.0

    for i, v in enumerate(values, start=start_t):
        pv = float(v) / _discount_factor(r, i)
        pvs.append(pv)
        s += pv

    return float(s), pvs


def dcf_equity(
    fcf: List[float],
    rate: float | None = None,
    terminal_growth_pct: float = 2.0,
    net_debt: float = 0.0,
    terminal_method: Literal["gordon", "exit_multiple"] = "gordon",
    exit_multiple: Optional[float] = None,
    terminal_ebitda: Optional[float] = None,
    **kwargs,
) -> Dict[str, float]:
    """
    DCF con due metodi di TV:
      - Gordon growth
      - Exit multiple su EBITDA

    Compat:
      - se rate è None e c'è discount_rate_pct in kwargs, usa quello.

    Ritorna:
      {
        enterprise_value,
        equity_value,
        wacc_pct,
        pv_explicit,
        pv_terminal,
        terminal_value,
        terminal_method
      }
    """
    if rate is None and kwargs.get("discount_rate_pct") is not None:
        rate = _asf(kwargs["discount_rate_pct"], 10.0)
    if rate is None:
        rate = 10.0

    rate = _clamp(_asf(rate, 10.0), 0.0, 200.0)
    terminal_growth_pct = _clamp(_asf(terminal_growth_pct, 2.0), -50.0, 50.0)
    net_debt = _asf(net_debt, 0.0)

    fcf_clean = _finite_floats(fcf)
    if not fcf_clean:
        return {
            "enterprise_value": 0.0,
            "equity_value": -float(net_debt),
            "wacc_pct": float(rate),
            "pv_explicit": 0.0,
            "pv_terminal": 0.0,
            "terminal_value": 0.0,
            "terminal_method": terminal_method,
        }

    # PV dei flussi espliciti
    pv_explicit, _ = _pv_series(fcf_clean, rate, start_t=1)

    # Terminal value non scontato
    if terminal_method == "exit_multiple":
        exit_multiple_v = _safe_positive(exit_multiple if exit_multiple is not None else 6.0, 6.0)
        if terminal_ebitda is None:
            # fallback prudente: EBITDA ~ FCF / 0.70 se FCF positivo
            last_fcf = _asf(fcf_clean[-1], 0.0)
            terminal_ebitda = (last_fcf / 0.70) if last_fcf > 0 else 0.0
        tv = exit_multiple_terminal(terminal_ebitda, exit_multiple_v)
    else:
        last_fcf = _asf(fcf_clean[-1], 0.0)
        fcf_t1 = last_fcf * (1.0 + _pct_to_frac(terminal_growth_pct))
        tv = gordon_growth_terminal(fcf_t1, terminal_growth_pct, rate)

    n = len(fcf_clean)
    pv_terminal = float(tv) / _discount_factor(_pct_to_frac(rate), n)

    ev = pv_explicit + pv_terminal
    equity = ev - float(net_debt)

    return {
        "enterprise_value": float(ev),
        "equity_value": float(equity),
        "wacc_pct": float(rate),
        "pv_explicit": float(pv_explicit),
        "pv_terminal": float(pv_terminal),
        "terminal_value": float(tv),
        "terminal_method": terminal_method,
    }


# =============================================================================
# Scenari & Stress test
# =============================================================================
def dcf_equity_scenarios(
    flows: Dict[str, List[float]],
    waccs_pct: Dict[str, float],
    *,
    method_per_scenario: Optional[Dict[str, Literal["gordon", "exit_multiple"]]] = None,
    terminal_growth_pct: float = 2.0,
    net_debt: float = 0.0,
    exit_multiple: Optional[float] = None,
    terminal_ebitda: Optional[float] = None,
) -> Dict[str, Dict[str, float]]:
    """
    Valuta più scenari in un colpo solo.

    flows: {"bull":[...], "base":[...], "bear":[...]}
    waccs_pct: {"bull": 9.0, "base": 11.0, "bear": 13.0}
    """
    out: Dict[str, Dict[str, float]] = {}

    for name, fcf in (flows or {}).items():
        method = (method_per_scenario or {}).get(name, "gordon")
        rate = _asf(waccs_pct.get(name, waccs_pct.get("base", 11.0)), 11.0)

        out[name] = dcf_equity(
            fcf=fcf,
            rate=rate,
            terminal_growth_pct=terminal_growth_pct,
            net_debt=net_debt,
            terminal_method=method,
            exit_multiple=exit_multiple,
            terminal_ebitda=terminal_ebitda,
        )

    return out


def macro_stress(
    base_fcf: List[float],
    *,
    inflation_pct: float = 0.0,
    revenue_shock_pct: float = 0.0,
    efficiency_gain_pct: float = 0.0,
    wacc_bump_pct: float = 0.0,
    base_wacc_pct: float = 11.0,
    terminal_growth_pct: float = 2.0,
    net_debt: float = 0.0,
    terminal_method: Literal["gordon", "exit_multiple"] = "gordon",
    exit_multiple: Optional[float] = None,
    terminal_ebitda: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Stress test macro light sui FCF.
    """
    fcf_clean = _finite_floats(base_fcf)
    base_wacc_pct = _asf(base_wacc_pct, 11.0)
    wacc_bump_pct = _asf(wacc_bump_pct, 0.0)

    if not fcf_clean:
        return {
            "base": dcf_equity(
                [],
                rate=base_wacc_pct,
                terminal_growth_pct=terminal_growth_pct,
                net_debt=net_debt,
                terminal_method=terminal_method,
                exit_multiple=exit_multiple,
                terminal_ebitda=terminal_ebitda,
            ),
            "stressed": dcf_equity(
                [],
                rate=base_wacc_pct + wacc_bump_pct,
                terminal_growth_pct=terminal_growth_pct,
                net_debt=net_debt,
                terminal_method=terminal_method,
                exit_multiple=exit_multiple,
                terminal_ebitda=terminal_ebitda,
            ),
            "haircut_frac": 0.0,
            "wacc_final_pct": base_wacc_pct + wacc_bump_pct,
        }

    haircut_frac = (
        -_pct_to_frac(inflation_pct)
        - _pct_to_frac(revenue_shock_pct)
        + _pct_to_frac(efficiency_gain_pct)
    )
    haircut_frac = _clamp(haircut_frac, -0.9, 2.0)

    stressed_fcf = [max(0.0, cf * (1.0 + haircut_frac)) for cf in fcf_clean]
    wacc_final = base_wacc_pct + wacc_bump_pct

    base_res = dcf_equity(
        fcf=fcf_clean,
        rate=base_wacc_pct,
        terminal_growth_pct=terminal_growth_pct,
        net_debt=net_debt,
        terminal_method=terminal_method,
        exit_multiple=exit_multiple,
        terminal_ebitda=terminal_ebitda,
    )
    stressed_res = dcf_equity(
        fcf=stressed_fcf,
        rate=wacc_final,
        terminal_growth_pct=terminal_growth_pct,
        net_debt=net_debt,
        terminal_method=terminal_method,
        exit_multiple=exit_multiple,
        terminal_ebitda=terminal_ebitda,
    )

    return {
        "base": base_res,
        "stressed": stressed_res,
        "haircut_frac": float(haircut_frac),
        "wacc_final_pct": float(wacc_final),
        "fcf_base": [float(x) for x in fcf_clean],
        "fcf_stressed": [float(x) for x in stressed_fcf],
    }


# =============================================================================
# Valutazione progetto (NPV/IRR/Payback)
# =============================================================================
def project_eval(cashflows: List[Number], discount_rate_pct: Number) -> Dict[str, float]:
    """
    Valuta progetto:
      - NPV (rate %)
      - IRR (%)
      - payback semplice
      - discounted payback
    """
    cfs = _finite_floats(cashflows)
    if not cfs:
        return {
            "npv": 0.0,
            "irr": 0.0,
            "payback_period": -1.0,
            "discounted_payback_period": -1.0,
        }

    discount_rate_pct = _asf(discount_rate_pct, 0.0)
    _npv = npv(discount_rate_pct, cfs)
    _irr = irr(cfs)

    # Payback semplice
    cumul = 0.0
    payback: Optional[int] = None
    for t, cf in enumerate(cfs):
        cumul += float(cf)
        if cumul >= 0.0 and payback is None:
            payback = t

    # Discounted payback
    r = _pct_to_frac(discount_rate_pct)
    d_cumul = 0.0
    d_payback: Optional[int] = None
    for t, cf in enumerate(cfs):
        d_cumul += float(cf) / _discount_factor(r, t)
        if d_cumul >= 0.0 and d_payback is None:
            d_payback = t

    return {
        "npv": float(_npv),
        "irr": float(_irr),
        "payback_period": float(payback if payback is not None else -1.0),
        "discounted_payback_period": float(d_payback if d_payback is not None else -1.0),
    }