# -*- coding: utf-8 -*-
"""
Hiring Engine - Analisi autonoma per ottimizzazione headcount e pianificazione assunzioni
"""
from __future__ import annotations

from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, asdict

from utils.math_utils import safe_div

__all__ = [
    "HeadcountAnalysis",
    "HiringRecommendation",
    "HiringEngine",
    "analyze_headcount",
]


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class HeadcountAnalysis:
    """Analisi corrente dell'headcount"""
    revenue_per_person: float  # Revenue per FTE
    profit_per_person: float  # Profit per FTE
    headcount_productive: int  # Assuming from revenue / revenue_per_person
    salary_cost_pct_revenue: float  # Salary as % of revenue
    ratio_management: float  # Managers as % of total headcount
    productivity_score: float  # 0-1 (1.0 = benchmark)
    is_overstaffed: bool  # True if below benchmark productivity
    is_understaffed: bool  # True if above benchmark productivity
    gap_people: int  # Number to hire/let go


@dataclass
class HiringRecommendation:
    """Raccomandazione assunzione"""
    role: str  # "Sales", "Engineering", "Operations", ecc.
    count: int  # Number of hires
    annual_cost: float  # Total annual cost (salary + burden)
    payback_months: float  # Quanti mesi per break-even
    expected_revenue_generation: float  # Expected annual revenue
    roi_percentage: float  # ROI %
    priority: str  # "critical", "high", "medium", "low"
    timing: str  # "immediate", "q1", "q2", "q3", "q4"
    rationale: str  # Spiegazione


@dataclass
class HiringPlan:
    """Piano assunzioni completo"""
    current_headcount: int
    target_headcount: int
    headcount_delta: int
    total_cost_year1: float  # Year 1 cost
    expected_revenue_uplift: float  # Year 1 revenue from hires
    expected_profit_uplift: float  # Year 1 profit
    payback_months: float  # Aggregate payback
    recommendations: List[HiringRecommendation]
    key_actions: List[str]  # Top 3 actions

    def to_dict(self) -> Dict[str, Any]:
        return {
            "current_headcount": self.current_headcount,
            "target_headcount": self.target_headcount,
            "headcount_delta": self.headcount_delta,
            "total_cost_year1": self.total_cost_year1,
            "expected_revenue_uplift": self.expected_revenue_uplift,
            "expected_profit_uplift": self.expected_profit_uplift,
            "payback_months": self.payback_months,
            "recommendations": [r.__dict__ for r in self.recommendations],
            "key_actions": self.key_actions,
        }


# =============================================================================
# Helpers
# =============================================================================

def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _infer_headcount(revenue: float, revenue_per_person: float = 250_000) -> int:
    """Inferisce headcount da revenue"""
    return max(1, int(_asf(revenue, 0.0) / _asf(revenue_per_person, 250_000)))


# =============================================================================
# Hiring Engine
# =============================================================================

class HiringEngine:
    """
    Analizza headcount attuale e raccomanda assunzioni/restructuring
    per massimizzare profittabilità
    """

    # Benchmark per sector
    REVENUE_PER_PERSON_BENCHMARK = {
        "tech": 500_000,      # Tech company per dev
        "saas": 400_000,
        "manufacturing": 150_000,
        "retail": 100_000,
        "services": 200_000,
        "default": 250_000,
    }

    SALARY_COST_PCT_BENCHMARK = {
        "tech": 0.35,         # 35% of revenue
        "saas": 0.30,
        "manufacturing": 0.25,
        "retail": 0.20,
        "services": 0.40,
        "default": 0.30,
    }

    def analyze(
        self,
        fatturato: float,
        utile: float,
        headcount: int = 0,
        salary_expenses: float = 0.0,
        sector: str = "default",
    ) -> HiringPlan:
        """
        Analizza headcount attuale e genera piano assunzioni
        
        Se headcount non è fornito, lo inferisce da fatturato
        Se salary_expenses non è fornito, lo stima
        """

        revenue = _asf(fatturato, 0.0)
        profit = _asf(utile, 0.0)

        # Inferisci headcount se non fornito
        benchmark_revenue_per_person = self.REVENUE_PER_PERSON_BENCHMARK.get(sector, 250_000)
        if headcount <= 0:
            headcount = _infer_headcount(revenue, benchmark_revenue_per_person)

        # Stima salary expenses se non fornito
        benchmark_salary_pct = self.SALARY_COST_PCT_BENCHMARK.get(sector, 0.30)
        if salary_expenses <= 0:
            salary_expenses = revenue * benchmark_salary_pct
        else:
            salary_expenses = _asf(salary_expenses, 0.0)

        # Calcola metriche attuali
        revenue_per_person = safe_div(revenue, headcount, 0.0)
        profit_per_person = safe_div(profit, headcount, 0.0)
        salary_cost_pct = safe_div(salary_expenses, revenue, 0.0)

        # Productivity score (0-1, 1.0 = benchmark)
        productivity_score = safe_div(revenue_per_person, benchmark_revenue_per_person, 0.0)

        # Determina se over/understaffed
        is_overstaffed = productivity_score < 0.85  # <85% di benchmark
        is_understaffed = productivity_score > 1.15  # >115% di benchmark

        # Desiderato: target alla productivity = 1.0
        if is_overstaffed:
            # Troppi dipendenti: suggerisci optimization
            target_headcount = int(revenue / benchmark_revenue_per_person)
            gap_people = headcount - target_headcount
        elif is_understaffed:
            # Troppo pochi dipendenti: suggerisci assunzione
            target_headcount = int(revenue / benchmark_revenue_per_person) + 1
            gap_people = target_headcount - headcount
        else:
            # OK: mantieni attuale
            target_headcount = headcount
            gap_people = 0

        # Genera raccomandazioni assunzione
        recommendations = []
        total_cost = 0.0
        total_revenue_uplift = 0.0
        total_profit_uplift = 0.0

        if is_understaffed or gap_people > 0:
            # Raccomanda assunzioni per colmare il gap
            for role_type, count, revenue_gen in self._get_hiring_priorities(
                revenue, profit, sector, gap_people
            ):
                avg_salary = salary_expenses / headcount if headcount > 0 else 50_000
                role_cost = count * avg_salary
                role_revenue = count * revenue_gen
                role_profit = role_revenue * 0.25  # Assume 25% margin

                payback = float('inf')
                if role_cost > 0:
                    payback = (role_cost * 12.0) / max(role_profit, 1.0)

                priority = "critical" if is_understaffed else "high"
                timing = "immediate" if is_understaffed else "q1"

                rec = HiringRecommendation(
                    role=role_type,
                    count=count,
                    annual_cost=role_cost,
                    payback_months=payback,
                    expected_revenue_generation=role_revenue,
                    roi_percentage=safe_div(role_profit * 100.0, role_cost, 0.0),
                    priority=priority,
                    timing=timing,
                    rationale=f"Assunzioni {role_type} colmano gap productivity, generano €{role_revenue:.0f} ricavi/anno",
                )
                recommendations.append(rec)
                total_cost += role_cost
                total_revenue_uplift += role_revenue
                total_profit_uplift += role_profit

        elif is_overstaffed and gap_people > 0:
            # Raccomanda restructuring
            rec = HiringRecommendation(
                role="Organization Optimization",
                count=-gap_people,
                annual_cost=-gap_people * (salary_expenses / headcount) if headcount > 0 else 0,
                payback_months=0.0,
                expected_revenue_generation=0.0,
                roi_percentage=float('inf'),  # Immediate savings
                priority="high",
                timing="q1",
                rationale=f"Ridurre headcount di {gap_people} persone, liberare €{gap_people * (salary_expenses / headcount) if headcount > 0 else 0:.0f}/anno",
            )
            recommendations.append(rec)
            total_cost = rec.annual_cost  # Negative
            total_profit_uplift = -rec.annual_cost  # Savings

        # Aggregate payback
        if total_cost > 0:
            aggregate_payback = safe_div(total_cost * 12.0, max(total_profit_uplift, 1.0), 99.0)
        else:
            aggregate_payback = 0.0

        # Key actions
        key_actions = []
        if is_understaffed:
            key_actions.append(f"🔴 IMMEDIATO: Assumere {gap_people} persone per colmare productivity gap")
        if is_overstaffed:
            key_actions.append(f"🟡 ENTRO Q1: Restructurare org, ridurre a {target_headcount} FTE ottimali")
        if productivity_score < 0.7:
            key_actions.append("🔴 CRITICO: Produttività sotto controllo - diagnosi dettagliata urgente")
        if salary_cost_pct > benchmark_salary_pct * 1.15:
            key_actions.append(f"🟡 Spese salariali {salary_cost_pct:.0%} vs benchmark {benchmark_salary_pct:.0%} - rev skill mix")

        return HiringPlan(
            current_headcount=headcount,
            target_headcount=target_headcount,
            headcount_delta=gap_people,
            total_cost_year1=total_cost,
            expected_revenue_uplift=total_revenue_uplift,
            expected_profit_uplift=total_profit_uplift,
            payback_months=aggregate_payback,
            recommendations=recommendations,
            key_actions=key_actions[:3],  # Top 3
        )

    def _get_hiring_priorities(
        self,
        revenue: float,
        profit: float,
        sector: str,
        gap_people: int,
    ) -> List[Tuple[str, int, float]]:
        """
        Ritorna priority hiring roles per settore
        Returns: [(role_name, count, revenue_per_person), ...]
        """

        if sector.lower() == "tech":
            return [
                ("Engineering", gap_people, 500_000),
            ]
        elif sector.lower() == "saas":
            return [
                ("Engineering", int(gap_people * 0.5), 400_000),
                ("Sales", int(gap_people * 0.3), 300_000),
                ("Support", int(gap_people * 0.2), 200_000),
            ]
        elif sector.lower() == "manufacturing":
            return [
                ("Production", int(gap_people * 0.6), 150_000),
                ("Quality", int(gap_people * 0.2), 120_000),
                ("Logistics", int(gap_people * 0.2), 100_000),
            ]
        elif sector.lower() == "retail":
            return [
                ("Sales Associates", int(gap_people * 0.7), 80_000),
                ("Managers", int(gap_people * 0.2), 120_000),
                ("Operations", int(gap_people * 0.1), 100_000),
            ]
        else:  # default
            return [
                ("Operations", int(gap_people * 0.5), 200_000),
                ("Sales", int(gap_people * 0.3), 150_000),
                ("Admin", int(gap_people * 0.2), 100_000),
            ]


def analyze_headcount(
    fatturato: float,
    utile: float,
    headcount: int = 0,
    salary_expenses: float = 0.0,
    sector: str = "default",
) -> HiringPlan:
    """Wrapper pubblico per headcount analysis"""
    return HiringEngine().analyze(
        fatturato=fatturato,
        utile=utile,
        headcount=headcount,
        salary_expenses=salary_expenses,
        sector=sector,
    )
