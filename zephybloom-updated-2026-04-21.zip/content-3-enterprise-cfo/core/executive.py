# -*- coding: utf-8 -*-
# content/core/executive.py — Executive summary + advisories (coerente con rate in frazione)
from __future__ import annotations

from typing import List, Dict
from core.schemas import KPI, Advisory
from utils.fmt_parse import fmt_eur, fmt_pct, fmt_number_eu


def _pct_frac(x: float) -> float:
    """
    Assicura che il valore passato a fmt_pct sia una frazione (0..1).
    Se arriva già in %, lo riporta a frazione in modo cauto.
    """
    try:
        v = float(x)
    except Exception:
        return 0.0
    if v <= 1.0:
        return v
    # se è plausibilmente una percentuale (es. 12.5), converti
    return v / 100.0


def executive_summary(k: KPI) -> str:
    """
    Headline numerica compatta:
      Ricavi | MC (con MC%) | BEP | Utile (con Net Margin) | EBITDA | ROI | CCC | Z
    Convenzioni:
      - mc_rate, net_margin_rate, roi sono frazioni 0..1
      - fmt_pct riceve frazioni (assicurato da _pct_frac)
      - CCC in giorni, Z con 2 decimali
    """
    return " | ".join([
        f"Ricavi {fmt_eur(k.fatturato)}",
        f"MC {fmt_eur(k.margine_contribuzione)} ({fmt_pct(_pct_frac(k.mc_rate))})",
        f"BEP {fmt_eur(k.break_even)}",
        f"Utile {fmt_eur(k.utile)} (NM {fmt_pct(_pct_frac(k.net_margin_rate))})",
        f"EBITDA {fmt_eur(k.ebitda)}",
        f"ROI {fmt_pct(_pct_frac(k.roi))}",
        f"CCC {int(round(k.ccc))}g",
        f"Z {k.altman_z:.2f}",
    ])


def advise_from_rules(alerts: List[Dict[str, float]]) -> List[Advisory]:
    """
    Converte gli alerts del rules engine in Advisory tipizzati.
    Campi attesi in ogni alert: code, message, severity.
    """
    out: List[Advisory] = []
    for a in alerts or []:
        out.append(Advisory(
            code=str(a.get("code", "RULE")),
            title=str(a.get("message", "Regola")),
            detail=str(a.get("detail", "")),
            severity=str(a.get("severity", "info")),
            suggestions=list(a.get("suggestions", [])) if isinstance(a.get("suggestions"), list) else [],
            meta={},
        ))
    return out
