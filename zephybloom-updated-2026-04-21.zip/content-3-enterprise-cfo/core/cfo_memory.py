"""CFO memory layer.

Turns stored monthly metrics into a short executive memory: what changed,
where momentum is improving or worsening, and what the CFO should watch next.
"""

from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from core.company_metrics import get_company_metrics_history, metrics_to_dict, save_company_metrics
from core.trend_analysis import TrendAnalyzer


def save_cfo_memory_snapshot(
    session: Session,
    tenant_id: str,
    company_id: str,
    company_name: str,
    metrics: Dict[str, float],
    measurement_date=None,
    industry: Optional[str] = None,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    record = save_company_metrics(
        session=session,
        tenant_id=tenant_id,
        company_id=company_id,
        company_name=company_name,
        metrics=metrics,
        measurement_date=measurement_date,
        industry=industry,
        notes=notes,
    )
    return {
        "company_id": record.company_id,
        "company_name": record.company_name,
        "period": f"{record.period_year}-{record.period_month:02d}",
        "metrics": metrics_to_dict(record),
    }


def build_cfo_memory_summary(
    session: Session,
    tenant_id: str,
    company_id: str,
    months: int = 12,
) -> Dict[str, Any]:
    records = get_company_metrics_history(
        session=session,
        tenant_id=tenant_id,
        company_id=company_id,
        months=months,
    )
    if not records:
        return {
            "has_memory": False,
            "company_id": company_id,
            "periods": [],
            "executive_memory": "Non ho ancora storico per questa azienda.",
            "trend_summary": "Salva almeno 2 mesi di dati per leggere trend e deterioramenti.",
            "alerts": [],
            "next_memory_actions": [
                "Salva il mese corrente",
                "Aggiungi il mese precedente",
                "Rilancia la memoria CFO",
            ],
        }

    periods = [
        {
            "period": f"{record.period_year}-{record.period_month:02d}",
            "fatturato": record.fatturato,
            "gross_margin_pct": record.gross_margin_pct,
            "ebitda_margin_pct": record.ebitda_margin_pct,
            "net_margin_pct": record.net_margin_pct,
            "roi_pct": record.roi_pct or 0,
        }
        for record in records
    ]

    if len(records) < 2:
        latest = records[-1]
        return {
            "has_memory": True,
            "company_id": company_id,
            "company_name": latest.company_name,
            "periods": periods,
            "executive_memory": (
                f"Ho 1 mese salvato per {latest.company_name}: fatturato EUR {latest.fatturato:,.0f}, "
                f"margine netto {latest.net_margin_pct:.1f}%."
            ),
            "trend_summary": "Serve un secondo mese per confrontare andamento e momentum.",
            "alerts": [],
            "next_memory_actions": ["Aggiungi il mese precedente o prossimo", "Poi chiedi: sto migliorando?"],
        }

    previous = records[-2]
    current = records[-1]
    analyzer = TrendAnalyzer()
    trends = analyzer.analyze_metrics(
        current_metrics=metrics_to_dict(current),
        previous_metrics=metrics_to_dict(previous),
        company_name=current.company_name,
    )

    revenue_change = _change_pct(current.fatturato, previous.fatturato)
    margin_change = current.net_margin_pct - previous.net_margin_pct
    executive_memory = _executive_memory(current.company_name, revenue_change, margin_change, trends.momentum_score)

    return {
        "has_memory": True,
        "company_id": company_id,
        "company_name": current.company_name,
        "periods": periods,
        "latest_period": periods[-1],
        "previous_period": periods[-2],
        "executive_memory": executive_memory,
        "trend_summary": trends.get_trend_summary(),
        "momentum_score": round(trends.momentum_score, 1),
        "momentum_label": "Improving" if trends.momentum_score > 10 else "Declining" if trends.momentum_score < -10 else "Stable",
        "alerts": trends.alerts,
        "next_memory_actions": _next_memory_actions(revenue_change, margin_change, trends.alerts),
    }


def _change_pct(current: float, previous: float) -> float:
    if not previous:
        return 0.0
    return ((current - previous) / abs(previous)) * 100


def _executive_memory(company_name: str, revenue_change: float, margin_change: float, momentum_score: float) -> str:
    if revenue_change > 0 and margin_change < -1:
        return (
            f"{company_name} sta crescendo, ma la qualita' della crescita peggiora: "
            f"fatturato {revenue_change:+.1f}% e margine netto {margin_change:+.1f} punti."
        )
    if revenue_change > 0 and margin_change >= 0:
        return (
            f"{company_name} mostra crescita sana: fatturato {revenue_change:+.1f}% "
            f"e margine netto {margin_change:+.1f} punti."
        )
    if revenue_change < 0 and margin_change > 0:
        return (
            f"{company_name} sta difendendo margine ma perde volume: fatturato {revenue_change:+.1f}% "
            f"e margine netto {margin_change:+.1f} punti."
        )
    if momentum_score < -10:
        return f"{company_name} mostra momentum debole: serve una War Room su margine, cassa e costi."
    return f"{company_name} ha andamento stabile: il prossimo valore nasce da trend piu' lunghi e dati operativi."


def _next_memory_actions(revenue_change: float, margin_change: float, alerts: List[str]) -> List[str]:
    if alerts:
        return ["Apri War Room sul primo alert", "Verifica dati che hanno causato il deterioramento", "Definisci una decisione con KPI di recupero"]
    if revenue_change > 0 and margin_change < -1:
        return ["Blocca crescita tossica", "Simula mix prezzo/costi", "Rivedi prodotti, canali o commesse a basso margine"]
    if revenue_change > 0:
        return ["Scala i segmenti con margine stabile", "Controlla cassa e costi fissi", "Registra l'esito delle decisioni"]
    return ["Capisci perche' il fatturato non cresce", "Proteggi margine e cassa", "Crea piano commerciale misurabile"]
