"""
Robust Input Validation for Decision System (FASE 1)

Handles edge cases and invalid inputs gracefully with specific, actionable error messages.
Supports partial data and fallback scenarios.
"""

import logging
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Validation result with data and error info"""
    is_valid: bool
    data: Dict[str, Any]
    errors: List[str]  # User-friendly error messages
    warnings: List[str]  # Non-fatal warnings
    recovery_suggestions: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict for API response"""
        return {
            "is_valid": self.is_valid,
            "data": self.data,
            "errors": self.errors,
            "warnings": self.warnings,
            "recovery_suggestions": self.recovery_suggestions,
        }


class RobustValidator:
    """Validate and sanitize input for decision system"""
    
    # Industry thresholds (universal fallback)
    DEFAULT_GROSS_MARGIN = 0.30
    DEFAULT_NET_MARGIN = 0.10
    DEFAULT_EBITDA_MARGIN = 0.18
    DEFAULT_ROI = 0.20
    DEFAULT_MAX_FIXED_COST_PCT = 0.35
    
    @staticmethod
    def validate_financial_data(
        fatturato: float,
        costi_variabili: float,
        costi_fissi: float,
        investimenti: Optional[float] = None,
        settore: Optional[str] = None,
        company_name: Optional[str] = None,
        **kwargs
    ) -> ValidationResult:
        """
        Validate and sanitize financial input.
        
        Handles:
        - Missing or zero values
        - Negative values
        - Invalid combinations (costs > revenue)
        - Unknown sectors
        - Partial data
        
        Returns ValidationResult with sanitized data and errors.
        """
        
        errors: List[str] = []
        warnings: List[str] = []
        data = {}
        
        # ===== FATTURATO VALIDATION =====
        try:
            fatturato = float(fatturato) if fatturato is not None else 0
            
            if fatturato < 0:
                errors.append("Fatturato non può essere negativo. Inserisci un valore positivo.")
                fatturato = 0
            elif fatturato == 0:
                errors.append("Fatturato è zero. Fornisci entrata di vendita per analisi significativa.")
            
            data["fatturato"] = max(0, fatturato)
            
        except (ValueError, TypeError) as e:
            errors.append(f"Fatturato non è un numero valido. Ricevuto: {fatturato}")
            data["fatturato"] = 0
        
        # ===== COSTI VARIABILI VALIDATION =====
        try:
            costi_variabili = float(costi_variabili) if costi_variabili is not None else 0
            
            if costi_variabili < 0:
                errors.append("Costi variabili non possono essere negativi.")
                costi_variabili = 0
            
            data["costi_variabili"] = max(0, costi_variabili)
            
        except (ValueError, TypeError) as e:
            errors.append(f"Costi variabili non è un numero valido.")
            data["costi_variabili"] = 0
        
        # ===== COSTI FISSI VALIDATION =====
        try:
            costi_fissi = float(costi_fissi) if costi_fissi is not None else 0
            
            if costi_fissi < 0:
                errors.append("Costi fissi non possono essere negativi.")
                costi_fissi = 0
            
            data["costi_fissi"] = max(0, costi_fissi)
            
        except (ValueError, TypeError) as e:
            errors.append(f"Costi fissi non è un numero valido.")
            data["costi_fissi"] = 0
        
        # ===== RELATIONSHIP VALIDATION =====
        total_costs = data["costi_variabili"] + data["costi_fissi"]
        
        if data["fatturato"] > 0:
            if total_costs > data["fatturato"]:
                diff = total_costs - data["fatturato"]
                warnings.append(
                    f"Costi totali (€{total_costs:,.0f}) superano fatturato (€{data['fatturato']:,.0f}). "
                    f"Stai perdendo €{diff:,.0f}/anno. Questo è critico."
                )
            
            if data["costi_variabili"] > data["fatturato"]:
                errors.append(
                    f"Costi variabili (€{data['costi_variabili']:,.0f}) superano fatturato (€{data['fatturato']:,.0f}). "
                    f"Il modello di business ha problemi fondamentali."
                )
        
        # ===== INVESTIMENTI VALIDATION =====
        try:
            investimenti = float(investimenti) if investimenti is not None else 0
            
            if investimenti < 0:
                warnings.append("Investimenti non possono essere negativi. Ignorato.")
                investimenti = 0
            
            data["investimenti"] = max(0, investimenti)
            
        except (ValueError, TypeError):
            data["investimenti"] = 0
        
        # ===== SETTORE VALIDATION =====
        valid_sectors = ["saas", "retail", "manufacturing", "services", "ecommerce"]
        
        if settore:
            settore_lower = str(settore).lower().strip()
            if settore_lower not in valid_sectors:
                warnings.append(
                    f"Settore '{settore}' non riconosciuto. "
                    f"Settori validi: {', '.join(valid_sectors)}. "
                    f"Uso thresholds universali."
                )
                data["settore"] = "default"
            else:
                data["settore"] = settore_lower
        else:
            data["settore"] = "default"
        
        # ===== COMPANY NAME =====
        data["company_name"] = str(company_name).strip() if company_name else "Unnamed Company"
        
        # ===== Additional fields =====
        for key in kwargs:
            if key not in ["dso_days", "dio_days", "dpo_days"]:
                continue
            try:
                value = float(kwargs[key]) if kwargs[key] is not None else 0
                data[key] = max(0, value)
            except (ValueError, TypeError):
                data[key] = 0
        
        # ===== DETERMINE VALIDITY =====
        is_valid = len(errors) == 0
        
        # Data is recoverable if we have at least fatturato > 0
        recovery_suggestions = None
        if data["fatturato"] == 0:
            recovery_suggestions = "Fornisci un fatturato reale per un'analisi significativa."
        elif len(errors) > 0:
            recovery_suggestions = "Correggi i campi marcati in rosso sopra. I valori non validi sono stati azzerati."
        
        logger.info(
            f"[VALIDATION] Processed {data['company_name']}: "
            f"fatturato=€{data['fatturato']:,.0f}, "
            f"settore={data['settore']}, "
            f"valid={is_valid}"
        )
        
        if errors:
            logger.warning(f"[VALIDATION] Errors: {errors}")
        
        if warnings:
            logger.warning(f"[VALIDATION] Warnings: {warnings}")
        
        return ValidationResult(
            is_valid=is_valid,
            data=data,
            errors=errors,
            warnings=warnings,
            recovery_suggestions=recovery_suggestions,
        )
    
    @staticmethod
    def calculate_kpi_safely(
        fatturato: float,
        costi_variabili: float,
        costi_fissi: float,
        investimenti: float = 0,
    ) -> Tuple[Dict[str, Any], List[str]]:
        """
        Calculate KPIs with guard clauses against division by zero and invalid states.
        
        Returns: (kpi_dict, warnings_list)
        """
        warnings = []
        kpis = {}
        
        # Guard: fatturato > 0
        if fatturato <= 0:
            warnings.append("Fatturato è zero o negativo. KPI non calcolabili.")
            return {
                "gross_profit_eur": 0,
                "gross_margin_pct": None,
                "ebitda_eur": 0,
                "ebitda_margin_pct": None,
                "net_profit_eur": 0,
                "net_margin_pct": None,
                "roi_pct": None,
            }, warnings
        
        # Gross Profit
        gross_profit = fatturato - costi_variabili
        gross_margin_pct = (gross_profit / fatturato) * 100 if fatturato > 0 else None
        
        if gross_margin_pct is not None and gross_margin_pct < 0:
            warnings.append(
                f"Gross margin negativo ({gross_margin_pct:.1f}%). "
                f"Costi variabili superano fatturato. Problema critico."
            )
        
        kpis["gross_profit_eur"] = gross_profit
        kpis["gross_margin_pct"] = gross_margin_pct
        
        # EBITDA
        ebitda = gross_profit - costi_fissi
        ebitda_margin_pct = (ebitda / fatturato) * 100 if fatturato > 0 else None
        
        if ebitda_margin_pct is not None and ebitda < 0:
            warnings.append(
                f"EBITDA negativo (€{ebitda:,.0f}). "
                f"Costi fissi {costi_fissi} sono troppo alti per fatturato {fatturato}."
            )
        
        kpis["ebitda_eur"] = ebitda
        kpis["ebitda_margin_pct"] = ebitda_margin_pct
        
        # Net Profit (assuming ebitda = net for simplicity in this context)
        net_margin_pct = ebitda_margin_pct  # Simplified
        kpis["net_profit_eur"] = ebitda
        kpis["net_margin_pct"] = net_margin_pct
        
        # ROI
        if investimenti and investimenti > 0:
            roi_pct = (ebitda / investimenti) * 100
            kpis["roi_pct"] = roi_pct
        else:
            kpis["roi_pct"] = None
        
        return kpis, warnings
    
    @staticmethod
    def get_severity_flags(
        gross_margin_pct: Optional[float],
        net_margin_pct: Optional[float],
        ebitda_eur: float,
        roi_pct: Optional[float],
        fatturato: float,
    ) -> Tuple[str, str]:
        """
        Determine overall health status and primary issue.
        
        Returns: (status, primary_issue)
        Status: "healthy" | "warning" | "critical"
        """
        
        status = "healthy"
        primary_issue = "Financial metrics are healthy"
        
        # Check profitability
        if net_margin_pct is not None:
            if net_margin_pct < 0:
                status = "critical"
                primary_issue = "Company is loss-making (negative profit)"
            elif net_margin_pct < 5:
                status = "critical"
                primary_issue = "Margin critically low (<5%)"
            elif net_margin_pct < 10:
                status = "warning"
                primary_issue = "Margin is thin (5-10%)"
        
        # Check profitability by gross margin
        if gross_margin_pct is not None and gross_margin_pct < 20:
            if status != "critical":
                status = "warning"
            primary_issue = "Gross margin too low (<20%)"
        
        # Check absolute profit
        if ebitda_eur < 0:
            status = "critical"
            primary_issue = "EBITDA is negative - operating at loss"
        elif ebitda_eur > 0 and fatturato > 0:
            if ebitda_eur / fatturato < 0.03:  # < 3% margin
                status = "critical"
                primary_issue = "Minimal margin - business is fragile"
        
        return status, primary_issue


def validate_input_safe(
    fatturato: float,
    costi_variabili: float,
    costi_fissi: float,
    investimenti: Optional[float] = None,
    settore: Optional[str] = None,
    company_name: Optional[str] = None,
    **kwargs
) -> ValidationResult:
    """Convenience wrapper for RobustValidator"""
    return RobustValidator.validate_financial_data(
        fatturato=fatturato,
        costi_variabili=costi_variabili,
        costi_fissi=costi_fissi,
        investimenti=investimenti,
        settore=settore,
        company_name=company_name,
        **kwargs
    )


def get_validator() -> RobustValidator:
    return RobustValidator()
