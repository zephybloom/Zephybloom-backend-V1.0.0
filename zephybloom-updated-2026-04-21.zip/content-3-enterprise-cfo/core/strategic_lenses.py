"""Strategic lenses for CFO War Room.

This module translates financial analysis into investor/operator style lenses.
It does not imitate specific people. It uses durable business concepts such as
capital allocation, pricing power, unit economics, cash discipline and growth
readiness to produce a deterministic decision layer.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from api.schemas_cfo import AnalyzeResponse
from core.cfo_intent_router import CFOIntent, IntentResult


def build_cfo_war_room(
    analysis: AnalyzeResponse,
    industry_insight: Dict[str, Any],
    intent: Optional[IntentResult] = None,
) -> Dict[str, Any]:
    """Build a structured CFO War Room decision pack."""

    kpi = analysis.kpi_snapshot
    score_breakdown = _score_breakdown(analysis, industry_insight)
    total_score = sum(score_breakdown.values())
    posture = industry_insight.get("strategic_posture", "review")
    primary = industry_insight.get("primary_constraint", {})

    lenses = [
        _capital_allocation_lens(kpi, industry_insight),
        _pricing_power_lens(kpi, industry_insight),
        _unit_economics_lens(kpi, industry_insight),
        _cash_discipline_lens(kpi, industry_insight),
        _growth_readiness_lens(kpi, industry_insight),
    ]

    final_decision = _final_decision(
        score=total_score,
        posture=posture,
        primary_constraint=primary.get("type"),
        intent=intent.intent if intent else CFOIntent.UNKNOWN,
        lenses=lenses,
    )

    return {
        "version": "cfo-war-room-v1",
        "business_quality_score": total_score,
        "score_label": _score_label(total_score),
        "score_breakdown": score_breakdown,
        "lenses": lenses,
        "final_decision": final_decision,
        "what_breaks_first": _what_breaks_first(kpi, industry_insight),
        "next_30_days": _next_30_days(final_decision["action"], intent.intent if intent else CFOIntent.UNKNOWN),
    }


def _score_breakdown(analysis: AnalyzeResponse, insight: Dict[str, Any]) -> Dict[str, int]:
    kpi = analysis.kpi_snapshot
    capital = insight.get("capital_efficiency", {})
    posture = insight.get("strategic_posture", "review")

    moat = _clamp_score(10 + (5 if kpi.gross_margin_pct >= 50 else 0) + (5 if kpi.net_margin_pct >= 15 else 0), 0, 20)
    pricing_power = _clamp_score(8 + int(max(0, min(kpi.gross_margin_pct - 30, 30)) / 3), 0, 20)
    cash_efficiency = _clamp_score(12 if kpi.ccc_days is None else 20 - int(min(max(kpi.ccc_days, 0), 100) / 6), 0, 20)
    margin_durability = _clamp_score(6 + int(max(0, min(kpi.net_margin_pct, 40)) / 2), 0, 20)
    scalability = _clamp_score(
        8
        + (5 if posture == "scale_selectively" else 0)
        + (4 if capital.get("status") in {"productive", "high_yield"} else 0)
        + (3 if kpi.ebitda_margin_pct >= 15 else 0),
        0,
        20,
    )

    return {
        "moat_proxy": moat,
        "pricing_power": pricing_power,
        "cash_efficiency": cash_efficiency,
        "margin_durability": margin_durability,
        "scalability": scalability,
    }


def _capital_allocation_lens(kpi, insight: Dict[str, Any]) -> Dict[str, str]:
    roi = kpi.roi_pct
    if roi is None:
        finding = "ROI non calcolabile: mancano investimenti affidabili."
        risk = "Senza ROI non sai se la crescita sta creando valore o solo assorbendo capitale."
        decision = "Inserisci investimenti e payback prima di finanziare nuovi progetti."
    elif roi >= 35:
        finding = f"ROI molto alto ({roi:.1f}%): il capitale oggi rende bene."
        risk = "Potrebbe dipendere da investimenti bassi; verifica se il rendimento scala davvero."
        decision = "Reinvesti solo nei canali con payback provato e margine netto difendibile."
    elif roi >= 15:
        finding = f"ROI produttivo ({roi:.1f}%): capitale impiegato in modo sano."
        risk = "Il rischio e' disperdere capitale su iniziative non misurate."
        decision = "Finanzia test piccoli, con kill switch su margine e cassa."
    else:
        finding = f"ROI debole ({roi:.1f}%): il capitale non sta rendendo abbastanza."
        risk = "Scalare ora puo' amplificare sprechi."
        decision = "Taglia investimenti a basso ritorno e concentra il capitale sui canali gia' profittevoli."

    return _lens("Capital Allocation", finding, risk, decision)


def _pricing_power_lens(kpi, insight: Dict[str, Any]) -> Dict[str, str]:
    if kpi.gross_margin_pct >= 55:
        finding = f"Margine lordo {kpi.gross_margin_pct:.1f}%: c'e' spazio per pricing e packaging."
        risk = "Vendere piu' volume con sconti puo' buttare via potere di prezzo."
        decision = "Testa +3/+5% prezzo o pacchetto premium prima di aumentare marketing."
    elif kpi.gross_margin_pct >= 35:
        finding = f"Margine lordo {kpi.gross_margin_pct:.1f}%: modello sano ma non infinito."
        risk = "Troppi sconti o canali costosi possono comprimere il margine."
        decision = "Segmenta clienti per sensibilita' prezzo e spingi offerte a margine alto."
    else:
        finding = f"Margine lordo {kpi.gross_margin_pct:.1f}%: contribution margin fragile."
        risk = "Ogni vendita aggiuntiva potrebbe contribuire troppo poco."
        decision = "Rivedi prezzo, mix prodotto e costo variabile prima di scalare vendite."

    return _lens("Pricing Power", finding, risk, decision)


def _unit_economics_lens(kpi, insight: Dict[str, Any]) -> Dict[str, str]:
    if kpi.net_margin_pct >= 20:
        finding = f"Margine netto {kpi.net_margin_pct:.1f}%: unit economics forti."
        risk = "Il rischio e' acquisire clienti peggiori per crescere piu' in fretta."
        decision = "Scala solo segmenti/clienti con margine simile o superiore alla media attuale."
    elif kpi.net_margin_pct >= 5:
        finding = f"Margine netto {kpi.net_margin_pct:.1f}%: profitto positivo ma da proteggere."
        risk = "Costi fissi e acquisizione clienti possono mangiare l'utile."
        decision = "Misura margine per cliente, prodotto e canale prima di investire."
    else:
        finding = f"Margine netto {kpi.net_margin_pct:.1f}%: troppo poco cuscinetto."
        risk = "Crescere puo' aumentare complessita' senza creare cassa."
        decision = "Ripara margine e costi prima di finanziare crescita."

    return _lens("Unit Economics", finding, risk, decision)


def _cash_discipline_lens(kpi, insight: Dict[str, Any]) -> Dict[str, str]:
    if kpi.ccc_days is None:
        return _lens(
            "Cash Discipline",
            "Ciclo di cassa non misurato: non sappiamo quanto velocemente l'utile diventa cassa.",
            "Un'azienda profittevole puo' comunque andare sotto stress se incassa tardi.",
            "Aggiungi DSO, DIO e DPO; poi controlla se la crescita assorbe o libera cassa.",
        )

    if kpi.ccc_days <= 45:
        finding = f"CCC {kpi.ccc_days:.0f} giorni: ciclo di cassa gestibile."
        risk = "La crescita puo' comunque assorbire capitale circolante."
        decision = "Mantieni incassi e scorte sotto controllo mentre aumenti vendite."
    else:
        finding = f"CCC {kpi.ccc_days:.0f} giorni: troppa cassa resta bloccata."
        risk = "Crescere puo' peggiorare liquidita' anche con utile positivo."
        decision = "Riduci DSO/magazzino prima di spingere crescita aggressiva."

    return _lens("Cash Discipline", finding, risk, decision)


def _growth_readiness_lens(kpi, insight: Dict[str, Any]) -> Dict[str, str]:
    posture = insight.get("strategic_posture")
    if posture == "scale_selectively":
        finding = "Il business puo' crescere, ma in modo selettivo."
        risk = "Il primo punto che si rompe sara' la qualita' della crescita: margini, sconti o costi di acquisizione."
        decision = "Cresci con test: +5% prezzo, +10% ticket medio, upsell clienti attuali."
    elif posture == "stabilize":
        finding = "Prima serve stabilizzare."
        risk = "La crescita adesso puo' amplificare perdite."
        decision = "Blocca iniziative non essenziali e torna a margine positivo."
    else:
        finding = "La crescita e' possibile, ma richiede ottimizzazione."
        risk = "Senza focus, i costi saliranno prima dei ricavi."
        decision = "Scegli una leva primaria: prezzo, mix clienti, costi variabili o cash cycle."

    return _lens("Growth Readiness", finding, risk, decision)


def _final_decision(
    score: int,
    posture: str,
    primary_constraint: Optional[str],
    intent: CFOIntent,
    lenses: List[Dict[str, str]],
) -> Dict[str, Any]:
    if posture == "stabilize" or primary_constraint == "profitability":
        action = "STABILIZE"
        why = "Prima bisogna fermare perdita/margine debole; la crescita ora aumenterebbe rischio."
    elif score >= 78 and intent == CFOIntent.GROWTH_STRATEGY:
        action = "TEST_GROWTH"
        why = "Qualita' economica buona: puoi testare crescita, ma con kill switch su margine e cassa."
    elif primary_constraint in {"unit_economics", "operating_leverage"}:
        action = "REPAIR_MARGIN"
        why = "La priorita' e' aumentare contribution margin o alleggerire costi fissi."
    elif primary_constraint == "cash_cycle":
        action = "FIX_CASH"
        why = "La crescita rischia di assorbire cassa prima di generare ritorno."
    else:
        action = "OPTIMIZE"
        why = "Il business regge; la prossima leva va scelta con simulazioni e test controllati."

    return {
        "action": action,
        "why": why,
        "primary_lens": lenses[0]["name"] if lenses else "CFO Review",
        "kill_switch": _kill_switch(action),
    }


def _what_breaks_first(kpi, insight: Dict[str, Any]) -> List[Dict[str, str]]:
    items = []
    primary = insight.get("primary_constraint", {}).get("type")

    if primary == "cash_cycle" or kpi.ccc_days is None:
        items.append({"area": "Cassa", "why": "utile e cassa possono divergere se incassi/scorte non sono sotto controllo."})
    if primary in {"unit_economics", "growth_quality"}:
        items.append({"area": "Margine", "why": "nuovi clienti o sconti possono abbassare il margine medio."})
    if primary in {"operating_leverage", "growth_quality"}:
        items.append({"area": "Costi fissi", "why": "struttura e personale possono crescere prima dei ricavi."})

    items.append({"area": "Focus commerciale", "why": "spingere tutti i clienti allo stesso modo crea fatturato poco profittevole."})
    return items[:4]


def _next_30_days(action: str, intent: CFOIntent) -> List[str]:
    if action == "TEST_GROWTH" or intent == CFOIntent.GROWTH_STRATEGY:
        return [
            "Segmenta clienti/prodotti per margine e ripetibilita'.",
            "Testa offerta premium o +3/+5% prezzo su un segmento controllato.",
            "Riapri preventivi persi e misura conversione, ticket medio e margine.",
            "Simula +10% vendite con costi variabili realistici.",
        ]
    if action == "REPAIR_MARGIN" or intent == CFOIntent.COST_OPTIMIZATION:
        return [
            "Separa costi variabili e fissi per impatto su margine.",
            "Simula -5% costi variabili e -5% costi fissi separatamente.",
            "Rinegozia fornitori o elimina spese non collegate a vendite/controllo.",
            "Misura effetto su EBITDA e cassa.",
        ]
    if action == "FIX_CASH":
        return [
            "Inserisci DSO, DIO e DPO reali.",
            "Riduci tempi incasso o aumenta acconti.",
            "Taglia scorte o work-in-progress lenti.",
            "Controlla se la crescita assorbe capitale circolante.",
        ]
    return [
        "Aggiorna dati finanziari reali.",
        "Esegui una simulazione sulla leva principale.",
        "Scegli una decisione da testare per 30 giorni.",
    ]


def _kill_switch(action: str) -> str:
    return {
        "TEST_GROWTH": "ferma il test se margine netto scende oltre 3 punti o incassi peggiorano.",
        "REPAIR_MARGIN": "ferma tagli che riducono vendite, qualita' o retention.",
        "FIX_CASH": "non finanziare crescita se DSO/magazzino peggiorano.",
        "STABILIZE": "non aumentare costi fissi finche' margine netto non torna positivo.",
        "OPTIMIZE": "non scalare una leva prima di averne simulato impatto su utile e cassa.",
    }.get(action, "ferma se utile, margine o cassa peggiorano.")


def _score_label(score: int) -> str:
    if score >= 85:
        return "excellent_business_quality"
    if score >= 70:
        return "strong_but_watch_scaling"
    if score >= 55:
        return "viable_needs_focus"
    return "fragile_requires_repair"


def _lens(name: str, finding: str, risk: str, decision: str) -> Dict[str, str]:
    return {
        "name": name,
        "finding": finding,
        "risk": risk,
        "decision": decision,
    }


def _clamp_score(value: int, minimum: int, maximum: int) -> int:
    return max(minimum, min(maximum, int(value)))
