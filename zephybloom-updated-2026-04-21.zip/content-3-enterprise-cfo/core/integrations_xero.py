"""
Xero Integration

Connects to Xero accounting software to sync:
- Financial data (revenue, costs, profit)
- Invoices
- Expenses
- Balance sheet
"""

from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, date
import requests
import json

from core.integrations_base import (
    AccountingIntegration,
    IntegrationConfig,
    IntegrationResult,
    IntegrationStatus,
    FinancialSnapshot,
    AuthenticationError,
    RateLimitError,
)


class XeroIntegration(AccountingIntegration):
    """
    Integrates with Xero accounting software via OAuth 2.0.
    
    Provides:
    - Financial snapshots (P&L data)
    - Invoice details
    - Expense reports
    - Customer aging
    """
    
    BASE_URL = "https://api.xero.com/api.xro/2.0"
    AUTH_URL = "https://identity.xero.com/connect/authorize"
    TOKEN_URL = "https://identity.xero.com/connect/token"
    
    def __init__(self, config: IntegrationConfig):
        super().__init__(config)
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.token_expires_at: Optional[datetime] = None
        self.tenant_id = config.tenant_id
    
    def authenticate(self) -> IntegrationResult:
        """
        Authenticate with Xero OAuth 2.0.
        
        Requires:
        - config.api_key (Client ID)
        - config.api_secret (Client Secret)
        - config.tenant_id (Organization ID)
        """
        try:
            if not self.config.api_key or not self.config.api_secret:
                raise AuthenticationError("Missing API credentials")
            
            # Using refresh token if available
            if self.refresh_token:
                return self._refresh_access_token()
            
            # Full OAuth flow would happen here
            # For this implementation, assume token is provided
            self.status = IntegrationStatus.AUTHENTICATED
            
            return IntegrationResult(
                success=True,
                data={"status": "authenticated"},
            )
        
        except Exception as e:
            self._log_error(str(e), "AUTH_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="AUTH_ERROR",
            )
    
    def _refresh_access_token(self) -> IntegrationResult:
        """Refresh access token using refresh token"""
        try:
            payload = {
                "grant_type": "refresh_token",
                "refresh_token": self.refresh_token,
                "client_id": self.config.api_key,
                "client_secret": self.config.api_secret,
            }
            
            response = requests.post(
                self.TOKEN_URL,
                data=payload,
                timeout=self.config.timeout_seconds,
            )
            
            if response.status_code == 200:
                data = response.json()
                self.access_token = data["access_token"]
                self.refresh_token = data.get("refresh_token", self.refresh_token)
                self.status = IntegrationStatus.AUTHENTICATED
                
                return IntegrationResult(success=True)
            else:
                raise AuthenticationError(f"Token refresh failed: {response.text}")
        
        except Exception as e:
            self._log_error(str(e), "TOKEN_ERROR")
            self.status = IntegrationStatus.EXPIRED
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="TOKEN_ERROR",
            )
    
    def sync_data(self) -> IntegrationResult:
        """Sync financial data from Xero"""
        try:
            if self.status != IntegrationStatus.AUTHENTICATED:
                return IntegrationResult(
                    success=False,
                    error="Not authenticated",
                    error_code="NOT_AUTHENTICATED",
                )
            
            # Get invoices and expenses for analysis
            invoices_result = self.get_invoices(
                start_date=date.today(),
                end_date=date.today(),
            )
            
            expenses_result = self.get_expenses(
                start_date=date.today(),
                end_date=date.today(),
            )
            
            self.last_sync = datetime.now()
            
            return IntegrationResult(
                success=True,
                data={
                    "invoices_synced": len(invoices_result[0] or []),
                    "expenses_synced": len(expenses_result[0] or []),
                },
            )
        
        except Exception as e:
            self._log_error(str(e), "SYNC_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="SYNC_ERROR",
            )
    
    def disconnect(self) -> IntegrationResult:
        """Disconnect from Xero"""
        try:
            self.access_token = None
            self.refresh_token = None
            self.status = IntegrationStatus.CONNECTING
            
            return IntegrationResult(success=True)
        
        except Exception as e:
            self._log_error(str(e), "DISCONNECT_ERROR")
            return IntegrationResult(
                success=False,
                error=str(e),
                error_code="DISCONNECT_ERROR",
            )
    
    def get_financial_snapshot(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[FinancialSnapshot], Optional[str]]:
        """
        Get P&L financial data from Xero.
        
        In production, this would:
        - Call Xero Reports API for P&L
        - Parse revenue, COGS, operating expenses
        - Calculate EBITDA and net profit
        """
        try:
            # Mock implementation
            # In production: call self._get_report("ProfitAndLoss", start_date, end_date)
            
            snapshot = FinancialSnapshot(
                fatturato=100_000,  # Would come from invoices
                costi_variabili=40_000,
                costi_fissi=30_000,
                gross_profit=60_000,
                ebitda=20_000,
                net_profit=15_000,
                period_start_date=start_date,
                period_end_date=end_date,
                source="xero",
                synced_at=datetime.now(),
            )
            
            return snapshot, None
        
        except Exception as e:
            return None, str(e)
    
    def get_invoices(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """
        Get invoices from Xero.
        
        Returns list of invoices with:
        - Invoice ID, date, amount
        - Customer name
        - Status (DRAFT, SUBMITTED, AUTHORISED, etc.)
        """
        try:
            # Mock implementation
            # In production: call Xero Invoices API
            
            invoices = [
                {
                    "invoice_id": "INV-001",
                    "customer": "Acme Corp",
                    "amount": 5000,
                    "date": start_date,
                    "status": "AUTHORISED",
                },
                {
                    "invoice_id": "INV-002",
                    "customer": "TechCorp",
                    "amount": 3500,
                    "date": start_date,
                    "status": "SUBMITTED",
                },
            ]
            
            return invoices, None
        
        except Exception as e:
            return None, str(e)
    
    def get_expenses(
        self,
        start_date: date,
        end_date: date,
    ) -> Tuple[Optional[List[Dict]], Optional[str]]:
        """
        Get expenses from Xero.
        
        Returns list of expense claims/bills with:
        - Expense ID, date, amount
        - Category (supplies, rent, salaries, etc.)
        - Status
        """
        try:
            # Mock implementation
            # In production: call Xero Bills/Expenses API
            
            expenses = [
                {
                    "expense_id": "EXP-001",
                    "category": "Supplies",
                    "amount": 250,
                    "date": start_date,
                    "vendor": "Office Depot",
                },
            ]
            
            return expenses, None
        
        except Exception as e:
            return None, str(e)
    
    def _get_report(
        self,
        report_type: str,
        start_date: date,
        end_date: date,
    ) -> Dict[str, Any]:
        """
        Get a report from Xero Reports API.
        
        Supported report types:
        - ProfitAndLoss
        - BalanceSheet
        - TrialBalance
        - AgedReceivables
        - AgedPayables
        """
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Xero-tenant-id": self.tenant_id,
            "Accept": "application/json",
        }
        
        params = {
            "fromDate": start_date.isoformat(),
            "toDate": end_date.isoformat(),
        }
        
        response = requests.get(
            f"{self.BASE_URL}/Reports/{report_type}",
            headers=headers,
            params=params,
            timeout=self.config.timeout_seconds,
        )
        
        if response.status_code == 429:
            raise RateLimitError("Xero API rate limit exceeded")
        
        response.raise_for_status()
        return response.json()
