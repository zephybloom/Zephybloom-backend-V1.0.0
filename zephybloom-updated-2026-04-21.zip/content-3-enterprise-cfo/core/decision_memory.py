"""Decision memory for CFO War Room.

Stores recommended decisions and their outcomes so the CFO can answer:
what is still open, what worked, what missed target, and what to repeat.
"""

from copy import deepcopy
from datetime import datetime, timedelta
import json
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from db.models import WarRoomDecisionMemory


_decision_memory: Dict[str, Dict[str, Dict[str, Any]]] = {}


def remember_war_room_decisions(tenant_id: str, war_room: Dict[str, Any], session: Optional[Session] = None) -> List[Dict[str, Any]]:
    """Store the current War Room decision tracker for a tenant."""

    tenant_bucket = _decision_memory.setdefault(tenant_id, {})
    saved: List[Dict[str, Any]] = []
    existing_records = list_decision_memory(tenant_id, session=session)
    queue_by_id = {
        item.get("decision_id"): item
        for item in war_room.get("decision_queue", [])
        if item.get("decision_id")
    }

    for tracker in war_room.get("execution_tracker", []):
        decision_id = tracker.get("decision_id")
        if not decision_id:
            continue
        queue_item = queue_by_id.get(decision_id, {})
        existing = tenant_bucket.get(decision_id, {})
        if session is not None:
            db_existing = get_decision_memory(tenant_id, decision_id, session=session)
            if db_existing:
                existing = db_existing
        sector = tracker.get("sector") or queue_item.get("sector")
        decision_type = queue_item.get("type") or existing.get("decision_type") or "war_room_decision"
        duplicate = _find_open_duplicate(existing_records, decision_id, sector, decision_type)
        if duplicate:
            saved.append({
                "decision_id": decision_id,
                "status": "duplicate_skipped",
                "duplicate_of": duplicate["decision_id"],
                "sector": sector,
                "decision_type": decision_type,
                "next_action": tracker.get("next_action"),
            })
            continue
        if existing.get("status") in {"done", "skipped", "archived"}:
            saved.append(deepcopy(existing))
            continue
        record = {
            **existing,
            "decision_id": decision_id,
            "source": "war_room",
            "sector": sector,
            "decision_type": decision_type,
            "rank": tracker.get("rank"),
            "owner": tracker.get("owner"),
            "status": existing.get("status") or tracker.get("status") or "todo",
            "decision": tracker.get("decision"),
            "next_action": tracker.get("next_action"),
            "success_metric": tracker.get("success_metric"),
            "evidence_needed": tracker.get("evidence_needed"),
            "follow_up_question": tracker.get("follow_up_question"),
            "expected_impact_eur": existing.get("expected_impact_eur"),
            "actual_impact_eur": existing.get("actual_impact_eur"),
            "outcome_review": existing.get("outcome_review"),
            "created_at": existing.get("created_at") or datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
        }
        if session is not None:
            _upsert_record(session, tenant_id, record)
        tenant_bucket[decision_id] = record
        saved.append(deepcopy(record))
    if session is not None:
        session.commit()
    return saved


def update_decision_status(
    tenant_id: str,
    decision_id: str,
    status: str,
    reason: Optional[str] = None,
    next_action: Optional[str] = None,
    expected_impact_eur: Optional[float] = None,
    postpone_days: Optional[int] = None,
    session: Optional[Session] = None,
) -> Dict[str, Any]:
    """Archive, reopen, postpone or update one remembered decision."""

    allowed_statuses = {"todo", "done", "skipped", "archived"}
    if status not in allowed_statuses:
        raise ValueError(f"Unsupported decision status: {status}")

    tenant_bucket = _decision_memory.setdefault(tenant_id, {})
    existing = get_decision_memory(tenant_id, decision_id, session=session) or tenant_bucket.get(decision_id)
    if not existing:
        raise KeyError(decision_id)

    review = deepcopy(existing.get("outcome_review") or {})
    if reason:
        review["status_reason"] = reason
    if status == "archived":
        review["status"] = "archived"
        review["archived_reason"] = reason or "Decisione archiviata dalla War Room."
    elif status == "todo" and postpone_days:
        review["status"] = "postponed"
        review["postpone_days"] = postpone_days
        review["next_review_at"] = (datetime.utcnow() + timedelta(days=postpone_days)).isoformat()

    record = {
        **existing,
        "status": status,
        "next_action": next_action or existing.get("next_action"),
        "expected_impact_eur": expected_impact_eur if expected_impact_eur is not None else existing.get("expected_impact_eur"),
        "outcome_review": review or existing.get("outcome_review"),
        "updated_at": datetime.utcnow().isoformat(),
        "created_at": existing.get("created_at") or datetime.utcnow().isoformat(),
    }
    if session is not None:
        _upsert_record(session, tenant_id, record)
        session.commit()
    tenant_bucket[decision_id] = record
    return deepcopy(_enrich_record(record))


def update_decision_outcome(
    tenant_id: str,
    decision_id: str,
    was_implemented: bool,
    actual_impact_eur: float,
    expected_impact_eur: Optional[float],
    outcome_review: Dict[str, Any],
    decision_context: Dict[str, Any],
    session: Optional[Session] = None,
) -> Dict[str, Any]:
    """Update one decision after feedback."""

    tenant_bucket = _decision_memory.setdefault(tenant_id, {})
    existing = tenant_bucket.get(decision_id, {})
    record = {
        **existing,
        "decision_id": decision_id,
        "source": decision_context.get("source", existing.get("source", "decision_system")),
        "sector": decision_context.get("sector", existing.get("sector", "general")),
        "decision_type": decision_context.get("decision_type", existing.get("decision_type", "general_decision")),
        "status": "done" if was_implemented else "skipped",
        "expected_impact_eur": expected_impact_eur,
        "actual_impact_eur": actual_impact_eur,
        "outcome_review": outcome_review,
        "updated_at": datetime.utcnow().isoformat(),
        "created_at": existing.get("created_at") or datetime.utcnow().isoformat(),
    }
    if session is not None:
        _upsert_record(session, tenant_id, record)
        session.commit()
    tenant_bucket[decision_id] = record
    return deepcopy(record)


def list_decision_memory(tenant_id: str, status: Optional[str] = None, session: Optional[Session] = None) -> List[Dict[str, Any]]:
    if session is not None:
        query = session.query(WarRoomDecisionMemory).filter(WarRoomDecisionMemory.tenant_id == tenant_id)
        if status:
            query = query.filter(WarRoomDecisionMemory.status == status)
        records = [_enrich_record(_record_to_dict(record)) for record in query.all()]
        return sorted(records, key=lambda record: (record.get("status") != "todo", record.get("rank") or 999, record.get("updated_at") or ""))

    records = [_enrich_record(record) for record in _decision_memory.get(tenant_id, {}).values()]
    if status:
        records = [record for record in records if record.get("status") == status]
    return sorted(deepcopy(records), key=lambda record: (record.get("status") != "todo", record.get("rank") or 999, record.get("updated_at") or ""))


def get_decision_memory(tenant_id: str, decision_id: str, session: Optional[Session] = None) -> Optional[Dict[str, Any]]:
    if session is not None:
        record = session.query(WarRoomDecisionMemory).filter(
            WarRoomDecisionMemory.tenant_id == tenant_id,
            WarRoomDecisionMemory.decision_id == decision_id,
        ).first()
        return _enrich_record(_record_to_dict(record)) if record else None

    record = _decision_memory.get(tenant_id, {}).get(decision_id)
    return _enrich_record(record) if record else None


def build_decision_memory_summary(tenant_id: str, session: Optional[Session] = None) -> Dict[str, Any]:
    records = list_decision_memory(tenant_id, session=session)
    done = [record for record in records if record.get("status") == "done"]
    open_ = [record for record in records if record.get("status") == "todo"]
    skipped = [record for record in records if record.get("status") == "skipped"]
    archived = [record for record in records if record.get("status") == "archived"]
    stale = [record for record in open_ if record.get("is_stale")]
    duplicates = _duplicate_open_decisions(open_)
    total_actual = sum(float(record.get("actual_impact_eur") or 0) for record in done)
    best = max(done, key=lambda record: float(record.get("actual_impact_eur") or 0), default=None)
    below_target = [
        record for record in done
        if (record.get("outcome_review") or {}).get("status") in {"below_target", "negative"}
    ]
    return {
        "total_decisions": len(records),
        "open_decisions": len(open_),
        "completed_decisions": len(done),
        "skipped_decisions": len(skipped),
        "archived_decisions": len(archived),
        "actual_impact_eur": total_actual,
        "best_decision": best,
        "below_target_count": len(below_target),
        "stale_open_decisions": len(stale),
        "duplicate_open_groups": len(duplicates),
        "memory_quality": _memory_quality(len(records), len(stale), len(duplicates)),
        "memory_quality_notes": _memory_quality_notes(stale, duplicates),
        "next_review": _next_review(open_, below_target, best),
    }


def clear_decision_memory(tenant_id: Optional[str] = None, session: Optional[Session] = None) -> None:
    if tenant_id is None:
        _decision_memory.clear()
        if session is not None:
            session.query(WarRoomDecisionMemory).delete()
            session.commit()
    else:
        _decision_memory.pop(tenant_id, None)
        if session is not None:
            session.query(WarRoomDecisionMemory).filter(WarRoomDecisionMemory.tenant_id == tenant_id).delete()
            session.commit()


def _next_review(open_: List[Dict[str, Any]], below_target: List[Dict[str, Any]], best: Optional[Dict[str, Any]]) -> str:
    if below_target:
        return f"Rivedi {below_target[0]['decision_id']}: risultato sotto target o negativo."
    if open_:
        return f"Completa o chiudi {open_[0]['decision_id']}: e' ancora aperta."
    if best:
        return f"Replica cio' che ha funzionato: {best['decision_id']}."
    return "Genera una War Room e salva le prime decisioni."


def _enrich_record(record: Dict[str, Any]) -> Dict[str, Any]:
    enriched = deepcopy(record)
    created_at = _parse_dt(enriched.get("created_at"))
    age_days = (datetime.utcnow() - created_at).days if created_at else 0
    enriched["age_days"] = age_days
    enriched["is_stale"] = enriched.get("status") == "todo" and age_days > 14
    return enriched


def _duplicate_open_decisions(open_decisions: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    groups: Dict[str, List[str]] = {}
    for record in open_decisions:
        key = f"{record.get('sector') or 'general'}::{record.get('decision_type') or 'unknown'}"
        groups.setdefault(key, []).append(record["decision_id"])
    return {key: ids for key, ids in groups.items() if len(ids) > 1}


def _find_open_duplicate(
    records: List[Dict[str, Any]],
    decision_id: str,
    sector: Optional[str],
    decision_type: Optional[str],
) -> Optional[Dict[str, Any]]:
    for record in records:
        if record.get("decision_id") == decision_id:
            continue
        if record.get("status") != "todo":
            continue
        if (record.get("sector") or "general") != (sector or "general"):
            continue
        if (record.get("decision_type") or "unknown") != (decision_type or "unknown"):
            continue
        return record
    return None


def _memory_quality(total: int, stale_count: int, duplicate_groups: int) -> str:
    if total == 0:
        return "empty"
    if stale_count or duplicate_groups:
        return "needs_cleanup"
    return "clean"


def _memory_quality_notes(stale: List[Dict[str, Any]], duplicates: Dict[str, List[str]]) -> List[str]:
    notes: List[str] = []
    if stale:
        notes.append(f"{len(stale)} decisione/i aperte da oltre 14 giorni: chiudere, aggiornare o archiviare.")
    if duplicates:
        notes.append(f"{len(duplicates)} gruppi duplicati: evitare di aprire piu' decisioni uguali sullo stesso vincolo.")
    if not notes:
        notes.append("Memoria decisionale pulita: nessun duplicato o stale critico.")
    return notes


def _upsert_record(session: Session, tenant_id: str, record: Dict[str, Any]) -> WarRoomDecisionMemory:
    db_record = session.query(WarRoomDecisionMemory).filter(
        WarRoomDecisionMemory.tenant_id == tenant_id,
        WarRoomDecisionMemory.decision_id == record["decision_id"],
    ).first()
    if db_record is None:
        db_record = WarRoomDecisionMemory(
            tenant_id=tenant_id,
            decision_id=record["decision_id"],
            created_at=_parse_dt(record.get("created_at")) or datetime.utcnow(),
        )
        session.add(db_record)

    db_record.source = record.get("source") or "war_room"
    db_record.sector = record.get("sector")
    db_record.decision_type = record.get("decision_type")
    db_record.rank = record.get("rank")
    db_record.owner = record.get("owner")
    db_record.status = record.get("status") or "todo"
    db_record.decision = record.get("decision")
    db_record.next_action = record.get("next_action")
    db_record.success_metric_json = _json_dump(record.get("success_metric"))
    db_record.evidence_needed_json = _json_dump(record.get("evidence_needed"))
    db_record.follow_up_question = record.get("follow_up_question")
    db_record.expected_impact_eur = record.get("expected_impact_eur")
    db_record.actual_impact_eur = record.get("actual_impact_eur")
    db_record.outcome_review_json = _json_dump(record.get("outcome_review"))
    db_record.updated_at = datetime.utcnow()
    return db_record


def _record_to_dict(record: WarRoomDecisionMemory) -> Dict[str, Any]:
    return {
        "decision_id": record.decision_id,
        "source": record.source,
        "sector": record.sector,
        "decision_type": record.decision_type,
        "rank": record.rank,
        "owner": record.owner,
        "status": record.status,
        "decision": record.decision,
        "next_action": record.next_action,
        "success_metric": _json_load(record.success_metric_json),
        "evidence_needed": _json_load(record.evidence_needed_json),
        "follow_up_question": record.follow_up_question,
        "expected_impact_eur": record.expected_impact_eur,
        "actual_impact_eur": record.actual_impact_eur,
        "outcome_review": _json_load(record.outcome_review_json),
        "created_at": record.created_at.isoformat() if record.created_at else None,
        "updated_at": record.updated_at.isoformat() if record.updated_at else None,
    }


def _json_dump(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=True)


def _json_load(value: Optional[str]) -> Any:
    if not value:
        return None
    try:
        return json.loads(value)
    except Exception:
        return None


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return None
