"""
TREND ANALYSIS MODULE

Analyzes financial metrics over time to identify:
- Month-over-month changes (improving / worsening)
- Trends and directions
- Trend alerts and warnings
- Momentum indicators

Used by the Decision Engine to add context: "Your margin dropped 15% MoM - investigate demand"
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timedelta


class TrendDirection(Enum):
    """Direction of trend"""
    IMPROVING = "improving"      # Getting better
    STABLE = "stable"            # No significant change
    WORSENING = "worsening"      # Getting worse


class TrendIntensity(Enum):
    """Intensity of change"""
    MILD = 0.05          # <5% change
    MODERATE = 0.10      # 5-10% change  
    SIGNIFICANT = 0.20   # 10-20% change
    SEVERE = 1.0         # >20% change


@dataclass
class MetricTrend:
    """Trend for a single metric"""
    metric_name: str                    # "gross_margin_pct", "fatturato", etc.
    current_value: float
    previous_value: float
    change_pct: float                   # % change from previous
    direction: TrendDirection
    intensity: TrendIntensity
    months_back: int = 1                # How many months back was previous value
    
    @property
    def display_change(self) -> str:
        """Format change for display"""
        sign = "↑" if self.direction == TrendDirection.IMPROVING else "↓" if self.direction == TrendDirection.WORSENING else "→"
        return f"{sign} {abs(self.change_pct):.1f}%"
    
    @property
    def is_alert(self) -> bool:
        """Should this trigger an alert?"""
        # Alert if worsening AND significant/severe change
        if self.direction == TrendDirection.WORSENING:
            return self.intensity.value >= TrendIntensity.SIGNIFICANT.value
        return False


@dataclass
class CompanyTrends:
    """Complete trend analysis for a company"""
    company_name: str
    analysis_date: datetime
    
    # Individual metric trends
    revenue_trend: Optional[MetricTrend] = None
    gross_margin_trend: Optional[MetricTrend] = None
    ebitda_margin_trend: Optional[MetricTrend] = None
    net_margin_trend: Optional[MetricTrend] = None
    roi_trend: Optional[MetricTrend] = None
    gross_profit_trend: Optional[MetricTrend] = None
    ebitda_trend: Optional[MetricTrend] = None
    net_profit_trend: Optional[MetricTrend] = None
    
    # Alerts and summaries
    alerts: List[str] = None
    momentum_score: float = 0.0  # -100 to +100 (negative = declining, positive = improving)
    
    def __post_init__(self):
        if self.alerts is None:
            self.alerts = []
    
    @property
    def has_alerts(self) -> bool:
        """Any metrics triggering alerts?"""
        return len(self.alerts) > 0
    
    def get_trend_summary(self) -> str:
        """Generate a summary of trends"""
        lines = []
        
        if self.revenue_trend:
            lines.append(f"📈 Revenue: {self.revenue_trend.display_change}")
        
        if self.gross_margin_trend:
            lines.append(f"📊 Gross Margin: {self.gross_margin_trend.display_change}")
        
        if self.ebitda_margin_trend:
            lines.append(f"📊 EBITDA Margin: {self.ebitda_margin_trend.display_change}")
        
        if self.net_margin_trend:
            lines.append(f"📊 Net Margin: {self.net_margin_trend.display_change}")
        
        if self.roi_trend:
            lines.append(f"📊 ROI: {self.roi_trend.display_change}")
        
        if self.has_alerts:
            lines.append(f"\n⚠️  ALERTS ({len(self.alerts)}):")
            for alert in self.alerts:
                lines.append(f"  - {alert}")
        
        lines.append(f"\n📈 Momentum Score: {self.momentum_score:+.0f} {'(Improving)' if self.momentum_score > 0 else '(Declining)' if self.momentum_score < 0 else '(Stable)'}")
        
        return "\n".join(lines)


class TrendAnalyzer:
    """Analyzes financial trends from historical metrics"""
    
    @staticmethod
    def calculate_trend(current: float, previous: float) -> Tuple[TrendDirection, TrendIntensity, float]:
        """
        Calculate trend from two values
        
        Returns: (direction, intensity, change_pct)
        """
        if previous == 0:
            # Can't calculate % change if previous was 0
            if current > 0:
                return TrendDirection.IMPROVING, TrendIntensity.SEVERE, 100.0
            elif current < 0:
                return TrendDirection.WORSENING, TrendIntensity.SEVERE, -100.0
            else:
                return TrendDirection.STABLE, TrendIntensity.MILD, 0.0
        
        change_pct = ((current - previous) / abs(previous)) * 100
        
        # Determine intensity
        abs_change = abs(change_pct)
        if abs_change < 5:
            intensity = TrendIntensity.MILD
        elif abs_change < 10:
            intensity = TrendIntensity.MODERATE
        elif abs_change < 20:
            intensity = TrendIntensity.SIGNIFICANT
        else:
            intensity = TrendIntensity.SEVERE
        
        # Determine direction (positive = improving for margins, metrics)
        if change_pct > 1:  # >1% is "improving" for margins/profitability
            direction = TrendDirection.IMPROVING
        elif change_pct < -1:
            direction = TrendDirection.WORSENING
        else:
            direction = TrendDirection.STABLE
        
        return direction, intensity, change_pct
    
    @staticmethod
    def analyze_metrics(
        current_metrics: Dict[str, float],
        previous_metrics: Dict[str, float],
        company_name: str = "Company",
        analysis_date: Optional[datetime] = None
    ) -> CompanyTrends:
        """
        Analyze trends from two snapshots of metrics
        
        current_metrics = {
            "fatturato": 5_000_000,
            "gross_margin_pct": 35.2,
            "ebitda_margin_pct": 18.5,
            ...
        }
        
        previous_metrics = {
            "fatturato": 4_800_000,
            "gross_margin_pct": 36.1,
            "ebitda_margin_pct": 19.2,
            ...
        }
        """
        
        if analysis_date is None:
            analysis_date = datetime.now()
        
        trends = CompanyTrends(company_name=company_name, analysis_date=analysis_date, alerts=[])
        
        # Helper to calculate individual trends
        def calc_metric_trend(name: str, attr: str) -> Optional[MetricTrend]:
            if name not in current_metrics or name not in previous_metrics:
                return None
            
            curr = current_metrics[name]
            prev = previous_metrics[name]
            
            direction, intensity, change_pct = TrendAnalyzer.calculate_trend(curr, prev)
            
            return MetricTrend(
                metric_name=attr,
                current_value=curr,
                previous_value=prev,
                change_pct=change_pct,
                direction=direction,
                intensity=intensity,
                months_back=1
            )
        
        # Calculate trends for each metric
        trends.revenue_trend = calc_metric_trend("fatturato", "Revenue")
        trends.gross_margin_trend = calc_metric_trend("gross_margin_pct", "Gross Margin %")
        trends.ebitda_margin_trend = calc_metric_trend("ebitda_margin_pct", "EBITDA Margin %")
        trends.net_margin_trend = calc_metric_trend("net_margin_pct", "Net Margin %")
        trends.roi_trend = calc_metric_trend("roi_pct", "ROI %")
        trends.gross_profit_trend = calc_metric_trend("gross_profit", "Gross Profit")
        trends.ebitda_trend = calc_metric_trend("ebitda", "EBITDA")
        trends.net_profit_trend = calc_metric_trend("net_profit", "Net Profit")
        
        # Generate alerts for worsening metrics
        if trends.revenue_trend and trends.revenue_trend.is_alert:
            trends.alerts.append(
                f"Revenue dropped {abs(trends.revenue_trend.change_pct):.1f}% MoM - investigate demand or pricing"
            )
        
        if trends.gross_margin_trend and trends.gross_margin_trend.is_alert:
            trends.alerts.append(
                f"Gross margin fell {abs(trends.gross_margin_trend.change_pct):.1f}% MoM - rising COGS or pricing pressure"
            )
        
        if trends.ebitda_margin_trend and trends.ebitda_margin_trend.is_alert:
            trends.alerts.append(
                f"EBITDA margin down {abs(trends.ebitda_margin_trend.change_pct):.1f}% MoM - cost control issue"
            )
        
        if trends.net_profit_trend and trends.net_profit_trend.is_alert:
            trends.alerts.append(
                f"Net profit fell {abs(trends.net_profit_trend.change_pct):.1f}% MoM - escalating problems"
            )
        
        # Calculate momentum score (-100 to +100)
        # Positive = improving, Negative = declining
        momentum_components = []
        
        if trends.revenue_trend:
            momentum_components.append(trends.revenue_trend.change_pct / 5)  # Revenue weight
        
        if trends.ebitda_margin_trend:
            momentum_components.append(trends.ebitda_margin_trend.change_pct)  # High weight for profitability
        
        if trends.roi_trend and trends.roi_trend.current_value > 0:
            momentum_components.append(trends.roi_trend.change_pct)
        
        if momentum_components:
            trends.momentum_score = sum(momentum_components) / len(momentum_components)
            # Cap at -100 to +100
            trends.momentum_score = max(-100, min(100, trends.momentum_score))
        
        return trends


def format_trend_output(trends: CompanyTrends, include_detailed: bool = False) -> str:
    """
    Format trend analysis for user output
    
    Output:
    📊 Trends (vs last month):
    • Revenue: ↑ 5.2%
    • Gross Margin: ↓ 2.1%  ⚠️ Investigate COGS
    • EBITDA Margin: ↓ 3.5%
    • Net Margin: ↓ 4.2%
    
    Momentum: ↓ -15 (Declining)
    """
    
    lines = []
    lines.append("📊 Trends (vs last month):")
    
    if trends.revenue_trend:
        sign = "↑" if trends.revenue_trend.direction == TrendDirection.IMPROVING else "↓"
        lines.append(f"  • Revenue: {sign} {abs(trends.revenue_trend.change_pct):.1f}%")
    
    if trends.gross_margin_trend:
        sign = "↑" if trends.gross_margin_trend.direction == TrendDirection.IMPROVING else "↓"
        alert = " ⚠️" if trends.gross_margin_trend.is_alert else ""
        lines.append(f"  • Gross Margin: {sign} {abs(trends.gross_margin_trend.change_pct):.1f}%{alert}")
    
    if trends.ebitda_margin_trend:
        sign = "↑" if trends.ebitda_margin_trend.direction == TrendDirection.IMPROVING else "↓"
        alert = " ⚠️" if trends.ebitda_margin_trend.is_alert else ""
        lines.append(f"  • EBITDA Margin: {sign} {abs(trends.ebitda_margin_trend.change_pct):.1f}%{alert}")
    
    if trends.net_margin_trend:
        sign = "↑" if trends.net_margin_trend.direction == TrendDirection.IMPROVING else "↓"
        alert = " ⚠️" if trends.net_margin_trend.is_alert else ""
        lines.append(f"  • Net Margin: {sign} {abs(trends.net_margin_trend.change_pct):.1f}%{alert}")
    
    if trends.roi_trend and trends.roi_trend.current_value is not None:
        sign = "↑" if trends.roi_trend.direction == TrendDirection.IMPROVING else "↓"
        lines.append(f"  • ROI: {sign} {abs(trends.roi_trend.change_pct):.1f}%")
    
    # Alerts
    if trends.has_alerts:
        lines.append("")
        lines.append("⚠️  Alerts:")
        for alert in trends.alerts:
            lines.append(f"  • {alert}")
    
    # Momentum
    lines.append("")
    momentum_emoji = "📈" if trends.momentum_score > 10 else "📉" if trends.momentum_score < -10 else "→"
    momentum_text = "Improving" if trends.momentum_score > 10 else "Declining" if trends.momentum_score < -10 else "Stable"
    lines.append(f"{momentum_emoji} Momentum: {trends.momentum_score:+.0f} ({momentum_text})")
    
    return "\n".join(lines)
