# -*- coding: utf-8 -*-
# content/core/scenario.py — Simulazioni prezzo/quantità/costi + Matrix (compatibile col tuo I/O)
from __future__ import annotations

from itertools import product
from typing import Any, Dict, Iterable, List, Tuple

from core.metrics import compute_kpis


# ============================================================
# Utility
# ============================================================
def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return float(default)
        return v
    except Exception:
        return float(default)


def _as_frac(x: Any) -> float:
    """
    Normalizza percentuali:
      - 10    -> 0.10
      - -5    -> -0.05
      - 0.10  -> 0.10
      - -0.05 -> -0.05
    """
    xf = _safe_float(x, 0.0)
    if 1.0 < abs(xf) <= 100.0:
        return xf / 100.0
    return xf


def _clamp_nonneg(x: Any) -> float:
    return max(0.0, _safe_float(x, 0.0))


def _clamp(x: Any, lo: float, hi: float) -> float:
    v = _safe_float(x, lo)
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


def _derive_qty(fatturato: float, prezzo_medio: float) -> float:
    """Qty ≈ Ricavi / Prezzo medio."""
    pm = _safe_float(prezzo_medio, 0.0)
    fatt = _safe_float(fatturato, 0.0)
    return fatt / pm if pm > 0.0 else 0.0


def _derive_cvu(costi_variabili: float, qty: float) -> float:
    """CVU ≈ Costi variabili / Qty."""
    cv = _safe_float(costi_variabili, 0.0)
    q = _safe_float(qty, 0.0)
    return cv / q if q > 0.0 else 0.0


def _get(base: Dict[str, Any], key: str, default: float = 0.0) -> float:
    return _safe_float((base or {}).get(key, default), default)


def _has_any(d: Dict[str, Any], keys: Iterable[str]) -> bool:
    for k in keys:
        if k in d and d[k] is not None:
            return True
    return False


def _resolve_price_delta(delta: Dict[str, Any]) -> Tuple[float, float]:
    """
    Restituisce:
      - price_pct come frazione
      - price_abs come delta assoluto
    """
    pct = delta.get("prezzo_pct", delta.get("price_pct", 0.0))
    absv = delta.get("prezzo_abs", delta.get("price_abs", 0.0))
    return _as_frac(pct), _safe_float(absv, 0.0)


def _resolve_elasticity(base: Dict[str, Any], delta: Dict[str, Any]) -> float:
    return _safe_float(
        delta.get(
            "elasticita_prezzo",
            delta.get("price_elasticity", base.get("price_elasticity", -1.2)),
        ),
        -1.2,
    )


def _normalize_target_to_abs(base_val: float, target: Any) -> float:
    """
    Converte un target in delta assoluta.
    Esempio:
      base 100, target 130 -> +30
    """
    return _safe_float(target, base_val) - _safe_float(base_val, 0.0)


# ============================================================
# Core apply helpers
# ============================================================
def _apply_scalar_delta(
    base_val: float,
    *,
    pct: float = 0.0,
    absv: float = 0.0,
    target: Any = None,
    non_negative: bool = True,
) -> float:
    """
    Applica:
      1. target, se presente
      2. altrimenti pct + abs
    """
    if target is not None:
        out = _safe_float(target, base_val)
    else:
        out = _safe_float(base_val, 0.0) * (1.0 + _as_frac(pct)) + _safe_float(absv, 0.0)

    return _clamp_nonneg(out) if non_negative else _safe_float(out, 0.0)


def _apply_price_qty_logic(base: Dict[str, Any], delta: Dict[str, Any]) -> Dict[str, float]:
    """
    Calcola l'effetto congiunto di prezzo e quantità.
    Restituisce:
      {
        "prezzo_medio": ...,
        "qty": ...,
        "fatturato": ...,
        "costi_variabili": ...,
        "cvu": ...,
      }
    """
    f0 = _get(base, "fatturato", 0.0)
    cv0 = _get(base, "costi_variabili", _get(base, "cogs", 0.0))
    pm0 = _get(base, "prezzo_medio", 0.0)

    # quantità baseline
    q0 = _derive_qty(f0, pm0) if pm0 > 0.0 else _get(base, "qty", 0.0)
    q0 = _clamp_nonneg(q0)

    # cvu baseline
    cvu0 = _get(base, "costo_variabile_unitario", 0.0)
    if cvu0 <= 0.0 and q0 > 0.0:
        cvu0 = _derive_cvu(cv0, q0)

    price_pct_frac, price_abs = _resolve_price_delta(delta)
    qty_pct_frac = None if delta.get("qty_pct") is None else _as_frac(delta.get("qty_pct"))
    elasticity = _resolve_elasticity(base, delta)

    # prezzo risultante
    if delta.get("prezzo_target") is not None or delta.get("price_target") is not None:
        pm1 = _safe_float(delta.get("prezzo_target", delta.get("price_target", pm0)), pm0)
        pm1 = _clamp_nonneg(pm1)
    else:
        pm1 = _clamp_nonneg(pm0 * (1.0 + price_pct_frac) + price_abs) if (pm0 > 0.0 or price_abs != 0.0 or price_pct_frac != 0.0) else pm0

    # quantità risultante
    if delta.get("qty_target") is not None:
        q1 = _clamp_nonneg(delta.get("qty_target"))
    else:
        if qty_pct_frac is not None:
            q1 = _clamp_nonneg(q0 * (1.0 + qty_pct_frac))
        else:
            # effetto elasticità solo se c'è stata una manovra prezzo
            if q0 > 0.0:
                dq = elasticity * price_pct_frac
                q1 = _clamp_nonneg(q0 * (1.0 + dq))
            else:
                q1 = 0.0

    # clamp prudente quantità
    if q0 > 0.0:
        q1 = min(q1, q0 * 5.0)

    # fatturato da prezzo/qty
    if delta.get("fatturato_target") is not None:
        fatt1 = _clamp_nonneg(delta.get("fatturato_target"))
    elif pm1 > 0.0 and q1 > 0.0:
        fatt1 = _clamp_nonneg(pm1 * q1)
    else:
        # fallback se qty non derivabile
        if f0 > 0.0:
            inferred_qty_shift = elasticity * price_pct_frac if qty_pct_frac is None else qty_pct_frac
            fatt1 = _clamp_nonneg(f0 * (1.0 + price_pct_frac) * (1.0 + inferred_qty_shift))
        else:
            fatt1 = 0.0

    # costi variabili
    lock_cvu = bool(delta.get("lock_cvu", True))

    if delta.get("costi_variabili_target") is not None:
        cv1 = _clamp_nonneg(delta.get("costi_variabili_target"))
    elif lock_cvu and cvu0 > 0.0 and q1 > 0.0:
        cv1 = _clamp_nonneg(cvu0 * q1)
    else:
        ratio = (fatt1 / f0) if f0 > 0.0 else 1.0
        cv1 = _clamp_nonneg(cv0 * ratio)

    return {
        "prezzo_medio": pm1,
        "qty": q1,
        "fatturato": fatt1,
        "costi_variabili": cv1,
        "cvu": cvu0,
    }


# ============================================================
# Simulazione singola
# ============================================================
def simulate(base: Dict[str, Any], delta: Dict[str, Any], *, sector: str | None = None) -> Dict[str, Any]:
    """
    Applica variazioni su base e ricalcola i KPI.

    Supporto leve:
      - fatturato_pct | fatturato_abs | fatturato_target
      - costi_variabili_pct | costi_variabili_abs | costi_variabili_target
      - costi_fissi_pct | costi_fissi_abs | costi_fissi_delta | costi_fissi_target
      - investimenti_abs | investimenti_pct | investimenti_target
      - prezzo_pct | price_pct | prezzo_abs | price_abs | prezzo_target | price_target
      - qty_pct | qty_target
      - elasticita_prezzo | price_elasticity
      - lock_cvu
    """
    base = dict(base or {})
    delta = dict(delta or {})

    # alias cogs -> costi_variabili se serve
    if "costi_variabili" not in base and "cogs" in base:
        base["costi_variabili"] = _safe_float(base.get("cogs"), 0.0)

    # ---------------- Baseline
    f0 = _get(base, "fatturato", 0.0)
    cv0 = _get(base, "costi_variabili", 0.0)
    cf0 = _get(base, "costi_fissi", 0.0)
    inv0 = _get(base, "investimenti", 0.0)

    amm0 = _get(base, "ammortamenti", 0.0)
    dso0 = _get(base, "dso", 0.0)
    dio0 = _get(base, "dio", 0.0)
    dpo0 = _get(base, "dpo", 0.0)
    cogs0 = _get(base, "cogs", cv0)
    pm0 = _get(base, "prezzo_medio", 0.0)
    cvu0 = _get(base, "costo_variabile_unitario", 0.0)

    # ---------------- Effetti prezzo / quantità
    has_price_or_qty = _has_any(
        delta,
        [
            "prezzo_pct",
            "price_pct",
            "prezzo_abs",
            "price_abs",
            "prezzo_target",
            "price_target",
            "qty_pct",
            "qty_target",
            "elasticita_prezzo",
            "price_elasticity",
        ],
    )

    if has_price_or_qty:
        pq = _apply_price_qty_logic(base, delta)
        fatt_base = pq["fatturato"]
        cv_base = pq["costi_variabili"]
        pm1 = pq["prezzo_medio"]
        qty1 = pq["qty"]
        cvu1 = pq["cvu"]
    else:
        fatt_base = f0
        cv_base = cv0
        pm1 = pm0
        qty1 = _derive_qty(f0, pm0) if pm0 > 0.0 else _get(base, "qty", 0.0)
        cvu1 = cvu0 if cvu0 > 0.0 else (_derive_cvu(cv0, qty1) if qty1 > 0.0 else 0.0)

    # ---------------- Ricavi/CV ulteriormente rifiniti da pct/abs/target
    # Se price/qty ha già impostato fatturato/cv, i delta sotto rifiniscono sopra quel baseline.
    fatt1 = _apply_scalar_delta(
        fatt_base,
        pct=delta.get("fatturato_pct", 0.0),
        absv=delta.get("fatturato_abs", 0.0),
        target=delta.get("fatturato_target", None),
        non_negative=True,
    )

    cv1 = _apply_scalar_delta(
        cv_base,
        pct=delta.get("costi_variabili_pct", 0.0),
        absv=delta.get("costi_variabili_abs", 0.0),
        target=delta.get("costi_variabili_target", None),
        non_negative=True,
    )

    cf1 = _apply_scalar_delta(
        cf0,
        pct=delta.get("costi_fissi_pct", 0.0),
        absv=_safe_float(delta.get("costi_fissi_abs", 0.0), 0.0) + _safe_float(delta.get("costi_fissi_delta", 0.0), 0.0),
        target=delta.get("costi_fissi_target", None),
        non_negative=True,
    )

    inv1 = _apply_scalar_delta(
        inv0,
        pct=delta.get("investimenti_pct", 0.0),
        absv=delta.get("investimenti_abs", 0.0),
        target=delta.get("investimenti_target", None),
        non_negative=True,
    )

    # ---------------- working capital / altri
    dso1 = _apply_scalar_delta(
        dso0,
        pct=0.0,
        absv=delta.get("dso_abs", 0.0),
        target=delta.get("dso_target", None),
        non_negative=True,
    )
    if delta.get("dso_pct") is not None:
        dso1 = _clamp_nonneg(dso0 * (1.0 + _as_frac(delta.get("dso_pct"))))

    dio1 = _apply_scalar_delta(
        dio0,
        pct=0.0,
        absv=delta.get("dio_abs", 0.0),
        target=delta.get("dio_target", None),
        non_negative=True,
    )
    if delta.get("dio_pct") is not None:
        dio1 = _clamp_nonneg(dio0 * (1.0 + _as_frac(delta.get("dio_pct"))))

    dpo1 = _apply_scalar_delta(
        dpo0,
        pct=0.0,
        absv=delta.get("dpo_abs", 0.0),
        target=delta.get("dpo_target", None),
        non_negative=True,
    )
    if delta.get("dpo_pct") is not None:
        dpo1 = _clamp_nonneg(dpo0 * (1.0 + _as_frac(delta.get("dpo_pct"))))

    amm1 = _apply_scalar_delta(
        amm0,
        pct=delta.get("ammortamenti_pct", 0.0),
        absv=delta.get("ammortamenti_abs", 0.0),
        target=delta.get("ammortamenti_target", None),
        non_negative=True,
    )

    # aggiorna qty se possibile coerentemente con fatturato finale
    if pm1 > 0.0:
        qty1 = _derive_qty(fatt1, pm1)
        qty1 = _clamp_nonneg(qty1)

    # cogs coerente con costi variabili
    cogs1 = cv1 if cv1 > 0.0 else cogs0

    # settore
    sector_eff = sector or str(base.get("sector", "default"))

    # payload finale verso KPI engine
    overrides: Dict[str, Any] = {
        "fatturato": fatt1,
        "sales": fatt1,
        "costi_variabili": cv1,
        "cogs": cogs1,
        "costi_fissi": cf1,
        "investimenti": inv1,
        "ammortamenti": amm1,
        "prezzo_medio": pm1,
        "costo_variabile_unitario": cvu1,
        "dso": dso1,
        "dio": dio1,
        "dpo": dpo1,
        "qty": qty1,
        "sector": sector_eff,
    }

    out = compute_kpis(**overrides).model_dump()

    # allega alcuni campi utili downstream
    out["qty"] = qty1
    out["prezzo_medio"] = pm1
    out["costo_variabile_unitario"] = cvu1
    out["sector"] = sector_eff

    return out


# ============================================================
# Apply sequence
# ============================================================
def simulate_apply(base: Dict[str, Any], deltas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Applica una sequenza di delta in cascata.
    Utile per piani multi-step.
    """
    out: List[Dict[str, Any]] = []
    cur = dict(base or {})
    sector_eff = str(cur.get("sector", "default"))

    for d in deltas or []:
        cur = simulate(cur, d, sector=sector_eff)
        out.append(cur)

    return out


# ============================================================
# Scenario Matrix
# ============================================================
def _grid_product(grid: Dict[str, List[Any]]) -> Iterable[Dict[str, Any]]:
    """
    Prodotto cartesiano della griglia.
    """
    if not grid:
        return []
    keys = list(grid.keys())
    vals = [list(grid[k]) for k in keys]
    return ({keys[i]: combo[i] for i in range(len(keys))} for combo in product(*vals))


def simulate_matrix(
    base: Dict[str, Any],
    grid: Dict[str, List[Any]],
    *,
    attach_params: bool = True,
    sort_by: str | None = "utile",
    descending: bool = True,
) -> List[Dict[str, Any]]:
    """
    Esegue una matrice di scenari variando le leve fornite in `grid`.

    Parametri:
    - attach_params: se True aggiunge `_scenario_params`
    - sort_by: metrica finale per ordinamento
    - descending: ordinamento decrescente

    Ritorna lista di KPI dict.
    """
    out: List[Dict[str, Any]] = []
    sector_eff = str((base or {}).get("sector", "default"))

    for params in _grid_product(grid or {}):
        row = simulate(base, params, sector=sector_eff)
        if attach_params:
            row["_scenario_params"] = dict(params)
        out.append(row)

    if sort_by:
        try:
            out.sort(key=lambda r: _safe_float(r.get(sort_by), 0.0), reverse=bool(descending))
        except Exception:
            pass

    return out