"""
Decision Processor - The Strategic Priority Engine

Ranks all possible actions by ROI, effort, risk.
Decides which leva to move first.
Now with industry-aware thresholds.
"""

from typing import List, Dict, Any, Optional
from enum import Enum
from dataclasses import dataclass
from core.analysis import AnalyzeResponse, KPISnapshot
from core.industry_adapter import get_industry_adapter

class ActionPriority(str, Enum):
    """Action priorities"""
    CRITICAL = "critical"      # High ROI, low effort, urgent
    HIGH = "high"              # High ROI, medium effort
    MEDIUM = "medium"          # Medium ROI or high effort
    LOW = "low"                # Low ROI or can wait


@dataclass
class PrioritizedAction:
    """A ranked action with full context"""
    rank: int
    priority: ActionPriority
    action: str
    description: str
    impact_eur: float
    effort_level: str  # low, medium, high
    effort_weeks: float
    risk_level: str  # low, medium, high
    risk_description: str
    why_now: str
    why_not: Optional[str] = None
    success_metrics: List[str] = None
    trap_to_avoid: Optional[str] = None

    @property
    def title(self) -> str:
        return self.action

    @property
    def verdict(self) -> str:
        if self.priority in {ActionPriority.CRITICAL, ActionPriority.HIGH}:
            return "GO"
        if self.priority == ActionPriority.MEDIUM:
            return "MAYBE"
        return "WAIT"

    @property
    def roi_score(self) -> float:
        effort_factor = {"low": 1.0, "medium": 0.7, "high": 0.45}.get(self.effort_level, 0.6)
        risk_factor = {"low": 1.0, "medium": 0.75, "high": 0.5}.get(self.risk_level, 0.7)
        return max(0.1, min(1.0, (self.impact_eur / 100_000) * effort_factor * risk_factor))

    @property
    def timeframe_days(self) -> int:
        return max(1, int((self.effort_weeks or 1) * 7))


class DecisionProcessor:
    """Rank and prioritize all actions (now industry-aware)"""
    
    def process(
        self,
        analysis: AnalyzeResponse,
        company_size: float,  # Annual revenue in EUR
        company_phase: str,   # "early", "growth", "mature", "decline"
        settore: str = "default",  # Industry code (saas, retail, etc.)
    ) -> List[PrioritizedAction]:
        """
        Analyze company and rank actions by priority.
        Uses industry-specific thresholds for evaluation.
        
        Returns ordered list of actions to take.
        """
        actions = []
        kpi = analysis.kpi_snapshot
        
        # Get industry-specific thresholds
        industry_adapter = get_industry_adapter(settore)
        thresholds = industry_adapter.profile
        
        # Convert percentages to decimals for comparison
        gross_margin_threshold = thresholds.healthy_gross_margin_pct * 0.75  # 75% of healthy
        net_margin_threshold = thresholds.healthy_net_margin_pct * 0.75
        
        # ===== CRITICAL ACTIONS (margin/cash related) =====
        
        # 1. Margin too low (industry-aware)?
        if kpi.gross_margin_pct is not None and kpi.gross_margin_pct < gross_margin_threshold:
            actions.append(self._create_margin_action(kpi, thresholds))
        
        # 2. Cash cycle crisis?
        if kpi.ccc_days is not None and kpi.ccc_days > 90:
            actions.append(self._create_cash_action(kpi, thresholds))
        
        # 3. Fixed costs too high (industry-aware)?
        if analysis.estimated_loss_eur and analysis.estimated_loss_eur > company_size * thresholds.max_fixed_cost_pct_revenue:
            actions.append(self._create_cost_action(analysis, thresholds))
        
        # ===== HIGH PRIORITY ACTIONS =====
        
        # 4. Growth without quality (net margin low)?
        if kpi.ebitda_margin_pct is not None and kpi.ebitda_margin_pct < net_margin_threshold:
            actions.append(self._create_quality_action(kpi, thresholds))
        
        # 5. Working capital inefficient?
        if kpi.ccc_days is not None and 45 < kpi.ccc_days < 90:
            actions.append(self._create_efficiency_action(kpi))
        
        # ===== MEDIUM PRIORITY ACTIONS =====
        
        # 6. ROI opportunity?
        if kpi.roi_pct is not None and kpi.roi_pct < 15:
            actions.append(self._create_roi_action(kpi))
        
        # ===== Sort by impact/effort ratio =====
        
        actions.sort(
            key=lambda x: (
                -self._score_action(x),  # Higher score first
                x.priority.value,        # Then by priority enum
            )
        )
        
        # Assign ranks
        for i, action in enumerate(actions, 1):
            action.rank = i
        
        return actions[:10]  # Top 10 actions
    
    def _score_action(self, action: PrioritizedAction) -> float:
        """Score action by ROI / effort"""
        effort_factor = {
            'low': 1.0,
            'medium': 2.0,
            'high': 3.0,
        }.get(action.effort_level, 2.0)
        
        priority_factor = {
            ActionPriority.CRITICAL: 4.0,
            ActionPriority.HIGH: 3.0,
            ActionPriority.MEDIUM: 2.0,
            ActionPriority.LOW: 1.0,
        }.get(action.priority, 2.0)
        
        return (action.impact_eur / effort_factor) * priority_factor
    
    def _create_margin_action(self, kpi: KPISnapshot, thresholds) -> PrioritizedAction:
        """Margin is too low - pricing or cost action (industry-aware)"""
        target_margin = thresholds.healthy_gross_margin_pct
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.CRITICAL,
            action="Increase Gross Margin",
            description=f"Raise pricing or reduce variable costs to reach {target_margin}%",
            impact_eur=kpi.gross_profit_eur * 0.05 if kpi.gross_profit_eur else 50_000,
            effort_level="medium",
            effort_weeks=2,
            risk_level="low",
            risk_description="Established product, minimal churn risk",
            why_now=f"Every week at current margin costs €3-5k in lost profit. Industry healthy: {target_margin}%",
            trap_to_avoid="Don't cut quality - increase value perception",
            success_metrics=[
                f"Margin increase toward {target_margin}% within 4 weeks",
                "Volume retention >95%",
                "NPS remains stable",
            ],
        )
    
    def _create_cash_action(self, kpi: KPISnapshot, thresholds) -> PrioritizedAction:
        """Cash cycle too long - working capital crisis (industry-aware)"""
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.CRITICAL,
            action="Optimize Cash Conversion Cycle",
            description="Reduce DSO, increase DPO, lower DIO",
            impact_eur=kpi.gross_profit_eur * 0.08 if kpi.gross_profit_eur else 80_000,
            effort_level="high",
            effort_weeks=6,
            risk_level="medium",
            risk_description="Requires supplier negotiation and customer policy changes",
            why_now=f"Current CCC: {kpi.ccc_days} days. Cash crunch can hit in 30-60 days if not addressed",
            trap_to_avoid="Don't sacrifice customer relationships for cash",
            success_metrics=[
                "CCC reduced by 20 days minimum",
                "DSO below 45 days",
                "DPO extended to 60+ days",
            ],
        )
    
    def _create_cost_action(self, analysis: AnalyzeResponse, thresholds) -> PrioritizedAction:
        """Fixed costs are a burden - need to trim (industry-aware)"""
        max_pct = thresholds.max_fixed_cost_pct_revenue * 100
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.HIGH,
            action="Reduce Fixed Cost Structure",
            description=f"Right-size your fixed cost base to <{max_pct:.0f}% of revenue",
            impact_eur=analysis.estimated_loss_eur or 100_000,
            effort_level="high",
            effort_weeks=4,
            risk_level="medium",
            risk_description="May require headcount decisions",
            why_now=f"Fixed costs are eating into profitability monthly. Industry max: {max_pct:.0f}%",
            trap_to_avoid="Don't cut capability too early - preserve ability to scale",
            success_metrics=[
                f"Fixed costs <{max_pct:.0f}% of revenue",
                "No loss of critical capability",
                "EBITDA margin improves to 15%+",
            ],
        )
    
    def _create_quality_action(self, kpi: KPISnapshot, thresholds) -> PrioritizedAction:
        """Scaling but profitability declining (industry-aware)"""
        target_ebitda = thresholds.healthy_ebitda_margin_pct
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.HIGH,
            action="Improve Quality of Growth",
            description=f"Ensure growth is profitable toward {target_ebitda}% EBITDA margin",
            impact_eur=kpi.gross_profit_eur * 0.1 if kpi.gross_profit_eur else 100_000,
            effort_level="medium",
            effort_weeks=3,
            risk_level="low",
            risk_description="Analysis-heavy, no operational risk",
            why_now=f"Current trajectory erodes margin with every new customer. Industry target: {target_ebitda}%",
            trap_to_avoid="Don't stop growth - change quality of growth",
            success_metrics=[
                f"EBITDA margin improves toward {target_ebitda}%",
                "Revenue still grows but more profitable",
                "Customer mix shifts to higher-margin segments",
            ],
        )
    
    def _create_efficiency_action(self, kpi: KPISnapshot) -> PrioritizedAction:
        """Working capital suboptimal but not critical"""
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.MEDIUM,
            action="Improve Working Capital Efficiency",
            description="Tighten CCC without sacrificing operations",
            impact_eur=50_000,
            effort_level="medium",
            effort_weeks=4,
            risk_level="low",
            risk_description="Operational improvements, low risk",
            why_now="This is low-hanging fruit improvement",
            trap_to_avoid="None - this is pure efficiency",
            success_metrics=[
                "CCC reduced by 15 days",
                "Working capital freed: €50k+",
            ],
        )
    
    def _create_roi_action(self, kpi: KPISnapshot) -> PrioritizedAction:
        """ROI below healthy threshold"""
        return PrioritizedAction(
            rank=0,
            priority=ActionPriority.MEDIUM,
            action="Improve Return on Invested Capital",
            description="Optimize asset utilization or reduce capital needs",
            impact_eur=50_000,
            effort_level="medium",
            effort_weeks=5,
            risk_level="low",
            risk_description="Incremental operational improvements",
            why_now="Low ROI means capital isn't generating expected returns",
            trap_to_avoid="Don't sacrifice growth for ROI - find both",
            success_metrics=[
                "ROI improves to 15%+",
                "Asset turnover increases",
            ],
        )


def get_decision_processor() -> DecisionProcessor:
    """Get singleton decision processor"""
    return DecisionProcessor()
