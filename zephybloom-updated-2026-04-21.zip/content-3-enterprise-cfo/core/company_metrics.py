"""
COMPANY METRICS STORAGE & RETRIEVAL

Helper functions to:
1. Save company metrics to database (historical tracking)
2. Retrieve historical metrics for trend calculation
3. Fetch and format trends for Decision Engine
"""

from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from db.models import CompanyMetricsHistory
from core.trend_analysis import TrendAnalyzer, format_trend_output


def save_company_metrics(
    session: Session,
    tenant_id: str,
    company_id: str,
    company_name: str,
    metrics: Dict[str, float],
    measurement_date: Optional[datetime] = None,
    industry: Optional[str] = None,
    company_size: Optional[str] = None,
    notes: Optional[str] = None,
) -> CompanyMetricsHistory:
    """
    Save company metrics to database for historical tracking.
    
    Args:
        session: Database session
        tenant_id: Tenant ID
        company_id: Company identifier (slug-based)
        company_name: Company name
        metrics: Dict with keys like "fatturato", "costi_variabili", etc.
        measurement_date: Date of measurement (defaults to today)
        industry: Industry/sector
        company_size: Small/Medium/Large
        notes: Optional notes
    
    Returns:
        CompanyMetricsHistory record
    
    Example:
        metrics = {
            "fatturato": 5_000_000,
            "costi_variabili": 3_250_000,
            "costi_fissi": 900_000,
            "investimenti": 500_000,
            "gross_profit": 1_750_000,
            "gross_margin_pct": 35.0,
            "ebitda": 850_000,
            "ebitda_margin_pct": 17.0,
            "net_profit": 850_000,
            "net_margin_pct": 17.0,
        }
        
        history = save_company_metrics(
            session,
            tenant_id="acme-corp",
            company_id="acme-us",
            company_name="Acme Corp",
            metrics=metrics,
            industry="manufacturing"
        )
    """
    
    if measurement_date is None:
        measurement_date = datetime.now()
    
    # Extract required fields
    fatturato = metrics.get("fatturato", 0)
    costi_variabili = metrics.get("costi_variabili", 0)
    costi_fissi = metrics.get("costi_fissi", 0)
    investimenti = metrics.get("investimenti")
    
    # Use provided or calculate from metrics
    gross_profit = metrics.get("gross_profit", fatturato - costi_variabili)
    gross_margin_pct = metrics.get("gross_margin_pct", (gross_profit / fatturato * 100) if fatturato > 0 else 0)
    ebitda = metrics.get("ebitda", gross_profit - costi_fissi)
    ebitda_margin_pct = metrics.get("ebitda_margin_pct", (ebitda / fatturato * 100) if fatturato > 0 else 0)
    net_profit = metrics.get("net_profit", ebitda)
    net_margin_pct = metrics.get("net_margin_pct", (net_profit / fatturato * 100) if fatturato > 0 else 0)
    
    roi_pct = None
    if investimenti and investimenti > 0:
        roi_pct = (net_profit / investimenti * 100)
    
    record = session.query(CompanyMetricsHistory).filter(
        CompanyMetricsHistory.tenant_id == tenant_id,
        CompanyMetricsHistory.company_id == company_id,
        CompanyMetricsHistory.period_month == measurement_date.month,
        CompanyMetricsHistory.period_year == measurement_date.year,
    ).first()

    if record is None:
        record = CompanyMetricsHistory(
            tenant_id=tenant_id,
            company_id=company_id,
            period_month=measurement_date.month,
            period_year=measurement_date.year,
            period_date=datetime(measurement_date.year, measurement_date.month, 1),
        )
        session.add(record)

    record.company_name = company_name
    record.fatturato = fatturato
    record.costi_variabili = costi_variabili
    record.costi_fissi = costi_fissi
    record.investimenti = investimenti or 0
    record.gross_profit = gross_profit
    record.gross_margin_pct = gross_margin_pct
    record.ebitda = ebitda
    record.ebitda_margin_pct = ebitda_margin_pct
    record.net_profit = net_profit
    record.net_margin_pct = net_margin_pct
    record.roi_pct = roi_pct
    record.industry = industry
    record.company_size = company_size
    record.notes = notes

    session.commit()
    
    return record


def get_company_metrics_history(
    session: Session,
    tenant_id: str,
    company_id: str,
    months: int = 12,
) -> List[CompanyMetricsHistory]:
    """
    Retrieve historical metrics for a company.
    
    Args:
        session: Database session
        tenant_id: Tenant ID
        company_id: Company identifier
        months: How many months of history to retrieve
    
    Returns:
        List of CompanyMetricsHistory records, ordered by date (oldest first)
    """
    
    cutoff_date = datetime.now() - timedelta(days=30 * months)
    
    records = session.query(CompanyMetricsHistory).filter(
        CompanyMetricsHistory.tenant_id == tenant_id,
        CompanyMetricsHistory.company_id == company_id,
        CompanyMetricsHistory.period_date >= cutoff_date,
    ).order_by(CompanyMetricsHistory.period_date.asc()).all()
    
    return records


def get_latest_company_metrics(
    session: Session,
    tenant_id: str,
    company_id: str,
) -> Optional[CompanyMetricsHistory]:
    """
    Get the most recent metrics for a company.
    
    Args:
        session: Database session
        tenant_id: Tenant ID
        company_id: Company identifier
    
    Returns:
        Most recent CompanyMetricsHistory record or None
    """
    
    record = session.query(CompanyMetricsHistory).filter(
        CompanyMetricsHistory.tenant_id == tenant_id,
        CompanyMetricsHistory.company_id == company_id,
    ).order_by(CompanyMetricsHistory.period_date.desc()).first()
    
    return record


def get_trend_summary_for_decision(
    session: Session,
    tenant_id: str,
    company_id: str,
) -> str:
    """
    Calculate and format trend summary for Decision Engine.
    
    This retrieves the last 2 months of data (current vs previous),
    calculates trends, and returns formatted summary text.
    
    Args:
        session: Database session
        tenant_id: Tenant ID
        company_id: Company identifier
    
    Returns:
        Formatted trend summary text (empty string if insufficient data)
    
    Example output:
        📊 Trends (vs last month):
          • Revenue: ↑ 5.2%
          • Gross Margin: ↓ 2.1%  ⚠️ ALERT
          • EBITDA Margin: ↑ 3.5%
          ...
        
        📈 Momentum: +12 (Improving)
    """
    
    # Get last 2 months of data
    records = get_company_metrics_history(session, tenant_id, company_id, months=2)
    
    if len(records) < 2:
        # Insufficient data for trend calculation
        return ""
    
    # Most recent is last, previous is second-to-last
    current = records[-1]
    previous = records[-2]
    
    # Convert to metric dicts for trend analyzer
    current_metrics = {
        "fatturato": current.fatturato,
        "costi_variabili": current.costi_variabili,
        "costi_fissi": current.costi_fissi,
        "investimenti": current.investimenti,
        "gross_profit": current.gross_profit,
        "gross_margin_pct": current.gross_margin_pct,
        "ebitda": current.ebitda,
        "ebitda_margin_pct": current.ebitda_margin_pct,
        "net_profit": current.net_profit,
        "net_margin_pct": current.net_margin_pct,
        "roi_pct": current.roi_pct or 0,
    }
    
    previous_metrics = {
        "fatturato": previous.fatturato,
        "costi_variabili": previous.costi_variabili,
        "costi_fissi": previous.costi_fissi,
        "investimenti": previous.investimenti,
        "gross_profit": previous.gross_profit,
        "gross_margin_pct": previous.gross_margin_pct,
        "ebitda": previous.ebitda,
        "ebitda_margin_pct": previous.ebitda_margin_pct,
        "net_profit": previous.net_profit,
        "net_margin_pct": previous.net_margin_pct,
        "roi_pct": previous.roi_pct or 0,
    }
    
    # Analyze trends
    analyzer = TrendAnalyzer()
    trends = analyzer.analyze_metrics(current_metrics, previous_metrics, current.company_name)
    
    # Format and return
    return format_trend_output(trends)


def metrics_to_dict(record: CompanyMetricsHistory) -> Dict[str, float]:
    """
    Convert CompanyMetricsHistory record to metrics dict for Decision Engine.
    
    Args:
        record: CompanyMetricsHistory database record
    
    Returns:
        Dict with all metrics
    """
    
    return {
        "fatturato": record.fatturato,
        "costi_variabili": record.costi_variabili,
        "costi_fissi": record.costi_fissi,
        "investimenti": record.investimenti or 0,
        "gross_profit": record.gross_profit,
        "gross_margin_pct": record.gross_margin_pct,
        "ebitda": record.ebitda,
        "ebitda_margin_pct": record.ebitda_margin_pct,
        "net_profit": record.net_profit,
        "net_margin_pct": record.net_margin_pct,
        "roi_pct": record.roi_pct or 0,
    }
