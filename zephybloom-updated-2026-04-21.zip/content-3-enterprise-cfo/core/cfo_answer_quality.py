"""Answer quality scoring for CFO chat responses.

The goal is not to judge writing style. It tells the product whether an answer
is grounded in KPIs, Data Room, vertical data, memory or just a safe fallback.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional


HIGH_TRUST_INTENTS = {
    "faq",
    "kpi_profit",
    "kpi_roi",
    "kpi_ebitda",
    "company_data_room",
    "company_data_room_history",
    "weekly_execution_plan",
    "decision_memory_summary",
    "cfo_memory_summary",
}


def build_answer_quality(
    question: str,
    response: str,
    intent: str,
    data_quality_pct: float,
    readiness_level: str,
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    data_room: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a compact quality envelope for a CFO answer."""

    sources = _sources(intent, company_data, operational_data_by_sector, data_room)
    missing = _missing_fields(data_room)
    unsupported = _unsupported_claims(response, sources, operational_data_by_sector)
    confidence = _confidence(intent, data_quality_pct, sources, missing, unsupported)
    policy = _policy_label(confidence, missing, unsupported, response)

    return {
        "version": "cfo-answer-quality-v1",
        "confidence_score": confidence,
        "quality_level": _quality_level(confidence),
        "policy": policy,
        "intent": intent,
        "data_quality_pct": round(float(data_quality_pct or 0), 1),
        "readiness_level": readiness_level,
        "sources": sources,
        "missing_data": missing[:6],
        "unsupported_claims": unsupported,
        "should_ask_follow_up": bool(missing) and confidence < 0.82,
        "audit_note": _audit_note(confidence, policy, sources),
    }


def _sources(
    intent: str,
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
    data_room: Optional[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    sources: List[Dict[str, Any]] = []
    if company_data:
        present = [key for key in ["fatturato", "costi_variabili", "costi_fissi", "investimenti", "settore"] if company_data.get(key) not in (None, "")]
        sources.append({"type": "company_financials", "label": "KPI aziendali", "coverage": len(present), "fields": present})
    if operational_data_by_sector:
        sectors = {
            sector: sorted(data.keys())
            for sector, data in operational_data_by_sector.items()
            if isinstance(data, dict) and data
        }
        if sectors:
            sources.append({"type": "operational_data", "label": "Dati operativi", "sectors": sectors})
    if data_room:
        sources.append({
            "type": "data_room",
            "label": "Data Room",
            "readiness_score_pct": data_room.get("readiness_score_pct"),
            "active_sector": data_room.get("active_sector"),
        })
    if "memory" in intent:
        sources.append({"type": "memory", "label": "Memoria CFO"})
    if "war" in intent or "weekly" in intent:
        sources.append({"type": "war_room", "label": "War Room"})
    if intent == "faq":
        sources.append({"type": "faq", "label": "FAQ validata"})
    return sources


def _missing_fields(data_room: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not data_room:
        return []
    missing: List[Dict[str, Any]] = []
    for gap in data_room.get("priority_gaps", [])[:6]:
        missing.append({
            "area": gap.get("area"),
            "label": gap.get("label"),
            "missing": gap.get("missing", []),
            "impact": gap.get("impact"),
        })
    return missing


def _unsupported_claims(
    response: str,
    sources: List[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
) -> List[str]:
    warnings: List[str] = []
    lower = (response or "").lower()
    source_types = {source.get("type") for source in sources}
    has_operational_rows = bool(operational_data_by_sector)

    if any(word in lower for word in ["prodotto", "sku", "piatto", "commessa", "canale"]) and not has_operational_rows:
        if "non invento" not in lower and "mi serv" not in lower and "manc" not in lower:
            warnings.append("Risposta operativa senza dati operativi espliciti.")

    money_numbers = re.findall(r"(?:eur|€)\s*[0-9][0-9\.\,]*", lower)
    if len(money_numbers) >= 3 and "company_financials" not in source_types and "data_room" not in source_types:
        warnings.append("Molti importi economici senza fonte dati strutturata.")

    if any(word in lower for word in ["garantito", "sicuro al 100", "senza rischio"]):
        warnings.append("Linguaggio troppo certo per una decisione CFO.")

    return warnings


def _confidence(
    intent: str,
    data_quality_pct: float,
    sources: List[Dict[str, Any]],
    missing: List[Dict[str, Any]],
    unsupported: List[str],
) -> float:
    score = 0.52
    score += min(max(float(data_quality_pct or 0), 0), 100) / 250
    if intent in HIGH_TRUST_INTENTS:
        score += 0.12
    if any(source.get("type") == "data_room" for source in sources):
        score += 0.1
    if any(source.get("type") == "operational_data" for source in sources):
        score += 0.1
    if missing:
        score -= min(len(missing) * 0.035, 0.18)
    if unsupported:
        score -= min(len(unsupported) * 0.12, 0.3)
    return round(max(0.05, min(score, 0.98)), 2)


def _quality_level(confidence: float) -> str:
    if confidence >= 0.82:
        return "high"
    if confidence >= 0.62:
        return "medium"
    return "low"


def _policy_label(confidence: float, missing: List[Dict[str, Any]], unsupported: List[str], response: str) -> str:
    lower = (response or "").lower()
    if unsupported:
        return "needs_review"
    if "non invento" in lower or "mi serv" in lower or "manc" in lower:
        return "asks_for_missing_data"
    if missing and confidence < 0.82:
        return "partial_data"
    return "grounded_answer"


def _audit_note(confidence: float, policy: str, sources: List[Dict[str, Any]]) -> str:
    source_labels = ", ".join(source.get("label", source.get("type", "fonte")) for source in sources) or "nessuna fonte strutturata"
    return f"Confidence {confidence:.2f}, policy {policy}, fonti: {source_labels}."
