"""Company Data Room for CFO-grade data collection.

The Data Room turns scattered company data into a structured CFO checklist:
what exists, what is missing, why it matters and what to ask next.
"""

from typing import Any, Dict, List, Optional

from core.company_operating_model import build_company_operating_model


DATA_ROOM_AREAS = {
    "company_profile": {
        "label": "Profilo azienda",
        "priority": 1,
        "fields": ["company_name", "sector", "annual_revenue", "business_model", "locations"],
        "why": "Serve per dare contesto alle soglie, ai benchmark e alle decisioni CFO.",
    },
    "people": {
        "label": "Personale e ruoli",
        "priority": 2,
        "fields": ["staff_roles", "employee_count", "payroll_costs", "role_productivity", "contract_types"],
        "why": "Permette di capire costo del personale, produttivita' e ruoli che assorbono margine.",
    },
    "products_services": {
        "label": "Prodotti, servizi e prezzi",
        "priority": 3,
        "fields": ["products", "services", "menu_items", "sku_sales", "projects", "unit_prices", "target_margin_pct"],
        "why": "Serve per capire cosa vendere, a che prezzo e con quale margine target.",
    },
    "purchase_costs": {
        "label": "Costi unitari e fornitori",
        "priority": 4,
        "fields": ["suppliers", "ingredient_costs", "purchase_costs", "materials_cost", "supplier_prices", "supplier_terms"],
        "why": "Serve per sbloccare analisi su margine prodotto, food cost, commesse e rinegoziazione fornitori.",
    },
    "sales_channels": {
        "label": "Canali vendita",
        "priority": 5,
        "fields": ["sales_channels", "average_ticket", "average_order_value", "monthly_orders", "conversion_rate", "cac_by_channel"],
        "why": "Serve per distinguere crescita sana da fatturato comprato a margine basso.",
    },
    "cash_working_capital": {
        "label": "Cassa, incassi e pagamenti",
        "priority": 6,
        "fields": ["cash_on_hand", "receivables", "payables", "payment_terms_days", "dso_days", "dpo_days", "collected_pct"],
        "why": "Permette di capire se l'utile si trasforma davvero in cassa.",
    },
    "inventory_operations": {
        "label": "Magazzino e operations",
        "priority": 7,
        "fields": ["inventory", "stock_value", "stock_turnover", "waste_rate", "stockouts", "capacity"],
        "why": "Serve per evidenziare capitale fermo, sprechi, colli di bottiglia e rotture operative.",
    },
    "customers": {
        "label": "Clienti e segmenti",
        "priority": 8,
        "fields": ["customers", "customer_segments", "repeat_rate", "churn_rate", "customer_margin", "top_customers"],
        "why": "Serve per capire quali clienti generano utile, cassa e rischio concentrazione.",
    },
}


SECTOR_REQUIRED_ENTITIES = {
    "restaurant": ["menu_items", "ingredient_costs", "staff_roles", "opening_days_per_month", "average_ticket"],
    "ecommerce": ["sku_sales", "purchase_costs", "monthly_orders", "customer_acquisition_cost", "return_rate_pct"],
    "construction": ["projects", "materials_cost", "labor_cost", "progress_pct", "billed_pct", "collected_pct"],
    "hotel": ["rooms", "occupancy_rate", "adr", "staff_roles", "ota_commissions"],
}


FIELD_LIBRARY = {
    "company_name": {"label": "Nome azienda", "type": "text", "example": "Rossi Group"},
    "sector": {"label": "Settore", "type": "select", "example": "restaurant"},
    "annual_revenue": {"label": "Fatturato annuo", "type": "number", "unit": "EUR", "example": 900000},
    "business_model": {"label": "Modello di business", "type": "text", "example": "Vendita diretta + delivery"},
    "locations": {"label": "Sedi/location", "type": "list", "example": [{"name": "Milano Centro", "revenue": 450000}]},
    "staff_roles": {"label": "Ruoli e costo personale", "type": "table", "example": [{"role": "Cuoco", "count": 2, "monthly_cost": 2400}]},
    "employee_count": {"label": "Numero dipendenti", "type": "number", "example": 12},
    "payroll_costs": {"label": "Costo personale mensile", "type": "number", "unit": "EUR", "example": 28000},
    "role_productivity": {"label": "Produttivita' per ruolo", "type": "table", "example": [{"role": "Sales", "revenue_per_month": 60000}]},
    "contract_types": {"label": "Tipologie contratti", "type": "table", "example": [{"type": "full-time", "count": 8}]},
    "products": {"label": "Prodotti", "type": "table", "example": [{"name": "Prodotto A", "price": 120, "unit_cost": 55}]},
    "services": {"label": "Servizi", "type": "table", "example": [{"name": "Consulenza", "price": 1200, "delivery_cost": 450}]},
    "menu_items": {"label": "Piatti/menu", "type": "table", "example": [{"name": "Margherita", "price": 9, "monthly_units": 1200}]},
    "sku_sales": {"label": "SKU venduti", "type": "table", "example": [{"sku": "Hero", "price": 75, "purchase_cost": 24, "monthly_units": 500}]},
    "projects": {"label": "Commesse/progetti", "type": "table", "example": [{"project": "Cantiere A", "contract_value": 240000, "progress_pct": 65}]},
    "unit_prices": {"label": "Prezzi unitari", "type": "table", "example": [{"item": "Prodotto A", "unit_price": 120}]},
    "target_margin_pct": {"label": "Margine target", "type": "number", "unit": "%", "example": 30},
    "suppliers": {"label": "Fornitori", "type": "table", "example": [{"name": "Fornitore A", "monthly_spend": 12000, "payment_terms_days": 60}]},
    "ingredient_costs": {"label": "Costi ingredienti", "type": "object", "example": {"mozzarella": 0.006, "farina": 0.001}},
    "purchase_costs": {"label": "Costi acquisto", "type": "object", "example": {"Hero SKU": 24}},
    "materials_cost": {"label": "Costo materiali", "type": "number", "unit": "EUR", "example": 82000},
    "supplier_prices": {"label": "Prezzi fornitori", "type": "table", "example": [{"supplier": "A", "item": "Materiale X", "price": 12}]},
    "supplier_terms": {"label": "Termini fornitori", "type": "table", "example": [{"supplier": "A", "payment_terms_days": 60}]},
    "sales_channels": {"label": "Canali vendita", "type": "table", "example": [{"channel": "Meta Ads", "revenue": 200000, "cost": 45000}]},
    "average_ticket": {"label": "Scontrino medio", "type": "number", "unit": "EUR", "example": 36},
    "average_order_value": {"label": "Valore medio ordine", "type": "number", "unit": "EUR", "example": 75},
    "monthly_orders": {"label": "Ordini mensili", "type": "number", "example": 800},
    "conversion_rate": {"label": "Conversion rate", "type": "number", "unit": "%", "example": 2.4},
    "cac_by_channel": {"label": "CAC per canale", "type": "table", "example": [{"channel": "Google", "cac": 18}]},
    "cash_on_hand": {"label": "Liquidita' disponibile", "type": "number", "unit": "EUR", "example": 85000},
    "receivables": {"label": "Crediti da incassare", "type": "number", "unit": "EUR", "example": 120000},
    "payables": {"label": "Debiti fornitori", "type": "number", "unit": "EUR", "example": 90000},
    "payment_terms_days": {"label": "Termini pagamento medi", "type": "number", "unit": "giorni", "example": 45},
    "dso_days": {"label": "DSO", "type": "number", "unit": "giorni", "example": 52},
    "dpo_days": {"label": "DPO", "type": "number", "unit": "giorni", "example": 60},
    "collected_pct": {"label": "Percentuale incassata", "type": "number", "unit": "%", "example": 65},
    "inventory": {"label": "Magazzino", "type": "table", "example": [{"item": "SKU A", "value": 12000, "days_in_stock": 45}]},
    "stock_value": {"label": "Valore stock", "type": "number", "unit": "EUR", "example": 65000},
    "stock_turnover": {"label": "Rotazione stock", "type": "number", "example": 5.2},
    "waste_rate": {"label": "Spreco/scarto", "type": "number", "unit": "%", "example": 4},
    "stockouts": {"label": "Rotture stock", "type": "number", "example": 3},
    "capacity": {"label": "Capacita' operativa", "type": "number", "example": 120},
    "customers": {"label": "Clienti", "type": "table", "example": [{"segment": "VIP", "revenue": 150000, "margin_pct": 35}]},
    "customer_segments": {"label": "Segmenti clienti", "type": "table", "example": [{"segment": "Repeat", "revenue": 240000}]},
    "repeat_rate": {"label": "Repeat rate", "type": "number", "unit": "%", "example": 32},
    "churn_rate": {"label": "Churn rate", "type": "number", "unit": "%", "example": 8},
    "customer_margin": {"label": "Margine cliente", "type": "table", "example": [{"customer": "Cliente A", "margin_pct": 28}]},
    "top_customers": {"label": "Top clienti", "type": "table", "example": [{"customer": "Cliente A", "revenue": 90000}]},
    "opening_days_per_month": {"label": "Giorni apertura/mese", "type": "number", "example": 25},
    "customer_acquisition_cost": {"label": "CAC medio", "type": "number", "unit": "EUR", "example": 18},
    "return_rate_pct": {"label": "Tasso resi", "type": "number", "unit": "%", "example": 5},
    "labor_cost": {"label": "Costo manodopera", "type": "number", "unit": "EUR", "example": 46000},
    "progress_pct": {"label": "Avanzamento commessa", "type": "number", "unit": "%", "example": 65},
    "billed_pct": {"label": "Percentuale fatturata", "type": "number", "unit": "%", "example": 45},
    "rooms": {"label": "Camere", "type": "number", "example": 42},
    "occupancy_rate": {"label": "Occupancy", "type": "number", "unit": "%", "example": 74},
    "adr": {"label": "ADR", "type": "number", "unit": "EUR", "example": 118},
    "ota_commissions": {"label": "Commissioni OTA", "type": "number", "unit": "%", "example": 17},
}


def build_company_data_room(
    company_data: Dict[str, Any],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    active_sector: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the CFO Data Room state and collection roadmap."""

    operating_model = build_company_operating_model(
        company_data=company_data or {},
        operational_data_by_sector=operational_data_by_sector or {},
        active_sector=active_sector,
    )
    combined = _combined_data(company_data or {}, operational_data_by_sector or {})
    active = _normalize_sector(active_sector or (company_data or {}).get("settore") or operating_model.get("active_sector"))
    areas = [_area_status(key, spec, combined) for key, spec in DATA_ROOM_AREAS.items()]
    sector_entities = _sector_entities(active, combined)
    gaps = _priority_gaps(areas, sector_entities, operating_model)
    next_questions = _next_questions(gaps, sector_entities)
    guided_collection = _guided_collection(areas, sector_entities, combined)
    score = _score(areas, sector_entities)

    return {
        "version": "company-data-room-v1",
        "active_sector": active,
        "readiness_score_pct": score,
        "readiness_level": _readiness_level(score),
        "areas": areas,
        "sector_entities": sector_entities,
        "priority_gaps": gaps,
        "next_questions": next_questions,
        "guided_collection": guided_collection,
        "operating_model_summary": {
            "overall_readiness_pct": operating_model.get("overall_readiness_pct"),
            "data_quality": operating_model.get("data_quality"),
            "cfo_signals": operating_model.get("cfo_signals"),
        },
        "premium_outputs": {
            "structured_company_memory": True,
            "cross_sector_data_room": True,
            "cfo_gap_prioritization": True,
            "ready_for_guided_onboarding": True,
            "dynamic_collection_schema": True,
            "prevents_random_answers": True,
        },
    }


def _area_status(key: str, spec: Dict[str, Any], combined: Dict[str, Any]) -> Dict[str, Any]:
    present = [field for field in spec["fields"] if _has_value(combined.get(field))]
    missing = [field for field in spec["fields"] if field not in present]
    coverage = round((len(present) / len(spec["fields"])) * 100, 1)
    return {
        "area": key,
        "label": spec["label"],
        "priority": spec["priority"],
        "why": spec["why"],
        "coverage_pct": coverage,
        "status": _area_level(coverage),
        "present_fields": present,
        "missing_fields": missing,
        "next_question": _question_for_area(spec["label"], missing, spec["why"]),
    }


def _sector_entities(active_sector: str, combined: Dict[str, Any]) -> Dict[str, Any]:
    required = SECTOR_REQUIRED_ENTITIES.get(active_sector, [])
    present = [field for field in required if _has_value(combined.get(field))]
    missing = [field for field in required if field not in present]
    coverage = round((len(present) / len(required)) * 100, 1) if required else 0
    return {
        "sector": active_sector,
        "required_entities": required,
        "present_entities": present,
        "missing_entities": missing,
        "coverage_pct": coverage,
        "can_answer_sector_questions": bool(required) and coverage >= 80,
        "next_question": _question_for_area(f"dati {active_sector}", missing, "rispondere con precisione sulle leve operative del settore"),
    }


def _priority_gaps(
    areas: List[Dict[str, Any]],
    sector_entities: Dict[str, Any],
    operating_model: Dict[str, Any],
) -> List[Dict[str, Any]]:
    gaps: List[Dict[str, Any]] = []
    for area in areas:
        if area["coverage_pct"] >= 80:
            continue
        gaps.append({
            "type": "company_area",
            "area": area["area"],
            "label": area["label"],
            "missing": area["missing_fields"][:4],
            "impact": area["why"],
            "priority_score": round((100 - area["coverage_pct"]) + (10 - area["priority"]), 1),
            "question": area["next_question"],
        })
    if sector_entities.get("missing_entities"):
        gaps.append({
            "type": "sector_entities",
            "area": sector_entities["sector"],
            "label": f"Dati verticali {sector_entities['sector']}",
            "missing": sector_entities["missing_entities"][:5],
            "impact": "Senza questi dati il CFO non puo' calcolare margini, prezzi target e simulazioni specifiche.",
            "priority_score": round(120 - float(sector_entities.get("coverage_pct") or 0), 1),
            "question": sector_entities["next_question"],
        })
    for signal in (operating_model.get("cfo_signals") or [])[:3]:
        if isinstance(signal, dict) and signal.get("question"):
            gaps.append({
                "type": "operating_model_signal",
                "area": signal.get("area", "operating_model"),
                "label": signal.get("label", "Segnale CFO"),
                "missing": [],
                "impact": signal.get("why", "Dato richiesto dal modello operativo."),
                "priority_score": 70,
                "question": signal["question"],
            })
    return sorted(gaps, key=lambda item: item["priority_score"], reverse=True)[:8]


def _next_questions(gaps: List[Dict[str, Any]], sector_entities: Dict[str, Any]) -> List[str]:
    questions = [gap["question"] for gap in gaps if gap.get("question")]
    if sector_entities.get("next_question") and sector_entities["next_question"] not in questions:
        questions.append(sector_entities["next_question"])
    return questions[:6] or ["Inserisci almeno fatturato, costi variabili, costi fissi e settore aziendale."]


def _guided_collection(
    areas: List[Dict[str, Any]],
    sector_entities: Dict[str, Any],
    combined: Dict[str, Any],
) -> Dict[str, Any]:
    area_steps = []
    for area in sorted(areas, key=lambda item: item["priority"]):
        missing = area.get("missing_fields", [])[:5]
        if not missing:
            continue
        area_steps.append({
            "step_id": area["area"],
            "label": area["label"],
            "why": area["why"],
            "destination": "company_data",
            "fields": [_field_schema(field, combined, destination="company_data") for field in missing],
        })

    sector_missing = sector_entities.get("missing_entities", [])[:6]
    sector_step = None
    if sector_missing:
        sector_step = {
            "step_id": f"{sector_entities['sector']}_entities",
            "label": f"Dati verticali {sector_entities['sector']}",
            "why": "Servono per calcolare margini, prezzi target, cassa e simulazioni specifiche.",
            "destination": f"operational_data_by_sector.{sector_entities['sector']}",
            "fields": [
                _field_schema(field, combined, destination=f"operational_data_by_sector.{sector_entities['sector']}")
                for field in sector_missing
            ],
        }

    steps = ([sector_step] if sector_step else []) + area_steps
    return {
        "schema_version": "data-room-guided-collection-v1",
        "first_step": steps[0] if steps else None,
        "steps": steps[:8],
        "suggested_save_strategy": "merge_by_destination",
    }


def _field_schema(field: str, combined: Dict[str, Any], destination: str) -> Dict[str, Any]:
    spec = FIELD_LIBRARY.get(field, {})
    return {
        "key": field,
        "label": spec.get("label", field.replace("_", " ").title()),
        "type": spec.get("type", "text"),
        "unit": spec.get("unit"),
        "example": spec.get("example"),
        "current_value": combined.get(field),
        "required": True,
        "destination": destination,
    }


def _score(areas: List[Dict[str, Any]], sector_entities: Dict[str, Any]) -> float:
    area_score = sum(area["coverage_pct"] for area in areas) / len(areas) if areas else 0
    sector_score = float(sector_entities.get("coverage_pct") or 0)
    if sector_entities.get("required_entities"):
        return round((area_score * 0.65) + (sector_score * 0.35), 1)
    return round(area_score, 1)


def _readiness_level(score: float) -> str:
    if score >= 80:
        return "cfo_ready"
    if score >= 55:
        return "analysis_ready"
    if score >= 30:
        return "guided_collection_needed"
    return "insufficient_data"


def _area_level(coverage: float) -> str:
    if coverage >= 80:
        return "complete"
    if coverage >= 50:
        return "usable"
    if coverage >= 25:
        return "partial"
    return "missing"


def _question_for_area(label: str, missing: List[str], why: str) -> str:
    if not missing:
        return f"{label}: dati principali presenti. Aggiorna i valori mensilmente."
    clean_why = (why or "").strip().rstrip(". ")
    if clean_why.lower().startswith("serve per "):
        clean_why = clean_why[10:]
    return f"Per {label.lower()} mi servono: {', '.join(missing[:3])}. Mi servono per {clean_why[:1].lower() + clean_why[1:]}."


def _combined_data(company_data: Dict[str, Any], operational_data_by_sector: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    combined = dict(company_data or {})
    aliases = {
        "annual_revenue": ["fatturato"],
        "variable_costs": ["costi_variabili"],
        "fixed_costs": ["costi_fissi"],
        "invested_capital": ["investimenti"],
        "sector": ["settore"],
    }
    for canonical, source_keys in aliases.items():
        if not _has_value(combined.get(canonical)):
            for source in source_keys:
                if _has_value(combined.get(source)):
                    combined[canonical] = combined[source]
                    break
    for sector_data in (operational_data_by_sector or {}).values():
        for key, value in (sector_data or {}).items():
            if _has_value(value) and not _has_value(combined.get(key)):
                combined[key] = value
    return combined


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {}, ())


def _normalize_sector(sector: Optional[str]) -> str:
    value = (sector or "default").strip().lower()
    aliases = {
        "ristorante": "restaurant",
        "ristoranti": "restaurant",
        "e-commerce": "ecommerce",
        "costruzioni": "construction",
        "edilizia": "construction",
        "albergo": "hotel",
        "hotels": "hotel",
    }
    return aliases.get(value, value)
