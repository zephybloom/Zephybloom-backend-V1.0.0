# -*- coding: utf-8 -*-
# content/core/forecast.py — Previsioni robuste (Holt + Auto + Seasonal naive + EMA + trend guards)
from __future__ import annotations

from typing import List, Optional, Tuple
from math import isfinite

from utils.math_utils import holt_winters_additive


# =============================================================================
# Sanitizzazione & helpers
# =============================================================================
def _sanitize_history(history: List[float]) -> List[float]:
    """
    Cast a float, rimuove NaN/Inf, conserva ordine.
    """
    out: List[float] = []
    for x in history or []:
        try:
            v = float(x)
            if isfinite(v):
                out.append(v)
        except Exception:
            continue
    return out


def _non_negative_guard(series: List[float], forecast: List[float]) -> List[float]:
    """
    Se tutti i dati storici sono >= 0, clamp i forecast a >= 0.
    Utile per ricavi, fatturato, volumi, costi.
    """
    if not series:
        return forecast
    if min(series) >= 0.0:
        return [max(0.0, float(v)) for v in forecast]
    return [float(v) for v in forecast]


def _is_flat(series: List[float], tol: float = 1e-9) -> bool:
    """
    True se la serie è praticamente costante.
    """
    if not series:
        return True
    return (max(series) - min(series)) <= tol


def _mean(values: List[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def _median(values: List[float]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return s[mid]
    return (s[mid - 1] + s[mid]) / 2.0


def _last_deltas(series: List[float]) -> List[float]:
    if len(series) < 2:
        return []
    return [series[i] - series[i - 1] for i in range(1, len(series))]


def _trend_strength(series: List[float]) -> float:
    """
    Proxy leggero della forza del trend:
    rapporto tra drift assoluto e dispersione dei delta.
    """
    deltas = _last_deltas(series)
    if len(deltas) < 2:
        return 0.0

    drift = abs((series[-1] - series[0]) / max(len(series) - 1, 1))
    mad = _mean([abs(d - _mean(deltas)) for d in deltas])

    if mad <= 1e-9:
        return 1.0 if drift > 0 else 0.0
    return drift / mad


# =============================================================================
# Metodi semplici
# =============================================================================
def _naive(last: float, periods: int) -> List[float]:
    return [float(last)] * periods


def _sma(hist: List[float], periods: int, window: int = 3) -> List[float]:
    w = max(1, min(int(window), len(hist)))
    avg = _mean(hist[-w:])
    return [avg] * periods


def _ema_level(hist: List[float], alpha: float = 0.35) -> float:
    """
    Livello EMA finale.
    """
    if not hist:
        return 0.0
    alpha = min(max(float(alpha), 0.01), 0.99)
    level = hist[0]
    for x in hist[1:]:
        level = alpha * x + (1.0 - alpha) * level
    return level


def _ema(hist: List[float], periods: int, alpha: float = 0.35) -> List[float]:
    """
    Forecast EMA semplice: ripete il livello smussato finale.
    """
    level = _ema_level(hist, alpha=alpha)
    return [level] * periods


def _drift(hist: List[float], periods: int) -> List[float]:
    """
    Random walk con drift lineare:
      drift = (last - first) / (n - 1)
    """
    n = len(hist)
    if n < 2:
        return [hist[-1]] * periods
    drift = (hist[-1] - hist[0]) / max(n - 1, 1)
    return [hist[-1] + drift * (i + 1) for i in range(periods)]


def _robust_drift(hist: List[float], periods: int) -> List[float]:
    """
    Variante più robusta del drift:
    usa la mediana dei delta recenti per evitare che un solo outlier
    distorca troppo la previsione.
    """
    if len(hist) < 2:
        return [hist[-1]] * periods

    deltas = _last_deltas(hist)
    if not deltas:
        return [hist[-1]] * periods

    tail = deltas[-min(6, len(deltas)) :]
    drift = _median(tail)
    return [hist[-1] + drift * (i + 1) for i in range(periods)]


# =============================================================================
# Stagionalità leggera
# =============================================================================
def _autocorr_at_lag(series: List[float], lag: int) -> float:
    """
    Autocorrelazione (Pearson) al lag dato.
    Restituisce 0.0 se non calcolabile.
    """
    n = len(series)
    if lag <= 0 or n <= lag + 2:
        return 0.0

    mu = _mean(series)
    num = 0.0
    den_l = 0.0
    den_r = 0.0

    for t in range(lag, n):
        lt = series[t] - mu
        rt = series[t - lag] - mu
        num += lt * rt
        den_l += lt * lt
        den_r += rt * rt

    den = (den_l * den_r) ** 0.5
    return num / den if den > 0 else 0.0


def _detect_season_length(series: List[float]) -> Optional[int]:
    """
    Prova lunghezze stagionali comuni.
    Ritorna la migliore se abbastanza credibile.

    Richiede almeno ~2 cicli per essere affidabile.
    """
    n = len(series)
    candidates = [12, 6, 4, 3, 2]

    best_lag = None
    best_r = 0.0

    for lag in candidates:
        if n < lag * 2:
            continue
        r = _autocorr_at_lag(series, lag)
        if r > best_r:
            best_r = r
            best_lag = lag

    return best_lag if (best_lag is not None and best_r >= 0.55) else None


def _seasonal_naive_forecast(hist: List[float], periods: int, season_len: int) -> List[float]:
    """
    Ripete l'ultimo pattern osservato.
    Se non c'è abbastanza storia, media per posizione stagionale.
    """
    n = len(hist)
    if season_len <= 1 or n == 0:
        return _naive(hist[-1], periods)

    if n >= season_len:
        pattern = hist[-season_len:]
    else:
        pattern = [0.0] * season_len
        counts = [0] * season_len
        for i, v in enumerate(hist):
            idx = i % season_len
            pattern[idx] += v
            counts[idx] += 1
        for i in range(season_len):
            pattern[i] = (pattern[i] / counts[i]) if counts[i] > 0 else hist[-1]

    fc: List[float] = []
    for i in range(periods):
        fc.append(pattern[i % season_len])
    return fc


# =============================================================================
# Metodo auto: selezione intelligente
# =============================================================================
def _select_auto_method(hist: List[float]) -> Tuple[str, Optional[int]]:
    """
    Sceglie il metodo migliore in modo euristico:
    - serie vuota   -> naive
    - serie piatta  -> naive
    - stagionalità  -> seasonal_naive
    - serie molto corta -> sma / naive
    - trend marcato -> holt
    - trend debole  -> ema
    """
    n = len(hist)

    if n == 0:
        return "naive", None

    if n == 1:
        return "naive", None

    if _is_flat(hist):
        return "naive", None

    season = _detect_season_length(hist)
    if season:
        return "seasonal_naive", season

    if n == 2:
        return "drift", None

    if n == 3:
        return "sma", None

    strength = _trend_strength(hist)
    if strength >= 0.75 and n >= 4:
        return "holt", None

    return "ema", None


# =============================================================================
# API principale
# =============================================================================
def forecast_series(history: List[float], periods: int = 6, method: str = "holt") -> List[float]:
    """
    Prevede i prossimi 'periods' punti data.

    Metodi supportati:
      - "auto"
      - "holt"
      - "seasonal_naive"
      - "naive"
      - "sma"
      - "ema"
      - "drift"
      - "robust_drift"

    Regole:
      - history vuota -> zeri
      - clamp non-negativo se la storia è tutta >= 0
      - holt fallback -> robust_drift -> drift -> naive
    """
    hist = _sanitize_history(history)
    p = max(1, min(int(periods or 1), 120))

    if not hist:
        return [0.0] * p

    method_l = (method or "holt").lower().strip()

    # =========================
    # AUTO
    # =========================
    if method_l == "auto":
        selected, season = _select_auto_method(hist)

        if selected == "seasonal_naive":
            fc = _seasonal_naive_forecast(hist, p, season or 1)
            return _non_negative_guard(hist, fc)

        if selected == "holt":
            try:
                fc = holt_winters_additive(hist, alpha=0.35, beta=0.15, periods=p)
                return _non_negative_guard(hist, fc)
            except Exception:
                fc = _robust_drift(hist, p) if len(hist) >= 2 else _naive(hist[-1], p)
                return _non_negative_guard(hist, fc)

        if selected == "ema":
            fc = _ema(hist, p, alpha=0.35)
            return _non_negative_guard(hist, fc)

        if selected == "drift":
            fc = _drift(hist, p)
            return _non_negative_guard(hist, fc)

        if selected == "sma":
            fc = _sma(hist, p, window=3)
            return _non_negative_guard(hist, fc)

        fc = _naive(hist[-1], p)
        return _non_negative_guard(hist, fc)

    # =========================
    # HOLT
    # =========================
    if method_l == "holt":
        if len(hist) < 3 or _is_flat(hist):
            fc = _naive(hist[-1], p)
            return _non_negative_guard(hist, fc)
        try:
            fc = holt_winters_additive(hist, alpha=0.35, beta=0.15, periods=p)
        except Exception:
            if len(hist) >= 3:
                fc = _robust_drift(hist, p)
            elif len(hist) >= 2:
                fc = _drift(hist, p)
            else:
                fc = _naive(hist[-1], p)
        return _non_negative_guard(hist, fc)

    # =========================
    # SEASONAL NAIVE
    # =========================
    if method_l == "seasonal_naive":
        season = _detect_season_length(hist)
        if not season:
            if len(hist) >= 12:
                season = 12
            elif len(hist) >= 6:
                season = 6
            elif len(hist) >= 4:
                season = 4
            elif len(hist) >= 3:
                season = 3
            else:
                season = 1
        fc = _seasonal_naive_forecast(hist, p, season)
        return _non_negative_guard(hist, fc)

    # =========================
    # EMA
    # =========================
    if method_l == "ema":
        fc = _ema(hist, p, alpha=0.35)
        return _non_negative_guard(hist, fc)

    # =========================
    # NAIVE
    # =========================
    if method_l == "naive":
        return _non_negative_guard(hist, _naive(hist[-1], p))

    # =========================
    # SMA
    # =========================
    if method_l == "sma":
        return _non_negative_guard(hist, _sma(hist, p, window=3))

    # =========================
    # DRIFT
    # =========================
    if method_l == "drift":
        return _non_negative_guard(hist, _drift(hist, p))

    # =========================
    # ROBUST DRIFT
    # =========================
    if method_l == "robust_drift":
        return _non_negative_guard(hist, _robust_drift(hist, p))

    # =========================
    # Fallback
    # =========================
    return _non_negative_guard(hist, _naive(hist[-1], p))