#!/bin/bash
# Quick Setup Script for Scalability Improvements
# Run after git pull of the optimization changes

set -e  # Exit on error

echo "🚀 Setting up scalability optimizations..."
echo ""

# 1. Update dependencies
echo "📦 Installing new dependencies..."
pip install -q prometheus-client  # Or: pip install -r requirements.txt
echo "✅ Dependencies installed"
echo ""

# 2. Check Redis (optional but recommended)
echo "🔍 Checking Redis connection..."
if command -v redis-cli &> /dev/null; then
    if redis-cli ping > /dev/null 2>&1; then
        echo "✅ Redis is running"
        REDIS_AVAILABLE=true
    else
        echo "⚠️  Redis is not running"
        echo "  → For distributed cache, run: redis-server"
        REDIS_AVAILABLE=false
    fi
else
    echo "⚠️  Redis not installed"
    echo "  → Install with: brew install redis (macOS) or apt install redis-server (Linux)"
    REDIS_AVAILABLE=false
fi
echo ""

# 3. Create .env.production template
echo "📝 Creating .env.production template..."
cat > .env.production.example << 'EOF'
# ===== Cache Settings =====
ZB_CACHE_ENABLED=true
ZB_CACHE_TTL_SECONDS=600
ZB_CACHE_MAX_IN_MEMORY=1000

# ===== Circuit Breaker Settings =====
ZB_CIRCUIT_BREAKER_ENABLED=true
ZB_CIRCUIT_BREAKER_LLM_FAIL_MAX=5
ZB_CIRCUIT_BREAKER_LLM_RESET_TIMEOUT=60
ZB_CIRCUIT_BREAKER_DB_FAIL_MAX=3
ZB_CIRCUIT_BREAKER_DB_RESET_TIMEOUT=30

# ===== Database Pool (Production) =====
ZB_DB_POOL_SIZE=100
ZB_DB_MAX_OVERFLOW=200

# ===== Rate Limiting =====
ZB_RATE_LIMIT_ENABLED=true
ZB_RATE_LIMIT_API_KEY_PER_MINUTE=1000
ZB_RATE_LIMIT_TENANT_PER_MINUTE=120
ZB_RATE_LIMIT_IP_PER_MINUTE=60

# ===== Prometheus Metrics =====
ZB_PROMETHEUS_ENABLED=true
ZB_PROMETHEUS_PORT=9090

# ===== Redis (if available) =====
# ZB_REDIS_URL=redis://localhost:6379/0
EOF
echo "✅ Created .env.production.example"
echo ""

# 4. Test the changes
echo "🧪 Running basic import tests..."
python -c "
try:
    from infra.cache_decorator import cached, init_cache
    print('✅ cache_decorator imports OK')
except Exception as e:
    print(f'❌ cache_decorator error: {e}')

try:
    from infra.circuit_breaker import CircuitBreaker, get_breaker
    print('✅ circuit_breaker imports OK')
except Exception as e:
    print(f'❌ circuit_breaker error: {e}')

try:
    from infra.metrics import get_metrics_endpoint
    print('✅ metrics imports OK')
except Exception as e:
    print(f'❌ metrics error: {e}')
"
echo ""

# 5. Summary
echo "✨ Setup Complete! ✨"
echo ""
echo "📊 Next Steps:"
echo "  1. Review SCALABILITY_IMPROVEMENTS.md"
echo "  2. Copy .env.production.example to .env.production"
echo "  3. Update .env.production with your Redis URL (if available)"
echo "  4. Run: python -m uvicorn api.main:app --reload"
echo "  5. Test: curl http://localhost:8000/metrics"
echo ""

if [ "$REDIS_AVAILABLE" = false ]; then
    echo "⚠️  Note: Running without Redis means:"
    echo "  - Cache uses in-memory LRU (single process only)"
    echo "  - Rate limiting uses in-memory (single process only)"
    echo "  → Set ZB_REDIS_URL=... in .env to enable distributed mode"
fi
echo ""
echo "🎯 Performance targets:"
echo "  - /cfo/analyze: 50ms → 5ms (cached)"
echo "  - Throughput: 10 RPS → 500 RPS"
echo "  - Memory: Safe (LRU eviction)"
echo ""
