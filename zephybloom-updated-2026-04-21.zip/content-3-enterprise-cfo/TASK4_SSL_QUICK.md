# Task 4: SSL/HTTPS Setup - Quick Guide

## 📋 Cosa Abbiamo Fatto

✅ Creato `nginx.conf` - reverse proxy con SSL/TLS  
✅ Creato `scripts/setup_ssl.sh` - automazione Let's Encrypt  
✅ Nginx con rate limiting integrato  
✅ Auto-renewal certificati

## 🚀 Come Usarlo (5 minuti)

### Step 1: Acquista dominio
```bash
# Compra dominio (Namecheap, Route53, etc.)
# Esempio: api.zephybloom.com
# Sottoindirizzo A record → IP del tuo server
```

### Step 2: Esegui setup SSL
```bash
bash scripts/setup_ssl.sh api.zephybloom.com admin@company.com
```

Fatto! Certbot installa Nginx, ottiene il certificato, configura auto-renewal.

### Step 3: Avvia backend
```bash
export ZB_OPENAI_API_KEY="sk-proj-..."
python -m uvicorn api.main:app --port 8002
```

### Step 4: Testa HTTPS
```bash
curl https://api.zephybloom.com/health
# Expected: {"status":"healthy"}
```

## ✅ Verifica
- ✅ Certificato valido (green lock in browser)
- ✅ Automatic renewal setup
- ✅ Rate limiting active
- ✅ HSTS headers added

**Status:** ✅ TASK 4 COMPLETE
