"""
Enhanced CFO Analyze endpoint with full decision-making system

POST /cfo/analyze-decision

Orchestrates all 12 decision modules to provide comprehensive strategic guidance.
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import Optional
import logging

from api.schemas_cfo import AnalyzeRequest, AnalyzeResponse
from api.schemas_decision import (
    EnhancedAnalyzeResponse,
    StrategicDecisionDetail,
    ExecutiveSummaryDetail,
    WowMomentDetail,
    ObjectionDetail,
    ActionPlanDetail,
    ActionDetail,
)
from api.tenant_context import require_auth, TenantContext
from core.analysis import analyze_company
from core.cfo_intelligence import build_cfo_insight_pack
from core.decision_coordinator import (
    DecisionCoordinator,
    StrategicDecision,
    ExecutiveSummary,
    DecisionCoordinatorOutput,
)
from core.validation_robust import validate_input_safe

# Performance
from infra.cache_decorator import cached
from infra.circuit_breaker import get_breaker
from infra.metrics import track_analysis_metrics

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/cfo",
    tags=["cfo-decision"],
)


@router.post(
    "/analyze-decision",
    response_model=EnhancedAnalyzeResponse,
    summary="Complete Analysis with Strategic Decisions",
    description="Financial analysis + complete decision-making system",
)
@cached("cfo_analyze_decision", ttl=600)
@track_analysis_metrics(sector="decision")
async def cfo_analyze_decision(
    request: AnalyzeRequest,
    tenant: TenantContext = Depends(require_auth),
) -> EnhancedAnalyzeResponse:
    """
    Complete CFO analysis with 12-module decision-making system.
    
    Flow:
    1. Run financial analysis (base layer)
    2. Identify prioritized actions (decision processor)
    3. Simulate each action in 3 scenarios (simulator)
    4. Calculate cost of inaction (cost calculator)
    5. Select appropriate tone (tone manager)
    6. Generate action plans (action plan generator)
    7. Identify likely objections (objection handler)
    8. Extract memorable insights (wow synthesizer)
    9. Record in company memory (strategic memory)
    10. Build executive summary
    11. Return comprehensive decision package
    
    **Performance:**
    - Results cached for 10 minutes
    - All 12 modules run in ~500ms (optimized)
    - Circuit breaker protects against cascading failures
    
    **Output includes:**
    - Base financial analysis
    - Top 3 strategic decisions (with rankings)
    - Cost of inaction + timeline to crisis
    - 3-scenario simulations (best/realistic/worst)
    - 24h/7gg/30gg action plans
    - Likely objections with data-driven responses
    - Memorable insights (wow moments)
    - Trend analysis (if historical data available)
    """
    
    try:
        if request.employee_count is None:
            raise ValueError("employee_count is required")
        if request.monthly_salary_avg is None:
            raise ValueError("monthly_salary_avg is required")
        if request.hiring_context is None:
            raise ValueError("hiring_context is required")
        if request.hiring_context not in {"boom", "decline", "stable", "hold"}:
            raise ValueError("hiring_context must be one of: boom, decline, stable, hold")
        if request.settore not in {"saas", "retail", "manufacturing", "services", "ecommerce", "default"}:
            raise ValueError("sector is not supported")

        # 0. Validate input robustly
        logger.info(f"[DECIDE] Validating input for {request.company_name}")
        validation = validate_input_safe(
            fatturato=request.fatturato,
            costi_variabili=request.costi_variabili,
            costi_fissi=request.costi_fissi,
            investimenti=request.investimenti,
            settore=request.settore,
            company_name=request.company_name,
        )
        
        if not validation.is_valid:
            logger.warning(f"[DECIDE] Input validation failed: {validation.errors}")
            raise ValueError(". ".join(validation.errors))
        
        # Log any warnings
        if validation.warnings:
            for warning in validation.warnings:
                logger.warning(f"[DECIDE] {warning}")
        
        # 1. Run base financial analysis
        logger.info(f"[DECIDE] Running base analysis for {validation.data['company_name']}")
        base_analysis = await _run_base_analysis(request)
        
        # 2. Run decision coordinator
        logger.info("[DECIDE] Orchestrating decision modules (1-12)")
        coordinator = DecisionCoordinator()
        
        company_size = _infer_company_size(request.fatturato)
        company_phase = _infer_company_phase(request)
        settore = request.settore or "default"
        
        output: DecisionCoordinatorOutput = coordinator.coordinate(
            analysis=base_analysis,
            company_id=tenant.tenant_id,
            company_size=company_size,
            company_phase=company_phase,
            settore=settore,
        )
        
        # 3. Convert to API response
        logger.info("[DECIDE] Converting to enhanced response")
        enhanced_decisions = _convert_decisions(output.decisions)
        executive_summary = _convert_summary(output.summary)
        industry_insight = build_cfo_insight_pack(
            analysis=output.analysis,
            settore=settore,
            trend_narrative=output.trend_narrative,
        )
        
        response = EnhancedAnalyzeResponse(
            status=output.analysis.status,
            headline=output.analysis.headline,
            summary=output.analysis.summary,
            gross_profit_eur=output.analysis.kpi_snapshot.gross_profit_eur if output.analysis.kpi_snapshot else None,
            gross_margin_pct=output.analysis.kpi_snapshot.gross_margin_pct if output.analysis.kpi_snapshot else None,
            ebitda_eur=output.analysis.kpi_snapshot.ebitda_eur if output.analysis.kpi_snapshot else None,
            ebitda_margin_pct=output.analysis.kpi_snapshot.ebitda_margin_pct if output.analysis.kpi_snapshot else None,
            net_profit_eur=output.analysis.kpi_snapshot.net_profit_eur if output.analysis.kpi_snapshot else None,
            net_margin_pct=output.analysis.kpi_snapshot.net_margin_pct if output.analysis.kpi_snapshot else None,
            roi_pct=output.analysis.kpi_snapshot.roi_pct if output.analysis.kpi_snapshot else None,
            ccc_days=output.analysis.kpi_snapshot.ccc_days if output.analysis.kpi_snapshot else None,
            industry_insight=industry_insight,
            executive_summary=executive_summary,
            strategic_decisions=enhanced_decisions,
            trend_narrative=output.trend_narrative,
            company_id=tenant.tenant_id,
        )
        
        logger.info(f"[DECIDE] SUCCESS: {len(enhanced_decisions)} decisions identified")
        return response
    
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"[DECIDE] Input validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid input: {str(e)}",
        )
    except ZeroDivisionError as e:
        logger.warning(f"[DECIDE] Calculation error (division by zero): {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Calculation error: Cannot divide by zero. Check that revenue and key metrics are positive.",
        )
    except TypeError as e:
        logger.warning(f"[DECIDE] Type error in processing: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Type error: Invalid data type provided. {str(e)}",
        )
    except KeyError as e:
        logger.warning(f"[DECIDE] Missing required field: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Missing required field: {str(e)}",
        )
    except Exception as e:
        logger.error(f"[DECIDE] Unexpected error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"System error during analysis. Please try again later.",
        )


# ===== Helper functions =====

async def _run_base_analysis(request: AnalyzeRequest) -> AnalyzeResponse:
    """Run base financial analysis with circuit breaker"""
    breaker = get_breaker("analysis")
    return breaker.call(
        analyze_company,
        fatturato=request.fatturato,
        costi_variabili=request.costi_variabili,
        costi_fissi=request.costi_fissi,
        investimenti=request.investimenti or 0,
        settore=request.settore,
        company_name=request.company_name,
        dso_days=request.dso_days,
        dio_days=request.dio_days,
        dpo_days=request.dpo_days,
    )


def _infer_company_size(fatturato: float) -> str:
    """Infer company size from revenue"""
    if fatturato < 500_000:
        return "small"
    elif fatturato < 5_000_000:
        return "medium"
    else:
        return "large"


def _infer_company_phase(request: AnalyzeRequest) -> str:
    """Infer company phase from financial metrics"""
    # Simplified logic - could be more sophisticated
    margin_pct = (request.fatturato - request.costi_variabili - request.costi_fissi) / request.fatturato
    
    if request.fatturato < 1_000_000:
        return "startup"
    elif margin_pct < 0.05:
        return "startup"
    elif margin_pct < 0.15:
        return "growth"
    else:
        return "scale"


def _convert_decisions(decisions: list) -> list:
    """Convert coordinator decisions to API schema"""
    result = []
    
    for d in decisions:
        objections = [
            ObjectionDetail(
                objection=obj.objection,
                response=obj.response,
                supporting_data=obj.supporting_data or {},
                recommendation=obj.recommendation,
            )
            for obj in d.common_objections
        ]
        
        action_plan = ActionPlanDetail(
            timeline_24h=[
                ActionDetail(
                    description=a.description if hasattr(a, 'description') else str(a),
                    priority=str(a.priority) if hasattr(a, 'priority') else "MEDIUM",
                    expected_outcome=a.expected_outcome if hasattr(a, 'expected_outcome') else "TBD",
                    success_metric=a.success_metric if hasattr(a, 'success_metric') else "TBD",
                )
                for a in d.timeline_24h
            ],
            timeline_7gg=[
                ActionDetail(
                    description=a.description if hasattr(a, 'description') else str(a),
                    priority=str(a.priority) if hasattr(a, 'priority') else "MEDIUM",
                    expected_outcome=a.expected_outcome if hasattr(a, 'expected_outcome') else "TBD",
                    success_metric=a.success_metric if hasattr(a, 'success_metric') else "TBD",
                )
                for a in d.timeline_7gg
            ],
            timeline_30gg=[
                ActionDetail(
                    description=a.description if hasattr(a, 'description') else str(a),
                    priority=str(a.priority) if hasattr(a, 'priority') else "MEDIUM",
                    expected_outcome=a.expected_outcome if hasattr(a, 'expected_outcome') else "TBD",
                    success_metric=a.success_metric if hasattr(a, 'success_metric') else "TBD",
                )
                for a in d.timeline_30gg
            ],
        )
        
        decision_detail = StrategicDecisionDetail(
            title=d.title,
            description=d.description,
            verdict=d.verdict,
            priority_score=d.priority_score,
            impact_eur=d.impact_eur,
            cost_of_inaction_monthly=d.cost_of_inaction.monthly_cost_eur,
            cost_of_inaction_6m=d.cost_of_inaction.quarterly_cost_eur * 2 if hasattr(d.cost_of_inaction, 'quarterly_cost_eur') else (d.cost_of_inaction.monthly_cost_eur * 6 if hasattr(d.cost_of_inaction, 'monthly_cost_eur') else 0),
            timeline_to_crisis=f"{d.cost_of_inaction.timeline_to_crisis}-{d.cost_of_inaction.timeline_to_crisis + 3} months" if hasattr(d.cost_of_inaction, 'timeline_to_crisis') else "6-9 months",
            best_case=d.best_case or {},
            realistic_case=d.realistic_case or {},
            worst_case=d.worst_case or {},
            action_plan=action_plan,
            common_objections=objections,
            tone=d.tone,
            tone_message=d.message,
        )
        
        result.append(decision_detail)
    
    return result


def _convert_summary(summary: ExecutiveSummary) -> ExecutiveSummaryDetail:
    """Convert coordinator summary to API schema"""
    wow_moments = [
        WowMomentDetail(
            title=w.title if hasattr(w, 'title') else "Insight",
            description=w.description if hasattr(w, 'description') else "",
            memorability_score=w.memorability_score if hasattr(w, 'memorability_score') else 5,
        )
        for w in summary.wow_moments
    ]
    
    return ExecutiveSummaryDetail(
        headline=summary.headline,
        situation=summary.situation,
        opportunity=summary.opportunity,
        primary_decision=summary.decision,
        timeline=summary.timeline,
        wow_moments=wow_moments,
    )
