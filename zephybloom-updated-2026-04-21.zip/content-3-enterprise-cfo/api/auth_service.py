"""
Enhanced authentication service with JWT tokens, API keys, and password hashing.

Features:
- JWT token generation and validation
- API key creation, hashing, and verification
- Password hashing with bcrypt
- Token revocation (token blacklist)
- Rate limiting by API key
"""

from __future__ import annotations
import os
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Any, Tuple

import jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from db.models import User, APIKey, Tenant, AuditLog

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT configuration from environment
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-key-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24


class AuthService:
    """Centralized authentication service."""

    @staticmethod
    def hash_password(password: str) -> str:
        """Hash password for storage."""
        return pwd_context.hash(password)

    @staticmethod
    def verify_password(password: str, password_hash: str) -> bool:
        """Verify password against stored hash."""
        try:
            return pwd_context.verify(password, password_hash)
        except Exception:
            return False

    @staticmethod
    def create_access_token(
        user_id: int,
        tenant_id: str,
        expires_hours: int = JWT_EXPIRY_HOURS,
        extra_claims: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Create JWT access token.
        
        Args:
            user_id: User ID
            tenant_id: Tenant context
            expires_hours: Token expiry in hours
            extra_claims: Additional claims to include
            
        Returns:
            Encoded JWT token
        """
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(hours=expires_hours)
        
        payload = {
            "sub": str(user_id),
            "tenant_id": tenant_id,
            "iat": int(now.timestamp()),
            "exp": int(expires_at.timestamp()),
            "type": "access",
        }
        
        if extra_claims:
            payload.update(extra_claims)
        
        return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

    @staticmethod
    def verify_access_token(token: str) -> Dict[str, Any]:
        """
        Verify JWT token and return payload.
        
        Args:
            token: JWT token string
            
        Returns:
            Token payload dict
            
        Raises:
            jwt.InvalidTokenError if token is invalid
        """
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError as e:
            raise ValueError(f"Invalid token: {e}")

    @staticmethod
    def create_api_key(
        db: Session,
        user_id: int,
        tenant_id: str,
        name: str,
        rate_limit_per_minute: int = 100,
        expires_in_days: Optional[int] = None,
    ) -> Tuple[str, str, 'APIKey']:  # (plain_key, masked_key, api_key_record)
        """
        Create a new API key for programmatic access.
        
        Args:
            db: Database session
            user_id: User who owns this key
            tenant_id: Tenant context
            name: Human-readable name (e.g., "Mobile App")
            rate_limit_per_minute: Rate limit for this key
            expires_in_days: Optional expiry (None = no expiry)
            
        Returns:
            Tuple of (plain_key, masked_key, api_key_record) where masked_key is for display
        """
        # Generate random key
        plain_key = secrets.token_urlsafe(32)
        key_hash = AuthService._hash_api_key(plain_key)
        
        expires_at = None
        if expires_in_days:
            expires_at = datetime.now(timezone.utc) + timedelta(days=expires_in_days)
        
        # Store hashed key in database
        api_key = APIKey(
            key=key_hash,
            name=name,
            user_id=user_id,
            tenant_id=tenant_id,
            rate_limit_per_minute=rate_limit_per_minute,
            expires_at=expires_at,
        )
        db.add(api_key)
        db.commit()
        db.refresh(api_key)
        
        # Return plain key (can only be shown once), masked version, and record
        masked_key = f"{plain_key[:8]}...{plain_key[-4:]}"
        return plain_key, masked_key, api_key

    @staticmethod
    def verify_api_key(db: Session, api_key: str) -> Optional[APIKey]:
        """
        Verify API key and return APIKey record.
        
        Args:
            db: Database session
            api_key: Plain API key from request
            
        Returns:
            APIKey record if valid, None otherwise
        """
        key_hash = AuthService._hash_api_key(api_key)
        
        api_key_record = (
            db.query(APIKey)
            .filter(
                APIKey.key == key_hash,
                APIKey.is_active == True,
            )
            .first()
        )
        
        if not api_key_record:
            return None
        
        # Check expiry
        if api_key_record.expires_at and api_key_record.expires_at < datetime.now(timezone.utc):
            return None
        
        # Update last_used_at
        api_key_record.last_used_at = datetime.now(timezone.utc)
        db.commit()
        
        return api_key_record

    @staticmethod
    def _hash_api_key(key: str) -> str:
        """Hash API key for storage."""
        return hashlib.sha256(key.encode()).hexdigest()


def log_audit(
    db: Session,
    action: str,
    endpoint: str,
    method: str,
    status_code: int,
    response_time_ms: int,
    user_id: Optional[int] = None,
    tenant_id: Optional[str] = None,
    api_key_id: Optional[int] = None,
    error_message: Optional[str] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
):
    """Log audit trail for compliance."""
    audit = AuditLog(
        action=action,
        endpoint=endpoint,
        method=method,
        status_code=status_code,
        response_time_ms=response_time_ms,
        user_id=user_id,
        tenant_id=tenant_id,
        api_key_id=api_key_id,
        error_message=error_message,
        ip_address=ip_address,
        user_agent=user_agent,
    )
    db.add(audit)
    db.commit()
