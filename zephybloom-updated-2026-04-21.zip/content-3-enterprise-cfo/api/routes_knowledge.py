# content/api/routes_knowledge.py
from __future__ import annotations
from fastapi import APIRouter, Depends, Query
from typing import Any, Dict, List, Optional
from knowledge.ingest_schemas import IngestRequest
from knowledge.index import ingest as ingest_knowledge, search as search_knowledge
from infra.tenancy import get_tenant_id
from utils.errors import from_exception

router = APIRouter(prefix="/knowledge", tags=["knowledge"])

@router.post("/ingest")
def knowledge_ingest(req: IngestRequest, tenant_id: str = Depends(get_tenant_id)) -> Dict[str, Any]:
    try:
        # tenant_id è propagabile su storage/indice se necessario (namespace)
        return ingest_knowledge(req)
    except Exception as e:
        raise from_exception(e, message="Unexpected error during knowledge ingestion")

@router.post("/search")
def knowledge_search(
    payload: Dict[str, Any],
    tenant_id: str = Depends(get_tenant_id),
):
    try:
        q = str(payload.get("query", "") or "")
        top_k = int(payload.get("top_k", 6) or 6)
        sector = payload.get("sector")
        level = payload.get("level")
        language = payload.get("language")
        return {"hits": search_knowledge(q, top_k=top_k, sector=sector, level=level, language=language)}
    except Exception as e:
        raise from_exception(e, message="Unexpected error during knowledge search")
