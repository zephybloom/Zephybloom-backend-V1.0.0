# content/api/routes_advice.py
"""
Strategic advice and action planning endpoint.

Main Endpoint:
  POST /advice/plan — Generate contextual business improvement actions.

Purpose:
  - Diagnose financial drivers (price, COGS, fixed costs)
  - Recommend incremental improvements with impact estimates
  - Provide execution roadmaps (effort, owners, KPIs)
  - Bridge CFO analysis to operational execution

Request schema (AdvicePlanRequest):
  - base: Financial context (revenue, costs, pricing)
  - goal: Strategy focus (grow_revenue | improve_margin | free_cash)
  - horizon_months: Planning horizon (1-36 months)
  - sector: Business sector (SAAS, retail, manufacturing, etc.)
  - price_elasticity: Demand elasticity coefficient (typical -0.8 to -1.6)

Response schema (AdvicePlanResponse):
  - summary: Narrative interpretation of plan
  - actions: List of AdviceAction with impact, effort, owners, steps, KPIs

Logic:
  - Normalizes context to consistent units
  - For each action: calculates iso-elastic demand impact, ROI delta
  - Returns actionable roadmap prioritized by effort/impact
  - Guards against edge cases (zero margins, negative COGS, etc.)

Use Cases:
  - Post-analysis tactical planning
  - Scenario testing (what if we reduce costs by 2%?)
  - Board-level summary of opportunities
  - Operational KPI setting
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import APIRouter
from pydantic import BaseModel, Field

from utils.coercion import safe_float

# Import tollerante: funziona sia se validators sta in core/ che in utils/
try:
    from core.validators import normalize_context_numeric  # tua versione attuale
except Exception:  # pragma: no cover
    from utils.validators import normalize_context_numeric  # se lo sposti

router = APIRouter(tags=["advice"])

# ---------- Schemi ----------
class AdvicePlanRequest(BaseModel):
    base: Dict[str, Any]
    goal: str = Field("grow_revenue", description="grow_revenue | improve_margin | free_cash")
    horizon_months: int = Field(6, ge=1, le=36)
    sector: Optional[str] = None
    price_elasticity: float = Field(-1.2, description="Elasticità domanda al prezzo (tipico -0.8..-1.6)")

    class Config:
        extra = "ignore"


class AdviceAction(BaseModel):
    code: str
    title: str
    impact_eur: float
    impact_roi_pct: float
    effort: str
    owners: List[str]
    steps: List[str]
    kpis: Dict[str, float]


class AdvicePlanResponse(BaseModel):
    summary: str
    actions: List[AdviceAction]


# ---------- Helper numerici ----------
def _round2(x: float) -> float:
    return round(float(x or 0.0), 2)


# Backward compatibility alias
_asf = safe_float

# NOTE: Commented out corrupted code - function definition was incomplete
# This was:
# def demand_elasticity_iso(q0, p0, p, eps):
#     """Domanda isoelastica: Q = Q0 * (p/p0)^ε..."""


def _round2(x: float) -> float:
    return round(float(x or 0.0), 2)


# ---------- Endpoint ----------
@router.post("/advice/plan", response_model=AdvicePlanResponse)
def advice_plan(req: AdvicePlanRequest):
    # 1) Normalizza il contesto (alias chiave, %, k/mln/mld…)
    b = normalize_context_numeric(req.base or {})

    # 2) Estrai basi pulite
    rev = _asf(b.get("fatturato") or b.get("sales"))
    cv = _asf(b.get("costi_variabili") or b.get("cogs"))
    cf = _asf(b.get("costi_fissi"))
    amm = _asf(b.get("ammortamenti"))
    invest = _asf(b.get("investimenti"))
    p0 = _asf(b.get("prezzo_medio"))
    cvu = _asf(b.get("costo_variabile_unitario"))
    dso = _asf(b.get("dso"))
    dio = _asf(b.get("dio"))
    dpo = _asf(b.get("dpo"))

    # 3) Profitto base semplice (senza tasse/interessi per coerenza con vecchia versione)
    utile0 = rev - cv - cf
    roi0 = (utile0 / invest * 100.0) if invest > 0 else 0.0

    actions: List[AdviceAction] = []

    # ---- Azione 1: Aumenta prezzo +2% (isoelastica) ----
    # Preconditions: prezzo>0, ricavi>0, cvu>=0 e cvu < prezzo (altrimenti BE irraggiungibile)
    if p0 > 0 and rev > 0 and cvu >= 0:
        q0 = rev / max(p0, 1e-9)
        p1 = p0 * 1.02
        # Se cvu supera p1, la marginalità diventa negativa → evitiamo di stimare verso l'alto
        if p1 > 0 and cvu < p1:
            q1 = _isoelastic_q(q0, p0, p1, req.price_elasticity)
            profit1 = q1 * (p1 - cvu) - cf
            delta = profit1 - utile0
            actions.append(AdviceAction(
                code="PRICE_UP_2",
                title="Aumenta il prezzo medio del 2%",
                impact_eur=_round2(delta),
                impact_roi_pct=_round2((delta / invest * 100.0) if invest > 0 else 0.0),
                effort="medio",
                owners=["Sales", "Marketing"],
                steps=[
                    "Segmenta clienti per sensibilità al prezzo",
                    "AB test su 2-3 listini (4-6 settimane)",
                    "Aggiorna listino e comunicazione"
                ],
                kpis={
                    # Δ MC-rate a parità di CVU
                    "mc_rate_delta_pp": _round2(((p1 - cvu) / p1 - (p0 - cvu) / p0) * 100.0) if p0 > 0 and p1 > 0 else 0.0
                }
            ))

    # ---- Azione 2: Riduci costi variabili -2% ----
    if cv > 0:
        delta_cv = 0.02 * cv  # riduzione di costo = beneficio su utile
        actions.append(AdviceAction(
            code="CVAR_DOWN_2",
            title="Riduci costi variabili del 2%",
            impact_eur=_round2(delta_cv),
            impact_roi_pct=_round2((delta_cv / invest * 100.0) if invest > 0 else 0.0),
            effort="medio",
            owners=["Procurement", "Ops"],
            steps=[
                "RFP fornitori top 3",
                "Standardizza ricette/processi",
                "Controllo scarti settimanale"
            ],
            kpis={"cv_delta_pct": -2.0}
        ))

    # ---- Azione 3: Riduci costi fissi -5% ----
    if cf > 0:
        delta_cf = 0.05 * cf  # taglio costi = beneficio su utile
        actions.append(AdviceAction(
            code="CFIX_DOWN_5",
            title="Riduci costi fissi del 5%",
            impact_eur=_round2(delta_cf),
            impact_roi_pct=_round2((delta_cf / invest * 100.0) if invest > 0 else 0.0),
            effort="medio",
            owners=["Finance", "HR"],
            steps=[
                "Audit voci CF",
                "Rinegozia 2 contratti principali",
                "Ottimizza turni/organico"
            ],
            kpis={"cf_delta_pct": -5.0}
        ))

    # ---- Azione 4: Migliora CCC → DSO -10gg (impatto su cassa, non su utile) ----
    if dso > 0 or dio > 0 or dpo > 0:
        ccc0 = dso + dio - dpo
        ccc1 = max(0.0, ccc0 - 10.0)
        # working capital approx = (COGS/365) * CCC
        wc0 = (cv / 365.0) * max(0.0, ccc0) if cv > 0 else 0.0
        wc1 = (cv / 365.0) * max(0.0, ccc1) if cv > 0 else 0.0
        delta_cash = wc0 - wc1  # cash liberata
        actions.append(AdviceAction(
            code="CCC_DSO10",
            title="Riduci DSO di 10 giorni",
            impact_eur=_round2(delta_cash),
            impact_roi_pct=0.0,  # su cassa, non utile
            effort="medio",
            owners=["AR", "Sales Ops"],
            steps=[
                "Sconti per incasso anticipato (2/10 net 30)",
                "Reminder automatici pre-scadenza",
                "Policy credito più rigorosa"
            ],
            kpis={"ccc_delta_days": -10.0}
        ))

    # ---- Azione 5: Crescita ricavi +8% (marketing + upsell) ----
    if rev > 0:
        delta_rev = 0.08 * rev
        # impatto utile ≈ delta_rev * MC-rate
        mc_rate = (rev - cv) / rev if rev > 0 else 0.0
        delta_profit = max(0.0, delta_rev * mc_rate)
        actions.append(AdviceAction(
            code="REV_UP_8",
            title="Piano crescita ricavi +8%",
            impact_eur=_round2(delta_profit),
            impact_roi_pct=_round2((delta_profit / invest * 100.0) if invest > 0 else 0.0),
            effort="alto",
            owners=["Marketing", "Sales"],
            steps=[
                "Campagne mirate su segmenti ad alta marginalità",
                "Upsell/cross-sell su clienti esistenti",
                "Ottimizza funnel e conversione"
            ],
            kpis={"revenue_delta_pct": 8.0}
        ))

    # 4) Summary coerente con goal & horizon
    goal_map = {
        "grow_revenue": "Crescita fatturato e quota margini",
        "improve_margin": "Espansione margini e disciplina costi",
        "free_cash": "Ottimizzazione capitale circolante e cassa",
    }
    goal_txt = goal_map.get(req.goal, "Miglioramento delle performance finanziarie")
    summary = f"{goal_txt}. Orizzonte: {int(req.horizon_months)} mesi. ROI baseline: { _round2(roi0) }%."

    # Ordina azioni per impatto € desc
    actions.sort(key=lambda a: a.impact_eur, reverse=True)
    return AdvicePlanResponse(summary=summary, actions=actions)
