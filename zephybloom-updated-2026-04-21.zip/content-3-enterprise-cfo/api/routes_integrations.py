"""
FASE 6 Integration API Routes

Expose external integrations (Xero, Stripe, HubSpot) via REST API.
Allows clients to:
- List registered integrations
- Authenticate with external services
- Sync data from all sources
- Query integration data
- Check health status
"""

from datetime import date, timedelta
from typing import Optional, List, Dict
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

from core.integrations_base import (
    IntegrationRegistry,
    get_integration_registry,
    IntegrationStatus,
)
from core.integrations_xero import XeroIntegration
from core.integrations_stripe import StripeIntegration
from core.integrations_hubspot import HubSpotIntegration
from core.integrations_base import IntegrationConfig


router = APIRouter(prefix="/api/integrations", tags=["integrations"])


# ============================================================================
# Request/Response Models
# ============================================================================

class IntegrationConfigRequest(BaseModel):
    """Request body for integration configuration"""
    api_key: str
    api_secret: Optional[str] = None
    tenant_id: Optional[str] = None
    base_url: Optional[str] = None
    timeout_seconds: Optional[int] = 30


class IntegrationStatusResponse(BaseModel):
    """Response for integration status"""
    name: str
    status: str
    error: Optional[str] = None
    last_sync: Optional[str] = None


class FinancialDataResponse(BaseModel):
    """Response for financial data from accounting integration"""
    source: str
    revenue_eur: int
    costs: Dict[str, int]
    profit_eur: int
    profit_margin_pct: float
    ebitda_eur: int


class TransactionDataResponse(BaseModel):
    """Response for transaction data from payment integration"""
    source: str
    period_days: int
    total_revenue_eur: int
    total_fees_eur: int
    total_refunds_eur: int
    success_rate_pct: float
    transaction_count: int


class CustomerMetricsResponse(BaseModel):
    """Response for customer metrics from CRM integration"""
    source: str
    total_customers: int
    active_customers: int
    mrr_eur: int
    arr_eur: int
    churn_rate_pct: float
    cac_eur: int
    ltv_eur: int


class CombinedDataResponse(BaseModel):
    """Combined data from all sources"""
    timestamp: str
    financial_data: Optional[Dict] = None
    transaction_data: Optional[Dict] = None
    customer_data: Optional[Dict] = None
    insights: Optional[List[str]] = None


# ============================================================================
# Endpoints
# ============================================================================

@router.get("/")
async def list_integrations() -> Dict:
    """
    List all registered integrations and their status.
    
    Returns:
        - integrations: List of integration names
        - count: Total count
        - statuses: Status for each integration
    """
    registry = get_integration_registry()
    names = registry.list_integrations()
    statuses = registry.get_status_all()
    
    return {
        "integrations": names,
        "count": len(names),
        "statuses": statuses,
    }


@router.post("/{integration_name}/register")
async def register_integration(
    integration_name: str,
    config: IntegrationConfigRequest,
) -> Dict:
    """
    Register/configure an external integration.
    
    Args:
        integration_name: "xero", "stripe", or "hubspot"
        config: API credentials and configuration
        
    Returns:
        - success: Boolean
        - message: Status message
        - integration: Integration details
    """
    registry = get_integration_registry()
    
    # Create integration config
    int_config = IntegrationConfig(
        api_key=config.api_key,
        api_secret=config.api_secret,
        tenant_id=config.tenant_id,
        base_url=config.base_url,
        timeout_seconds=config.timeout_seconds,
    )
    
    # Create appropriate integration
    if integration_name == "xero":
        integration = XeroIntegration(int_config)
    elif integration_name == "stripe":
        integration = StripeIntegration(int_config)
    elif integration_name == "hubspot":
        integration = HubSpotIntegration(int_config)
    else:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown integration: {integration_name}. Valid: xero, stripe, hubspot",
        )
    
    # Register
    registry.register(integration_name, integration)
    
    return {
        "success": True,
        "message": f"{integration_name} registered",
        "integration": {
            "name": integration_name,
            "status": integration.get_status().value,
        },
    }


@router.post("/{integration_name}/authenticate")
async def authenticate_integration(integration_name: str) -> Dict:
    """
    Authenticate with an external service.
    
    Args:
        integration_name: "xero", "stripe", or "hubspot"
        
    Returns:
        - success: Boolean
        - message: Status message
        - status: Current integration status
    """
    registry = get_integration_registry()
    
    integration = registry.get(integration_name)
    if not integration:
        raise HTTPException(
            status_code=404,
            detail=f"Integration not registered: {integration_name}",
        )
    
    result = integration.authenticate()
    
    return {
        "success": result.success,
        "message": result.data if result.success else result.error,
        "status": integration.get_status().value,
    }


@router.post("/sync")
async def sync_all_integrations() -> Dict:
    """
    Sync data from all registered integrations.
    
    Returns:
        - results: Dict with sync results per integration
        - timestamp: When sync occurred
        - success_count: How many synced successfully
    """
    registry = get_integration_registry()
    results = registry.sync_all()
    
    success_count = sum(
        1 for r in results.values() if r.get("success", False)
    )
    
    return {
        "results": results,
        "timestamp": date.today().isoformat(),
        "success_count": success_count,
        "total_count": len(results),
    }


@router.get("/xero/financial")
async def get_xero_financial_data(
    days: int = 30,
) -> FinancialDataResponse:
    """
    Get financial data from Xero.
    
    Args:
        days: Number of days to look back (default 30)
        
    Returns:
        FinancialDataResponse with P&L data
    """
    registry = get_integration_registry()
    xero = registry.get("xero")
    
    if not xero:
        raise HTTPException(status_code=404, detail="Xero not registered")
    
    xero.authenticate()
    
    end = date.today()
    start = end - timedelta(days=days)
    
    snapshot, error = xero.get_financial_snapshot(start, end)
    
    if not snapshot:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch financial data: {error}",
        )
    
    return FinancialDataResponse(
        source="xero",
        revenue_eur=snapshot.fatturato,
        costs={
            "cogs": snapshot.cogs,
            "opex": snapshot.opex,
        },
        profit_eur=snapshot.net_profit,
        profit_margin_pct=(
            (snapshot.net_profit / snapshot.fatturato * 100)
            if snapshot.fatturato > 0 else 0
        ),
        ebitda_eur=snapshot.ebitda,
    )


@router.get("/stripe/transactions")
async def get_stripe_transaction_data(
    days: int = 30,
) -> TransactionDataResponse:
    """
    Get transaction data from Stripe.
    
    Args:
        days: Number of days to look back (default 30)
        
    Returns:
        TransactionDataResponse with payment data
    """
    registry = get_integration_registry()
    stripe = registry.get("stripe")
    
    if not stripe:
        raise HTTPException(status_code=404, detail="Stripe not registered")
    
    stripe.authenticate()
    
    end = date.today()
    start = end - timedelta(days=days)
    
    data, error = stripe.get_transaction_data(start, end)
    
    if not data:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch transaction data: {error}",
        )
    
    return TransactionDataResponse(
        source="stripe",
        period_days=days,
        total_revenue_eur=data.total_revenue,
        total_fees_eur=data.fees,
        total_refunds_eur=data.refunds,
        success_rate_pct=data.successful_rate_pct,
        transaction_count=len(data.transactions) if data.transactions else 0,
    )


@router.get("/hubspot/customers")
async def get_hubspot_customer_metrics() -> CustomerMetricsResponse:
    """
    Get customer metrics from HubSpot.
    
    Returns:
        CustomerMetricsResponse with CRM data
    """
    registry = get_integration_registry()
    hubspot = registry.get("hubspot")
    
    if not hubspot:
        raise HTTPException(status_code=404, detail="HubSpot not registered")
    
    hubspot.authenticate()
    
    metrics, error = hubspot.get_customer_metrics()
    
    if not metrics:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch customer metrics: {error}",
        )
    
    return CustomerMetricsResponse(
        source="hubspot",
        total_customers=metrics.total_customers,
        active_customers=metrics.active_customers,
        mrr_eur=metrics.mrr,
        arr_eur=metrics.arr,
        churn_rate_pct=metrics.churn_rate_pct,
        cac_eur=metrics.cac,
        ltv_eur=metrics.ltv,
    )


@router.get("/combined")
async def get_combined_data() -> CombinedDataResponse:
    """
    Get combined data from all sources (Xero + Stripe + HubSpot).
    
    Returns:
        CombinedDataResponse with unified financial view
    """
    registry = get_integration_registry()
    
    financial_data = None
    transaction_data = None
    customer_data = None
    insights = []
    
    # Get financial data from Xero
    xero = registry.get("xero")
    if xero:
        xero.authenticate()
        end = date.today()
        start = end - timedelta(days=30)
        snapshot, _ = xero.get_financial_snapshot(start, end)
        if snapshot:
            financial_data = {
                "revenue": snapshot.fatturato,
                "profit": snapshot.net_profit,
                "margin": round(
                    (snapshot.net_profit / snapshot.fatturato * 100)
                    if snapshot.fatturato > 0 else 0,
                    1,
                ),
                "ebitda": snapshot.ebitda,
            }
    
    # Get transaction data from Stripe
    stripe = registry.get("stripe")
    if stripe:
        stripe.authenticate()
        end = date.today()
        start = end - timedelta(days=30)
        data, _ = stripe.get_transaction_data(start, end)
        if data:
            transaction_data = {
                "revenue": data.total_revenue,
                "fees_pct": data.fees / data.total_revenue * 100,
                "success_rate": data.successful_rate_pct,
            }
    
    # Get customer metrics from HubSpot
    hubspot = registry.get("hubspot")
    if hubspot:
        hubspot.authenticate()
        metrics, _ = hubspot.get_customer_metrics()
        if metrics:
            customer_data = {
                "customers": metrics.total_customers,
                "mrr": metrics.mrr,
                "arr": metrics.arr,
                "churn": metrics.churn_rate_pct,
                "ltv": metrics.ltv,
            }
    
    # Generate insights
    if financial_data and transaction_data:
        insights.append(
            f"Financial margin ({financial_data['margin']}%) has room for improvement"
        )
    
    if customer_data and customer_data["churn"] > 5:
        insights.append(
            f"Customer churn ({customer_data['churn']}%) is above target. Review retention."
        )
    
    if customer_data and financial_data:
        cac_to_ltv = (
            customer_data.get('ltv', 1) / 
            (financial_data['revenue'] / customer_data['customers'] 
             if customer_data['customers'] > 0 else 1)
        )
        if cac_to_ltv > 0.3:
            insights.append(
                "CAC to LTV ratio is healthy. Customer acquisition efficient."
            )
    
    return CombinedDataResponse(
        timestamp=date.today().isoformat(),
        financial_data=financial_data,
        transaction_data=transaction_data,
        customer_data=customer_data,
        insights=insights if insights else None,
    )


@router.get("/health")
async def health_check() -> Dict:
    """
    Health check for all integrations.
    
    Returns:
        - status: "healthy", "partial", or "unhealthy"
        - integrations: Status of each integration
        - timestamp: When check occurred
    """
    registry = get_integration_registry()
    statuses = registry.get_status_all()
    
    authenticated = sum(
        1 for s in statuses.values()
        if s == IntegrationStatus.AUTHENTICATED.value
    )
    
    total = len(statuses)
    
    if authenticated == total:
        status = "healthy"
    elif authenticated > 0:
        status = "partial"
    else:
        status = "unhealthy"
    
    return {
        "status": status,
        "integrations": statuses,
        "total": total,
        "authenticated": authenticated,
        "timestamp": date.today().isoformat(),
    }
