"""
Pydantic input validation schemas for all endpoints.

Centralized request/response validation with guardrails.
"""

from __future__ import annotations
from typing import Optional, Any, List, Dict
from datetime import datetime
from pydantic import BaseModel, Field, EmailStr, validator, field_validator

# ============================================
# Authentication Schemas
# ============================================

class UserRegisterRequest(BaseModel):
    """User registration request."""
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=255)
    full_name: str = Field(..., min_length=1, max_length=255)
    
    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        """Enforce password complexity."""
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserLoginRequest(BaseModel):
    """User login request."""
    email: EmailStr
    password: str


class UserLoginResponse(BaseModel):
    """Login response with JWT token."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    user_id: int
    tenant_id: str


class APIKeyCreateRequest(BaseModel):
    """Create new API key."""
    name: str = Field(..., min_length=1, max_length=255)
    rate_limit_per_minute: int = Field(default=100, ge=1, le=10000)
    expires_in_days: Optional[int] = Field(default=None, ge=1, le=3650)  # max 10 years


class APIKeyResponse(BaseModel):
    """API key response (plain key shown only once)."""
    id: int
    key: str  # Plain key - only shown once at creation
    name: str
    rate_limit_per_minute: int
    created_at: datetime
    expires_at: Optional[datetime]


# ============================================
# KPI Request/Response Schemas
# ============================================

class KPIContextInput(BaseModel):
    """Financial context for KPI computation."""
    fatturato: float = Field(default=0.0, ge=0)
    costi_variabili: float = Field(default=0.0, ge=0)
    costi_fissi: float = Field(default=0.0, ge=0)
    investimenti: float = Field(default=0.0, ge=0)
    prezzo: float = Field(default=0.0, gt=0)
    volume: float = Field(default=0.0, ge=0)
    sector: Optional[str] = Field(default="default", max_length=100)
    
    @field_validator("*")
    @classmethod
    def validate_numeric(cls, v: Any) -> float:
        """Ensure numeric fields are valid floats."""
        if v is None:
            return 0.0
        try:
            f = float(v)
            # Guard against NaN/Inf
            if not (-1e10 < f < 1e10):
                raise ValueError("Value out of reasonable range")
            return f
        except (TypeError, ValueError) as e:
            raise ValueError(f"Invalid numeric value: {e}")


class KPIRequest(BaseModel):
    """KPI computation request."""
    context: KPIContextInput
    tenant_id: Optional[str] = Field(default=None, max_length=128)


class KPIOutputMetrics(BaseModel):
    """Computed KPI metrics."""
    gross_margin: float
    net_margin: float
    roa: float
    roe: float
    current_ratio: float


class KPIResponse(BaseModel):
    """KPI computation response."""
    metrics: KPIOutputMetrics
    status: str = "ok"
    computed_at: datetime
    warnings: List[str] = Field(default_factory=list)


# ============================================
# Simulation Schemas
# ============================================

class SimulationDelta(BaseModel):
    """Delta assumptions for simulation."""
    fatturato_pct: float = Field(default=0.0, ge=-100, le=200)
    costi_variabili_pct: float = Field(default=0.0, ge=-100, le=200)
    costi_fissi_pct: float = Field(default=0.0, ge=-100, le=200)
    prezzo_pct: float = Field(default=0.0, ge=-100, le=200)


class SimulateRequest(BaseModel):
    """Scenario simulation request."""
    base: KPIContextInput
    delta: SimulationDelta
    scenario_name: Optional[str] = Field(default=None, max_length=255)
    tenant_id: Optional[str] = Field(default=None, max_length=128)


class SimulateResponse(BaseModel):
    """Simulation results."""
    scenario: str
    result: Dict[str, Any]
    delta_applied: SimulationDelta
    status: str = "ok"


# ============================================
# Valuation Schemas
# ============================================

class ValuationRequest(BaseModel):
    """Valuation request (DCF/NPV)."""
    cashflows: List[float] = Field(default_factory=list, max_length=50)
    discount_rate_pct: float = Field(default=10.0, ge=0, le=100)
    terminal_growth_pct: float = Field(default=2.0, ge=0, le=10)
    net_debt: float = Field(default=0.0, ge=0)
    dcf_fcf: Optional[List[float]] = Field(default=None, max_length=50)
    tenant_id: Optional[str] = Field(default=None, max_length=128)


class ValuationResponse(BaseModel):
    """Valuation results."""
    npv: Optional[float] = None
    irr: Optional[float] = None
    equity_value: Optional[float] = None
    enterprise_value: Optional[float] = None
    status: str = "ok"


# ============================================
# Chat/Conversational Schemas
# ============================================

class ChatMessage(BaseModel):
    """Single chat message."""
    role: str = Field(..., pattern="^(user|assistant)$")
    content: str = Field(..., min_length=1, max_length=5000)
    timestamp: Optional[datetime] = None


class ChatRequest(BaseModel):
    """Chat endpoint request."""
    session_id: Optional[str] = Field(default=None, max_length=128)
    message: str = Field(..., min_length=1, max_length=5000)
    context: Optional[KPIContextInput] = None
    tenant_id: Optional[str] = Field(default=None, max_length=128)
    system_prompt: Optional[str] = Field(default=None, max_length=2000)


class ChatResponse(BaseModel):
    """Chat endpoint response."""
    session_id: str
    role: str = "assistant"
    content: str
    intent: Optional[str] = None
    timestamp: datetime


# ============================================
# Health Check Schemas
# ============================================

class ComponentHealth(BaseModel):
    """Single component health status."""
    status: str = Field(..., pattern="^(healthy|degraded|unhealthy)$")
    latency_ms: Optional[int] = None
    description: Optional[str] = None


class HealthResponse(BaseModel):
    """Full health check response."""
    status: str = Field(..., pattern="^(healthy|degraded|unhealthy)$")
    timestamp: datetime
    version: str
    components: Dict[str, ComponentHealth]
    uptime_seconds: int
    requests_processed: int


# ============================================
# Error Response Schemas
# ============================================

class ErrorDetail(BaseModel):
    """Error detail in response."""
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class ErrorResponse(BaseModel):
    """Standard error response."""
    error: ErrorDetail
    request_id: Optional[str] = None
    timestamp: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "error": {
                    "code": "CALCULATION_ERROR",
                    "message": "Division by zero in KPI computation",
                    "details": {"field": "denominator"}
                },
                "request_id": "req-123456",
                "timestamp": "2026-04-14T18:30:00Z"
            }
        }


# ============================================
# Pagination Schemas
# ============================================

class PaginationParams(BaseModel):
    """Pagination parameters."""
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=1000)
    sort_by: Optional[str] = Field(default=None, max_length=100)
    sort_order: str = Field(default="asc", pattern="^(asc|desc)$")


class PaginatedResponse(BaseModel):
    """Paginated response wrapper."""
    items: List[Dict[str, Any]]
    total: int
    page: int
    page_size: int
    total_pages: int
