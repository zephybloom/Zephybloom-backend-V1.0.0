# content/api/security.py
from __future__ import annotations

import time
import threading
from typing import Any, Dict, Optional

from fastapi import HTTPException, status
from api.config import settings

try:
    import jwt  # type: ignore
except Exception:
    jwt = None  # type: ignore


# =========================
# In-memory rate limit
# =========================

_BUCKETS: Dict[str, Dict[str, Any]] = {}
_BUCKETS_LOCK = threading.Lock()
_MAX_TENANT_LEN = 120


def _now_ts() -> int:
    return int(time.time())


def _normalize_tenant_id(tenant_id: Optional[str]) -> str:
    try:
        tid = str(tenant_id or "default").strip()
    except Exception:
        return "default"

    if not tid:
        return "default"

    return tid[:_MAX_TENANT_LEN]


def _cleanup_expired_buckets(window_s: int, now: Optional[int] = None) -> None:
    """
    Pulisce bucket molto vecchi per evitare crescita infinita in memoria.
    Mantiene una retention morbida di 3 finestre.
    """
    try:
        now_ts = int(now if now is not None else _now_ts())
        ttl = max(1, int(window_s)) * 3
    except Exception:
        return

    to_delete = []
    for tid, bucket in _BUCKETS.items():
        try:
            start = int(bucket.get("start", now_ts))
            if now_ts - start >= ttl:
                to_delete.append(tid)
        except Exception:
            to_delete.append(tid)

    for tid in to_delete:
        _BUCKETS.pop(tid, None)


# =========================
# JWT
# =========================

def _parse_bearer_token(authorization: Optional[str]) -> Optional[str]:
    """
    Estrae il token da:
      Authorization: Bearer <token>

    Ritorna:
    - None se header assente/vuoto
    - token se valido
    - solleva 401 se formato errato
    """
    if authorization is None:
        return None

    try:
        auth = str(authorization).strip()
    except Exception:
        return None

    if not auth:
        return None

    parts = auth.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header must use Bearer token",
        )

    token = parts[1].strip()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing bearer token",
        )

    return token


def verify_jwt(authorization: Optional[str]) -> Dict[str, Any]:
    """
    Supporta:
      Authorization: Bearer <token>

    Comportamento:
    - se Authorization manca -> accetta (auth opzionale a livello middleware/app)
    - se header non è Bearer -> 401
    - se PyJWT o JWT_SECRET non sono configurati -> dev mode, accetta token Bearer come fittizio
    - se JWT è attivo -> valida HS256

    Config:
    - ZB_JWT_SECRET
    - ZB_JWT_REQUIRED=true/false

    Ritorna payload decoded oppure dict dev.
    """
    token = _parse_bearer_token(authorization)
    if token is None:
        return {}

    secret = str(getattr(settings, "JWT_SECRET", "") or "").strip()
    jwt_required = bool(getattr(settings, "JWT_REQUIRED", False))

    # Dev mode: libreria jwt o secret non presenti
    if jwt is None or not secret:
        if jwt_required:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="JWT verification is required but not configured",
            )
        return {
            "sub": "dev",
            "scope": "all",
            "auth_mode": "dev",
        }

    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )

    if not isinstance(payload, dict):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    return payload


# =========================
# Rate limit
# =========================

def rate_limit(tenant_id: str, limit: int = 120, window_s: int = 60) -> Dict[str, Any]:
    """
    Ultra-light in-memory rate limit per tenant.

    Logica:
    - contatore per finestra fissa
    - reset allo scadere della finestra
    - pulizia bucket vecchi
    - thread-safe tramite lock

    Ritorna info diagnostiche:
      {
        "tenant_id": ...,
        "limit": ...,
        "remaining": ...,
        "reset_in_s": ...
      }
    """
    tid = _normalize_tenant_id(tenant_id)

    try:
        limit = max(1, int(limit))
    except Exception:
        limit = 120

    try:
        window_s = max(1, int(window_s))
    except Exception:
        window_s = 60

    now = _now_ts()

    with _BUCKETS_LOCK:
        _cleanup_expired_buckets(window_s=window_s, now=now)

        bucket = _BUCKETS.get(tid)
        if not isinstance(bucket, dict):
            bucket = {"start": now, "count": 0}
            _BUCKETS[tid] = bucket

        try:
            start = int(bucket.get("start", now))
            count = int(bucket.get("count", 0))
        except Exception:
            start = now
            count = 0
            bucket["start"] = start
            bucket["count"] = count

        elapsed = max(0, now - start)

        if elapsed >= window_s:
            start = now
            count = 0
            bucket["start"] = start
            bucket["count"] = count
            elapsed = 0

        count += 1
        bucket["count"] = count

        reset_in_s = max(0, window_s - elapsed)
        remaining = max(0, limit - count)

        if count > limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Rate limit exceeded",
            )

        return {
            "tenant_id": tid,
            "limit": limit,
            "remaining": remaining,
            "reset_in_s": reset_in_s,
        }


def reset_rate_limit_bucket(tenant_id: str) -> Dict[str, Any]:
    """
    Utility utile per test/debug.
    """
    tid = _normalize_tenant_id(tenant_id)
    with _BUCKETS_LOCK:
        existed = tid in _BUCKETS
        _BUCKETS.pop(tid, None)
    return {
        "tenant_id": tid,
        "reset": True,
        "existed": existed,
    }


def get_rate_limit_bucket(tenant_id: str) -> Dict[str, Any]:
    """
    Utility diagnostica per test/debug.
    """
    tid = _normalize_tenant_id(tenant_id)
    now = _now_ts()

    with _BUCKETS_LOCK:
        bucket = _BUCKETS.get(tid)
        if not isinstance(bucket, dict):
            return {
                "tenant_id": tid,
                "start": None,
                "count": 0,
                "age_s": 0,
            }

        try:
            start = int(bucket.get("start", now))
        except Exception:
            start = now

        try:
            count = int(bucket.get("count", 0))
        except Exception:
            count = 0

        return {
            "tenant_id": tid,
            "start": start,
            "count": count,
            "age_s": max(0, now - start),
        }
