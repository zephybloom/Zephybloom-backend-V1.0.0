# -*- coding: utf-8 -*-
# content/api/routes_opportunities.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import OpportunitiesRequest
from core.opportunities import opportunities

router = APIRouter()

@router.post("/opportunities")
def opportunities_route(req: OpportunitiesRequest):
    items = opportunities(req.base, sector=req.sector, price_elasticity=float(req.price_elasticity or -1.2))
    return {"top_opportunities": items}
