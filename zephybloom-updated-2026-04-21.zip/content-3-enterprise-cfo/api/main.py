# -*- coding: utf-8 -*-
"""
ZephyBloom LLM CFO API – CANONICAL ENTRY POINT

This is the main FastAPI application used by launcher.py and production deployments.

Features:
  - All routers mounted: core, chat, advice, ext, knowledge
  - Complete middleware stack: CORS, RequestID, Body limit, ApiKey auth
  - Security: Optional JWT + Rate limiting per tenant
  - Tenancy support: Multi-tenant isolation via headers and route context
  - Route deduplication: Keeps single version of /whatif/breakeven

Entry point for:
  - launcher.py (uvicorn server)
  - Docker/production deployments
  - Development server

Configuration via environment variables (api/config.py):
  - ZB_LLM_PROVIDER, ZB_OPENAI_API_KEY
  - JWT_SECRET, JWT_REQUIRED
  - RATE_LIMIT_PER_TENANT
  - CORS_ORIGINS, APP_API_KEY
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

from api.config import settings
from utils.logging_utils import (
    configure_root_logging,
    bind_context,
    clear_context,
    get_logger,
)
from api.deps import ContextVarsMiddleware, register_exception_handlers
from api.middleware_ratelimit import RateLimitMiddleware
from db.session import init_session_factory
from api.rate_limiter import init_rate_limiter

# Caching and optimization
from infra.cache_decorator import init_cache
from infra.circuit_breaker import get_breaker
from infra.metrics import get_metrics_endpoint

# Routers
from api.routes_core import router as core_router
# from api.routes_chat import router as chat_router  # TEMP: Disabled - intelligent_questions.py has syntax error
from api.routes_advice import router as advice_router
from api.routes_ext import router as ext_router
from api.routes_knowledge import router as knowledge_router
from api.routes_auth import router as auth_router
from api.routes_cfo import router as cfo_router
from api.routes_cfo_advanced import router as cfo_advanced_router
from api.routes_cfo_strategy import router as cfo_strategy_router
from api.routes_decision import router as decision_router
from api.routes_feedback import router as feedback_router
from api.routes_integrations import router as integrations_router
from api.routes_onboarding import router as onboarding_router

# Security / Tenancy
from api.security import verify_jwt, rate_limit
from infra.tenancy import get_tenant_id

log = get_logger("api.main")


# =========================
# Helpers
# =========================
def _safe_int(v: Any, default: int) -> int:
    try:
        return int(v)
    except Exception:
        return int(default)


def _safe_bool(v: Any, default: bool = False) -> bool:
    try:
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.strip().lower() in {"1", "true", "yes", "y", "on"}
        return bool(v)
    except Exception:
        return default


def _safe_str(v: Any, default: str = "") -> str:
    try:
        s = str(v).strip()
        return s if s else default
    except Exception:
        return default


def _resolve_tenant_id(request: Request, fallback: str = "default") -> str:
    """
    Risoluzione tenant robusta:
    1. header X-Tenant-Id
    2. query param tenant_id
    3. helper get_tenant_id(request)
    4. fallback
    """
    try:
        hdr = request.headers.get("X-Tenant-Id")
        if hdr and str(hdr).strip():
            return str(hdr).strip()
    except Exception:
        pass

    try:
        qp = request.query_params.get("tenant_id")
        if qp and str(qp).strip():
            return str(qp).strip()
    except Exception:
        pass

    try:
        tid = get_tenant_id(request)
        if tid is not None:
            tid_str = str(tid).strip()
            if tid_str:
                return tid_str
    except Exception:
        pass

    return fallback


# =========================
# Route dedupe
# =========================
def _ensure_canonical_breakeven_route(app: FastAPI) -> None:
    """Mantiene una sola rotta POST /whatif/breakeven, preferendo quella di routes_core."""
    try:
        be_candidates = []
        for r in list(app.router.routes):
            path = getattr(r, "path", None)
            methods = set(getattr(r, "methods", []) or [])
            if path == "/whatif/breakeven" and "POST" in methods:
                endpoint = getattr(r, "endpoint", None)
                mod = getattr(endpoint, "__module__", "")
                qual = getattr(endpoint, "__qualname__", "")
                be_candidates.append((r, mod, qual))

        if len(be_candidates) <= 1:
            return

        core_route = None
        for r, mod, qual in be_candidates:
            if mod.startswith("content.api.routes_core"):
                core_route = r
                break

        if core_route is not None:
            for r, mod, qual in be_candidates:
                if r is not core_route:
                    try:
                        app.router.routes.remove(r)
                        log.info(
                            "Removed duplicate /whatif/breakeven route",
                            module=mod,
                            endpoint=qual,
                        )
                    except Exception:
                        pass
        else:
            keep = be_candidates[0][0]
            for r, mod, qual in be_candidates[1:]:
                try:
                    app.router.routes.remove(r)
                    log.info(
                        "Removed duplicate /whatif/breakeven route (kept first)",
                        module=mod,
                        endpoint=qual,
                    )
                except Exception:
                    pass

    except Exception as e:
        try:
            log.warning("Dedupe routes failed", error=str(e))
        except Exception:
            pass


# =========================
# Middlewares
# =========================
class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        rid_header = getattr(settings, "REQUEST_ID_HEADER", "X-Request-ID")
        req_id = request.headers.get(rid_header) or request.headers.get("X-Request-Id") or "-"
        user_id = request.headers.get("X-User-Id") or "-"
        path = request.url.path

        bind_context(request_id=req_id, user_id=user_id, route=path)
        try:
            response = await call_next(request)
            if req_id and req_id != "-":
                response.headers[rid_header] = req_id
            return response
        finally:
            clear_context()


class MaxBodySizeMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        cl = request.headers.get("content-length")
        max_bytes = _safe_int(getattr(settings, "REQUEST_MAX_BYTES", 1_000_000), 1_000_000)

        try:
            if cl and int(cl) > max_bytes:
                return JSONResponse({"detail": "Payload too large"}, status_code=413)
        except Exception:
            pass

        return await call_next(request)


class ApiKeyAuthMiddleware(BaseHTTPMiddleware):
    """
    API Key globale: usa APP_API_KEY se presente; bypass se vuota.
    Nota: /__routes__ NON è in allowlist, quindi resta protetta.
    """

    ALLOWLIST = {
        "/health",
        "/docs",
        "/openapi.json",
        "/metrics",
        "/_selftest",
        "/_whoami_chat",
        "/whoami",
        "/ui",
        "/ui/",
    }

    async def dispatch(self, request: Request, call_next):
        app_key = getattr(settings, "APP_API_KEY", None) or getattr(settings, "app_api_key", None)
        if not app_key:
            return await call_next(request)

        path = request.url.path
        if path in self.ALLOWLIST or path.startswith("/ui"):
            return await call_next(request)

        header_key = request.headers.get("x-api-key") or request.headers.get("X-API-KEY")
        query_key = request.query_params.get("api_key")

        if header_key == app_key or query_key == app_key:
            return await call_next(request)

        return JSONResponse({"detail": "Invalid API key"}, status_code=401)


class SecurityMiddleware(BaseHTTPMiddleware):
    """
    JWT + Rate limit opzionali.
    - Se JWT_SECRET non è configurato, verify_jwt accetta in dev mode.
    - Rate limit per tenant.
    """

    BYPASS_PATHS = {
        "/health",
        "/docs",
        "/openapi.json",
        "/metrics",
        "/_selftest",
        "/whoami",
    }

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        if path in self.BYPASS_PATHS or path.startswith("/ui"):
            return await call_next(request)

        auth = request.headers.get("Authorization")
        verify_jwt(auth)

        tenant_id = _resolve_tenant_id(request, fallback="default")

        rate_limit(
            str(tenant_id),
            limit=_safe_int(getattr(settings, "RATE_LIMIT_PER_TENANT", 120), 120),
            window_s=_safe_int(getattr(settings, "RATE_LIMIT_WINDOW_S", 60), 60),
        )

        return await call_next(request)


class BreakevenSchemaFilter(BaseHTTPMiddleware):
    """
    Filtra la risposta di POST /whatif/breakeven per rimuovere chiavi extra.
    Tiene solo: be_qty, be_revenue, mc_rate.
    """

    def __init__(self, app, allowed_keys=None):
        super().__init__(app)
        self.allowed = set(allowed_keys or ["be_qty", "be_revenue", "mc_rate"])

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        try:
            if request.method.upper() != "POST" or request.url.path != "/whatif/breakeven":
                return response

            if response.status_code != 200:
                return response

            chunks = []
            async for section in response.body_iterator:
                chunks.append(section)

            body_bytes = b"".join(chunks)
            data = json.loads(body_bytes.decode("utf-8"))

            if isinstance(data, dict):
                filtered = {k: data.get(k) for k in self.allowed}
                for k in ("be_qty", "be_revenue", "mc_rate"):
                    filtered.setdefault(k, None)
                return JSONResponse(filtered, status_code=response.status_code)

            return Response(
                content=body_bytes,
                status_code=response.status_code,
                media_type=getattr(response, "media_type", "application/json"),
                headers=dict(response.headers),
            )

        except Exception:
            return response


# =========================
# App factory
# =========================
def create_app() -> FastAPI:
    app = FastAPI(
        title="LLM CFO API",
        version="1.3",
    )

    try:
        configure_root_logging()
    except Exception:
        pass

    # --------- Startup events -----------
    @app.on_event("startup")
    async def startup():
        """Initialize database, cache, and rate limiter on startup."""
        try:
            init_session_factory()
            log.info("Database session factory initialized")
        except Exception as e:
            log.error("Failed to initialize database", error=str(e))

        try:
            redis_url = getattr(settings, 'REDIS_URL', None)
            init_rate_limiter(redis_url)
            log.info("Rate limiter initialized")
        except Exception as e:
            log.error("Failed to initialize rate limiter", error=str(e))
        
        # Initialize cache
        try:
            if getattr(settings, "CACHE_ENABLED", True):
                redis_url = getattr(settings, 'REDIS_URL', None)
                init_cache(redis_url)
                log.info("Cache initialized")
        except Exception as e:
            log.warning("Cache initialization failed", error=str(e))
        
        # Initialize circuit breakers
        try:
            if getattr(settings, "CIRCUIT_BREAKER_ENABLED", True):
                llm_fail_max = getattr(settings, "CIRCUIT_BREAKER_LLM_FAIL_MAX", 5)
                llm_timeout = getattr(settings, "CIRCUIT_BREAKER_LLM_RESET_TIMEOUT", 60)
                get_breaker("llm_calls", fail_max=llm_fail_max, reset_timeout=llm_timeout)
                
                db_fail_max = getattr(settings, "CIRCUIT_BREAKER_DB_FAIL_MAX", 3)
                db_timeout = getattr(settings, "CIRCUIT_BREAKER_DB_RESET_TIMEOUT", 30)
                get_breaker("db_calls", fail_max=db_fail_max, reset_timeout=db_timeout)
                
                log.info("Circuit breakers initialized")
        except Exception as e:
            log.warning("Circuit breaker initialization failed", error=str(e))

    @app.on_event("shutdown")
    async def shutdown():
        """Cleanup on shutdown."""
        try:
            log.info("API shutting down")
        except Exception:
            pass

    # Helper to parse CORS CSV strings
    def _parse_cors_csv(value, default=None) -> list:
        """Parse CORS value from CSV string"""
        if default is None:
            default = ["*"]
        if not value:
            return default
        if isinstance(value, (list, tuple, set)):
            return [str(x).strip() for x in value if str(x).strip()]
        return [x.strip() for x in str(value).split(",") if x.strip()]
    
    # Helper to parse single CORS field
    def _get_cors_field(field_name: str, default=None):
        """Get CORS field and parse as CSV"""
        if default is None:
            default = ["*"]
        val = getattr(settings, field_name, None)
        if val is None:
            return default
        return _parse_cors_csv(val, default)

    # ----------------- CORS -----------------
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_get_cors_field("CORS_ORIGINS", ["*"]),
        allow_origin_regex=getattr(settings, "CORS_ORIGIN_REGEX", None),
        allow_credentials=_safe_bool(getattr(settings, "CORS_ALLOW_CREDENTIALS", True), True),
        allow_methods=_get_cors_field("CORS_METHODS", ["*"]),
        allow_headers=_get_cors_field("CORS_HEADERS", ["*"]),
        expose_headers=_get_cors_field("CORS_EXPOSE_HEADERS", []),
        max_age=_safe_int(getattr(settings, "CORS_MAX_AGE", 600), 600),
    )

    # ------------- Context vars -------------
    try:
        app.add_middleware(ContextVarsMiddleware)
    except Exception:
        pass

    app.add_middleware(RequestContextMiddleware)
    app.add_middleware(MaxBodySizeMiddleware)
    app.add_middleware(ApiKeyAuthMiddleware)
    app.add_middleware(SecurityMiddleware)
    app.add_middleware(RateLimitMiddleware)

    # --------- Exception handlers -----------
    try:
        register_exception_handlers(app)
    except Exception:
        pass

    # ------------- Endpoints base -----------
    @app.get("/health")
    def health():
        return {"status": "healthy", "version": app.version}

    @app.get("/metrics")
    def metrics():
        """Prometheus metrics endpoint."""
        content, content_type = get_metrics_endpoint()
        return Response(content=content, media_type=content_type)

    @app.get("/_selftest")
    def selftest():
        summary = {}
        safe_dict = {}

        try:
            summary = settings.summary() if hasattr(settings, "summary") else {}
        except Exception:
            summary = {}

        try:
            safe_dict = settings.safe_dict() if hasattr(settings, "safe_dict") else {}
        except Exception:
            safe_dict = {}

        return {
            "summary": summary,
            "config": safe_dict,
            "openai_key_present": bool(getattr(settings, "OPENAI_API_KEY", None)),
            "llm_provider": getattr(settings, "LLM_PROVIDER", None),
            "demo_mode": getattr(settings, "DEMO_MODE", None),
            "test_mode": getattr(settings, "TEST_MODE", None),
        }

    @app.get("/whoami")
    def whoami(request: Request):
        rid = request.headers.get(getattr(settings, "REQUEST_ID_HEADER", "X-Request-ID"), "-")
        return {
            "request_id": rid,
            "client": request.client.host if request.client else "-",
            "path": request.url.path,
        }

    # ------------- Routers ------------------
    app.include_router(auth_router)
    # app.include_router(chat_router)  # TEMP: Disabled - intelligent_questions.py has syntax error
    app.include_router(core_router)
    app.include_router(ext_router)
    app.include_router(knowledge_router)
    app.include_router(advice_router)
    app.include_router(cfo_router)
    app.include_router(cfo_advanced_router)
    app.include_router(cfo_strategy_router)
    app.include_router(decision_router)
    app.include_router(feedback_router)
    app.include_router(integrations_router)
    app.include_router(onboarding_router)

    _ensure_canonical_breakeven_route(app)

    # ------------- Diagnostica --------------
    @app.get("/__routes__")
    def list_routes() -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for r in app.router.routes:
            methods = sorted(list(getattr(r, "methods", []) or []))
            endpoint = getattr(r, "endpoint", None)
            out.append(
                {
                    "path": getattr(r, "path", ""),
                    "methods": methods,
                    "module": getattr(endpoint, "__module__", ""),
                    "endpoint": getattr(endpoint, "__qualname__", ""),
                }
            )
        return out

    # Filtro schema a valle
    app.add_middleware(BreakevenSchemaFilter)

    # ------------- Gradio (opzionale) -------
    try:
        from gradio import mount_gradio_app
        from frontend.gradio import create_demo

        ui_path = getattr(settings, "UI_PATH", os.getenv("ZB_UI_PATH", "/ui")) or "/ui"
        ui_path = _safe_str(ui_path, "/ui")
        if not ui_path.startswith("/"):
            ui_path = "/" + ui_path

        backend_base_url = getattr(settings, "BACKEND_BASE_URL", "http://127.0.0.1:8000")
        demo = create_demo(backend_base_url)
        app = mount_gradio_app(app, demo, path=ui_path)
    except Exception as e:
        try:
            log.warning("Gradio mount skipped", error=str(e))
        except Exception:
            pass

    try:
        log.info(
            "API started",
            env=getattr(settings, "ENV", "unknown"),
            provider=getattr(settings, "LLM_PROVIDER", "unknown"),
            model=getattr(settings, "LLM_MODEL", "unknown"),
        )
    except Exception:
        pass

    return app


# Espone l'app per uvicorn: uvicorn content.api.main:app --reload
app = create_app()
