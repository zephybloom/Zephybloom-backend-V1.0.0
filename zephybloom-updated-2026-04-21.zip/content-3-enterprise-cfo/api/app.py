# -*- coding: utf-8 -*-
"""
DEPRECATED: Use content.api.main instead.

This module contains a simplified FastAPI factory for basic use cases.
For production and full-feature deployment, use content.api.main which includes:
- All routers (core, chat, advice, ext, knowledge)
- Complete middleware stack
- Security integration (JWT, rate limiting)
- Tenancy support
- Route deduplication

Kept for backward compatibility and testing purposes.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from api.config import settings
from api.deps import ContextVarsMiddleware, register_exception_handlers
from utils.logging_utils import bind_context, clear_context, get_logger

# Routers
from api.routes_chat import router as chat_router

log = get_logger("api.app")


def create_app() -> FastAPI:
    app = FastAPI(title="LLM CFO API", version="1.3")

    # --- CORS (valori già compatibili via alias in settings) -----------------
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_origin_regex=settings.CORS_ORIGIN_REGEX,
        allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
        allow_methods=settings.CORS_METHODS or ["*"],
        allow_headers=settings.CORS_HEADERS or ["*"],
        expose_headers=settings.CORS_EXPOSE_HEADERS or [],
        max_age=settings.CORS_MAX_AGE,
    )

    # --- Context vars (se esiste il middleware dedicato) ---------------------
    try:
        app.add_middleware(ContextVarsMiddleware)
    except Exception:
        pass

    # --- Request ID + logging context ----------------------------------------
    class RequestContextMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            try:
                rid_header = settings.REQUEST_ID_HEADER or "X-Request-ID"
            except Exception:
                rid_header = "X-Request-ID"
            req_id = request.headers.get(rid_header) or request.headers.get("X-Request-Id") or "-"
            user_id = request.headers.get("X-User-Id") or "-"
            path = request.url.path

            bind_context(request_id=req_id, route=path, user_id=user_id)
            try:
                response = await call_next(request)
                return response
            finally:
                # evita leakage tra richieste
                clear_context()

    app.add_middleware(RequestContextMiddleware)

    # --- Body limit ----------------------------------------------------------
    class MaxBodySizeMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            cl = request.headers.get("content-length")
            try:
                max_bytes = int(getattr(settings, "REQUEST_MAX_BYTES", 1_000_000))
            except Exception:
                max_bytes = 1_000_000
            if cl and int(cl) > max_bytes:
                return JSONResponse({"detail": "Payload too large"}, status_code=413)
            return await call_next(request)

    app.add_middleware(MaxBodySizeMiddleware)

    # --- API key globale (facoltativa) ---------------------------------------
    class ApiKeyAuthMiddleware(BaseHTTPMiddleware):
        ALLOWLIST = {
            "/health",
            "/docs",
            "/openapi.json",
            "/metrics",
            "/_selftest",
            "/_whoami_chat",
            "/whoami",
        }

        async def dispatch(self, request: Request, call_next):
            app_key = getattr(settings, "APP_API_KEY", None)
            if not app_key:
                return await call_next(request)

            path = request.url.path
            if path in self.ALLOWLIST or path.startswith("/ui"):
                return await call_next(request)

            # header o query string per test veloci
            header_key = request.headers.get("x-api-key")
            query_key = request.query_params.get("api_key")
            if header_key == app_key or query_key == app_key:
                return await call_next(request)

            return JSONResponse({"detail": "Invalid API key"}, status_code=401)

    app.add_middleware(ApiKeyAuthMiddleware)

    # --- Error handlers ------------------------------------------------------
    try:
        register_exception_handlers(app)
    except Exception:
        pass

    # --- Endpoints base ------------------------------------------------------
    @app.get("/health")
    def health():
        return {"status": "ok", "version": app.version}

    @app.get("/_selftest")
    def selftest():
        return {
            "summary": settings.summary(),
            "config": settings.safe_dict(),
            "openai_key_present": bool(getattr(settings, "OPENAI_API_KEY", None)),
            "llm_provider": settings.LLM_PROVIDER,
            "demo_mode": settings.DEMO_MODE,
            "test_mode": settings.TEST_MODE,
        }

    @app.get("/whoami")
    def whoami(request: Request):
        rid = request.headers.get(settings.REQUEST_ID_HEADER, "-")
        return {
            "request_id": rid,
            "client": request.client.host if request.client else "-",
            "path": request.url.path,
        }

    # --- Routers -------------------------------------------------------------
    app.include_router(chat_router)
    # app.include_router(kpi_router)
    # app.include_router(sim_router)
    # app.include_router(rag_router)
    # app.include_router(opt_router)
    # app.include_router(val_router)

    log.info("API started", env=settings.ENV, model=settings.LLM_MODEL, provider=settings.LLM_PROVIDER)
    return app


# istanza usata da Uvicorn / launcher
app = create_app()
