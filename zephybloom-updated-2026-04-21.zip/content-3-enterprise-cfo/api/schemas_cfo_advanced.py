"""
CFO Advanced Schemas - Enterprise analytics with historicals and segmentation

Support for:
- Time series data (annual/quarterly/monthly KPIs)
- Revenue breakdown by segment/product line
- Customer concentration data
- Benchmarking against competitors
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Literal
from enum import Enum
from datetime import date


# ============================================
# ENUMS
# ============================================

class PeriodType(str, Enum):
    """Time period type"""
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUAL = "annual"


class SegmentType(str, Enum):
    """Revenue segment type"""
    PRODUCT_LINE = "product_line"
    CUSTOMER_SEGMENT = "customer_segment"
    GEOGRAPHY = "geography"
    VERTICAL = "vertical"
    CHANNEL = "channel"


# ============================================
# TIME SERIES
# ============================================

class KPIHistorical(BaseModel):
    """Single period KPI snapshot"""
    
    period_date: date = Field(..., description="Period end date (YYYY-MM-DD)")
    period_type: PeriodType = Field(default=PeriodType.ANNUAL, description="Period granularity")
    
    # Income statement
    fatturato: float = Field(ge=0, description="Revenue")
    costi_variabili: float = Field(ge=0, description="Variable costs")
    costi_fissi: float = Field(ge=0, description="Fixed costs")
    ebitda: Optional[float] = Field(default=None, description="EBITDA")
    
    # Balance sheet (snapshot)
    total_assets: Optional[float] = Field(default=None, ge=0, description="Total assets")
    total_liabilities: Optional[float] = Field(default=None, ge=0, description="Total liabilities")
    equity: Optional[float] = Field(default=None, ge=0, description="Shareholders' equity")
    
    # Cash/WC
    cash: Optional[float] = Field(default=None, ge=0, description="Cash & equivalents")
    working_capital: Optional[float] = Field(default=None, description="Working capital")
    
    # Headcount (for unit economics)
    headcount: Optional[int] = Field(default=None, ge=0, description="Number of employees")
    
    class Config:
        example = {
            "period_date": "2025-12-31",
            "period_type": "annual",
            "fatturato": 5000000,
            "costi_variabili": 2000000,
            "costi_fissi": 1500000,
            "ebitda": 1500000,
            "total_assets": 3000000,
            "equity": 1500000,
            "cash": 500000,
            "headcount": 25
        }


# ============================================
# SEGMENTATION
# ============================================

class RevenueSegment(BaseModel):
    """Revenue breakdown by dimension"""
    
    segment_type: SegmentType = Field(..., description="Type of segmentation")
    segment_name: str = Field(..., min_length=1, description="Segment name (e.g., 'Premium', 'US', 'SaaS')")
    
    # Revenue & margin
    fatturato: float = Field(..., ge=0, description="Segment revenue")
    margin_pct: Optional[float] = Field(default=None, ge=0, le=100, description="Segment margin %")
    
    # Growth & trend
    growth_yoy_pct: Optional[float] = Field(default=None, description="YoY growth % (can be negative)")
    proportion_of_total_pct: Optional[float] = Field(default=None, ge=0, le=100, description="% of total revenue")
    
    # Customer metrics (if applicable)
    num_customers: Optional[int] = Field(default=None, ge=0, description="Number of customers in segment")
    churn_rate_pct: Optional[float] = Field(default=None, ge=0, le=100, description="Monthly/annual churn %")
    avg_customer_value_eur: Optional[float] = Field(default=None, ge=0, description="Average customer LTV")
    
    class Config:
        example = {
            "segment_type": "customer_segment",
            "segment_name": "Enterprise",
            "fatturato": 2000000,
            "margin_pct": 65.0,
            "growth_yoy_pct": 25.0,
            "proportion_of_total_pct": 40.0,
            "num_customers": 5,
            "churn_rate_pct": 2.0,
            "avg_customer_value_eur": 400000
        }


class CustomerConcentration(BaseModel):
    """Customer concentration metrics"""
    
    total_customers: int = Field(..., ge=1, description="Total number of customers")
    top_10_pct_of_revenue: float = Field(..., ge=0, le=100, description="% of revenue from top 10")
    herfindahl_index: Optional[float] = Field(
        default=None, 
        ge=0, 
        le=10000,
        description="Herfindahl index (0 = perfect diversity, 10000 = monopoly)"
    )
    single_customer_concentration_pct: Optional[float] = Field(
        default=None,
        ge=0,
        le=100,
        description="% of revenue from largest customer (key person risk)"
    )
    
    class Config:
        example = {
            "total_customers": 150,
            "top_10_pct_of_revenue": 55.0,
            "herfindahl_index": 850.0,
            "single_customer_concentration_pct": 15.0
        }


# ============================================
# MARKET & COMPETITIVE
# ============================================

class IndustryBenchmark(BaseModel):
    """Industry benchmark data for comparison"""
    
    sector: str = Field(..., description="Sector code (manufacturing, saas, retail, etc)")
    year: int = Field(..., ge=2020, le=2026, description="Benchmark year")
    
    # Margins
    gross_margin_median_pct: float = Field(..., ge=0, le=100)
    net_margin_median_pct: float = Field(..., ge=0, le=100)
    ebitda_margin_median_pct: float = Field(..., ge=0, le=100)
    
    # Growth
    revenue_growth_median_pct: float = Field(..., description="Median YoY growth %")
    
    # Efficiency
    asset_turnover_median: Optional[float] = Field(default=None, ge=0)
    roi_median_pct: Optional[float] = Field(default=None)
    
    # Market cap / multiples
    ev_ebitda_median: Optional[float] = Field(default=None, ge=0, description="EV/EBITDA multiple")
    pe_median: Optional[float] = Field(default=None, ge=0, description="P/E multiple")
    
    class Config:
        example = {
            "sector": "saas",
            "year": 2025,
            "gross_margin_median_pct": 75.0,
            "net_margin_median_pct": 20.0,
            "ebitda_margin_median_pct": 30.0,
            "revenue_growth_median_pct": 18.0,
            "asset_turnover_median": 1.5,
            "roi_median_pct": 25.0,
            "ev_ebitda_median": 12.0,
            "pe_median": 20.0
        }


class CompetitorSnapshot(BaseModel):
    """Competitor financial metrics for comparison"""
    
    competitor_name: str = Field(..., min_length=1, description="Company name")
    revenue_eur: float = Field(..., ge=0, description="Annual revenue")
    gross_margin_pct: Optional[float] = Field(default=None, ge=0, le=100)
    net_margin_pct: Optional[float] = Field(default=None, ge=0, le=100)
    growth_yoy_pct: Optional[float] = Field(default=None, description="YoY growth %")
    
    class Config:
        example = {
            "competitor_name": "TechCorp Inc",
            "revenue_eur": 50000000,
            "gross_margin_pct": 70.0,
            "net_margin_pct": 18.0,
            "growth_yoy_pct": 22.0
        }


# ============================================
# ADVANCED REQUEST SCHEMA
# ============================================

class AnalyzeRequestAdvanced(BaseModel):
    """
    Advanced /cfo/analyze-advanced request with full data richness
    
    Supports:
    - Historical KPI time series
    - Revenue breakdown by segment
    - Customer concentration
    - Market/competitive context
    - Balance sheet data for Altman Z-score
    """
    
    # --------- BASIC (same as standard request) ---------
    company_name: Optional[str] = Field(default=None, description="Company name")
    settore: str = Field(
        default="default",
        description="Industry sector"
    )
    
    # Current year data (snapshot)
    fatturato: float = Field(..., ge=0, description="Latest annual revenue")
    costi_variabili: float = Field(..., ge=0, description="Latest variable costs")
    costi_fissi: float = Field(..., ge=0, description="Latest fixed costs")
    investimenti: Optional[float] = Field(default=0, ge=0, description="Annual CapEx")
    
    # --------- BALANCE SHEET ---------
    total_assets: Optional[float] = Field(default=None, ge=0, description="Total assets")
    total_liabilities: Optional[float] = Field(default=None, ge=0, description="Total liabilities")
    equity: Optional[float] = Field(default=None, ge=0, description="Shareholders equity")
    
    # For Altman Z-score + working capital analysis
    working_capital: Optional[float] = Field(default=None, description="Current assets - current liabilities")
    current_assets: Optional[float] = Field(default=None, ge=0, description="Current assets")
    current_liabilities: Optional[float] = Field(default=None, ge=0, description="Current liabilities")
    retained_earnings: Optional[float] = Field(default=None, description="Retained earnings")
    ebit: Optional[float] = Field(default=None, description="EBIT (operating profit)")
    
    # --------- WORKING CAPITAL DETAIL ---------
    dso_days: Optional[float] = Field(default=None, ge=0, description="Days Sales Outstanding")
    dio_days: Optional[float] = Field(default=None, ge=0, description="Days Inventory Outstanding")
    dpo_days: Optional[float] = Field(default=None, ge=0, description="Days Payables Outstanding")
    
    # --------- TIME SERIES HISTORICALS ---------
    historicals: Optional[List[KPIHistorical]] = Field(
        default=[],
        description="Historical KPI data (3-5 years), sorted by date ascending"
    )
    
    # --------- SEGMENTATION ---------
    revenue_segments: Optional[List[RevenueSegment]] = Field(
        default=[],
        description="Revenue breakdown by product/customer/geography"
    )
    
    customer_concentration: Optional[CustomerConcentration] = Field(
        default=None,
        description="Customer concentration & diversification metrics"
    )
    
    # --------- MARKET CONTEXT ---------
    industry_benchmark: Optional[IndustryBenchmark] = Field(
        default=None,
        description="Industry benchmarks for comparison"
    )
    
    competitors: Optional[List[CompetitorSnapshot]] = Field(
        default=[],
        description="Competitive data for comparison"
    )
    
    # --------- MARKET SIZE ---------
    market_size_eur: Optional[float] = Field(
        default=None, 
        ge=0,
        description="Total addressable market (TAM) in EUR"
    )
    market_share_pct: Optional[float] = Field(
        default=None,
        ge=0,
        le=100,
        description="Current market share %"
    )
    
    # --------- PEOPLE ---------
    headcount: Optional[int] = Field(default=None, ge=0, description="Current employees")
    headcount_growth_pct: Optional[float] = Field(default=None, description="YoY headcount growth %")
    
    class Config:
        example = {
            "company_name": "TechCorp Italia",
            "settore": "saas",
            "fatturato": 10000000,
            "costi_variabili": 2500000,
            "costi_fissi": 3000000,
            "investimenti": 400000,
            "total_assets": 5000000,
            "equity": 3000000,
            "working_capital": 800000,
            "dso_days": 45,
            "dio_days": 30,
            "dpo_days": 60,
            "historicals": [
                {
                    "period_date": "2023-12-31",
                    "period_type": "annual",
                    "fatturato": 8000000,
                    "costi_variabili": 2000000,
                    "costi_fissi": 2500000,
                    "headcount": 18
                },
                {
                    "period_date": "2024-12-31",
                    "period_type": "annual",
                    "fatturato": 10000000,
                    "costi_variabili": 2500000,
                    "costi_fissi": 3000000,
                    "headcount": 22
                }
            ],
            "revenue_segments": [
                {
                    "segment_type": "customer_segment",
                    "segment_name": "Enterprise",
                    "fatturato": 6000000,
                    "margin_pct": 70.0,
                    "growth_yoy_pct": 35.0,
                    "num_customers": 8,
                    "churn_rate_pct": 3.0
                },
                {
                    "segment_type": "customer_segment",
                    "segment_name": "SMB",
                    "fatturato": 4000000,
                    "margin_pct": 65.0,
                    "growth_yoy_pct": 15.0,
                    "num_customers": 120,
                    "churn_rate_pct": 8.0
                }
            ],
            "customer_concentration": {
                "total_customers": 128,
                "top_10_pct_of_revenue": 48.0,
                "single_customer_concentration_pct": 12.0
            },
            "market_size_eur": 500000000,
            "market_share_pct": 2.0,
            "headcount": 22,
            "headcount_growth_pct": 22.0
        }


# ============================================
# ADVANCED RESPONSE SCHEMA
# ============================================

class TrendAnalysis(BaseModel):
    """Trend analysis for a metric over time"""
    
    metric_name: str = Field(..., description="Metric being analyzed")
    periods: int = Field(..., ge=1, description="Number of periods in trend")
    cagr_pct: Optional[float] = Field(default=None, description="Compound annual growth rate %")
    yoy_growth_pct: Optional[float] = Field(default=None, description="Latest YoY growth %")
    trend_direction: Literal["improving", "declining", "stable"] = Field(
        ..., 
        description="Overall trend"
    )
    volatility_pct: Optional[float] = Field(default=None, ge=0, description="Standard deviation %")
    
    class Config:
        example = {
            "metric_name": "Gross Margin %",
            "periods": 3,
            "cagr_pct": 2.5,
            "yoy_growth_pct": 4.0,
            "trend_direction": "improving",
            "volatility_pct": 1.2
        }


class BenchmarkComparison(BaseModel):
    """Company metric vs industry benchmark"""
    
    metric_name: str = Field(..., description="Metric name")
    your_value: float = Field(..., description="Your company value")
    benchmark_median: float = Field(..., description="Industry median")
    percentile_rank: float = Field(
        ..., 
        ge=0, 
        le=100,
        description="Your percentile rank (0=worst, 100=best)"
    )
    gap_to_median_pct: float = Field(
        ...,
        description="% gap to median (negative = below, positive = above)"
    )
    
    class Config:
        example = {
            "metric_name": "Net Margin %",
            "your_value": 25.0,
            "benchmark_median": 18.0,
            "percentile_rank": 72.0,
            "gap_to_median_pct": 38.9
        }


class DupontAnalysis(BaseModel):
    """DuPont decomposition of ROA/ROE"""
    
    roa_pct: Optional[float] = Field(default=None, description="Return on Assets %")
    roe_pct: Optional[float] = Field(default=None, description="Return on Equity %")
    
    # Components
    net_margin_pct: float = Field(..., description="Net profit / Revenue")
    asset_turnover: float = Field(..., description="Revenue / Total Assets")
    financial_leverage: Optional[float] = Field(default=None, description="Total Assets / Equity")
    
    # Contributions (which component is driving ROA)
    margin_contribution_pct: float = Field(..., ge=0, le=100, description="% of ROA from margin")
    turnover_contribution_pct: float = Field(..., ge=0, le=100, description="% of ROA from turnover")
    
    class Config:
        example = {
            "roa_pct": 15.0,
            "roe_pct": 22.5,
            "net_margin_pct": 20.0,
            "asset_turnover": 0.75,
            "financial_leverage": 1.5,
            "margin_contribution_pct": 65.0,
            "turnover_contribution_pct": 35.0
        }


class AnalyzeAdvancedResponse(BaseModel):
    """Advanced analysis response with benchmarking, trends, decomposition"""
    
    # Basic analysis (same as standard)
    status: str = Field(..., description="Company health: healthy, warning, critical")
    headline: str = Field(..., description="One-line summary")
    summary: str = Field(..., description="Executive summary")
    
    # KPI snapshot
    kpi_snapshot: Dict[str, float] = Field(..., description="Current KPI snapshot")
    
    # NEW: Benchmark comparison
    benchmark_comparisons: Optional[List[BenchmarkComparison]] = Field(
        default=[],
        description="How you compare vs industry benchmarks"
    )
    
    # NEW: Trend analysis
    trends: Optional[List[TrendAnalysis]] = Field(
        default=[],
        description="Trend analysis for key metrics (CAGR, volatility)"
    )
    
    # NEW: DuPont decomposition
    dupont: Optional[DupontAnalysis] = Field(
        default=None,
        description="DuPont analysis showing what drives returns"
    )
    
    # NEW: Segment analysis
    segment_performance: Optional[Dict[str, Dict]] = Field(
        default=None,
        description="Performance by revenue segment"
    )
    
    # NEW: Customer concentration risks
    concentration_risk: Optional[str] = Field(
        default=None,
        description="Risk assessment of customer concentration"
    )
    
    # Recommendations
    recommended_actions: List[Dict] = Field(...)
    estimated_loss_eur: float = Field(...)
    potential_recovery_eur: float = Field(...)
    
    class Config:
        example = {
            "status": "healthy",
            "headline": "Strong growth with margin optimization opportunity",
            "summary": "Your company is outpacing the industry benchmark by 18% in growth. Focus areas include margin expansion in SMB segment and customer diversification.",
            "kpi_snapshot": {
                "net_margin_pct": 25.0,
                "gross_margin_pct": 75.0,
                "roi_pct": 22.0
            },
            "benchmark_comparisons": [
                {
                    "metric_name": "Net Margin %",
                    "your_value": 25.0,
                    "benchmark_median": 18.0,
                    "percentile_rank": 72.0,
                    "gap_to_median_pct": 38.9
                }
            ],
            "trends": [
                {
                    "metric_name": "Revenue",
                    "periods": 3,
                    "cagr_pct": 25.0,
                    "trend_direction": "improving"
                }
            ],
            "dupont": {
                "roa_pct": 15.0,
                "roe_pct": 22.5,
                "margin_contribution_pct": 65.0,
                "turnover_contribution_pct": 35.0
            },
            "recommended_actions": []
        }
