"""
CFO Product Layer - Pydantic Schemas for Monetizable API

All schemas for /cfo/analyze, /cfo/simulate, /cfo/chat endpoints
"""

from pydantic import BaseModel, Field, model_validator
from typing import Optional, List, Dict, Any
from enum import Enum


# ============================================
# ENUMS
# ============================================

class HealthStatus(str, Enum):
    """Company health status"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"


class PriorityLevel(str, Enum):
    """Action priority"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ============================================
# REQUEST SCHEMAS
# ============================================

class AnalyzeRequest(BaseModel):
    """Request schema for /cfo/analyze endpoint"""
    
    fatturato: float = Field(
        ...,
        ge=0,
        description="Revenue in EUR"
    )
    costi_variabili: float = Field(
        ...,
        ge=0,
        description="Variable costs in EUR"
    )
    costi_fissi: float = Field(
        ...,
        ge=0,
        description="Fixed costs in EUR"
    )
    investimenti: float = Field(
        default=0,
        ge=0,
        description="Investments/CapEx in EUR"
    )
    settore: str = Field(
        default="default",
        alias="sector",
        description="Industry sector (default, manufacturing, saas, retail, etc)"
    )
    company_name: Optional[str] = Field(
        default=None,
        description="Optional company name for personalization"
    )
    
    # Optional deep inputs for better analysis
    dso_days: Optional[float] = Field(
        default=None,
        ge=0,
        description="Days Sales Outstanding"
    )
    dio_days: Optional[float] = Field(
        default=None,
        ge=0,
        description="Days Inventory Outstanding"
    )
    dpo_days: Optional[float] = Field(
        default=None,
        ge=0,
        description="Days Payable Outstanding"
    )
    employee_count: Optional[int] = Field(default=None, ge=0)
    monthly_salary_avg: Optional[float] = Field(default=None, ge=0)
    hiring_context: Optional[str] = Field(default=None)
    
    class Config:
        populate_by_name = True
        example = {
            "fatturato": 1000000,
            "costi_variabili": 400000,
            "costi_fissi": 300000,
            "investimenti": 50000,
            "settore": "manufacturing",
            "company_name": "Acme Corp"
        }


class SimulateRequest(BaseModel):
    """Request schema for /cfo/simulate endpoint"""
    
    base_analysis: AnalyzeRequest = Field(
        ...,
        description="Base company data (same as /analyze)"
    )
    scenario_name: str = Field(
        ...,
        min_length=1,
        description="Name of scenario (e.g., 'Price Increase +5%')"
    )
    fatturato_delta: Optional[float] = Field(
        default=0,
        description="Revenue change in EUR"
    )
    costi_variabili_delta: Optional[float] = Field(
        default=0,
        description="Variable costs change in EUR"
    )
    costi_fissi_delta: Optional[float] = Field(
        default=0,
        description="Fixed costs change in EUR"
    )
    investimenti_delta: Optional[float] = Field(
        default=0,
        description="Investment change in EUR"
    )

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_flat_payload(cls, data):
        if not isinstance(data, dict) or "base_analysis" in data:
            return data

        legacy_keys = {
            "fatturato_base",
            "costi_variabili_base",
            "costi_fissi_base",
            "investimenti_base",
        }
        if not legacy_keys.intersection(data):
            return data

        scenario = data.get("scenario", "Scenario")
        param_value = float(data.get("param_value") or 0)

        mapped = {
            "base_analysis": {
                "fatturato": data.get("fatturato_base", 0),
                "costi_variabili": data.get("costi_variabili_base", 0),
                "costi_fissi": data.get("costi_fissi_base", 0),
                "investimenti": data.get("investimenti_base", 0),
                "settore": data.get("settore", data.get("sector", "default")),
                "company_name": data.get("company_name"),
            },
            "scenario_name": str(scenario).replace("_", " ").title(),
            "fatturato_delta": data.get("fatturato_delta", 0),
            "costi_variabili_delta": data.get("costi_variabili_delta", 0),
            "costi_fissi_delta": data.get("costi_fissi_delta", 0),
            "investimenti_delta": data.get("investimenti_delta", 0),
        }

        if scenario == "cost_reduction":
            mapped["costi_fissi_delta"] = -abs(param_value)
        elif scenario == "revenue_increase":
            mapped["fatturato_delta"] = abs(param_value)
        elif scenario == "investment":
            mapped["investimenti_delta"] = abs(param_value)

        return mapped
    
    class Config:
        example = {
            "base_analysis": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 50000,
                "settore": "manufacturing"
            },
            "scenario_name": "Price Increase +5%",
            "fatturato_delta": 50000,
            "costi_variabili_delta": -20000
        }


class ChatMessage(BaseModel):
    """Message for chat history"""
    role: str = Field(..., description="'user' or 'assistant'")
    content: str = Field(..., description="Message content")


class ChatRequest(BaseModel):
    """Request schema for /cfo/chat endpoint"""
    
    message: str = Field(
        ...,
        min_length=1,
        description="User question or request"
    )
    company_data: AnalyzeRequest = Field(
        ...,
        description="Current company financial data"
    )
    chat_history: Optional[List[ChatMessage]] = Field(
        default=[],
        description="Previous chat messages for context"
    )
    operational_data: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Sector-specific operational data already collected, such as recipes, SKU costs, staff roles, rooms, projects"
    )
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = Field(
        default=None,
        description="All sector-specific operational data saved for the company"
    )
    
    class Config:
        example = {
            "message": "Come posso aumentare il mio profitto del 20%?",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 50000,
                "settore": "manufacturing"
            },
            "chat_history": []
        }


# ============================================
# RESPONSE SCHEMAS
# ============================================

class KPISnapshot(BaseModel):
    """Key Performance Indicators snapshot"""
    
    gross_profit_eur: float = Field(..., description="Gross profit in EUR")
    gross_margin_pct: float = Field(..., description="Gross margin percentage (0-100)")
    ebitda_eur: float = Field(..., description="EBITDA in EUR")
    ebitda_margin_pct: float = Field(..., description="EBITDA margin percentage")
    net_profit_eur: float = Field(..., description="Net profit in EUR")
    net_margin_pct: float = Field(..., description="Net margin percentage")
    roi_pct: Optional[float] = Field(default=None, description="Return on Investment percentage")
    ccc_days: Optional[float] = Field(default=None, description="Cash Conversion Cycle in days")
    

class RecommendedAction(BaseModel):
    """Single recommended action with details"""
    
    title: str = Field(..., description="Action title")
    description: str = Field(..., description="Detailed description")
    impatto_euro: float = Field(..., description="Estimated financial impact in EUR")
    priorita: PriorityLevel = Field(..., description="Action priority")
    passi: List[str] = Field(..., description="Implementation steps")
    
    class Config:
        example = {
            "title": "Reduce Fixed Costs",
            "description": "Optimize overhead by renegotiating supplier contracts",
            "impatto_euro": 30000,
            "priorita": "high",
            "passi": [
                "Review all vendor contracts",
                "Request RFQ from 3 competitors",
                "Negotiate new terms"
            ]
        }


class Diagnosis(BaseModel):
    """Problem diagnosis with root cause"""
    
    problema_principale: str = Field(..., description="Main problem identified")
    causa_principale: str = Field(..., description="Root cause analysis")
    impatto_stimato_eur: float = Field(..., description="Estimated financial impact in EUR")


class AnalyzeResponse(BaseModel):
    """Response schema for /cfo/analyze endpoint - The complete analysis"""
    
    status: HealthStatus = Field(..., description="Company health status")
    headline: str = Field(..., description="One-line summary (e.g., 'Profitability Crisis')")
    summary: str = Field(..., description="2-3 sentence executive summary")
    
    diagnosis: Diagnosis = Field(..., description="Problem and root cause analysis")
    
    estimated_loss_eur: float = Field(
        ...,
        description="Estimated annual loss if nothing changes"
    )
    potential_recovery_eur: float = Field(
        ...,
        description="Potential profit recovery from recommended actions"
    )
    priority: PriorityLevel = Field(
        ...,
        description="Overall priority for action"
    )
    
    kpi_snapshot: KPISnapshot = Field(..., description="Current KPI metrics")
    
    recommended_actions: List[RecommendedAction] = Field(
        ...,
        min_items=1,
        max_items=5,
        description="Top 3-5 recommended actions"
    )
    
    class Config:
        example = {
            "status": "critical",
            "headline": "Profitability Crisis - Immediate Action Required",
            "summary": "Your company is operating at a loss with 30% margin erosion. Fixed costs are 45% of revenue, indicating structural inefficiency.",
            "diagnosis": {
                "problema_principale": "Profitability erosion due to rising fixed costs",
                "causa_principale": "Fixed costs grew 25% YoY while revenue stagnated",
                "impatto_stimato_eur": 150000
            },
            "estimated_loss_eur": 150000,
            "potential_recovery_eur": 120000,
            "priority": "critical",
            "kpi_snapshot": {
                "gross_profit_eur": 600000,
                "gross_margin_pct": 60.0,
                "ebitda_eur": 300000,
                "ebitda_margin_pct": 30.0,
                "net_profit_eur": -100000,
                "net_margin_pct": -10.0,
                "roi_pct": -200.0
            },
            "recommended_actions": [
                {
                    "title": "Reduce Fixed Costs",
                    "description": "Optimize overhead",
                    "impatto_euro": 80000,
                    "priorita": "critical",
                    "passi": ["Review contracts", "Negotiate rates"]
                }
            ]
        }


class ScenarioComparison(BaseModel):
    """Comparison between base and simulated scenario"""
    
    base_kpi: KPISnapshot = Field(..., description="Base scenario KPIs")
    scenario_kpi: KPISnapshot = Field(..., description="Simulated scenario KPIs")
    
    profit_delta_eur: float = Field(..., description="Change in profit")
    profit_delta_pct: float = Field(..., description="Percentage change in profit")
    
    roi_delta_pct: Optional[float] = Field(default=None, description="Change in ROI")
    
    recommendation: str = Field(..., description="Should you pursue this scenario?")
    

class SimulateResponse(BaseModel):
    """Response schema for /cfo/simulate endpoint"""
    
    scenario_name: str = Field(..., description="Name of the scenario")
    base_analysis: AnalyzeResponse = Field(..., description="Original analysis")
    scenario_analysis: AnalyzeResponse = Field(..., description="Analysis with changes applied")
    comparison: ScenarioComparison = Field(..., description="Side-by-side comparison")
    impact: Optional[dict] = Field(default=None, description="Legacy impact summary")
    
    class Config:
        example = {
            "scenario_name": "Price Increase +5%",
            "base_analysis": {...},
            "scenario_analysis": {...},
            "comparison": {
                "base_kpi": {...},
                "scenario_kpi": {...},
                "profit_delta_eur": 50000,
                "profit_delta_pct": 8.3,
                "recommendation": "YES - This scenario improves profitability significantly"
            }
        }


class ChatResponse(BaseModel):
    """Response schema for /cfo/chat endpoint"""
    
    response: str = Field(..., description="Assistant's response")
    analysis: Optional[AnalyzeResponse] = Field(
        default=None,
        description="Re-analyzed data if query required calculation"
    )
    recommendations: Optional[List[RecommendedAction]] = Field(
        default=None,
        description="Specific actions if query asks for recommendations"
    )
    conversation_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Structured conversation metadata: intent, resolved message, next step and suggested action"
    )
    
    class Config:
        example = {
            "response": "To increase profit by 20%, focus on: 1) Reduce fixed costs by 10% (€30k), 2) Improve gross margin by 2% through pricing (€20k), 3) Reduce working capital by 15 days (€25k improved cash flow). Total impact: €75k additional profit.",
            "analysis": {...},
            "recommendations": [...]
        }


# ============================================
# TREND SCHEMAS
# ============================================

class MetricTrendData(BaseModel):
    """Individual metric trend"""
    metric_name: str = Field(..., description="e.g., 'Gross Margin %'")
    current_value: float = Field(..., description="Current metric value")
    previous_value: float = Field(..., description="Previous month's value")
    change_pct: float = Field(..., description="% change from previous")
    direction: str = Field(..., description="improving, stable, worsening")
    is_alert: bool = Field(..., description="True if trend needs attention")


class TrendsResponse(BaseModel):
    """Response schema for /cfo/trends endpoint"""
    
    has_data: bool = Field(..., description="True if historical data available")
    revenue_trend: Optional[MetricTrendData] = Field(default=None, description="Revenue trend")
    gross_margin_trend: Optional[MetricTrendData] = Field(default=None, description="Gross margin trend")
    ebitda_margin_trend: Optional[MetricTrendData] = Field(default=None, description="EBITDA margin trend")
    net_margin_trend: Optional[MetricTrendData] = Field(default=None, description="Net margin trend")
    roi_trend: Optional[MetricTrendData] = Field(default=None, description="ROI trend")
    
    momentum_score: float = Field(..., description="Overall momentum score (-100 to +100)")
    momentum_label: str = Field(..., description="Improving, Stable, or Declining")
    
    alerts: List[str] = Field(default=[], description="List of alerts for worsening metrics")
    trend_summary: str = Field(..., description="Human-readable trend summary")
    
    class Config:
        example = {
            "has_data": True,
            "revenue_trend": {
                "metric_name": "Revenue",
                "current_value": 5100000,
                "previous_value": 5000000,
                "change_pct": 2.0,
                "direction": "improving",
                "is_alert": False
            },
            "gross_margin_trend": {
                "metric_name": "Gross Margin %",
                "current_value": 32.0,
                "previous_value": 35.0,
                "change_pct": -8.6,
                "direction": "worsening",
                "is_alert": True
            },
            "momentum_score": -11,
            "momentum_label": "Declining",
            "alerts": ["EBITDA margin down 17.9% - cost control issue"],
            "trend_summary": "📊 Trends (vs last month): ..."
        }


# ============================================
# ERROR SCHEMAS
# ============================================

class CFOErrorResponse(BaseModel):
    """Error response for CFO endpoints"""
    
    detail: str = Field(..., description="Error message")
    error_code: Optional[str] = Field(default=None, description="Specific error code")
    suggestion: Optional[str] = Field(default=None, description="Suggested fix")
    
    class Config:
        example = {
            "detail": "Invalid input: fatturato must be greater than zero",
            "error_code": "INVALID_INPUT",
            "suggestion": "Please provide positive values for revenue"
        }
