# -*- coding: utf-8 -*-
# content/api/config.py
from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Optional, Any, Dict, ClassVar

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _parse_csv_list(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    s = str(v).strip()
    if not s:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _parse_bool(v: Any, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in {"1", "true", "yes", "y", "on"}:
        return True
    if s in {"0", "false", "no", "n", "off"}:
        return False
    return default


class Settings(BaseSettings):
    # --- App ---
    APP_NAME: str = "ZephyBloom CFO API"
    ENV: str = "production"  # development | staging | production
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    VERSION: str = "0.1.0"

    # Trace/observability
    REQUEST_ID_HEADER: str = "X-Request-ID"

    # --- URLs ---
    BACKEND_BASE_URL: str = "http://127.0.0.1:8000"
    FRONTEND_BASE_URL: Optional[str] = None
    UI_PATH: str = "/ui"
    ENABLE_UI: bool = True

    # --- CORS (as CSV strings, parsed to lists by validators) ---
    # Validators convert CSV strings to lists
    CORS_ORIGINS: List[str] = ["*"]
    CORS_HEADERS: List[str] = ["*"]
    CORS_METHODS: List[str] = ["*"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_EXPOSE_HEADERS: str = ""
    CORS_MAX_AGE: int = 600
    CORS_ORIGIN_REGEX: Optional[str] = None

    # --- Sicurezza App (API Key della tua API, NON di OpenAI) ---
    APP_API_KEY: Optional[str] = None

    # --- JWT / Security ---
    JWT_SECRET: Optional[str] = None
    JWT_REQUIRED: bool = False  # Automatically set to True if ENV=production
    RATE_LIMIT_PER_TENANT: int = 120
    RATE_LIMIT_WINDOW_S: int = 60

    # --- LLM / Chat ---
    OPENAI_API_KEY: Optional[str] = None
    LLM_PROVIDER: str = "openai"   # openai | mock
    LLM_MODEL: str = "gpt-4o-mini"
    TIMEOUT_S: int = 30
    TOOLCALLING_OFFLINE: bool = True
    STRICT_OPENAI_IN_PROD: bool = False

    # --- Feature flags ---
    DEMO_MODE: bool = True
    TEST_MODE: bool = False

    # --- Limiti / pipeline ---
    REQUEST_MAX_BYTES: int = 1_000_000
    RESPONSE_MAX_BYTES: int = 1_000_000
    REQUEST_TIMEOUT_MS: int = 30_000

    # --- Twilio / WhatsApp ---
    TWILIO_ACCOUNT_SID: Optional[str] = None
    TWILIO_AUTH_TOKEN: Optional[str] = None
    TWILIO_WHATSAPP_NUMBER: Optional[str] = None

    # --- RAG / Vector index ---
    RAG_BACKEND: str = "memory"  # memory | qdrant
    RAG_EAGER_INIT: bool = False
    RAG_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    RAG_DIM: int = 128
    RAG_COLLECTION: str = "llm_cfo_chunks"
    RAG_DEVICE: str = "cpu"
    RAG_CACHE_DIR: str = ".rag_cache"
    RAG_MAX_DOCS: int = 5000
    RAG_TOP_K: int = 4
    RAG_CHUNK_SIZE: int = 350
    RAG_OVERLAP: int = 50

    # --- Qdrant ---
    QDRANT_URL: Optional[str] = "http://localhost:6333"
    QDRANT_API_KEY: Optional[str] = None

    # --- Database (Phase 1 Security) ---
    # Default: SQLite for local dev. Set DATABASE_URL env var to use PostgreSQL
    # SQLite example: "sqlite:///./zephytheory.db"
    # PostgreSQL examples:
    #   Dev: "postgresql://zephybloom:password@localhost:5432/zephybloom_dev"
    #   Production: "postgresql://user:secure_pass@prod-db.aws.rds.amazonaws.com:5432/zephybloom_prod"
    DATABASE_URL: str = "sqlite:///./zephytheory.db"
    DB_POOL_SIZE: int = 20  # 20 for dev/test, 50+ for prod
    DB_MAX_OVERFLOW: int = 40  # 40 for dev, 100+ for prod
    DB_ECHO: bool = False  # Set to True for SQL debugging
    DB_POOL_RECYCLE_SECONDS: int = 3600  # Recycle connections every hour

    # --- Redis (Rate Limiting) ---
    REDIS_URL: Optional[str] = None  # redis://localhost:6379/0
    # If None, uses in-memory rate limiting (single-server only)

    # --- JWT Configuration ---
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_HOURS: int = 24
    JWT_REFRESH_EXPIRY_DAYS: int = 7
    JWT_REQUIRED: bool = False  # Set to True in staging/production
    JWT_SECRET: Optional[str] = None  # Load from env or generate on startup

    # --- Rate Limiting ---
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_API_KEY_PER_MINUTE: int = 100  # Default per API key
    RATE_LIMIT_TENANT_PER_MINUTE: int = 1000  # Default per tenant
    RATE_LIMIT_IP_PER_MINUTE: int = 30  # Unauthenticated requests

    # --- Security ---
    REQUIRE_HTTPS: bool = False  # Set to True in production
    CSRF_ENABLED: bool = True
    MAX_REQUEST_SIZE_MB: int = 10

    # --- Audit ---
    AUDIT_ENABLED: bool = True
    AUDIT_LOG_RETENTION_DAYS: int = 90

    # --- Cache (Decorator & Redis) ---
    CACHE_ENABLED: bool = True
    CACHE_TTL_SECONDS: int = 600  # Default TTL for cached results
    CACHE_MAX_IN_MEMORY: int = 1000  # Max entries in in-memory fallback

    # --- Circuit Breaker ---
    CIRCUIT_BREAKER_ENABLED: bool = True
    CIRCUIT_BREAKER_LLM_FAIL_MAX: int = 5
    CIRCUIT_BREAKER_LLM_RESET_TIMEOUT: int = 60
    CIRCUIT_BREAKER_DB_FAIL_MAX: int = 3
    CIRCUIT_BREAKER_DB_RESET_TIMEOUT: int = 30

    # --- Prometheus Metrics ---
    PROMETHEUS_ENABLED: bool = True
    PROMETHEUS_PORT: int = 9090

    # --- Pydantic v2 config ---
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="ZB_",
        extra="ignore",
    )

    # ---------------------------
    # Compatibilità: alias legacy
    # ---------------------------
    _ALIASES: ClassVar[Dict[str, str]] = {
        "api_key": "APP_API_KEY",
        "model": "LLM_MODEL",
        "provider": "LLM_PROVIDER",
        "timeout_s": "TIMEOUT_S",
        "timeout": "TIMEOUT_S",
        "toolcalling_offline": "TOOLCALLING_OFFLINE",
        "cors_allow_origins": "CORS_ORIGINS",
        "cors_allow_headers": "CORS_HEADERS",
        "cors_allow_methods": "CORS_METHODS",
        "cors_allow_credentials": "CORS_ALLOW_CREDENTIALS",
        "cors_expose_headers": "CORS_EXPOSE_HEADERS",
        "cors_max_age": "CORS_MAX_AGE",
        "cors_allow_regex": "CORS_ORIGIN_REGEX",
        "request_max_bytes": "REQUEST_MAX_BYTES",
        "response_max_bytes": "RESPONSE_MAX_BYTES",
        "request_timeout_ms": "REQUEST_TIMEOUT_MS",
        "rag_backend": "RAG_BACKEND",
        "rag_eager_init": "RAG_EAGER_INIT",
        "rag_model": "RAG_MODEL",
        "rag_dim": "RAG_DIM",
        "rag_collection": "RAG_COLLECTION",
        "rag_device": "RAG_DEVICE",
        "rag_cache_dir": "RAG_CACHE_DIR",
        "rag_max_docs": "RAG_MAX_DOCS",
        "rag_top_k": "RAG_TOP_K",
        "rag_chunk_size": "RAG_CHUNK_SIZE",
        "rag_overlap": "RAG_OVERLAP",
        "qdrant_url": "QDRANT_URL",
        "qdrant_api_key": "QDRANT_API_KEY",
        "jwt_secret": "JWT_SECRET",
        "jwt_required": "JWT_REQUIRED",
        "rate_limit_per_tenant": "RATE_LIMIT_PER_TENANT",
        "rate_limit_window_s": "RATE_LIMIT_WINDOW_S",
    }

    # ---------- Validators ----------
    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def _norm_cors_origins(cls, v: Any) -> List[str]:
        return _parse_csv_list(v) or ["*"]

    @field_validator("CORS_HEADERS", mode="before")
    @classmethod
    def _norm_cors_headers(cls, v: Any) -> List[str]:
        return _parse_csv_list(v) or ["*"]

    @field_validator("CORS_METHODS", mode="before")
    @classmethod
    def _norm_cors_methods(cls, v: Any) -> List[str]:
        return _parse_csv_list(v) or ["*"]

    @field_validator(
        "DEBUG",
        "ENABLE_UI",
        "CORS_ALLOW_CREDENTIALS",
        "TOOLCALLING_OFFLINE",
        "STRICT_OPENAI_IN_PROD",
        "DEMO_MODE",
        "TEST_MODE",
        "RAG_EAGER_INIT",
        "JWT_REQUIRED",
        mode="before",
    )
    @classmethod
    def _norm_bool_fields(cls, v: Any) -> bool:
        return _parse_bool(v, default=False)

    @field_validator("LOG_LEVEL", mode="before")
    @classmethod
    def _norm_log_level(cls, v: Any) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        s = str(v or "INFO").strip().upper()
        return s if s in allowed else "INFO"

    @field_validator("LLM_PROVIDER", mode="before")
    @classmethod
    def _norm_provider(cls, v: Any) -> str:
        s = str(v or "mock").strip().lower()
        return s if s in {"openai", "mock"} else "mock"

    @field_validator("RAG_BACKEND", mode="before")
    @classmethod
    def _norm_rag_backend(cls, v: Any) -> str:
        s = str(v or "memory").strip().lower()
        return s if s in {"memory", "qdrant"} else "memory"

    @field_validator("CORS_ORIGINS", "CORS_HEADERS", "CORS_METHODS", "CORS_EXPOSE_HEADERS", mode="before")
    @classmethod
    def _parse_cors_to_csv(cls, v: Any) -> str:
        """Convert CORS values to CSV string format"""
        if v is None:
            return ""
        if isinstance(v, (list, tuple)):
            # Convert list to CSV
            return ",".join(str(x).strip() for x in v if str(x).strip())
        # Handle as string (already CSV or single value)
        s = str(v).strip()
        return s if s else ""

    @field_validator(
        "TIMEOUT_S",
        "REQUEST_MAX_BYTES",
        "RESPONSE_MAX_BYTES",
        "REQUEST_TIMEOUT_MS",
        "CORS_MAX_AGE",
        "RAG_DIM",
        "RAG_MAX_DOCS",
        "RAG_TOP_K",
        "RAG_CHUNK_SIZE",
        "RAG_OVERLAP",
        "RATE_LIMIT_PER_TENANT",
        "RATE_LIMIT_WINDOW_S",
        mode="before",
    )
    @classmethod
    def _norm_positive_ints(cls, v: Any) -> int:
        try:
            return max(0, int(v))
        except Exception:
            return 0

    @model_validator(mode="after")
    def _derive_flags_and_failfast(self) -> "Settings":
        env = (self.ENV or "production").lower().strip()
        if env not in {"development", "staging", "production"}:
            env = "production"
        object.__setattr__(self, "ENV", env)

        # Timeout / limiti minimi ragionevoli
        if self.TIMEOUT_S <= 0:
            object.__setattr__(self, "TIMEOUT_S", 30)
        if self.REQUEST_TIMEOUT_MS <= 0:
            object.__setattr__(self, "REQUEST_TIMEOUT_MS", 30_000)
        if self.REQUEST_MAX_BYTES <= 0:
            object.__setattr__(self, "REQUEST_MAX_BYTES", 1_000_000)
        if self.RESPONSE_MAX_BYTES <= 0:
            object.__setattr__(self, "RESPONSE_MAX_BYTES", 1_000_000)

        # RAG bounds
        if self.RAG_TOP_K <= 0:
            object.__setattr__(self, "RAG_TOP_K", 4)
        if self.RAG_CHUNK_SIZE < 50:
            object.__setattr__(self, "RAG_CHUNK_SIZE", 350)
        if self.RAG_OVERLAP < 0:
            object.__setattr__(self, "RAG_OVERLAP", 50)
        if self.RAG_OVERLAP >= self.RAG_CHUNK_SIZE:
            object.__setattr__(self, "RAG_OVERLAP", max(0, self.RAG_CHUNK_SIZE // 5))

        # Rate limit bounds
        if self.RATE_LIMIT_PER_TENANT <= 0:
            object.__setattr__(self, "RATE_LIMIT_PER_TENANT", 120)
        if self.RATE_LIMIT_WINDOW_S <= 0:
            object.__setattr__(self, "RATE_LIMIT_WINDOW_S", 60)

        # ========== SECURITY ENFORCEMENT ==========
        # JWT_REQUIRED must be true in production
        if env in {"staging", "production"}:
            object.__setattr__(self, "JWT_REQUIRED", True)
        
        # Generate JWT_SECRET if not provided (security requirement)
        if self.JWT_REQUIRED and not self.JWT_SECRET:
            import secrets
            secret = secrets.token_urlsafe(48)
            object.__setattr__(self, "JWT_SECRET", secret)
            print(f"⚠️  Generated JWT_SECRET: {secret[:20]}... (save this to .env)")

        return self

        # Provider LLM
        if self.LLM_PROVIDER == "openai" and not self.OPENAI_API_KEY:
            if self.STRICT_OPENAI_IN_PROD and env == "production":
                raise RuntimeError(
                    "OPENAI_API_KEY mancante con provider=openai in ENV=production. "
                    "Imposta ZB_OPENAI_API_KEY o setta ZB_STRICT_OPENAI_IN_PROD=false per fallback 'mock'."
                )
            object.__setattr__(self, "LLM_PROVIDER", "mock")

        if self.LLM_PROVIDER not in {"openai", "mock"}:
            object.__setattr__(self, "LLM_PROVIDER", "mock")

        # FRONTEND_BASE_URL auto-guess
        if not self.FRONTEND_BASE_URL:
            fe_guess = os.getenv("GRADIO_URL") or os.getenv("SPACE_URL")
            if fe_guess:
                object.__setattr__(self, "FRONTEND_BASE_URL", fe_guess)

        # UI path coerente
        ui_path = (self.UI_PATH or "/ui").strip()
        if not ui_path.startswith("/"):
            ui_path = "/" + ui_path
        object.__setattr__(self, "UI_PATH", ui_path)

        return self

    # ---------- Helpers ----------
    def is_prod(self) -> bool:
        return self.ENV == "production"

    def is_dev(self) -> bool:
        return self.ENV == "development"

    def is_staging(self) -> bool:
        return self.ENV == "staging"

    def safe_dict(self) -> Dict[str, Any]:
        data = self.model_dump()
        for k in [
            "OPENAI_API_KEY",
            "TWILIO_AUTH_TOKEN",
            "QDRANT_API_KEY",
            "APP_API_KEY",
            "JWT_SECRET",
            "TWILIO_ACCOUNT_SID",
        ]:
            if k in data and data[k]:
                data[k] = "***"
        return data

    def summary(self) -> str:
        return (
            f"{self.APP_NAME} v{self.VERSION}\n"
            f"ENV={self.ENV} DEBUG={self.DEBUG} LOG_LEVEL={self.LOG_LEVEL}\n"
            f"Backend={self.BACKEND_BASE_URL}  Frontend={self.FRONTEND_BASE_URL or '-'}  UI_PATH={self.UI_PATH}\n"
            f"LLM_PROVIDER={self.LLM_PROVIDER}  MODEL={self.LLM_MODEL}  DEMO_MODE={self.DEMO_MODE}  TEST_MODE={self.TEST_MODE}\n"
            f"JWT_REQUIRED={self.JWT_REQUIRED}  RATE_LIMIT={self.RATE_LIMIT_PER_TENANT}/{self.RATE_LIMIT_WINDOW_S}s\n"
            f"RAG={self.RAG_BACKEND} (top_k={self.RAG_TOP_K}, chunk={self.RAG_CHUNK_SIZE}/{self.RAG_OVERLAP})\n"
            f"CORS_ORIGINS={self.CORS_ORIGINS}\n"
        )

    # ---------- Compat layer ----------
    def __getattr__(self, name: str) -> Any:
        alias = type(self)._ALIASES.get(name)
        if alias:
            if alias in self.__dict__:
                return self.__dict__[alias]
            try:
                return object.__getattribute__(self, alias)
            except AttributeError:
                pass

        upper = name.upper()
        if upper in self.__dict__:
            return self.__dict__[upper]
        try:
            return object.__getattribute__(self, upper)
        except AttributeError:
            raise AttributeError(f"{type(self).__name__!r} object has no attribute {name!r}")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings with fallback for parsing errors"""
    try:
        return Settings()
    except Exception as e:
        # Fallback: create with minimal/safe defaults if parsing fails
        # This can happen with Pydantic v2 Settings JSON parsing issues
        print(f"⚠️  Settings parsing error: {str(e)[:100]}. Using fallback config.")
        
        # Create a minimal safe config
        class FallbackSettings(BaseSettings):
            APP_NAME: str = "ZephyBloom CFO API"
            ENV: str = "production"
            DEBUG: bool = False
            LOG_LEVEL: str = "INFO"
            CORS_ORIGINS: str = "*"
            CORS_HEADERS: str = "*"
            CORS_METHODS: str = "*"
            CORS_ALLOW_CREDENTIALS: bool = True
            CORS_EXPOSE_HEADERS: str = ""
            model_config = SettingsConfigDict(extra="ignore")
        
        return FallbackSettings()  # type: ignore


settings = get_settings()