Se usi il rules engine gerarchico, avvia il router con:
  NLPRouter(rules_dir='content/knowledge/rules', intents_dir='content/nlp/intents')
