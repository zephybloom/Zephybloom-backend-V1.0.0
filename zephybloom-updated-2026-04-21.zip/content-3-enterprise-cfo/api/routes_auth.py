"""
Authentication and tenant management routes.

Complete auth flow:
- User registration
- Login (JWT token)
- API key management
- Tenant management
"""

from __future__ import annotations
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status, Header
from sqlalchemy.orm import Session

from db.session import get_session
from db.models import User, Tenant, APIKey
from api.auth_service import AuthService, log_audit
from api.schemas_validation import (
    UserRegisterRequest,
    UserLoginRequest,
    UserLoginResponse,
    APIKeyCreateRequest,
    APIKeyResponse,
    ErrorResponse,
)
from api.tenant_context import (
    get_tenant_context,
    TenantContext,
    get_verified_tenant,
    require_auth,
    get_current_user,
)

router = APIRouter(prefix="/auth", tags=["authentication"])


# ============================================
# Registration
# ============================================
@router.post(
    "/register",
    response_model=dict,
    responses={
        422: {"model": ErrorResponse, "description": "Validation error"},
        409: {"model": ErrorResponse, "description": "Email already exists"},
    },
)
def register(
    request: UserRegisterRequest,
    db: Session = Depends(get_session),
):
    """
    Register a new user.

    - **email**: Unique email address
    - **password**: Min 8 chars, must contain uppercase + digit
    - **full_name**: Full name
    """
    # Check if user exists
    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email already registered"
        )

    # Hash password & create user
    password_hash = AuthService.hash_password(request.password)
    user = User(
        email=request.email,
        password_hash=password_hash,
        full_name=request.full_name,
        role="user",
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Create default tenant for user
    tenant = Tenant(
        id=request.email.split("@")[0].lower(),
        name=request.full_name,
        owner_id=user.id,
        is_active=True,
    )
    db.add(tenant)
    db.commit()

    # Log audit
    try:
        log_audit(
            db,
            action="user_registered",
            endpoint="/auth/register",
            method="POST",
            status_code=201,
            response_time_ms=0,
        )
    except Exception:
        pass

    return {
        "status": "success",
        "user_id": user.id,
        "email": user.email,
        "tenant_id": tenant.id,
        "message": "User registered successfully. API key required for full access.",
    }


# ============================================
# Login
# ============================================
@router.post(
    "/login",
    response_model=UserLoginResponse,
    responses={
        401: {"model": ErrorResponse, "description": "Invalid credentials"},
    },
)
def login(
    request: UserLoginRequest,
    db: Session = Depends(get_session),
):
    """
    User login with email and password.

    Returns JWT access token valid for 24 hours.
    """
    user = db.query(User).filter(User.email == request.email).first()

    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    # Verify password
    try:
        AuthService.verify_password(request.password, user.password_hash)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    # Get primary tenant
    tenant = db.query(Tenant).filter(Tenant.owner_id == user.id).first()
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="User tenant not found",
        )

    # Create JWT token
    token = AuthService.create_access_token(
        user_id=user.id,
        tenant_id=tenant.id,
        expires_hours=24,
    )

    # Log audit
    try:
        log_audit(
            db,
            action="user_login",
            endpoint="/auth/login",
            method="POST",
            status_code=200,
            response_time_ms=0,
        )
    except Exception:
        pass

    return UserLoginResponse(
        access_token=token,
        token_type="bearer",
        expires_in=86400,  # 24 hours in seconds
        user_id=user.id,
        tenant_id=tenant.id,
    )


# ============================================
# API Key Management
# ============================================
@router.post(
    "/api-keys",
    response_model=APIKeyResponse,
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
    },
)
def create_api_key(
    request: APIKeyCreateRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
):
    """
    Create a new API key for programmatic access.

    Plain key is returned only once - save it securely.
    Used in subsequent API calls via X-API-Key header.
    """
    if not tenant.user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User information not available",
        )

    # Create API key
    plain_key, masked_key, api_key = AuthService.create_api_key(
        db=db,
        user_id=tenant.user_id,
        tenant_id=tenant.tenant_id,
        name=request.name,
        rate_limit_per_minute=request.rate_limit_per_minute,
        expires_in_days=request.expires_in_days,
    )

    # Log audit
    try:
        log_audit(
            db,
            action="api_key_created",
            endpoint="/auth/api-keys",
            method="POST",
            status_code=200,
            response_time_ms=0,
            user_id=tenant.user_id,
            tenant_id=tenant.tenant_id,
        )
    except Exception:
        pass

    return APIKeyResponse(
        id=api_key.id,
        key=plain_key,  # Only shown once
        name=api_key.name,
        rate_limit_per_minute=api_key.rate_limit_per_minute,
        created_at=api_key.created_at,
        expires_at=api_key.expires_at,
    )


@router.get(
    "/api-keys",
    response_model=list[APIKeyResponse],
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
    },
)
def list_api_keys(
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
):
    """List all API keys for current user (masked)."""
    if not tenant.user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User information not available",
        )

    keys = db.query(APIKey).filter(
        APIKey.user_id == tenant.user_id,
        APIKey.tenant_id == tenant.tenant_id,
    ).all()

    return [
        APIKeyResponse(
            id=k.id,
            key=f"sk_...{k.key[-4:]}",  # Masked key
            name=k.name,
            rate_limit_per_minute=k.rate_limit_per_minute,
            created_at=k.created_at,
            expires_at=k.expires_at,
        )
        for k in keys
    ]


@router.delete(
    "/api-keys/{key_id}",
    response_model=dict,
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
        404: {"model": ErrorResponse, "description": "Key not found"},
    },
)
def delete_api_key(
    key_id: int,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
):
    """Delete an API key."""
    if not tenant.user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User information not available",
        )

    key = db.query(APIKey).filter(
        APIKey.id == key_id,
        APIKey.user_id == tenant.user_id,
    ).first()

    if not key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="API key not found",
        )

    db.delete(key)
    db.commit()

    # Log audit
    try:
        log_audit(
            db,
            action="api_key_deleted",
            endpoint=f"/auth/api-keys/{key_id}",
            method="DELETE",
            status_code=200,
            response_time_ms=0,
            user_id=tenant.user_id,
            tenant_id=tenant.tenant_id,
        )
    except Exception:
        pass

    return {"status": "success", "message": "API key deleted"}


# ============================================
# Tenant Management
# ============================================
@router.get(
    "/tenant",
    response_model=dict,
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
    },
)
def get_tenant_info(
    tenant: TenantContext = Depends(get_verified_tenant),
    db: Session = Depends(get_session),
):
    """Get current tenant information."""
    tenant_record = db.query(Tenant).filter(Tenant.id == tenant.tenant_id).first()

    if not tenant_record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found",
        )

    return {
        "id": tenant_record.id,
        "name": tenant_record.name,
        "description": tenant_record.description,
        "owner_id": tenant_record.owner_id,
        "is_active": tenant_record.is_active,
        "created_at": tenant_record.created_at,
        "updated_at": tenant_record.updated_at,
    }


@router.post(
    "/tenant",
    response_model=dict,
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
        403: {"model": ErrorResponse, "description": "Not authorized"},
    },
)
def update_tenant_info(
    update_data: dict,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
):
    """Update tenant information (owner only)."""
    tenant_record = db.query(Tenant).filter(Tenant.id == tenant.tenant_id).first()

    if not tenant_record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found",
        )

    if tenant_record.owner_id != tenant.user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only tenant owner can update settings",
        )

    # Update allowed fields
    if "name" in update_data:
        tenant_record.name = update_data["name"]
    if "description" in update_data:
        tenant_record.description = update_data["description"]

    tenant_record.updated_at = datetime.utcnow()
    db.commit()

    # Log audit
    try:
        log_audit(
            db,
            action="tenant_updated",
            endpoint="/auth/tenant",
            method="POST",
            status_code=200,
            response_time_ms=0,
            user_id=tenant.user_id,
            tenant_id=tenant.tenant_id,
        )
    except Exception:
        pass

    return {
        "status": "success",
        "message": "Tenant updated",
        "tenant_id": tenant_record.id,
    }


# ============================================
# Health Check
# ============================================
@router.get("/health")
def auth_health():
    """Authentication service health check."""
    return {
        "status": "healthy",
        "service": "auth",
        "timestamp": datetime.utcnow().isoformat(),
    }
