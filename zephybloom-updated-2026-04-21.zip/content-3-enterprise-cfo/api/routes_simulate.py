# content/api/routes_simulate.py
from utils.errors import CalculationAppError, from_exception

@router.post("/simulate", response_model=SimulateResponse)
def simulate_route(req: SimulateRequest):
    try:
        kpi, assumptions = simulate(
            req.base,
            req.delta,
            sector=str(req.base.get("sector", "default")),
        )

        meta = {}
        if "_extras" in kpi:
            meta.update(kpi.pop("_extras"))
        if "_diag" in kpi:
            meta["diag"] = kpi.pop("_diag")

        return SimulateResponse(**kpi, meta=meta, assumptions=assumptions)
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore durante la simulazione di scenario",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "simulate",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during scenario simulation")
