"""
Customer onboarding endpoints.

POST /onboarding/register - Create new tenant + admin user + API key
GET /onboarding/status/{tenant_id} - Check onboarding status
"""

from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr
from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session

from db.session import get_session
from db.models import User, Tenant, APIKey, TenantSettings
from api.auth_service import AuthService
from api.tenant_context import get_current_user

import secrets

router = APIRouter(prefix="/onboarding", tags=["onboarding"])


class OnboardingRequest(BaseModel):
    """Customer onboarding request."""
    company_name: str
    admin_email: EmailStr
    admin_password: Optional[str] = None
    phone: Optional[str] = None
    country: Optional[str] = "IT"


class OnboardingResponse(BaseModel):
    """Customer onboarding response."""
    success: bool
    user_id: str
    tenant_id: str
    email: str
    api_key: str
    message: str


class OnboardingStatus(BaseModel):
    """Onboarding status."""
    tenant_id: str
    company_name: str
    admin_email: str
    api_keys_count: int
    created_at: datetime
    is_active: bool


@router.post("/register", response_model=OnboardingResponse)
async def register_customer(
    request: OnboardingRequest,
    db: Session = Depends(get_session)
):
    """
    Register a new customer (tenant + admin user + API key).
    
    This endpoint creates:
    1. User account with admin role
    2. Tenant organization
    3. API key for programmatic access
    4. Default tenant settings
    
    Response includes API key that should be stored securely by customer.
    """
    
    # Generate password if not provided
    admin_password = request.admin_password or secrets.token_urlsafe(16)
    
    try:
        # Check if email already exists
        existing_user = db.query(User).filter(
            User.email == request.admin_email
        ).first()
        
        if existing_user:
            raise HTTPException(
                status_code=409,
                detail=f"Email {request.admin_email} already registered"
            )
        
        # Create user account
        user = User(
            email=request.admin_email,
            password_hash=AuthService.hash_password(admin_password),
            full_name=f"{request.company_name} Admin",
            role="admin",
            is_active=True,
        )
        db.add(user)
        db.flush()  # Get user ID
        
        # Create tenant (use company slug as ID)
        tenant_id = request.company_name.lower().replace(" ", "-")
        
        # Check if tenant already exists
        existing_tenant = db.query(Tenant).filter(
            Tenant.id == tenant_id
        ).first()
        
        if existing_tenant:
            raise HTTPException(
                status_code=409,
                detail=f"Tenant '{tenant_id}' already exists"
            )
        
        tenant = Tenant(
            id=tenant_id,
            name=request.company_name,
            description=f"Tenant for {request.company_name}",
            owner_id=user.id,
            is_active=True,
            phone=request.phone,
            country=request.country,
        )
        db.add(tenant)
        db.flush()
        
        # Create API key
        api_key_value = secrets.token_urlsafe(32)
        api_key = APIKey(
            key=AuthService.hash_password(api_key_value),
            name=f"{request.company_name} Default API Key",
            user_id=user.id,
            tenant_id=tenant_id,
            rate_limit_per_minute=100,
            is_active=True,
        )
        db.add(api_key)
        db.flush()
        
        # Create tenant settings
        tenant_settings = TenantSettings(
            tenant_id=tenant_id,
            rate_limit_per_minute=1000,
            max_concurrent_requests=50,
            enable_kpi_engine=True,
            enable_simulation=True,
            enable_valuation=True,
            enable_whatif=True,
        )
        db.add(tenant_settings)
        
        # Commit
        db.commit()
        
        return OnboardingResponse(
            success=True,
            user_id=user.id,
            tenant_id=tenant_id,
            email=request.admin_email,
            api_key=api_key_value,
            message=f"Customer {request.company_name} onboarded successfully",
        )
        
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Onboarding failed: {str(e)}"
        )


@router.get("/{tenant_id}/status", response_model=OnboardingStatus)
async def get_onboarding_status(
    tenant_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_session)
):
    """Get onboarding status for a tenant."""
    
    # Verify user is admin of this tenant
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    if tenant.owner_id != current_user.id and current_user.role != "superadmin":
        raise HTTPException(
            status_code=403,
            detail="Not authorized to view this tenant"
        )
    
    # Get API keys count
    api_keys_count = db.query(APIKey).filter(
        APIKey.tenant_id == tenant_id,
        APIKey.is_active == True
    ).count()
    
    return OnboardingStatus(
        tenant_id=tenant.id,
        company_name=tenant.name,
        admin_email=db.query(User).filter(
            User.id == tenant.owner_id
        ).first().email,
        api_keys_count=api_keys_count,
        created_at=tenant.created_at,
        is_active=tenant.is_active,
    )


@router.post("/{tenant_id}/api-keys")
async def create_api_key(
    tenant_id: str,
    key_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_session)
):
    """Create additional API key for tenant."""
    
    # Verify user is admin of this tenant
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    if tenant.owner_id != current_user.id and current_user.role != "superadmin":
        raise HTTPException(
            status_code=403,
            detail="Not authorized to manage this tenant"
        )
    
    # Create new API key
    api_key_value = secrets.token_urlsafe(32)
    api_key = APIKey(
        key=AuthService.hash_password(api_key_value),
        name=key_name,
        user_id=current_user.id,
        tenant_id=tenant_id,
        rate_limit_per_minute=100,
        is_active=True,
    )
    
    db.add(api_key)
    db.commit()
    
    return {
        "success": True,
        "api_key": api_key_value,
        "name": key_name,
        "created_at": api_key.created_at,
    }
