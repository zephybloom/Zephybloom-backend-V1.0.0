"""
Rate limiting service using Redis for distributed caching.

Implements:
- Token bucket algorithm per API key
- Per-tenant rate limits
- Fallback to in-memory if Redis unavailable (with LRU eviction)
- Distributed rate limiting across multiple servers

Memory safety:
- In-memory buckets limited to MAX_BUCKETS (10,000)
- LRU eviction when limit exceeded
- Auto cleanup of expired buckets
"""

from __future__ import annotations
import time
import logging
from typing import Dict, Optional
from datetime import datetime
from threading import Lock

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

log = logging.getLogger(__name__)

# Fallback in-memory storage with LRU eviction
MAX_BUCKETS = 10_000
MIN_BUCKETS_CLEANUP = 500  # Cleanup when reaching this
_IN_MEMORY_BUCKETS: Dict[str, Dict] = {}
_BUCKET_LOCK = Lock()


class RateLimiter:
    """Rate limiting with Redis backend and in-memory fallback."""

    def __init__(self, redis_url: Optional[str] = None):
        """
        Initialize rate limiter.
        
        Args:
            redis_url: Redis connection URL (e.g., "redis://localhost:6379/0")
                      If None, uses in-memory storage (single-server only)
        """
        self.redis_available = False
        self.redis_client = None
        
        if redis_url and REDIS_AVAILABLE:
            try:
                self.redis_client = redis.from_url(redis_url, decode_responses=True)
                self.redis_client.ping()
                self.redis_available = True
            except Exception:
                # Fallback to in-memory if Redis fails
                pass

    def check_rate_limit(
        self,
        key: str,
        limit: int,
        window_seconds: int = 60,
    ) -> Dict[str, any]:
        """
        Check if request is within rate limit.
        
        Args:
            key: Identifier (API key hash, tenant_id, or user_id)
            limit: Max requests allowed in window
            window_seconds: Time window in seconds
            
        Returns:
            {
                "allowed": bool,
                "remaining": int,
                "reset_in_seconds": int,
                "limit": int,
            }
        """
        if self.redis_available:
            return self._check_redis(key, limit, window_seconds)
        else:
            return self._check_memory(key, limit, window_seconds)

    def _check_redis(self, key: str, limit: int, window_seconds: int) -> Dict[str, any]:
        """Check rate limit using Redis."""
        now = int(time.time())
        window_key = f"ratelimit:{key}:{now // window_seconds}"
        
        try:
            # Increment counter
            count = self.redis_client.incr(window_key)
            
            # Set expiry if first request
            if count == 1:
                self.redis_client.expire(window_key, window_seconds + 1)
            
            # Get TTL for remaining time
            ttl = self.redis_client.ttl(window_key)
            reset_in = max(0, ttl)
            
            allowed = count <= limit
            remaining = max(0, limit - count)
            
            return {
                "allowed": allowed,
                "remaining": remaining,
                "reset_in_seconds": reset_in,
                "limit": limit,
            }
        except Exception:
            # Fail open - allow request if Redis fails
            return {
                "allowed": True,
                "remaining": limit,
                "reset_in_seconds": window_seconds,
                "limit": limit,
            }

    def _check_memory(self, key: str, limit: int, window_seconds: int) -> Dict[str, any]:
        """Check rate limit using in-memory storage (single-server only)."""
        now = int(time.time())
        window_start = (now // window_seconds) * window_seconds
        
        bucket_key = f"{key}:{window_start}"
        
        with _BUCKET_LOCK:
            # Clean up expired buckets periodically
            if len(_IN_MEMORY_BUCKETS) >= MIN_BUCKETS_CLEANUP:
                self._cleanup_expired_buckets(window_seconds)
            
            # LRU eviction if at capacity
            if len(_IN_MEMORY_BUCKETS) >= MAX_BUCKETS:
                # Remove least recently used bucket
                oldest_key = min(
                    _IN_MEMORY_BUCKETS.keys(),
                    key=lambda k: _IN_MEMORY_BUCKETS[k].get("last_accessed", 0)
                )
                evicted = _IN_MEMORY_BUCKETS.pop(oldest_key)
                log.warning(
                    f"Rate limiter: LRU eviction - removed bucket {oldest_key}, "
                    f"total buckets now {len(_IN_MEMORY_BUCKETS)}"
                )
            
            # Update or create bucket
            if bucket_key not in _IN_MEMORY_BUCKETS:
                _IN_MEMORY_BUCKETS[bucket_key] = {
                    "count": 1,
                    "window_start": window_start,
                    "last_accessed": now,
                }
            else:
                _IN_MEMORY_BUCKETS[bucket_key]["count"] += 1
                _IN_MEMORY_BUCKETS[bucket_key]["last_accessed"] = now
            
            count = _IN_MEMORY_BUCKETS[bucket_key]["count"]
        
        reset_in = window_seconds - (now - window_start)
        allowed = count <= limit
        remaining = max(0, limit - count)
        
        return {
            "allowed": allowed,
            "remaining": remaining,
            "reset_in_seconds": reset_in,
            "limit": limit,
        }
    
    def _cleanup_expired_buckets(self, window_seconds: int) -> None:
        """Remove expired buckets to prevent unbounded growth."""
        now = int(time.time())
        threshold = now - (window_seconds * 2)  # Keep 2 windows
        
        expired_keys = [
            k for k, v in _IN_MEMORY_BUCKETS.items()
            if v.get("window_start", now) < threshold
        ]
        
        for k in expired_keys:
            del _IN_MEMORY_BUCKETS[k]
        
        if expired_keys:
            log.debug(f"Rate limiter: Cleaned {len(expired_keys)} expired buckets")

    def reset_limit(self, key: str):
        """Reset rate limit for a key (admin operation)."""
        if self.redis_available:
            try:
                # Clear all windows for this key
                cursor = 0
                while True:
                    cursor, keys = self.redis_client.scan(
                        cursor,
                        match=f"ratelimit:{key}:*",
                        count=100,
                    )
                    if keys:
                        self.redis_client.delete(*keys)
                    if cursor == 0:
                        break
            except Exception:
                pass
        else:
            # In-memory cleanup
            keys_to_delete = [k for k in _IN_MEMORY_BUCKETS if k.startswith(f"{key}:")]
            for k in keys_to_delete:
                del _IN_MEMORY_BUCKETS[k]


# Global rate limiter instance
_rate_limiter: Optional[RateLimiter] = None


def init_rate_limiter(redis_url: Optional[str] = None) -> RateLimiter:
    """Initialize global rate limiter (call in main.py startup)."""
    global _rate_limiter
    _rate_limiter = RateLimiter(redis_url)
    return _rate_limiter


def get_rate_limiter() -> RateLimiter:
    """Get global rate limiter instance."""
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = RateLimiter()
    return _rate_limiter
