"""
CFO Advanced Endpoints - /cfo/analyze-advanced, /cfo/segment-analysis, /cfo/sensitivity

Enterprise-grade analysis with:
- Benchmarking vs industry
- Trend analysis (CAGR, growth rates)
- DuPont decomposition
- Sensitivity analysis
- Segment performance breakdown
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import Optional, List, Dict
from datetime import date

from api.schemas_cfo_advanced import (
    AnalyzeRequestAdvanced, AnalyzeAdvancedResponse,
    TrendAnalysis, BenchmarkComparison, DupontAnalysis,
)
from api.tenant_context import require_auth, TenantContext

from core.benchmarking import BenchmarkingEngine
from core.timeseries import TimeSeriesAnalysis, extract_trends_from_api_request, build_trend_data_from_historicals, TrendPoint
from core.dupont import DupontEngine
from core.sensitivity import SensitivityAnalysis

# ============================================
# ROUTER SETUP
# ============================================

router = APIRouter(
    prefix="/cfo",
    tags=["cfo-advanced"],
    responses={
        401: {"model": Dict, "description": "Not authenticated"},
        400: {"model": Dict, "description": "Invalid request"},
        500: {"model": Dict, "description": "Analysis error"},
    }
)


# ============================================
# ENDPOINT 1: /cfo/analyze-advanced
# ============================================

@router.post(
    "/analyze-advanced",
    response_model=AnalyzeAdvancedResponse,
    summary="Advanced Financial Analysis",
    description="Enterprise-grade analysis with benchmarking, trends, DuPont decomposition, and sensitivity",
)
def cfo_analyze_advanced(
    request: AnalyzeRequestAdvanced,
    tenant: TenantContext = Depends(require_auth),
) -> AnalyzeAdvancedResponse:
    """
    Advanced CFO analysis with rich data
    
    Supports:
    - Historical KPI time series (3-5 years)
    - Revenue breakdown by segment
    - Benchmarking vs industry
    - Trend analysis (CAGR, growth rates)
    - DuPont decomposition (what drives ROA/ROE)
    - Sensitivity analysis
    - Customer concentration risk
    
    Returns comprehensive analysis with strategic insights
    """
    
    try:
        # ===== INPUT VALIDATION =====
        if request.fatturato <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Fatturato must be positive",
            )
        
        # ===== CURRENT KPI SNAPSHOT =====
        current_kpis = _compute_current_kpis(
            fatturato=request.fatturato,
            costi_variabili=request.costi_variabili,
            costi_fissi=request.costi_fissi,
            total_assets=request.total_assets,
            equity=request.equity,
        )
        
        # ===== BENCHMARKING =====
        benchmark_comparisons = []
        if request.industry_benchmark or request.settore:
            benchmark_comparisons = _compute_benchmarks(
                your_metrics=current_kpis,
                sector=request.settore,
            )
        
        # ===== TREND ANALYSIS =====
        trends = []
        if request.historicals:
            trends = _compute_trends(historicals=request.historicals)
        
        # ===== DUPONT ANALYSIS =====
        dupont = None
        if request.total_assets and request.equity:
            dupont = _compute_dupont(
                net_profit=current_kpis.get("net_profit", 0),
                total_assets=request.total_assets,
                equity=request.equity,
                revenue=request.fatturato,
            )
        
        # ===== SEGMENT PERFORMANCE =====
        segment_performance = None
        if request.revenue_segments:
            segment_performance = _compute_segment_performance(
                segments=request.revenue_segments,
                total_revenue=request.fatturato,
            )
        
        # ===== CONCENTRATION RISK =====
        concentration_risk = None
        if request.customer_concentration:
            concentration_risk = _assess_concentration_risk(
                request.customer_concentration
            )
        
        # ===== SIMPLE HEALTH STATUS =====
        net_margin_pct = current_kpis.get("net_margin_pct", 0)
        if net_margin_pct < 0:
            status_val = "critical"
        elif net_margin_pct < 5:
            status_val = "warning"
        else:
            status_val = "healthy"
        
        # ===== HEADLINE & SUMMARY =====
        headline, summary = _create_advanced_messaging(
            status=status_val,
            current_kpis=current_kpis,
            benchmarks=benchmark_comparisons,
            dupont=dupont,
            concentration_risk=concentration_risk,
        )
        
        # ===== BUILD RESPONSE =====
        return AnalyzeAdvancedResponse(
            status=status_val,
            headline=headline,
            summary=summary,
            kpi_snapshot=current_kpis,
            benchmark_comparisons=benchmark_comparisons,
            trends=trends,
            dupont=dupont,
            segment_performance=segment_performance,
            concentration_risk=concentration_risk,
            recommended_actions=[],  # TODO: Generate from analysis
            estimated_loss_eur=0.0,  # TODO
            potential_recovery_eur=0.0,  # TODO
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Advanced analysis error: {str(e)}",
        )


# ============================================
# ENDPOINT 2: /cfo/segment-analysis
# ============================================

@router.post(
    "/segment-analysis",
    summary="Revenue Segment Analysis",
    description="Detailed performance breakdown by customer segment, product line, or geography",
)
def cfo_segment_analysis(
    request: AnalyzeRequestAdvanced,
    tenant: TenantContext = Depends(require_auth),
) -> Dict:
    """
    Analyze performance by revenue segment
    
    Identifies:
    - Highest margin segments
    - Fastest growing segments
    - Retention/churn by segment
    - Opportunity gaps
    """
    
    try:
        if not request.revenue_segments:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No segment data provided",
            )
        
        segment_analysis = _compute_segment_performance(
            segments=request.revenue_segments,
            total_revenue=request.fatturato,
        )
        
        return {
            "segments": segment_analysis,
            "insights": _generate_segment_insights(
                segments=request.revenue_segments,
                total_revenue=request.fatturato,
            ),
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Segment analysis error: {str(e)}",
        )


# ============================================
# ENDPOINT 3: /cfo/sensitivity
# ============================================

@router.post(
    "/sensitivity",
    summary="Sensitivity Analysis",
    description="What-if analysis: impact of changes in revenue, costs, prices",
)
def cfo_sensitivity(
    request: AnalyzeRequestAdvanced,
    tenant: TenantContext = Depends(require_auth),
) -> Dict:
    """
    Sensitivity analysis: how do changes in key variables affect profit?
    
    Simulates:
    - Revenue ±10%
    - Variable costs ±5%
    - Fixed costs ±10%
    - Prices ±5%
    
    Shows tornado chart of which variables matter most
    """
    
    try:
        # Build tornado chart
        tornado_data = SensitivityAnalysis.build_tornado(
            base_revenue=request.fatturato,
            base_variable_costs=request.costi_variabili,
            base_fixed_costs=request.costi_fissi,
        )
        
        # Get insights
        insights = SensitivityAnalysis.get_sensitivity_insights(
            base_revenue=request.fatturato,
            base_variable_costs=request.costi_variabili,
            base_fixed_costs=request.costi_fissi,
        )
        
        # Rank by sensitivity
        ranked = SensitivityAnalysis.rank_by_sensitivity(tornado_data)
        
        return {
            "tornado": {
                var: {
                    "upside_impact_eur": data.upside_impact_eur,
                    "downside_impact_eur": data.downside_impact_eur,
                    "total_range": data.total_range,
                }
                for var, data in tornado_data.items()
            },
            "sensitivity_ranking": [
                {"variable": var, "impact_range": impact}
                for var, impact in ranked
            ],
            "insights": insights,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Sensitivity analysis error: {str(e)}",
        )


# ============================================
# HELPER FUNCTIONS
# ============================================

def _compute_current_kpis(
    fatturato: float,
    costi_variabili: float,
    costi_fissi: float,
    total_assets: Optional[float] = None,
    equity: Optional[float] = None,
) -> Dict:
    """Compute current KPI snapshot"""
    
    gross_profit = fatturato - costi_variabili
    gross_margin_pct = (gross_profit / fatturato * 100) if fatturato > 0 else 0
    
    ebitda = gross_profit - costi_fissi
    ebitda_margin_pct = (ebitda / fatturato * 100) if fatturato > 0 else 0
    
    net_profit = ebitda  # Simplified
    net_margin_pct = (net_profit / fatturato * 100) if fatturato > 0 else 0
    
    return {
        "fatturato": round(fatturato, 2),
        "costi_variabili": round(costi_variabili, 2),
        "costi_fissi": round(costi_fissi, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_margin_pct": round(gross_margin_pct, 2),
        "ebitda": round(ebitda, 2),
        "ebitda_margin_pct": round(ebitda_margin_pct, 2),
        "net_profit": round(net_profit, 2),
        "net_margin_pct": round(net_margin_pct, 2),
        "total_assets": round(total_assets, 2) if total_assets else None,
        "equity": round(equity, 2) if equity else None,
    }


def _compute_benchmarks(
    your_metrics: Dict,
    sector: str,
) -> List[BenchmarkComparison]:
    """Compute benchmark comparisons"""
    
    engine = BenchmarkingEngine(sector=sector)
    comparisons_data = engine.full_comparison(your_metrics)
    
    result = []
    for metric, comp_data in comparisons_data.items():
        result.append(BenchmarkComparison(
            metric_name=metric,
            your_value=round(comp_data["your_value"], 2),
            benchmark_median=round(comp_data["benchmark_value"], 2),
            percentile_rank=round(comp_data["percentile_rank"], 1),
            gap_to_median_pct=round(comp_data["gap_pct"], 1),
        ))
    
    return result


def _compute_trends(historicals: List[Dict]) -> List[TrendAnalysis]:
    """Compute trend analysis for metrics"""
    
    trend_data = extract_trends_from_api_request(historicals)
    
    if not trend_data:
        return []
    
    results = TimeSeriesAnalysis.analyze_multiple_metrics(trend_data)
    
    output = []
    for metric_name, trend_result in results.items():
        output.append(TrendAnalysis(
            metric_name=metric_name,
            periods=trend_result.num_periods,
            cagr_pct=trend_result.cagr_pct,
            yoy_growth_pct=trend_result.latest_growth_pct,
            trend_direction=trend_result.trend_direction,
            volatility_pct=trend_result.volatility_pct,
        ))
    
    return output


def _compute_dupont(
    net_profit: float,
    total_assets: float,
    equity: float,
    revenue: float,
) -> Optional[DupontAnalysis]:
    """Compute DuPont decomposition"""
    
    if not total_assets or not equity:
        return None
    
    dupont_result = DupontEngine.decompose(net_profit, revenue, total_assets, equity)
    
    return DupontAnalysis(
        roa_pct=dupont_result.roa_pct,
        roe_pct=dupont_result.roe_pct,
        net_margin_pct=dupont_result.net_margin_pct,
        asset_turnover=dupont_result.asset_turnover,
        financial_leverage=dupont_result.financial_leverage,
        margin_contribution_pct=dupont_result.margin_contribution_pct,
        turnover_contribution_pct=dupont_result.turnover_contribution_pct,
        leverage_contribution_pct=dupont_result.leverage_contribution_pct,
    )


def _compute_segment_performance(segments: List[Dict], total_revenue: float) -> Dict:
    """Analyze segment performance"""
    
    segment_analysis = {}
    for seg in segments:
        seg_name = seg.get("segment_name", "Unknown")
        seg_revenue = seg.get("fatturato", 0)
        seg_margin = seg.get("margin_pct", 0)
        
        segment_analysis[seg_name] = {
            "revenue": round(seg_revenue, 2),
            "revenue_proportion_pct": round((seg_revenue / total_revenue * 100) if total_revenue > 0 else 0, 1),
            "margin_pct": round(seg_margin, 1),
            "margin_contribution": round(seg_revenue * seg_margin / 100, 2),
            "growth_yoy_pct": round(seg.get("growth_yoy_pct", 0), 1),
            "churn_rate_pct": round(seg.get("churn_rate_pct", 0), 1),
        }
    
    return segment_analysis


def _assess_concentration_risk(concentration_data: Dict) -> str:
    """Assess customer concentration risk"""
    
    top_10_pct = concentration_data.get("top_10_pct_of_revenue", 0)
    single_cust_pct = concentration_data.get("single_customer_concentration_pct", 0)
    
    if single_cust_pct > 20 or top_10_pct > 70:
        return "🔴 HIGH RISK: Revenue is heavily concentrated. Key person/customer risk. Priority: diversify."
    elif single_cust_pct > 10 or top_10_pct > 50:
        return "🟡 MODERATE RISK: Some concentration detected. Monitor top customers closely."
    else:
        return "🟢 LOW RISK: Revenue is well-diversified across customer base."


def _generate_segment_insights(segments: List[Dict], total_revenue: float) -> List[str]:
    """Generate insights about segment performance"""
    
    insights = []
    
    # Find highest margin segment
    if segments:
        highest_margin_seg = max(segments, key=lambda s: s.get("margin_pct", 0))
        insights.append(f"Highest-margin segment: {highest_margin_seg.get('segment_name')} ({highest_margin_seg.get('margin_pct', 0):.0f}%)")
    
    # Find fastest growing
    fastest_growing = max(segments, key=lambda s: s.get("growth_yoy_pct", 0))
    if fastest_growing.get("growth_yoy_pct", 0) > 0:
        insights.append(f"Fastest growing: {fastest_growing.get('segment_name')} (+{fastest_growing.get('growth_yoy_pct', 0):.0f}% YoY)")
    
    # Alert on high churn
    for seg in segments:
        if seg.get("churn_rate_pct", 0) > 10:
            insights.append(f"⚠️ High churn in {seg.get('segment_name')}: {seg.get('churn_rate_pct', 0):.0f}% / period")
    
    return insights


def _create_advanced_messaging(
    status: str,
    current_kpis: Dict,
    benchmarks: List[BenchmarkComparison],
    dupont: Optional[DupontAnalysis],
    concentration_risk: Optional[str],
) -> tuple:
    """Create headline and summary for advanced analysis"""
    
    headline = "Financial Analysis"
    
    if status == "critical":
        headline = "🔴 Critical: Immediate Action Required"
    elif status == "warning":
        headline = "🟡 Warning: Performance Below Healthy Levels"
    else:
        headline = "🟢 Healthy Financial Position"
    
    summary = f"Net margin: {current_kpis.get('net_margin_pct', 0):.1f}%. "
    
    if dupont and dupont.primary_driver:
        summary += f"Profitability driven by {dupont.primary_driver}. "
    
    if concentration_risk:
        summary += f"{concentration_risk} "
    
    return headline, summary
