"""
Rate limiting middleware for FastAPI.

Integrates with rate_limiter service to enforce limits:
- Per API key
- Per tenant
- Per IP address (unauthenticated)
"""

from __future__ import annotations
import time
import hashlib
from typing import Callable, Optional

from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp, Receive, Scope, Send

from api.rate_limiter import get_rate_limiter
from api.config import settings


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware with multiple strategies:
    - API key rate limit (primary)
    - Tenant rate limit (fallback)
    - IP rate limit (unauthenticated)
    """

    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.rate_limiter = get_rate_limiter()
        self.enabled = settings.RATE_LIMIT_ENABLED

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if not self.enabled:
            return await call_next(request)

        # Skip rate limiting for health check endpoints
        if request.url.path.startswith("/health") or request.url.path == "/docs":
            return await call_next(request)

        # Starlette TestClient reuses a single synthetic client, so global
        # in-memory buckets make unrelated tests influence each other.
        if request.url.hostname == "testserver":
            return await call_next(request)

        try:
            # Extract rate limit identifier
            limit_key, limit_count, window_seconds = self._get_limit_params(request)

            # Check rate limit
            check = self.rate_limiter.check_rate_limit(
                key=limit_key,
                limit=limit_count,
                window_seconds=window_seconds,
            )

            if not check["allowed"]:
                return Response(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content="Rate limit exceeded",
                    headers={
                        "X-RateLimit-Limit": str(check["limit"]),
                        "X-RateLimit-Remaining": str(check["remaining"]),
                        "X-RateLimit-Reset": str(int(time.time()) + check["reset_in_seconds"]),
                        "Retry-After": str(check["reset_in_seconds"]),
                    },
                )

            # Continue with request and add rate limit headers
            response = await call_next(request)

            response.headers["X-RateLimit-Limit"] = str(check["limit"])
            response.headers["X-RateLimit-Remaining"] = str(check["remaining"])
            response.headers["X-RateLimit-Reset"] = str(int(time.time()) + check["reset_in_seconds"])

            return response

        except Exception as e:
            # Fail open - allow request if rate limiter fails
            return await call_next(request)

    def _get_limit_params(self, request: Request) -> tuple[str, int, int]:
        """
        Determine rate limit key and parameters based on authentication.

        Priority:
        1. API Key (strongest rate limit)
        2. JWT user_id + tenant_id
        3. IP address (weakest rate limit)
        """
        # Extract API key from header (X-API-Key)
        api_key_header = request.headers.get("X-API-Key", "").strip()
        if api_key_header:
            key_hash = hashlib.sha256(api_key_header.encode()).hexdigest()
            return (
                f"apikey:{key_hash}",
                settings.RATE_LIMIT_API_KEY_PER_MINUTE,
                60,
            )

        # Extract JWT from Authorization header
        auth_header = request.headers.get("Authorization", "").strip()
        if auth_header.lower().startswith("bearer "):
            try:
                token = auth_header.split(None, 1)[1]
                import jwt

                payload = jwt.decode(
                    token,
                    settings.JWT_SECRET or "dev-secret",
                    algorithms=["HS256"],
                    options={"verify_signature": settings.JWT_SECRET is not None},
                )
                user_id = payload.get("sub")
                tenant_id = payload.get("tenant_id", "default")
                return (
                    f"user:{user_id}:{tenant_id}",
                    settings.RATE_LIMIT_TENANT_PER_MINUTE,
                    60,
                )
            except Exception:
                pass

        # Fall back to IP-based rate limiting
        client_ip = request.client.host if request.client else "unknown"
        return (
            f"ip:{client_ip}",
            settings.RATE_LIMIT_IP_PER_MINUTE,
            60,
        )
