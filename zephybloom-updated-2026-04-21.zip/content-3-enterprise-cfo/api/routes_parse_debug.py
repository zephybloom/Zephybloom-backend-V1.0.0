# -*- coding: utf-8 -*-
# content/api/routes_parse_debug.py — NL → slot extractor + normalize (pro)
from __future__ import annotations
import re
from typing import Any, Dict, Tuple, Optional

from fastapi import APIRouter
from api.schemas import ParseDebugRequest
from core.validators import normalize_context_numeric

router = APIRouter(tags=["debug"])

# --------------------------------------------------------------------
# Helpers numerici: EU/EN, valute, suffissi (k / mln / m / mld / bn)
# --------------------------------------------------------------------
_KMB = {"k": 1_000, "m": 1_000_000, "mln": 1_000_000, "million": 1_000_000,
        "bn": 1_000_000_000, "mld": 1_000_000_000}

def _clean_num_txt(s: str) -> str:
    s = (s or "")
    s = s.replace("€", "").replace("euro", "").replace("EUR", "")
    s = s.replace(" ", "")
    # caso EU: "1.234.567,89" → "1234567.89"
    s = s.replace(".", "")
    s = s.replace(",", ".")
    return s

def _to_float(s: str) -> float:
    try:
        return float(_clean_num_txt(s))
    except Exception:
        return 0.0

def _apply_suffix(val: float, suf: Optional[str]) -> float:
    if not suf:
        return val
    m = _KMB.get(suf.strip().lower())
    return val * m if m else val

def _num_kmb(num_s: str, suf_s: Optional[str]) -> float:
    return _apply_suffix(_to_float(num_s), suf_s)

# --------------------------------------------------------------------
# Pattern: percentuali e numeri con suffisso
# --------------------------------------------------------------------
# Esempi catturati: "3", "3%", "+3%", "- 1,5 %"
_PCT = r"([+-]?\s*\d+(?:[.,]\d+)?)\s*%?"
# Esempi catturati: "50k", "1.2m", "1,5 mln", "2 mld", "1500000"
_NUM  = r"([+-]?\s*\d+(?:[.,]\d+)?)"
_SUF  = r"(k|K|m|M|mln|MLN|million|bn|BN|mld|MLD)?"
_NUM_SUF = rf"{_NUM}\s*{_SUF}"

# --------------------------------------------------------------------
# Regole NL → slot
#   Ogni regola: (regex, chiave, tipo {pct|abs}, note)
# --------------------------------------------------------------------
_RULES: Tuple[Tuple[re.Pattern, str, str], ...] = (
    # Prezzo (percentuale + assoluto opzionale) — caso "prezzo ... 3%"
    (re.compile(r"(?:prezz\w*|listin\w*|price)\s*(?:medio)?\s*(?:del|di)?\s*" + _PCT, re.I), "price_pct", "pct"),
    (re.compile(r"(?:prezzo\s*medio|avg\s*price)\s*[:=]\s*" + _NUM_SUF, re.I), "prezzo_medio_abs", "abs"),

    # Costi fissi (%, abs)
    (re.compile(r"(?:costi?\s*fiss[ia]).{0,20}?(?:\+|-|riduc|tagli|aument).{0,5}" + _PCT, re.I), "costi_fissi_pct", "pct"),
    (re.compile(r"(?:costi?\s*fiss[ia]).{0,10}?(?:-|\+)?\s*" + _NUM_SUF, re.I), "costi_fissi_abs", "abs"),

    # Costi variabili / COGS (%, abs)
    (re.compile(r"(?:costi?\s*variabil[ie]|cv|cogs).{0,20}?(?:\+|-|riduc|aument).{0,5}" + _PCT, re.I), "costi_variabili_pct", "pct"),
    (re.compile(r"(?:costi?\s*variabil[ie]|cv|cogs)\s*[:=]?\s*" + _NUM_SUF, re.I), "costi_variabili_abs", "abs"),

    # Fatturato / Ricavi (%, abs)
    (re.compile(r"(?:fatturat[oa]|ricav[io]|vendite|sales).{0,20}?(?:\+|-|cresc|aument|riduc).{0,5}" + _PCT, re.I), "fatturato_pct", "pct"),
    (re.compile(r"(?:fatturat[oa]|ricav[io]|vendite|sales)\s*[:=]?\s*" + _NUM_SUF, re.I), "fatturato_abs", "abs"),

    # CVU (assoluto)
    (re.compile(r"(?:cvu|costo\s*variabile\s*unitari[oa]|unit\s*cost)\s*[:=]?\s*" + _NUM_SUF, re.I), "costo_variabile_unitario_abs", "abs"),

    # DSO / DIO / DPO (assoluti in giorni, anche con segno)
    (re.compile(r"\b(dso)\s*[:=]?\s*" + _NUM, re.I), "dso_abs", "abs"),
    (re.compile(r"\b(dio)\s*[:=]?\s*" + _NUM, re.I), "dio_abs", "abs"),
    (re.compile(r"\b(dpo)\s*[:=]?\s*" + _NUM, re.I), "dpo_abs", "abs"),

    # Elasticità prezzo (assoluta, negativa tipicamente)
    (re.compile(r"(?:elasticit[aà]|elasticity|price\s*elasticity)\s*[:=]?\s*" + _NUM, re.I), "price_elasticity", "abs"),
)

# Pattern addizionale: caso "verbo ... prezzo ... 3%" (es. "aumenta il prezzo del 3%")
_PRICE_VERB_FIRST_RX = re.compile(
    r"(?:alz|aument|riduc|abbass|tagli|modific|aggiorn|rived)[^\d%]{0,40}"
    r"(?:prezz\w*|listin\w*|price)[^\d%]{0,40}" + _PCT,
    re.I
)

def _extract_slots(text: str) -> Dict[str, float]:
    """Applica le regole in serie; l'ultima occorrenza vince (override sensato)."""
    slots: Dict[str, float] = {}
    t = text or ""

    # 0) Patch robusta per price_pct con ordine "verbo → prezzo → percentuale"
    mverb = _PRICE_VERB_FIRST_RX.search(t)
    if mverb:
        slots["price_pct"] = float(_to_float(mverb.group(1)))

    # 1) Regole generiche
    for rx, key, kind in _RULES:
        for m in rx.finditer(t):
            if kind == "pct":
                # prendi il primo gruppo numerico del PCT
                val = _to_float(m.group(1))
                slots[key] = float(val)
            else:
                # ABS: cerca NUM + (SUF opzionale)
                groups = m.groups()
                num_s, suf_s = None, None
                # euristica semplice: ultimo numero e ultimo suffisso presenti
                for g in groups[::-1]:
                    if g is None:
                        continue
                    if suf_s is None and re.fullmatch(r"(k|K|m|M|mln|MLN|million|bn|BN|mld|MLD)", g):
                        suf_s = g
                    if num_s is None and re.fullmatch(r"[+-]?\s*\d+(?:[.,]\d+)?", g):
                        num_s = g
                if num_s is None:
                    continue
                slots[key] = float(_num_kmb(num_s, suf_s))
    return slots

# --------------------------------------------------------------------
# Endpoint
# --------------------------------------------------------------------
@router.post("/debug/parse")
def parse_debug(req: ParseDebugRequest):
    """
    Esempi:
      - "Aumenta il prezzo del 3% e riduci i costi fissi di 50k"
        → price_pct=3.0, costi_fissi_abs=50000.0
      - "Porta i ricavi a 1,5 mln e CV a 700k; DSO -10"
        → fatturato_abs=1_500_000, costi_variabili_abs=700_000, dso_abs=-10
    """
    text = (req.text or "")
    slots = _extract_slots(text)

    # Merge: lo slot estratto override-a il contesto
    merged: Dict[str, Any] = dict(req.context or {})
    merged.update(slots)

    # Normalizzazione robusta (alias, %, frazioni, k/mln/mld)
    normalized = normalize_context_numeric(merged)

    return {"slots": slots, "merged": merged, "normalized": normalized}
