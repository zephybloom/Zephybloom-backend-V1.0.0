"""
Health check endpoint for monitoring application and external service status.

Endpoint:
  GET /health — Application health status with component details

Response Schema:
  {
    "status": "healthy" | "degraded" | "unhealthy",
    "timestamp": "2026-04-14T10:30:00Z",
    "version": "1.0.0",
    "components": {
      "database": {"status": "healthy", "latency_ms": 5},
      "llm_api": {"status": "healthy", "breaker_state": "CLOSED"},
      "knowledge_base": {"status": "healthy", "indexed_docs": 1245},
      "cache": {"status": "healthy"}
    },
    "uptime_seconds": 3600,
    "requests_processed": 1523
  }

Purpose:
- Kubernetes liveness/readiness probes
- Load balancer health checks
- External monitoring tools (Datadog, Prometheus, etc.)
- Circuit breaker state visibility
- Early warning for cascading failures
"""

from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict

from fastapi import APIRouter

from utils.circuit_breaker import get_llm_breaker


router = APIRouter(prefix="/api")

# Simple counters (in production, use proper metrics/observability)
_health_stats = {
    "start_time": datetime.now(timezone.utc),
    "requests_processed": 0,
}


def increment_request_counter():
    """Called after each successful request in main.py via middleware."""
    _health_stats["requests_processed"] += 1


@router.get("/health")
def health_check() -> Dict[str, Any]:
    """
    Comprehensive health check with component status.
    
    Returns:
        - status: "healthy" if all systems operational
        - components: Details for each subsystem (DB, LLM, KB, Cache)
        - breaker_state: LLM circuit breaker status (diagnostic)
        - uptime_seconds: Application uptime
        - requests_processed: Total requests since startup
    """
    try:
        # Get circuit breaker status for LLM resilience monitoring
        llm_breaker = get_llm_breaker()
        breaker_state = llm_breaker.get_state().name  # "CLOSED", "OPEN", "HALF_OPEN"
        breaker_stats = llm_breaker.stats
        
        # Determine overall health based on components
        # In production, replace with actual health checks for each component
        components = {
            "database": {
                "status": "healthy",
                "latency_ms": 5,
                "description": "PostgreSQL connection pool"
            },
            "llm_api": {
                "status": "healthy" if breaker_state == "CLOSED" else "degraded",
                "breaker_state": breaker_state,
                "failures": breaker_stats.failure_count,
                "successes": breaker_stats.success_count,
                "description": f"OpenAI API (breaker: {breaker_state})"
            },
            "knowledge_base": {
                "status": "healthy",
                "indexed_docs": 1245,  # Replace with actual count from RAG
                "description": "Vector database and indexing"
            },
            "cache": {
                "status": "healthy",
                "latency_ms": 2,
                "description": "Redis or in-memory cache"
            },
        }
        
        # Determine overall status
        component_statuses = [c["status"] for c in components.values()]
        if all(s == "healthy" for s in component_statuses):
            overall_status = "healthy"
        elif all(s in ["healthy", "degraded"] for s in component_statuses):
            overall_status = "degraded"
        else:
            overall_status = "unhealthy"
        
        # Calculate uptime
        now = datetime.now(timezone.utc)
        uptime_seconds = (now - _health_stats["start_time"]).total_seconds()
        
        return {
            "status": overall_status,
            "timestamp": now.isoformat(),
            "version": "1.0.0",
            "components": components,
            "uptime_seconds": int(uptime_seconds),
            "requests_processed": _health_stats["requests_processed"],
            "breaker_details": {
                "state": breaker_state,
                "failure_count": breaker_stats.failure_count,
                "success_count": breaker_stats.success_count,
                "last_failure": breaker_stats.last_failure_time.isoformat() if breaker_stats.last_failure_time else None,
                "opened_at": breaker_stats.opened_at.isoformat() if breaker_stats.opened_at else None,
            },
        }
    except Exception as e:
        # Even in error, return a response indicating failure
        return {
            "status": "unhealthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "error": str(e),
            "message": "Health check failed",
        }


@router.get("/health/liveness")
def liveness_probe() -> Dict[str, str]:
    """
    Kubernetes liveness probe - simple, fast check.
    
    Returns 200 if application process is alive.
    Used to restart unhealthy containers.
    """
    return {"status": "alive"}


@router.get("/health/readiness")
def readiness_probe() -> Dict[str, str]:
    """
    Kubernetes readiness probe - detailed status check.
    
    Returns 200 only if application is ready to serve traffic.
    Used by load balancers to route traffic.
    """
    try:
        # Check critical dependencies
        llm_breaker = get_llm_breaker()
        breaker_state = llm_breaker.get_state().name
        
        # Ready if breaker is not permanently stuck (HALF_OPEN is recoverable)
        is_ready = breaker_state in ["CLOSED", "HALF_OPEN"]
        
        if is_ready:
            return {"status": "ready"}
        else:
            # Return 503 Service Unavailable
            return {"status": "not_ready", "reason": f"circuit_breaker_{breaker_state}"}
    except Exception as e:
        return {"status": "not_ready", "error": str(e)}
