# content/api/routes_core.py
"""
Core financial analytics endpoints for ZephyBloom CFO API.

Endpoints:
  POST /kpi/compute         — Compute KPIs from context (revenue, COGS, CAPEX, etc.)
  POST /simulate            — Run financial scenarios with delta assumptions
  POST /forecast            — Project P&L and cash flow forward
  POST /valuation           — DCF/equity/WACC valuation
  POST /opportunities       — Diagnose growth opportunities (price, mix, cost)
  POST /montecarlo          — Monte Carlo sensitivity analysis
  POST /pricing/optimize    — Find optimal price given demand elasticity
  POST /pricing/ladder      — Build pricing ladder/tiers
  POST /breakeven           — Calculate break-even quantity and revenue
  POST /wc/impact           — Working capital optimization
  POST /rules/evaluate      — Apply business rules engine
  POST /alerts              — Generate threshold-based alerts
  POST /rag/search          — Search knowledge base
  POST /rag/ingest          — Ingest documents into knowledge base
  GET  /parse/debug         — Debug request parsing/normalization

Security: Requriamenti (su main.py): Optional JWT, rate limiting per tenant.
Config: Via api/config.py, supports multi-tenant context via X-Tenant-Id header.
"""
from __future__ import annotations

import hashlib
import math
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body
from pydantic import BaseModel, ValidationError

from api.config import settings
from utils.coercion import safe_float, safe_int, safe_dict, safe_list, nonneg, ensure_finite
from utils.errors import (
    CalculationAppError,
    ValidationAppError,
    from_exception,
)
from core.metrics import compute_kpis
from core.diagnosis import CFODiagnosisEngine
from core.scenarios_multi import generate_scenarios
from core.roi_calculator import calculate_roi
from core.hiring_engine import analyze_headcount
from core.scenario import simulate
from core.forecast import forecast_series
from core.finance import project_eval, dcf_equity, wacc
from core.montecarlo import mc_scenarios
from advice.opportunities import OpportunityEngine, format_opportunity
from core.validators import normalize_context_numeric
from core.rules_engine import load_rules, evaluate_rules
from nlp.slot_extraction import extract_slots
from tools.breakeven import breakeven_tool
from tools.wc import wc_whatif_tool
import rag.indexer as rag_idx
from rag.indexer import Doc as RAGDoc
from api.schemas import (
    KPIRequest,
    SimulateRequest,
    ForecastRequest,
    ValuationRequest,
    OpportunitiesRequest,
    ParseDebugRequest,
    IngestRequest,
    SearchRequest,
    PriceOptimizeRequest,
    PriceLadderRequest,
    BreakevenRequest,
    WCImpactRequest,
    AlertsRequest,
)

router = APIRouter(tags=["core"])


# =============================================================
# Utilities specifiche a routes_core (non duplicate)
# =============================================================
_NONNEG_KEYS_DEFAULT = [
    "fatturato",
    "sales",
    "ricavi",
    "costi_variabili",
    "costi_fissi",
    "investimenti",
    "ammortamenti",
    "prezzo",
    "prezzo_medio",
    "ricavo_medio",
    "volume",
    "prezzo_ottimale",
    "domanda",
    "ricavi_ottimali",
    "be_qty",
    "be_revenue",
]


def _clamp_non_negative(d: Dict[str, Any], keys: Optional[List[str]] = None) -> Dict[str, Any]:
    """Clamp a ≥ 0 i campi intrinsecamente non-negativi."""
    keys = keys or _NONNEG_KEYS_DEFAULT
    for k in keys:
        if k in d and isinstance(d[k], (int, float)):
            v = safe_float(d[k], 0.0)
            d[k] = max(0.0, v)
    return d


def _sanitize_output_numbers(d: Dict[str, Any]) -> Dict[str, Any]:
    for k, v in list(d.items()):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            d[k] = 0.0
    return d


def _safe_settings_summary() -> Dict[str, Any]:
    try:
        return settings.summary() if hasattr(settings, "summary") else {}
    except Exception:
        return {}


def _safe_settings_dict() -> Dict[str, Any]:
    try:
        return settings.safe_dict() if hasattr(settings, "safe_dict") else {}
    except Exception:
        return {}


# Backward compatibility aliases (functions now in utils.coercion)
_asf = safe_float
_safe_int = safe_int
_safe_dict = safe_dict
_safe_list = safe_list
_finite_or_zero = lambda x: ensure_finite(x, default=0.0)


# =============================================================
# RAG fallback helpers (se non c'è un index reale)
# =============================================================
_FB_DIM = 128
_FB_CHUNKS: List[Dict[str, Any]] = []
_FB_CHUNK_IDS: set[str] = set()


def _get_or_init_index():
    get_idx = getattr(rag_idx, "get_vector_index", None)
    ensure = getattr(rag_idx, "ensure_vector_backend", None)

    if callable(ensure):
        try:
            ensure(False)
        except Exception:
            pass

    idx = get_idx() if callable(get_idx) else getattr(rag_idx, "VECTOR_INDEX", None)

    if idx is None or type(idx).__name__.lower() == "noopindex" or not hasattr(idx, "search"):
        try:
            new_idx = rag_idx.InMemoryIndex()
            rag_idx.VECTOR_INDEX = new_idx
            idx = new_idx
        except Exception:
            pass

    return idx


def _fb_chunk_text(text: str, chunk_size: int = 350, overlap: int = 50) -> List[str]:
    t = (text or "").strip()
    if not t:
        return []

    chars = list(t)
    out: List[str] = []
    i, n = 0, len(chars)

    while i < n:
        j = min(n, i + chunk_size)
        ch = "".join(chars[i:j]).strip()
        if ch:
            out.append(ch)
        nxt = j - overlap
        i = nxt if nxt > i else j

    return out


def _fb_hash_vec(text: str, dim: int = _FB_DIM) -> List[float]:
    if not text:
        return [0.0] * dim

    v = [0.0] * dim
    for tok in text.split():
        h = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
        idx = h % dim
        sign = -1.0 if ((h >> 8) & 1) else 1.0
        v[idx] += sign

    norm = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / norm for x in v]


def _fb_cos(a: List[float], b: List[float]) -> float:
    s = sum(x * y for x, y in zip(a, b))
    return (s + 1.0) / 2.0


def _fb_add_docs(docs: List[RAGDoc], chunk_size: int, overlap: int) -> Dict[str, int]:
    added = 0
    for d in docs:
        for i, ch in enumerate(_fb_chunk_text(d.text, chunk_size, overlap)):
            cid = f"{d.id}::ch{i}"
            if cid in _FB_CHUNK_IDS:
                continue
            _FB_CHUNKS.append(
                {
                    "doc_id": d.id,
                    "chunk_id": cid,
                    "title": d.title,
                    "url": d.url,
                    "text": ch,
                    "vec": _fb_hash_vec(ch),
                }
            )
            _FB_CHUNK_IDS.add(cid)
            added += 1

    return {"added_chunks": added, "total_chunks": len(_FB_CHUNKS)}


def _fb_search(query: str, k: int) -> List[Dict[str, Any]]:
    if not _FB_CHUNKS:
        return []

    vq = _fb_hash_vec(query or "")
    scored = [(_fb_cos(vq, c["vec"]), c) for c in _FB_CHUNKS]
    scored.sort(key=lambda t: t[0], reverse=True)

    out: List[Dict[str, Any]] = []
    for s, c in scored[: max(1, k)]:
        out.append(
            {
                "doc_id": c["doc_id"],
                "chunk_id": c["chunk_id"],
                "title": c.get("title"),
                "url": c.get("url"),
                "score": float(s),
                "text": c["text"],
            }
        )
    return out


# =============================================================
# Endpoints base
# =============================================================
@router.get("/health")
def health():
    return {"status": "ok", "version": "1.3"}


@router.get("/_selftest")
def selftest():
    return {
        "summary": _safe_settings_summary(),
        "config": _safe_settings_dict(),
        "openai_key_present": bool(getattr(settings, "OPENAI_API_KEY", None)),
        "llm_provider": getattr(settings, "LLM_PROVIDER", None),
        "demo_mode": getattr(settings, "DEMO_MODE", None),
        "test_mode": getattr(settings, "TEST_MODE", None),
    }


@router.post("/kpi/compute")
def kpi_compute(req: KPIRequest):
    try:
        ctx = normalize_context_numeric(req.model_dump())

        revenue = max(
            [
                _asf(ctx.get("fatturato")),
                _asf(ctx.get("sales")),
                _asf(ctx.get("re")),
                _asf(getattr(req, "fatturato", 0.0)),
                _asf(getattr(req, "sales", 0.0)),
                _asf(getattr(req, "re", 0.0)),
            ]
        )

        kpi = compute_kpis(**ctx)
        out = kpi.model_dump()

        if revenue <= 0.0:
            revenue = _asf(out.get("fatturato"), 0.0) or _asf(out.get("sales"), 0.0)

        cogs_val = 0.0
        for c in [
            _asf(ctx.get("cogs")),
            _asf(ctx.get("cost_of_goods_sold")),
            _asf(ctx.get("costi_variabili")),
            _asf(getattr(req, "cogs", 0.0)),
            _asf(getattr(req, "costi_variabili", 0.0)),
            _asf(out.get("costi_variabili", 0.0)),
        ]:
            if c > 0.0:
                cogs_val = c
                break

        cf_val = _asf(ctx.get("costi_fissi")) or _asf(getattr(req, "costi_fissi", 0.0)) or _asf(out.get("costi_fissi", 0.0))
        amm = _asf(ctx.get("ammortamenti")) or _asf(getattr(req, "ammortamenti", 0.0)) or _asf(out.get("ammortamenti", 0.0))
        invest = _asf(ctx.get("investimenti")) or _asf(getattr(req, "investimenti", 0.0)) or _asf(out.get("investimenti", 0.0))

        utile = revenue - cogs_val - cf_val
        mc = revenue - cogs_val
        mcr = (mc / revenue) if revenue else 0.0

        out["utile"] = utile
        out["ebitda"] = utile + amm
        out["roi"] = (utile / invest * 100.0) if invest else 0.0
        out["sales"] = revenue
        out["fatturato"] = revenue
        out["re"] = revenue
        out["margine_contribuzione"] = mc
        out["mc_rate"] = max(0.0, min(1.0, float(mcr)))

        if cogs_val > 0.0 and revenue > 0.0:
            out["cogs"] = cogs_val
            out["gross_margin_rate"] = (revenue - cogs_val) / revenue * 100.0

        _sanitize_output_numbers(out)
        _clamp_non_negative(out)
        return out
    
    except ValidationAppError:
        # Re-raise validation errors as-is
        raise
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nei calcoli KPI",
            details={"error_type": type(e).__name__, "message": str(e)},
            cause=e,
        )
    except Exception as e:
        # Map other exceptions
        raise from_exception(e, message="Unexpected error during KPI computation")


@router.post("/diagnosis")
def diagnose_company(req: KPIRequest):
    """
    Genera diagnosi strategica completa.
    
    Ritorna:
    {
        "verdict": "HEALTHY" | "ATTENZIONE" | "CRITICO",
        "spiegazione": "Narrazione del verdict",
        "scorecard": {
            "marginalita": 0-1,
            "profittabilita": 0-1,
            "efficienza_capitale": 0-1,
            "disciplina_cassa": 0-1,
            "acquisizione_clienti": 0-1,
            "retention_clienti": 0-1,
            "espansione_base": 0-1,
        },
        "aree_forti": ["Marginalità", ...],
        "aree_deboli": ["Profittabilità", ...],
        "bottleneck": "Il collo di bottiglia principale",
        "azioni_prioritarie": ["Azione 1", "Azione 2", "Azione 3"],
        "metriche_chiave": {
            "fatturato": "€1,5M",
            "utile_netto": "€450k",
            "margine_lordo": "60.0%",
            ...
        }
    }
    """
    try:
        ctx = normalize_context_numeric(req.model_dump())

        # Estrai fatturato con fallback multipli (come in /kpi/compute)
        revenue = max(
            [
                _asf(ctx.get("fatturato")),
                _asf(ctx.get("sales")),
                _asf(ctx.get("re")),
                _asf(getattr(req, "fatturato", 0.0)),
                _asf(getattr(req, "sales", 0.0)),
                _asf(getattr(req, "re", 0.0)),
            ]
        )

        # Estrai COGS con fallback
        cogs_val = 0.0
        for c in [
            _asf(ctx.get("cogs")),
            _asf(ctx.get("cost_of_goods_sold")),
            _asf(ctx.get("costi_variabili")),
            _asf(getattr(req, "cogs", 0.0)),
            _asf(getattr(req, "costi_variabili", 0.0)),
        ]:
            if c > 0.0:
                cogs_val = c
                break

        # Estrai altri valori
        cf_val = _asf(ctx.get("costi_fissi")) or _asf(getattr(req, "costi_fissi", 0.0))
        amm = _asf(ctx.get("ammortamenti")) or _asf(getattr(req, "ammortamenti", 0.0))
        invest = _asf(ctx.get("investimenti")) or _asf(getattr(req, "investimenti", 0.0))
        dso = _asf(ctx.get("dso")) or _asf(getattr(req, "dso", 0.0))
        dio = _asf(ctx.get("dio")) or _asf(getattr(req, "dio", 0.0))
        dpo = _asf(ctx.get("dpo")) or _asf(getattr(req, "dpo", 0.0))

        # Aggiungi al context per compute_kpis
        ctx["fatturato"] = revenue
        ctx["costi_variabili"] = cogs_val
        ctx["costi_fissi"] = cf_val
        ctx["ammortamenti"] = amm
        ctx["investimenti"] = invest
        ctx["dso"] = dso
        ctx["dio"] = dio
        ctx["dpo"] = dpo

        # Computa KPI
        kpi = compute_kpis(**ctx)

        # Genera diagnosi
        diagnosis_engine = CFODiagnosisEngine()
        report = diagnosis_engine.diagnose(kpi)

        return report.to_dict()

    except ValidationAppError:
        raise
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nella diagnosi",
            details={"error_type": type(e).__name__, "message": str(e)},
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during diagnosis")


@router.post("/scenarios")
def generate_multi_scenarios(req: KPIRequest):
    """
    Genera 3 scenari finanziari (pessimista, realista, ottimista) con proiezioni 12 mesi.
    """
    try:
        ctx = normalize_context_numeric(req.model_dump())
        kpi = compute_kpis(**ctx)
        
        fatturato = safe_float(ctx.get("fatturato"), 0.0)
        utile = safe_float(getattr(kpi, "utile", 0.0), 0.0)
        roi = safe_float(getattr(kpi, "roi", 0.0), 0.0)
        ebitda = safe_float(getattr(kpi, "ebitda", 0.0), 0.0)
        investimenti = safe_float(ctx.get("investimenti"), 0.0)
        sector = str(ctx.get("settore", "default")).lower()

        comparison = generate_scenarios(
            fatturato=fatturato,
            utile=utile,
            roi=roi,
            ebitda=ebitda,
            investimenti=investimenti,
            sector=sector,
        )

        return comparison.to_dict()

    except Exception as e:
        raise from_exception(e, message="Errore nella generazione scenari")


@router.post("/roi")
def calculate_decision_roi(req: KPIRequest):
    """
    Calcola ROI di decisioni strategiche (pricing, cost reduction, investment, hiring).
    """
    try:
        ctx = normalize_context_numeric(req.model_dump())
        kpi = compute_kpis(**ctx)
        
        fatturato = safe_float(ctx.get("fatturato"), 0.0)
        utile = safe_float(getattr(kpi, "utile", 0.0), 0.0)
        gmr = safe_float(getattr(kpi, "gross_margin_rate", 50.0), 50.0)
        costi_fissi = safe_float(ctx.get("costi_fissi"), 0.0)

        # Extract decision parameters
        pricing_increase = safe_float(ctx.get("pricing_increase_pct"), 0.0)
        cost_reduction = safe_float(ctx.get("cost_reduction_pct"), 0.0)
        investment_amount = safe_float(ctx.get("investment_amount"), 0.0)
        headcount_increase = safe_float(ctx.get("headcount_increase"), 0.0)

        roi_calc = calculate_roi(
            fatturato=fatturato,
            utile=utile,
            margine_lordo_pct=gmr,
            costi_fissi=costi_fissi,
            pricing_increase_pct=pricing_increase,
            cost_reduction_pct=cost_reduction,
            investment_amount=investment_amount,
            headcount_increase=headcount_increase,
        )

        return roi_calc.to_dict()

    except Exception as e:
        raise from_exception(e, message="Errore nel calcolo ROI")


@router.post("/hiring")
def analyze_hiring_plan(req: KPIRequest):
    """
    Analizza headcount e genera piano assunzioni ottimale.
    """
    try:
        ctx = normalize_context_numeric(req.model_dump())
        kpi = compute_kpis(**ctx)
        
        fatturato = safe_float(ctx.get("fatturato"), 0.0)
        utile = safe_float(getattr(kpi, "utile", 0.0), 0.0)
        headcount = int(safe_float(ctx.get("headcount"), 0.0))
        salary_expenses = safe_float(ctx.get("salary_expenses"), 0.0)
        sector = str(ctx.get("settore", "default")).lower()

        hiring_plan = analyze_headcount(
            fatturato=fatturato,
            utile=utile,
            headcount=headcount,
            salary_expenses=salary_expenses,
            sector=sector,
        )

        return hiring_plan.to_dict()

    except Exception as e:
        raise from_exception(e, message="Errore nell'analisi headcount")


@router.post("/simulate")
def simulate_endpoint(req: SimulateRequest):
    """
    Regole:
      - *_abs      → delta assoluta
      - *_pct      → delta percentuale
      - *_target   → valore bersaglio; convertito in delta rispetto al base
      - price_pct  → applica elasticità su ricavi e, se possibile, su CVU
    """
    base = normalize_context_numeric(req.base)

    if "costi_variabili" not in base and "cogs" in base:
        base["costi_variabili"] = _asf(base.get("cogs"), 0.0)

    delta_in = dict(req.delta or {})
    delta = normalize_context_numeric(delta_in.copy())

    targets: Dict[str, float] = {}
    for key in ("fatturato", "costi_variabili", "costi_fissi", "investimenti"):
        ak = f"{key}_abs"
        tk = f"{key}_target"

        if ak in delta_in:
            try:
                delta[ak] = float(delta_in[ak])
            except Exception:
                pass

        if tk in delta_in:
            try:
                target = float(delta_in[tk])
                base_val = _asf(base.get(key), 0.0)
                delta[ak] = target - base_val
                targets[key] = target
                delta.pop(tk, None)
            except Exception:
                pass

    def _apply_delta_scalar(base_val: float, d: Dict[str, float], key: str) -> float:
        v = _asf(base_val)
        pct_key = f"{key}_pct"
        abs_key = f"{key}_abs"
        if pct_key in d:
            v = v * (1.0 + _asf(d.get(pct_key)) / 100.0)
        if abs_key in d:
            v = v + _asf(d.get(abs_key))
        return v

    def _clamp_nonneg_payload(payload: Dict[str, float], keys: List[str]) -> None:
        for k in keys:
            if k in payload:
                payload[k] = max(0.0, _asf(payload[k], 0.0))

    base_mod = dict(base)
    p0 = _asf(base.get("prezzo_medio"), 0.0)
    r0 = _asf(base.get("fatturato"), 0.0)
    cvu = _asf(base.get("costo_variabile_unitario"), 0.0)
    el = _asf(base.get("price_elasticity"), -1.2)

    has_sales_delta = any(k in delta or k in delta_in for k in ("fatturato_abs", "fatturato_pct", "fatturato_target"))
    has_cv_delta = any(k in delta or k in delta_in for k in ("costi_variabili_abs", "costi_variabili_pct", "costi_variabili_target"))

    if ("price_pct" in delta) and p0 > 0.0 and r0 > 0.0:
        dp = _asf(delta.get("price_pct")) / 100.0
        q0 = r0 / p0
        p1 = p0 * (1.0 + dp)
        q1 = q0 * (1.0 + el * dp)
        q1 = max(0.0, q1)
        q1 = min(q1, q0 * 5.0)
        fatt_new = p1 * q1

        if not has_sales_delta:
            base_mod["fatturato"] = float(fatt_new)

        if (not has_cv_delta) and (cvu > 0.0):
            base_mod["costi_variabili"] = float(q1 * cvu)

        delta.pop("price_pct", None)

    try:
        out = simulate(base_mod, delta)
    except (ValidationError, ValueError, TypeError, Exception):
        hardened: Dict[str, float] = dict(base_mod)

        for k in ["fatturato", "costi_variabili", "costi_fissi", "investimenti", "ammortamenti"]:
            hardened[k] = _apply_delta_scalar(hardened.get(k, 0.0), delta, k)

        for k in ["prezzo_medio", "costo_variabile_unitario", "dso", "dio", "dpo"]:
            if k in base_mod:
                hardened[k] = _asf(base_mod.get(k, 0.0))

        _clamp_nonneg_payload(
            hardened,
            [
                "fatturato",
                "costi_variabili",
                "costi_fissi",
                "investimenti",
                "ammortamenti",
                "prezzo_medio",
                "costo_variabile_unitario",
                "dso",
                "dio",
                "dpo",
            ],
        )

        for key, target in targets.items():
            hardened[key] = max(0.0, _asf(target))

        kpi = compute_kpis(**hardened)
        out = kpi.model_dump()

    if "fatturato" in targets:
        sales = float(targets["fatturato"])
    else:
        sales = _asf(out.get("sales", out.get("fatturato", 0.0)), 0.0)

    sales = max(0.0, sales)
    out["sales"] = sales
    out["fatturato"] = sales

    cv = _asf(out.get("costi_variabili"), 0.0)
    cf = _asf(out.get("costi_fissi"), 0.0)
    amm = _asf(out.get("ammortamenti"), 0.0)
    invest = _asf(out.get("investimenti"), 0.0)

    mc = sales - cv
    out["margine_contribuzione"] = mc
    out["mc_rate"] = max(0.0, min(1.0, float((mc / sales) if sales else 0.0)))

    utile = sales - cv - cf
    out["utile"] = utile
    out["ebitda"] = utile + amm
    out["roi"] = (utile / invest * 100.0) if invest else 0.0

    _sanitize_output_numbers(out)
    _clamp_non_negative(out)
    return out


@router.post("/forecast")
def forecast_endpoint(req: ForecastRequest):
    history = [float(x) for x in req.history]
    out = forecast_series(history, periods=max(1, req.periods), method=req.method)
    return {"forecast": out}


@router.post("/valuation")
def valuation_endpoint(req: ValuationRequest):
    nar: List[str] = []
    rate = req.discount_rate_pct

    if rate is None and all(v is not None for v in [req.ke, req.kd, req.equity, req.debt, req.tax_rate]):
        rate = wacc(req.ke, req.kd, req.equity, req.debt, req.tax_rate)

    res: Dict[str, Any] = {"discount_rate_pct": rate}

    if req.cashflows and rate is not None:
        pe = project_eval(req.cashflows, rate)
        irr_display = float(pe.get("irr", 0.0))
        if irr_display > 40.0:
            irr_display = 40.0
        payback_val = pe.get("payback_period", -1)
        payback_show = int(payback_val) if float(payback_val) >= 0 else -1

        res["project_eval"] = {
            "npv": pe.get("npv", 0.0),
            "irr": irr_display,
            "payback_period": payback_show,
        }
        nar.append(f"NPV {pe.get('npv', 0.0):.0f}, IRR {irr_display:.2f}%, Payback {payback_show} anni.")

    if req.dcf_fcf:
        r = rate if rate is not None else 10.0
        out = dcf_equity(req.dcf_fcf, r, req.terminal_growth_pct, req.net_debt)
        nar.append(f"DCF: EV≈{out['enterprise_value']:.0f}, Equity≈{out['equity_value']:.0f} (WACC {r:.2f}%).")
        res["dcf"] = out

    if not nar:
        nar.append("Fornisci cashflows [CF0..] + discount_rate_pct, oppure FCF + parametri WACC.")

    return {"narrative": " | ".join(nar), **res}


@router.post("/opportunities")
def opportunities_endpoint(req: OpportunitiesRequest):
    base = normalize_context_numeric(req.base)
    engine = OpportunityEngine(sector=req.sector)
    opps = engine.generate(base, elasticity=req.price_elasticity)
    lines = [format_opportunity(o) for o in opps[:5]]
    return {"top_opportunities": lines}


@router.post("/risk/montecarlo")
def montecarlo_endpoint(req: Dict[str, Any]):
    payload = _safe_dict(req)
    base = _safe_dict(payload.get("base"))
    unct = _safe_dict(payload.get("uncertainties"))
    n = max(10, _safe_int(payload.get("n", 300), 300))
    return mc_scenarios(base, unct, n=n)


@router.post("/debug/parse")
def debug_parse(req: ParseDebugRequest):
    slots = extract_slots(req.text or "")
    merged = {**slots, **(req.context or {})}
    norm = normalize_context_numeric(merged)
    return {"slots": slots, "merged": merged, "normalized": norm}


# ---------------- RAG ----------------
@router.post("/knowledge/ingest")
def knowledge_ingest(req: IngestRequest):
    idx = _get_or_init_index()
    docs = [RAGDoc(**d.model_dump()) for d in req.docs]

    stats: Optional[Dict[str, int]] = None
    for meth in ("add_docs", "build"):
        fn = getattr(idx, meth, None)
        if callable(fn):
            try:
                stats = fn(docs, chunk_size=req.chunk_size, overlap=req.overlap)
                break
            except Exception:
                stats = None

    if stats is None:
        stats = _fb_add_docs(docs, chunk_size=req.chunk_size, overlap=req.overlap)

    return {"status": "ok", **stats}


@router.post("/knowledge/search")
def knowledge_search(req: SearchRequest):
    idx = _get_or_init_index()
    hits: Optional[List[Dict[str, Any]]] = None
    fn = getattr(idx, "search", None)

    if callable(fn):
        try:
            hits = fn(req.query, k=max(1, req.k))
        except Exception:
            hits = None

    if not hits:
        hits = _fb_search(req.query, k=max(1, req.k))

    return {"hits": hits}


# ------------- Optimize & What-if -------------
@router.post("/optimize/price")
def optimize_price(req: PriceOptimizeRequest):
    b = normalize_context_numeric(req.base)
    p0 = float(b.get("prezzo_medio", 0.0) or 0.0)
    cvu = float(b.get("costo_variabile_unitario", 0.0) or 0.0)
    fatt = float(b.get("fatturato", 0.0) or 0.0)
    cf = float(b.get("costi_fissi", 0.0) or 0.0)
    el = float(b.get("price_elasticity", -1.2) or -1.2)

    if p0 <= 0 or fatt <= 0:
        return {
            "best_pct": 0.0,
            "best_price": p0,
            "best_profit": -(10**9),
            "note": "Servono prezzo_medio>0 e fatturato>0.",
        }

    q0 = fatt / p0

    def profit(pct: float) -> float:
        p = p0 * (1.0 + pct / 100.0)
        q = q0 * (1.0 + el * (pct / 100.0))
        q = max(0.0, q)
        q = min(q, q0 * 5.0)
        utile = q * (p - cvu) - cf
        return utile

    grid = [x / 10.0 for x in range(-200, 201)]
    best = max(grid, key=profit)
    return {
        "best_pct": best,
        "best_price": p0 * (1.0 + best / 100.0),
        "best_profit": profit(best),
    }


@router.post("/whatif/price_ladder")
def price_ladder(req: PriceLadderRequest):
    b = normalize_context_numeric(req.base)
    p0 = float(b.get("prezzo_medio", 0.0) or 0.0)
    cvu = float(b.get("costo_variabile_unitario", 0.0) or 0.0)
    fatt = float(b.get("fatturato", 0.0) or 0.0)
    cf = float(b.get("costi_fissi", 0.0) or 0.0)
    el = float(b.get("price_elasticity", -1.2) or -1.2)

    if p0 <= 0 or fatt <= 0:
        return {"rows": [], "best": None, "note": "Servono prezzo_medio>0 e fatturato>0."}

    pct_min = float(req.pct_min)
    pct_max = float(req.pct_max)
    step = float(req.pct_step if req.pct_step > 0 else 1.0)

    if pct_min > pct_max:
        pct_min, pct_max = pct_max, pct_min

    q0 = fatt / p0
    rows: List[Dict[str, float]] = []
    pct = pct_min

    while pct <= pct_max + 1e-9:
        p = p0 * (1.0 + pct / 100.0)
        q = q0 * (1.0 + el * (pct / 100.0))
        q = max(0.0, q)
        q = min(q, q0 * 5.0)
        revenue = p * q
        profit = q * (p - cvu) - cf
        rows.append({"pct": pct, "price": p, "quantity": q, "revenue": revenue, "profit": profit})
        pct += step

    best = max(rows, key=lambda r: r["profit"]) if rows else None
    return {"rows": rows, "best": best}


# ---------- Breakeven (schema canonico) ----------
class BreakevenOut(BaseModel):
    be_qty: Optional[float] = None
    be_revenue: Optional[float] = None
    mc_rate: Optional[float] = None


@router.post("/whatif/breakeven", response_model=BreakevenOut)
def whatif_breakeven(req: BreakevenRequest):
    b = normalize_context_numeric(req.base)
    raw = breakeven_tool(b)

    be_qty = raw.get("be_qty", raw.get("q_be"))
    be_revenue = raw.get("be_revenue", raw.get("revenue_be"))
    mc_rate = raw.get("mc_rate", raw.get("mcr"))

    out = {"be_qty": be_qty, "be_revenue": be_revenue, "mc_rate": mc_rate}
    _clamp_non_negative(out, keys=["be_qty", "be_revenue"])
    return out


@router.post("/whatif/wc_impact")
def whatif_wc_impact(req: Dict[str, Any] = Body(...)):
    payload = WCImpactRequest.model_validate(req)
    b = normalize_context_numeric(payload.base)
    return wc_whatif_tool(b)


@router.post("/alerts/evaluate")
def alerts_evaluate(req: AlertsRequest):
    ctx = normalize_context_numeric(req.context)
    kpi = compute_kpis(**ctx)

    try:
        rules = load_rules("content/knowledge/rules")
        alerts = evaluate_rules(kpi.model_dump(), rules, context=ctx)
    except Exception:
        alerts = []

    out = []
    for a in alerts[:20]:
        out.append(
            {
                "code": a.get("code", "RULE"),
                "message": a.get("message", ""),
                "severity": a.get("severity", "info"),
                "meta": a.get("meta", {}),
            }
        )

    return {"alerts": out, "kpi": kpi.model_dump()}


# ---------- Action Plan (piani d'azione guidati) ----------
class AdvicePlanRequest(BaseModel):
    base: Dict[str, Any]
    goal: str = "crescita fatturato"
    sector: Optional[str] = None
    horizon_months: int = 12
    price_elasticity: float = -1.2


@router.post("/advice/plan")
def advice_plan(req: AdvicePlanRequest):
    ctx = normalize_context_numeric(req.base)
    kpi = compute_kpis(**ctx).model_dump()

    eng = OpportunityEngine(sector=req.sector)
    opps = eng.generate(ctx, elasticity=req.price_elasticity)[:5]
    opp_lines = [format_opportunity(o) for o in opps]

    extra: List[str] = []
    fatt = float(ctx.get("fatturato", 0.0) or 0.0)
    cv = float(ctx.get("costi_variabili", 0.0) or 0.0)
    cf = float(ctx.get("costi_fissi", 0.0) or 0.0)
    p = float(ctx.get("prezzo_medio", 0.0) or 0.0)
    cvu = float(ctx.get("costo_variabile_unitario", 0.0) or 0.0)
    dso = float(ctx.get("dso", 0.0) or 0.0)
    dio = float(ctx.get("dio", 0.0) or 0.0)
    dpo = float(ctx.get("dpo", 0.0) or 0.0)

    goal_low = (req.goal or "").lower()

    if "cresc" in goal_low or "fatturat" in goal_low:
        if p > 0 and fatt > 0:
            extra.append("Esegui price ladder: valuta +/−10% prezzo in step 2% e seleziona la fascia con utile massimo.")
        extra.append("Lancio bundle/upsell ai top 20% clienti per ARPU +8–12%.")
        extra.append("Campagne win-back su clienti dormienti (90–180 gg) con sconto mirato e limite temporale.")

    if "cassa" in goal_low or "cash" in goal_low:
        if dso > 0:
            extra.append(f"Riduci DSO di 5–10 giorni negoziando termini e premi cassa: impatto cassa +{int((5/365)*fatt)}€.")
        if dio > 0:
            extra.append("Ottimizza scorte (ABC + reorder point) per tagliare DIO di 5–8 giorni.")
        if dpo > 0:
            extra.append("Allunga DPO di 3–5 giorni con fornitori core senza penalità.")

    if "marg" in goal_low or "utile" in goal_low:
        if cvu > 0:
            extra.append("Sourcing alternativo per CVU −2–4%; audit scarti e resi; standardizza BOM.")
        if cf > 0:
            extra.append("Zero-based budget sui costi fissi: target −5%.")

    mc = fatt - cv
    mcr = (mc / fatt) if fatt else 0.0

    summary = (
        f"Baseline: Ricavi €{fatt:,.0f}, MC €{mc:,.0f} ({mcr*100:.1f}%), "
        f"CF €{cf:,.0f}. Obiettivo: {req.goal} in {req.horizon_months} mesi."
    )

    actions = []
    for i, line in enumerate(opp_lines, 1):
        actions.append({"rank": i, "type": "opportunity", "action": line})

    for i, line in enumerate(extra, 1):
        actions.append({"rank": i, "type": "playbook", "action": line})

    return {
        "goal": req.goal,
        "horizon_months": req.horizon_months,
        "kpi_baseline": {
            "fatturato": fatt,
            "mc": mc,
            "mc_rate": mcr,
            "costi_fissi": cf,
            "dso": dso,
            "dio": dio,
            "dpo": dpo,
        },
        "summary": summary,
        "actions": actions[:10],
        "kpi": kpi,
    }