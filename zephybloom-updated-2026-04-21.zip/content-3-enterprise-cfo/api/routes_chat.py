# content/api/routes_chat.py
# -*- coding: utf-8 -*-
"""
Conversational CFO assistant endpoint for ZephyBloom.

Main Endpoint:
  POST /chat — Multi-turn conversational interface with financial analysis.

Features:
  - Session management (in-memory memory store)
  - Intent-based routing + NLP analysis
  - Multi-lingual support (IT, EN)
  - Pending action state machine (goal-based planning)
  - KPI derivation and business logic
  - Tool calling (breakeven, working capital, pricing)
  - Formatting for EUR/percentage values

Request schema (ChatRequest):
  - text: User message
  - session_id: Session identifier (default: "default")
  - context: Financial context (fatturato, costi_variabili, etc.)
  - remember: Store exchange in session memory
  - use_tools: Enable tool calling

Response schema (ChatResponse):
  - intent: Detected intent (chat_generic, analysis_utile, plan_fixed, etc.)
  - narrative: Formatted markdown response
  - value: Computed monetary value (if applicable)
  - value_str: Formatted value (EUR abbreviated)
  - advisories: Structured recommendations
  - tools_used: List of tools invoked
  - sources: RAG knowledge base references
  - meta: Additional context (session_id, pending actions, etc.)

Architecture:
  1. Input normalization + security (SQL injection check)
  2. Session state retrieval via RouterPool
  3. NLP intent matching + slot extraction
  4. LLM-based reasoning with tool-calling capability
  5. Business logic execution (KPI, scenarios, rules)
  6. Response building + formatting
  7. Memory persistence

State Machine (Pending Actions):
  - goal_plan: User confirmed 3-lever plan (revenue, CV, CF)
  - plan_fixed: Execute plan on specific percentages
  - payback_calc: Calculate investment payback
  - explain_wc: Working capital analysis
"""
from __future__ import annotations

import math
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from fastapi import APIRouter

from api.schemas import ChatRequest, ChatResponse, ChatSimpleRequest

# KPI & tools
from core.metrics import compute_kpis
from core.validators import normalize_context_numeric
from tools.breakeven import breakeven_tool
from tools.wc import wc_whatif_tool

# Utils & NLP
from utils.fmt_parse import parse_number
from utils.coercion import safe_float, safe_dict, safe_list, safe_str
from utils.formatting import fmt_eur, fmt_pct, fmt_pct100, safe_value_str, serialize_advisories, safe_sources
from utils.errors import CalculationAppError, IntentMatchingAppError
from nlp.memory import MemoryStore
from nlp.slot_extraction import extract_slots
from nlp.llm_adapter import complete_zephy, DEFAULT_SYSTEM
from nlp.router.llm import NLPRouterLLM

router = APIRouter(tags=["chat"])


# =========================
# Session routing & memory
# =========================

def _normalize_session_id(session_id: Optional[str]) -> str:
    sid = (session_id or "default").strip()
    sid = re.sub(r"\s+", "_", sid)
    sid = re.sub(r"[^A-Za-z0-9_\-:.]", "", sid)
    return sid[:120] if sid else "default"


class RouterPool:
    def __init__(self, memory_store: Optional[MemoryStore] = None) -> None:
        self._routers: Dict[str, NLPRouterLLM] = {}
        self._memory = memory_store

    def get(self, session_id: str) -> NLPRouterLLM:
        sid = _normalize_session_id(session_id)
        if sid not in self._routers:
            self._routers[sid] = NLPRouterLLM(
                memory=self._memory,
                tenant_id=sid,
            )
        return self._routers[sid]

    def reset(self, session_id: str) -> None:
        sid = _normalize_session_id(session_id)
        self._routers.pop(sid, None)

    def clear(self) -> None:
        self._routers.clear()


memory = MemoryStore()
router_pool = RouterPool(memory_store=memory)

# Stato conversazionale per “pending actions”
PENDING_ACTIONS: Dict[str, Dict[str, Any]] = {}


# =========================
# Helpers (security & fmt)
# =========================

def sanitize_text(txt: str) -> str:
    """Rimuove pattern rischiosi e spazi superflui."""
    if not txt:
        return ""

    bad_patterns = [
        r"drop\s+table\b.*",
        r"delete\s+from\b.*",
        r"truncate\s+table\b.*",
        r"union\s+select\b.*",
        r"ignore\s+previous\s+instructions\b.*",
    ]
    out = txt
    for pat in bad_patterns:
        out = re.sub(pat, "", out, flags=re.IGNORECASE)

    out = re.sub(r"\s+", " ", out).strip()
    return out


def clamp_extracted_slots(slots: Dict[str, Any], max_abs: float = 1_000_000_000.0) -> Dict[str, Any]:
    """
    Converte gli slot numerici in float e ne limita il modulo.
    Usa parse_number per evitare float(None).
    """
    out: Dict[str, Any] = {}
    for k, v in (slots or {}).items():
        num = parse_number(v)
        if num is None:
            out[k] = v
        else:
            if abs(num) > max_abs:
                num = math.copysign(max_abs, num)
            out[k] = float(num)
    return out


def _append_memory_message(session_id: str, role: str, content: str) -> None:
    try:
        memory.append_message(session_id, role=role, content=content)
    except Exception:
        pass


def _extract_answer_fields(ans: Any) -> Dict[str, Any]:
    intent = getattr(ans, "intent", "unknown")
    narrative = getattr(ans, "narrative", "")
    advisories = getattr(ans, "advisories", []) or []
    tools_used = getattr(ans, "tools_used", []) or []
    sources = getattr(ans, "sources", None)
    meta = getattr(ans, "meta", {}) or {}
    value = getattr(ans, "value", None)
    value_str = getattr(ans, "value_str", None)

    if hasattr(ans, "model_dump"):
        try:
            d = ans.model_dump()
            if isinstance(d, dict):
                intent = d.get("intent", intent)
                narrative = d.get("narrative", narrative)
                advisories = d.get("advisories", advisories) or []
                tools_used = d.get("tools_used", tools_used) or []
                sources = d.get("sources", sources)
                meta = d.get("meta", meta) or {}
                value = d.get("value", value)
                value_str = d.get("value_str", value_str)
        except Exception:
            pass

    return {
        "intent": intent,
        "narrative": narrative,
        "advisories": advisories,
        "tools_used": tools_used,
        "sources": sources,
        "meta": meta if isinstance(meta, dict) else {},
        "value": value,
        "value_str": value_str,
    }


def _build_chat_response(
    *,
    intent: str,
    value: Any,
    value_str: Optional[str],
    narrative: str,
    advisories: Any,
    tools_used: Any = None,
    sources: Any = None,
    meta: Optional[Dict[str, Any]] = None,
) -> ChatResponse:
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)) or abs(float(value)) > 1e12:
            value = None
            value_str = None

    if value_str is None and isinstance(value, (int, float)):
        value_str = safe_value_str(value)

    return ChatResponse(
        intent=str(intent or "unknown"),
        value=value if isinstance(value, (int, float)) else None,
        value_str=value_str,
        narrative=str(narrative or ""),
        advisories=serialize_advisories(advisories),
        tools_used=[str(t) for t in (tools_used or [])],
        sources=safe_sources(sources),
        meta=meta or {},
    )


# =========================
# KPI derivation util
# =========================

def _derive_kpi(context: Dict[str, Any]) -> Dict[str, float]:
    """
    Usa compute_kpis e sovrascrive alcuni campi chiave con logiche deterministiche.
    """
    try:
        kpi_obj = compute_kpis(**context)
        k = kpi_obj.model_dump()
    except Exception:
        k = {}

    fatt = safe_float(context.get("fatturato", k.get("fatturato", k.get("sales", 0.0))))
    cv = safe_float(context.get("costi_variabili", k.get("costi_variabili", k.get("cogs", 0.0))))
    cf = safe_float(context.get("costi_fissi", k.get("costi_fissi", 0.0)))
    amm = safe_float(context.get("ammortamenti", k.get("ammortamenti", 0.0)))
    inv = safe_float(context.get("investimenti", k.get("investimenti", 0.0)))

    utile = fatt - cv - cf
    ebitda = utile + amm
    mc = fatt - cv
    mc_rate = (mc / fatt) if fatt else 0.0
    roi = (utile / inv * 100.0) if inv else 0.0  # ROI in %

    k.update(
        {
            "fatturato": fatt,
            "sales": fatt,
            "re": fatt,
            "costi_variabili": cv,
            "costi_fissi": cf,
            "ammortamenti": amm,
            "investimenti": inv,
            "utile": utile,
            "ebitda": ebitda,
            "margine_contribuzione": mc,
            "mc_rate": mc_rate,
            "roi": roi,
            "sector": context.get("sector", "default"),
        }
    )
    return k


# =========================
# Piano a 3 leve: costruzione + esecuzione
# =========================

AFFIRMATIVE = re.compile(
    r"^\s*(s[iì]|ok|va bene|procedi|procedi pure|perfetto|fai|fai pure|go|vai|esegui|esegui pure)\b.*$",
    re.I,
)


def _parse_target_increase_pct(text: str) -> Optional[float]:
    m = re.search(r"([+\-]?\d+(?:[\.,]\d+)?)\s*%", (text or "").replace(",", "."), re.I)
    if m:
        try:
            return float(m.group(1))
        except Exception:
            return None
    return None


def _distribute_goal(U0: float, fatt: float, cv: float, cf: float, goal_pct: float) -> Tuple[float, float, float]:
    """
    Distribuisce ΔU su 3 leve (ricavi, CV, CF). Ritorna percentuali (a, b, c).
    """
    goal_abs = U0 * (goal_pct / 100.0)
    mc_rate = (fatt - cv) / fatt if fatt else 0.0
    if mc_rate <= 0:
        wR, wCV, wCF = 0.2, 0.45, 0.35
    else:
        wR, wCV, wCF = 0.40, 0.35, 0.25

    target_R = goal_abs * wR
    a = (target_R / mc_rate / fatt) if (fatt and mc_rate > 0) else 0.0

    target_CV = goal_abs * wCV
    b = -(target_CV / cv) if cv else 0.0

    target_CF = goal_abs * wCF
    c = -(target_CF / cf) if cf else 0.0

    a = max(-0.2, min(0.2, a))
    b = max(-0.2, min(0.0, b))
    c = max(-0.2, min(0.0, c))
    return (a, b, c)


def _apply_deltas_simple(ctx: Dict[str, float], a: float, b: float, c: float) -> Dict[str, float]:
    fatt0 = safe_float(ctx.get("fatturato"))
    cv0 = safe_float(ctx.get("costi_variabili"))
    cf0 = safe_float(ctx.get("costi_fissi"))
    amm0 = safe_float(ctx.get("ammortamenti"))
    inv0 = safe_float(ctx.get("investimenti"))

    fatt1 = fatt0 * (1.0 + a)
    cv1 = cv0 * (1.0 + b)
    cf1 = cf0 * (1.0 + c)
    utile0 = fatt0 - cv0 - cf0
    utile1 = fatt1 - cv1 - cf1
    ebitda0 = utile0 + amm0
    ebitda1 = utile1 + amm0
    mc_rate1 = (fatt1 - cv1) / fatt1 if fatt1 else 0.0
    roi1 = (utile1 / inv0 * 100.0) if inv0 else 0.0

    return {
        "fatt0": fatt0,
        "cv0": cv0,
        "cf0": cf0,
        "utile0": utile0,
        "ebitda0": ebitda0,
        "fatt1": fatt1,
        "cv1": cv1,
        "cf1": cf1,
        "utile1": utile1,
        "ebitda1": ebitda1,
        "mc_rate1": mc_rate1,
        "roi1": roi1,
        "a": a,
        "b": b,
        "c": c,
    }


def _narrative_plan_and_result(res: Dict[str, float], goal_pct: Optional[float]) -> str:
    a, b, c = res["a"], res["b"], res["c"]
    utile0 = res["utile0"]
    fatt1, utile1 = res["fatt1"], res["utile1"]
    ebitda1 = res["ebitda1"]
    mc1 = res["mc_rate1"]

    goal_str = f" (+{goal_pct:.1f}% target)" if (goal_pct is not None) else ""
    return f"""**Piano applicato{goal_str}:**  
- Ricavi: **{fmt_pct(a)}** → {fmt_eur(fatt1)}  
- Costi variabili: **{fmt_pct(b)}**  
- Costi fissi: **{fmt_pct(c)}**  

**Risultato atteso:**  
- Utile: **{fmt_eur(utile1)}** (Δ **{fmt_eur(utile1 - utile0)}**)  
- EBITDA: **{fmt_eur(ebitda1)}**  
- MC%: **{fmt_pct(mc1)}**

**Lettura rapida:** combiniamo un lieve **uplift ricavi** con **efficienze sui CV** e un **alleggerimento CF**.  
Vuoi che trasformi il piano in una **ladder di scenari** (±5% / ±10%) per vedere sensibilità?"""


# =========================
# Playbook per settore + Analisi utile
# =========================

def _sector_playbook(sector: str, k: Dict[str, float]) -> Tuple[List[str], List[str]]:
    fatt = safe_float(k.get("fatturato"))
    cf = safe_float(k.get("costi_fissi"))
    ebitda = safe_float(k.get("ebitda"))
    mc_rate = safe_float(k.get("mc_rate"))
    ebitda_margin = (ebitda / fatt) if fatt else 0.0

    low_margin = mc_rate < 0.25
    high_fixed = (cf / fatt) > 0.35 if fatt else False
    weak_ebitda = ebitda_margin < 0.12

    sector = (sector or "default").lower()
    levers: List[str] = []
    risks: List[str] = []

    if sector in ("saas", "software"):
        levers += [
            "Aumenta **ARPU** con bundle/feature tiered; rafforza l’**upsell**.",
            "Riduci **churn** con CS/Onboarding e annualizzazioni.",
            "Ottimizza **spend marketing** su canali con CAC payback < 12 mesi.",
        ]
        risks += ["Scontistica aggressiva che deprime NRR.", "Sovracosti su cloud/infra."]
    elif sector in ("retail", "ecommerce", "gdo"):
        levers += [
            "Migliora **mix**: spingi SKU ad alto margine, riduci promo erosive.",
            "Ottimizza **logistica/packaging** per ridurre CV.",
            "Riduci **out-of-stock** e tempi di riordino per non perdere vendite.",
        ]
        risks += ["Pressione prezzi dei competitor.", "Stock obsoleti / invenduto."]
    elif sector in ("manufacturing", "manifattura", "industry"):
        levers += [
            "Negozia **listini fornitura** e alternative materie prime.",
            "Automazione/ottimizzazione **linee produttive** (OEE).",
            "Revisione **make-or-buy** su componenti a basso valore.",
        ]
        risks += ["Shock energia/materie prime.", "Colli di bottiglia produttivi."]
    elif sector in ("services", "servizi", "agenzia", "consulting"):
        levers += [
            "Migliora **pricing per valore** (pacchetti, retainers).",
            "Aumenta **utilization** del team; riduci tempi non fatturabili.",
            "Standardizza/automatizza **delivery** per ridurre CF unitari.",
        ]
        risks += ["Overstaffing / sottoutilizzo.", "Dipendenza da pochi clienti."]
    else:
        levers += [
            "Ritocca **prezzo medio** (+2–3%) se l’elasticità lo consente.",
            "Migliora **mix** verso prodotti/servizi ad alto margine.",
            "Spending review sui **CF** non core; negozia contratti.",
        ]
        risks += ["Elasticità prezzo e churn/abbandono.", "CV in crescita (materie prime, logistica)."]

    if low_margin:
        levers.append("Focalizzati su **margine di contribuzione**: riduci CV (sourcing) e ribilancia listini.")
        risks.append("Margine basso: promo/sconti eccessivi possono portare a perdita.")
    if high_fixed:
        levers.append("Alleggerisci **costi fissi** o sposta a variabile (outsourcing dove ha senso).")
        risks.append("Struttura rigida: lentezza nel rientrare in utile con shock domanda.")
    if weak_ebitda:
        levers.append("Spingi **efficienze operative** e automazioni per recuperare EBITDA margin.")
        risks.append("Resilienza bassa a cali di volume: valuta break-even per famiglia prodotto.")

    return levers, risks


def _cfo_block(
    title: str,
    metrics: List[Tuple[str, str]],
    levers: List[str],
    risks: List[str],
    next_step: Optional[str] = None,
) -> str:
    lines = [f"**{title}**\n"]
    if metrics:
        m = "  \n".join([f"• **{k}**: {v}" for k, v in metrics])
        lines.append(m + "\n")
    if levers:
        lines.append("\n**Leve operative**")
        lines += [f"- {x}" for x in levers]
    if risks:
        lines.append("\n**Rischi / attenzioni**")
        lines += [f"- {x}" for x in risks]
    if next_step:
        lines.append(f"\n**Prossimo passo**: {next_step}")
    return "\n".join(lines).strip()


def _utile_analysis_text(k: Dict[str, float]) -> str:
    fatt = safe_float(k.get("fatturato"))
    utile = safe_float(k.get("utile"))
    ebitda = safe_float(k.get("ebitda"))
    mc_rate = safe_float(k.get("mc_rate"))
    ebitda_margin = (ebitda / fatt) if fatt else 0.0
    utile_margin = (utile / fatt) if fatt else 0.0

    sector = str(k.get("sector", "default"))
    levers, risks = _sector_playbook(sector, k)

    title = f"Utile operativo stimato: {fmt_eur(utile)}"
    metrics = [
        ("Ricavi", fmt_eur(fatt)),
        ("Utile / Ricavi", fmt_pct(utile_margin)),
        ("EBITDA", fmt_eur(ebitda)),
        ("EBITDA / Ricavi", fmt_pct(ebitda_margin)),
        ("Margine di contribuzione", fmt_pct(mc_rate)),
    ]
    next_step = "Vuoi che **simuli +5% ricavi, −3% CV e −5% CF** per vedere l’impatto?"
    return _cfo_block(title, metrics, levers, risks, next_step)


def _wc_analysis_text(context: Dict[str, Any]) -> str:
    try:
        out = wc_whatif_tool(context)
        ccc_before = out.get("ccc_before")
        ccc_after = out.get("ccc_after")
        delta_cash = out.get("delta_cash")
        title = "Analisi Working Capital"

        metrics = []
        if ccc_before is not None:
            metrics.append(("CCC prima", f"{safe_float(ccc_before):.0f}g"))
        if ccc_after is not None:
            metrics.append(("CCC dopo", f"{safe_float(ccc_after):.0f}g"))
        if delta_cash is not None:
            metrics.append(("Delta cassa", fmt_eur(safe_float(delta_cash))))

        levers = [
            "Riduci **DSO** con reminder e policy di incasso più forte.",
            "Riduci **DIO** con rotazione e pianificazione migliore.",
            "Ottimizza **DPO** senza stressare i fornitori chiave.",
        ]
        risks = [
            "Ridurre troppo il magazzino può generare stock-out.",
            "Allungare troppo i pagamenti può deteriorare i rapporti fornitori.",
        ]
        next_step = "Vuoi che simuli un piano **DSO−5 / DIO−3 / DPO+5** sul tuo contesto?"
        return _cfo_block(title, metrics, levers, risks, next_step)
    except Exception:
        return _cfo_block(
            "Analisi Working Capital",
            [],
            ["Per una simulazione completa servono almeno **dso**, **dio**, **dpo** e base economica coerente."],
            [],
            "Fornisci i giorni di incasso, stock e pagamento e faccio la simulazione.",
        )


# =========================
# Quick handlers
# =========================

def q_utile(context: Dict[str, Any]) -> Tuple[str, float, str]:
    k = _derive_kpi(context)
    utile = k["utile"]
    narrative = f"**Utile operativo:** {fmt_eur(utile)}.  \nVuoi un'**analisi rapida** (margini, leve e rischi)?"
    return "kpi_utile", utile, narrative


def q_fatturato(context: Dict[str, Any]) -> Tuple[str, Optional[float], str]:
    k = _derive_kpi(context)
    fatt = k["fatturato"]
    title = f"Ricavi attesi: {fmt_eur(fatt)}"
    metrics = [
        ("Ricavi (top-line)", fmt_eur(fatt)),
        ("Margine di contribuzione", fmt_pct(k["mc_rate"])),
        ("Utile", fmt_eur(k["utile"])),
    ]
    levers = [
        "Aumenta **scontrino medio** (bundle, up-sell).",
        "Espandi **canali** (partnership, marketplace) e **regioni**.",
        "Riduci **lead time** ed **out-of-stock** per non perdere vendite.",
    ]
    risks = ["Attrito commerciale, saturazione canali, concorrenza su prezzo."]
    next_step = "Vuoi una **ladder prezzo ±20%** con elasticità per vedere revenue e profitto?"
    narrative = _cfo_block(title, metrics, levers, risks, next_step)
    return "kpi_fatturato", None, narrative


def q_ebitda(context: Dict[str, Any]) -> Tuple[str, float, str]:
    k = _derive_kpi(context)
    fatt, ebitda = k["fatturato"], k["ebitda"]
    margin = (ebitda / fatt) if fatt else 0.0
    title = f"EBITDA stimato: {fmt_eur(ebitda)} ({fmt_pct(margin)})"
    metrics = [
        ("Ricavi", fmt_eur(fatt)),
        ("EBITDA", fmt_eur(ebitda)),
        ("EBITDA / Ricavi", fmt_pct(margin)),
    ]
    levers = ["Efficienza operativa, automazione, sourcing alternativo a CV, tagli CF mirati."]
    risks = ["Shock costi variabili, stagionalità, rigidità costi fissi."]
    narrative = _cfo_block(title, metrics, levers, risks, "Vuoi un piano **−5% CV e −3% CF**?")
    return "kpi_ebitda", ebitda, narrative


def q_margine(context: Dict[str, Any]) -> Tuple[str, float, str]:
    k = _derive_kpi(context)
    mc_rate = k["mc_rate"]
    title = f"Margine di contribuzione: {fmt_pct(mc_rate)}"
    metrics = [
        ("Fatturato", fmt_eur(k["fatturato"])),
        ("Costi variabili", fmt_eur(k["costi_variabili"])),
        ("Margine di contribuzione", fmt_pct(mc_rate)),
    ]
    levers = ["Mix verso SKU ad alto margine, negozia listini, ottimizza packaging/logistica."]
    risks = ["Promozioni aggressive e scontistica non sostenibile."]
    narrative = _cfo_block(title, metrics, levers, risks, "Vuoi testare un **+2% prezzo** su 3 SKU chiave?")
    return "kpi_margine", mc_rate, narrative


def q_roi(context: Dict[str, Any]) -> Tuple[str, float, str]:
    k = _derive_kpi(context)
    roi = k["roi"]
    title = f"ROI stimato: {fmt_pct100(roi)}"
    metrics = [
        ("Utile", fmt_eur(k["utile"])),
        ("Investimenti", fmt_eur(k["investimenti"])),
        ("ROI", fmt_pct100(roi)),
    ]
    levers = ["Rimanda capex non core, priorità a progetti con payback < 24 mesi."]
    risks = ["Attività sottoutilizzata, obsolescenza, rischio di esecuzione."]
    narrative = _cfo_block(title, metrics, levers, risks, "Vuoi che calcoli **payback** su 3 investimenti?")
    return "kpi_roi", roi, narrative


def q_breakeven(context: Dict[str, Any]) -> Tuple[str, Optional[float], str]:
    try:
        be = breakeven_tool(context)
        q_be = be.get("q_be") or be.get("quantity_be") or be.get("break_even_qty")
        rev_be = be.get("revenue_be") or be.get("revenue_at_be")
        title = "Punto di pareggio"
        metrics = [
            ("Quantità a BE", f"{safe_float(q_be):,.0f}".replace(",", ".")),
            ("Ricavi a BE", fmt_eur(safe_float(rev_be))),
        ]
        levers = ["Aumenta prezzo, riduci CVU, alleggerisci CF: tutte spostano il BE."]
        risks = ["Elasticità della domanda oltre una certa soglia."]
        narrative = _cfo_block(title, metrics, levers, risks, "Vuoi una **ladder Δprezzo ±10%**?")
        value = safe_float(q_be) if q_be is not None else None
        return "kpi_breakeven", value, narrative
    except Exception:
        title = "Punto di pareggio: dati richiesti"
        narrative = _cfo_block(
            title,
            [],
            ["Servono almeno: **costi_fissi**, **prezzo_medio**, **costo_variabile_unitario**."],
            [],
            "Fornisci CF, prezzo medio e CVU: calcolo subito il BE.",
        )
        return "kpi_breakeven", None, narrative


def q_wc(context: Dict[str, Any]) -> Tuple[str, Optional[float], str]:
    DSO = safe_float(context.get("dso", 0))
    DIO = safe_float(context.get("dio", 0))
    DPO = safe_float(context.get("dpo", 0))
    ccc = DSO + DIO - DPO
    title = f"Working Capital / CCC stimato: {ccc:.0f} giorni"
    metrics = [("DSO", f"{DSO:.0f}g"), ("DIO", f"{DIO:.0f}g"), ("DPO", f"{DPO:.0f}g"), ("CCC", f"{ccc:.0f}g")]
    levers = [
        "Riduci **DSO**: sconti per early payment, credito più selettivo.",
        "Riduci **DIO**: planning/riordino, discontinue lenti, migliora rotazioni.",
        "Aumenta **DPO**: negozia scadenze fornitori dove sostenibile.",
    ]
    risks = ["Stock-out se riduci inventario troppo velocemente."]
    narrative = _cfo_block(title, metrics, levers, risks, "Vuoi simulare **DSO−5 / DIO−3 / DPO+5** e l’impatto cassa?")
    return "kpi_wc", ccc, narrative


QUICK_HANDLERS: List[Tuple[re.Pattern, Callable[[Dict[str, Any]], Tuple[str, Optional[float], str]]]] = [
    (re.compile(r"\b(utile|profitto|risultato netto|risultato)\b", re.I), q_utile),
    (re.compile(r"\b(fatturato|ricavi|revenue|sales)\b", re.I), q_fatturato),
    (re.compile(r"\bebitda\b", re.I), q_ebitda),
    (re.compile(r"\bmargine( di contribuzione)?\b", re.I), q_margine),
    (re.compile(r"\broi\b", re.I), q_roi),
    (re.compile(r"(?:\bbreak[- ]?even\b|\bpunto di pareggio\b)", re.I), q_breakeven),
    (re.compile(r"(?:\bworking capital\b|\bccc\b|\bdso\b|\bdio\b|\bdpo\b|\bcassa\b|\bliquidit[àa]\b)", re.I), q_wc),
]


def _run_quick_handlers(user_text: str, context: Dict[str, Any]) -> Optional[Tuple[str, Optional[float], str]]:
    for pat, handler in QUICK_HANDLERS:
        if pat.search(user_text or ""):
            try:
                return handler(context)
            except Exception:
                continue
    return None


# =========================
# Endpoints
# =========================

@router.post("/chat_simple")
def chat_simple(req: ChatSimpleRequest):
    """
    Endpoint semplice: chiama direttamente il modello LLM (senza tool-calling esplicito).
    Usato per prompt liberi / debug. Non tocca il router deterministico.
    """
    session_id = _normalize_session_id(req.session_id)
    clean_text = sanitize_text(req.text or "")
    system_msg = req.system or DEFAULT_SYSTEM

    try:
        res = complete_zephy(
            user=clean_text,
            context=None,
            system=system_msg,
            temperature=float(req.temperature),
            max_tokens=req.max_tokens or 800,
        )
        reply = (res.text or "").strip()
        if not reply:
            reply = "In questo momento non riesco a dare una risposta utile."
    except Exception:
        reply = "In questo momento non riesco a rispondere. Riprova tra poco."

    if reply:
        _append_memory_message(session_id, role="user", content=clean_text)
        _append_memory_message(session_id, role="assistant", content=reply)

    return {"reply": reply}


@router.post("/chat", response_model=ChatResponse)
def chat_endpoint(req: ChatRequest):
    session_id = _normalize_session_id(req.session_id)

    if req.remember:
        _append_memory_message(session_id, role="user", content=req.text)

    clean_text = sanitize_text(req.text or "")
    slots_from_text = extract_slots(clean_text)
    slots_from_text = clamp_extracted_slots(slots_from_text, max_abs=1_000_000_000.0)

    raw_context = {**slots_from_text, **(req.context or {})}
    context = normalize_context_numeric(raw_context)
    context["tenant_id"] = session_id

    # === (A) Pending action confirm
    if AFFIRMATIVE.match(clean_text) and session_id in PENDING_ACTIONS:
        plan = PENDING_ACTIONS.pop(session_id, None) or {}
        ptype = plan.get("type")

        if ptype in ("plan_fixed", "goal_plan"):
            a, b, c = plan.get("a", 0.0), plan.get("b", 0.0), plan.get("c", 0.0)
            goal_pct = plan.get("goal_pct")
            res = _apply_deltas_simple(context, a, b, c)
            narrative = _narrative_plan_and_result(res, goal_pct)

            if req.remember:
                _append_memory_message(session_id, role="assistant", content=narrative)

            return _build_chat_response(
                intent="plan_executed",
                value=res["utile1"],
                value_str=fmt_eur(res["utile1"]),
                narrative=narrative,
                advisories=[],
                tools_used=["quick_plan"],
                sources=None,
                meta={"session_id": session_id, "pending_action_consumed": ptype},
            )

        if ptype == "payback_calc":
            k = _derive_kpi(context)
            inv = safe_float(k.get("investimenti"))
            if inv <= 0:
                text = "Per calcolare il **payback** mi serve un importo in **investimenti** > 0."
            else:
                ebitda = safe_float(k.get("ebitda"))
                if ebitda <= 0:
                    text = f"Investimenti {fmt_eur(inv)}. Non posso stimare il payback perché l'EBITDA è ≤ 0."
                else:
                    years = inv / ebitda
                    text = (
                        f"**Payback stimato:** {years:.1f} anni  \n"
                        f"- Investimenti: {fmt_eur(inv)}  \n"
                        f"- EBITDA: {fmt_eur(ebitda)}  \n\n"
                        f"Per accelerarlo: priorità a iniziative con **margini alti**, riduzione **CV** e **CF** non core."
                    )

            if req.remember:
                _append_memory_message(session_id, role="assistant", content=text)

            return _build_chat_response(
                intent="payback_executed",
                value=None,
                value_str=None,
                narrative=text,
                advisories=[],
                tools_used=["payback_quick"],
                sources=None,
                meta={"session_id": session_id, "pending_action_consumed": ptype},
            )

        if ptype == "explain_utile":
            k = _derive_kpi(context)
            narrative = _utile_analysis_text(k)
            PENDING_ACTIONS[session_id] = {"type": "plan_fixed", "a": 0.05, "b": -0.03, "c": -0.05}

            if req.remember:
                _append_memory_message(session_id, role="assistant", content=narrative)

            return _build_chat_response(
                intent="analysis_utile",
                value=k["utile"],
                value_str=fmt_eur(k["utile"]),
                narrative=narrative,
                advisories=[],
                tools_used=["analysis"],
                sources=None,
                meta={"session_id": session_id, "next_pending_action": "plan_fixed"},
            )

        if ptype == "explain_wc":
            narrative = _wc_analysis_text(context)
            if req.remember:
                _append_memory_message(session_id, role="assistant", content=narrative)

            return _build_chat_response(
                intent="analysis_wc",
                value=None,
                value_str=None,
                narrative=narrative,
                advisories=[],
                tools_used=["wc_whatif_tool"],
                sources=None,
                meta={"session_id": session_id},
            )

        return _build_chat_response(
            intent="no_pending_action",
            value=None,
            value_str=None,
            narrative="Non ho un’azione da eseguire collegata all’ultimo suggerimento.",
            advisories=[],
            tools_used=[],
            sources=None,
            meta={"session_id": session_id},
        )

    # === (B) Goal-based
    goal_pct = _parse_target_increase_pct(clean_text)
    if goal_pct is not None or re.search(r"aument(a|are).+utile", clean_text, re.I):
        k = _derive_kpi(context)
        U0, fatt, cv, cf = k["utile"], k["fatturato"], k["costi_variabili"], k["costi_fissi"]
        target = goal_pct if goal_pct is not None else 10.0

        a, b, c = _distribute_goal(U0, fatt, cv, cf, target)
        res = _apply_deltas_simple(context, a, b, c)

        PENDING_ACTIONS[session_id] = {
            "type": "goal_plan",
            "a": a,
            "b": b,
            "c": c,
            "goal_pct": target,
        }

        narrative = f"""**Obiettivo:** +{target:.1f}% utile (baseline: {fmt_eur(U0)}).  
**Proposta a 3 leve (da confermare):**  
- Ricavi **{fmt_pct(a)}** (pricing / mix / volumi)  
- Costi variabili **{fmt_pct(b)}** (efficienze, sourcing)  
- Costi fissi **{fmt_pct(c)}** (spending review mirata)  
  
Se confermi, applico il piano e ti mostro numeri precisi (utile, EBITDA, MC%)."""

        if req.remember:
            _append_memory_message(session_id, role="assistant", content=narrative)

        return _build_chat_response(
            intent="goal_plan_proposed",
            value=res["utile1"],
            value_str=_fmt_eur(res["utile1"]),
            narrative=narrative,
            advisories=[],
            tools_used=["goal_planner"],
            sources=None,
            meta={"session_id": session_id, "pending_action": "goal_plan", "goal_pct": target},
        )

    # === (C) working capital shortcut
    if re.search(r"(simula|what[- ]?if).*(dso|dio|dpo|ccc|working capital|cassa)", clean_text, re.I):
        wc_text = _wc_analysis_text(context)
        if req.remember:
            _append_memory_message(session_id, role="assistant", content=wc_text)

        return _build_chat_response(
            intent="wc_analysis",
            value=None,
            value_str=None,
            narrative=wc_text,
            advisories=[],
            tools_used=["wc_whatif_tool"],
            sources=None,
            meta={"session_id": session_id},
        )

    # === (D) quick answer
    quick = _run_quick_handlers(clean_text, context)

    # === (E) router response
    router_inst = router_pool.get(session_id)
    try:
        ans = router_inst.handle(clean_text, context)
        ans_data = _extract_answer_fields(ans)
    except IntentMatchingAppError as e:
        # Intent matching failed - provide fallback
        ans_data = {
            "intent": "intent_not_found",
            "value": None,
            "value_str": None,
            "narrative": f"Non ho capito bene la domanda. Puoi riformularla? (Errore: {e.message})",
            "advisories": [],
            "tools_used": [],
            "sources": None,
            "meta": {"router_error": "intent_not_found"},
        }
    except CalculationAppError as e:
        # Calculation failed (division by zero, etc)
        ans_data = {
            "intent": "calculation_error",
            "value": None,
            "value_str": None,
            "narrative": f"Ho incontrato un problema nei calcoli ({e.code}). Controlla i dati di input.",
            "advisories": [],
            "tools_used": [],
            "sources": None,
            "meta": {"router_error": "calculation_error", "details": e.details},
        }
    except Exception as e:
        # Unexpected error - fallback gracefully
        ans_data = {
            "intent": "router_error",
            "value": None,
            "value_str": None,
            "narrative": f"Ho avuto un problema nel router chat ({type(e).__name__}). Riprovami.",
            "advisories": [],
            "tools_used": [],
            "sources": None,
            "meta": {"router_error": type(e).__name__},
        }

    final_intent = ans_data["intent"]
    final_value = ans_data["value"]
    final_value_str = ans_data["value_str"]
    final_narrative = ans_data["narrative"]
    final_advisories = ans_data["advisories"]
    final_tools_used = ans_data["tools_used"] or []
    final_sources = ans_data["sources"]
    final_meta = ans_data["meta"] if isinstance(ans_data["meta"], dict) else {}

    # Quick answers hanno priorità come risposta breve e forte
    if quick:
        q_intent, q_value, q_text = quick
        final_intent = q_intent
        final_value = q_value
        final_value_str = _safe_value_str(q_value)
        final_narrative = q_text

        if q_intent == "kpi_utile":
            PENDING_ACTIONS[session_id] = {"type": "explain_utile"}
        elif q_intent == "kpi_roi":
            PENDING_ACTIONS[session_id] = {"type": "payback_calc"}
        elif q_intent == "kpi_wc":
            PENDING_ACTIONS[session_id] = {"type": "explain_wc"}

    if req.remember:
        _append_memory_message(session_id, role="assistant", content=str(final_narrative or ""))

    final_meta = {
        "session_id": session_id,
        **final_meta,
    }

    return _build_chat_response(
        intent=str(final_intent),
        value=final_value,
        value_str=final_value_str,
        narrative=str(final_narrative or ""),
        advisories=final_advisories,
        tools_used=final_tools_used,
        sources=final_sources,
        meta=final_meta,
    )


@router.post("/chat/reset")
def reset_chat(req: ChatSimpleRequest):
    session_id = _normalize_session_id(req.session_id)
    router_pool.reset(session_id)
    PENDING_ACTIONS.pop(session_id, None)
    try:
        memory.forget(session_id)
    except Exception:
        pass
    return {"status": "ok", "session_id": session_id, "reset": True}