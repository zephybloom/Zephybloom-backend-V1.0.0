# content/api/schemas.py
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Literal, Union
from pydantic import BaseModel, Field, field_validator, model_validator


# =========================
# Base + helpers (Pydantic)
# =========================

class _BaseModel(BaseModel):
    """Modello base: ignora extra per compatibilità retro."""
    model_config = dict(extra="ignore")


class _ResponseBase(_BaseModel):
    """Mixin per tutte le response: versioning + currency + meta opzionale."""
    schema_version: Literal["1.1"] = Field("1.1", description="API contract version")
    currency: Literal["EUR"] = Field("EUR", description="ISO currency of monetary fields")
    meta: Dict[str, Any] = Field(default_factory=dict, description="Diagnostics/notes (non-breaking)")


class _UnitsGuards:
    """Validator helpers: rate/pct, finiteness, non-negativi opzionali."""

    @staticmethod
    def finite_or_zero(v: Optional[float]) -> float:
        if v is None:
            return 0.0
        try:
            x = float(v)
            return x if math.isfinite(x) else 0.0
        except Exception:
            return 0.0

    @staticmethod
    def finite_or_none(v: Optional[float]) -> Optional[float]:
        if v is None:
            return None
        try:
            x = float(v)
            return x if math.isfinite(x) else None
        except Exception:
            return None

    @staticmethod
    def clamp_rate(v: Optional[float]) -> float:
        x = _UnitsGuards.finite_or_zero(v)
        return max(0.0, min(x, 1.0))

    @staticmethod
    def clamp_pct(v: Optional[float]) -> float:
        x = _UnitsGuards.finite_or_zero(v)
        return max(0.0, min(x, 100.0))

    @staticmethod
    def clamp_nonneg(v: Optional[float]) -> float:
        x = _UnitsGuards.finite_or_zero(v)
        return max(0.0, x)

    @staticmethod
    def pass_through_number(v: Optional[float]) -> float:
        return _UnitsGuards.finite_or_zero(v)


# =================
# Requests (DTO in)
# =================

class KPIRequest(_BaseModel):
    """Input grezzo per il calcolo KPI. Importi in EUR, giorni in gg."""
    fatturato: float = Field(0, ge=0, description="Ricavi / vendite")
    costi_variabili: float = Field(0, ge=0, description="Costi variabili totali")
    costi_fissi: float = Field(0, ge=0, description="Costi fissi totali")
    investimenti: float = Field(0, ge=0, description="Capex / investimenti")
    prezzo_medio: float = Field(0, ge=0, description="Prezzo medio unitario")
    costo_variabile_unitario: float = Field(0, ge=0, description="CVU (costo variabile unitario)")
    cogs: float = Field(0, ge=0, description="Costo del venduto (alternativa a costi variabili)")
    ammortamenti: float = Field(0, ge=0, description="Ammortamenti")
    dso: float = Field(0, ge=0, description="Days Sales Outstanding (giorni)")
    dio: float = Field(0, ge=0, description="Days Inventory Outstanding (giorni)")
    dpo: float = Field(0, ge=0, description="Days Payables Outstanding (giorni)")
    wc: float = Field(0, ge=0, description="Working capital (facoltativo)")
    re: float = Field(0, ge=0, description="Retained earnings (alias vendite in alcuni contesti)")
    ebit: float = Field(0, description="EBIT (può essere < 0)")
    mve: float = Field(0, ge=0, description="Market Value of Equity")
    sales: float = Field(0, ge=0, description="Alias fatturato")
    ta: float = Field(0, ge=0, description="Total Assets")
    tl: float = Field(0, ge=0, description="Total Liabilities")
    mrr: float = Field(0, ge=0, description="Monthly Recurring Revenue (SaaS)")
    churn_rate: float = Field(0, ge=0, description="Churn rate in punti percentuali (es. 5 = 5%)")
    cac: float = Field(0, ge=0, description="Customer Acquisition Cost")
    ltv: float = Field(0, ge=0, description="Lifetime Value (se assente sarà stimato)")
    arpu: float = Field(0, ge=0, description="Average Revenue Per User")
    nrr: float = Field(0, ge=0, description="Net Revenue Retention (pp, es. 110 = 110%)")
    sector: str = Field("default", description="Settore (es. retail, saas, restaurant)")

    @field_validator("dso", "dio", "dpo")
    @classmethod
    def _cap_days(cls, v: float) -> float:
        return max(0.0, min(float(v or 0.0), 3650.0))

    @field_validator("sector")
    @classmethod
    def _normalize_sector(cls, v: str) -> str:
        return str(v or "default").strip().lower() or "default"


class SimulateRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="Base numerica (fatturato, costi, prezzi, ecc.)")
    delta: Dict[str, float] = Field(default_factory=dict, description="Delta %/assoluti (es. prezzo_pct, costi_fissi_abs)")


class ForecastRequest(_BaseModel):
    history: List[float] = Field(default_factory=list, description="Serie storica (unità coerenti con endpoint)")
    periods: int = Field(6, ge=1, description="Numero di periodi futuri (>=1)")
    method: str = Field("sma", description="Metodo ('sma' | 'ema' | 'holt' | fallback naive)")

    @field_validator("method")
    @classmethod
    def _norm_method(cls, v: str) -> str:
        return (v or "sma").strip().lower()


class ValuationRequest(_BaseModel):
    cashflows: Optional[List[float]] = Field(None, description="[CF0, CF1..] per NPV/IRR/Payback")
    discount_rate_pct: Optional[float] = Field(None, description="Tasso sconto in pp (10 = 10%)")
    dcf_fcf: Optional[List[float]] = Field(None, description="[FCF1..FCFn] per valutazione DCF")
    terminal_growth_pct: float = Field(2.0, description="Crescita terminale (pp)")
    net_debt: float = Field(0.0, description="Debito netto (EV→Equity)")
    ke: Optional[float] = Field(None, description="Costo Equity (pp)")
    kd: Optional[float] = Field(None, description="Costo Debito (pp)")
    equity: Optional[float] = Field(None, description="Valore Equity (per WACC)")
    debt: Optional[float] = Field(None, description="Valore Debito (per WACC)")
    tax_rate: Optional[float] = Field(None, description="Aliquota fiscale (pp)")

    @model_validator(mode="after")
    def _noop(self):
        return self


class OpportunitiesRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="Base numerica (fatturato, costi, ecc.)")
    price_elasticity: float = Field(-1.2, description="Elasticità domanda al prezzo")
    sector: str = Field("default", description="Settore (influenza il playbook)")


class MonteCarloRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="Base numerica")
    uncertainties: Dict[str, Dict[str, float]] = Field(..., description="Mappa delta->parametri dist (mu/sigma o a/b/c)")
    n: int = Field(300, ge=10, le=25000, description="Numero simulazioni (10..25000)")


class IngestDoc(_BaseModel):
    id: str = Field(..., description="ID documento")
    text: str = Field(..., description="Contenuto testuale")
    title: Optional[str] = Field(None, description="Titolo")
    url: Optional[str] = Field(None, description="URL di riferimento")
    meta: Optional[Dict[str, Any]] = Field(None, description="Metadati arbitrari")


class IngestRequest(_BaseModel):
    docs: List[IngestDoc] = Field(..., description="Documenti da indicizzare")
    chunk_size: int = Field(350, ge=50, le=2000, description="Lunghezza chunk fallback")
    overlap: int = Field(50, ge=0, le=500, description="Overlap tra chunk")
    model_config = dict(
        extra="ignore",
        json_schema_extra={
            "example": {
                "docs": [{"id": "doc-1", "text": "Contenuto...", "title": "Titolo", "url": "https://..."}],
                "chunk_size": 350,
                "overlap": 50,
            }
        },
    )


class SearchRequest(_BaseModel):
    query: str = Field(..., description="Query testuale")
    k: int = Field(4, ge=1, le=20, description="Top-K risultati")


class ChatRequest(_BaseModel):
    text: str = Field(..., description="Messaggio utente")
    context: Dict[str, Any] = Field(default_factory=dict, description="Contesto numerico/fatti già noti")
    session_id: str = Field("default", description="ID sessione conversazionale")
    use_tools: bool = Field(True, description="Abilita tool-calling interno (best effort)")
    remember: bool = Field(True, description="Memorizza lo scambio nella finestra conversazionale")
    use_rag: bool = Field(False, description="(Riservato) abilita RAG")
    rag_k: int = Field(4, ge=1, le=10, description="Top-K RAG")
    model_config = dict(
        extra="ignore",
        json_schema_extra={
            "example": {
                "text": "Calcola l'utile e proponi 3 azioni per aumentarlo del 10%.",
                "context": {
                    "fatturato": 1_200_000,
                    "costi_variabili": 700_000,
                    "costi_fissi": 350_000,
                },
            }
        },
    )

    @field_validator("session_id")
    @classmethod
    def _normalize_session_id(cls, v: str) -> str:
        s = str(v or "default").strip()
        return s[:120] if s else "default"

    @field_validator("text")
    @classmethod
    def _normalize_text(cls, v: str) -> str:
        return str(v or "").strip()


class ParseDebugRequest(_BaseModel):
    text: str = Field(..., description="Testo da parsare")
    context: Dict[str, Any] = Field(default_factory=dict, description="Contesto da unire")


class PriceOptimizeRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="prezzo_medio, costo_variabile_unitario, fatturato, costi_fissi, price_elasticity")


class PriceLadderRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="prezzo_medio, costo_variabile_unitario, fatturato, costi_fissi, price_elasticity")
    pct_min: float = Field(-20.0, description="Variazione prezzo minima (%)")
    pct_max: float = Field(20.0, description="Variazione prezzo massima (%)")
    pct_step: float = Field(1.0, gt=0, description="Passo in punti percentuali (>0)")

    @model_validator(mode="after")
    def _ensure_range(self):
        if self.pct_min > self.pct_max:
            self.pct_min, self.pct_max = self.pct_max, self.pct_min
        return self


class BreakevenRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="prezzo_medio, costo_variabile_unitario, costi_fissi (+ opz. qty/fatturato)")


class WCImpactRequest(_BaseModel):
    base: Dict[str, float] = Field(..., description="fatturato, cogs/costi_variabili, dso, dio, dpo, dso_delta, dio_delta, dpo_delta")


class AlertsRequest(_BaseModel):
    context: Dict[str, Any] = Field(default_factory=dict, description="Contesto per calcolo KPI + regole")
    sector: str = Field("default", description="Settore per eventuali regole/benchmark")


class ChatSimpleRequest(_BaseModel):
    text: str = Field(..., description="Prompt semplice (no tool-calling)")
    session_id: str = Field("default", description="ID sessione")
    system: Optional[str] = Field(None, description="System prompt opzionale")
    temperature: float = Field(0.2, ge=0, le=2, description="Creatività del modello (0..2)")
    max_tokens: Optional[int] = Field(None, ge=1, description="Limite token risposta")

    @field_validator("session_id")
    @classmethod
    def _normalize_session_id(cls, v: str) -> str:
        s = str(v or "default").strip()
        return s[:120] if s else "default"

    @field_validator("text")
    @classmethod
    def _normalize_text(cls, v: str) -> str:
        return str(v or "").strip()


# =================
# Responses (DTO out)
# =================

class KPIResponse(_ResponseBase):
    sales: float = Field(..., description="Ricavi")
    cogs: float = Field(..., description="Costo del venduto")
    gross_margin: float = Field(..., description="MC = sales - cogs")
    gross_margin_rate: float = Field(..., description="MC rate ∈ [0,1]")
    fixed_costs: float = Field(..., description="Costi fissi")
    depreciation: float = Field(..., description="Ammortamenti")
    ebitda: float = Field(..., description="EBITDA")
    ebit: float = Field(..., description="EBIT")
    taxes: float = Field(..., description="Imposte (se disponibili)")
    net_income: float = Field(..., description="Utile netto (se taxes==0 ⇒ = EBIT)")
    net_margin_rate: float = Field(..., description="Net margin ∈ [0,1]")
    roi_pct: float = Field(..., description="ROI in percentuale (0..100)")
    dso: float = Field(..., description="Days Sales Outstanding")
    dio: float = Field(..., description="Days Inventory Outstanding")
    dpo: float = Field(..., description="Days Payables Outstanding")
    ccc_days: float = Field(..., description="CCC (giorni)")
    wc_need: float = Field(..., description="Fabbisogno CC stimato")
    break_even_qty: float = Field(..., description="Quantità BE")
    break_even_revenue: float = Field(..., description="Ricavi BE")

    @field_validator("gross_margin_rate", "net_margin_rate")
    @classmethod
    def _rate_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_rate(v)

    @field_validator("roi_pct")
    @classmethod
    def _pct_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_pct(v)

    @field_validator("sales", "cogs", "fixed_costs", "depreciation", "dso", "dio", "dpo", "wc_need", "break_even_qty", "break_even_revenue")
    @classmethod
    def _nonneg_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)

    @field_validator("gross_margin", "ebitda", "ebit", "taxes", "net_income", "ccc_days")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class SimulateResponse(_ResponseBase):
    sales: float
    cogs: float
    gross_margin: float
    gross_margin_rate: float
    fixed_costs: float
    depreciation: float
    ebitda: float
    ebit: float
    taxes: float
    net_income: float
    net_margin_rate: float
    roi_pct: float
    ccc_days: float = 0.0
    break_even_qty: float
    break_even_revenue: float
    assumptions: Dict[str, Any] = Field(default_factory=dict, description="Assunzioni (elasticity, base_qty, price_base, range, ecc.)")

    @field_validator("gross_margin_rate", "net_margin_rate")
    @classmethod
    def _rate_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_rate(v)

    @field_validator("roi_pct")
    @classmethod
    def _pct_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_pct(v)

    @field_validator("sales", "cogs", "fixed_costs", "depreciation", "break_even_qty", "break_even_revenue")
    @classmethod
    def _nonneg_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)

    @field_validator("gross_margin", "ebitda", "ebit", "taxes", "net_income", "ccc_days")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class BreakevenResponse(_ResponseBase):
    mc_rate: float
    be_qty: float
    be_revenue: float

    @field_validator("mc_rate")
    @classmethod
    def _rate_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_rate(v)

    @field_validator("be_qty", "be_revenue")
    @classmethod
    def _nonneg_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)


class PriceOptimizeResponse(_ResponseBase):
    best_pct: float = Field(..., description="Δ prezzo ottimale (%) rispetto a baseline")
    best_price: float = Field(..., description="Prezzo ottimale")
    best_profit: float = Field(..., description="Utile/profitto stimato al best")
    assumptions: Dict[str, Any] = Field(default_factory=dict, description="elasticity, base_qty, explored_range, model")

    @field_validator("best_price")
    @classmethod
    def _best_price_nonneg(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)

    @field_validator("best_pct", "best_profit")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class PriceLadderRow(_BaseModel):
    pct: float
    price: float
    quantity: float
    revenue: float
    profit: float

    @field_validator("pct", "profit")
    @classmethod
    def _finite_signed(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)

    @field_validator("price", "quantity", "revenue")
    @classmethod
    def _finite_nonneg(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)


class PriceLadderResponse(_ResponseBase):
    rows: List[PriceLadderRow]
    best: PriceLadderRow
    assumptions: Dict[str, Any] = Field(default_factory=dict, description="elasticity, base_qty, bounds")


class WCImpactResponse(_ResponseBase):
    ccc_before: float
    ccc_after: float
    delta_ccc: float
    wc_need_before: float
    wc_need_after: float
    delta_cash: float
    ccc: float
    notes: Dict[str, Any] = Field(default_factory=dict, description="Es. {'no_change_applied': True}")

    @field_validator("ccc_before", "ccc_after", "wc_need_before", "wc_need_after", "ccc")
    @classmethod
    def _nonneg_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_nonneg(v)

    @field_validator("delta_ccc", "delta_cash")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class ValuationProjectEval(_BaseModel):
    npv: float
    irr: Optional[float] = None
    payback_period: Optional[float] = None

    @field_validator("npv")
    @classmethod
    def _finite_npv(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)

    @field_validator("irr", "payback_period")
    @classmethod
    def _finite_optional(cls, v: Optional[float]) -> Optional[float]:
        return _UnitsGuards.finite_or_none(v)


class ValuationProjectResponse(_ResponseBase):
    narrative: str
    discount_rate_pct: float
    project_eval: ValuationProjectEval

    @field_validator("discount_rate_pct")
    @classmethod
    def _pct_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_pct(v)


class ValuationDCF(_BaseModel):
    enterprise_value: float
    equity_value: float
    wacc_pct: float
    pv_explicit: float
    pv_terminal: float
    terminal_method: Literal["gordon", "exit_multiple"] = "gordon"

    @field_validator("wacc_pct")
    @classmethod
    def _pct_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_pct(v)

    @field_validator("enterprise_value", "equity_value", "pv_explicit", "pv_terminal")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class ValuationDCFResponse(_ResponseBase):
    narrative: str
    discount_rate_pct: float
    dcf: ValuationDCF

    @field_validator("discount_rate_pct")
    @classmethod
    def _pct_guard(cls, v: float) -> float:
        return _UnitsGuards.clamp_pct(v)


class OpportunityItem(_BaseModel):
    title: str
    delta_profit_eur: float
    delta_roi_pct: float
    steps: List[str]
    meta: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("delta_profit_eur", "delta_roi_pct")
    @classmethod
    def _finite_guard(cls, v: float) -> float:
        return _UnitsGuards.pass_through_number(v)


class OpportunitiesResponse(_ResponseBase):
    top_opportunities: List[OpportunityItem]


class AlertItem(_BaseModel):
    code: str
    message: str
    severity: Literal["info", "warning", "critical"] = "info"
    meta: Dict[str, Any] = Field(default_factory=dict)


class AlertsResponse(_ResponseBase):
    alerts: List[AlertItem]
    kpi: Dict[str, Any] = Field(default_factory=dict)


class ChatResponse(_ResponseBase):
    intent: str = Field(..., description="Intent rilevato/risposta")
    value: Optional[float] = Field(None, description="Valore numerico rilevante (se applicabile)")
    value_str: Optional[str] = Field(None, description="Valore formattato (se applicabile)")
    narrative: str = Field(..., description="Testo di risposta")
    advisories: List[Dict[str, Any]] = Field(default_factory=list, description="Avvisi/consigli strutturati")
    tools_used: List[str] = Field(default_factory=list, description="Elenco tool utilizzati (nomi)")
    sources: Optional[List[Dict[str, Any]]] = Field(None, description="Fonti RAG (se presenti)")

    @field_validator("tools_used", mode="before")
    @classmethod
    def _normalize_tools_used(cls, v: Any) -> List[str]:
        if v is None:
            return []
        if isinstance(v, list):
            return [str(x) for x in v if x is not None]
        return [str(v)]

    @field_validator("advisories", mode="before")
    @classmethod
    def _normalize_advisories(cls, v: Any) -> List[Dict[str, Any]]:
        if v is None:
            return []

        out: List[Dict[str, Any]] = []
        if not isinstance(v, list):
            v = [v]

        for item in v:
            if item is None:
                continue

            if isinstance(item, dict):
                out.append({
                    "code": item.get("code", "INFO"),
                    "title": item.get("title", ""),
                    "detail": item.get("detail", ""),
                    "severity": item.get("severity", "info"),
                    "suggestions": item.get("suggestions", []) or [],
                })
                continue

            if hasattr(item, "model_dump"):
                try:
                    d = item.model_dump()
                    if isinstance(d, dict):
                        out.append({
                            "code": d.get("code", "INFO"),
                            "title": d.get("title", ""),
                            "detail": d.get("detail", ""),
                            "severity": d.get("severity", "info"),
                            "suggestions": d.get("suggestions", []) or [],
                        })
                        continue
                except Exception:
                    pass

            out.append({
                "code": getattr(item, "code", "INFO"),
                "title": getattr(item, "title", ""),
                "detail": getattr(item, "detail", ""),
                "severity": getattr(item, "severity", "info"),
                "suggestions": getattr(item, "suggestions", []) or [],
            })

        return out

    @field_validator("sources", mode="before")
    @classmethod
    def _normalize_sources(cls, v: Any) -> Optional[List[Dict[str, Any]]]:
        if v is None:
            return None
        if not isinstance(v, list):
            return None

        out: List[Dict[str, Any]] = []
        for item in v:
            if isinstance(item, dict):
                out.append(item)
            elif hasattr(item, "model_dump"):
                try:
                    d = item.model_dump()
                    if isinstance(d, dict):
                        out.append(d)
                except Exception:
                    continue
        return out or None

    @model_validator(mode="after")
    def _cleanup_chat_response(self):
        if self.value is not None:
            try:
                if not math.isfinite(float(self.value)):
                    self.value = None
                    self.value_str = None
            except Exception:
                self.value = None
                self.value_str = None

        self.intent = str(self.intent or "unknown")
        self.narrative = str(self.narrative or "")

        if not isinstance(self.meta, dict):
            self.meta = {}

        if not isinstance(self.advisories, list):
            self.advisories = []

        if not isinstance(self.tools_used, list):
            self.tools_used = []

        return self