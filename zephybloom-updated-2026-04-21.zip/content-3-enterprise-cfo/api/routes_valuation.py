# -*- coding: utf-8 -*-
# content/api/routes_valuation.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import ValuationRequest
from core.valuation import project_eval, dcf_gordon
from utils.errors import CalculationAppError, ValidationAppError, from_exception

router = APIRouter()

@router.post("/valuation")
def valuation_route(req: ValuationRequest):
    try:
        out = {"discount_rate_pct": req.discount_rate_pct}
        # Project eval (se cashflows presenti)
        if req.cashflows:
            try:
                r = float((req.discount_rate_pct or 10.0) / 100.0)
                npv, irr, payback = project_eval([float(x) for x in req.cashflows], r)
                out["project_eval"] = {"npv": npv, "irr": (irr * 100.0) if irr is not None else None, "payback_period": payback}
            except (ValueError, ZeroDivisionError, ArithmeticError) as e:
                raise CalculationAppError(
                    "Errore nel calcolo project evaluation (NPV/IRR)",
                    details={
                        "error_type": type(e).__name__,
                        "message": str(e),
                        "endpoint": "project_eval",
                    },
                    cause=e,
                )
        # DCF (se dcf_fcf presenti)
        if req.dcf_fcf:
            try:
                r = float((req.discount_rate_pct or 10.0) / 100.0)
                g = float((req.terminal_growth_pct or 2.0) / 100.0)
                ev, equity, pv_explicit, pv_terminal = dcf_gordon([float(x) for x in req.dcf_fcf], r, g, float(req.net_debt or 0.0))
                out["dcf"] = {
                    "enterprise_value": ev,
                    "equity_value": equity,
                    "wacc_pct": req.discount_rate_pct,
                    "pv_explicit": pv_explicit,
                    "pv_terminal": pv_terminal,
                    "terminal_method": "gordon",
                }
            except (ValueError, ZeroDivisionError, ArithmeticError) as e:
                raise CalculationAppError(
                    "Errore nel calcolo DCF (Gordon)",
                    details={
                        "error_type": type(e).__name__,
                        "message": str(e),
                        "endpoint": "dcf_gordon",
                    },
                    cause=e,
                )
        # Narrativa sintetica
        parts = []
        if "project_eval" in out:
            pe = out["project_eval"]
            if pe["irr"] is not None:
                parts.append(f"NPV {round(pe['npv']):,}".replace(",", ""))
                parts.append(f"IRR {pe['irr']:.2f}%")
                parts.append(f"Payback {pe['payback_period']} anni")
        if "dcf" in out:
            dv = out["dcf"]
            parts.append(f"DCF: EV≈{round(dv['enterprise_value']):,}, Equity≈{round(dv['equity_value']):,} (WACC {dv['wacc_pct']:.2f}%).".replace(",", ""))
        out["narrative"] = " | ".join(parts) if parts else "Nessun dato sufficiente per la valutazione."
        return out
    except CalculationAppError:
        raise
    except Exception as e:
        raise from_exception(e, message="Unexpected error during valuation")
