# -*- coding: utf-8 -*-
# content/api/routes_alerts.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import AlertsRequest
from core.kpi_engine import compute_kpi, KPIOptions
from core.alerts import evaluate_alerts
from utils.errors import CalculationAppError, from_exception

router = APIRouter()

@router.post("/alerts/evaluate")
def alerts_route(req: AlertsRequest):
    try:
        opts = KPIOptions(sector=req.sector or "default")
        kpi = compute_kpi(req.context or {}, options=opts)
        alerts = evaluate_alerts(kpi, sector=req.sector)
        # riportiamo parte dei KPI in risposta per trasparenza/debug come fai nei test
        return {"alerts": alerts, "kpi": kpi}
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nella valutazione degli alert",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "alerts_evaluate",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during alert evaluation")
