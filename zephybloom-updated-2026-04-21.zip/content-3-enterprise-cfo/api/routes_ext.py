# content/api/routes_ext.py
from __future__ import annotations
from fastapi import APIRouter, Depends
from typing import Any, Dict, List
from infra.tenancy import get_tenant_id
from core.scenario import simulate_matrix
from core.finance import project_eval
from nlp.router import NLPRouter
from core.metrics import compute_kpis
from core.rules_engine import load_rules
from utils.errors import CalculationAppError, from_exception

router = APIRouter(prefix="/api", tags=["core-ext"])
_nlp = NLPRouter(rules_dir="content/knowledge/rules", intents_dir="content/nlp/intents")

@router.post("/simulate/matrix")
def simulate_matrix_ep(payload: Dict[str, Any], tenant_id: str = Depends(get_tenant_id)):
    try:
        base = payload.get("base", {})
        grid = payload.get("grid", {})
        res = simulate_matrix(base, grid)
        return {"items": res}
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nella simulazione matrice",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "simulate_matrix",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during matrix simulation")

@router.post("/valuation/scenarios")
def valuation_scenarios(payload: Dict[str, Any], tenant_id: str = Depends(get_tenant_id)):
    """
    payload: {"scenarios":[ {"cashflows":[..],"discount_rate_pct":..}, ... ]}
    """
    try:
        out = []
        for sc in payload.get("scenarios", []):
            cf = sc.get("cashflows", [])
            dr = sc.get("discount_rate_pct", 10.0)
            out.append(project_eval(cf, dr))
        return {"items": out}
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nel calcolo scenari di valutazione",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "valuation_scenarios",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during valuation scenarios")

@router.post("/valuation/stress")
def valuation_stress(payload: Dict[str, Any], tenant_id: str = Depends(get_tenant_id)):
    """
    payload: {"cashflows":[..], "discount_rates":[8,10,12]}
    """
    try:
        cf = payload.get("cashflows", [])
        rates = payload.get("discount_rates", [8, 10, 12])
        return {"items": [project_eval(cf, r) for r in rates]}
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nell'analisi di stress valuation",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "valuation_stress",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during valuation stress analysis")

@router.post("/kpi/sensitivity")
def kpi_sensitivity(payload: Dict[str, Any], tenant_id: str = Depends(get_tenant_id)):
    """
    payload: base KPI + {"params":{"fatturato_pct":[-5,0,5], "costi_fissi_pct":[-5,0,5] ...}}
    """
    try:
        base = {k: payload.get(k, 0.0) for k in ["fatturato","costi_variabili","costi_fissi","investimenti","prezzo_medio","costo_variabile_unitario","cogs","ammortamenti","dso","dio","dpo"]}
        params = payload.get("params", {})
        grid = {}
        for k, arr in params.items():
            grid[k] = arr
        sims = []
        # usa il router simulate per coerenza narrativa se vuoi, qui facciamo diretto:
        for f in grid.get("fatturato_pct", [0]):
            for cv in grid.get("costi_variabili_pct", [0]):
                for cf in grid.get("costi_fissi_pct", [0]):
                    sc = {"fatturato_pct": f, "costi_variabili_pct": cv, "costi_fissi_pct": cf}
                    from core.scenario import simulate
                    sims.append(simulate(base, sc))
        return {"items": sims}
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nell'analisi di sensibilità KPI",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "kpi_sensitivity",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during KPI sensitivity analysis")

@router.get("/rules/list")
def rules_list():
    try:
        return {"rules": load_rules("content/knowledge/rules")}
    except Exception as e:
        raise from_exception(e, message="Unexpected error loading rules")
