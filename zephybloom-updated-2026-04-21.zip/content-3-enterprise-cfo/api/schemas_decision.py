"""
Enhanced CFO Analysis with Full Decision-Making

Extends the basic AnalyzeResponse with complete strategic decisions.
Created by DecisionCoordinator to provide actionable strategic guidance.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

from api.schemas_cfo import AnalyzeResponse, RecommendedAction
from core.tone_manager import CFOTone
from core.industry_adapter import IndustryInsight


class ObjectionDetail(BaseModel):
    """Response to a likely entrepreneur objection"""
    objection: str = Field(..., description="The objection/pushback")
    response: str = Field(..., description="Data-driven response")
    supporting_data: Dict[str, Any] = Field(default_factory=dict)
    recommendation: str = Field(..., description="What to do about it")


class ActionDetail(BaseModel):
    """Individual action in a plan"""
    description: str
    priority: str  # HIGH, MEDIUM, LOW
    expected_outcome: str
    success_metric: str


class ActionPlanDetail(BaseModel):
    """24-hour, 7-day, 30-day action plan"""
    timeline_24h: List[ActionDetail] = Field(default_factory=list)
    timeline_7gg: List[ActionDetail] = Field(default_factory=list)
    timeline_30gg: List[ActionDetail] = Field(default_factory=list)


class StrategicDecisionDetail(BaseModel):
    """Complete strategic decision with all supporting analysis"""
    # Core decision
    title: str = Field(..., description="Decision title (e.g., 'Hire VP Operations')")
    description: str = Field(..., description="What and why")
    verdict: str = Field(..., description="GO, MAYBE, WAIT, BUILD_FIRST")
    
    # Impact
    priority_score: float = Field(..., ge=0, le=100, description="ROI/effort score 0-100")
    impact_eur: float = Field(..., description="Estimated financial impact in EUR")
    
    # Cost of inaction
    cost_of_inaction_monthly: float = Field(
        ...,
        description="Cost of doing nothing per month"
    )
    cost_of_inaction_6m: float = Field(
        ...,
        description="Cumulative cost over 6 months"
    )
    timeline_to_crisis: str = Field(
        ...,
        description="When does inaction become critical? (e.g., '3-6 months')"
    )
    
    # Simulations
    best_case: Dict[str, Any] = Field(default_factory=dict)
    realistic_case: Dict[str, Any] = Field(default_factory=dict)
    worst_case: Dict[str, Any] = Field(default_factory=dict)
    
    # Action plan
    action_plan: ActionPlanDetail = Field(default_factory=ActionPlanDetail)
    
    # Objections
    common_objections: List[ObjectionDetail] = Field(
        default_factory=list,
        description="Likely pushback from entrepreneur with responses"
    )
    
    # Tone & messaging
    tone: CFOTone = Field(
        default=CFOTone.COMPETENT,
        description="How to frame this decision: SOFT, COMPETENT, FIRM, DIRECT, HARSH, MANAGER, MOTIVATOR"
    )
    tone_message: str = Field(
        ...,
        description="Tone-adjusted messaging"
    )


class WowMomentDetail(BaseModel):
    """Memorable insight from analysis"""
    title: str = Field(..., description="What's the memorable insight?")
    description: str = Field(..., description="Why is this important?")
    memorability_score: float = Field(..., ge=1, le=10, description="1-10 impact score")
    supporting_metric: Optional[str] = Field(None)
    supporting_value: Optional[float] = Field(None)


class ExecutiveSummaryDetail(BaseModel):
    """Strategic summary for executives"""
    headline: str = Field(..., description="Main finding")
    situation: str = Field(..., description="What's happening now?")
    opportunity: str = Field(..., description="What CAN we do?")
    primary_decision: str = Field(..., description="What SHOULD we do first?")
    timeline: str = Field(..., description="24h-7gg-30gg action timeline")
    wow_moments: List[WowMomentDetail] = Field(
        default_factory=list,
        description="2-3 memorable insights"
    )


class EnhancedAnalyzeResponse(BaseModel):
    """
    Enhanced CFO analysis response with full decision-making system.
    
    Extends AnalyzeResponse with:
    - Strategic decisions (ranked by ROI/effort)
    - Cost of inaction (quantifies risk)
    - Action plans (24h-7gg-30gg)
    - Objection responses (anticipate pushback)
    - Tone management (appropriate tone for context)
    - Memorable insights (wow moments)
    """
    
    # Basic analysis (pass-through)
    status: str = Field(..., description="Health status: healthy, warning, critical")
    headline: str = Field(..., description="Executive summary")
    summary: str = Field(..., description="Detailed analysis")
    
    # KPI snapshot
    gross_profit_eur: Optional[float] = None
    gross_margin_pct: Optional[float] = None
    ebitda_eur: Optional[float] = None
    ebitda_margin_pct: Optional[float] = None
    net_profit_eur: Optional[float] = None
    net_margin_pct: Optional[float] = None
    roi_pct: Optional[float] = None
    ccc_days: Optional[int] = None
    
    # ===== DECISION SYSTEM FIELDS =====
    
    # Industry context (NEW)
    industry_insight: Optional[Dict[str, Any]] = Field(
        None,
        description="Industry-specific insights: health assessment, benchmarks, competitive position"
    )
    
    # Executive summary (strategic overview)
    executive_summary: ExecutiveSummaryDetail = Field(
        default_factory=ExecutiveSummaryDetail,
        description="High-level strategic summary"
    )
    
    # Strategic decisions (ranked 1-3)
    strategic_decisions: List[StrategicDecisionDetail] = Field(
        default_factory=list,
        min_items=0,
        max_items=3,
        description="Top 3 strategic decisions (ranked)"
    )
    
    # Trend context
    trend_narrative: Optional[str] = Field(
        None,
        description="How is the company evolving? (if historical data available)"
    )
    
    # Metadata
    decision_timestamp: datetime = Field(
        default_factory=datetime.now,
        description="When was decision analysis run?"
    )
    
    company_id: Optional[str] = Field(
        None,
        description="Company identifier for memory/history"
    )
    
    model_version: str = Field(
        default="decision-v1.0",
        description="Version of decision system"
    )


# ===== Conversion function =====

def convert_to_enhanced_response(
    base_analysis: AnalyzeResponse,
    decisions: List[StrategicDecisionDetail],
    executive_summary: ExecutiveSummaryDetail,
    trend_narrative: Optional[str] = None,
    company_id: Optional[str] = None,
) -> EnhancedAnalyzeResponse:
    """Convert base analysis + decisions to enhanced response"""
    
    return EnhancedAnalyzeResponse(
        status=base_analysis.status,
        headline=base_analysis.headline,
        summary=base_analysis.summary,
        gross_profit_eur=base_analysis.kpi_snapshot.gross_profit_eur if base_analysis.kpi_snapshot else None,
        gross_margin_pct=base_analysis.kpi_snapshot.gross_margin_pct if base_analysis.kpi_snapshot else None,
        ebitda_eur=base_analysis.kpi_snapshot.ebitda_eur if base_analysis.kpi_snapshot else None,
        ebitda_margin_pct=base_analysis.kpi_snapshot.ebitda_margin_pct if base_analysis.kpi_snapshot else None,
        net_profit_eur=base_analysis.kpi_snapshot.net_profit_eur if base_analysis.kpi_snapshot else None,
        net_margin_pct=base_analysis.kpi_snapshot.net_margin_pct if base_analysis.kpi_snapshot else None,
        roi_pct=base_analysis.kpi_snapshot.roi_pct if base_analysis.kpi_snapshot else None,
        ccc_days=base_analysis.kpi_snapshot.ccc_days if base_analysis.kpi_snapshot else None,
        executive_summary=executive_summary,
        strategic_decisions=decisions,
        trend_narrative=trend_narrative,
        company_id=company_id,
    )
