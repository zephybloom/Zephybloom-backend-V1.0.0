# -*- coding: utf-8 -*-
"""
LLM operations wrapper con circuit breaker e error handling specifici.

Centralizza la logica di:
  - Circuit breaker per proteggere da cascading failures
  - Retry logic con backoff
  - Specific error mapping (rate limit, timeout, ecc.)
  - Structured logging
  - Fallback strategies

Utilizzo:

    llm_ops = LLMOperations()
    
    try:
        response = llm_ops.chat(messages, system=..., temperature=0.2)
    except LLMRateLimitAppError:
        # implementa retry o fallback
    except LLMAppError as e:
        # gestisci errore LLM
        log.error(f"LLM error: {e.code}")
"""
from __future__ import annotations

import time
from typing import Any, Optional

from utils.logging_utils import get_logger
from utils.errors import (
    LLMAppError,
    LLMRateLimitAppError,
    TimeoutAppError,
    ExternalServiceAppError,
    ValidationAppError,
)
from utils.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerOpenError,
    get_llm_breaker,
)

log = get_logger("api.llm_ops")


class LLMOperations:
    """
    High-level interface per operazioni LLM con error handling.
    Wrappa llm_adapter.complete_zephy() e fornisce circuit breaking.
    """
    
    def __init__(self, max_retries: int = 2, retry_delay_s: float = 1.0):
        self.max_retries = max_retries
        self.retry_delay_s = retry_delay_s
        self.breaker = get_llm_breaker()
    
    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        system: Optional[str] = None,
        temperature: float = 0.2,
        stream: bool = False,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """
        Call LLM chat with circuit breaker protection.
        
        Raises:
            CircuitBreakerOpenError: Service is down (use fallback)
            LLMRateLimitAppError: Rate limited
            LLMAppError: Other LLM errors
            TimeoutAppError: Timeout
            ValidationAppError: Invalid input
        """
        # Validate inputs early
        if not messages or not isinstance(messages, list):
            raise ValidationAppError("messages must be a non-empty list")
        
        # Import here to avoid circular dependency
        from nlp.llm_adapter import complete_zephy, DEFAULT_SYSTEM
        
        # Bind circuit breaker
        def _wrapped_call() -> str:
            return complete_zephy(
                messages,
                system=system or DEFAULT_SYSTEM,
                temperature=temperature,
                stream=stream,
                max_tokens=max_tokens,
                **kwargs,
            )
        
        # Attempt with circuit breaker
        attempt = 0
        last_error = None
        
        while attempt <= self.max_retries:
            try:
                result = self.breaker.call(_wrapped_call)
                log.debug(f"LLM call succeeded on attempt {attempt + 1}")
                return result
            
            except CircuitBreakerOpenError as e:
                log.warning(f"Circuit breaker OPEN: {e}")
                raise LLMAppError(
                    "LLM service is temporarily unavailable (circuit breaker open)",
                    details={"breaker_state": str(self.breaker.get_state())},
                    cause=e,
                ).with_status(503)
            
            except TimeoutError as e:
                log.warning(f"LLM timeout on attempt {attempt + 1}: {e}")
                last_error = e
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay_s * (2 ** attempt))  # exponential backoff
                    attempt += 1
                else:
                    raise TimeoutAppError(
                        "LLM request timed out after retries",
                        details={"attempts": attempt + 1, "max_retries": self.max_retries},
                        cause=e,
                    ).with_status(504)
            
            except Exception as e:
                # Check for rate limit indicators
                error_str = str(e).lower()
                if "rate" in error_str or "quota" in error_str or "429" in error_str:
                    log.warning(f"LLM rate limit detected: {e}")
                    raise LLMRateLimitAppError(
                        "OpenAI API rate limit exceeded",
                        details={"error_message": str(e)},
                        cause=e,
                    )
                
                # Check for auth/permission errors
                if "unauthorized" in error_str or "invalid" in error_str or "401" in error_str:
                    log.error(f"LLM authentication error: {e}")
                    raise ValidationAppError(
                        "LLM API authentication failed",
                        details={"error_message": str(e)[:100]},
                        cause=e,
                    ).with_status(401)
                
                # Generic LLM error
                log.error(f"LLM error on attempt {attempt + 1}: {e}")
                last_error = e
                
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay_s * (2 ** attempt))
                    attempt += 1
                else:
                    raise LLMAppError(
                        "LLM request failed after retries",
                        details={
                            "attempts": attempt + 1,
                            "max_retries": self.max_retries,
                            "last_error": str(last_error)[:200],
                        },
                        cause=last_error,
                    )
        
        # Should not reach here
        raise LLMAppError("LLM operation failed unexpectedly")
    
    def get_health(self) -> dict[str, Any]:
        """Check LLM service health via circuit breaker status."""
        stats = self.breaker.get_state()
        return {
            "llm_service": "degraded" if stats.state.value != "closed" else "healthy",
            "circuit_breaker": stats.to_dict(),
        }
    
    def reset(self) -> None:
        """Reset circuit breaker (for testing or manual reset)."""
        self.breaker.reset()
        log.info("LLM circuit breaker manually reset")


# Singleton instance
_llm_ops: Optional[LLMOperations] = None


def get_llm_ops() -> LLMOperations:
    """Get or create the global LLM operations instance."""
    global _llm_ops
    if _llm_ops is None:
        _llm_ops = LLMOperations()
    return _llm_ops
