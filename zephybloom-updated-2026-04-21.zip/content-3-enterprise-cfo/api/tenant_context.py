"""
Multi-tenant dependencies and tenant isolation enforcement.

Ensures that:
- Every request has a tenant context
- Requests are isolated by tenant_id
- Audit logs capture tenant information
"""

from __future__ import annotations
from typing import Optional, Dict, Any

from fastapi import Depends, HTTPException, Header, status
from sqlalchemy.orm import Session

from db.session import get_session
from db.models import Tenant, User, APIKey
from api.auth_service import AuthService
from api.config import settings


class TenantContext:
    """Tenant context holder for request."""

    def __init__(
        self,
        tenant_id: str,
        user_id: Optional[int] = None,
        api_key_id: Optional[int] = None,
        is_verified: bool = False,
    ):
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.api_key_id = api_key_id
        self.is_verified = is_verified


def _auth_enforced() -> bool:
    """
    Dev/demo restano fluidi; staging/prod o JWT_REQUIRED richiedono identita verificata.
    """
    env = getattr(settings, "ENV", "production")
    demo_mode = bool(getattr(settings, "DEMO_MODE", False))
    test_mode = bool(getattr(settings, "TEST_MODE", False))
    jwt_required = bool(getattr(settings, "JWT_REQUIRED", False))
    return jwt_required or (env in {"staging", "production"} and not demo_mode and not test_mode)


async def get_tenant_context(
    authorization: Optional[str] = Header(None),
    x_tenant_id: Optional[str] = Header(None),
    x_api_key: Optional[str] = Header(None),
    db: Session = Depends(get_session),
) -> TenantContext:
    """
    Extract and verify tenant context from request.

    Priority:
    1. X-Tenant-Id header (explicit)
    2. JWT token tenant_id claim
    3. API key tenant_id
    4. Default tenant

    Returns:
        TenantContext with verified tenant and user info
    """

    # Try API Key first (strongest authentication)
    if x_api_key:
        api_key_record = AuthService.verify_api_key(db, x_api_key)
        if api_key_record:
            return TenantContext(
                tenant_id=api_key_record.tenant_id,
                user_id=api_key_record.user_id,
                api_key_id=api_key_record.id,
                is_verified=True,
            )

    # Try JWT token
    if authorization:
        try:
            payload = AuthService.verify_access_token(
                authorization.replace("Bearer ", "").strip()
            )
            user_id = int(payload.get("sub", 0))
            jwt_tenant_id = payload.get("tenant_id", "default")

            # Override with explicit header if provided
            tenant_id = x_tenant_id or jwt_tenant_id

            return TenantContext(
                tenant_id=tenant_id,
                user_id=user_id,
                is_verified=True,
            )
        except Exception:
            pass

    # Try explicit tenant header (less secure, for testing/demo)
    if x_tenant_id:
        return TenantContext(
            tenant_id=x_tenant_id,
            is_verified=False,  # Unverified - for demo/testing only
        )

    # Default fallback
    return TenantContext(
        tenant_id="default",
        is_verified=False,
    )


async def get_verified_tenant(
    tenant: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_session),
) -> TenantContext:
    """
    Verify tenant is valid and active.

    Raises:
        HTTPException 403 if tenant is invalid/inactive
    """

    if not _auth_enforced():
        return tenant

    tenant_record = db.query(Tenant).filter(
        Tenant.id == tenant.tenant_id,
        Tenant.is_active == True,
    ).first()

    if not tenant_record:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Tenant {tenant.tenant_id} not found or inactive",
        )

    return tenant


def require_auth(
    tenant: TenantContext = Depends(get_verified_tenant),
) -> TenantContext:
    """
    Require verified authentication.

    Raises:
        HTTPException 401 if not authenticated
    """
    if _auth_enforced() and not tenant.is_verified:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    return tenant


async def get_current_user(
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> tuple[TenantContext, User]:
    """
    Get current authenticated user.

    Returns:
        Tuple of (TenantContext, User)
    """
    if not tenant.user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User information not available",
        )

    user = db.query(User).filter(User.id == tenant.user_id).first()

    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return tenant, user
