"""
CFO Strategy Endpoints - /cfo/strategy, /cfo/roadmap, /cfo/action-plan

Endpoints:
1. POST /cfo/strategy - Strategic analysis (Porter 5 Forces, Ansoff, Balanced Scorecard)
2. POST /cfo/roadmap - 3-5 year strategic roadmap with milestones
3. POST /cfo/action-plan - Operational 90/365 day action plan
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

from api.tenant_context import require_auth, TenantContext
from core.strategy import StrategyEngine, Porter5Analysis, AnsoffAnalysis, BalancedScorecard
from core.roadmap import RoadmapEngine, StrategicRoadmap

# ============================================
# REQUEST SCHEMAS
# ============================================

class StrategyRequest(BaseModel):
    """Request for strategic analysis"""
    company_name: str = Field(..., description="Company name")
    sector: str = Field(..., description="Industry sector (saas, manufacturing, retail, etc)")
    revenue: float = Field(..., ge=0, description="Annual revenue EUR")
    net_margin_pct: float = Field(..., description="Current net margin %")
    growth_rate_pct: float = Field(default=0, description="Current YoY growth %")
    market_position: str = Field(
        default="Challenger",
        description="Incumbent, Challenger, Niche Player, or Startup"
    )
    employees: int = Field(default=0, ge=0, description="Current headcount")
    nps_score: Optional[float] = Field(default=None, description="Net Promoter Score")
    customer_churn_pct: Optional[float] = Field(default=None, description="Customer churn %")
    market_share_pct: Optional[float] = Field(default=None, description="Current market share %")
    tam_eur: Optional[float] = Field(default=None, description="Total Addressable Market EUR")
    
    class Config:
        example = {
            "company_name": "TechCorp Italia",
            "sector": "saas",
            "revenue": 10000000,
            "net_margin_pct": 20.0,
            "growth_rate_pct": 25.0,
            "market_position": "Challenger",
            "employees": 50,
            "nps_score": 52,
            "tam_eur": 500000000,
        }


class RoadmapRequest(BaseModel):
    """Request for strategic roadmap"""
    company_name: str = Field(..., description="Company name")
    current_revenue: float = Field(..., ge=0, description="Annual revenue EUR")
    growth_target_pct: float = Field(..., ge=0, description="5-year growth target %")
    ansoff_strategy: str = Field(
        default="market_penetration",
        description="Primary growth strategy (market_penetration, product_development, market_development, diversification)"
    )
    market_size_eur: float = Field(default=0, description="TAM EUR")
    target_market_share_pct: float = Field(default=10, ge=0, le=100, description="Target market share %")


# ============================================
# ROUTER SETUP
# ============================================

router = APIRouter(
    prefix="/cfo",
    tags=["cfo-strategy"],
    responses={
        401: {"model": Dict, "description": "Not authenticated"},
        400: {"model": Dict, "description": "Invalid request"},
        500: {"model": Dict, "description": "Analysis error"},
    }
)


# ============================================
# ENDPOINT 1: /cfo/strategy
# ============================================

@router.post(
    "/strategy",
    summary="Strategic Analysis",
    description="Multi-framework strategic analysis (Porter 5 Forces, Ansoff Matrix, Balanced Scorecard)",
)
def cfo_strategy(
    request: StrategyRequest,
    tenant: TenantContext = Depends(require_auth),
) -> Dict:
    """
    Comprehensive strategic analysis
    
    Includes:
    1. Porter 5 Forces - Competitive intensity and attractiveness
    2. Ansoff Matrix - Growth strategy options (4 quadrants)
    3. Balanced Scorecard - Strategic metrics across 4 perspectives
    
    Returns insights on competitive position and strategic implications
    """
    
    try:
        # ===== PORTER 5 FORCES =====
        porter = StrategyEngine.analyze_porter_5(
            sector=request.sector,
            your_market_position=request.market_position,
            revenue_size=request.revenue,
        )
        
        porter_dict = {
            "overall_attractiveness_score": porter.overall_attractiveness_score,
            "industry_verdict": porter.industry_verdict,
            "strategic_implication": porter.strategic_implication,
            "forces": [
                {
                    "force": f.force.value,
                    "intensity_score": f.intensity_score,
                    "drivers": f.drivers,
                    "implications": f.implications,
                    "recommendations": f.recommendations,
                }
                for f in porter.forces
            ],
        }
        
        # ===== ANSOFF MATRIX =====
        ansoff = StrategyEngine.analyze_ansoff(
            revenue=request.revenue,
            gross_margin_pct=request.net_margin_pct + 15,  # Rough estimate
            growth_rate_pct=request.growth_rate_pct,
            market_position=request.market_position,
            product_portfolio_count=1,  # Default
            geographic_footprint=["Europe"],  # Default
        )
        
        ansoff_dict = {
            "recommended_priority": [s.value for s in ansoff.recommended_priority],
            "rationale": ansoff.rationale,
            "options": [
                {
                    "strategy": o.strategy.value,
                    "description": o.description,
                    "market_opportunity": o.market_opportunity,
                    "risk_level": o.risk_level,
                    "investment_required": o.investment_required,
                    "timeline_months": o.timeline_months,
                    "expected_revenue_impact_pct": o.expected_revenue_impact_pct,
                    "success_factors": o.success_factors,
                    "example_actions": o.example_actions,
                }
                for o in ansoff.options
            ],
        }
        
        # ===== BALANCED SCORECARD =====
        bsc = StrategyEngine.build_balanced_scorecard(
            revenue=request.revenue,
            net_margin_pct=request.net_margin_pct,
            employee_count=request.employees,
            nps_score=request.nps_score,
            customer_churn_pct=request.customer_churn_pct,
        )
        
        bsc_dict = {
            "financial_metrics": [
                {
                    "metric": m.metric_name,
                    "baseline": m.baseline_value,
                    "target": m.target_value,
                    "unit": m.unit,
                    "initiative": m.initiative,
                    "owner": m.owner,
                }
                for m in bsc.financial_metrics
            ],
            "customer_metrics": [
                {
                    "metric": m.metric_name,
                    "baseline": m.baseline_value,
                    "target": m.target_value,
                    "unit": m.unit,
                    "initiative": m.initiative,
                    "owner": m.owner,
                }
                for m in bsc.customer_metrics
            ],
            "internal_metrics": [
                {
                    "metric": m.metric_name,
                    "baseline": m.baseline_value,
                    "target": m.target_value,
                    "unit": m.unit,
                    "initiative": m.initiative,
                    "owner": m.owner,
                }
                for m in bsc.internal_metrics
            ],
            "learning_metrics": [
                {
                    "metric": m.metric_name,
                    "baseline": m.baseline_value,
                    "target": m.target_value,
                    "unit": m.unit,
                    "initiative": m.initiative,
                    "owner": m.owner,
                }
                for m in bsc.learning_metrics
            ],
        }
        
        return {
            "company_name": request.company_name,
            "sector": request.sector,
            "market_position": request.market_position,
            "porter_5_forces": porter_dict,
            "ansoff_matrix": ansoff_dict,
            "balanced_scorecard": bsc_dict,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Strategy analysis error: {str(e)}",
        )


# ============================================
# ENDPOINT 2: /cfo/roadmap
# ============================================

@router.post(
    "/roadmap",
    summary="3-5 Year Strategic Roadmap",
    description="Generate detailed roadmap with phases, initiatives, resources, and milestones",
)
def cfo_roadmap(
    request: RoadmapRequest,
    tenant: TenantContext = Depends(require_auth),
) -> Dict:
    """
    5-year strategic roadmap
    
    Generates:
    - 4 phases: Discovery → Build → Scale → Mature
    - Key initiatives per phase
    - Resource requirements (headcount, budget)
    - Milestones and success metrics
    - Risk mitigation strategies
    - Annual revenue and budget projections
    """
    
    try:
        roadmap = RoadmapEngine.build_roadmap(
            company_name=request.company_name,
            current_revenue=request.current_revenue,
            growth_target_pct=request.growth_target_pct,
            ansoff_strategy=request.ansoff_strategy,
            market_size_eur=request.market_size_eur,
            target_market_share_pct=request.target_market_share_pct,
        )
        
        # Format for output
        phases_output = []
        for phase in roadmap.phases:
            initiatives_output = [
                {
                    "name": init.name,
                    "description": init.description,
                    "owner": init.owned_by,
                    "timeline": f"Months {init.starts_month}-{init.starts_month + init.duration_months - 1}",
                    "team_size": init.team_size,
                    "budget_eur": init.budget_eur,
                    "success_metric": init.success_metric,
                    "revenue_impact_eur": init.revenue_impact_eur,
                    "risk_level": init.risk_level,
                }
                for init in phase.initiatives
            ]
            
            phases_output.append({
                "phase": phase.phase.value,
                "duration_months": phase.duration_months,
                "months": f"{phase.start_month}-{phase.end_month}",
                "initiatives": initiatives_output,
                "total_headcount": phase.total_headcount,
                "total_budget_eur": phase.total_budget_eur,
                "capex_eur": phase.capital_expenditure_eur,
                "revenue_target_eur": phase.revenue_target_eur,
                "milestones": phase.key_milestones,
                "top_risks": phase.top_risks,
                "mitigations": phase.mitigations,
            })
        
        return {
            "company": request.company_name,
            "mission": roadmap.mission,
            "phases": phases_output,
            "financial_projections": {
                "current_revenue_eur": request.current_revenue,
                "year_1_target_eur": round(roadmap.year_1_revenue_projection, 0),
                "year_3_target_eur": round(roadmap.year_3_revenue_projection, 0),
                "year_5_target_eur": round(roadmap.year_5_revenue_projection, 0),
            },
            "annual_budget_allocation": {
                int(k): round(v, 0) for k, v in roadmap.annual_budget_allocation.items()
            },
            "annual_headcount_plan": roadmap.annual_headcount_plan,
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Roadmap generation error: {str(e)}",
        )


# ============================================
# ENDPOINT 3: /cfo/action-plan
# ============================================

@router.post(
    "/action-plan",
    summary="90 & 365 Day Action Plan",
    description="Operational action plan for next 90 days and full year",
)
def cfo_action_plan(
    request: StrategyRequest,
    tenant: TenantContext = Depends(require_auth),
) -> Dict:
    """
    Detailed 90-day and 365-day action plan
    
    For each period includes:
    - Top 3-5 OKRs (objectives and key results)
    - Weekly milestones
    - Owner assignments
    - Resource needs
    - Success metrics
    - Risk tracking
    """
    
    try:
        # Generate 90-day plan
        action_90 = _generate_90_day_plan(request)
        
        # Generate 365-day plan
        action_365 = _generate_365_day_plan(request)
        
        return {
            "company": request.company_name,
            "period_90_days": action_90,
            "period_365_days": action_365,
            "executive_summary": _create_action_plan_summary(request),
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Action plan error: {str(e)}",
        )


# ============================================
# HELPER FUNCTIONS
# ============================================

def _generate_90_day_plan(request: StrategyRequest) -> Dict:
    """Generate 90-day operational action plan"""
    
    return {
        "okrs": [
            {
                "objective": "Achieve revenue growth target",
                "key_results": [
                    "Increase pipeline by 50% (meetings generated)",
                    "Achieve 25% win rate on opportunities",
                    "Close €500K in new ARR"
                ],
                "owner": "VP Sales",
            },
            {
                "objective": "Improve product engagement",
                "key_results": [
                    "Increase MAU by 30%",
                    "Reduce time-to-value to <2 weeks",
                    "Achieve 90%+ onboarding completion"
                ],
                "owner": "VP Product",
            },
            {
                "objective": "Build strong financial controls",
                "key_results": [
                    "Implement monthly close process (5 days)",
                    "Build 3-year rolling forecast",
                    "Achieve 95%+ forecast accuracy"
                ],
                "owner": "CFO",
            },
        ],
        "weekly_milestones": [
            {"week": 1, "milestone": "Kickoff meeting, align leadership", "owner": "CEO"},
            {"week": 2, "milestone": "Sales playbook finalized", "owner": "VP Sales"},
            {"week": 3, "milestone": "Product roadmap Q2 set", "owner": "VP Product"},
            {"week": 4, "milestone": "Financial model updated", "owner": "CFO"},
            {"week": 8, "milestone": "Mid-plan review, adjust if needed", "owner": "CEO"},
            {"week": 12, "milestone": "90-day review + plan for next quarter", "owner": "CEO"},
        ],
        "resource_requirements": {
            "additional_headcount": 3,
            "budget_required_eur": 75_000,
            "tools_or_systems": ["Salesforce CRM", "Product analytics tool", "Financial planning tool"]
        }
    }


def _generate_365_day_plan(request: StrategyRequest) -> Dict:
    """Generate 365-day (annual) action plan"""
    
    return {
        "q1_plan": {
            "focus": "Foundation: Build sales machine, product roadmap, financial controls",
            "revenue_target": round(request.revenue * 1.06, 0),
            "key_initiatives": [
                "Sales playbook & process (RPM)",
                "Customer success program launch",
                "Product roadmap execution",
                "Annual budget & plan"
            ],
        },
        "q2_plan": {
            "focus": "Momentum: Grow pipeline, improve product-market fit",
            "revenue_target": round(request.revenue * 1.12, 0),
            "key_initiatives": [
                "Expand sales team (+2 AEs)",
                "Launch new product feature",
                "Partner program launch",
                "Marketing campaign refresh"
            ],
        },
        "q3_plan": {
            "focus": "Scale: Accelerate growth, optimize operations",
            "revenue_target": round(request.revenue * 1.18, 0),
            "key_initiatives": [
                "Second office/market entry",
                "Product platform expansion",
                "Customer summit",
                "Operational excellence program"
            ],
        },
        "q4_plan": {
            "focus": "Prepare for next year: Consolidate gains, plan 2027",
            "revenue_target": round(request.revenue * 1.25, 0),
            "key_initiatives": [
                "Year-end close & 2027 planning",
                "Budget review & allocation",
                "Annual strategy review",
                "Talent & culture initiatives"
            ],
        },
        "quarterly_review_cadence": {
            "monthly_all_hands": "Every 1st Friday at 10 AM",
            "quarterly_board_meeting": "Last week of quarter",
            "annual_offsite": "January (2 days)"
        }
    }


def _create_action_plan_summary(request: StrategyRequest) -> str:
    """Create executive summary of action plan"""
    
    return f"""
    EXECUTIVE SUMMARY - 12-MONTH ACTION PLAN
    Company: {request.company_name}
    Current Revenue: €{request.revenue:,.0f}
    Growth Target: +25-30% (to €{request.revenue * 1.25:,.0f})
    
    KEY THEMES:
    1. SALES & REVENUE: Build repeatable sales process, expand team, hit €{request.revenue * 1.25:,.0f} ARR
    2. PRODUCT: Execute product roadmap, improve engagement, achieve product-market fit
    3. OPERATIONS: Build financial controls, improve margins, operational excellence
    4. PEOPLE: Recruit key hires, develop culture, succession planning
    
    QUARTERLY MILESTONES:
    Q1: Build foundation (sales machine, product roadmap, financials)
    Q2: Build momentum (expand team, launch features)
    Q3: Scale faster (new market, more products, efficiency)
    Q4: Consolidate & plan (2027 strategy, budget, new initiatives)
    
    SUCCESS METRICS:
    - Revenue: €{request.revenue * 1.25:,.0f} ARR
    - Growth: +25-30% YoY
    - Margin: +5 points (to {request.net_margin_pct + 5:.0f}%)
    - Headcount: 50+ people
    - Customer NPS: 60+
    """
