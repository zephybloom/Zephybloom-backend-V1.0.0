# -*- coding: utf-8 -*-
# content/api/routes_optimize.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import (
    PriceOptimizeRequest, PriceOptimizeResponse,
    PriceLadderRequest, PriceLadderResponse, PriceLadderRow
)
from core.pricing import optimize_price, price_ladder

router = APIRouter()

@router.post("/optimize/price", response_model=PriceOptimizeResponse)
def optimize_price_route(req: PriceOptimizeRequest):
    best, assumptions = optimize_price(req.base)
    meta = {"assumptions": assumptions}
    return PriceOptimizeResponse(**best, meta=meta)

@router.post("/whatif/price_ladder", response_model=PriceLadderResponse)
def price_ladder_route(req: PriceLadderRequest):
    rows, best, assumptions = price_ladder(
        req.base,
        pct_min=float(req.pct_min),
        pct_max=float(req.pct_max),
        pct_step=float(req.pct_step),
    )
    # Cast rows → PriceLadderRow
    rows_models = [PriceLadderRow(**r) for r in rows]
    return PriceLadderResponse(rows=rows_models, best=PriceLadderRow(**best), meta={"assumptions": assumptions})
