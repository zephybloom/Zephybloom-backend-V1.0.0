# -*- coding: utf-8 -*-
# content/api/routes_kpi.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import KPIRequest, KPIResponse
from core.kpi_engine import compute_kpi, KPIOptions
from utils.errors import CalculationAppError, ValidationAppError, from_exception

router = APIRouter()

@router.post("/kpi/compute", response_model=KPIResponse)
def kpi_compute(req: KPIRequest):
    try:
        # Opzioni: settore dal payload (fallback default)
        opts = KPIOptions(sector=req.sector or "default")
        data = compute_kpi(req.model_dump(), options=opts)

        meta = {}
        for k in ("_extras", "_diag"):
            if k in data:
                payload = data.pop(k)
                # flattiamo in meta mantenendo i namespace (e.g., 'saas', 'risk', 'benchmarks', 'diag')
                if k == "_extras":
                    meta.update(payload)
                else:
                    meta["diag"] = payload

        return KPIResponse(**data, meta=meta)
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nel calcolo KPI",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "kpi_compute",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during KPI computation")
