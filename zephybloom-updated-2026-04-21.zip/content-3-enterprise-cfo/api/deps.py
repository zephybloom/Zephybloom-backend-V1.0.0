# -*- coding: utf-8 -*-
# content/api/deps.py
from __future__ import annotations

import uuid
import logging
from typing import Callable

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.status import HTTP_500_INTERNAL_SERVER_ERROR
from starlette.responses import Response

from utils.logging_utils import bind_context, get_logger
from utils.errors import AppError, ValidationAppError, from_exception


# ---------------------------------------------------------------------
# Middleware: context vars (convo_id, user_id, route)
# ---------------------------------------------------------------------
class ContextVarsMiddleware(BaseHTTPMiddleware):
    """Inietta convo_id/user_id/route nei contextvars e riflette l'ID in risposta."""

    async def dispatch(self, request: Request, call_next):
        convo_id = request.headers.get("X-Conversation-Id") or uuid.uuid4().hex[:12]
        user_id = request.headers.get("X-User-Id") or "-"
        route = request.url.path

        bind_context(convo_id=convo_id, user_id=user_id, route=route)
        request.state.convo_id = convo_id

        response: Response = await call_next(request)
        # Propaga header utile per tracing lato client
        response.headers["X-Conversation-Id"] = convo_id
        return response


# ---------------------------------------------------------------------
# Dependency: logger già “scoped” per un router
# ---------------------------------------------------------------------
def get_logger_dep(route_name: str) -> Callable[[], logging.Logger]:
    def _dep() -> logging.Logger:
        return get_logger(route_name)
    return _dep


# ---------------------------------------------------------------------
# Exception handlers uniformi
# ---------------------------------------------------------------------
def register_exception_handlers(app: FastAPI) -> None:
    log = get_logger("api.errors")

    @app.exception_handler(AppError)
    async def _app_error_handler(request: Request, exc: AppError):
        # Log in WARNING (non è crash, ma serve traccia)
        log.warning(
            "AppError",
            extra={"code": exc.code, "status": exc.http_status, "details": exc.details, "path": request.url.path},
        )
        return JSONResponse(status_code=exc.http_status, content=exc.to_dict())

    @app.exception_handler(RequestValidationError)
    async def _validation_handler(request: Request, exc: RequestValidationError):
        e = ValidationAppError("Request validation failed", details={"errors": exc.errors()})
        log.warning(
            "ValidationError",
            extra={"code": e.code, "status": e.http_status, "details": e.details, "path": request.url.path},
        )
        payload = e.to_dict()
        payload["detail"] = exc.errors()
        return JSONResponse(status_code=e.http_status, content=payload)

    @app.exception_handler(Exception)
    async def _generic_handler(request: Request, exc: Exception):
        # Mappa l’eccezione in un AppError coerente per non perdere semantica
        app_err = from_exception(exc, message="Unexpected error")
        # Log stack trace completo
        log.exception(
            "Unhandled exception",
            extra={"code": app_err.code, "status": app_err.http_status, "path": request.url.path},
        )
        return JSONResponse(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": {"code": "internal_server_error", "message": "Unexpected error"}},
        )
