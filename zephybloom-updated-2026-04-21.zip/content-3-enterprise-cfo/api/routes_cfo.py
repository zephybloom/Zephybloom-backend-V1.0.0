"""
CFO Product Endpoints

Routes for:
- POST /cfo/analyze - Complete financial analysis
- POST /cfo/simulate - Scenario simulation
- POST /cfo/chat - AI-powered CFO chat (with memory system)
- POST /cfo/ai-analyze - AI-powered analysis with ChatGPT
"""

from fastapi import APIRouter, HTTPException, Response, status, Depends
from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any
import time
import re
from sqlalchemy.orm import Session

from api.schemas_cfo import (
    AnalyzeRequest, AnalyzeResponse,
    SimulateRequest, SimulateResponse,
    ChatMessage, ChatRequest, ChatResponse,
    CFOErrorResponse,
)
from api.tenant_context import require_auth, TenantContext
from api.schemas_validation import ErrorResponse
from core.analysis import analyze_company, create_analysis_engine
from core.answer_policy import AnswerValidation, build_safe_cfo_answer, validate_cfo_answer
from core.cfo_answer_quality import build_answer_quality
from core.cfo_intelligence import build_cfo_insight_pack
from core.cfo_conversation_brain import ConversationAction, decide_conversation_action
from core.cfo_decision_playbook import build_decision_playbook
from core.cfo_intent_router import CFOIntent, IntentResult, MessageKind, is_single_kpi_intent, normalize_question_words, route_cfo_intent
from core.company_metrics import save_company_metrics, get_trend_summary_for_decision, get_company_metrics_history
from core.cfo_memory import build_cfo_memory_summary, save_cfo_memory_snapshot
from core.cfo_report import build_monthly_cfo_report
from core.cfo_report_pdf import render_monthly_report_pdf
from core.company_data_room import build_company_data_room
from core.company_data_room_store import (
    build_data_room_history_summary,
    get_data_room_history,
    get_data_room_snapshot,
    import_data_room_rows,
    merge_saved_data_room,
    upsert_data_room_snapshot,
)
from core.company_operating_model import build_company_operating_model
from core.construction_calculator import analyze_construction, simulate_construction
from core.data_requirements import assess_data_completeness
from core.decision_memory import (
    build_decision_memory_summary,
    get_decision_memory,
    list_decision_memory,
    remember_war_room_decisions,
    update_decision_status,
)
from core.business_model_schema import DataCompletenessResult
from core.ecommerce_calculator import analyze_ecommerce, simulate_ecommerce
from core.restaurant_calculator import analyze_restaurant, simulate_restaurant
from core.strategic_lenses import build_cfo_war_room
from core.unit_economics_detail import analyze_unit_economics
from core.war_room_engine import build_unified_war_room

# Database session
from db.session import get_session

# New CFO Chatbot Engine
from nlp.cfo_chatbot import create_cfo_engine

# Performance optimization
from infra.circuit_breaker import get_breaker

# AI Provider - ChatGPT integration
from infra.ai_provider import get_ai_provider, CFOAnalysisAI
from faq.faq_router import route_faq


def _format_eur(value: float) -> str:
    return f"EUR {value:,.0f}".replace(",", ".")


def _safe_float(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _normalize_question_words(question: Optional[str]) -> set:
    return normalize_question_words(question)


def _humanize_move(move: str) -> str:
    move = (move or "").strip()
    translations = {
        "Improve profitability": "proteggi il margine prima di spingere nuova crescita",
        "Revenue Growth Initiative": "aumenta il fatturato solo sui clienti/prodotti piu' profittevoli",
        "Supply Chain Cost Reduction": "riduci i costi variabili senza tagliare qualita' o servizio",
        "Inventory optimization (tie-up vs stockouts)": "libera cassa dal magazzino senza creare rotture di stock",
    }
    return translations.get(move, move[:1].lower() + move[1:] if move else "mantieni disciplina sui margini")


def _humanize_health(label: str) -> str:
    translations = {
        "Financially scalable": "azienda pronta a crescere, ma con disciplina",
        "Needs margin repair": "azienda da rimettere in margine prima di scalare",
        "At risk": "azienda da stabilizzare prima di investire in crescita",
    }
    return translations.get((label or "").strip(), "situazione da verificare")


def _humanize_constraint(summary: str) -> str:
    translations = {
        "The model is financially viable; the next constraint is scaling without margin erosion.": (
            "il modello regge; il prossimo rischio e' crescere senza perdere margine"
        ),
    }
    return translations.get((summary or "").strip(), summary or "scalare senza perdere margine")

# ===============================================
# SIMPLE MEMORY SYSTEM (per tenant)
# ===============================================
# In production, use Redis or database
_chat_memory: Dict[str, List[Dict]] = {}  # tenant_id -> list of {q, intent, summary}

def _save_to_chat_memory(tenant_id: str, question: str, intent: str, response_summary: str):
    """Save Q&A to memory (last 10 per tenant)"""
    if tenant_id not in _chat_memory:
        _chat_memory[tenant_id] = []
    
    _chat_memory[tenant_id].append({
        "ts": time.time(),
        "question": question,
        "intent": intent,
        "summary": response_summary[:100],  # First 100 chars
    })
    
    # Keep only last 10 entries per tenant
    _chat_memory[tenant_id] = _chat_memory[tenant_id][-10:]

def _get_chat_history(tenant_id: str) -> str:
    """Get conversation history for context"""
    if tenant_id not in _chat_memory or not _chat_memory[tenant_id]:
        return "No previous conversation history."
    
    history = "Recent conversation history:\n"
    for entry in _chat_memory[tenant_id][-3:]:  # Last 3 entries
        history += f"- Q: {entry['question']} (intent: {entry['intent']})\n"
    return history


# ===============================================
# METRICS HISTORY HELPERS
# ===============================================

def _build_metrics_from_request(request: 'AnalyzeRequest') -> Dict[str, float]:
    """Convert AnalyzeRequest to metrics dict for historical tracking"""
    
    fatturato = request.fatturato
    cv = request.costi_variabili
    cf = request.costi_fissi
    inv = request.investimenti or 0
    
    gross_profit = fatturato - cv
    gross_margin_pct = (gross_profit / fatturato * 100) if fatturato > 0 else 0
    ebitda = gross_profit - cf
    ebitda_margin_pct = (ebitda / fatturato * 100) if fatturato > 0 else 0
    net_profit = ebitda
    net_margin_pct = (net_profit / fatturato * 100) if fatturato > 0 else 0
    roi_pct = (net_profit / inv * 100) if inv > 0 else 0
    
    return {
        "fatturato": fatturato,
        "costi_variabili": cv,
        "costi_fissi": cf,
        "investimenti": inv,
        "gross_profit": gross_profit,
        "gross_margin_pct": gross_margin_pct,
        "ebitda": ebitda,
        "ebitda_margin_pct": ebitda_margin_pct,
        "net_profit": net_profit,
        "net_margin_pct": net_margin_pct,
        "roi_pct": roi_pct,
    }

# ============================================
# ROUTER SETUP
# ============================================

router = APIRouter(
    prefix="/cfo",
    tags=["cfo"],
    responses={
        401: {"model": ErrorResponse, "description": "Not authenticated"},
        400: {"model": CFOErrorResponse, "description": "Invalid request"},
        500: {"model": CFOErrorResponse, "description": "Analysis error"},
    }
)


class UnitEconomicsRow(BaseModel):
    customer: Optional[str] = None
    product: Optional[str] = None
    supplier: Optional[str] = None
    quantity: float = Field(default=1, ge=0)
    unit_price: Optional[float] = Field(default=None, ge=0)
    purchase_price: Optional[float] = Field(default=None, ge=0)
    revenue: Optional[float] = Field(default=None, ge=0)
    direct_cost: Optional[float] = Field(default=None, ge=0)
    discounts: float = Field(default=0, ge=0)
    commissions: float = Field(default=0, ge=0)
    logistics_cost: float = Field(default=0, ge=0)


class UnitEconomicsRequest(BaseModel):
    rows: List[UnitEconomicsRow] = Field(..., min_length=1, max_length=5000)


class CFOMemorySnapshotRequest(BaseModel):
    company_id: str = Field(default="default", description="Stable company identifier for memory/history")
    company_name: str = Field(default="Azienda", description="Company display name")
    metrics: Dict[str, float] = Field(..., description="Monthly financial metrics")
    measurement_date: Optional[str] = Field(default=None, description="ISO date for the snapshot month")
    industry: Optional[str] = Field(default=None, description="Sector/industry")
    notes: Optional[str] = Field(default=None, description="Notes for this monthly snapshot")


class DecisionMemoryStatusRequest(BaseModel):
    status: str = Field(..., description="todo, skipped, archived or done")
    reason: Optional[str] = Field(default=None, description="Why the decision status changed")
    next_action: Optional[str] = Field(default=None, description="Updated next action")
    expected_impact_eur: Optional[float] = Field(default=None, description="Updated expected economic impact")
    postpone_days: Optional[int] = Field(default=None, ge=1, le=90, description="Days before reviewing again")


class DataRequirementsRequest(BaseModel):
    sector: str = Field(default="default", description="Business sector, for example restaurant/ecommerce/hotel/construction")
    provided_data: Dict[str, Any] = Field(default_factory=dict, description="Data already collected from the company")


class RestaurantAnalysisRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Restaurant financial and operational data")


class RestaurantSimulationRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Restaurant financial and operational data")
    scenario: Dict[str, Any] = Field(default_factory=dict, description="Operational scenario deltas")


class EcommerceAnalysisRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Ecommerce financial and operational data")


class EcommerceSimulationRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Ecommerce financial and operational data")
    scenario: Dict[str, Any] = Field(default_factory=dict, description="Ecommerce scenario deltas")


class ConstructionAnalysisRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Construction project and cash-flow data")


class ConstructionSimulationRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Construction project and cash-flow data")
    scenario: Dict[str, Any] = Field(default_factory=dict, description="Construction scenario deltas")


class WarRoomRequest(BaseModel):
    company_id: str = Field(default="default", description="Stable company identifier used to load saved Data Room data")
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict,
        description="Operational data already collected by sector, e.g. restaurant/ecommerce/construction",
    )
    active_sector: Optional[str] = Field(
        default=None,
        description="Current company sector, used as a prioritization hint",
    )


class CompanyOperatingModelRequest(BaseModel):
    company_data: Dict[str, Any] = Field(
        default_factory=dict,
        description="Universal company financial and operational data",
    )
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict,
        description="Sector-specific operating data already collected",
    )
    active_sector: Optional[str] = Field(
        default=None,
        description="Current sector used to select the main operating model",
    )


class CompanyDataRoomRequest(BaseModel):
    company_id: str = Field(default="default", description="Stable company identifier")
    company_data: Dict[str, Any] = Field(default_factory=dict, description="Universal company data")
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict,
        description="Sector-specific operational data",
    )
    active_sector: Optional[str] = Field(default=None, description="Current sector used for vertical requirements")
    save: bool = Field(default=False, description="When true, persist this Data Room snapshot for the tenant/company")
    merge: bool = Field(default=True, description="When saving, merge with existing Data Room data")


class CompanyDataRoomImportRequest(BaseModel):
    company_id: str = Field(default="default", description="Stable company identifier")
    company_name: str = Field(default="Azienda", description="Company display name")
    active_sector: str = Field(..., description="Sector where rows should be imported")
    entity: str = Field(..., description="Data entity, e.g. sku_sales, suppliers, staff_roles, projects")
    rows: List[Dict[str, Any]] = Field(..., min_length=1, max_length=10000, description="Rows to import")


class CFOAnswerQualityRequest(BaseModel):
    question: str = Field(..., description="User question")
    response: str = Field(..., description="CFO answer to audit")
    intent: str = Field(default="manual_review", description="Answer intent or route")
    company_data: Dict[str, Any] = Field(default_factory=dict)
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    active_sector: Optional[str] = Field(default=None)


class CFOReportRequest(BaseModel):
    company_id: str = Field(default="default", description="Stable company identifier for memory/history")
    company_name: str = Field(default="Azienda", description="Company display name")
    period: Optional[str] = Field(default=None, description="Report period, for example 2026-04")
    company_data: Dict[str, Any] = Field(default_factory=dict, description="Current company financial data")
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict,
        description="Operational data grouped by sector for War Room context",
    )
    use_saved_data_room: bool = Field(default=True, description="Merge saved Data Room data before building the report")


class DecisionPlaybookRequest(BaseModel):
    company_data: Dict[str, Any] = Field(
        default_factory=dict,
        description="Universal company financial and operational data",
    )
    operational_data_by_sector: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict,
        description="Sector-specific operating data already collected",
    )
    active_sector: Optional[str] = Field(
        default=None,
        description="Current sector used to select the main playbook",
    )
    question: Optional[str] = Field(
        default=None,
        description="User question or business intent",
    )


@router.post(
    "/decision-playbook",
    response_model=dict,
    summary="CFO Decision Playbook",
    description="Turn company data and intent into a 30/60/90-day CFO execution plan.",
)
def cfo_decision_playbook(
    request: DecisionPlaybookRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    playbook = build_decision_playbook(
        company_data=request.company_data,
        operational_data_by_sector=request.operational_data_by_sector,
        active_sector=request.active_sector,
        question=request.question,
    )
    return {
        "status": "success",
        "playbook": playbook,
        "premium_outputs": playbook["premium_outputs"],
    }


@router.post(
    "/operating-model",
    response_model=dict,
    summary="Company Operating Model",
    description="Normalize company data into one CFO-grade operating model and data roadmap.",
)
def cfo_operating_model(
    request: CompanyOperatingModelRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    operating_model = build_company_operating_model(
        company_data=request.company_data,
        operational_data_by_sector=request.operational_data_by_sector,
        active_sector=request.active_sector,
    )
    return {
        "status": "success",
        "operating_model": operating_model,
        "premium_outputs": operating_model["premium_outputs"],
    }


@router.post(
    "/answer-quality",
    response_model=dict,
    summary="Audit CFO answer quality",
    description="Score whether a CFO answer is grounded in structured data, Data Room and operational context.",
)
def cfo_answer_quality(
    request: CFOAnswerQualityRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    data_room = build_company_data_room(
        company_data=request.company_data,
        operational_data_by_sector=request.operational_data_by_sector,
        active_sector=request.active_sector or request.company_data.get("settore"),
    )
    operating_model = build_company_operating_model(
        company_data=request.company_data,
        operational_data_by_sector=request.operational_data_by_sector,
        active_sector=request.active_sector or request.company_data.get("settore"),
    )
    quality = build_answer_quality(
        question=request.question,
        response=request.response,
        intent=request.intent,
        data_quality_pct=operating_model["data_quality"]["score_pct"],
        readiness_level=data_room["readiness_level"],
        company_data=request.company_data,
        operational_data_by_sector=request.operational_data_by_sector,
        data_room=data_room,
    )
    return {
        "status": "success",
        "answer_quality": quality,
        "premium_outputs": {
            "answer_audit": True,
            "source_traceability": True,
            "confidence_score": True,
            "anti_random_answer_guardrail": True,
        },
    }


@router.post(
    "/data-room",
    response_model=dict,
    summary="Company CFO Data Room",
    description="Build the structured company Data Room with gaps, next questions and CFO readiness.",
)
def cfo_data_room(
    request: CompanyDataRoomRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    saved = get_data_room_snapshot(db, tenant.tenant_id, request.company_id)
    merged = merge_saved_data_room(saved, request.company_data, request.operational_data_by_sector)
    active_sector = request.active_sector or merged["active_sector"]

    snapshot = None
    if request.save:
        snapshot = upsert_data_room_snapshot(
            session=db,
            tenant_id=tenant.tenant_id,
            company_id=request.company_id,
            company_name=merged["company_data"].get("company_name") or request.company_id,
            company_data=merged["company_data"],
            operational_data_by_sector=merged["operational_data_by_sector"],
            active_sector=active_sector,
            merge=request.merge,
        )
        merged = merge_saved_data_room(snapshot, {}, {})

    data_room = build_company_data_room(
        company_data=merged["company_data"],
        operational_data_by_sector=merged["operational_data_by_sector"],
        active_sector=active_sector,
    )
    return {
        "status": "success",
        "data_room": data_room,
        "snapshot": snapshot or saved,
        "saved": bool(snapshot),
        "premium_outputs": data_room["premium_outputs"],
    }


@router.get(
    "/data-room",
    response_model=dict,
    summary="Get saved CFO Data Room",
    description="Return the saved Data Room snapshot and rebuilt CFO readiness for one company.",
)
def cfo_data_room_get(
    company_id: str = "default",
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    snapshot = get_data_room_snapshot(db, tenant.tenant_id, company_id)
    if not snapshot:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Data Room snapshot not found")
    data_room = build_company_data_room(
        company_data=snapshot["company_data"],
        operational_data_by_sector=snapshot["operational_data_by_sector"],
        active_sector=snapshot["active_sector"],
    )
    return {
        "status": "success",
        "snapshot": snapshot,
        "data_room": data_room,
        "premium_outputs": data_room["premium_outputs"],
    }


@router.get(
    "/data-room/context",
    response_model=dict,
    summary="Saved Data Room CFO Context",
    description="Return a compact context summary from the saved Data Room for onboarding, chat and executive screens.",
)
def cfo_data_room_context(
    company_id: str = "default",
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    snapshot = get_data_room_snapshot(db, tenant.tenant_id, company_id)
    if not snapshot:
        return {
            "status": "empty",
            "company_id": company_id,
            "has_saved_data_room": False,
            "context": {
                "readiness_score_pct": 0,
                "readiness_level": "not_started",
                "active_sector": None,
                "available_sectors": [],
                "next_questions": ["Inserisci i primi dati aziendali nella Data Room."],
                "last_import": None,
            },
        }

    data_room = build_company_data_room(
        company_data=snapshot["company_data"],
        operational_data_by_sector=snapshot["operational_data_by_sector"],
        active_sector=snapshot["active_sector"],
    )
    return {
        "status": "success",
        "company_id": company_id,
        "has_saved_data_room": True,
        "context": {
            "company_name": snapshot["company_name"],
            "readiness_score_pct": data_room["readiness_score_pct"],
            "readiness_level": data_room["readiness_level"],
            "active_sector": data_room["active_sector"],
            "available_sectors": list((snapshot.get("operational_data_by_sector") or {}).keys()),
            "next_questions": data_room.get("next_questions", [])[:5],
            "priority_gaps": data_room.get("priority_gaps", [])[:5],
            "last_import": (snapshot.get("import_summary") or {}).get("last_import"),
            "updated_at": snapshot.get("updated_at"),
        },
        "premium_outputs": {
            "persistent_data_room": True,
            "chat_context_ready": True,
            "guided_onboarding_ready": True,
        },
    }


@router.get(
    "/data-room/history",
    response_model=dict,
    summary="Saved Data Room History",
    description="Return Data Room snapshot history and CFO delta between latest and previous versions.",
)
def cfo_data_room_history(
    company_id: str = "default",
    limit: int = 12,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    summary = build_data_room_history_summary(
        session=db,
        tenant_id=tenant.tenant_id,
        company_id=company_id,
        limit=limit,
    )
    return {
        "status": "success" if summary["has_history"] else "empty",
        "history_summary": summary,
        "snapshots": get_data_room_history(db, tenant.tenant_id, company_id, limit=limit),
        "premium_outputs": {
            "data_room_history": True,
            "readiness_delta": True,
            "operational_data_timeline": True,
        },
    }


@router.post(
    "/data-room/import",
    response_model=dict,
    summary="Import rows into CFO Data Room",
    description="Import structured rows such as products, suppliers, staff, channels or projects into the saved Data Room.",
)
def cfo_data_room_import(
    request: CompanyDataRoomImportRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    try:
        snapshot = import_data_room_rows(
            session=db,
            tenant_id=tenant.tenant_id,
            company_id=request.company_id,
            company_name=request.company_name,
            active_sector=request.active_sector,
            entity=request.entity,
            rows=request.rows,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))

    data_room = build_company_data_room(
        company_data=snapshot["company_data"],
        operational_data_by_sector=snapshot["operational_data_by_sector"],
        active_sector=snapshot["active_sector"],
    )
    return {
        "status": "success",
        "snapshot": snapshot,
        "data_room": data_room,
        "imported": {
            "entity": request.entity,
            "row_count": len(request.rows),
            "sector": request.active_sector,
        },
        "premium_outputs": {
            **data_room["premium_outputs"],
            "csv_excel_import_ready": True,
            "persistent_data_room": True,
        },
    }


@router.post(
    "/war-room",
    response_model=dict,
    summary="Unified CFO War Room",
    description="Aggregate vertical CFO analyses into one executive decision view.",
)
def cfo_war_room(
    request: WarRoomRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    saved = get_data_room_snapshot(db, tenant.tenant_id, request.company_id)
    merged = merge_saved_data_room(saved, {"settore": request.active_sector} if request.active_sector else {}, request.operational_data_by_sector)
    active_sector = request.active_sector or merged.get("active_sector")
    operational_data_by_sector = merged["operational_data_by_sector"]
    previous_decisions = list_decision_memory(tenant.tenant_id, session=db)
    previous_summary = build_decision_memory_summary(tenant.tenant_id, session=db)
    war_room = build_unified_war_room(
        operational_data_by_sector=operational_data_by_sector,
        active_sector=active_sector,
        decision_memory_context={
            "decisions": previous_decisions,
            "summary": previous_summary,
        },
    )
    remembered_decisions = remember_war_room_decisions(tenant.tenant_id, war_room, session=db)
    return {
        "status": "success",
        "war_room": war_room,
        "decision_memory": {
            "remembered_count": len(remembered_decisions),
            "summary": build_decision_memory_summary(tenant.tenant_id, session=db),
        },
        "data_room_context": {
            "loaded_saved_snapshot": bool(saved),
            "company_id": request.company_id,
            "active_sector": active_sector,
            "sector_count": len(operational_data_by_sector or {}),
        },
        "premium_outputs": war_room["premium_outputs"],
    }


@router.get(
    "/memory/decisions",
    response_model=dict,
    summary="CFO Decision Memory",
    description="List remembered War Room decisions and their execution outcomes.",
)
def cfo_memory_decisions(
    status_filter: Optional[str] = None,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    decisions = list_decision_memory(tenant.tenant_id, status=status_filter, session=db)
    return {
        "status": "success",
        "decisions": decisions,
        "summary": build_decision_memory_summary(tenant.tenant_id, session=db),
        "premium_outputs": {
            "decision_history": True,
            "open_decision_tracking": True,
            "outcome_memory": True,
        },
    }


@router.get(
    "/memory/decisions/{decision_id}",
    response_model=dict,
    summary="CFO Decision Memory Detail",
    description="Return one remembered decision with status and outcome.",
)
def cfo_memory_decision_detail(
    decision_id: str,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    decision = get_decision_memory(tenant.tenant_id, decision_id, session=db)
    if not decision:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Decision not found in CFO memory")
    return {
        "status": "success",
        "decision": decision,
    }


@router.patch(
    "/memory/decisions/{decision_id}",
    response_model=dict,
    summary="Update CFO Decision Memory Status",
    description="Archive, reopen, postpone or update one remembered War Room decision.",
)
def cfo_memory_decision_status(
    decision_id: str,
    request: DecisionMemoryStatusRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    try:
        decision = update_decision_status(
            tenant_id=tenant.tenant_id,
            decision_id=decision_id,
            status=request.status,
            reason=request.reason,
            next_action=request.next_action,
            expected_impact_eur=request.expected_impact_eur,
            postpone_days=request.postpone_days,
            session=db,
        )
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Decision not found in CFO memory")
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    return {
        "status": "success",
        "decision": decision,
        "summary": build_decision_memory_summary(tenant.tenant_id, session=db),
        "premium_outputs": {
            "decision_lifecycle": True,
            "memory_cleanup": True,
            "operational_follow_up": True,
        },
    }


@router.post(
    "/memory/snapshot",
    response_model=dict,
    summary="Save CFO Memory Snapshot",
    description="Save monthly company metrics for historical CFO memory and trend analysis.",
)
def cfo_memory_snapshot(
    request: CFOMemorySnapshotRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    from datetime import datetime

    measurement_date = datetime.fromisoformat(request.measurement_date) if request.measurement_date else None
    snapshot = save_cfo_memory_snapshot(
        session=db,
        tenant_id=tenant.tenant_id,
        company_id=request.company_id,
        company_name=request.company_name,
        metrics=request.metrics,
        measurement_date=measurement_date,
        industry=request.industry,
        notes=request.notes,
    )
    summary = build_cfo_memory_summary(
        session=db,
        tenant_id=tenant.tenant_id,
        company_id=request.company_id,
        months=12,
    )
    return {
        "status": "success",
        "snapshot": snapshot,
        "memory_summary": summary,
        "premium_outputs": {
            "monthly_kpi_memory": True,
            "trend_ready": len(summary.get("periods", [])) >= 2,
            "chat_memory_context": True,
        },
    }


@router.get(
    "/memory/summary",
    response_model=dict,
    summary="CFO Memory Summary",
    description="Return historical CFO memory, trend narrative, alerts and next actions.",
)
def cfo_memory_summary(
    company_id: str = "default",
    months: int = 12,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    summary = build_cfo_memory_summary(
        session=db,
        tenant_id=tenant.tenant_id,
        company_id=company_id,
        months=months,
    )
    return {
        "status": "success",
        "memory_summary": summary,
        "premium_outputs": {
            "monthly_kpi_memory": True,
            "trend_narrative": True,
            "alerts": True,
            "next_memory_actions": True,
        },
    }


@router.post(
    "/report/monthly",
    response_model=dict,
    summary="Monthly CFO Report",
    description="Create a board-ready CFO monthly report from KPIs, War Room, trends and decision memory.",
)
def cfo_monthly_report(
    request: CFOReportRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    saved = get_data_room_snapshot(db, tenant.tenant_id, request.company_id) if request.use_saved_data_room else None
    merged = merge_saved_data_room(saved, request.company_data or {}, request.operational_data_by_sector)
    company_data = merged["company_data"]
    operational_data_by_sector = merged["operational_data_by_sector"]
    if not company_data.get("fatturato") and not company_data.get("revenue"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Per generare il report serve almeno il fatturato/revenue dell'azienda.",
        )

    report = build_monthly_cfo_report(
        company_data=company_data,
        operational_data_by_sector=operational_data_by_sector,
        tenant_id=tenant.tenant_id,
        company_id=request.company_id,
        company_name=company_data.get("company_name") or request.company_name,
        period=request.period,
        session=db,
    )
    return {
        "status": "success",
        "report": report,
        "data_room_context": {
            "loaded_saved_snapshot": bool(saved),
            "company_id": request.company_id,
            "sector_count": len(operational_data_by_sector or {}),
        },
        "premium_outputs": report["premium_outputs"],
    }


@router.post(
    "/report/monthly/pdf",
    summary="Monthly CFO Report PDF",
    description="Create and download a PDF version of the monthly CFO report.",
)
def cfo_monthly_report_pdf(
    request: CFOReportRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> Response:
    saved = get_data_room_snapshot(db, tenant.tenant_id, request.company_id) if request.use_saved_data_room else None
    merged = merge_saved_data_room(saved, request.company_data or {}, request.operational_data_by_sector)
    company_data = merged["company_data"]
    operational_data_by_sector = merged["operational_data_by_sector"]
    if not company_data.get("fatturato") and not company_data.get("revenue"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Per generare il PDF serve almeno il fatturato/revenue dell'azienda.",
        )

    report = build_monthly_cfo_report(
        company_data=company_data,
        operational_data_by_sector=operational_data_by_sector,
        tenant_id=tenant.tenant_id,
        company_id=request.company_id,
        company_name=company_data.get("company_name") or request.company_name,
        period=request.period,
        session=db,
    )
    pdf_bytes = render_monthly_report_pdf(report)
    filename = f"report-cfo-{request.company_id or 'azienda'}-{report['period']}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-CFO-Report-Version": report["version"],
        },
    )


@router.post(
    "/construction/analyze",
    response_model=dict,
    summary="Construction CFO operational analysis",
    description="Analyze project margin, WIP, SAL/billing, collections, delay risk and cash gap.",
)
def cfo_construction_analyze(
    request: ConstructionAnalysisRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    analysis = analyze_construction(request.data)
    return {
        "status": "success",
        "sector": "construction",
        "construction_analysis": analysis,
        "premium_outputs": {
            "calculates_project_margin": True,
            "calculates_cash_gap": True,
            "calculates_wip_unbilled": True,
            "flags_projects_to_fix": True,
        },
    }


@router.post(
    "/construction/simulate",
    response_model=dict,
    summary="Construction CFO scenario simulation",
    description="Simulate materials, labor, subcontractors, SAL, collections, delays, variants and fixed costs.",
)
def cfo_construction_simulate(
    request: ConstructionSimulationRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    simulation = simulate_construction(request.data, request.scenario)
    return {
        "status": "success",
        "sector": "construction",
        "construction_simulation": simulation,
        "premium_outputs": {
            "compares_base_vs_scenario": True,
            "calculates_cash_gap_delta": True,
            "calculates_margin_delta": True,
            "returns_go_no_go_decision": True,
        },
    }


@router.post(
    "/ecommerce/simulate",
    response_model=dict,
    summary="Ecommerce CFO scenario simulation",
    description="Simulate price, volume, returns, CAC, ads, shipping and purchase cost changes.",
)
def cfo_ecommerce_simulate(
    request: EcommerceSimulationRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    simulation = simulate_ecommerce(request.data, request.scenario)
    return {
        "status": "success",
        "sector": "ecommerce",
        "ecommerce_simulation": simulation,
        "premium_outputs": {
            "compares_base_vs_scenario": True,
            "calculates_profit_delta": True,
            "calculates_break_even_cac_delta": True,
            "returns_go_no_go_decision": True,
        },
    }


@router.post(
    "/ecommerce/analyze",
    response_model=dict,
    summary="Ecommerce CFO operational analysis",
    description="Analyze SKU margin, returns, shipping, CAC, ROAS and break-even CAC.",
)
def cfo_ecommerce_analyze(
    request: EcommerceAnalysisRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    analysis = analyze_ecommerce(request.data)
    return {
        "status": "success",
        "sector": "ecommerce",
        "ecommerce_analysis": analysis,
        "premium_outputs": {
            "calculates_sku_margin": True,
            "calculates_break_even_cac": True,
            "calculates_roas": True,
            "flags_skus_to_fix": True,
        },
    }


@router.post(
    "/restaurant/analyze",
    response_model=dict,
    summary="Restaurant CFO operational analysis",
    description="Analyze food cost, dish margin, target price, labour cost, prime cost and break-even covers.",
)
def cfo_restaurant_analyze(
    request: RestaurantAnalysisRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    analysis = analyze_restaurant(request.data)
    return {
        "status": "success",
        "sector": "restaurant",
        "restaurant_analysis": analysis,
        "premium_outputs": {
            "calculates_food_cost": True,
            "calculates_target_price": True,
            "calculates_prime_cost": True,
            "calculates_break_even_covers": True,
        },
    }


@router.post(
    "/restaurant/simulate",
    response_model=dict,
    summary="Restaurant CFO scenario simulation",
    description="Simulate price, covers, ingredient cost, staff, waste and fixed cost changes.",
)
def cfo_restaurant_simulate(
    request: RestaurantSimulationRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    simulation = simulate_restaurant(request.data, request.scenario)
    return {
        "status": "success",
        "sector": "restaurant",
        "restaurant_simulation": simulation,
        "premium_outputs": {
            "compares_base_vs_scenario": True,
            "calculates_profit_delta": True,
            "calculates_prime_cost_delta": True,
            "returns_go_no_go_decision": True,
        },
    }


@router.post(
    "/data-requirements",
    response_model=dict,
    summary="Sector-specific CFO data requirements",
    description="Assess which operational data is missing before giving precise CFO advice.",
)
def cfo_data_requirements(
    request: DataRequirementsRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    completeness = assess_data_completeness(
        sector=request.sector,
        provided_data=request.provided_data,
    )
    return {
        "status": "success",
        "data_readiness": completeness.to_dict(),
        "premium_outputs": {
            "prevents_random_answers": True,
            "asks_sector_specific_questions": True,
            "supports_precise_simulations": completeness.can_answer_precisely,
        },
    }


@router.post(
    "/unit-economics",
    response_model=dict,
    summary="Customer/product profitability analysis",
    description="Analyze granular customer, product and supplier profitability rows.",
)
def cfo_unit_economics(
    request: UnitEconomicsRequest,
    tenant: TenantContext = Depends(require_auth),
) -> dict:
    rows = [row.model_dump() for row in request.rows]
    analysis = analyze_unit_economics(rows)
    return {
        "status": "success",
        "row_count": analysis["row_count"],
        "unit_economics": analysis,
        "premium_outputs": {
            "can_answer_customer_profitability": True,
            "can_answer_product_margin": True,
            "can_answer_supplier_renegotiation": True,
        },
    }


# ============================================
# ENDPOINT 1: /cfo/analyze - Complete Analysis
# ============================================

@router.post(
    "/analyze",
    response_model=AnalyzeResponse,
    summary="Complete Financial Analysis",
    description="Comprehensive financial analysis with diagnosis, KPIs, and recommended actions",
)
def cfo_analyze(
    request: AnalyzeRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> AnalyzeResponse:
    """
    Complete financial analysis endpoint
    
    Analyzes company financial data and provides:
    - Health status assessment
    - Problem diagnosis with root causes
    - Key performance indicators (KPIs)
    - Top 3-5 recommended actions with financial impact
    - Historical trend analysis (vs last month)
    
    **Input:**
    - fatturato (EUR): Annual revenue
    - costi_variabili (EUR): Variable costs
    - costi_fissi (EUR): Fixed costs
    - investimenti (EUR): Capital expenditures
    - settore: Industry sector for benchmarking
    
    **Output:**
    - Health status: healthy, warning, critical
    - Financial diagnosis with estimated impact
    - Snapshot of key metrics
    - Prioritized action plan
    - Trend analysis if historical data available
    
    **Performance:**
    - Results cached for 10 minutes
    - ~95% hit rate on repeat requests
    - Circuit breaker protects against cascading failures
    """
    
    try:
        # Validate input ranges (early exit)
        if request.fatturato <= 0:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Fatturato must be positive",
            )
        
        if request.costi_variabili < 0 or request.costi_fissi < 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Costs cannot be negative",
            )
        
        if request.costi_variabili >= request.fatturato:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Variable costs cannot exceed revenue",
            )
        
        # ========================================
        # STEP 1: Save metrics to history
        # ========================================
        company_id = request.company_name or "default"
        metrics = _build_metrics_from_request(request)
        
        try:
            save_company_metrics(
                session=db,
                tenant_id=tenant.tenant_id,
                company_id=company_id,
                company_name=request.company_name or "Company",
                metrics=metrics,
                industry=request.settore,
                notes="Submitted via /cfo/analyze"
            )
        except Exception as e:
            # Don't fail the analysis if metrics saving fails
            print(f"Warning: Failed to save metrics history: {str(e)}")
        
        # ========================================
        # STEP 2: Get trend summary (optional)
        # ========================================
        trend_summary = ""
        try:
            trend_summary = get_trend_summary_for_decision(
                session=db,
                tenant_id=tenant.tenant_id,
                company_id=company_id
            )
        except Exception as e:
            # Warn but don't fail if trend calculation fails
            print(f"Warning: Failed to calculate trends: {str(e)}")
            trend_summary = ""
        
        # ========================================
        # STEP 3: Run primary analysis
        # ========================================
        breaker = get_breaker("analysis")
        analysis = breaker.call(
            analyze_company,
            fatturato=request.fatturato,
            costi_variabili=request.costi_variabili,
            costi_fissi=request.costi_fissi,
            investimenti=request.investimenti or 0,
            settore=request.settore,
            company_name=request.company_name,
            dso_days=request.dso_days,
            dio_days=request.dio_days,
            dpo_days=request.dpo_days,
        )
        
        # ========================================
        # STEP 4: Return analysis
        # ========================================
        # Note: trend_summary is available for future use
        # (e.g., when integrating with Decision Engine in /cfo/chat)
        
        return analysis
    
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis error: {str(e)}",
        )


# ============================================
# ENDPOINT 1B: /cfo/ai-analyze - AI-Powered Analysis with ChatGPT
# ============================================

@router.post(
    "/ai-analyze",
    response_model=dict,
    summary="AI-Powered Financial Analysis",
    description="Complete analysis with ChatGPT-powered CFO insights using 'Alex Theory' template",
)
def cfo_ai_analyze(
    request: AnalyzeRequest,
    specific_question: Optional[str] = None,
    use_mock: bool = False,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    """
    AI-powered financial analysis using ChatGPT
    
    Combines core financial analysis with intelligent AI response using ChatGPT.
    
    Returns structured response with:
    - Professional CFO diagnosis
    - Risk assessment
    - Priority action plan
    - Strategic recommendation
    
    All formatted with "Alex Theory" template:
    📊 NUMERO CHIAVE | 🧠 DIAGNOSI | ⚠️ RISCHIO | 🎯 AZIONE PRIORITARIA
    📈 ALTRE AZIONI | 💥 IMPATTO STIMATO | 🧭 PERCHÉ CONTA | 🧠 CONSIGLIO STRATEGICO
    
    **Query Parameters:**
    - specific_question: Optional CEO question to address
    - use_mock: Set to true for testing without OpenAI API key
    
    **Returns:**
    Dict with both base analysis and AI-powered response:
    - analysis: Basic financial metrics and health status
    - ai_response: Structured CFO advice with template formatting
    - formatted_text: Complete formatted response for CEO
    """
    
    try:
        # Validate input
        if request.fatturato <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Fatturato must be positive",
            )
        
        if request.costi_variabili >= request.fatturato:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Variable costs cannot exceed revenue",
            )
        
        # ====== STEP 1: Save metrics to history ======
        company_id = request.company_name or "default"
        metrics = _build_metrics_from_request(request)
        
        try:
            save_company_metrics(
                session=db,
                tenant_id=tenant.tenant_id,
                company_id=company_id,
                company_name=request.company_name or "Company",
                metrics=metrics,
                industry=request.settore,
                notes="Submitted via /cfo/ai-analyze"
            )
        except Exception as e:
            print(f"Warning: Failed to save metrics history: {str(e)}")
        
        # ====== STEP 2: Get trend context ======
        trend_context = ""
        try:
            trend_context = get_trend_summary_for_decision(
                session=db,
                tenant_id=tenant.tenant_id,
                company_id=company_id
            )
        except Exception as e:
            print(f"Warning: Failed to calculate trends: {str(e)}")
        
        # ====== STEP 3: Run base analysis ======
        analysis = analyze_company(
            fatturato=request.fatturato,
            costi_variabili=request.costi_variabili,
            costi_fissi=request.costi_fissi,
            investimenti=request.investimenti or 0,
            settore=request.settore,
            company_name=request.company_name,
            dso_days=request.dso_days,
            dio_days=request.dio_days,
            dpo_days=request.dpo_days,
        )
        
        # ====== STEP 4: Get AI provider and generate response ======
        industry_insight = build_cfo_insight_pack(
            analysis=analysis,
            settore=request.settore,
            trend_narrative=trend_context if trend_context else None,
        )
        data_readiness = assess_data_completeness(
            sector=request.settore,
            provided_data={
                "annual_revenue": request.fatturato,
                "variable_costs": request.costi_variabili,
                "fixed_costs": request.costi_fissi,
                "invested_capital": request.investimenti or 0,
                "dso_days": request.dso_days,
                "dio_days": request.dio_days,
                "dpo_days": request.dpo_days,
            },
        )
        intent_result = route_cfo_intent(specific_question)
        war_room = build_cfo_war_room(analysis, industry_insight, intent_result)
        faq_context = _get_faq_context(specific_question)
        strategic_answer = _strategic_chat_answer(specific_question, analysis, industry_insight, intent_result, war_room)
        if (is_single_kpi_intent(intent_result) or strategic_answer is not None) and faq_context and faq_context.get("score", 0) < 90:
            faq_context = None

        provider = get_ai_provider("mock" if use_mock else "openai")
        
        company_data = {
            "company_name": request.company_name or "Company",
            "settore": request.settore,
            "company_size": "Medium" if request.fatturato < 5_000_000 else "Large",
            "fatturato": request.fatturato,
            "costi_variabili": request.costi_variabili,
            "costi_fissi": request.costi_fissi,
            "investimenti": request.investimenti or 0,
            "gross_profit": metrics["gross_profit"],
            "gross_margin_pct": metrics["gross_margin_pct"],
            "ebitda": metrics["ebitda"],
            "ebitda_margin_pct": metrics["ebitda_margin_pct"],
            "net_profit": metrics["net_profit"],
            "net_margin_pct": metrics["net_margin_pct"],
            "roi_pct": metrics["roi_pct"],
            "industry_insight": industry_insight,
            "faq_context": faq_context,
            "data_readiness": data_readiness.to_dict(),
        }

        quick_answer = _quick_kpi_answer(specific_question, analysis, industry_insight, intent_result)
        if quick_answer is not None:
            answer_validation = validate_cfo_answer(quick_answer, industry_insight)
            return {
                "status": "success",
                "timestamp": time.time(),
                "company": {
                    "name": request.company_name or "Company",
                    "sector": request.settore,
                },
                "base_analysis": {
                    "status": analysis.status.value,
                    "headline": analysis.headline,
                    "summary": analysis.summary,
                    "kpi_snapshot": {
                        "gross_profit_eur": analysis.kpi_snapshot.gross_profit_eur,
                        "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
                        "ebitda_eur": analysis.kpi_snapshot.ebitda_eur,
                        "ebitda_margin_pct": analysis.kpi_snapshot.ebitda_margin_pct,
                        "net_profit_eur": analysis.kpi_snapshot.net_profit_eur,
                        "net_margin_pct": analysis.kpi_snapshot.net_margin_pct,
                        "roi_pct": analysis.kpi_snapshot.roi_pct,
                    }
                },
                "industry_insight": industry_insight,
                "data_readiness": data_readiness.to_dict(),
                "war_room": war_room,
                "ai_response": quick_answer.to_dict(),
                "formatted_text": _format_human_quick_answer(quick_answer),
                "answer_validation": {
                    "is_valid": answer_validation.is_valid,
                    "warnings": answer_validation.warnings,
                    "blocked_terms": answer_validation.blocked_terms,
                    "response_source": "deterministic_kpi",
                    "intent": intent_result.intent.value,
                    "intent_confidence": intent_result.confidence,
                },
                "faq_context": faq_context,
                "trend_context": trend_context if trend_context else "No historical trends available yet",
                "question_asked": specific_question or None,
            }

        if strategic_answer is not None:
            return {
                "status": "success",
                "timestamp": time.time(),
                "company": {
                    "name": request.company_name or "Company",
                    "sector": request.settore,
                },
                "base_analysis": {
                    "status": analysis.status.value,
                    "headline": analysis.headline,
                    "summary": analysis.summary,
                    "kpi_snapshot": {
                        "gross_profit_eur": analysis.kpi_snapshot.gross_profit_eur,
                        "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
                        "ebitda_eur": analysis.kpi_snapshot.ebitda_eur,
                        "ebitda_margin_pct": analysis.kpi_snapshot.ebitda_margin_pct,
                        "net_profit_eur": analysis.kpi_snapshot.net_profit_eur,
                        "net_margin_pct": analysis.kpi_snapshot.net_margin_pct,
                        "roi_pct": analysis.kpi_snapshot.roi_pct,
                    }
                },
                "industry_insight": industry_insight,
                "data_readiness": data_readiness.to_dict(),
                "war_room": war_room,
                "ai_response": {
                    "key_number": "Strategia CFO",
                    "headline": "Risposta strategica deterministica",
                    "diagnostic": strategic_answer,
                    "risk_assessment": "",
                    "priority_action": "",
                    "other_actions": [],
                    "estimated_impact": "",
                    "why_it_matters": "",
                    "strategic_advice": strategic_answer,
                },
                "formatted_text": strategic_answer,
                "answer_validation": {
                    "is_valid": True,
                    "warnings": [],
                    "blocked_terms": [],
                    "response_source": "deterministic_strategy",
                    "intent": intent_result.intent.value,
                    "intent_confidence": intent_result.confidence,
                },
                "faq_context": faq_context,
                "trend_context": trend_context if trend_context else "No historical trends available yet",
                "question_asked": specific_question or None,
            }
        
        # Call AI provider with optional question. If the external model fails,
        # keep the product usable with a governed deterministic CFO response.
        try:
            ai_response: CFOAnalysisAI = provider.analyze(
                company_data=company_data,
                specific_question=specific_question,
                trend_context=trend_context if trend_context else None,
            )
            answer_validation = validate_cfo_answer(ai_response, industry_insight)
            response_source = "ai"
        except Exception as e:
            ai_response = build_safe_cfo_answer(
                insight=industry_insight,
                base_analysis={
                    "potential_recovery_eur": analysis.potential_recovery_eur,
                    "estimated_loss_eur": analysis.estimated_loss_eur,
                    "kpi_snapshot": {
                        "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
                        "net_margin_pct": analysis.kpi_snapshot.net_margin_pct,
                    },
                },
                specific_question=specific_question,
            )
            answer_validation = AnswerValidation(
                is_valid=False,
                warnings=[f"Provider AI non disponibile: {str(e)}"],
                blocked_terms=[],
            )
            response_source = "deterministic_fallback"

        if not answer_validation.is_valid:
            ai_response = build_safe_cfo_answer(
                insight=industry_insight,
                base_analysis={
                    "potential_recovery_eur": analysis.potential_recovery_eur,
                    "estimated_loss_eur": analysis.estimated_loss_eur,
                    "kpi_snapshot": {
                        "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
                        "net_margin_pct": analysis.kpi_snapshot.net_margin_pct,
                    },
                },
                specific_question=specific_question,
            )
            response_source = "deterministic_fallback"
        
        # ====== STEP 5: Build response ======
        return {
            "status": "success",
            "timestamp": time.time(),
            "company": {
                "name": request.company_name or "Company",
                "sector": request.settore,
            },
            "base_analysis": {
                "status": analysis.status.value,
                "headline": analysis.headline,
                "summary": analysis.summary,
                "kpi_snapshot": {
                    "gross_profit_eur": analysis.kpi_snapshot.gross_profit_eur,
                    "gross_margin_pct": analysis.kpi_snapshot.gross_margin_pct,
                    "ebitda_eur": analysis.kpi_snapshot.ebitda_eur,
                    "ebitda_margin_pct": analysis.kpi_snapshot.ebitda_margin_pct,
                    "net_profit_eur": analysis.kpi_snapshot.net_profit_eur,
                    "net_margin_pct": analysis.kpi_snapshot.net_margin_pct,
                    "roi_pct": analysis.kpi_snapshot.roi_pct,
                }
            },
            "industry_insight": industry_insight,
            "data_readiness": data_readiness.to_dict(),
            "war_room": war_room,
            "ai_response": ai_response.to_dict(),
            "formatted_text": ai_response.to_formatted_text(),
            "answer_validation": {
                "is_valid": answer_validation.is_valid,
                "warnings": answer_validation.warnings,
                "blocked_terms": answer_validation.blocked_terms,
                "response_source": response_source,
            },
            "faq_context": faq_context,
            "trend_context": trend_context if trend_context else "No historical trends available yet",
            "question_asked": specific_question or None,
        }
    
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"AI Analysis error: {str(e)}",
        )


def _get_faq_context(specific_question: Optional[str]) -> Optional[Dict]:
    """Return matched FAQ context for a CEO question, if available."""
    if not specific_question:
        return None

    try:
        faq = route_faq(specific_question)
    except Exception:
        return None

    if not faq.get("matched"):
        return None

    return {
        "answer": faq.get("answer"),
        "score": faq.get("score"),
        "category": faq.get("category"),
        "matched_question": faq.get("matched_question"),
    }


def _quick_kpi_answer(
    question: Optional[str],
    analysis,
    industry_insight: Dict,
    intent_result: Optional[IntentResult] = None,
) -> Optional[CFOAnalysisAI]:
    """Short deterministic answers for single-KPI chat questions."""
    if not question:
        return None

    intent_result = intent_result or route_cfo_intent(question)
    kpi = analysis.kpi_snapshot
    next_move = _humanize_move(industry_insight.get("next_best_move", {}).get("move", "mantieni disciplina sui margini"))
    health = _humanize_health(industry_insight.get("health_label", "da verificare"))

    if intent_result.intent == CFOIntent.KPI_ROI:
        return CFOAnalysisAI(
            key_number=f"ROI attuale: {kpi.roi_pct:.1f}%" if kpi.roi_pct is not None else "ROI non calcolabile senza investimenti",
            headline="Rendimento del capitale investito",
            diagnostic=(
                f"Il ROI misura utile / investimenti x 100. Con utile netto di {_format_eur(kpi.net_profit_eur)} "
                f"e investimenti inseriti, il rendimento e' {kpi.roi_pct:.1f}%."
                if kpi.roi_pct is not None
                else "Per calcolare il ROI servono utile e investimenti maggiori di zero."
            ),
            risk_assessment="Un ROI alto va letto insieme a margine e cassa: se cresce solo per investimenti bassi, puo' non essere sostenibile.",
            priority_action="Usa il ROI per decidere dove reinvestire capitale, non come unico indicatore di salute.",
            other_actions=["Confronta ROI con margine netto", "Verifica cash flow operativo", "Simula nuovi investimenti prima di scalare"],
            estimated_impact="Impatto da stimare con scenario dedicato sugli investimenti.",
            why_it_matters="Ti dice se il capitale impiegato sta creando valore o assorbendo risorse.",
            strategic_advice=f"Stato CFO: {health}. Prossima mossa: {next_move}.",
        )

    if intent_result.intent == CFOIntent.KPI_PROFIT:
        return CFOAnalysisAI(
            key_number=f"Utile netto: {_format_eur(kpi.net_profit_eur)} ({kpi.net_margin_pct:.1f}% del fatturato)",
            headline="Profitto netto aziendale",
            diagnostic=(
                f"L'utile e' quello che resta all'azienda dopo aver pagato i costi. Qui rimangono {_format_eur(kpi.net_profit_eur)}. "
                f"Il margine netto e' {kpi.net_margin_pct:.1f}%."
            ),
            risk_assessment="Il rischio non e' l'utile di oggi: e' crescere facendo scendere questo margine.",
            priority_action=next_move,
            other_actions=["Guarda margine lordo prima del fatturato", "Controlla costi fissi mese per mese", "Simula crescita e costi in percentuale"],
            estimated_impact=f"Miglioramento potenziale stimato: {_format_eur(analysis.potential_recovery_eur)}",
            why_it_matters="L'utile finanzia cassa, investimenti e sicurezza. Il fatturato da solo non basta.",
            strategic_advice=f"Da CFO: {health}. Cresci solo se ogni euro in piu' mantiene margine.",
        )

    if intent_result.intent == CFOIntent.KPI_EBITDA:
        return CFOAnalysisAI(
            key_number=f"EBITDA: EUR {kpi.ebitda_eur:,.0f} ({kpi.ebitda_margin_pct:.1f}% del fatturato)",
            headline="Redditivita' operativa",
            diagnostic="L'EBITDA misura la performance operativa prima di interessi, tasse e ammortamenti.",
            risk_assessment="Se l'EBITDA scende mentre il fatturato cresce, la crescita sta consumando marginalita'.",
            priority_action=next_move,
            other_actions=["Controlla costi fissi", "Proteggi pricing", "Misura EBITDA per linea di business"],
            estimated_impact="Impatto da stimare simulando prezzo, volumi e costi fissi.",
            why_it_matters="E' il KPI piu' rapido per capire se il motore operativo genera cassa potenziale.",
            strategic_advice=f"Stato CFO: {health}. Usa EBITDA e cassa insieme, non isolati.",
        )

    return None


def _strategic_chat_answer(
    question: Optional[str],
    analysis,
    industry_insight: Dict,
    intent_result: Optional[IntentResult] = None,
    war_room: Optional[Dict] = None,
) -> Optional[str]:
    """Human CFO answers for common strategic questions."""
    intent_result = intent_result or route_cfo_intent(question)
    if not intent_result.normalized_words:
        return None

    kpi = analysis.kpi_snapshot
    next_move = _humanize_move(industry_insight.get("next_best_move", {}).get("move", "mantieni disciplina sui margini"))
    primary = industry_insight.get("primary_constraint", {})
    health = _humanize_health(industry_insight.get("health_label", "da verificare"))
    war_room = war_room or build_cfo_war_room(analysis, industry_insight, intent_result)
    final_decision = war_room.get("final_decision", {})
    score = war_room.get("business_quality_score")
    score_line = f"Business Quality Score: {score}/100. " if score is not None else ""
    data_gate = _data_gate_answer(question, intent_result, industry_insight.get("sector", ""), None)
    if data_gate:
        return data_gate

    if intent_result.intent == CFOIntent.COST_OPTIMIZATION:
        fixed_cost_pct = (kpi.ebitda_eur and 0)  # placeholder to keep simple Pylance quiet in editors
        fixed_cost_pct = max(0, 100 - kpi.gross_margin_pct - kpi.net_margin_pct)
        return (
            f"Se fossi seduto al tuo tavolo oggi, partirei dai costi, ma senza tagliare alla cieca.\n\n"
            f"{score_line}Oggi hai margine lordo {kpi.gross_margin_pct:.1f}% e margine netto {kpi.net_margin_pct:.1f}%. "
            f"Quindi il business regge, ma il taglio giusto deve proteggere qualita' e vendite.\n\n"
            f"Leve da guardare prima:\n"
            f"1. Costi variabili: fornitori, logistica, commissioni, produzione. Anche -3% qui migliora subito il margine.\n"
            f"2. Costi fissi: software, consulenze, affitti, personale non produttivo. Taglia solo cio' che non genera ricavi o controllo.\n"
            f"3. Marketing: non ridurlo tutto; sposta budget dai canali con CAC alto a quelli con margine cliente migliore.\n\n"
            f"La mia decisione: simula -5% costi variabili e -5% costi fissi separatamente. "
            f"Il taglio migliore e' quello che aumenta utile senza frenare il fatturato.\n\n"
            f"Decisione War Room: {final_decision.get('action', 'OPTIMIZE')} - {final_decision.get('why', next_move)}"
        )

    if intent_result.intent == CFOIntent.CUSTOMER_PROFITABILITY:
        avg_profit = kpi.net_profit_eur
        return (
            f"Posso dirti l'utile totale, ma non ancora l'utile per cliente.\n\n"
            f"Oggi vedo utile netto {_format_eur(kpi.net_profit_eur)} e margine netto {kpi.net_margin_pct:.1f}%, "
            f"ma non ho il numero clienti ne' ricavi/costi per singolo cliente. Se dividessi ora, inventerei.\n\n"
            f"Per calcolarlo mi servono questi campi:\n"
            f"1. cliente\n"
            f"2. ricavi cliente\n"
            f"3. costo variabile servito/prodotto\n"
            f"4. sconti o commissioni\n"
            f"5. ore/servizi dedicati, se ci sono\n\n"
            f"Formula CFO:\n"
            f"utile per cliente = ricavi cliente - costi variabili cliente - costi diretti cliente.\n\n"
            f"Decisione: carica o inserisci una tabella clienti. Poi ti ordino i clienti in tre gruppi: "
            f"molto profittevoli, medi, da correggere. Questo e' uno dei dati piu' importanti per vendere meglio."
        )

    if intent_result.intent == CFOIntent.PRODUCT_MARGIN:
        return (
            f"Non posso sapere quali prodotti hanno piu' margine senza dati per prodotto.\n\n"
            f"Il margine aziendale e' buono: lordo {kpi.gross_margin_pct:.1f}% e netto {kpi.net_margin_pct:.1f}%. "
            f"Ma questo e' il totale azienda, non mi dice quali prodotti lo generano.\n\n"
            f"Per rispondere davvero mi serve una tabella con:\n"
            f"1. nome prodotto/SKU\n"
            f"2. prezzo medio di vendita\n"
            f"3. costo acquisto o produzione\n"
            f"4. quantita' vendute\n"
            f"5. sconti, resi, commissioni o logistica se rilevanti\n\n"
            f"Formula CFO:\n"
            f"margine prodotto = (prezzo vendita - costo diretto) / prezzo vendita.\n\n"
            f"Output che ti preparo appena ho quei dati:\n"
            f"- top prodotti per margine %\n"
            f"- top prodotti per utile totale\n"
            f"- prodotti da spingere\n"
            f"- prodotti da riprezzare o togliere."
        )

    if intent_result.intent == CFOIntent.PROCUREMENT_BENCHMARK:
        return (
            f"Qui serve benchmark acquisti: non posso sapere se nel settore compri caro senza prezzi prodotto/fornitore.\n\n"
            f"Quello che posso fare e' costruire una matrice confronto:\n"
            f"1. prodotto o materia prima\n"
            f"2. fornitore attuale\n"
            f"3. prezzo unitario che paghi\n"
            f"4. quantita' acquistata\n"
            f"5. eventuale prezzo alternativo o benchmark mercato\n\n"
            f"Formula CFO:\n"
            f"risparmio potenziale = (prezzo attuale - prezzo benchmark) x quantita'.\n\n"
            f"Decisione: parti dai 10 prodotti/fornitori con spesa annua piu' alta. "
            f"Anche un -3% sui costi variabili puo' avere impatto immediato sul margine lordo.\n\n"
            f"Se mi dai quei dati, ti restituisco: dove paghi troppo, quanto puoi recuperare e quali fornitori rinegoziare prima."
        )

    if intent_result.intent == CFOIntent.WEAKNESS_DIAGNOSIS:
        return (
            f"Il quadro che vedo non e' di sopravvivenza. E' di scala.\n\n"
            f"Numero chiave: utile netto {_format_eur(kpi.net_profit_eur)}, margine netto {kpi.net_margin_pct:.1f}%.\n"
            f"{score_line}"
            f"Questo e' buono. Il rischio e' crescere e perdere controllo su margini, cassa e costi.\n\n"
            f"Dove migliorare:\n"
            f"1. Unita' economica per cliente/prodotto: devi sapere dove guadagni davvero, non solo dove fatturi.\n"
            f"2. Pricing: se hai margine forte, puoi testare aumenti selettivi invece di vendere piu' volume a basso margine.\n"
            f"3. Costi fissi: devono crescere piu' lentamente del fatturato.\n"
            f"4. Cassa: controlla incassi, magazzino e pagamenti. L'utile senza cassa non finanzia crescita.\n\n"
            f"La mia lettura: prima separa clienti/prodotti in tre gruppi: molto profittevoli, medi, da correggere. "
            f"Poi spingi solo i primi.\n\n"
            f"Stato: {health}. Vincolo principale: {_humanize_constraint(primary.get('summary', 'scalare senza perdere margine'))}."
        )

    if intent_result.intent == CFOIntent.GROWTH_STRATEGY:
        question_lower = (question or "").lower()
        if str(industry_insight.get("sector") or "").lower() == "restaurant" or any(token in question_lower for token in ["ristorante", "ristoranti", "restaurant"]):
            return (
                f"Se il tuo obiettivo e' acquisire piu' clienti nel ristorante, io non partirei dagli sconti. Partirei da domanda locale, ritorno clienti e ticket medio.\n\n"
                f"Situazione: {score_line}margine netto {kpi.net_margin_pct:.1f}% e ROI {kpi.roi_pct:.1f}%. "
                f"Quindi la domanda giusta non e' solo come portare piu' persone, ma come portare coperti che tornano, spendono bene e non comprimono il margine.\n\n"
                f"Piano in 30 giorni:\n"
                f"1. Riattiva i clienti gia' esistenti: crea una campagna su WhatsApp/Instagram/email per chi e' gia' venuto, con invito mirato su giorni deboli e non con sconto generico.\n"
                f"2. Costruisci un'offerta d'ingresso forte: menu degustazione, pranzo executive o serata tema che alzi ticket medio e ti differenzi davvero nella zona.\n"
                f"3. Presidia Google Maps, recensioni e contenuti social locali: per un ristorante, nuova domanda nasce soprattutto da reputazione, vicinanza e prova sociale.\n"
                f"4. Crea partnership locali: hotel, palestre premium, uffici, eventi, strutture turistiche. Sono canali di acquisizione a CAC piu' basso di advertising freddo.\n"
                f"5. Misura due numeri ogni settimana: nuovi coperti acquisiti e ritorno clienti entro 30 giorni. Se entra gente ma non torna, il problema non e' marketing: e' esperienza o offerta.\n\n"
                f"Leva commerciale prioritaria:\n"
                f"- giorni vuoti: promozione controllata per riempire capacita' inutilizzata\n"
                f"- giorni forti: alza ticket medio con upsell, pairing, premium dishes e prenotazioni migliori\n"
                f"- delivery: spingilo solo se resta margine vero dopo commissioni\n\n"
                f"Cosa simulare ora: +10% coperti, +5% ticket medio e +3% food cost. "
                f"Se il margine netto resta vicino al {kpi.net_margin_pct:.1f}%, la crescita e' sana. Se scende troppo, stai comprando clienti male.\n\n"
                f"Decisione War Room: {final_decision.get('action', 'TEST_GROWTH')} - {final_decision.get('why', next_move)}"
            )
        return (
            f"Se vuoi vendere di piu', io non inseguirei volume generico. Cercherei ricavi che restano utili anche dopo costi e cassa.\n\n"
            f"Situazione: {score_line}margine netto {kpi.net_margin_pct:.1f}% e ROI {kpi.roi_pct:.1f}%. "
            f"Quindi non devi inseguire volume generico: devi aumentare vendite dove resta utile.\n\n"
            f"Piano in 30 giorni:\n"
            f"1. Scegli il target migliore: clienti che comprano piu' spesso, pagano puntuali e hanno meno sconto. "
            f"Fai una lista dei 20 clienti/prospect piu' simili a loro.\n"
            f"2. Crea un'offerta semplice: pacchetto base, pacchetto consigliato e pacchetto premium. "
            f"Il pacchetto consigliato deve spingere ticket medio e margine, non solo prezzo basso.\n"
            f"3. Fai upsell ai clienti attuali: chi ha gia' comprato e' la vendita piu' economica. "
            f"Obiettivo: +10% valore medio ordine prima di aumentare il budget marketing.\n"
            f"4. Riapri i preventivi persi: contatta chi non ha comprato negli ultimi 90 giorni con una proposta specifica, non con uno sconto generico.\n"
            f"5. Misura ogni canale: tieni solo quelli dove costo acquisizione, margine e incasso stanno in piedi insieme.\n\n"
            f"Script commerciale da usare:\n"
            f"\"Ti propongo questa soluzione per aumentare risultato/risparmio, non per spendere meno. "
            f"La versione consigliata e' questa perche' ti evita il problema X e ti porta il beneficio Y.\"\n\n"
            f"Cosa simulare ora: +5% prezzo, +10% volume, +10% ticket medio. "
            f"Se il margine netto resta vicino al {kpi.net_margin_pct:.1f}%, puoi spingere. "
            f"Se scende troppo, stai vendendo male.\n\n"
            f"Decisione War Room: {final_decision.get('action', 'TEST_GROWTH')} - {final_decision.get('why', next_move)}"
        )

    return None


def _build_provided_data(company_data: AnalyzeRequest, operational_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    provided = {
        "annual_revenue": company_data.fatturato,
        "variable_costs": company_data.costi_variabili,
        "fixed_costs": company_data.costi_fissi,
        "invested_capital": company_data.investimenti or 0,
        "dso_days": company_data.dso_days,
        "dio_days": company_data.dio_days,
        "dpo_days": company_data.dpo_days,
    }
    if operational_data:
        provided.update(operational_data)
    return provided


def _data_gate_answer(
    question: Optional[str],
    intent_result: IntentResult,
    sector: str,
    readiness: Optional[DataCompletenessResult],
) -> Optional[str]:
    """Ask for sector-specific data before precise operational answers."""
    if not question:
        return None

    gated_intents = {
        CFOIntent.PRODUCT_MARGIN,
        CFOIntent.PROCUREMENT_BENCHMARK,
        CFOIntent.CUSTOMER_PROFITABILITY,
    }
    words = intent_result.normalized_words
    asks_price_target = {"prezzo", "vendere", "margine"} <= words or {"prezzo", "target"} <= words
    asks_operational = bool({"piatti", "piatto", "menu", "ingredienti", "ricetta", "merce", "personale", "coperti"} & words)

    if intent_result.intent not in gated_intents and not asks_price_target and not asks_operational:
        return None

    if readiness is None:
        return None

    if readiness.can_answer_precisely:
        return None

    missing_required = _prioritize_missing_fields(readiness.missing_required, intent_result)
    missing = missing_required[:5]
    if not missing:
        return None

    missing_lines = "\n".join(
        f"{idx}. {field.label}: {field.why_needed}" for idx, field in enumerate(missing, start=1)
    )
    question_lines = "\n".join(f"- {item}" for item in readiness.next_questions[:4])

    sector_name = readiness.sector_name.lower()
    return (
        f"Qui non ti do una risposta inventata: per questa domanda mi mancano dati operativi da {sector_name}.\n\n"
        f"Posso gia' leggere i numeri base, ma la precisione risposta ora e' {readiness.answer_precision_pct:.1f}% "
        f"e lo stato e' {readiness.readiness_level}.\n\n"
        f"Dati che mi servono prima:\n{missing_lines}\n\n"
        f"Domande che farei da CFO:\n{question_lines}\n\n"
        f"Appena mi dai questi dati posso calcolare margine reale, ROI operativo, prezzo target e priorita' di intervento "
        f"senza confondere fatturato con utile."
    )


def _try_operating_model_answer(
    question: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
    intent_result: IntentResult,
) -> Optional[str]:
    lower = (question or "").lower()
    words = intent_result.normalized_words

    asks_data_roadmap = any(
        token in lower
        for token in [
            "che dati",
            "quali dati",
            "cosa ti serve",
            "cosa manca",
            "dati mancanti",
            "analizzare meglio",
        ]
    )
    asks_company_improvement = any(
        token in lower
        for token in [
            "dove posso migliorare",
            "dove migliorare",
            "punti deboli",
            "debolezze",
            "cosa migliorare",
            "migliorare l'azienda",
            "migliorare azienda",
        ]
    )
    asks_operating_model = bool({"azienda", "struttura", "dati", "modello", "operativo"} & words) and any(
        token in lower for token in ["analisi", "leggere", "capire", "completa", "completo"]
    )

    if not (asks_data_roadmap or asks_company_improvement or asks_operating_model):
        return None

    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    model = build_company_operating_model(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
    )

    section_lines = "\n".join(
        f"- {section['label']}: {section['coverage_pct']}% ({section['status']})"
        for section in model["section_readiness"]
    )
    entity_lines = "\n".join(
        f"- {entity.replace('_', ' ')}: {detail['quality']} ({detail['count']})"
        for entity, detail in model.get("entity_catalog", {}).items()
        if detail.get("present")
    ) or "- Nessuna entita' operativa completa ancora presente."
    signal_lines = "\n".join(
        f"- {signal['message']}"
        for signal in model["cfo_signals"][:4]
    ) or "- Nessun segnale critico evidente dai dati disponibili."
    question_lines = "\n".join(
        f"{idx}. {item}"
        for idx, item in enumerate(model["next_questions"][:6], start=1)
    ) or "1. Inserisci dati operativi del settore per passare da analisi generica a diagnosi precisa."

    sector_model = model.get("active_sector_model") or {}
    sector_precision = sector_model.get("answer_precision_pct", 0)
    sector_name = sector_model.get("sector_name", "azienda")

    if asks_data_roadmap:
        opening = (
            "Per risponderti da CFO vero, non mi basta fatturato/costi. "
            "Mi serve completare il modello operativo dell'azienda."
        )
        decision = "Priorita': raccogli prima i dati che cambiano margine, cassa e capacita' operativa."
    else:
        opening = (
            "La prima lettura non e' sul frontend: e' sul modello operativo. "
            "Qui capisco dove l'azienda e' leggibile e dove sto ancora lavorando con dati parziali."
        )
        decision = "Priorita': migliora prima l'area dati piu' debole, poi decidi crescita, costi o pricing."

    return (
        f"{opening}\n\n"
        f"Numero chiave: readiness complessiva {model['overall_readiness_pct']}%. "
        f"Data quality {model['data_quality']['score_pct']}% ({model['data_quality']['level']}). "
        f"Precisione verticale {sector_name}: {sector_precision}%.\n\n"
        f"Aree aziendali:\n{section_lines}\n\n"
        f"Entita' operative gia' lette:\n{entity_lines}\n\n"
        f"Segnali CFO:\n{signal_lines}\n\n"
        f"Domande che ti farei ora:\n{question_lines}\n\n"
        f"Policy risposta: {model['data_quality']['answer_policy']}\n\n"
        f"Decisione CFO: {decision}"
    )


def _try_data_room_history_chat_answer(
    question: str,
    company_data: AnalyzeRequest,
    tenant_id: Optional[str],
    db: Optional[Session] = None,
) -> Optional[str]:
    lower = (question or "").lower()
    if not any(token in lower for token in ["storico data room", "data room cambi", "cosa è cambiato", "cosa e cambiato", "readiness data room"]):
        return None
    if not tenant_id or db is None:
        return None

    company_id = company_data.company_name or "default"
    summary = build_data_room_history_summary(
        session=db,
        tenant_id=tenant_id,
        company_id=company_id,
        limit=12,
    )
    if not summary.get("has_history"):
        return (
            "Storico Data Room\n\n"
            "Non ho ancora versioni salvate per questa azienda.\n\n"
            "Decisione CFO: salva la Data Room o importa prodotti, fornitori, personale, canali o commesse. "
            "Da quel momento posso confrontare cosa migliora o peggiora."
        )

    latest = summary.get("latest") or {}
    delta = summary.get("delta") or {}
    timeline_lines = "\n".join(
        f"- {item.get('created_at')}: readiness {item.get('readiness_score_pct')}%, "
        f"righe {item.get('row_count')}, motivo {item.get('change_reason')}"
        for item in summary.get("timeline", [])[:4]
    )
    new_sectors = ", ".join(delta.get("new_sectors") or []) or "nessuno"
    removed_sectors = ", ".join(delta.get("removed_sectors") or []) or "nessuno"
    return (
        "Storico Data Room CFO\n\n"
        f"Lettura: {summary.get('cfo_comment')}\n\n"
        f"Ultimo stato: readiness {latest.get('readiness_score_pct')}%, "
        f"{latest.get('sector_count')} settori, {latest.get('row_count')} righe operative.\n\n"
        f"Delta dall'ultima versione: readiness {delta.get('readiness_score_pct')}, "
        f"settori {delta.get('sector_count')}, righe {delta.get('row_count')}.\n"
        f"Nuovi settori: {new_sectors}. Settori rimossi: {removed_sectors}.\n\n"
        f"Timeline recente:\n{timeline_lines}\n\n"
        "Decisione CFO: usa questo storico per capire se l'azienda sta diventando piu' leggibile. "
        "Il prossimo salto e' collegare ogni miglioramento dati a una decisione War Room."
    )


def _try_data_room_chat_answer(
    question: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
) -> Optional[str]:
    lower = (question or "").lower()
    trigger_tokens = [
        "data room",
        "quale prodotto",
        "quali prodotti",
        "prodotto devo",
        "piatto devo",
        "sku devo",
        "fornitore",
        "fornitori",
        "personale",
        "dipendenti",
        "commessa",
        "commesse",
        "cantiere",
        "cantieri",
        "sal",
        "wip",
        "canale",
        "canali",
        "marketing",
        "cac",
        "roas",
        "hotel",
        "albergo",
        "camere",
        "occupancy",
        "adr",
        "ota",
        "la cassa",
        "di cassa",
        "cash flow",
        "pagamenti",
        "incassi",
        "dati mi mancano",
        "dati mancano",
        "cosa manca",
    ]
    if not any(token in lower for token in trigger_tokens):
        return None

    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    data_room = build_company_data_room(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
    )
    combined = _data_room_combined_payload(company_data, operational_data, by_sector, active_sector)
    focus = _data_room_focus(lower)

    if focus == "products":
        return _answer_product_from_data_room(combined, data_room)
    if focus == "suppliers":
        return _answer_supplier_from_data_room(combined, data_room)
    if focus == "people":
        return _answer_people_from_data_room(combined, data_room)
    if focus == "cash":
        return _answer_cash_from_data_room(combined, data_room)
    if focus == "projects":
        return _answer_projects_from_data_room(combined, data_room)
    if focus == "channels":
        return _answer_channels_from_data_room(combined, data_room)
    if focus == "hotel":
        return _answer_hotel_from_data_room(combined, data_room)

    gaps = data_room.get("priority_gaps", [])[:4]
    gap_lines = "\n".join(
        f"- {gap['label']}: {gap.get('impact', 'dato necessario per aumentare precisione')}"
        for gap in gaps
    ) or "- Nessun blocco critico evidente."
    questions = data_room.get("next_questions", [])[:5]
    question_lines = "\n".join(f"{idx}. {item}" for idx, item in enumerate(questions, start=1))
    next_step = _data_room_next_step(data_room)

    return (
        f"Data Room CFO: readiness {data_room['readiness_score_pct']}% "
        f"({data_room['readiness_level']}).\n\n"
        f"Cosa manca per risposte piu' precise:\n{gap_lines}\n\n"
        f"Domande prioritarie:\n{question_lines}\n\n"
        f"Prossimo step: {next_step}.\n\n"
        f"Decisione CFO: prima completo i dati che cambiano margine, cassa e capacita' operativa; "
        f"poi posso dirti cosa spingere, cosa tagliare e dove stai perdendo soldi."
    )


def _try_data_collection_confirmation_answer(
    question: str,
    company_data: AnalyzeRequest,
) -> Optional[str]:
    lower = (question or "").strip().lower()
    if not lower.startswith("per ") or "mi servono" not in lower:
        return None

    sector = (company_data.settore or "").lower()

    if any(token in lower for token in ["personale", "ruoli", "staff_roles", "employee_count", "payroll_costs"]):
        return (
            "Corretto: questo e' il blocco dati giusto per leggere il personale.\n\n"
            "Con `staff_roles`, `employee_count` e `payroll_costs` posso stimare:\n"
            "1. costo del lavoro per ruolo\n"
            "2. peso del personale sul margine\n"
            "3. produttivita' per coperto, ordine, camera o commessa\n\n"
            "Decisione CFO: appena li carichi, separo ruoli che sostengono crescita da ruoli che assorbono margine."
        )

    if any(token in lower for token in ["canali vendita", "sales_channels", "average_ticket", "average_order_value"]):
        return (
            "Esatto: questo e' il blocco dati dei canali vendita.\n\n"
            "Con `sales_channels`, `average_ticket` e `average_order_value` posso capire:\n"
            "1. quali canali portano clienti profittevoli\n"
            "2. quali comprano fatturato a margine basso\n"
            "3. dove conviene aumentare budget o presidio commerciale\n\n"
            "Decisione CFO: prima ordino i canali per utile reale, poi ti dico quale scalare e quale ridurre."
        )

    if any(token in lower for token in ["magazzino", "inventory", "stock_value", "stock_turnover", "operations"]):
        return (
            "Sì, questo blocco serve per magazzino e operations.\n\n"
            "Con `inventory`, `stock_value` e `stock_turnover` posso evidenziare:\n"
            "1. capitale fermo in stock\n"
            "2. sprechi e rotture di stock\n"
            "3. colli di bottiglia che bloccano margine e cassa\n\n"
            "Decisione CFO: appena li inserisci, ti mostro dove hai merce lenta, dove perdi rotazione e dove liberare cassa."
        )

    if any(token in lower for token in ["fornitori", "suppliers", "ingredient_costs", "purchase_costs", "costi unitari"]):
        suffix = "food cost, menu engineering e rinegoziazione fornitori" if sector in {"restaurant", "ristorante", "ristoranti"} else "margine prodotto, commesse e rinegoziazione fornitori"
        return (
            "Giusto: questo e' il blocco dati di costi unitari e fornitori.\n\n"
            "Con `suppliers`, `ingredient_costs` e `purchase_costs` posso calcolare:\n"
            "1. costo diretto reale per prodotto o servizio\n"
            "2. risparmio potenziale per fornitore\n"
            f"3. leve su {suffix}\n\n"
            "Decisione CFO: prima individuo le voci con spesa alta e margine fragile, poi ti dico dove rinegoziare subito."
        )

    return None


def _data_room_focus(lower: str) -> str:
    if any(token in lower for token in ["hotel", "albergo", "camere", "occupancy", "adr", "ota", "revpar"]):
        return "hotel"
    if any(token in lower for token in ["commessa", "commesse", "cantiere", "cantieri", "sal", "wip", "progetto", "progetti"]):
        return "projects"
    if any(token in lower for token in ["canale", "canali", "marketing", "cac", "roas", "ads", "campagne"]):
        return "channels"
    if any(token in lower for token in ["prodotto", "prodotti", "piatto", "piatti", "sku", "menu", "spingere", "vendere"]):
        return "products"
    if any(token in lower for token in ["fornitore", "fornitori", "acquisto", "merce"]):
        return "suppliers"
    if any(token in lower for token in ["personale", "dipendenti", "staff", "ruolo", "ruoli"]):
        return "people"
    if any(token in lower for token in ["cassa", "incassi", "pagamenti", "cash"]):
        return "cash"
    return "general"


def _data_room_combined_payload(
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    by_sector: Dict[str, Dict[str, Any]],
    active_sector: str,
) -> Dict[str, Any]:
    combined: Dict[str, Any] = company_data.model_dump(by_alias=True)
    active_data = by_sector.get(active_sector) or operational_data or {}
    if isinstance(active_data, dict):
        combined.update(active_data)
    return combined


def _answer_product_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    candidates: List[Dict[str, Any]] = []

    for item in combined.get("sku_sales") or []:
        if not isinstance(item, dict):
            continue
        name = item.get("sku") or item.get("name") or item.get("product") or "SKU"
        price = _safe_float(item.get("price") or item.get("average_price") or item.get("unit_price"))
        cost = _safe_float(item.get("purchase_cost") or item.get("unit_cost") or item.get("cogs"))
        extra = _safe_float(item.get("shipping_cost") or item.get("commission_cost") or 0)
        units = _safe_float(item.get("monthly_units") or item.get("units") or item.get("quantity") or 0)
        if price is None or cost is None:
            continue
        margin = price - cost - (extra or 0)
        candidates.append({
            "name": str(name),
            "unit_margin": margin,
            "margin_pct": (margin / price * 100) if price else 0,
            "contribution": margin * (units or 1),
        })

    for item in combined.get("products") or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name") or item.get("product") or "Prodotto"
        price = _safe_float(item.get("price") or item.get("selling_price"))
        cost = _safe_float(item.get("unit_cost") or item.get("purchase_cost") or item.get("cost"))
        units = _safe_float(item.get("monthly_units") or item.get("units") or item.get("quantity") or 0)
        if price is None or cost is None:
            continue
        margin = price - cost
        candidates.append({
            "name": str(name),
            "unit_margin": margin,
            "margin_pct": (margin / price * 100) if price else 0,
            "contribution": margin * (units or 1),
        })

    for item in combined.get("menu_items") or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name") or item.get("dish") or "Piatto"
        price = _safe_float(item.get("price") or item.get("selling_price"))
        recipe_cost = _safe_float(item.get("recipe_cost") or item.get("ingredient_cost") or item.get("food_cost"))
        units = _safe_float(item.get("monthly_units") or item.get("units_sold") or item.get("quantity") or 0)
        if price is None or recipe_cost is None:
            continue
        margin = price - recipe_cost
        candidates.append({
            "name": str(name),
            "unit_margin": margin,
            "margin_pct": (margin / price * 100) if price else 0,
            "contribution": margin * (units or 1),
        })

    if not candidates:
        missing = _missing_for_focus(data_room, ["SKU", "prodotti", "menu", "prezzo", "costo", "quantita"])
        return _missing_data_room_answer(
            "prodotti/margini",
            missing,
            "per capire quale prodotto spingere devo conoscere prezzo, costo diretto e volume venduto.",
            data_room,
        )

    ranked = sorted(candidates, key=lambda row: (row["contribution"], row["margin_pct"]), reverse=True)
    best = ranked[0]
    lines = "\n".join(
        f"{idx}. {row['name']}: margine {row['margin_pct']:.1f}%, "
        f"utile unitario {_format_eur(row['unit_margin'])}, contributo stimato {_format_eur(row['contribution'])}"
        for idx, row in enumerate(ranked[:3], start=1)
    )
    return (
        f"Data Room CFO - prodotti da spingere.\n\n"
        f"Primo prodotto: {best['name']}.\n"
        f"Perche': combina margine unitario {_format_eur(best['unit_margin'])}, "
        f"margine {best['margin_pct']:.1f}% e contributo stimato {_format_eur(best['contribution'])}.\n\n"
        f"Classifica attuale:\n{lines}\n\n"
        f"Decisione CFO: spingi il primo prodotto solo se non crea colli di bottiglia operativi "
        f"e se il volume aggiuntivo non abbassa il margine. Il prodotto migliore non e' sempre quello col margine %, "
        f"ma quello che porta piu' utile totale senza bloccare cassa e capacita'."
    )


def _answer_supplier_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    suppliers = [item for item in (combined.get("suppliers") or []) if isinstance(item, dict)]
    if not suppliers:
        missing = _missing_for_focus(data_room, ["fornitori", "prezzo", "quantita", "merce"])
        return _missing_data_room_answer(
            "fornitori/acquisti",
            missing,
            "per dirti dove paghi troppo mi servono fornitore, prodotto acquistato, prezzo unitario e volume.",
            data_room,
        )

    ranked = sorted(
        suppliers,
        key=lambda item: _safe_float(item.get("monthly_spend") or item.get("spend") or item.get("annual_spend") or 0) or 0,
        reverse=True,
    )
    lines = "\n".join(
        f"{idx}. {item.get('name') or item.get('supplier') or 'Fornitore'}: spesa stimata "
        f"{_format_eur(_safe_float(item.get('monthly_spend') or item.get('spend') or item.get('annual_spend') or 0) or 0)}"
        for idx, item in enumerate(ranked[:5], start=1)
    )
    return (
        f"Data Room CFO - fornitori da controllare.\n\n"
        f"Partirei dai fornitori con piu' spesa, perche' anche piccoli miglioramenti hanno impatto immediato.\n\n"
        f"{lines}\n\n"
        f"Decisione CFO: negozia prima i fornitori ad alta spesa e bassa sostituibilita' solo con dati in mano; "
        f"per ogni voce calcola risparmio = differenza prezzo x volume. Non tagliare qualita' se sostiene vendite o recensioni."
    )


def _answer_people_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    roles = [item for item in (combined.get("staff_roles") or combined.get("team_roles") or []) if isinstance(item, dict)]
    if not roles:
        missing = _missing_for_focus(data_room, ["personale", "ruolo", "stipendio", "ore"])
        return _missing_data_room_answer(
            "personale",
            missing,
            "per valutare il personale mi servono ruolo, costo mensile, ore e impatto operativo.",
            data_room,
        )

    ranked = sorted(
        roles,
        key=lambda item: _safe_float(item.get("monthly_cost") or item.get("salary") or item.get("cost") or 0) or 0,
        reverse=True,
    )
    lines = "\n".join(
        f"{idx}. {item.get('role') or item.get('name') or 'Ruolo'}: costo "
        f"{_format_eur(_safe_float(item.get('monthly_cost') or item.get('salary') or item.get('cost') or 0) or 0)}"
        for idx, item in enumerate(ranked[:5], start=1)
    )
    return (
        f"Data Room CFO - personale.\n\n"
        f"Non guarderei solo chi costa di piu': guarderei costo, produttivita' e impatto su ricavi/qualita'.\n\n"
        f"{lines}\n\n"
        f"Decisione CFO: prima misura ricavi o capacita' generata per ruolo. "
        f"Tagliare personale senza questa lettura puo' abbassare servizio, vendite e margine reale."
    )


def _answer_cash_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    cash_keys = ["cash_on_hand", "receivables", "payables", "dso_days", "dpo_days", "dio_days"]
    has_cash_data = any(combined.get(key) not in (None, "") for key in cash_keys)
    if not has_cash_data:
        missing = _missing_for_focus(data_room, ["cassa", "incassi", "pagamenti", "DSO", "DPO"])
        return _missing_data_room_answer(
            "cassa",
            missing,
            "per leggere la cassa devo conoscere incassi, debiti, crediti e tempi medi di pagamento.",
            data_room,
        )

    cash = _safe_float(combined.get("cash_on_hand") or 0) or 0
    receivables = _safe_float(combined.get("receivables") or 0) or 0
    payables = _safe_float(combined.get("payables") or 0) or 0
    net_position = cash + receivables - payables
    dso = _safe_float(combined.get("dso_days") or 0) or 0
    dpo = _safe_float(combined.get("dpo_days") or 0) or 0

    return (
        f"Data Room CFO - cassa.\n\n"
        f"Numero chiave: posizione stimata {_format_eur(net_position)} "
        f"(cassa {_format_eur(cash)} + crediti {_format_eur(receivables)} - debiti {_format_eur(payables)}).\n\n"
        f"Tempi: incasso medio {dso:.0f} giorni, pagamento medio {dpo:.0f} giorni.\n\n"
        f"Decisione CFO: se DSO supera DPO, la crescita puo' assorbire cassa anche con utile positivo. "
        f"Prima di scalare, riduci giorni di incasso o negozia pagamenti fornitori piu' lunghi."
    )


def _answer_projects_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    projects = [item for item in (combined.get("projects") or []) if isinstance(item, dict)]
    if not projects:
        missing = _missing_for_focus(data_room, ["commesse", "progetti", "SAL", "incassi", "avanzamento"])
        return _missing_data_room_answer(
            "commesse/cantieri",
            missing,
            "per dirti quale commessa blocca cassa o margine mi servono valore contratto, costi, avanzamento, fatturato e incassato.",
            data_room,
        )

    rows: List[Dict[str, Any]] = []
    for item in projects:
        name = item.get("project") or item.get("name") or item.get("commessa") or "Commessa"
        value = _safe_float(item.get("contract_value") or item.get("revenue") or item.get("value")) or 0
        costs = sum(
            _safe_float(item.get(key) or 0) or 0
            for key in ["materials_cost", "labor_cost", "subcontractor_cost", "other_cost", "direct_cost"]
        )
        progress = _safe_float(item.get("progress_pct") or item.get("completion_pct") or 0) or 0
        billed_pct = _safe_float(item.get("billed_pct") or item.get("invoiced_pct") or 0) or 0
        collected_pct = _safe_float(item.get("collected_pct") or item.get("paid_pct") or 0) or 0
        expected_profit = value - costs
        margin_pct = (expected_profit / value * 100) if value else 0
        wip = value * max(progress - billed_pct, 0) / 100
        cash_gap = (costs * min(progress, 100) / 100) - (value * min(collected_pct, 100) / 100)
        rows.append({
            "name": str(name),
            "value": value,
            "expected_profit": expected_profit,
            "margin_pct": margin_pct,
            "wip": wip,
            "cash_gap": cash_gap,
        })

    cash_risk = sorted(rows, key=lambda row: row["cash_gap"], reverse=True)
    margin_risk = sorted(rows, key=lambda row: row["margin_pct"])
    cash_lines = "\n".join(
        f"{idx}. {row['name']}: cash gap {_format_eur(row['cash_gap'])}, "
        f"WIP {_format_eur(row['wip'])}, margine atteso {row['margin_pct']:.1f}%"
        for idx, row in enumerate(cash_risk[:3], start=1)
    )
    weak = margin_risk[0]
    return (
        f"Data Room CFO - commesse/cantieri.\n\n"
        f"Commessa piu' delicata per cassa: {cash_risk[0]['name']} "
        f"con cash gap stimato {_format_eur(cash_risk[0]['cash_gap'])}.\n"
        f"Commessa piu' delicata per margine: {weak['name']} con margine atteso {weak['margin_pct']:.1f}%.\n\n"
        f"Priorita' operative:\n{cash_lines}\n\n"
        f"Decisione CFO: prima recupera SAL/fatturazione e incassi sulle commesse che assorbono cassa; "
        f"non aprire nuove commesse se il WIP cresce piu' degli incassi."
    )


def _answer_channels_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    channels = [item for item in (combined.get("sales_channels") or combined.get("cac_by_channel") or []) if isinstance(item, dict)]
    if not channels:
        missing = _missing_for_focus(data_room, ["canali", "CAC", "conversione", "fatturato", "margine"])
        return _missing_data_room_answer(
            "canali vendita",
            missing,
            "per dirti quale canale scalare mi servono fatturato, costo acquisizione, conversione e margine per canale.",
            data_room,
        )

    rows: List[Dict[str, Any]] = []
    for item in channels:
        name = item.get("channel") or item.get("name") or "Canale"
        revenue = _safe_float(item.get("revenue") or item.get("sales") or item.get("monthly_revenue") or 0) or 0
        cost = _safe_float(item.get("cost") or item.get("ad_spend") or item.get("spend") or 0) or 0
        margin_pct = _safe_float(item.get("margin_pct") or item.get("gross_margin_pct") or combined.get("net_margin_pct") or 0) or 0
        profit_after_cost = revenue * margin_pct / 100 - cost
        roas = revenue / cost if cost else 0
        rows.append({
            "name": str(name),
            "revenue": revenue,
            "cost": cost,
            "margin_pct": margin_pct,
            "profit_after_cost": profit_after_cost,
            "roas": roas,
        })

    ranked = sorted(rows, key=lambda row: (row["profit_after_cost"], row["roas"]), reverse=True)
    lines = "\n".join(
        f"{idx}. {row['name']}: utile dopo costo canale {_format_eur(row['profit_after_cost'])}, "
        f"ROAS {row['roas']:.1f}, ricavi {_format_eur(row['revenue'])}"
        for idx, row in enumerate(ranked[:4], start=1)
    )
    return (
        f"Data Room CFO - canali vendita.\n\n"
        f"Canale da scalare prima: {ranked[0]['name']}.\n"
        f"Perche': genera {_format_eur(ranked[0]['profit_after_cost'])} dopo il costo canale, "
        f"con ROAS {ranked[0]['roas']:.1f}.\n\n"
        f"Classifica canali:\n{lines}\n\n"
        f"Decisione CFO: sposta budget dai canali con utile post-costo basso verso quelli con margine e payback migliori. "
        f"Non scalare solo sul ROAS: controlla anche resi, incassi e margine netto."
    )


def _answer_hotel_from_data_room(combined: Dict[str, Any], data_room: Dict[str, Any]) -> str:
    rooms = _safe_float(combined.get("rooms"))
    occupancy = _safe_float(combined.get("occupancy_rate"))
    adr = _safe_float(combined.get("adr"))
    ota = _safe_float(combined.get("ota_commissions") or combined.get("ota_commissions_pct") or 0) or 0
    if rooms is None or occupancy is None or adr is None:
        missing = _missing_for_focus(data_room, ["camere", "occupancy", "ADR", "OTA", "hotel"])
        return _missing_data_room_answer(
            "hotel",
            missing,
            "per leggere un hotel mi servono almeno camere, occupancy, ADR e commissioni OTA.",
            data_room,
        )

    occupied_room_nights_month = rooms * 30 * occupancy / 100
    monthly_room_revenue = occupied_room_nights_month * adr
    revpar = adr * occupancy / 100
    ota_cost = monthly_room_revenue * ota / 100
    direct_revenue = monthly_room_revenue - ota_cost
    return (
        f"Data Room CFO - hotel.\n\n"
        f"Numero chiave: RevPAR {_format_eur(revpar)}. "
        f"Ricavi camere stimati/mese {_format_eur(monthly_room_revenue)} su {occupied_room_nights_month:.0f} room night vendute.\n\n"
        f"Commissioni OTA stimate: {_format_eur(ota_cost)}. Ricavo netto dopo OTA: {_format_eur(direct_revenue)}.\n\n"
        f"Decisione CFO: lavora su tre leve in ordine: occupancy nei giorni vuoti, ADR nei giorni di domanda forte, "
        f"e mix canali per ridurre commissioni OTA senza perdere prenotazioni."
    )


def _missing_for_focus(data_room: Dict[str, Any], tokens: List[str]) -> List[Dict[str, Any]]:
    lowered = [token.lower() for token in tokens]
    gaps = data_room.get("priority_gaps", [])
    matches = [
        gap for gap in gaps
        if any(token in f"{gap.get('label', '')} {gap.get('field', '')}".lower() for token in lowered)
    ]
    return matches[:5] or gaps[:5]


def _missing_data_room_answer(
    focus: str,
    missing: List[Dict[str, Any]],
    why: str,
    data_room: Dict[str, Any],
) -> str:
    missing_lines = "\n".join(
        f"{idx}. {gap.get('label') or gap.get('field')}: {gap.get('impact') or gap.get('why_needed', 'dato necessario')}"
        for idx, gap in enumerate(missing[:5], start=1)
    ) or "1. Dati operativi specifici su prezzi, costi, volumi e tempi."
    next_step = _data_room_next_step(data_room)
    return (
        f"Data Room CFO - {focus}.\n\n"
        f"Qui non invento: {why}\n\n"
        f"Dati mancanti:\n{missing_lines}\n\n"
        f"Prossimo step: {next_step}.\n\n"
        f"Appena li inserisci posso calcolare priorita', impatto economico e decisione consigliata."
    )


def _data_room_next_step(data_room: Dict[str, Any]) -> str:
    guided = data_room.get("guided_collection") or {}
    first_step = guided.get("first_step") if isinstance(guided, dict) else None
    if isinstance(first_step, dict):
        return first_step.get("label") or first_step.get("step_id") or "Completa il primo blocco della Data Room"
    steps = guided.get("steps") if isinstance(guided, dict) else []
    if steps and isinstance(steps[0], dict):
        return steps[0].get("label") or steps[0].get("step_id") or "Completa il primo blocco della Data Room"
    return "Completa il primo blocco della Data Room"


def _try_decision_playbook_chat_answer(
    question: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
    intent_result: IntentResult,
) -> Optional[str]:
    strategic_intents = {
        CFOIntent.GROWTH_STRATEGY,
        CFOIntent.COST_OPTIMIZATION,
        CFOIntent.WEAKNESS_DIAGNOSIS,
        CFOIntent.PRODUCT_MARGIN,
        CFOIntent.PROCUREMENT_BENCHMARK,
    }
    if intent_result.intent not in strategic_intents:
        return None

    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    playbook = build_decision_playbook(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
        question=question,
    )
    decision = playbook["decision"]
    actions = decision["actions"]

    actions_30 = _numbered_lines(actions.get("30_days", []))
    actions_60 = _numbered_lines(actions.get("60_days", []))
    actions_90 = _numbered_lines(actions.get("90_days", []))
    kpis = ", ".join(decision.get("kpis_to_monitor", []))
    next_questions = playbook.get("operating_model_summary", {}).get("next_questions", [])
    next_question = next_questions[0] if next_questions else "Vuoi che trasformi questo piano in priorita' settimanali con impatto stimato?"

    growth_line = ""
    if playbook["intent"] == CFOIntent.GROWTH_STRATEGY.value:
        growth_line = "Vincolo principale: scala il fatturato solo dove margine, cassa e capacita' operativa restano sotto controllo.\n\n"

    return (
        f"{decision['title']}\n\n"
        f"Decisione CFO: {decision['decision']}\n\n"
        f"{growth_line}"
        f"Perche' conta: {decision['why']}\n\n"
        f"Impatto stimato: {decision['economic_impact']}\n"
        f"Owner: {decision['owner']}\n"
        f"Priorita': {decision['priority']}\n\n"
        f"Piano 30 giorni:\n{actions_30}\n\n"
        f"Piano 60 giorni:\n{actions_60}\n\n"
        f"Piano 90 giorni:\n{actions_90}\n\n"
        f"KPI da monitorare: {kpis}\n\n"
        f"Rischio: {decision['risk']}\n"
        f"Costo dell'inazione: {decision['cost_of_inaction']}\n\n"
        f"Simulazione consigliata: {decision['recommended_simulation']}\n\n"
        f"Prossima domanda utile: {next_question}"
    )


def _try_weekly_execution_answer(
    question: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
    intent_result: IntentResult,
) -> Optional[str]:
    lower = (question or "").lower()
    if not any(
        phrase in lower
        for phrase in [
            "priorita",
            "priorità",
            "cosa devo fare",
            "da dove parto",
            "da dove iniziare",
            "prossima mossa",
            "prossime mosse",
            "war room",
            "priorita settimanali",
            "priorita' settimanali",
            "priorità settimanali",
            "azioni operative settimanali",
            "azioni settimanali",
            "piano settimanale",
            "questa settimana",
        ]
    ):
        return None

    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    if by_sector:
        war_room = build_unified_war_room(
            operational_data_by_sector=by_sector,
            active_sector=active_sector,
        )
        return _format_war_room_chat_answer(war_room)

    playbook = build_decision_playbook(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
        question=_weekly_base_question(intent_result),
    )
    decision = playbook["decision"]
    actions = (decision.get("actions") or {}).get("30_days", [])[:3]
    kpis = decision.get("kpis_to_monitor", [])[:4]

    action_lines = "\n".join(
        f"{idx}. {action}\n   Owner: {decision['owner']}\n   KPI: {kpis[min(idx - 1, len(kpis) - 1)] if kpis else 'KPI operativo'}"
        for idx, action in enumerate(actions, start=1)
    ) or "1. Completa i dati operativi mancanti.\n   Owner: Founder/CEO\n   KPI: data quality"

    return (
        "Agenda CFO di questa settimana\n\n"
        f"Decisione guida: {decision['decision']}\n\n"
        f"Le 3 priorita':\n{action_lines}\n\n"
        f"Rischio da controllare: {decision['risk']}\n\n"
        f"Simulazione da lanciare dopo le azioni: {decision['recommended_simulation']}\n\n"
        "Prossimo passo CFO: a fine settimana confronta KPI attesi vs risultati reali e aggiorna la War Room."
    )


def _format_war_room_chat_answer(war_room: Dict[str, Any]) -> str:
    priority = war_room.get("priority_decision") or {}
    agenda = war_room.get("weekly_agenda") or []
    queue = war_room.get("decision_queue") or []
    data_gaps = war_room.get("data_gap_board") or []
    stop_go = war_room.get("stop_go_board") or []
    tracker = war_room.get("execution_tracker") or []
    executive = war_room.get("executive_summary") or {}
    portfolio = war_room.get("portfolio_summary") or {}

    agenda_lines = "\n".join(
        f"{idx}. {item.get('day')}: {item.get('action')}\n"
        f"   Owner: {item.get('owner')}\n"
        f"   KPI: {item.get('kpi')}"
        for idx, item in enumerate(agenda[:3], start=1)
    ) or "1. Completa i dati operativi mancanti.\n   Owner: Founder/CEO\n   KPI: data quality"

    queue_lines = "\n".join(
        f"{item.get('rank')}. {item.get('label')}: {item.get('decision')}"
        for item in queue[:3]
    ) or "1. Inserisci almeno un verticale operativo per costruire priorita'."

    data_gap_lines = "\n".join(
        f"- {gap.get('label')}: {gap.get('field')}"
        for gap in data_gaps[:4]
    ) or "- Nessun blocco dati critico nella War Room attuale."

    stop_go_lines = "\n".join(
        f"- {rule.get('label')}: {rule.get('status')} | {rule.get('kill_switch')}"
        for rule in stop_go[:3]
    ) or "- Stop/Go non disponibile finche' mancano dati operativi."

    tracker_lines = "\n".join(
        f"- {item.get('decision_id')}: {item.get('success_metric', {}).get('rule')}"
        for item in tracker[:3]
    ) or "- Tracker disponibile appena la War Room genera almeno una decisione."

    readiness = portfolio.get("readiness_avg_pct", 0)
    return (
        "War Room CFO di questa settimana\n\n"
        f"Executive summary: {executive.get('headline')}\n"
        f"{executive.get('diagnosis')}\n\n"
        f"Decisione prioritaria: {priority.get('decision')}\n\n"
        f"Perche' ora: {priority.get('why')}\n\n"
        f"Istruzione operativa: {priority.get('board_instruction') or priority.get('next_step')}\n\n"
        f"Agenda:\n{agenda_lines}\n\n"
        f"Coda decisionale:\n{queue_lines}\n\n"
        f"Dati che possono bloccare precisione:\n{data_gap_lines}\n\n"
        f"Stop/Go control:\n{stop_go_lines}\n\n"
        f"Controllo esecuzione:\n{tracker_lines}\n\n"
        f"Readiness dati media: {readiness}%\n\n"
        "Prossimo passo CFO: esegui la prima azione, poi aggiorna i dati e rilancia la War Room."
    )


def _weekly_base_question(intent_result: IntentResult) -> str:
    if intent_result.intent == CFOIntent.COST_OPTIMIZATION:
        return "quali costi posso tagliare senza danneggiare la crescita?"
    if intent_result.intent == CFOIntent.GROWTH_STRATEGY:
        return "come posso vendere di più?"
    if intent_result.intent == CFOIntent.PRODUCT_MARGIN:
        return "quale prodotto devo spingere?"
    return "dove posso migliorare l'azienda?"


def _try_clarifying_answer(
    question: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
    intent_result: IntentResult,
) -> Optional[str]:
    words = intent_result.normalized_words
    lower = (question or "").lower()
    vague_tokens = {"aiuto", "consiglio", "utile", "cfo", "azienda", "business", "fare", "prossimo"}
    is_vague = intent_result.intent == CFOIntent.UNKNOWN or len(words - vague_tokens) <= 1
    if not is_vague:
        return None

    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    model = build_company_operating_model(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
    )
    questions = model.get("next_questions", [])[:3]
    if not questions:
        questions = [
            "Vuoi lavorare su crescita fatturato, margine o cassa?",
            "Hai dati per prodotto/cliente/canale o solo conto economico generale?",
            "Vuoi una diagnosi rapida o un piano operativo 30/60/90 giorni?",
        ]

    question_lines = "\n".join(f"{idx}. {item}" for idx, item in enumerate(questions, start=1))
    entities = [
        entity.replace("_", " ")
        for entity, detail in model.get("entity_catalog", {}).items()
        if detail.get("present")
    ]
    entity_line = ", ".join(entities[:5]) if entities else "solo dati economici base"

    return (
        "Ti rispondo meglio se restringiamo il campo.\n\n"
        f"Oggi leggo: {entity_line}.\n"
        f"Data quality: {model['data_quality']['score_pct']}% ({model['data_quality']['level']}).\n\n"
        "Scegli una direzione o rispondi a una di queste domande:\n"
        f"{question_lines}\n\n"
        "Opzioni rapide:\n"
        "- 'fammi diagnosi punti deboli'\n"
        "- 'come aumento il margine'\n"
        "- 'che dati ti servono'\n"
        "- 'fammi piano settimanale'\n\n"
        "Prossimo passo CFO: scegli margine, crescita o cassa e ti preparo un piano operativo."
    )


def _numbered_lines(items: List[str]) -> str:
    return "\n".join(f"{idx}. {item}" for idx, item in enumerate(items, start=1)) or "1. Nessuna azione disponibile."


def _append_follow_up(response: str, next_best_prompt: Optional[str]) -> str:
    if not next_best_prompt:
        return response
    if "Prossimo passo CFO:" in response:
        return response
    return f"{response}\n\nProssimo passo CFO: {next_best_prompt}"


def _prioritize_missing_fields(missing_fields, intent_result: IntentResult):
    if intent_result.intent == CFOIntent.PRODUCT_MARGIN:
        priority = {
            "menu_items": 0,
            "ingredient_costs": 1,
            "recipe_quantities": 2,
            "sku_sales": 0,
            "sku_purchase_costs": 1,
            "shipping_cost_per_order": 2,
        }
    elif intent_result.intent == CFOIntent.PROCUREMENT_BENCHMARK:
        priority = {
            "ingredient_costs": 0,
            "sku_purchase_costs": 0,
            "supplier_prices": 1,
            "materials_cost_by_project": 1,
        }
    elif intent_result.intent == CFOIntent.CUSTOMER_PROFITABILITY:
        priority = {
            "sku_sales": 0,
            "customer_acquisition_cost": 1,
            "sales_channels": 2,
        }
    else:
        priority = {}

    return sorted(
        missing_fields,
        key=lambda field: (priority.get(field.key, 50), field.category, field.label),
    )


def _is_single_kpi_question(question: Optional[str]) -> bool:
    return is_single_kpi_intent(route_cfo_intent(question))


def _format_human_quick_answer(answer: CFOAnalysisAI) -> str:
    """Compact CFO-style text for chat KPI questions."""
    actions = "\n".join(f"- {action}" for action in (answer.other_actions or [])[:3])
    return (
        f"{answer.key_number}\n\n"
        f"Lettura CFO: {answer.diagnostic}\n\n"
        f"Punto di attenzione: {answer.risk_assessment}\n\n"
        f"Cosa farei adesso: {answer.priority_action}\n\n"
        f"Controlli subito utili:\n{actions}\n\n"
        f"{answer.strategic_advice}"
    )


# ============================================
# ENDPOINT 2: /cfo/simulate - Scenario Analysis
# ============================================

@router.post(
    "/simulate",
    response_model=SimulateResponse,
    summary="Scenario Simulation",
    description="Simulate financial impact of changes",
)
def cfo_simulate(
    request: SimulateRequest,
    tenant: TenantContext = Depends(require_auth),
) -> SimulateResponse:
    """
    Simulate different business scenarios
    
    Compare base case with hypothetical changes:
    - Price increases/decreases
    - Cost reductions
    - Investment changes
    - Volume changes
    
    Returns side-by-side comparison with recommendations
    """
    
    try:
        # Validate scenario name
        if not request.scenario_name or len(request.scenario_name.strip()) == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Scenario name is required",
            )
        
        # Base case analysis
        base_analysis = analyze_company(
            fatturato=request.base_analysis.fatturato,
            costi_variabili=request.base_analysis.costi_variabili,
            costi_fissi=request.base_analysis.costi_fissi,
            investimenti=request.base_analysis.investimenti or 0,
            settore=request.base_analysis.settore,
            company_name=request.base_analysis.company_name,
        )
        
        # Calculate scenario values
        scenario_fatturato = request.base_analysis.fatturato + (request.fatturato_delta or 0)
        scenario_cv = request.base_analysis.costi_variabili + (request.costi_variabili_delta or 0)
        scenario_cf = request.base_analysis.costi_fissi + (request.costi_fissi_delta or 0)
        scenario_invest = request.base_analysis.investimenti + (request.investimenti_delta or 0)
        
        # Validate scenario values
        if scenario_fatturato <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Scenario revenue must remain positive",
            )
        
        if scenario_cv < 0 or scenario_cf < 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Scenario costs cannot be negative",
            )
        
        # Scenario analysis
        scenario_analysis = analyze_company(
            fatturato=scenario_fatturato,
            costi_variabili=scenario_cv,
            costi_fissi=scenario_cf,
            investimenti=scenario_invest,
            settore=request.base_analysis.settore,
            company_name=request.base_analysis.company_name,
        )
        
        # Calculate comparison
        profit_delta = scenario_analysis.kpi_snapshot.net_profit_eur - base_analysis.kpi_snapshot.net_profit_eur
        profit_delta_pct = (
            (profit_delta / abs(base_analysis.kpi_snapshot.net_profit_eur) * 100)
            if base_analysis.kpi_snapshot.net_profit_eur != 0
            else 0
        )
        
        # ROI delta
        roi_delta_pct = None
        if (
            base_analysis.kpi_snapshot.roi_pct is not None and
            scenario_analysis.kpi_snapshot.roi_pct is not None
        ):
            roi_delta_pct = (
                scenario_analysis.kpi_snapshot.roi_pct - 
                base_analysis.kpi_snapshot.roi_pct
            )
        
        # Recommendation
        if profit_delta > 0:
            recommendation = f"YES - This scenario improves profit by €{profit_delta:,.0f} ({profit_delta_pct:+.1f}%)"
        elif profit_delta > -10000:
            recommendation = f"MAYBE - Profit changes by €{profit_delta:,.0f} ({profit_delta_pct:+.1f}%). Consider other factors."
        else:
            recommendation = f"NO - This scenario reduces profit by €{abs(profit_delta):,.0f} ({profit_delta_pct:+.1f}%). Not recommended."
        
        return SimulateResponse(
            scenario_name=request.scenario_name,
            base_analysis=base_analysis,
            scenario_analysis=scenario_analysis,
            comparison={
                "base_kpi": base_analysis.kpi_snapshot,
                "scenario_kpi": scenario_analysis.kpi_snapshot,
                "profit_delta_eur": round(profit_delta, 2),
                "profit_delta_pct": round(profit_delta_pct, 2),
                "roi_delta_pct": roi_delta_pct,
                "recommendation": recommendation,
            },
            impact={
                "revenue_impact": round(scenario_fatturato - request.base_analysis.fatturato, 2),
                "cost_impact": round((scenario_cv + scenario_cf) - (request.base_analysis.costi_variabili + request.base_analysis.costi_fissi), 2),
                "profit_impact": round(profit_delta, 2),
            },
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Simulation error: {str(e)}",
        )


# ============================================
# ENDPOINT 3: /cfo/trends - Get Trend Indicators
# ============================================

@router.get(
    "/trends",
    response_model=dict,  # Returns TrendsResponse schema
    summary="Get Trend Indicators",
    description="Retrieve month-over-month trend data for KPI indicators",
)
def cfo_trends(
    company_id: str = "default",
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> dict:
    """
    Get trend indicators for a company.
    
    Returns:
    - Month-over-month changes for key metrics
    - Trend direction (improving/worsening/stable)
    - Momentum score for overall health trajectory
    - Alerts for metrics needing attention
    
    Used to enrich dashboard KPI cards with trend visualization.
    
    **Query Parameters:**
    - company_id: Company identifier (default: "default")
    
    **Returns:**
    - has_data: True if historical data available (need 2+ months)
    - revenue_trend: Revenue MoM change
    - gross_margin_trend: Gross margin MoM change
    - ebitda_margin_trend: EBITDA margin MoM change
    - net_margin_trend: Net margin MoM change
    - roi_trend: ROI MoM change
    - momentum_score: Overall trajectory (-100 to +100)
    - momentum_label: Improving/Stable/Declining
    - alerts: List of trend alerts
    - trend_summary: Formatted trend text
    """
    
    try:
        # Get trend summary
        trend_summary = get_trend_summary_for_decision(
            session=db,
            tenant_id=tenant.tenant_id,
            company_id=company_id
        )
        
        # If no trend data, return empty response
        if not trend_summary:
            return {
                "has_data": False,
                "revenue_trend": None,
                "gross_margin_trend": None,
                "ebitda_margin_trend": None,
                "net_margin_trend": None,
                "roi_trend": None,
                "momentum_score": 0,
                "momentum_label": "Stable",
                "alerts": [],
                "trend_summary": "No historical data available yet. Submit data for 2+ months to see trends."
            }
        
        # Get historical records for detailed analysis
        from core.trend_analysis import TrendAnalyzer
        records = get_company_metrics_history(
            session=db,
            tenant_id=tenant.tenant_id,
            company_id=company_id,
            months=2
        )
        
        if len(records) < 2:
            return {
                "has_data": False,
                "revenue_trend": None,
                "gross_margin_trend": None,
                "ebitda_margin_trend": None,
                "net_margin_trend": None,
                "roi_trend": None,
                "momentum_score": 0,
                "momentum_label": "Stable",
                "alerts": [],
                "trend_summary": "Need at least 2 months of data to calculate trends."
            }
        
        # Build metrics dicts
        current = records[-1]
        previous = records[-2]
        
        current_metrics = {
            "fatturato": current.fatturato,
            "costi_variabili": current.costi_variabili,
            "costi_fissi": current.costi_fissi,
            "investimenti": current.investimenti,
            "gross_profit": current.gross_profit,
            "gross_margin_pct": current.gross_margin_pct,
            "ebitda": current.ebitda,
            "ebitda_margin_pct": current.ebitda_margin_pct,
            "net_profit": current.net_profit,
            "net_margin_pct": current.net_margin_pct,
            "roi_pct": current.roi_pct or 0,
        }
        
        previous_metrics = {
            "fatturato": previous.fatturato,
            "costi_variabili": previous.costi_variabili,
            "costi_fissi": previous.costi_fissi,
            "investimenti": previous.investimenti,
            "gross_profit": previous.gross_profit,
            "gross_margin_pct": previous.gross_margin_pct,
            "ebitda": previous.ebitda,
            "ebitda_margin_pct": previous.ebitda_margin_pct,
            "net_profit": previous.net_profit,
            "net_margin_pct": previous.net_margin_pct,
            "roi_pct": previous.roi_pct or 0,
        }
        
        # Analyze trends
        analyzer = TrendAnalyzer()
        trends = analyzer.analyze_metrics(current_metrics, previous_metrics, current.company_name)
        
        # Build response
        def trend_to_dict(trend):
            if trend is None:
                return None
            return {
                "metric_name": trend.metric_name,
                "current_value": trend.current_value,
                "previous_value": trend.previous_value,
                "change_pct": round(trend.change_pct, 2),
                "direction": trend.direction.value,
                "is_alert": trend.is_alert,
            }
        
        return {
            "has_data": True,
            "revenue_trend": trend_to_dict(trends.revenue_trend),
            "gross_margin_trend": trend_to_dict(trends.gross_margin_trend),
            "ebitda_margin_trend": trend_to_dict(trends.ebitda_margin_trend),
            "net_margin_trend": trend_to_dict(trends.net_margin_trend),
            "roi_trend": trend_to_dict(trends.roi_trend),
            "momentum_score": round(trends.momentum_score, 1),
            "momentum_label": "Improving" if trends.momentum_score > 10 else "Declining" if trends.momentum_score < -10 else "Stable",
            "alerts": trends.alerts,
            "trend_summary": trend_summary,
        }
    
    except Exception as e:
        # Return error as trends data
        return {
            "has_data": False,
            "revenue_trend": None,
            "gross_margin_trend": None,
            "ebitda_margin_trend": None,
            "net_margin_trend": None,
            "roi_trend": None,
            "momentum_score": 0,
            "momentum_label": "Stable",
            "alerts": [],
            "trend_summary": f"Error retrieving trends: {str(e)}"
        }


# ============================================
# ENDPOINT 4: /cfo/chat - CFO Assistant Chat
# ============================================

@router.post(
    "/chat",
    response_model=ChatResponse,
    summary="CFO Assistant Chat",
    description="Ask financial questions to AI-powered CFO assistant",
)
def cfo_chat(
    request: ChatRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> ChatResponse:
    """
    AI-powered CFO assistant for financial questions
    
    Uses advanced intent recognition and specialized financial engines:
    - Expert Rules: Intelligent priority ranking
    - Valuation: DCF analysis and multiples
    - Acquisition ROI: M&A scenario analysis
    - Simulations: What-if scenario modeling
    - KPI Analysis: Performance metrics
    - Liquidity: Working capital optimization
    
    Ask questions about:
    - Profitability improvement strategies
    - Company valuation ("Quanto vale?")
    - Acquisition decisions ("Se acquisisco...?")
    - Cost reduction opportunities
    - Pricing strategies
    - Business scaling
    - Financial ratios and benchmarking
    
    Returns personalized recommendations based on company data and intent.
    """
    
    try:
        effective_message = _resolve_short_follow_up(request.message, request.chat_history or [])

        # Validate message
        if not effective_message or len(effective_message.strip()) < 3:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Please provide a meaningful question (minimum 3 characters)",
            )
        
        # Create CFO chatbot engine
        engine = create_cfo_engine()
        company_id = request.company_data.company_name or "default"
        saved_data_room = get_data_room_snapshot(db, tenant.tenant_id, company_id)
        merged_data_room = merge_saved_data_room(
            saved_data_room,
            request.company_data.model_dump(by_alias=True),
            request.operational_data_by_sector,
        )
        effective_operational_by_sector = merged_data_room["operational_data_by_sector"] or request.operational_data_by_sector
        effective_operational_data = request.operational_data
        active_sector = request.company_data.settore or merged_data_room.get("active_sector")
        if not effective_operational_data and active_sector:
            effective_operational_data = (effective_operational_by_sector or {}).get(active_sector)
        
        # Build context from company data
        context = {
            "fatturato": request.company_data.fatturato,
            "costi_variabili": request.company_data.costi_variabili,
            "costi_fissi": request.company_data.costi_fissi,
            "investimenti": request.company_data.investimenti or 0,
            "dso_days": getattr(request.company_data, "dso_days", 30) or 30,
            "dio_days": getattr(request.company_data, "dio_days", 45) or 45,
            "dpo_days": getattr(request.company_data, "dpo_days", 30) or 30,
            # Opzionali per M&A analysis
            "net_debt": getattr(request.company_data, "net_debt", 0) or 0,
            "target_price": getattr(request.company_data, "target_price", None),
            "target_ebitda": getattr(request.company_data, "target_ebitda", None),
        }

        controlled_response = _try_controlled_chat_response(
            effective_message,
            request.company_data,
            effective_operational_data,
            effective_operational_by_sector,
            tenant.tenant_id,
            db,
        )
        if controlled_response:
            conversation_state = _build_chat_conversation_state(
                original_message=request.message,
                effective_message=effective_message,
                intent=controlled_response["intent"],
                response=controlled_response["response"],
                company_data=request.company_data,
                operational_data=effective_operational_data,
                operational_data_by_sector=effective_operational_by_sector,
            )
            _save_to_chat_memory(
                tenant_id=tenant.tenant_id,
                question=effective_message,
                intent=controlled_response["intent"],
                response_summary=controlled_response["response"],
            )
            return ChatResponse(
                response=controlled_response["response"],
                analysis=None,
                recommendations=None,
                conversation_state=conversation_state,
            )
        
        # Analyze question using new CFO engine
        analysis_result = engine.analyze(effective_message, context)
        response_data = analysis_result.to_response()
        
        # Build narrative response
        narrative = response_data.get("narrative", "Analisi completata.")
        
        # Save to chat memory (for future context) ✅ MEMORY SYSTEM
        _save_to_chat_memory(
            tenant_id=tenant.tenant_id,
            question=effective_message,
            intent=analysis_result.intent,
            response_summary=narrative,
        )
        
        # Extract recommendations if present (for structured output)
        recommendations = None
        question_lower = effective_message.lower()
        if any(keyword in question_lower for keyword in ["cosa", "come", "azioni", "strategie", "raccomandazioni", "suggerisci", "priorit"]):
            # If expert_rules or strategy, include action recommendations
            if analysis_result.intent in ["expert_rules", "strategy_analysis"]:
                recommendations = []  # Could be extended to build RecommendedAction objects
        
        return ChatResponse(
            response=narrative,
            analysis=None,  # Don't include full analysis in chat response to keep it lightweight
            recommendations=recommendations,
            conversation_state={
                "intent": str(analysis_result.intent),
                "original_message": request.message,
                "resolved_message": effective_message,
                "next_best_prompt": "Vuoi che trasformi questa risposta in un piano operativo CFO?",
                "suggested_action": "decision_playbook",
                "requires_follow_up": True,
                "answer_quality": build_answer_quality(
                    question=effective_message,
                    response=narrative,
                    intent=str(analysis_result.intent),
                    data_quality_pct=0,
                    readiness_level="fallback_engine",
                    company_data=request.company_data.model_dump(by_alias=True),
                    operational_data_by_sector=effective_operational_by_sector,
                    data_room=None,
                ),
            },
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Chat error: {str(e)}",
        )


def _try_controlled_chat_response(
    message: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]] = None,
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]] = None,
    tenant_id: Optional[str] = None,
    db: Optional[Session] = None,
) -> Optional[Dict[str, str]]:
    """Answer common CFO chat questions with deterministic, FAQ-aware logic."""
    text = (message or "").strip()
    lower = text.lower()
    intent_result = route_cfo_intent(text)
    is_definition_question = (
        intent_result.message_kind == MessageKind.DEFINITION_REQUEST
        or any(token in lower for token in ["cos'è", "cosa è", "che cos", "significa", "spiegami", "definisci"])
    )
    readiness = assess_data_completeness(
        sector=company_data.settore,
        provided_data=_build_provided_data(company_data, operational_data),
    )
    conversation_decision = decide_conversation_action(
        question=text,
        sector=company_data.settore,
        readiness=readiness,
        has_operational_data=bool(operational_data),
    )

    analysis = analyze_company(
        fatturato=company_data.fatturato,
        costi_variabili=company_data.costi_variabili,
        costi_fissi=company_data.costi_fissi,
        investimenti=company_data.investimenti or 0,
        settore=company_data.settore,
        company_name=company_data.company_name,
        dso_days=company_data.dso_days,
        dio_days=company_data.dio_days,
        dpo_days=company_data.dpo_days,
    )
    insight = build_cfo_insight_pack(analysis, settore=company_data.settore)
    kpi = analysis.kpi_snapshot
    war_room = build_cfo_war_room(analysis, insight, intent_result)

    receipt = _extract_revenue_amount(lower)
    if receipt is not None and any(token in lower for token in ["netto", "rimane", "resta", "utile"]):
        estimated_net = receipt * (kpi.net_margin_pct / 100)
        return {
            "intent": "net_revenue_estimate",
            "response": (
                f"📊 **IMPATTO**\nSu {format_eur(receipt)} incassati, con margine netto attuale "
                f"{kpi.net_margin_pct:.1f}% restano circa **{format_eur(estimated_net)}** di utile netto stimato.\n\n"
                "🧠 **ANALISI**\nÈ una stima proporzionale: assume che quei ricavi abbiano la stessa struttura costi media "
                "dell'azienda. Se l'incasso riguarda un prodotto/cliente con costi diversi, il netto cambia.\n\n"
                "🚀 **AZIONE**\nPer renderlo preciso servono: costi variabili associati a quell'incasso, eventuali commissioni, IVA/tasse e costi operativi diretti."
            ),
        }

    quick_answer = _quick_kpi_answer(text, analysis, insight, intent_result)
    if quick_answer is not None and not is_definition_question:
        return {
            "intent": intent_result.intent.value,
            "response": _format_human_quick_answer(quick_answer),
        }

    if intent_result.intent in {
        CFOIntent.GROWTH_STRATEGY,
        CFOIntent.WEAKNESS_DIAGNOSIS,
    } and (
        "migliorare le vendite" in lower
        or "migliorare vendite" in lower
        or "acquisire piu clienti" in lower
        or "acquisire più clienti" in lower
        or ("ristorante" in lower and "clienti" in lower)
        or "punti carenti" in lower
        or "dove posso migliorare" in lower
        or "dove migliorare" in lower
    ):
        strategic_answer = _strategic_chat_answer(text, analysis, insight, intent_result, war_room)
        if strategic_answer:
            return {
                "intent": intent_result.intent.value,
                "response": strategic_answer,
            }

    faq = _get_faq_context(text)
    if faq and (is_definition_question or (faq.get("score", 0) >= 90 and intent_result.intent == CFOIntent.UNKNOWN)):
        return {
            "intent": "faq",
            "response": (
                f"🧠 **ANALISI**\n{faq['answer'].strip()}\n\n"
                "🚀 **AZIONE**\nUsa questa definizione insieme ai KPI reali dell'azienda, non come numero isolato."
            ),
        }

    if conversation_decision.action == ConversationAction.WAR_ROOM:
        weekly_answer = _try_weekly_execution_answer(
            text,
            company_data,
            operational_data,
            operational_data_by_sector,
            intent_result,
        )
        if weekly_answer:
            return {
                "intent": "weekly_execution_plan",
                "response": weekly_answer,
            }

    if conversation_decision.action == ConversationAction.ASK_FOR_DATA:
        data_collection_confirmation = _try_data_collection_confirmation_answer(text, company_data)
        if data_collection_confirmation:
            return {
                "intent": "data_collection_confirmation",
                "response": data_collection_confirmation,
            }

        operating_model_answer = _try_operating_model_answer(
            text,
            company_data,
            operational_data,
            operational_data_by_sector,
            intent_result,
        )
        if operating_model_answer:
            return {
                "intent": "company_operating_model",
                "response": operating_model_answer,
            }

        data_room_answer = _try_data_room_chat_answer(
            text,
            company_data,
            operational_data,
            operational_data_by_sector,
        )
        if data_room_answer:
            return {
                "intent": "company_data_room",
                "response": data_room_answer,
            }

        data_gate = _data_gate_answer(text, intent_result, company_data.settore, readiness)
        if data_gate:
            return {
                "intent": f"{conversation_decision.action.value}_{intent_result.intent.value}",
                "response": _append_follow_up(data_gate, conversation_decision.next_best_prompt),
            }

    if conversation_decision.action == ConversationAction.RUN_SIMULATION:
        restaurant_simulation_answer = _try_restaurant_simulation_answer(text, company_data, operational_data)
        if restaurant_simulation_answer:
            return {
                "intent": "restaurant_simulation",
                "response": restaurant_simulation_answer,
            }

        ecommerce_simulation_answer = _try_ecommerce_simulation_answer(text, company_data, operational_data)
        if ecommerce_simulation_answer:
            return {
                "intent": "ecommerce_simulation",
                "response": ecommerce_simulation_answer,
            }

        construction_simulation_answer = _try_construction_simulation_answer(text, company_data, operational_data)
        if construction_simulation_answer:
            return {
                "intent": "construction_simulation",
                "response": construction_simulation_answer,
            }

    decision_memory_answer = _try_decision_memory_chat_answer(text, tenant_id, db)
    if decision_memory_answer:
        return {
            "intent": "decision_memory_summary",
            "response": decision_memory_answer,
        }

    data_room_history_answer = _try_data_room_history_chat_answer(text, company_data, tenant_id, db)
    if data_room_history_answer:
        return {
            "intent": "company_data_room_history",
            "response": data_room_history_answer,
        }

    memory_answer = _try_cfo_memory_answer(text, company_data, tenant_id, db)
    if memory_answer:
        return {
            "intent": "cfo_memory_summary",
            "response": memory_answer,
        }

    if _is_data_room_priority_question(lower):
        data_collection_confirmation = _try_data_collection_confirmation_answer(text, company_data)
        if data_collection_confirmation:
            return {
                "intent": "data_collection_confirmation",
                "response": data_collection_confirmation,
            }

        data_room_answer = _try_data_room_chat_answer(
            text,
            company_data,
            operational_data,
            operational_data_by_sector,
        )
        if data_room_answer:
            return {
                "intent": "company_data_room",
                "response": data_room_answer,
            }

    restaurant_answer = _try_restaurant_operational_answer(text, intent_result, company_data, operational_data)
    if restaurant_answer:
        return {
            "intent": f"restaurant_{intent_result.intent.value}",
            "response": restaurant_answer,
        }

    ecommerce_answer = _try_ecommerce_operational_answer(text, intent_result, company_data, operational_data)
    if ecommerce_answer:
        return {
            "intent": f"ecommerce_{intent_result.intent.value}",
            "response": ecommerce_answer,
        }

    construction_answer = _try_construction_operational_answer(text, intent_result, company_data, operational_data)
    if construction_answer:
        return {
            "intent": f"construction_{intent_result.intent.value}",
            "response": construction_answer,
        }

    playbook_answer = _try_decision_playbook_chat_answer(
        text,
        company_data,
        operational_data,
        operational_data_by_sector,
        intent_result,
    )
    if playbook_answer:
        return {
            "intent": f"{ConversationAction.DECISION_PLAYBOOK.value}_{intent_result.intent.value}",
            "response": _append_follow_up(playbook_answer, conversation_decision.next_best_prompt),
        }

    clarification_answer = _try_clarifying_answer(
        text,
        company_data,
        operational_data,
        operational_data_by_sector,
        intent_result,
    )
    if clarification_answer:
        return {
            "intent": "clarifying_questions",
            "response": clarification_answer,
        }

    if any(token in lower for token in ["scalare", "crescere", "crescita", "fatturato", "aumentare vendite", "far crescere"]):
        return {
            "intent": "controlled_growth_strategy",
            "response": (
                f"📊 **IMPATTO**\nStato: **{insight['health_label']}**. Vincolo principale: "
                f"**{insight['primary_constraint']['type']}**.\n\n"
                f"🧠 **ANALISI**\n{insight['primary_constraint']['summary']} "
                f"Margine lordo {kpi.gross_margin_pct:.1f}%, margine netto {kpi.net_margin_pct:.1f}%.\n\n"
                f"🚀 **AZIONE**\n{insight['next_best_move']['move']}\n\n"
                "Poi scala il fatturato solo sui canali/clienti con margine migliore. Prima proteggi il vincolo, poi acceleri."
            ),
        }

    if "roi" in lower and not is_definition_question:
        return {
            "intent": "kpi_roi",
            "response": (
                f"📊 **IMPATTO**\nROI attuale: **{kpi.roi_pct:.1f}%**.\n\n"
                f"🧠 **ANALISI**\nUtile netto {format_eur(kpi.net_profit_eur)} su investimenti "
                f"{format_eur(company_data.investimenti or 0)}. "
                f"Efficienza capitale: {insight['capital_efficiency']['status']}.\n\n"
                f"🚀 **AZIONE**\n{insight['next_best_move']['move']}"
            ),
        }

    return None


def _is_data_room_priority_question(lower: str) -> bool:
    priority_tokens = [
        "quale prodotto",
        "quali prodotti",
        "prodotto devo",
        "piatto devo",
        "quale canale",
        "quali canali",
        "canale marketing",
        "quale commessa",
        "quali commesse",
        "quale cantiere",
        "camere adr",
        "ota",
        "hotel",
        "piu margine",
        "più margine",
        "devo spingere",
        "mi blocca la cassa",
    ]
    return any(token in lower for token in priority_tokens)


def _build_chat_conversation_state(
    original_message: str,
    effective_message: str,
    intent: str,
    response: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
    operational_data_by_sector: Optional[Dict[str, Dict[str, Any]]],
) -> Dict[str, Any]:
    by_sector = dict(operational_data_by_sector or {})
    active_sector = company_data.settore or "default"
    if operational_data and active_sector not in by_sector:
        by_sector[active_sector] = operational_data

    readiness = assess_data_completeness(
        sector=active_sector,
        provided_data=_build_provided_data(company_data, operational_data),
    )
    conversation_decision = decide_conversation_action(
        question=effective_message,
        sector=active_sector,
        readiness=readiness,
        has_operational_data=bool(operational_data),
    )
    operating_model = build_company_operating_model(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
    )
    data_room = build_company_data_room(
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        active_sector=active_sector,
    )
    answer_quality = build_answer_quality(
        question=effective_message,
        response=response,
        intent=intent,
        data_quality_pct=operating_model["data_quality"]["score_pct"],
        readiness_level=readiness.readiness_level,
        company_data=company_data.model_dump(by_alias=True),
        operational_data_by_sector=by_sector,
        data_room=data_room,
    )

    return {
        "intent": intent,
        "message_kind": conversation_decision.intent_result.message_kind.value,
        "brain_action": conversation_decision.action.value,
        "brain_reason": conversation_decision.reason,
        "confidence": conversation_decision.confidence,
        "original_message": original_message,
        "resolved_message": effective_message,
        "was_follow_up": original_message.strip() != effective_message.strip(),
        "next_best_prompt": _extract_next_prompt(response) or conversation_decision.next_best_prompt,
        "suggested_action": _suggested_action_from_response(response, conversation_decision.action.value),
        "requires_follow_up": bool(_extract_next_prompt(response) or conversation_decision.next_best_prompt),
        "data_quality_pct": operating_model["data_quality"]["score_pct"],
        "readiness_level": readiness.readiness_level,
        "answer_quality": answer_quality,
    }


def _extract_next_prompt(response: str) -> str:
    if "Prossimo passo CFO:" not in response:
        return ""
    return response.split("Prossimo passo CFO:", 1)[1].strip().splitlines()[0].strip()


def _suggested_action_from_response(response: str, fallback: str) -> str:
    lower = (response or "").lower()
    if "simulazione consigliata" in lower or "vuoi che simuli" in lower:
        return "run_simulation"
    if "agenda cfo di questa settimana" in lower or "priorita" in lower:
        return "weekly_execution"
    if "mi mancano" in lower or "che dati" in lower:
        return "collect_data"
    if "piano 30 giorni" in lower:
        return "decision_playbook"
    return fallback


def _try_cfo_memory_answer(
    question: str,
    company_data: AnalyzeRequest,
    tenant_id: Optional[str],
    db: Optional[Session],
) -> Optional[str]:
    lower = (question or "").lower()
    if not any(
        phrase in lower
        for phrase in [
            "rispetto al mese scorso",
            "sto migliorando",
            "sto peggiorando",
            "storico",
            "trend",
            "memoria",
            "andamento",
            "mese scorso",
        ]
    ):
        return None
    if not tenant_id or db is None:
        return None

    company_id = company_data.company_name or "default"
    memory = build_cfo_memory_summary(
        session=db,
        tenant_id=tenant_id,
        company_id=company_id,
        months=12,
    )
    actions = "\n".join(f"- {action}" for action in memory.get("next_memory_actions", [])[:3])
    alerts = "\n".join(f"- {alert}" for alert in memory.get("alerts", [])[:3]) or "- Nessun alert storico critico."

    return (
        "Memoria CFO\n\n"
        f"Lettura: {memory.get('executive_memory')}\n\n"
        f"Trend: {memory.get('trend_summary')}\n\n"
        f"Momentum: {memory.get('momentum_label', 'n/d')} ({memory.get('momentum_score', 0)})\n\n"
        f"Alert:\n{alerts}\n\n"
        f"Prossime azioni:\n{actions}\n\n"
        "Prossimo passo CFO: aggiorna lo snapshot del mese corrente dopo ogni chiusura contabile."
    )


def _try_decision_memory_chat_answer(
    question: str,
    tenant_id: Optional[str],
    db: Optional[Session] = None,
) -> Optional[str]:
    lower = (question or "").lower()
    if not any(
        phrase in lower
        for phrase in [
            "decisioni aperte",
            "decisioni ancora aperte",
            "quali decisioni",
            "azione ha portato",
            "azioni hanno portato",
            "ha funzionato",
            "cosa ha funzionato",
            "decisione della settimana scorsa",
            "decisioni completate",
            "storico decisioni",
            "cosa dovevo fare",
            "cosa resta da fare",
            "decisioni stale",
            "decisioni vecchie",
            "cosa devo chiudere",
            "cosa archiviare",
        ]
    ):
        return None
    if not tenant_id:
        return None

    decisions = list_decision_memory(tenant_id, session=db)
    summary = build_decision_memory_summary(tenant_id, session=db)
    if not decisions:
        return (
            "Memoria decisioni CFO\n\n"
            "Non ho ancora decisioni salvate. Genera una War Room: da li' posso ricordare priorita', owner, KPI e risultati.\n\n"
            "Prossimo passo CFO: apri la War Room e salva le prime decisioni operative."
        )

    open_decisions = [item for item in decisions if item.get("status") == "todo"]
    completed = [item for item in decisions if item.get("status") == "done"]
    archived = [item for item in decisions if item.get("status") == "archived"]
    stale = [item for item in open_decisions if item.get("is_stale")]
    best = summary.get("best_decision")

    open_lines = "\n".join(
        f"- {item['decision_id']}: {item.get('next_action') or item.get('decision')}"
        f"{' (da chiudere o archiviare)' if item.get('is_stale') else ''}"
        for item in open_decisions[:3]
    ) or "- Nessuna decisione aperta."

    completed_lines = "\n".join(
        f"- {item['decision_id']}: impatto EUR {float(item.get('actual_impact_eur') or 0):,.0f}, "
        f"esito {(item.get('outcome_review') or {}).get('status', 'misurato')}"
        for item in completed[:3]
    ) or "- Nessuna decisione completata."

    best_line = (
        f"La migliore finora e' {best['decision_id']} con impatto EUR {float(best.get('actual_impact_eur') or 0):,.0f}."
        if best
        else "Non ho ancora una decisione vincente da replicare."
    )
    cleanup_line = (
        f"Prima pulizia memoria: hai {len(stale)} decisione/i vecchie da chiudere, aggiornare o archiviare."
        if stale
        else "Memoria operativa pulita: nessuna decisione vecchia critica."
    )

    return (
        "Memoria decisioni CFO\n\n"
        f"Quadro: {summary['total_decisions']} decisioni totali, {summary['open_decisions']} aperte, "
        f"{summary['completed_decisions']} completate, {len(archived)} archiviate. "
        f"Impatto reale registrato: EUR {summary['actual_impact_eur']:,.0f}.\n\n"
        f"Decisioni aperte:\n{open_lines}\n\n"
        f"Decisioni completate:\n{completed_lines}\n\n"
        f"Lettura CFO: {best_line}\n"
        f"{cleanup_line}\n"
        f"Prossima review: {summary['next_review']}\n\n"
        "Prossimo passo CFO: completa una decisione aperta oppure archiviala se non e' piu' rilevante; poi aggiorno la priorita' successiva."
    )


def _resolve_short_follow_up(message: str, chat_history: List[ChatMessage]) -> str:
    """Expand short confirmations using the last assistant follow-up."""
    text = (message or "").strip()
    normalized = text.lower().replace("ì", "i")
    short_confirmations = {
        "si",
        "sì",
        "ok",
        "vai",
        "procedi",
        "fallo",
        "ok fallo",
        "simula",
        "facciamolo",
        "certo",
    }
    if normalized not in short_confirmations:
        return text

    last_assistant = next(
        (item.content for item in reversed(chat_history or []) if item.role == "assistant" and item.content),
        "",
    )
    lower = last_assistant.lower()

    if "simulazione consigliata:" in lower or "vuoi che simuli" in lower:
        simulation = _extract_after_marker(last_assistant, "Simulazione consigliata:")
        return f"simula {simulation}" if simulation else "simula lo scenario consigliato"

    if "tagli sicuri" in lower or "costi da rinegoziare" in lower:
        return "separa tagli sicuri, tagli rischiosi e costi da rinegoziare"

    if "priorita' settimanali" in lower or "priorità settimanali" in lower:
        return "trasforma questo piano in priorita settimanali con owner e KPI"

    if "quali dati" in lower or "mi servono" in lower or "mi serve" in lower:
        return "dimmi quali dati devo inserire per rispondere con precisione"

    if "piano 30 giorni" in lower:
        return "trasforma questo piano in azioni operative settimanali"

    return text


def _extract_after_marker(text: str, marker: str) -> str:
    if marker not in text:
        return ""
    after = text.split(marker, 1)[1].strip()
    return after.splitlines()[0].strip()


def _try_construction_simulation_answer(
    message: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"construction", "costruzioni", "edilizia"}:
        return None
    if not operational_data:
        return None

    scenario = _parse_construction_scenario(message)
    if not scenario:
        return None

    construction_data = _build_provided_data(company_data, operational_data)
    simulation = simulate_construction(construction_data, scenario)
    delta = simulation["delta"]
    base = simulation["base"]["summary"]
    simulated = simulation["simulated"]["summary"]

    return (
        f"Simulazione Construction CFO: {simulation['scenario_name']}.\n\n"
        f"Base: utile dopo overhead {_format_eur(base['net_profit_after_overhead_eur'])}, "
        f"margine atteso {base['expected_margin_pct']:.1f}%, cash gap {_format_eur(base['cash_gap_eur'])}, "
        f"WIP non fatturato {_format_eur(base['wip_unbilled_eur'])}.\n\n"
        f"Scenario: utile dopo overhead {_format_eur(simulated['net_profit_after_overhead_eur'])}, "
        f"margine atteso {simulated['expected_margin_pct']:.1f}%, cash gap {_format_eur(simulated['cash_gap_eur'])}, "
        f"WIP non fatturato {_format_eur(simulated['wip_unbilled_eur'])}.\n\n"
        f"Impatto:\n"
        f"- Delta utile dopo overhead: {_format_eur(delta['net_profit_after_overhead_eur'])}\n"
        f"- Delta margine atteso: {delta['expected_margin_pct']:.1f} punti\n"
        f"- Delta cash gap: {_format_eur(delta['cash_gap_eur'])}\n"
        f"- Delta WIP non fatturato: {_format_eur(delta['wip_unbilled_eur'])}\n\n"
        f"Decisione CFO: {simulation['decision']}"
    )


def _try_construction_operational_answer(
    message: str,
    intent_result: IntentResult,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"construction", "costruzioni", "edilizia"}:
        return None
    if not operational_data:
        return None
    words = intent_result.normalized_words
    if not ({"commessa", "commesse", "cantiere", "cantieri", "sal", "cassa", "cash", "margine"} & words):
        return None

    construction_data = _build_provided_data(company_data, operational_data)
    analysis = analyze_construction(construction_data)
    summary = analysis["summary"]
    cash_risk = analysis["projects_by_cash_risk"][:3]
    to_fix = analysis["projects_to_fix"][:3]

    risk_lines = "\n".join(
        f"{idx}. {project['project']}: cash gap {_format_eur(project['cash_gap_eur'])}, "
        f"WIP {_format_eur(project['wip_unbilled_eur'])}, decisione {project['decision']}"
        for idx, project in enumerate(cash_risk, start=1)
    ) or "Nessuna commessa con rischio cassa evidente."
    fix_lines = "\n".join(
        f"- {project['project']}: margine {project['expected_margin_pct']:.1f}%, rischio ritardo {_format_eur(project['delay_risk_eur'])}, {project['decision']}"
        for project in to_fix
    ) or "- Nessuna commessa critica evidente."
    rec_lines = "\n".join(f"- {rec}" for rec in analysis["recommendations"][:4])

    return (
        "Analisi construction sui dati operativi inseriti.\n\n"
        f"Numero chiave: margine atteso {summary['expected_margin_pct']:.1f}%, "
        f"cash gap {_format_eur(summary['cash_gap_eur'])}, WIP non fatturato {_format_eur(summary['wip_unbilled_eur'])}.\n\n"
        f"Commesse con rischio cassa:\n{risk_lines}\n\n"
        f"Commesse da correggere:\n{fix_lines}\n\n"
        f"Decisione CFO:\n{rec_lines}"
    )


def _parse_construction_scenario(message: str) -> Optional[Dict[str, Any]]:
    lower = (message or "").lower()
    if not any(token in lower for token in ["simula", "scenario", "se ", "cosa succede", "aumento", "riduco", "ritardo", "incasso", "sal"]):
        return None

    scenario = {"name": "Scenario construction da chat"}
    mappings = [
        ("materials_cost_delta_pct", ["materiali", "materie prime"]),
        ("labor_cost_delta_pct", ["manodopera", "lavoro", "personale"]),
        ("subcontractor_cost_delta_pct", ["subappalti", "subappalto"]),
        ("billed_delta_pct", ["sal", "fatturato", "fatturazione"]),
        ("collected_delta_pct", ["incasso", "incassi", "collected", "pagamento"]),
        ("fixed_cost_delta_pct", ["costi fissi", "struttura"]),
    ]
    for field, keywords in mappings:
        value = _extract_pct_near_keywords(lower, keywords)
        if value is not None:
            scenario[field] = value

    delay = _extract_number_near_keywords(lower, ["ritardo", "ritardi", "settimane"])
    if delay is not None:
        scenario["delay_weeks_delta"] = delay

    change_order = _extract_amount_near_keywords(lower, ["variante", "varianti", "extra"])
    if change_order is not None:
        scenario["change_orders_approved_delta"] = change_order

    return scenario if len(scenario) > 1 else None


def _extract_number_near_keywords(text: str, keywords: List[str]) -> Optional[float]:
    for keyword in keywords:
        match = re.search(rf"{re.escape(keyword)}[^\d+\-]{{0,30}}([+\-]?\d+(?:[.,]\d+)?)", text)
        if match:
            return float(match.group(1).replace(",", "."))
    return None


def _extract_amount_near_keywords(text: str, keywords: List[str]) -> Optional[float]:
    value = _extract_number_near_keywords(text, keywords)
    if value is None:
        return None
    if "k" in text or "mila" in text:
        return value * 1000
    return value


def _try_ecommerce_simulation_answer(
    message: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"ecommerce", "e-commerce", "online_store"}:
        return None
    if not operational_data:
        return None

    scenario = _parse_ecommerce_scenario(message)
    if not scenario:
        return None

    ecommerce_data = _build_provided_data(company_data, operational_data)
    simulation = simulate_ecommerce(ecommerce_data, scenario)
    delta = simulation["delta"]
    base = simulation["base"]["summary"]
    simulated = simulation["simulated"]["summary"]

    return (
        f"Simulazione Ecommerce CFO: {simulation['scenario_name']}.\n\n"
        f"Base: utile {_format_eur(base['net_profit_eur'])}, margine netto {base['net_margin_pct']:.1f}%, "
        f"break-even CAC {_format_eur(base['break_even_cac_eur'])}, ROAS {base['roas']:.1f}.\n\n"
        f"Scenario: utile {_format_eur(simulated['net_profit_eur'])}, margine netto {simulated['net_margin_pct']:.1f}%, "
        f"break-even CAC {_format_eur(simulated['break_even_cac_eur'])}, ROAS {simulated['roas']:.1f}.\n\n"
        f"Impatto:\n"
        f"- Delta ricavi annui: {_format_eur(delta['annual_revenue_eur'])}\n"
        f"- Delta utile annuo: {_format_eur(delta['net_profit_eur'])}\n"
        f"- Delta margine netto: {delta['net_margin_pct']:.1f} punti\n"
        f"- Delta break-even CAC: {_format_eur(delta['break_even_cac_eur'])}\n"
        f"- Delta ROAS: {delta['roas']:.1f}\n\n"
        f"Decisione CFO: {simulation['decision']}"
    )


def _try_ecommerce_operational_answer(
    message: str,
    intent_result: IntentResult,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"ecommerce", "e-commerce", "online_store"}:
        return None
    if not operational_data:
        return None
    words = intent_result.normalized_words
    if not ({"sku", "prodotti", "prodotto", "cac", "roas", "margine", "spingere"} & words):
        return None

    ecommerce_data = _build_provided_data(company_data, operational_data)
    analysis = analyze_ecommerce(ecommerce_data)
    summary = analysis["summary"]
    top_skus = analysis["top_skus_by_profit"][:3]
    to_fix = analysis["skus_to_fix"][:3]

    top_lines = "\n".join(
        f"{idx}. {sku['sku']}: contributo/mese {_format_eur(sku['monthly_contribution_eur'])}, "
        f"margine {sku['contribution_margin_pct']:.1f}%, decisione {sku['decision']}"
        for idx, sku in enumerate(top_skus, start=1)
    ) or "Nessuno SKU calcolabile con i dati attuali."
    fix_lines = "\n".join(
        f"- {sku['sku']}: margine {sku['contribution_margin_pct']:.1f}%, contributo/unità {_format_eur(sku['contribution_per_unit_eur'])}, {sku['decision']}"
        for sku in to_fix
    ) or "- Nessuno SKU critico evidente."
    rec_lines = "\n".join(f"- {rec}" for rec in analysis["recommendations"][:4])

    return (
        "Analisi ecommerce sui dati operativi inseriti.\n\n"
        f"Numero chiave: margine contributivo {summary['contribution_margin_pct']:.1f}%, "
        f"break-even CAC {_format_eur(summary['break_even_cac_eur'])}, ROAS {summary['roas']:.1f}.\n\n"
        f"SKU migliori per utile:\n{top_lines}\n\n"
        f"SKU da correggere:\n{fix_lines}\n\n"
        f"Decisione CFO:\n{rec_lines}"
    )


def _parse_ecommerce_scenario(message: str) -> Optional[Dict[str, Any]]:
    lower = (message or "").lower()
    if not any(token in lower for token in ["simula", "scenario", "se ", "cosa succede", "aumento", "aumentassi", "riduco", "ridurre", "abbasso"]):
        return None

    scenario = {"name": "Scenario ecommerce da chat"}
    mappings = [
        ("price_delta_pct", ["prezzo", "prezzi", "aov", "ticket"]),
        ("volume_delta_pct", ["ordini", "volume", "vendite", "conversione", "conversion"]),
        ("purchase_cost_delta_pct", ["costo prodotto", "costi prodotto", "fornitore", "fornitori", "acquisto"]),
        ("shipping_cost_delta_pct", ["spedizione", "spedizioni", "shipping"]),
        ("return_rate_delta_pct", ["resi", "reso", "return"]),
        ("ad_spend_delta_pct", ["ads", "advertising", "budget", "spesa marketing"]),
        ("cac_delta_pct", ["cac", "acquisizione"]),
    ]
    for field, keywords in mappings:
        value = _extract_pct_near_keywords(lower, keywords)
        if value is not None:
            scenario[field] = value
    return scenario if len(scenario) > 1 else None


def _try_restaurant_simulation_answer(
    message: str,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"restaurant", "ristorante", "ristoranti"}:
        return None
    if not operational_data:
        return None

    scenario = _parse_restaurant_scenario(message)
    if not scenario:
        return None

    restaurant_data = _build_provided_data(company_data, operational_data)
    simulation = simulate_restaurant(restaurant_data, scenario)
    delta = simulation["delta"]
    simulated = simulation["simulated"]["summary"]
    base = simulation["base"]["summary"]

    return (
        f"Simulazione CFO: {simulation['scenario_name']}.\n\n"
        f"Base: utile {_format_eur(base['net_profit_eur'])}, margine netto {base['net_margin_pct']:.1f}%, "
        f"prime cost {base['prime_cost_pct']:.1f}%.\n\n"
        f"Scenario: utile {_format_eur(simulated['net_profit_eur'])}, margine netto {simulated['net_margin_pct']:.1f}%, "
        f"prime cost {simulated['prime_cost_pct']:.1f}%.\n\n"
        f"Impatto:\n"
        f"- Delta ricavi annui: {_format_eur(delta['annual_revenue_eur'])}\n"
        f"- Delta utile annuo: {_format_eur(delta['net_profit_eur'])}\n"
        f"- Delta margine netto: {delta['net_margin_pct']:.1f} punti\n"
        f"- Delta prime cost: {delta['prime_cost_pct']:.1f} punti\n"
        f"- Delta break-even: {delta['break_even_covers_per_day']:.1f} coperti/giorno\n\n"
        f"Decisione CFO: {simulation['decision']}"
    )


def _parse_restaurant_scenario(message: str) -> Optional[Dict[str, Any]]:
    lower = (message or "").lower()
    if not any(token in lower for token in ["simula", "scenario", "se ", "cosa succede", "aumento", "aumentassi", "riduco", "ridurre", "abbasso"]):
        return None

    scenario = {"name": "Scenario da chat"}
    mappings = [
        ("price_delta_pct", ["prezzo", "prezzi", "scontrino", "ticket"]),
        ("covers_delta_pct", ["coperti", "clienti", "volume", "vendite"]),
        ("ingredient_cost_delta_pct", ["ingredienti", "materie prime", "merce", "food cost", "costo ingredienti"]),
        ("staff_cost_delta_pct", ["personale", "stipendi", "staff", "lavoro"]),
        ("fixed_cost_delta_pct", ["costi fissi", "affitto", "struttura"]),
        ("waste_delta_pct", ["spreco", "sprechi", "scarto", "scarti"]),
    ]

    for field, keywords in mappings:
        value = _extract_pct_near_keywords(lower, keywords)
        if value is not None:
            scenario[field] = value

    return scenario if len(scenario) > 1 else None


def _extract_pct_near_keywords(text: str, keywords: List[str]) -> Optional[float]:
    for keyword in keywords:
        pattern_after = rf"{re.escape(keyword)}[^\d+\-]{{0,30}}([+\-]?\d+(?:[.,]\d+)?)\s*%?"
        match = re.search(pattern_after, text)
        if match:
            return _signed_scenario_value(text, match, keyword)

        pattern_before = rf"([+\-]?\d+(?:[.,]\d+)?)\s*%?[^\w]{{0,20}}{re.escape(keyword)}"
        match = re.search(pattern_before, text)
        if match:
            return _signed_scenario_value(text, match, keyword)
    return None


def _signed_scenario_value(text: str, match, keyword: str) -> float:
    value = float(match.group(1).replace(",", "."))
    window_start = max(0, match.start() - 30)
    window_end = min(len(text), match.end() + 30)
    window = text[window_start:window_end]
    negative_words = ["riduco", "riduci", "ridurre", "abbasso", "abbassare", "taglio", "meno", "calo"]
    positive_words = ["aumento", "aumentare", "aumentassi", "piu", "più", "cresco", "crescere"]

    if match.group(1).startswith(("+", "-")):
        return value
    if keyword in {"spreco", "sprechi", "scarto", "scarti"} and any(word in window for word in negative_words):
        return -abs(value)
    if any(word in window for word in negative_words):
        return -abs(value)
    if any(word in window for word in positive_words):
        return abs(value)
    return value


def _try_restaurant_operational_answer(
    message: str,
    intent_result: IntentResult,
    company_data: AnalyzeRequest,
    operational_data: Optional[Dict[str, Any]],
) -> Optional[str]:
    if (company_data.settore or "").lower() not in {"restaurant", "ristorante", "ristoranti"}:
        return None
    if not operational_data:
        return None
    if intent_result.intent != CFOIntent.PRODUCT_MARGIN and not ({"piatti", "piatto", "menu", "prezzo"} & intent_result.normalized_words):
        return None

    restaurant_data = _build_provided_data(company_data, operational_data)
    analysis = analyze_restaurant(restaurant_data)
    summary = analysis["summary"]
    top_profit = analysis["top_dishes_by_profit"][:3]
    to_fix = analysis["dishes_to_fix"][:3]

    top_lines = "\n".join(
        f"{idx}. {dish['name']}: utile/mese {_format_eur(dish['monthly_profit_eur'])}, "
        f"margine {dish['gross_margin_pct']:.1f}%, food cost {dish['food_cost_pct']:.1f}%"
        for idx, dish in enumerate(top_profit, start=1)
    ) or "Nessun piatto calcolabile con i dati attuali."
    fix_lines = "\n".join(
        f"- {dish['name']}: prezzo {_format_eur(dish['price_eur'])}, "
        f"prezzo target {_format_eur(dish['recommended_price_for_target_margin_eur'])}, decisione {dish['decision']}"
        for dish in to_fix
    ) or "- Nessun piatto critico evidente."
    rec_lines = "\n".join(f"- {rec}" for rec in analysis["recommendations"][:4])

    return (
        "Analisi ristorante sui dati operativi inseriti.\n\n"
        f"Numero chiave: food cost {summary['food_cost_pct']:.1f}%, labour cost {summary['labour_cost_pct']:.1f}%, "
        f"prime cost {summary['prime_cost_pct']:.1f}%.\n"
        f"Break-even stimato: {summary['break_even_covers_per_day']:.1f} coperti/giorno.\n\n"
        f"Piatti migliori per utile:\n{top_lines}\n\n"
        f"Piatti da correggere:\n{fix_lines}\n\n"
        f"Decisione CFO:\n{rec_lines}"
    )


def _extract_revenue_amount(text: str) -> Optional[float]:
    match = re.search(r"(\d+(?:[.,]\d+)?)\s*(k|m|mila|milioni)?", text)
    if not match:
        return None
    value = float(match.group(1).replace(",", "."))
    suffix = match.group(2)
    if suffix in {"k", "mila"}:
        value *= 1000
    elif suffix in {"m", "milioni"}:
        value *= 1_000_000
    return value


def format_eur(value: float) -> str:
    return f"€{value:,.0f}".replace(",", ".")


# ============================================
# HELPER FUNCTIONS
# ============================================

# Old template-based helper functions removed.
# The new CFO Chatbot Engine handles all response generation.
# See: nlp/cfo_chatbot.py for implementation details.
