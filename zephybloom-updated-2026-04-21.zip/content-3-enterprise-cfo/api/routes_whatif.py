# -*- coding: utf-8 -*-
# content/api/routes_whatif.py
from __future__ import annotations
from fastapi import APIRouter
from api.schemas import BreakevenRequest, BreakevenResponse, WCImpactRequest, WCImpactResponse
from core.whatif import whatif_breakeven, whatif_wc_impact
from utils.errors import CalculationAppError, from_exception

router = APIRouter()

@router.post("/whatif/breakeven", response_model=BreakevenResponse)
def whatif_breakeven_route(req: BreakevenRequest):
    try:
        data = whatif_breakeven(req.base)
        return BreakevenResponse(**data)
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nel calcolo breakeven (quantità/ricavi)",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "whatif_breakeven",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during breakeven analysis")

@router.post("/whatif/wc_impact", response_model=WCImpactResponse)
def whatif_wc_impact_route(req: WCImpactRequest):
    try:
        data = whatif_wc_impact(req.base)
        return WCImpactResponse(**data)
    except (ValueError, ZeroDivisionError, ArithmeticError) as e:
        raise CalculationAppError(
            "Errore nel calcolo working capital impact",
            details={
                "error_type": type(e).__name__,
                "message": str(e),
                "endpoint": "whatif_wc_impact",
            },
            cause=e,
        )
    except Exception as e:
        raise from_exception(e, message="Unexpected error during working capital analysis")
