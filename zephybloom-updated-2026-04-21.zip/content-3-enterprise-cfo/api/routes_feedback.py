"""
Decision Feedback API Routes

Allows companies to provide feedback on decisions:
- Was this decision implemented?
- What was the actual impact?
- What did we learn?

POST /cfo/decision/{decision_id}/feedback
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import Optional
from pydantic import BaseModel, Field
from datetime import datetime
import logging

from api.tenant_context import require_auth, TenantContext
from core.decision_memory import update_decision_outcome
from core.learning_engine import get_learning_engine
from db.models import Decision, DecisionAccuracy
from db.session import get_session
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/cfo",
    tags=["cfo-feedback"],
)


class DecisionFeedbackRequest(BaseModel):
    """Feedback on a decision that was made"""
    was_implemented: bool = Field(
        ...,
        description="Was this decision actually implemented?"
    )
    implementation_date: Optional[str] = Field(
        None,
        description="When was it implemented? (ISO format, optional)"
    )
    actual_impact_eur: Optional[float] = Field(
        None,
        description="What was the actual financial impact in EUR? (positive or negative)"
    )
    expected_impact_eur: Optional[float] = Field(
        None,
        description="Expected financial impact in EUR, if available from the decision tracker"
    )
    decision_type: Optional[str] = Field(
        None,
        description="Decision type, e.g. cash_recovery, margin_recovery, paid_growth_blocker"
    )
    sector: Optional[str] = Field(
        None,
        description="Sector connected to the decision, e.g. restaurant, ecommerce, construction"
    )
    lessons_learned: Optional[str] = Field(
        None,
        description="What did we learn from this decision?"
    )
    mistakes: Optional[str] = Field(
        None,
        description="What went wrong? What would we do differently?"
    )
    success_factors: Optional[str] = Field(
        None,
        description="What factors led to success?"
    )


class DecisionFeedbackResponse(BaseModel):
    """Response after feedback is recorded"""
    status: str = "success"
    decision_id: str
    message: str
    accuracy_report: Optional[dict] = None


@router.post(
    "/decision/{decision_id}/feedback",
    response_model=DecisionFeedbackResponse,
    summary="Provide Feedback on a Decision",
    description="Record what actually happened with a recommended decision (implementation status, actual impact, lessons)",
)
async def submit_decision_feedback(
    decision_id: str,
    feedback: DecisionFeedbackRequest,
    tenant: TenantContext = Depends(require_auth),
    db: Session = Depends(get_session),
) -> DecisionFeedbackResponse:
    """
    Record feedback on a strategic decision.
    
    This is crucial for the learning system to improve future recommendations.
    
    **What to provide:**
    - Was the decision implemented? (YES/NO)
    - If yes, what was the actual impact vs expected?
    - What did you learn? What would you do differently?
    
    **Why it matters:**
    - Helps us understand accuracy of our recommendations
    - Identifies patterns (what types of decisions work best for your company)
    - Improves future recommendations through machine learning
    
    ***Example:**
    ```
    POST /cfo/decision/decision_20260415_acme_001/feedback
    {
        "was_implemented": true,
        "implementation_date": "2026-04-10",
        "actual_impact_eur": 42000,
        "lessons_learned": "Pricing change went smoother than expected",
        "mistakes": "Should have notified customers 2 weeks earlier"
    }
    ```
    """
    
    try:
        # TODO: In production, fetch from DB and update
        # For now, simulate the flow
        
        logger.info(f"[FEEDBACK] Recording feedback for decision {decision_id}")
        
        if feedback.was_implemented and feedback.actual_impact_eur is None:
            raise ValueError("Must provide actual_impact_eur when the decision was implemented")
        
        # Record in learning engine
        learning_engine = get_learning_engine()
        
        decision_context = _decision_context_from_feedback(decision_id, feedback)
        expected_impact = feedback.expected_impact_eur if feedback.expected_impact_eur is not None else _default_expected_impact(decision_context["decision_type"])
        actual_impact = feedback.actual_impact_eur if feedback.actual_impact_eur is not None else 0

        if feedback.was_implemented:
            learning_engine.record_decision_outcome(
                decision_type=decision_context["decision_type"],
                expected_impact_eur=expected_impact,
                actual_impact_eur=actual_impact,
            )
        learning_engine.state.decisions_analyzed += 1
        learning_engine.state.overall_implementation_rate = _estimate_implementation_rate(
            current=learning_engine.state.overall_implementation_rate,
            total=learning_engine.state.decisions_analyzed,
            was_implemented=feedback.was_implemented,
        )
        
        logger.info(f"[FEEDBACK] Recorded outcome: expected {expected_impact}, actual {actual_impact}")
        outcome_review = _build_outcome_review(
            decision_context=decision_context,
            expected_impact=expected_impact,
            actual_impact=actual_impact,
            was_implemented=feedback.was_implemented,
        )
        memory_record = update_decision_outcome(
            tenant_id=tenant.tenant_id,
            decision_id=decision_id,
            was_implemented=feedback.was_implemented,
            actual_impact_eur=actual_impact,
            expected_impact_eur=expected_impact,
            outcome_review=outcome_review,
            decision_context=decision_context,
            session=db,
        )
        
        # Generate accuracy report
        summary = learning_engine.get_learning_summary()
        
        return DecisionFeedbackResponse(
            status="success",
            decision_id=decision_id,
            message=f"Feedback recorded. Actual impact: €{actual_impact:,.0f}",
            accuracy_report={
                "learning_summary": summary,
                "decision_context": decision_context,
                "expected_impact_eur": expected_impact,
                "actual_impact_eur": actual_impact,
                "was_implemented": feedback.was_implemented,
                "outcome_review": outcome_review,
                "memory_record": memory_record,
                "adjustment_factor": learning_engine.get_adjustment_factor(decision_context["decision_type"]),
            }
        )
    
    except ValueError as e:
        logger.error(f"[FEEDBACK] Validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    
    except Exception as e:
        logger.error(f"[FEEDBACK] Failed to record feedback: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to record decision feedback"
        )


def _decision_context_from_feedback(decision_id: str, feedback: DecisionFeedbackRequest) -> dict:
    parts = (decision_id or "").split("-")
    inferred_sector = feedback.sector
    inferred_type = feedback.decision_type
    if decision_id.startswith("wr-") and len(parts) >= 4:
        inferred_sector = inferred_sector or parts[2]
        inferred_type = inferred_type or "-".join(parts[3:])

    return {
        "decision_id": decision_id,
        "sector": inferred_sector or "general",
        "decision_type": inferred_type or "general_decision",
        "source": "war_room" if decision_id.startswith("wr-") else "decision_system",
    }


def _default_expected_impact(decision_type: str) -> float:
    defaults = {
        "cashrecovery": 25000,
        "cash-recovery": 25000,
        "marginrecovery": 18000,
        "margin-recovery": 18000,
        "paidgrowthblocker": 15000,
        "paid-growth-blocker": 15000,
        "profitablegrowth": 20000,
        "profitable-growth": 20000,
        "datablocker": 0,
        "data-blocker": 0,
    }
    return float(defaults.get((decision_type or "").lower(), 10000))


def _estimate_implementation_rate(current: float, total: int, was_implemented: bool) -> float:
    if total <= 1:
        return 1.0 if was_implemented else 0.0
    previous_total = total - 1
    previous_implemented = current * previous_total
    return (previous_implemented + (1 if was_implemented else 0)) / total


def _build_outcome_review(
    decision_context: dict,
    expected_impact: float,
    actual_impact: float,
    was_implemented: bool,
) -> dict:
    if not was_implemented:
        return {
            "status": "not_implemented",
            "verdict": "Decisione non eseguita.",
            "variance_pct": None,
            "cfo_read": "Non posso giudicare l'efficacia economica senza esecuzione.",
            "next_action": "Decidi se eliminare, rimandare o rieseguire questa priorita' nella prossima War Room.",
        }

    if expected_impact == 0:
        variance_pct = None
        status = "measured"
        cfo_read = "Impatto registrato, ma senza target economico iniziale il confronto resta qualitativo."
    else:
        variance_pct = round(((actual_impact - expected_impact) / abs(expected_impact)) * 100, 1)
        if actual_impact >= expected_impact:
            status = "above_target"
            cfo_read = "Risultato sopra target: decisione da replicare su casi simili, controllando che non crei effetti collaterali su margine o cassa."
        elif actual_impact >= expected_impact * 0.8:
            status = "near_target"
            cfo_read = "Risultato buono ma sotto target: la direzione e' corretta, serve capire cosa ha limitato l'impatto."
        elif actual_impact > 0:
            status = "below_target"
            cfo_read = "Risultato positivo ma debole: prima di ripetere, correggi causa, owner, timing o qualita' dati."
        else:
            status = "negative"
            cfo_read = "Risultato negativo: blocca replica della decisione e fai post-mortem prima della prossima War Room."

    return {
        "status": status,
        "verdict": f"{decision_context['sector']} / {decision_context['decision_type']}",
        "variance_pct": variance_pct,
        "cfo_read": cfo_read,
        "next_action": _outcome_next_action(status, decision_context),
    }


def _outcome_next_action(status: str, decision_context: dict) -> str:
    if status == "above_target":
        return "Replica la decisione su un segmento simile e alza leggermente il target della prossima settimana."
    if status == "near_target":
        return "Ripeti la decisione, ma correggi il fattore che ha creato lo scostamento dal target."
    if status == "below_target":
        return "Rilancia la War Room e confronta questa azione con una alternativa a maggiore impatto."
    if status == "negative":
        return "Metti la decisione in stop e raccogli evidenze prima di riprovarla."
    return f"Aggiorna i dati {decision_context['sector']} e rivaluta la priorita'."


@router.get(
    "/decisions/accuracy",
    summary="Get Decision Accuracy Metrics",
    description="View how accurate our recommendations have been",
)
async def get_accuracy_metrics(
    tenant: TenantContext = Depends(require_auth),
    period_days: int = 30,
) -> dict:
    """
    Get accuracy metrics for your tenant.
    
    Shows:
    - Implementation rate (% of recommendations actually done)
    - Accuracy rate (% of implemented decisions that hit target)
    - Variance from target (how far off we were on average)
    - Success/failure patterns (what types of decisions work best)
    
    **Example response:**
    ```json
    {
        "total_decisions": 15,
        "decisions_with_feedback": 12,
        "implementation_rate": 0.80,
        "accuracy_rate": 0.75,
        "average_variance_pct": 12.5,
        "success_patterns": ["Pricing", "Cost Reduction"],
        "failure_patterns": ["Hiring"],
        "is_healthy": true
    }
    ```
    """
    
    try:
        learning_engine = get_learning_engine()
        summary = learning_engine.get_learning_summary()
        
        return {
            "status": "success",
            "period_days": period_days,
            "learning_summary": summary,
            "overall_accuracy": learning_engine.state.overall_accuracy_rate,
            "overall_implementation": learning_engine.state.overall_implementation_rate,
        }
    
    except Exception as e:
        logger.error(f"[ACCURACY] Failed to get metrics: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve accuracy metrics"
        )


@router.get(
    "/decisions/recent",
    summary="Get Recent Decisions Tracking",
    description="View recent decisions and their implementation status",
)
async def get_recent_decisions(
    tenant: TenantContext = Depends(require_auth),
    limit: int = 10,
) -> dict:
    """
    Get recent decisions made for your company.
    
    Shows which decisions were made, whether they were implemented,
    and their actual impact.
    
    **Example:**
    ```json
    {
        "decisions": [
            {
                "decision_id": "decision_20260415_acme_001",
                "title": "Increase Gross Margin",
                "verdict": "GO",
                "expected_impact_eur": 50000,
                "was_implemented": true,
                "actual_impact_eur": 42000,
                "variance_pct": -16
            }
        ]
    }
    ```
    """
    
    try:
        # TODO: In production, query Decision table
        # For now, return empty
        return {
            "status": "success",
            "decisions": [],
            "total_pending_feedback": 0,
        }
    
    except Exception as e:
        logger.error(f"[DECISIONS] Failed to get recent: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve recent decisions"
        )
