# Day 2-3 Daily Stand Template

**Phase:** Send Invites & Onboarding Scheduling  
**Dates:** April 17-18, 2026 (Thursday-Friday)  
**Owner:** [Your Name]

---

## Day 2 Morning Stand

**Time:** 9:00 AM  
**Duration:** 5 minutes

### Overnight Summary

```
Email checking (Done: [ ] / Pending: [ ])

Responses received:
□ Name: ________ Status: [Interested/Declined/Question]
□ Name: ________ Status: [Interested/Declined/Question]
□ Name: ________ Status: [Interested/Declined/Question]

Actions taken:
□ Replied to interested parties
□ Sent calendar links
□ Logged responses in CSV

Current pipeline:
Total Day 1 contacts: ____
Responses Day 2 morning: ____
Interested so far: ____
```

---

## Day 2 Execution Log

### Phase 1: Follow-up Wave (10:00 AM)

**Goal:** Contact 8-10 non-responders from Day 1

```
LinkedIn follow-up messages sent:
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________

Time spent: ____ minutes
Quality check (personalized): ☐ Yes ☐ Partial
```

---

### Phase 2: Warm Referral Calls (11:00 AM)

**Goal:** Call 3-5 referral sources from Day 1

```
Call #1:
Name: ________________
Company/Role: ________________
Result: ☐ Interested ☐ No ☐ Will pass along
Time: ____ minutes
Any intros given? ☐ Yes ☐ No

Call #2:
Name: ________________
Company/Role: ________________
Result: ☐ Interested ☐ No ☐ Will pass along
Time: ____ minutes
Any intros given? ☐ Yes ☐ No

Call #3:
Name: ________________
Company/Role: ________________
Result: ☐ Interested ☐ No ☐ Will pass along
Time: ____ minutes
Any intros given? ☐ Yes ☐ No

Call #4 (if time):
Name: ________________
Company/Role: ________________
Result: ☐ Interested ☐ No ☐ Will pass along
Time: ____ minutes
Any intros given? ☐ Yes ☐ No

Call #5 (if time):
Name: ________________
Company/Role: ________________
Result: ☐ Interested ☐ No ☐ Will pass along
Time: ____ minutes
Any intros given? ☐ Yes ☐ No

Total calls made: ____
Intros received: ____
Time spent: ____ minutes
```

---

### Phase 3: Send Formal Invites (12:00 PM)

**Goal:** Send calendar links to all interested parties

```
Interested parties (from Day 1 + referrals + Day 2 morning):
☐ Name: __________________ Company: __________________
☐ Name: __________________ Company: __________________
☐ Name: __________________ Company: __________________
☐ Name: __________________ Company: __________________
☐ Name: __________________ Company: __________________

Total formal invites sent: ____
Calendar links included: ☐ Yes
Materials sent (user guide): ☐ Yes
Time spent: ____ minutes
```

---

### Phase 4: Afternoon Check-in (3:00 PM)

**Goal:** Monitor responses, track updates

```
New responses (12 PM - 3 PM):
☐ Name: ________ Status: [Interested/Decline/Question] Time: ____
☐ Name: ________ Status: [Interested/Decline/Question] Time: ____
☐ Name: ________ Status: [Interested/Decline/Question] Time: ____

Updated tracking system:
□ CSV updated with all responses
□ Status fields correct
□ Decision fields correct

Current interested count: ____
Expected by EOD: ____ (target: 3-4)
```

---

### Phase 5: Onboarding Confirmation (If scheduled)

**If someone booked Thursday afternoon:**

```
Call details:
Name: ________________
Company: ________________
Sector: ________________
Time: __________________
Call link: ________________

Call outcome:
☐ Went well ☐ Needs follow-up ☐ Negative signal
First impression: ________________
Key feedback: ________________
Next action: ________________
```

---

### Phase 6: EOD Update (5:00 PM)

**Update tracking:**
```bash
python3 scripts/recruitment_tracker.py report
```

**Spreadsheet summary:**
```
Total contacted (Day 1-2): ____
Responses received: ____
Interested (likely to accept): ____
Confirmed onboarding: ____
Status: 🟢 ON TRACK / 🟡 POSSIBLE / 🔴 NEEDS PIVOT
```

**EOD email to team:**
```
TO: Product Team
SUBJECT: Day 2 Recruitment Update

Day 2 Summary:
✓ Responses: [X] people
✓ Interested: [X] people (will onboard)
✓ Confirmed: [X] onboarding calls scheduled
✓ Follow-ups: [X] scheduled for Day 3

Onboarding schedule:
→ [Name] - [Day] [Time]
→ [Name] - [Day] [Time]
→ [Name] - [Day] [Time]
→ Pending: [X] expected to confirm Friday

Next: Day 3 final push + confirm all appointments
```

---

## Day 3 Morning Stand

**Time:** 9:00 AM  
**Duration:** 5 minutes

### Overnight & Early Morning (6-9 AM)

```
Email check:
Responses received: ____ 
Interested: ____
Declined: ____
No response: ____

Action taken:
□ Replied to interested
□ Sent calendar links
□ Logged to CSV
```

---

## Day 3 Execution Log

### Phase 1: Final Push (10:00 AM)

**Goal:** Last outreach to remaining "Pending"

```
Final follow-up messages sent to:
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________
☐ Name: ________________

Message type: ☐ LinkedIn ☐ Email ☐ Direct message
Tone: ☐ Friendly ☐ Direct (last call)
Expected response: 2-3 more confirmed
Time spent: ____ minutes
```

---

### Phase 2: Confirm All Appointments (11:00 AM)

**Goal:** Lock in 100% of scheduled onboardings

```
Contacts marked "Interested" with scheduled times:
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending
☐ Name: ________________ Slot: [Day] [Time] Confirmed: ☐ Yes ☐ Pending

Total confirmed: ____
Pending confirmation: ____
Target: All confirmed by afternoon
Time spent: ____ minutes
```

---

### Phase 3: Support Team Briefing (12:00 PM)

**Attendees:** All support/onboarding team members  
**Duration:** 15 minutes

**Briefing agenda:**
```
☐ Who's onboarding? (intro, photo, company)
  1. ________________ - __________________
  2. ________________ - __________________
  3. ________________ - __________________
  4. ________________ - __________________
  5. ________________ - __________________

☐ When are they onboarding?
  1. Monday [Time]
  2. Monday [Time]
  3. Tuesday [Time]
  4. Tuesday [Time]
  5. Wednesday [Time]

☐ What to expect in calls? (common questions, tips)
☐ Assign buddies (who supports whom?)
☐ User guide walkthrough (what we told them)
☐ Q&A from team

Team readiness: ☐ All ready ☐ Need more prep ☐ Critical gaps
```

---

### Phase 4: System Readiness Check (1:00 PM)

**Goal:** Weekend prep - ensure system ready for Monday

```
☐ Health check passed
  Command: curl https://staging-api.zephybloom.it/health
  Result: 200 OK ✓

☐ Database backup current
  Command: ls -lh /backups/pilot/ | tail -1
  Result: ________________

☐ Monitoring dashboard live
  Command: python3 scripts/pilot_monitoring.py
  Result: Dashboard accessible ✓

☐ API keys generated
  Generated keys (emails ready): ____
  Ready to send: ☐ Yes

☐ Email templates ready
  ☐ Confirmation email
  ☐ Support email
  ☐ Feedback form email
  ☐ Onboarding guide email

System status: ☐ 🟢 READY ☐ 🟡 SOME GAPS ☐ 🔴 NEEDS FIX
```

---

### Phase 5: Final Metrics (2:00 PM)

**Run final report:**
```bash
python3 scripts/recruitment_tracker.py report
```

**Record results:**
```
RECRUITING FINAL RESULTS:

Total unique contacts: ____
├─ LinkedIn: ____
├─ Email/Referral: ____
└─ Community: ____

Conversion breakdown:
├─ Responses: ____ (X%)
├─ Interested: ____ (X%)
└─ Confirmed onboarding: ____ (X%)

Target achieved: ☐ Yes (5-7) ☐ Partial (3-4) ☐ Below (< 3)

By sector:
├─ SaaS: ____
├─ Manufacturing: ____
└─ Retail: ____

By health:
├─ Healthy: ____
├─ Struggling: ____
└─ Critical: ____

READY FOR LAUNCH: ☐ YES - ALL SYSTEMS GO
                   ☐ MOSTLY - MINOR ISSUES
                   ☐ NO - NEEDS MORE TIME
```

---

### Phase 6: Thank You Mails (3:00 PM)

**Send to referral sources:**
```
Referral sources to thank:
☐ Name: ________________ Status: ☐ Sent
☐ Name: ________________ Status: ☐ Sent
☐ Name: ________________ Status: ☐ Sent

Message: "Thank you for intro to [Company]. They're onboarding next week!"
```

---

### Phase 7: Final Stakeholder Email (4:00 PM)

**To:** Product Lead, CEO, Team

**Subject:** ✅ Pilot Recruitment COMPLETE - Ready for Monday Launch

```
Recruitment Complete!

Total Outreach: ____ contacts
Final Acceptance: ____ users (__% conversion)
Status: 🟢 READY FOR LAUNCH

Users Confirmed (with times):
1. ________________ - ____________________ - [Day] [Time]
2. ________________ - ____________________ - [Day] [Time]
3. ________________ - ____________________ - [Day] [Time]
4. ________________ - ____________________ - [Day] [Time]
5. ________________ - ____________________ - [Day] [Time]
6. ________________ - ____________________ - [Day] [Time]
7. ________________ - ____________________ - [Day] [Time]

Sector Diversity:
SaaS: ____ | Manufacturing: ____ | Retail: ____

Health Diversity:
Healthy: ____ | Struggling: ____ | Critical: ____

System Ready:
✅ Staging environment ✅ Monitoring live
✅ Support team trained ✅ API keys ready
✅ Database backed up ✅ Email templates ready

Launch Timeline:
• Monday (April 20): First 2-3 onboardings
• Tuesday (April 21): Next 2-3 onboardings
• Wed-Fri: All users active + feedback

PILOT LAUNCHES MONDAY AT 9 AM! 🚀
```

---

## Day 2-3 Success Checklist

**Print this and check off as you go:**

```
DAY 2 MORNING
☐ Overnight responses checked
☐ Follow-up wave sent (8-10 people)
☐ Warm calls made (3-5 calls)
☐ Formal invites sent (2-4 people)
☐ Onboarding call conducted (if booked)
☐ Afternoon responses logged
☐ CSV updated
☐ EOD email sent

DAY 3 MORNING
☐ Overnight responses checked
☐ Final push sent (last outreach)
☐ All onboardings confirmed (100%)
☐ Support team briefed
☐ System readiness checked
☐ Final metrics reviewed
☐ Thank you mails sent
☐ Stakeholder email sent

FINAL STATUS
☐ 5-7 users confirmed
☐ All have dates/times
☐ All have materials
☐ System ready
☐ Team ready
☐ Go for Monday launch

FINAL VERDICT: ✅ READY TO LAUNCH
```

---

## Expected Timeline

```
DAY 2 (THURSDAY)
9:00 AM   Overnight check + follow-ups
10:00 AM  LinkedIn follow-up wave (non-responders Day 1)
11:00 AM  Warm referral calls (3-5)
12:00 PM  Send formal invites (interested parties)
2:00 PM   Onboarding call (if booked)
3:00 PM   Email check + tracking update
4:00 PM   Track & update CSV
5:00 PM   EOD summary

⏱️  Total time: 6-7 hours

DAY 3 (FRIDAY)
9:00 AM   Overnight check
10:00 AM  Final push (last outreach)
11:00 AM  Confirm all appointments
12:00 PM  Support team briefing
1:00 PM   System readiness check
2:00 PM   Final metrics review
3:00 PM   Thank you mails
4:00 PM   Stakeholder email
5:00 PM   Final checklist

⏱️  Total time: 6-7 hours
```

---

**End of Day 2-3 Execution Template**

Next: Day 4-5 (First Users Online)

