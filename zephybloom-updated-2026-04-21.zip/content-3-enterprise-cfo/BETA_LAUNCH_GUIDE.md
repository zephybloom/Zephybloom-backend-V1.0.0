# 🚀 ZephyBloom Beta - Launch in 3 Steps (Tonight)

**Time:** ~5 minutes setup, then go live immediately

---

## 📋 What You'll Have After This

```
✅ Backend API running (http://localhost:8001)
✅ Frontend Web App running (http://localhost:3000)
✅ 10 beta accounts created with temp passwords
✅ Credentials file ready to send to beta testers
✅ All tested and working
```

---

## 🎯 Option A: One Command Setup (Easiest)

**If your backend is NOT currently running:**

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# This starts BOTH backend and frontend, creates 10 accounts
bash LAUNCH_BETA_NOW.sh
```

**Then skip to "Test It"** section below.

---

## 🎯 Option B: Manual Setup (If backend already running)

### Terminal 1 (Backend) - If NOT already running:
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo
./START_APP.sh
```

Wait for:
```
✅ Application startup complete
```

---

### Terminal 2 (Frontend) - NEW:
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo/frontend_react

npm install
npm start
```

Wait for:
```
✓ Compiled successfully!
You can now view cfo-dashboard-app in the browser.
Local: http://localhost:3000
```

---

### Terminal 3 (Create accounts) - NEW:
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# Create 10 accounts automatically
bash SETUP_BETA.sh
```

This creates 10 accounts and generates `BETA_CREDENTIALS.txt`

---

## ✅ Test It

### 1. Open browser
```
http://localhost:3000
```

### 2. See login page
Page should look professional with ZephyBloom logo

### 3. Login with first account
```
Email:    mario@acmeinc.it
Password: [temp password from BETA_CREDENTIALS.txt]
```

### 4. Required: Change password on first login
System prompts you - set any password you want (e.g., `Mario123`)

### 5. Inside the app - You should see:
- Dashboard with financial data
- KPI cards (Gross Margin, EBITDA, Net Profit, ROI)
- Graph charts
- "Analyze" button
- "Scenario Simulator" option
- Chat button

### 6. Test an analysis
- Click "Analyze"
- Enter sample data (or leave defaults)
- Click "Analyze"
- See results: Status, KPI, Recommendations

✅ **If all this works, you're DONE.**

---

## 📧 Send to Beta Testers (Tomorrow morning)

Open the file `BETA_CREDENTIALS.txt` (created by setup script)

It contains all 10 accounts with:
- Email
- Temporary password
- Company name
- Sector

**Email to them:**

```
Subject: ZephyBloom Beta Access - Credentials Inside

Hi [Name],

You've been selected for our beta test!

Access the app here:
→ http://localhost:3000

Your credentials are below. Change password on first login.

[Copy/paste the credentials from BETA_CREDENTIALS.txt]

Test instructions:
1. Login
2. Change your password
3. Try analyzing your company financials
4. Try a scenario simulation
5. Send feedback to this email

Thanks for being an early tester!
[Your name]
```

---

## 🛑 When You're Done Testing

To stop everything:

```bash
# Kill all Python processes
pkill -f "python3"
pkill -f "npm"

# Or manually:
# Ctrl+C in each terminal
```

---

## 🔍 Troubleshooting

### "Port 3000 already in use"
```bash
# Find and kill process
lsof -i :3000
kill -9 [PID]
```

### "npm: command not found"
Install Node.js from https://nodejs.org/

### "Frontend won't connect to backend"
Check that backend is running:
```bash
curl http://localhost:8001/health
```

Should return JSON with `"status": "healthy"`

### "Credentials file not created"
Created manually:
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# List all accounts
python3 scripts/create_pilot_user.py --list
```

---

## ✨ Summary

```
🎯 TONIGHT:
├─ Run: bash LAUNCH_BETA_NOW.sh
├─ Wait: ~2-3 min for everything to start
├─ Test: http://localhost:3000
└─ Save: BETA_CREDENTIALS.txt

📧 TOMORROW MORNING:
├─ Open BETA_CREDENTIALS.txt
├─ Send to 10 beta testers
├─ They login and test
└─ Collect feedback

🎉 DONE!
```

---

## 🚀 GO NOW

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo
bash LAUNCH_BETA_NOW.sh
```

**Then come back when you see "ZephyBloom CFO Beta is LIVE!"**

You've got this. 🎯
