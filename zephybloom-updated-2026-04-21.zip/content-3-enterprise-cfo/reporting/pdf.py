# content/reporting/pdf.py
from __future__ import annotations
from typing import Any, Dict, List, Optional

def build_ceo_report(kpi: Dict[str, Any], sims: List[Dict[str, Any]], valuation: Dict[str, Any], alerts: List[Dict[str, Any]], advice: List[str]) -> bytes:
    """
    Genera un PDF semplice.
    Richiede 'reportlab' o 'fpdf'. Se non presenti, solleva eccezione con istruzioni.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import cm
    except Exception:
        try:
            from fpdf import FPDF  # type: ignore
        except Exception:
            raise RuntimeError("Installare uno tra 'reportlab' o 'fpdf' per generare PDF.")

        # fallback FPDF
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 14)
        pdf.cell(0, 10, "CEO Report", ln=True)
        pdf.set_font("Arial", "", 11)
        pdf.multi_cell(0, 6, f"KPI: {kpi}")
        pdf.ln(2)
        pdf.multi_cell(0, 6, f"Valuation: {valuation}")
        pdf.ln(2)
        pdf.multi_cell(0, 6, "Top Alerts:")
        for a in alerts[:5]:
            pdf.multi_cell(0, 6, f"- {a.get('title','')}")
        pdf.ln(2)
        pdf.multi_cell(0, 6, "Advice:")
        for s in advice[:5]:
            pdf.multi_cell(0, 6, f"- {s}")
        return bytes(pdf.output(dest="S").encode("latin1"))

    # reportlab path
    from io import BytesIO
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = h - 2*cm
    c.setFont("Helvetica-Bold", 16)
    c.drawString(2*cm, y, "CEO Report")
    y -= 1.0*cm
    c.setFont("Helvetica", 11)
    c.drawString(2*cm, y, f"KPI: {kpi}")
    y -= 0.8*cm
    c.drawString(2*cm, y, f"Valuation: {valuation}")
    y -= 0.8*cm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2*cm, y, "Top Alerts:")
    y -= 0.6*cm
    c.setFont("Helvetica", 11)
    for a in alerts[:8]:
        c.drawString(2.2*cm, y, f"- {a.get('title','')}")
        y -= 0.5*cm
        if y < 2*cm:
            c.showPage(); y = h - 2*cm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2*cm, y, "Advice:")
    y -= 0.6*cm
    c.setFont("Helvetica", 11)
    for s in advice[:10]:
        c.drawString(2.2*cm, y, f"- {s}")
        y -= 0.5*cm
        if y < 2*cm:
            c.showPage(); y = h - 2*cm
    c.showPage()
    c.save()
    return buf.getvalue()
