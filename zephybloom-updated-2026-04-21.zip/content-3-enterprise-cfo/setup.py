from setuptools import setup, find_packages

setup(
    name="content",
    version="1.0.0",
    description="ZephyBloom CFO API",
    packages=find_packages(exclude=["tests", "*.tests", "*.tests.*", "tests.*"]),
    python_requires=">=3.9",
)
