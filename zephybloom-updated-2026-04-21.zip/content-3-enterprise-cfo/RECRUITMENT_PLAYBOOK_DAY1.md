# Pilot Recruitment Playbook

**Objective:** Identify & reach out to 5-10 Italian SMEs for 2-week pilot
**Timeline:** Day 1-2 (16-17 April 2026)
**Target:** 50% acceptance, launch with 5-10 by Day 5

---

## Target Company Profile

### Ideal Pilot Candidate

**Size:**
- Revenue: €500k - €5M
- Employees: 5-50
- Age: Established (3+ years)

**Sector (Diversity Important):**
- 🏭 Manufacturing (2-3 companies)
- 💻 SaaS/Tech (2-3 companies)
- 🏪 Retail/E-commerce (1-2 companies)

**Financial Health Mix:**
- Healthy: 40% (using for growth benefits)
- Struggling: 40% (need help identifying issues)
- Critical: 20% (urgent decision-making)

**Owner Profile:**
- **Decision-maker:** CEO, Owner, COO, or CFO
- **Tech comfort:** Basic to intermediate (web app users)
- **Motivation:** "How can I improve my business?"
- **Engagement:** Can commit 30 min for onboarding + 2 weekly calls
- **Language:** Preferably Italian (or English)
- **Geography:** Italy preferred (timezone alignment)

**Red Flags to Avoid:**
- ❌ Non-Italian companies (language barrier)
- ❌ Early-stage startups <1 year (unstable financials)
- ❌ Extremely large enterprises (not SME)
- ❌ Unwilling to share basic financials confidentially
- ❌ Too busy for any commitment

---

## Recruitment Channels & Sources

### Channel 1: Direct Outreach (LinkedIn)

**Process:**
1. Search: Italy + Revenue €500k-€5M + SaaS/Manufacturing/Retail
2. Filter: CEO, Founder, Owner, CFO titles
3. Message: Personalized invite (see templates below)
4. Follow-up: 3 days if no response, 7 days second attempt

**Expected Conversion:** 10-15% response → 5-7% acceptance

### Channel 2: Network Referrals

**Who to ask:**
- Business partners / existing customers
- Accountants & business consultants
- Trade associations (Italian manufacturing, SaaS, retail)
- Accelerators / incubators

**Script for referral:** 
"Hi [Person], we're running a 2-week pilot of financial analysis AI. Do you know 2-3 sharp CEOs who'd be interested in free testing & helping shape the product?"

**Expected Conversion:** 30-40% response → 50-60% of referrals accept

### Channel 3: Community & Events

**Places to reach:**
- LinkedIn groups: Italian entrepreneurs, SaaS founders, manufacturers
- Facebook groups: Business owners, startups
- Online communities: GrowthHackers, Indie Hackers, etc.
- Email lists: If you have existing audience

**Method:** Post + DM interested parties

**Expected Conversion:** 5-10% response → 20-30% acceptance

---

## Outreach Messages

### Template 1: LinkedIn Message (Cold)

**Subject:** Pilot Opportunity - Free Financial Analysis AI

```
Ciao [First Name],

I saw your company [Company] in [Sector] - impressive growth!

We're launching ZephyBloom CFO Enterprise (financial analysis AI) 
and looking for 5-10 sharp business leaders to help shape it.

The commitment:
⏱️  30 min onboarding
📊  Run 2-3 analyses on your actual company data
💬  2-3 optional feedback calls
🎁  Free access for 2 weeks
🏆  Directly influence the product

No NDAs or commitment - just honest feedback.

Interested? Reply or check: [link to PILOT_USER_GUIDE.md]

Best,
[Your Name]
ZephyBloom
```

**Personalization hooks:**
- Mention their company/sector specifically
- Reference something recent they've posted
- Show you understand their business

---

### Template 2: Email Outreach (Via Network)

**Subject:** 2-week AI product pilot - FREE (Looking for 2-3 CEOs)

```
Hi [Name],

[Referrer] suggested I reach out to you.

**The Ask:**
We're running a pilot of ZephyBloom CFO Enterprise (AI financial analysis) 
and looking for 5-10 Italian business leaders to test & give feedback.

2-week commitment:
✓ 30 min onboarding call
✓ Analyze your company (your data, your numbers)
✓ Get AI-generated recommendations
✓ 2-3 optional feedback calls (schedule when you want)
✓ Free access ($500/month value)

**Why we're asking:**
You're exactly the type of sharp founder/CEO we want to learn from. 
If this works for you, it should work for others like you.

**The benefit:**
You get financial insights tailored to YOUR business + directly help shape 
the product before everyone else.

**What happens to your data:**
Completely confidential. Deleted after 30 days unless you say keep it. 
GDPR compliant. No sharing, no selling, no AI training on your business.

**Next step:**
Reply YES (takes 3 seconds) + we'll send you a detailed guide and schedule onboarding.

Sound good?

[Your Name]
ZephyBloom CFO Enterprise
[Email] | [Phone] | [Calendar Link]
```

**Variants by sector:**
- For SaaS: "We'll benchmark you against other tech companies"
- For Manufacturing: "Focus on cost optimization + supply chain"
- For Retail: "Analyze margins, inventory, growth potential"

---

### Template 3: Referral Follow-up (After "YES")

**Subject:** ✅ You're In! - Onboarding Tomorrow [time]

```
Fantastic, [Name]!

You're in - onboarding is [Day] at [Time].

Before we connect, few things:

1. **Read the user guide** (5 min)
   → PILOT_USER_GUIDE.md (explains what to expect)

2. **Gather your numbers** (optional, you can find them during call)
   → Annual Revenue
   → Cost of Goods Sold (or costs that vary with production)
   → Operating Expenses (salaries, rent, utilities, etc.)
   → Annual Investments/Capex

3. **Onboarding call details**
   → [Calendar link]
   → Duration: 30 minutes
   → We'll: Explain system, you input data, see analysis live
   → Questions: Ask anything!

4. **What's next after**
   → You get your analysis report
   → You can try "scenario planning" (what-if analysis)
   → Feedback form (2 min, just your honest opinion)
   → Optional weekly check-ins (we call you, 15 min)

That's it! 

See you [Day] at [Time].

[Your Name]
ZephyBloom
```

---

## Screening Questions (During Initial Call/Message)

Ask if they:

**1. Decision Authority**
- "Are you the person who makes financial strategy decisions?"
- Goal: Confirm they won't need approval from someone else

**2. Data Access**
- "Can you access your company's basic financial data (revenue, costs, investment)?"
- Goal: Confirm they have the numbers (within confidentiality)

**3. Time Commitment**
- "Can you commit 30 minutes for onboarding + 2-3 optional calls over 2 weeks?"
- Goal: Confirm availability

**4. Openness to Feedback**
- "If we ask for honest feedback (even if critical), you're comfortable giving it?"
- Goal: Confirm they'll give real feedback, not just validation

**5. Use Case**
- "What's one financial question you'd like answered about your business?"
- Goal: Understand their motivation + ensure it's solvable

**Red Flag Answers:**
- ❌ "I'd need to ask [boss/investor/board]"
- ❌ "Our financials are too complicated to share"
- ❌ "I don't have time for calls"
- ❌ "I just want to validate that our analysis is right"

---

## Recruitment Tracking Template

### Spreadsheet: Pilot_Recruitment_Status.csv

```csv
Name,Company,Sector,Email,Phone,LinkedIn,Revenue_est,Contact_Date,Status,Response_Date,Decision,Onboarding_Date,Notes
[Examples below]

# STATUS: New, Contacted, Interested, Accepted, Onboarded, Declined, No_Response
# DECISION: Pending, Yes, No, Maybe
```

### Example Data

```csv
Alice Rossi,TechStartup SRL,SaaS,alice@techstartup.it,+39 331 123 4567,linkedin.com/in/alice-rossi,2000000,2026-04-16,Contacted,2026-04-16,Interested,2026-04-20,"Enthusiastic about growth tech"
Marco Bianchi,FabbricaBianchi,Manufacturing,marco@fabbrica.it,+39 333 987 6543,linkedin.com/in/marco-bianchi,800000,2026-04-16,Contacted,,Pending,,Website contact form
Giulia Neri,RetailOnline Shop,Retail,giulia@retailshop.it,+39 348 555 1234,,1500000,2026-04-17,New,,,,Referred by AccountantXYZ
```

### Tracking Metrics

**Daily Update (EOD):**
```
Total Contacted:     N
├─ Responded:        N (rate: X%)
├─ Interested:       N (rate: X%)
└─ Accepted:         N (rate: X%, target: 50%)

Breakdown by Status:
├─ New:              0
├─ Contacted:        3
├─ Interested:       1
├─ Accepted:         0
├─ Declined:         0
└─ No Response:      2

Current Run Rate:
Target: 10 companies → Need: 20 contacts (50% conversion)
Status: [Day N: M/20]
```

---

## Day 1 Execution Plan

### Morning (9 AM - 12 PM)

**[ ] 9:00 - Prep Phase (1 hour)**
- Copy Recruitment Tracking spreadsheet to Google Sheets (shared with team)
- Print this guide + keep at desk
- Open Tracker + Calendar
- Prepare message templates (save in drafts)

**[ ] 10:00 - Research Phase (1.5 hours)**
- LinkedIn: Search 10-15 potential contacts
  - Use filters: Italy + SaaS + CEO → 5 contacts
  - Use filters: Italy + Manufacturing + Owner → 5 contacts
  - Use filters: Italy + Retail + Founder → 5 contacts
- Note: Name, company, sector, email/LinkedIn

**[ ] 11:30 - Initial Outreach (0.5 hours)**
- Send 5 LinkedIn messages (one per company)
- Format: Keep text brief, use Template 1 above
- Goals: 10% response within 24 hours = 0-1 response (acceptable)

### Afternoon (2 PM - 6 PM)

**[ ] 2:00 - Email Phase (1.5 hours)**
- Identify 5-7 referral sources (accountants, consultants, partners)
- Personnalized ask: "Do you know 2-3 CEOs who'd pilot?"
- Add to spreadsheet

**[ ] 3:30 - Community Outreach (1 hour)**
- Post in 2-3 relevant LinkedIn groups (Italian entrepreneurs, SaaS founders)
- Template: "Startups: Help shape ZephyBloom CFO Enterprise (AI financial analysis). 2-week pilot, free access. DMif interested."
- Note: Keep it brief, add link to PILOT_USER_GUIDE.md

**[ ] 4:30 - Spreadsheet Update (0.5 hours)**
- Log all outreach to Pilot_Recruitment_Status.csv
- Update "Contact_Date" + "Status" = "Contacted"
- Report daily count

**[ ] 5:00 - Planning Tomorrow (0.5 hours)**
- Review responses (likely 0-2 at this early stage)
- Plan Day 2 follow-ups
- Prep Day 2 warm outreach

### Evening (Optional)

**After hours (low priority):**
- Monitor LinkedIn/email for early responses
- Log any incoming interest
- Send thank-you to anyone responding

---

## Day 2 Execution Plan (April 17)

### Morning (9 AM)

**[ ] Review Overnight Responses**
- Any new matches? Add to tracking
- Any questions? Respond within 2 hours
- Send thank-you + move to next step

**[ ] Follow-up Wave**
- Contact #6-10 (fresh batch) via LinkedIn
- Email 3-5 referral sources (if not done Day 1)
- Add to tracking spreadsheet

### Afternoon

**[ ] Referral Follow-ups**
- Call top 2-3 referral sources (warm outreach)
- Ask: "Any leads from the message I sent?"
- If yes: Get intro email or direct contact

**[ ] Early Wins**
- For anyone responding "YES": 
  - Send Template 3 (onboarding confirmation)
  - Schedule call in calendar
  - Send PILOT_USER_GUIDE.md

---

## Goal: End of Day 2

```
Contacts Attempted:   15-20
├─ LinkedIn Messages: 10
├─ Direct Email:      5-7
└─ Community Posts:   1-2

Early Responses:      2-3
├─ Interested:        1-2
├─ Maybe/Later:       1
└─ Declined:          0

**Onboardings Scheduled (Days 3-5): 1-2**

Momentum: 🟢 On track

Next: Day 3-5, get 5-10 to "Accepted" status
```

---

## Email Templates by Sector

### SaaS-Specific

```
Hey [Name],

I noticed [Company] is doing some interesting work in [niche].

Quick opportunity: We're running a 2-week pilot of ZephyBloom CFO Enterprise 
(AI-powered financial analysis).

For SaaS founders, it focuses on:
✓ Unit economics (CAC, LTV, payback period)
✓ Burn rate vs runway analysis
✓ SaaS-specific benchmarks (margins, churn, growth)
✓ Pricing optimization opportunities

Free, 2 weeks, your data stays yours.

Interested? [Link to guide]

—
[Your Name]
```

### Manufacturing-Specific

```
Hello [Name],

I see FabbricaBianchi is a solid [subsector] manufacturer.

We're piloting ZephyBloom CFO Enterprise with Italian manufacturers, 
focusing on:
✓ Cost of goods optimization
✓ Margin analysis (where's your money?)
✓ Supply chain efficiency
✓ Comparison to sector benchmarks

Your financials, completely confidential. Free 2-week trial.

Could be useful? [Link]

Best,
[Your Name]
```

### Retail-Specific

```
Hi [Name],

Retail margins are brutal - we get it. That's why we built ZephyBloom.

For 2 weeks, we're letting retail leaders test it free:
✓ Gross margin analysis
✓ Fixed cost optimization (rent, staff, utilities)
✓ Inventory efficiency insights
✓ Benchmarking to other retailers

Honest feedback helps us build better. Your data is safe.

Game? [Link]

—
[Your Name]
```

---

## Success Criteria (Day 1-2)

| Metric | Target | Status |
|--------|--------|--------|
| Contacts attempted | 15-20 | TBD |
| Response rate | 10-15% | TBD |
| Interest rate | 50%+ of responses | TBD |
| Accepted (scheduled) | 2-3 by Day 2 EOD | TBD |
| On track for 10 total | YES by Day 7 | TBD |

**If target met:** Continue Day 3 (onboarding)
**If <1 response:** Double channels (more referrals, community posts)
**If >3 accepted:** Pause outreach, focus onboarding

---

## Scripts & Automation

### Simple Contact Tracker (Google Sheets)

```
Create Google Sheet: "Pilot Recruitment"

Columns:
A: Name
B: Company
C: Sector
D: Email
E: LinkedIn
F: Contact Date (YYYY-MM-DD)
G: Status (New/Contacted/Interested/Accepted/Declined/No Response)
H: Response Date
I: Decision (Yes/No/Maybe/Pending)
J: Onboarding Date
K: Notes

Add 5 test rows → Try filtering & sorting
Sort by Status to see which need follow-up
Use conditional formatting: Green=Accepted, Yellow=Interested, Red=Declined
```

### Email Tracking (Simple)

```
Send emails from: pilot-recruitment@zephybloom.it
Tag all subject lines: [RECRUIT-001], [RECRUIT-002], etc.

Use Gmail filters:
→ Star all responses
→ Label "Pilot/Responses" auto-collects

Check daily: Gmail → Pilot/Responses → See all feedback in one place
```

---

## Contingency Plans

### If Day 1-2 slow response (<1 interest)?

**Pivot options:**
1. **Double down on referral channel**
   - More calls to business consultants
   - Ask for 3 personal intros instead of names
   - Higher conversion rate (30-50%)

2. **Accelerate community channel**
   - Post in 5+ groups (Italian, SaaS, Startup, Manufacturing, Retail)
   - Create 30-second video demo
   - Ask for shares/RTs

3. **Direct outreach to vendors**
   - Accountants, bookkeepers, business coaches
   - "Your clients are who we want to demo to"
   - Win-win: Their clients get free software

### If Day 1-2 VERY high interest (>5 offers)?

**Good problem!**
- Be selective: Prioritize diverse cohort (health, sector, size mix)
- Politely defer extras: "We're full for pilot, interested in next wave?"
- Get waitlist (for phase 2 expansion)

---

## Checklist for Day 1 (Print & Post)

```
☐ 9:00 AM   - Prep: Templates, spreadsheet, calendar
☐ 10:00 AM  - Research: 10-15 LinkedIn prospects
☐ 11:30 AM  - Outreach: Send 5 LinkedIn messages
☐ 2:00 PM   - Email: Reach out to 5-7 referral sources
☐ 3:30 PM   - Community: Post in 2-3 groups
☐ 4:30 PM   - Track: Update spreadsheet
☐ 5:00 PM   - Plan: Tomorrow's follow-ups
☐ 5:30 PM   - Summary: Email team "Day 1 complete"

END OF DAY REPORT:
Total Contacted: ___
Responses: ___
Interested: ___
Next: Day 2 follow-ups
```

---

## Contact Day 1 (Sunday EOD)

**Email sending summary to team:**

```
TO: Product Team
SUBJECT: Pilot Recruitment - Day 1 Summary

Day 1 Results:
✓ Contacted: 15 companies
✓ Channels: 5 LinkedIn, 5 email, 5 community posts
✓ Responses: 0 (expected - too early)
✓ Next: Day 2 follow-up + referral calls

Action Day 2:
→ Follow-ups to non-responders
→ Call referral sources
→ Email template variations (test different pitches)

Tracking: [Link to spreadsheet]

Status: 🟢 ON TRACK - On schedule to hit 10 companies by Day 5
```

---

**Ready to launch Day 1?**

✅ Playbook created
✅ Templates ready
✅ Tracking system designed
✅ Success criteria clear

**Next steps:**
1. Print this playbook
2. Create Google Sheet for tracking
3. 9:00 AM tomorrow → Execute "Prep Phase"
4. Report progress EOD

Good luck! 🚀

