# content/llm/client.py
from __future__ import annotations
import os, json, time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Callable

@dataclass
class LLMMessage:
    role: str  # "system" | "user" | "assistant" | "tool"
    content: str
    name: Optional[str] = None
    tool_call_id: Optional[str] = None

class _ProviderBase:
    def generate_text(self, model: str, messages: List[LLMMessage], max_tokens: int = 600, temperature: float = 0.2) -> str:
        raise NotImplementedError

    def generate_with_tools(
        self, model: str, messages: List[LLMMessage], tools: List[Dict[str, Any]],
        max_tokens: int = 600, temperature: float = 0.2
    ) -> Dict[str, Any]:
        """
        Ritorna un dict con:
        {
          "type": "tool_calls" | "text",
          "tool_calls": [{"id": "...","name":"...","arguments":{...}}, ...]  # opzionale
          "text": "risposta finale"                                          # opzionale
        }
        """
        raise NotImplementedError

    def embed(self, model: str, text: str) -> List[float]:
        # fallback pseudo-embedding deterministico (nessuna dipendenza esterna)
        import hashlib
        h = hashlib.sha256(text.encode("utf-8")).digest()
        return [(b/255.0 - 0.5) for b in h[:128]]

# ---------- OpenAI provider (consigliato) ----------
class _OpenAIProvider(_ProviderBase):
    def __init__(self):
        # Prova a importare la SDK; se non c'è, resta offline
        try:
            from openai import OpenAI  # type: ignore
        except Exception as e:
            self._client = None
            self._err = e
            return

        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_BASE_URL")  # opzionale (proxy/self-host)

        # Se non c'è la chiave, resta in modalità offline (nessun crash)
        if not api_key or not str(api_key).strip():
            self._client = None
            self._err = "Missing OPENAI_API_KEY"
            return

        # Altrimenti inizializza il client reale
        try:
            self._client = OpenAI(api_key=api_key, base_url=base_url)
            self._err = None
        except Exception as e:
            # Qualsiasi errore → offline
            self._client = None
            self._err = e


    @staticmethod
    def _to_openai_messages(messages: List[LLMMessage]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for m in messages:
            d: Dict[str, Any] = {"role": m.role, "content": m.content}
            if m.name: d["name"] = m.name
            if m.role == "tool" and m.tool_call_id:
                d["tool_call_id"] = m.tool_call_id
            out.append(d)
        return out

    @staticmethod
    def _to_openai_tools(tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # TOOL_SPECS -> OpenAI schema
        out = []
        for spec in tools:
            out.append({
                "type": "function",
                "function": {
                    "name": spec["name"],
                    "description": spec.get("description",""),
                    "parameters": spec.get("parameters", {"type":"object","properties":{}})
                }
            })
        return out

    def generate_text(self, model: str, messages: List[LLMMessage], max_tokens: int = 600, temperature: float = 0.2) -> str:
        if not self._client:
            # fallback
            return f"(offline) {messages[-1].content}"
        resp = self._client.chat.completions.create(
            model=model,
            messages=self._to_openai_messages(messages),
            max_tokens=max_tokens,
            temperature=temperature
        )
        return (resp.choices[0].message.content or "").strip()

    def generate_with_tools(
        self, model: str, messages: List[LLMMessage], tools: List[Dict[str, Any]],
        max_tokens: int = 600, temperature: float = 0.2
    ) -> Dict[str, Any]:
        if not self._client:
            # fallback: nessun tool-calling reale
            return {"type": "text", "text": f"(offline) {messages[-1].content}"}
        resp = self._client.chat.completions.create(
            model=model,
            messages=self._to_openai_messages(messages),
            tools=self._to_openai_tools(tools),
            tool_choice="auto",
            max_tokens=max_tokens,
            temperature=temperature
        )
        msg = resp.choices[0].message
        tool_calls = getattr(msg, "tool_calls", None)
        if tool_calls:
            calls = []
            for tc in tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except Exception:
                    args = {}
                calls.append({"id": tc.id, "name": name, "arguments": args})
            return {"type": "tool_calls", "tool_calls": calls}
        return {"type": "text", "text": (msg.content or "").strip()}

    def embed(self, model: str, text: str) -> List[float]:
        if not self._client:
            return super().embed(model, text)
        out = self._client.embeddings.create(model=model, input=text)
        return out.data[0].embedding  # type: ignore

# ---------- Client pubblico ----------
class LLMClient:
    """
    Client vendor-agnostico con supporto:
      - generate(): testo semplice
      - embed(): embeddings
      - agent(): loop tool-calling (OpenAI-style) con invoker e TOOL_SPECS
    """
    def __init__(self, model: str = None, provider: str = None, temperature: float = 0.2):
        self.model = model or os.getenv("LLM_MODEL", "gpt-4o-mini")
        self.temperature = float(os.getenv("LLM_TEMPERATURE", temperature))
        provider = provider or os.getenv("LLM_PROVIDER", "openai").lower()

        if provider == "openai":
            self._prov: _ProviderBase = _OpenAIProvider()
        else:
            # fallback base
            self._prov = _ProviderBase()

    # ---- API base ----
    def generate(self, messages: List[LLMMessage], max_tokens: int = 600) -> str:
        return self._prov.generate_text(self.model, messages, max_tokens=max_tokens, temperature=self.temperature)

    def embed(self, text: str, model: str = None) -> List[float]:
        em_model = model or os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")
        return self._prov.embed(em_model, text)

    # ---- Agent loop (tool-calling) ----
    def agent(
        self,
        messages: List[LLMMessage],
        toolspecs: Dict[str, Dict[str, Any]],
        invoker: "ToolInvoker",
        max_steps: int = 3,
        max_tokens: int = 700
    ) -> Tuple[str, List[str]]:
        """
        Esegue un loop tool-calling:
        - Chiede al modello se vuole chiamare un tool (tool_choice=auto)
        - Esegue il tool tramite invoker
        - Aggiunge la risposta tool come messaggio 'tool'
        - Ripete fino a testo finale o max_steps
        Ritorna (testo_finale, [tools_usati])
        """
        tools_used: List[str] = []
        step = 0
        tools_list = [spec for spec in toolspecs.values()]
        chat = list(messages)

        while step < max_steps:
            step += 1
            resp = self._prov.generate_with_tools(self.model, chat, tools_list, max_tokens=max_tokens, temperature=self.temperature)
            if resp.get("type") == "text":
                return resp.get("text",""), tools_used

            # tool calls
            for call in resp.get("tool_calls", []):
                name = call["name"]
                args = call.get("arguments", {}) or {}
                try:
                    result = invoker.invoke_safe(name, args)
                except Exception as e:
                    result = {"error": str(e)}

                tools_used.append(name)
                # Aggiungi messaggio 'tool' con tool_call_id (richiesto da OpenAI)
                content = json.dumps(result, ensure_ascii=False)
                chat.append(LLMMessage(role="tool", content=content, name=name, tool_call_id=call.get("id")))
            # Dopo aver aggiunto i tool results, chiedi al modello la risposta finale
            chat.append(LLMMessage(role="assistant", content="Ho ricevuto i risultati degli strumenti. Elabora la risposta finale."))

        # se si esce per max_steps, fai un riassunto safe
        return "(Nota: raggiunto il limite di passaggi; fornisco risultato sintetico.)", tools_used
