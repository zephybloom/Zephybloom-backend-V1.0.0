# Live Support Runbook (Day 4-5 & Beyond)

**Purpose:** Provide excellent, fast support to pilot users during live deployment  
**Response target:** <30 minutes for any user question  
**Tone:** Friendly, helpful, never defensive

---

## Support Channels & Response Times

### Email (pilot-support@zephybloom.it)
- **Response time:** <2 hours (aim for <1 hour)
- **Availability:** 9 AM - 6 PM weekdays
- **After hours:** Check once next morning

### Slack (#pilot-support channel)
- **Response time:** <15 minutes (realtime)
- **Availability:** During business hours
- **Setup:** Direct DM to responder if urgent

### Phone (For critical issues only)
- **Response time:** Immediate
- **Use case:** System down, data concern, user distressed
- **Contact:** [On-call number]

---

## Pre-Launch Support Setup

### [ ] Slack Channel Configuration

```
Create: #pilot-support (private)
Invite: All team members + pilot users
Purpose: Real-time support & questions
Pinned messages:
  ├─ Support contact info
  ├─ FAQ document
  ├─ Common issues & solutions
  ├─ System status page
  └─ Escalation procedure
```

### [ ] Email Templates (Save in drafts)

**1. Welcome/Confirmation**
```
Subject: Welcome to ZephyBloom Pilot! 

Hi [Name],

You're all set! Here's what you need to know:

LOGIN INFO
Email: [email@company.com]
Password: [temp]
Link: https://staging-api.zephybloom.it/login

QUICK START (5 min to first analysis)
1. Log in with credentials above
2. Enter your revenue, costs, investment (or skip—we can estimate)
3. Click "Analyze"
4. Get your financial health analysis in seconds

QUESTIONS?
→ Email: pilot-support@zephybloom.it
→ Slack: #pilot-support (I'll respond within 15 min)
→ Phone: [number] (for urgent issues)

Let me know how it goes!
[Your Name]
```

**2. Quick Support Response**
```
Subject: Re: [Their question]

Hi [Name],

Thanks for reaching out!

Your issue: [restate their problem in one sentence]

Here's what's happening: [explain clearly, non-technical]

What you can do: [specific steps]

Let me know if that helps! If not, we'll dig deeper.

[Your Name]
```

**3. Escalation Acknowledgment**
```
Subject: We're looking into this [Your issue name]

Hi [Name],

Thanks for reporting this. We take it seriously.

Current status: Engineering team investigating
Expected timeline: We'll have an answer/fix by [time]
Your workaround: [if applicable]

I'll follow up with an update at [time].

[Your Name]
```

---

## Common Support Questions & Responses

### Category 1: Login & Access Issues

**Issue: "I can't log in"**

Debug questions:
- What error message do you see? (Take screenshot)
- Are you using the correct email?
- Did you reset password? (If not, send link)

Response:
```
"I'm sorry you're having trouble! Let's fix this quickly.

Can you try [specific step] and let me know what happens?

If that doesn't work, I'll generate a new temporary password 
for you right away."
```

---

**Issue: "I forgot my password"**

Response:
```
"No problem! Click 'Forgot password' on the login page.
You'll get an email with a reset link (check spam folder too).

If you don't get the email in 5 minutes, let me know 
and I'll send you a temporary password directly."
```

---

### Category 2: Data & Analysis Issues

**Issue: "The analysis says HEALTHY but we're losing money"**

Response (listen first):
```
"Let me understand your situation.

You analyzed with:
- Revenue: €___
- Costs: €___
- Investment: €___

And the system said HEALTHY, but you think you're 
losing money. Is that right?

A few questions:
1. When you say 'losing money,' what do you mean? 
   (Negative profit? Burn rate?)
2. Did you include ALL costs? (Often people forget about cost of goods)
3. The revenue—is that annual?

Once I understand, we can debug together."
```

**Common reasons it shows wrong status:**
- They entered monthly revenue (system assumes annual)
- They didn't include all operating expenses
- They're confusing net profit with cash flow
- System has a bug (rare but document if true)

---

**Issue: "The recommendations don't apply to my business"**

Response:
```
"That's totally fair. The system analyzes financials 
but doesn't know your unique situation.

Here's what I'd suggest:
1. Take the financial insights (margins, profit, ROI) as facts
2. Use those to ask better questions
3. For implementation, talk to your accountant or advisor who knows your biz

Does that make sense? Which recommendation seemed 
least relevant to you? That's helpful feedback."
```

---

**Issue: "The numbers don't match my accounting"**

Response:
```
"Good catch! Let's find where the discrepancy is.

Can you share:
1. The numbers you analyzed with (what you gave us)
2. Your actual accounting numbers
3. A screenshot of the analysis we showed

Most likely explanations:
- Different accounting period (quarterly vs annual)
- Different definition of costs (we count COGS differently than you)
- One-time events (big sale, unexpected expense)

Once I see both sides, we can figure it out together."
```

---

### Category 3: Feature Requests / "I wish it did X"

**Issue: "Can you add [feature]?"**

Response:
```
"Great idea! That's exactly the kind of feedback we need.

I'm noting that down. In the short term, here's a workaround: [if applicable]

But this is gold for the v2 roadmap. 
Are you okay if I mention you specifically when we pitch 
this feature to the team? Helps with prioritization."
```

Common requests to note:
- Competitor benchmarking
- Cash flow analysis
- Historical trending
- Export to Excel
- Mobile app

---

### Category 4: Bugs & Technical Issues

**Issue: "The system is slow" or "I got an error"**

Debug questions:
- What were you trying to do?
- What error message appeared? (Screenshot?)
- When did this start?
- Is it still happening now?

Response:
```
"Sorry you're hitting a snag! Let me investigate.

Quick debug:
1. Try a different browser if this persists
2. Clear your cache (Ctrl+Shift+Delete)
3. Try again

If it still happens, I'm escalating to our engineering team.
They can see exactly what went wrong in our logs.

ETA for fix: [time] - I'll update you."
```

If it's a real bug:
```
"We've identified the issue. Here's what's happening:
[brief technical explanation if applicable]

We're working on a fix. In the meantime:
[workaround if any]

I'll update you when it's resolved. Sorry for the disruption!"
```

---

### Category 5: Data Privacy & Security

**Issue: "Is my data secure?" or "Where does it go?"**

Response:
```
"Great question. Here's exactly what happens:

YOUR DATA:
✓ Encrypted when stored (can't access without key)
✓ Encrypted in transit (TLS 1.3)
✓ Only we can read it (not AI training)

RETENTION:
✓ During pilot: We keep it
✓ After pilot (30 days): We delete unless you ask to keep
✓ You can delete anytime: Just ask

SHARING:
✓ We don't share with anyone
✓ We don't sell it
✓ We use anonymized patterns for learning (not your case)

COMPLIANCE:
✓ We follow GDPR
✓ You have right to data export
✓ You have right to erasure

Any other concerns? Happy to explain more."
```

---

### Category 6: How-To Questions

**Issue: "How do I run a 'what-if' scenario?"**

Response:
```
"Easy! Here's how:

1. Analyze your company normally (you've done this)
2. After you see the results, click "Try a Scenario"
3. Change ONE number (e.g., raise prices 10%)
4. Click "Analyze" again
5. Compare the two results

Example: 'If I raise my prices by 10%, my profit goes from 
€50k to €75k. That's the impact.'

Common scenarios to try:
- Raise prices 5-10%
- Reduce fixed costs by 10-15%
- Increase sales volume by 20-30%

Try 2-3, tell us what you learn!"
```

---

## Escalation Decision Tree

```
User question/issue
    ↓
[Can I answer in <2 min?]
├─→ YES: Answer immediately, move on
└─→ NO: Ask clarifying questions

[Do I know the answer after questions?]
├─→ YES: Explain clearly
└─→ NO: "Let me investigate & get back to you"

[Is this a system bug or feature gap?]
├─→ BUG: "We found issue X. Engineering is fixing it. ETA: [time]"
├─→ FEATURE: "Great feedback! Noted for v2 roadmap"
└─→ USER ERROR: Guide them to correct approach

[Is the user frustrated or urgent?]
├─→ CRITICAL: Call them (don't just email)
├─→ UPSET: Empathize, offer phone call
└─→ CURIOUS: Email is fine

[Is this affecting pilot results?]
├─→ YES (user can't use system): Fix immediately
├─→ NO (nice-to-have improvement): Note for later
└─→ MAYBE: Escalate to product team
```

---

## Common Support Scenarios & Responses

### Scenario 1: User Confused About EBITDA

```
USER: "What's EBITDA? I don't understand that number."

RESPONSE:
"Great question—it's a technical term that confuses everyone.

Simple version: It's how much profit you're making 
from your core business operations.

Formula: Revenue - Costs - Operating Expenses
= EBITDA (before taxes & depreciation)

Why we show it: It tells you if your business model is working.

Example:
Revenue: €100,000
Costs: €40,000
Operating: €40,000
= EBITDA: €20,000

That means €20k of the €100k is true business profit. 
The rest goes to taxes, loans, reinvestment.

Make sense? Happy to explain more clearly if it doesn't."
```

---

### Scenario 2: User Gets Conflicting Advice

```
USER: "Your system says I should raise prices, 
but my accountant says I should cut costs."

RESPONSE:
"Good that you're talking to your accountant! 
They know your business (we only see the numbers).

Here's how to think about it:
- Our insight: 'Your margin is low' (fact)
- Your accountant's advice: 'You should do X' (judgement)

The recommendation 'raise prices' is ONE option.
'Cut costs' is another option.
'Find customers willing to pay more' is another option.

Ask your accountant: 'Given these margins, what's 
the BEST way to improve profitability?' 
They'll have context we don't.

We're your data analyst. Your accountant is your strategy partner.
Use both! That's how good decisions get made."
```

---

### Scenario 3: User Wants Guarantee

```
USER: "If I implement your recommendations, 
will my business definitely improve?"

RESPONSE:
"Great question—and I'll be honest.

We can't guarantee it. Here's why:
- We analyze your numbers, not your market
- We don't know your competition
- We don't know your customer relationships
- Implementation matters as much as the idea

What we CAN guarantee:
- Our analysis is accurate (based on solid financial math)
- The recommendations are based on proven business practices
- You'll understand your financial situation better after

What you need to do:
- Talk to your accountant (validate our analysis)
- Talk to your business advisor (refine the strategy)
- Test 1-2 recommendations (learn what works for you)
- Iterate (keep what works, drop what doesn't)

You're the expert on your business. We're just 
giving you better data to make decisions with.

Sound fair?"
```

---

## Support Quality Checklist

**For every support response, ask:**

```
☐ Did I understand their question correctly?
  (Restate it back to them)

☐ Did I answer in plain language?
  (No jargon unless necessary)

☐ Is my answer complete?
  (Do they have everything they need to fix it?)

☐ Did I offer next steps?
  ("Try this, let me know if it works")

☐ Am I being helpful, not defensive?
  (Not "That's not a bug" but "Here's why it works that way")

☐ Did I make them feel supported?
  ("We're here to help" tone, not annoyed)

☐ Is my response under 4 paragraphs?
  (Concise, not overwhelming)

☐ Did I offer escalation if needed?
  ("If this doesn't work, we'll dig deeper")
```

---

## Support Logs & Tracking

### Daily Support Summary

```
DATE: ____________

USERS WITH ISSUES: ____
├─ Login problems: ____
├─ Analysis questions: ____
├─ Feature requests: ____
├─ Bug reports: ____
└─ Other: ____

RESPONSE TIME AVERAGE: ____ min (target: <30 min)

ESCALATIONS TO ENGINEERING: ____
├─ Critical: ____
├─ High: ____
└─ Medium: ____

ISSUES RESOLVED TODAY: ____
STILL PENDING: ____

PATTERNS NOTICED:
1. Most common question: ________________
2. Most common confusion: ________________
3. Feature request (#1): ________________

ACTION ITEMS:
→ Update FAQ with [issue]
→ Add tooltip for [confused field]
→ Escalate [bug] to engineering
→ Monitor [potential issue] tomorrow
```

---

## FAQ to Maintain

Keep updated during pilot:

```
# Pilot FAQ (Living Document)

## Getting Started
Q: Where do I log in?
A: [Link]

Q: I forgot my password
A: [Instructions]

Q: What if I don't have exact numbers?
A: [You can estimate]

## Understanding Results
Q: What does EBITDA mean?
A: [Plain language explanation]

Q: Why does it say HEALTHY when I don't feel healthy?
A: [Common reasons]

Q: What's the Cost of Inaction?
A: [Explanation]

## Scenarios & "What-If"
Q: How do I try a scenario?
A: [Steps]

Q: Can I compare two analyses?
A: [Yes, here's how]

## Data & Privacy
Q: Where does my data go?
A: [Secure, encrypted, deleted after pilot]

Q: Can I export my analysis?
A: [Yes, here's how]

## Feedback & Pilot
Q: How do I submit feedback?
A: [Feedback form in dashboard]

Q: Can I give you feedback directly?
A: [You can email or Slack]

Q: What happens after the pilot?
A: [We analyze results, you get insights]
```

---

## Escalation Contacts

```
SUPPORT TEAM (Pilot)
Lead: [Name] [Email] [Phone]
Backup: [Name] [Email] [Phone]

ENGINEERING (For bugs)
Lead: [Name] [Email]
On-call: [Name] [Phone]

PRODUCT (For feature requests)
Lead: [Name] [Email]

DATA/PRIVACY (For security concerns)
Lead: [Name] [Email]

OPS (For system down)
Lead: [Name] [Phone] [Email]
```

---

## After-Hours Protocol

**For issues outside 9 AM - 6 PM:**

1. **Check Slack:** Is this critical?
   - System down? → Call ops lead immediately
   - User data concern? → Escalate next morning
   - User frustrated? → Respond first thing

2. **Documentation:** Log in Slack so morning team knows
   - Thread with issue description
   - What you did
   - Next owner (assign)

3. **Response SLA:**
   - Critical: Respond same hour (for shutdown)
   - High: Respond next morning (9 AM)
   - Medium/Low: Respond next business day

---

**END OF LIVE SUPPORT RUNBOOK**

Use daily during pilot launch + ongoing!

