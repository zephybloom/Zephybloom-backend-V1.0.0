#!/usr/bin/env python3
"""
ZephyBloom CFO API - Direct Python Launcher
Simple, direct server startup without bash complications.
"""

import sys
import os
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Set up environment
os.environ.setdefault("ZB_LLM_PROVIDER", "openai")
os.environ.setdefault("JWT_REQUIRED", "false")

def main():
    try:
        import uvicorn
        from api.main import app
        
        print("\n" + "="*60)
        print("🚀 ZephyBloom CFO API - Starting Server")
        print("="*60)
        print("\n📍 Access the app:")
        print("   API:     http://localhost:8001")
        print("   Docs:    http://localhost:8001/docs")
        print("   Health:  http://localhost:8001/health")
        print("\n⏹️  Press Ctrl+C to stop\n")
        
        # Run the server
        uvicorn.run(
            app,
            host="127.0.0.1",
            port=8001,
            reload=True,
            log_level="info"
        )
        
    except ImportError as e:
        print(f"\n❌ Error: {e}")
        print("\nDependencies not installed. Run:")
        print("  pip3 install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Server error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
