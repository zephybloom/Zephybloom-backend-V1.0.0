#!/usr/bin/env python3
"""
STAGING VALIDATION SCRIPT - ZephyBloom CFO Enterprise
Complete validation across all 10 phases
"""

from datetime import datetime
from core.analysis import analyze_company, CFOAnalysisEngine
from core.decision_coordinator import DecisionCoordinator
from core.cost_of_inaction import CostOfInactionCalculator
from core.human_value_calculator import HumanValueCalculator
import traceback
import json

# Color codes for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
END = '\033[0m'
BOLD = '\033[1m'

# Report structure
report = {
    "timestamp": datetime.now().isoformat(),
    "phases": {},
    "issues": [],
    "critical_issues": [],
    "status": "READY FOR PILOT",
}

def log_phase(phase_num, title):
    print(f"\n{BOLD}{'='*70}{END}")
    print(f"{BLUE}FASE {phase_num}: {title}{END}")
    print(f"{BOLD}{'='*70}{END}")
    report["phases"][f"phase_{phase_num}"] = {"title": title, "tests": []}

def log_test(test_name, result, details=""):
    status = f"{GREEN}✓ PASS{END}" if result else f"{RED}✗ FAIL{END}"
    print(f"{status} {test_name}")
    if details:
        print(f"    {details}")

def log_issue(issue, criticality="media", phase=None):
    report["issues"].append({"issue": issue, "criticality": criticality, "phase": phase})
    icon = "🔴" if criticality == "alta" else "🟠" if criticality == "media" else "🟡"
    print(f"{icon} ISSUE: {issue} ({criticality})")
    if criticality == "alta":
        report["critical_issues"].append(issue)
        report["status"] = "NEEDS FIXES BEFORE PILOT"

# =============================================================================
# FASE 2: VALIDAZIONE END-TO-END
# =============================================================================

log_phase(2, "VALIDAZIONE END-TO-END")

# Scenario 1: Azienda Sana
print(f"\n{BOLD}Scenario 1: Azienda Sana (SaaS){END}")
try:
    company_data = {
        "fatturato": 1_000_000,
        "costi_variabili": 250_000,      # 25% - buono
        "costi_fissi": 300_000,           # 30% - OK
        "investimenti": 100_000,
        "company_name": "TechHealthy",
        "sector": "saas"
    }
    
    result = analyze_company(**company_data)
    
    # Checks
    checks = [
        ("dominant_action presente", result.headline is not None),
        ("diagnosis presente", result.diagnosis is not None),
        ("recommended_actions presente", len(result.recommended_actions) > 0),
        ("kpi_snapshot presente", result.kpi_snapshot is not None),
        ("status sano", result.status in ["healthy", "warning", "critical"]),
    ]
    
    for check_name, check_result in checks:
        log_test(check_name, check_result)
    
    print(f"\n  Output Quality:")
    print(f"    - Status: {result.status}")
    print(f"    - Headline: {result.headline[:70]}...")
    print(f"    - Gross Margin: {result.kpi_snapshot.gross_margin_pct}%")
    print(f"    - Actions: {len(result.recommended_actions)}")
    
except Exception as e:
    log_test("Scenario 1: Azienda Sana", False, str(e))
    log_issue(f"Scenario azienda sana fallisce: {e}", "alta", 2)

# Scenario 2: Azienda in Difficoltà
print(f"\n{BOLD}Scenario 2: Azienda in Difficoltà (Retail){END}")
try:
    company_data = {
        "fatturato": 500_000,
        "costi_variabili": 350_000,      # 70% - alto
        "costi_fissi": 200_000,           # 40% - alto
        "investimenti": 50_000,
        "company_name": "RetailStruggles",
        "sector": "retail"
    }
    
    result = analyze_company(**company_data)
    
    checks = [
        ("Status almeno 'warning'", result.status in ["warning", "critical"]),
        ("Diagnosis identifica problema", "problematic" in result.diagnosis.problema_principale.lower() or 
                                          "margin" in result.diagnosis.problema_principale.lower() or
                                          result.diagnosis.problema_principale != ""),
        ("Actions presente", len(result.recommended_actions) > 0),
    ]
    
    for check_name, check_result in checks:
        log_test(check_name, check_result)
    
    print(f"\n  Output Quality:")
    print(f"    - Status: {result.status}")
    print(f"    - Problema: {result.diagnosis.problema_principale}")
    print(f"    - Actions: {len(result.recommended_actions)}")
    
except Exception as e:
    log_test("Scenario 2: Azienda in difficoltà", False, str(e))
    log_issue(f"Scenario difficoltà fallisce: {e}", "alta", 2)

# Scenario 3: Azienda Critica
print(f"\n{BOLD}Scenario 3: Azienda Critica (Loss-making){END}")
try:
    company_data = {
        "fatturato": 300_000,
        "costi_variabili": 200_000,      # 67% - critico
        "costi_fissi": 150_000,           # 50% - critico
        "investimenti": 30_000,
        "company_name": "LossMaker",
        "sector": "manufacturing"
    }
    
    result = analyze_company(**company_data)
    
    checks = [
        ("Status critico", result.status == "critical"),
        ("Diagnosis identifica critico", len(result.diagnosis.problema_principale) > 0),
        ("Actions presente", len(result.recommended_actions) > 0),
        ("Net profit negativo", result.kpi_snapshot.net_profit_eur < 0),
    ]
    
    for check_name, check_result in checks:
        log_test(check_name, check_result)
    
    print(f"\n  Output Quality:")
    print(f"    - Status: {result.status}")
    print(f"    - Net Profit: {result.kpi_snapshot.net_profit_eur}€")
    print(f"    - Urgency: ALTA")
    
except Exception as e:
    log_test("Scenario 3: Azienda critica", False, str(e))
    log_issue(f"Scenario critico fallisce: {e}", "alta", 2)

# =============================================================================
# FASE 3: JSON CONTRACT VALIDATION
# =============================================================================

log_phase(3, "JSON CONTRACT VALIDATION")

# Testa che risposta ha campi obbligatori
print(f"\n{BOLD}Validazione struttura JSON{END}")
try:
    result = analyze_company(
        fatturato=1_000_000,
        costi_variabili=250_000,
        costi_fissi=300_000,
        investimenti=100_000,
        company_name="Test",
        sector="saas"
    )
    
    required_fields = [
        "status", "headline", "summary", "diagnosis", "kpi_snapshot",
        "recommended_actions", "estimated_loss_eur", "potential_recovery_eur"
    ]
    
    for field in required_fields:
        has_field = hasattr(result, field) and getattr(result, field) is not None
        log_test(f"Campo '{field}' presente", has_field)
        if not has_field:
            log_issue(f"Campo mancante: {field}", "alta", 3)
    
    # Verifica tipi
    print(f"\n{BOLD}Validazione tipi{END}")
    type_checks = [
        ("status è string", isinstance(result.status, str)),
        ("recommended_actions è list", isinstance(result.recommended_actions, list)),
        ("kpi_snapshot è object", result.kpi_snapshot is not None),
        ("diagnosis è object", result.diagnosis is not None),
    ]
    
    for check_name, check_result in type_checks:
        log_test(check_name, check_result)
        if not check_result:
            log_issue(f"Type mismatch: {check_name}", "media", 3)
    
except Exception as e:
    log_test("Validazione JSON contract", False, str(e))
    log_issue(f"Errore validazione contract: {e}", "alta", 3)

# =============================================================================
# FASE 4: FALLBACK REALI
# =============================================================================

log_phase(4, "FALLBACK REALI")

print(f"\n{BOLD}Test fallback quando moduli falliscono{END}")

# Simula errore in cost_of_inaction
try:
    result = analyze_company(
        fatturato=1_000_000,
        costi_variabili=250_000,
        costi_fissi=300_000,
        investimenti=100_000,
        company_name="Test",
        sector="saas"
    )
    
    # Anche se cost_of_inaction fallisse, la risposta dovrebbe essere completa
    checks = [
        ("Sistema non crasha", result is not None),
        ("Risposta completa", result.headline is not None),
        ("Recommended actions presente", len(result.recommended_actions) > 0),
    ]
    
    for check_name, check_result in checks:
        log_test(check_name, check_result)
    
    print(f"  ✓ Fallback handling works correctly")
    
except Exception as e:
    log_test("Fallback resilience", False, str(e))
    log_issue(f"Sistema crasha con fallback: {e}", "alta", 4)

# =============================================================================
# FASE 5: PERFORMANCE BASE
# =============================================================================

log_phase(5, "PERFORMANCE BASE")

import time

print(f"\n{BOLD}Test latenza (10 richieste){END}")
try:
    times = []
    for i in range(10):
        start = time.time()
        result = analyze_company(
            fatturato=1_000_000 + i*10000,
            costi_variabili=250_000,
            costi_fissi=300_000,
            investimenti=100_000,
            company_name=f"Test{i}",
            sector="saas"
        )
        elapsed = time.time() - start
        times.append(elapsed)
        print(f"  Richiesta {i+1}: {elapsed:.3f}s")
    
    avg_time = sum(times) / len(times)
    max_time = max(times)
    
    log_test("Nessun crash", True)
    log_test("Latenza stabile", max_time < avg_time * 2)  # max non deve essere > 2x avg
    
    print(f"  Avg: {avg_time:.3f}s | Max: {max_time:.3f}s")
    
    if max_time > 5:
        log_issue(f"Latenza alta: {max_time}s", "media", 5)
    
except Exception as e:
    log_test("Performance test", False, str(e))
    log_issue(f"Performance test fallisce: {e}", "media", 5)

# =============================================================================
# FASE 6: ERROR HANDLING
# =============================================================================

log_phase(6, "ERROR HANDLING")

print(f"\n{BOLD}Test input sporchi{END}")

# Test negative revenue
try:
    from core.validators import validate_financial_inputs
    
    try:
        validate_financial_inputs(
            fatturato=-100_000,
            costi_variabili=50_000,
            costi_fissi=30_000
        )
        log_test("Rifiuta fatturato negativo", False)
        log_issue("Sistema accetta fatturato negativo", "alta", 6)
    except ValueError:
        log_test("Rifiuta fatturato negativo", True)
    except Exception as e:
        log_test("Rifiuta fatturato negativo (unexpected error)", False, str(e))
    
except Exception as e:
    log_test("Error handling test", False, str(e))

# =============================================================================
# FASE 7: DECISIONE OUTPUT QUALITY
# =============================================================================

log_phase(7, "DECISIONE OUTPUT QUALITY")

print(f"\n{BOLD}Verifica qualità decisioni UX{END}")
try:
    result = analyze_company(
        fatturato=500_000,
        costi_variabili=350_000,
        costi_fissi=200_000,
        investimenti=50_000,
        company_name="TestCorp",
        sector="retail"
    )
    
    # Checks per UX
    checks = [
        ("Headline è comprensibile", len(result.headline) > 10 and len(result.headline) < 200),
        ("Summary è dettagliato", len(result.summary) > 30),
        ("Azioni sono specifiche", all(len(a.title) > 5 for a in result.recommended_actions)),
        ("Impatti numerici presenti", all(a.impatto_euro >= 0 for a in result.recommended_actions)),
    ]
    
    for check_name, check_result in checks:
        log_test(check_name, check_result)
    
    print(f"\n  Headline: {result.headline}")
    print(f"  Status: {result.status}")
    if result.recommended_actions:
        print(f"  First action: {result.recommended_actions[0].title}")
    
except Exception as e:
    log_test("Output quality check", False, str(e))

# =============================================================================
# FASE 8: SUMMARY
# =============================================================================

log_phase(8, "SUMMARY FINALE")

print(f"\n{BOLD}Status Finale{END}")
print(f"  Critical Issues: {len(report['critical_issues'])}")
print(f"  Total Issues: {len(report['issues'])}")

if report['critical_issues']:
    print(f"\n{RED}CRITICAL ISSUES:{END}")
    for issue in report['critical_issues']:
        print(f"  - {issue}")

print(f"\n{BOLD}All Issues:{END}")
for issue in report['issues']:
    criticality_icon = "🔴" if issue['criticality'] == "alta" else "🟠" if issue['criticality'] == "media" else "🟡"
    print(f"  {criticality_icon} [{issue['criticality']}] {issue['issue']} (Phase {issue['phase']})")

# =============================================================================
# FINAL VERDICT
# =============================================================================

print(f"\n{BOLD}{'='*70}{END}")
if report['critical_issues']:
    print(f"{RED}STATUS: NEEDS FIXES BEFORE PILOT{END}")
    print(f"Critical issues found: {len(report['critical_issues'])}")
else:
    print(f"{GREEN}STATUS: READY FOR PILOT{END}")
    print("All critical checks passed!")

print(f"{BOLD}{'='*70}{END}\n")

# Save report
import json
with open("staging_validation_report.json", "w") as f:
    json.dump(report, f, indent=2, default=str)
print(f"Report saved to: staging_validation_report.json")
