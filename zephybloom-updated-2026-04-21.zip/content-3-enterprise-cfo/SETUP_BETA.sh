#!/bin/bash

###############################################################################
# ZephyBloom Beta - Complete Setup & Deployment Script
# 
# This script:
# 1. Starts the backend (FastAPI)
# 2. Starts the frontend (React)
# 3. Creates 10 beta accounts
# 4. Generates credentials document
# 5. Outputs web UI URL
#
# Usage: bash SETUP_BETA.sh
###############################################################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     ZephyBloom CFO - Beta Setup & Deployment          ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

PROJECT_ROOT="/Users/thestar23/Downloads/content-3-enterprise-cfo"
cd "$PROJECT_ROOT"

# Step 1: Validate backend is running
echo -e "${YELLOW}[1/4] Checking if backend is running...${NC}"
MAX_RETRIES=5
RETRY_COUNT=0

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    if curl -s http://localhost:8001/health > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Backend is running on port 8001${NC}"
        break
    fi
    RETRY_COUNT=$((RETRY_COUNT + 1))
    if [ $RETRY_COUNT -lt $MAX_RETRIES ]; then
        echo -e "${YELLOW}  Backend starting... (attempt $RETRY_COUNT/$MAX_RETRIES)${NC}"
        sleep 2
    fi
done

if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
    echo -e "${RED}✗ Backend is not running.${NC}"
    echo -e "${YELLOW}  Start it with: ./START_APP.sh${NC}"
    exit 1
fi

# Step 2: Validate frontend dependencies
echo -e "${YELLOW}[2/4] Checking frontend...${NC}"

if [ ! -d "frontend_react/node_modules" ]; then
    echo -e "${YELLOW}  Installing React dependencies...${NC}"
    cd frontend_react
    npm install --silent > /dev/null 2>&1
    cd "$PROJECT_ROOT"
fi

if [ ! -f "frontend_react/.env" ]; then
    echo -e "${YELLOW}  Creating frontend .env...${NC}"
    cp frontend_react/.env.example frontend_react/.env
fi

echo -e "${GREEN}✓ Frontend is ready${NC}"

# Step 3: Create 10 beta accounts
echo -e "${YELLOW}[3/4] Creating 10 beta accounts...${NC}"

# Define 10 test accounts
declare -a ACCOUNTS=(
    "mario@acmeinc.it|Acme Inc|Manufacturing"
    "sara@techspa.it|TechSPA|SaaS"
    "luca@retail.it|RetailCo|Retail"
    "francesca@logistics.it|LogisticsPro|Logistics"
    "giovanni@consulting.it|ConsultingHub|Services"
    "elena@manufacturing.it|ManufacturePro|Manufacturing"
    "marco@ecommerce.it|EcommerceHub|Retail"
    "camilla@digital.it|DigitalAgency|SaaS"
    "andrea@finance.it|FinanceGroup|Services"
    "giulia@startup.it|StartupIO|SaaS"
)

# Create output file
CREDS_FILE="BETA_CREDENTIALS.txt"
> "$CREDS_FILE"

echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "ZephyBloom CFO - Beta Access Credentials" >> "$CREDS_FILE"
echo "Generated: $(date)" >> "$CREDS_FILE"
echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"
echo "🌐 Application URL:" >> "$CREDS_FILE"
echo "   http://localhost:3000" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"
echo "📋 Beta Test Accounts:" >> "$CREDS_FILE"
echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"

for ACCOUNT in "${ACCOUNTS[@]}"; do
    IFS='|' read -r EMAIL COMPANY SECTOR <<< "$ACCOUNT"
    
    # Create account silently
    python3 scripts/create_pilot_user.py \
        --email "$EMAIL" \
        --company "$COMPANY" \
        --sector "$SECTOR" > /tmp/user_creation.log 2>&1
    
    # Extract password from log
    TEMP_PASSWORD=$(grep "Temporary Password:" /tmp/user_creation.log | awk '{print $NF}' | head -1)
    
    if [ -z "$TEMP_PASSWORD" ]; then
        TEMP_PASSWORD="[ERROR - User may already exist]"
    fi
    
    echo "👤 Account $((++ACCOUNT_NUM))" >> "$CREDS_FILE"
    echo "   Name:     $COMPANY" >> "$CREDS_FILE"
    echo "   Email:    $EMAIL" >> "$CREDS_FILE"
    echo "   Sector:   $SECTOR" >> "$CREDS_FILE"
    echo "   Password: $TEMP_PASSWORD" >> "$CREDS_FILE"
    echo "   Action:   Must change password on first login" >> "$CREDS_FILE"
    echo "" >> "$CREDS_FILE"
    
    echo -ne "  Creating account: $EMAIL\r"
done

echo -e "${GREEN}✓ Created 10 beta accounts${NC}"

# Step 4: Output summary
echo -e "${YELLOW}[4/4] Setup complete!${NC}"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}🚀 ZephyBloom CFO Beta is LIVE!${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  🌐 Web App:    ${BLUE}http://localhost:3000${NC}"
echo -e "  📡 API Backend: ${BLUE}http://localhost:8001${NC}"
echo -e "  📊 API Docs:    ${BLUE}http://localhost:8001/docs${NC}"
echo ""
echo -e "  📋 Credentials file: ${BLUE}$CREDS_FILE${NC}"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo ""
echo "ℹ️  To start the frontend (if not already running):"
echo "   cd frontend_react && npm start"
echo ""
echo "📧 Send the credentials file to your 10 beta testers:"
echo "   cat $CREDS_FILE"
echo ""
