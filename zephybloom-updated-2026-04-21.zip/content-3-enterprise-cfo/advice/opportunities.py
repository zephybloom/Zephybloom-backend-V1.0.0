# content/advice/opportunities.py
from __future__ import annotations

from typing import Any, Dict, List, Optional
from dataclasses import dataclass

# Import tollerante: usa i validator core oppure fallback utils
try:
    from core.validators import normalize_context_numeric
except Exception:  # pragma: no cover
    from utils.validators import normalize_context_numeric  # type: ignore

# Per coerenza con KPI / CCC
try:
    from core.kpi_engine import compute_ccc_and_wc
except Exception:  # pragma: no cover
    def compute_ccc_and_wc(
        sales: float,
        cogs: float,
        dso: float,
        dio: float,
        dpo: float,
        *,
        days_in_year: int = 365,
        wc_on_sales_share: float = 1.0,
        wc_on_cogs_share: float = 1.0,
    ):
        dso = max(0.0, float(dso or 0.0))
        dio = max(0.0, float(dio or 0.0))
        dpo = max(0.0, float(dpo or 0.0))
        ccc = dso + dio - dpo
        sales_day = sales / float(days_in_year) if sales > 0 else 0.0
        cogs_day = cogs / float(days_in_year) if cogs > 0 else 0.0
        wc_need = (
            wc_on_sales_share * sales_day * dso
            + wc_on_cogs_share * cogs_day * dio
            - wc_on_cogs_share * cogs_day * dpo
        )
        return ccc, max(0.0, wc_need)


# ============================================================
# Helpers
# ============================================================
def _asf(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v:  # NaN
            return default
        return v
    except Exception:
        return default


def _clamp_nonneg(x: float) -> float:
    return max(0.0, float(x or 0.0))


def _round2(x: float) -> float:
    return round(float(x or 0.0), 2)


def _safe_roi(delta_profit: float, invest: float) -> float:
    if invest and invest > 0:
        return (delta_profit / invest) * 100.0
    return 0.0


def _safe_margin(revenue: float, variable_cost: float) -> float:
    if revenue <= 0:
        return 0.0
    return max(0.0, (revenue - variable_cost) / revenue)


def _safe_qty_from_rev_price(revenue: float, price: float) -> float:
    if revenue <= 0 or price <= 0:
        return 0.0
    return revenue / price


def _safe_cvu_from_cv_qty(cv: float, qty: float) -> float:
    if cv <= 0 or qty <= 0:
        return 0.0
    return cv / qty


def _isoelastic_q(q0: float, p0: float, p: float, eps: float) -> float:
    """
    Modello isoelastico:
        Q = Q0 * (p/p0)^eps
    """
    if p0 <= 0 or q0 < 0:
        return max(0.0, q0)
    try:
        q = q0 * ((p / p0) ** eps)
        return max(0.0, q)
    except Exception:
        return max(0.0, q0)


def _sector_key(sector: Optional[str]) -> str:
    s = (sector or "").strip().lower()
    aliases = {
        "ristorazione": "restaurant",
        "ristorante": "restaurant",
        "pizzeria": "restaurant",
        "hotel": "hotel",
        "albergo": "hotel",
        "saas": "saas",
        "software": "saas",
        "ecommerce": "ecommerce",
        "e-commerce": "ecommerce",
        "retail": "retail",
        "agenzia": "agency",
        "agency": "agency",
        "servizi": "services",
        "service": "services",
        "consulenza": "services",
        "manifattura": "manufacturing",
        "industry": "manufacturing",
    }
    return aliases.get(s, s or "default")


def _priority_bucket(code: str) -> str:
    if code.startswith(("PRICE_", "MIX_", "UPSELL_", "NRR_", "SAAS_", "RETAIL_", "HOTEL_")):
        return "growth"
    if code.startswith(("CVAR_", "CFIX_", "RESTAURANT_", "SERVICES_")):
        return "efficiency"
    if code.startswith(("CCC_",)):
        return "cash"
    return "general"


def _opportunity_quality_score(
    *,
    delta_profit: float,
    delta_roi_pct: float,
    bucket: str,
) -> float:
    """
    Score sintetico per ordinare:
    - profitto pesa di più
    - ROI aiuta a parità di profitto
    - bucket cash non vince su profitto ma resta rilevante
    """
    score = float(delta_profit)
    score += float(delta_roi_pct) * 100.0

    if bucket == "cash":
        score += 2_500.0
    elif bucket == "growth":
        score += 1_500.0
    elif bucket == "efficiency":
        score += 1_000.0

    return score


# ============================================================
# Modelli
# ============================================================
@dataclass
class Opportunity:
    code: str
    title: str
    delta_profit: float
    delta_roi_pct: float
    steps: List[str]
    meta: Optional[Dict[str, Any]] = None


# ============================================================
# Engine
# ============================================================
class OpportunityEngine:
    """
    Engine opportunità:
    - prezzo
    - costi variabili
    - costi fissi
    - mix / upsell
    - cassa / CCC
    - leve specifiche per settore
    """

    def __init__(self, sector: str | None = None):
        self.sector = _sector_key(sector)

    def generate(self, base: Dict[str, Any], elasticity: float = -1.2) -> List[Opportunity]:
        b = normalize_context_numeric(base or {})

        # =========================
        # Base economica
        # =========================
        rev = _clamp_nonneg(_asf(b.get("fatturato") or b.get("sales") or b.get("ricavi")))
        cv = _clamp_nonneg(_asf(b.get("costi_variabili") or b.get("cogs")))
        cf = _clamp_nonneg(_asf(b.get("costi_fissi")))
        invest = _clamp_nonneg(_asf(b.get("investimenti")))
        amm = _clamp_nonneg(_asf(b.get("ammortamenti")))

        p0 = _clamp_nonneg(_asf(b.get("prezzo_medio")))
        cvu = _clamp_nonneg(_asf(b.get("costo_variabile_unitario")))
        q0 = _safe_qty_from_rev_price(rev, p0)
        if cvu <= 0.0 and q0 > 0.0:
            cvu = _safe_cvu_from_cv_qty(cv, q0)

        dso = _clamp_nonneg(_asf(b.get("dso")))
        dio = _clamp_nonneg(_asf(b.get("dio")))
        dpo = _clamp_nonneg(_asf(b.get("dpo")))

        ltv = _clamp_nonneg(_asf(b.get("ltv")))
        cac = _clamp_nonneg(_asf(b.get("cac")))
        arpu = _clamp_nonneg(_asf(b.get("arpu") or b.get("avg_ticket") or b.get("ticket_medio")))
        churn = _clamp_nonneg(_asf(b.get("churn_rate")))
        nrr = _clamp_nonneg(_asf(b.get("nrr")))

        utile0 = rev - cv - cf
        ebitda0 = utile0 + amm
        mc0 = rev - cv
        mc_rate0 = _safe_margin(rev, cv)

        out: List[Opportunity] = []

        # ============================================================
        # 1) Prezzo +1%
        # ============================================================
        if p0 > 0.0 and rev > 0.0 and cvu >= 0.0:
            p1 = p0 * 1.01
            if p1 > cvu:
                q1 = _isoelastic_q(q0, p0, p1, elasticity)
                rev1 = p1 * q1
                cv1 = cvu * q1 if cvu > 0 else cv
                utile1 = rev1 - cv1 - cf
                delta = max(0.0, utile1 - utile0)

                out.append(
                    Opportunity(
                        code="PRICE_UP_1",
                        title="Aumenta prezzo medio dell’1%",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Segmenta i clienti meno sensibili al prezzo",
                            "Testa il nuovo listino su un cluster limitato",
                            "Monitora conversione, volume e margine per 2–4 settimane",
                        ],
                        meta={
                            "bucket": "growth",
                            "price_before": _round2(p0),
                            "price_after": _round2(p1),
                            "qty_before": _round2(q0),
                            "qty_after": _round2(q1),
                            "revenue_before": _round2(rev),
                            "revenue_after": _round2(rev1),
                        },
                    )
                )

        # ============================================================
        # 2) Mix / premium tier +3%
        # ============================================================
        if p0 > 0.0 and rev > 0.0 and cvu >= 0.0:
            p2 = p0 * 1.03
            eps_soft = elasticity * 0.7
            if p2 > cvu:
                q2 = _isoelastic_q(q0, p0, p2, eps_soft)
                rev2 = p2 * q2
                cv2 = cvu * q2 if cvu > 0 else cv
                utile2 = rev2 - cv2 - cf
                delta2 = max(0.0, utile2 - utile0)

                out.append(
                    Opportunity(
                        code="MIX_UP_3",
                        title="Migliora mix / premium tier (+3% prezzo effettivo)",
                        delta_profit=_round2(delta2),
                        delta_roi_pct=_round2(_safe_roi(delta2, invest)),
                        steps=[
                            "Spingi bundle o pacchetti premium",
                            "Riposiziona l’offerta su valore e outcome",
                            "Riduci sconti sui clienti già ad alta conversione",
                        ],
                        meta={
                            "bucket": "growth",
                            "price_before": _round2(p0),
                            "price_after": _round2(p2),
                            "elasticity_used": _round2(eps_soft),
                        },
                    )
                )

        # ============================================================
        # 3) CV -2%
        # ============================================================
        if cv > 0.0:
            benefit = max(0.0, 0.02 * cv)
            out.append(
                Opportunity(
                    code="CVAR_DOWN_2",
                    title="Riduci costi variabili del 2%",
                    delta_profit=_round2(benefit),
                    delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                    steps=[
                        "Apri una mini-RFP sui fornitori principali",
                        "Standardizza processo / delivery",
                        "Riduci scarti, resi e inefficienze operative",
                    ],
                    meta={
                        "bucket": "efficiency",
                        "cv_base": _round2(cv),
                    },
                )
            )

        # ============================================================
        # 4) CV -5% su sourcing / scarti
        # ============================================================
        if cv > 0.0 and mc_rate0 < 0.55:
            benefit = max(0.0, 0.05 * cv)
            out.append(
                Opportunity(
                    code="CVAR_DOWN_5",
                    title="Riduci costi variabili del 5% su sourcing e scarti",
                    delta_profit=_round2(benefit),
                    delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                    steps=[
                        "Mappa top 20% voci di costo variabile",
                        "Rinegozia listini e condizioni minime d’ordine",
                        "Introduce controllo scarti / sprechi settimanale",
                    ],
                    meta={
                        "bucket": "efficiency",
                        "cv_base": _round2(cv),
                    },
                )
            )

        # ============================================================
        # 5) CF -5%
        # ============================================================
        if cf > 0.0:
            benefit = max(0.0, 0.05 * cf)
            out.append(
                Opportunity(
                    code="CFIX_DOWN_5",
                    title="Taglia costi fissi del 5%",
                    delta_profit=_round2(benefit),
                    delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                    steps=[
                        "Audit costi fissi per funzione",
                        "Rinegozia software, contratti e servizi non core",
                        "Trasforma parte della struttura da fissa a variabile",
                    ],
                    meta={
                        "bucket": "efficiency",
                        "cf_base": _round2(cf),
                    },
                )
            )

        # ============================================================
        # 6) CF -10% se struttura pesante
        # ============================================================
        if cf > 0.0 and rev > 0.0 and (cf / rev) > 0.30:
            benefit = max(0.0, 0.10 * cf)
            out.append(
                Opportunity(
                    code="CFIX_DOWN_10",
                    title="Alleggerisci struttura fissa del 10%",
                    delta_profit=_round2(benefit),
                    delta_roi_pct=_round2(_safe_roi(benefit, invest)),
                    steps=[
                        "Taglia attività a basso valore",
                        "Accorpa ruoli o processi duplicati",
                        "Sposta parte dell’operatività su modelli più flessibili",
                    ],
                    meta={
                        "bucket": "efficiency",
                        "cf_share_on_revenue": _round2(cf / rev),
                    },
                )
            )

        # ============================================================
        # 7) CCC -15 giorni
        # ============================================================
        if (dso + dio + dpo) > 0.0 and rev > 0.0:
            ccc0, wc0 = compute_ccc_and_wc(rev, cv, dso, dio, dpo)
            dso1 = max(0.0, dso - 15.0)
            ccc1, wc1 = compute_ccc_and_wc(rev, cv, dso1, dio, dpo)
            delta_cash = max(0.0, wc0 - wc1)

            out.append(
                Opportunity(
                    code="CCC_DOWN_15",
                    title="Riduci ciclo cassa (CCC) di 15 giorni",
                    delta_profit=0.0,
                    delta_roi_pct=0.0,
                    steps=[
                        "Accelera incassi con reminder e policy chiare",
                        "Riduci stock lento o fermo",
                        "Allunga DPO dove sostenibile senza stressare i fornitori",
                    ],
                    meta={
                        "bucket": "cash",
                        "ccc_before": _round2(ccc0),
                        "ccc_after": _round2(ccc1),
                        "delta_cash": _round2(delta_cash),
                    },
                )
            )

        # ============================================================
        # 8) Upsell / ARPU
        # ============================================================
        if rev > 0.0 and (arpu > 0.0 or self.sector in {"saas", "services", "agency"}):
            uplift = 0.08
            delta = max(0.0, (rev * uplift * mc_rate0))
            out.append(
                Opportunity(
                    code="UPSELL_ARPU_8",
                    title="Aumenta ARPU con upsell / bundle (+8% ricavi da base clienti)",
                    delta_profit=_round2(delta),
                    delta_roi_pct=_round2(_safe_roi(delta, invest)),
                    steps=[
                        "Disegna una scala di valore chiara",
                        "Proponi bundle o upgrade ai clienti attivi",
                        "Attiva trigger di upsell legati a utilizzo o maturità",
                    ],
                    meta={
                        "bucket": "growth",
                        "revenue_uplift_pct": 8.0,
                    },
                )
            )

        # ============================================================
        # 9) Retention / churn
        # ============================================================
        if churn > 0.0 and churn >= 0.04:
            retention_gain = min(0.02, churn * 0.25)
            delta = max(0.0, rev * retention_gain * mc_rate0)
            out.append(
                Opportunity(
                    code="CHURN_DOWN",
                    title="Riduci churn e aumenta retention",
                    delta_profit=_round2(delta),
                    delta_roi_pct=_round2(_safe_roi(delta, invest)),
                    steps=[
                        "Rafforza onboarding e quick wins",
                        "Segmenta clienti a rischio",
                        "Attiva customer success o follow-up proattivi",
                    ],
                    meta={
                        "bucket": "growth",
                        "churn_rate": _round2(churn),
                    },
                )
            )

        # ============================================================
        # 10) NRR / espansione account
        # ============================================================
        if nrr > 0.0 and nrr < 1.05:
            expansion_gain = 0.05
            delta = max(0.0, rev * expansion_gain * mc_rate0)
            out.append(
                Opportunity(
                    code="NRR_EXPANSION",
                    title="Espandi il valore della base clienti esistente",
                    delta_profit=_round2(delta),
                    delta_roi_pct=_round2(_safe_roi(delta, invest)),
                    steps=[
                        "Monitora cohort e clienti maturi",
                        "Costruisci offerte premium o moduli extra",
                        "Attiva review periodiche per account growth",
                    ],
                    meta={
                        "bucket": "growth",
                        "nrr": _round2(nrr),
                    },
                )
            )

        # ============================================================
        # 11) Migliora EBITDA operativo
        # ============================================================
        if ebitda0 > 0.0 and rev > 0.0 and mc_rate0 < 0.40:
            delta = max(0.0, rev * 0.02 * mc_rate0)
            out.append(
                Opportunity(
                    code="EBITDA_QUALITY",
                    title="Migliora la qualità dell’EBITDA operativo",
                    delta_profit=_round2(delta),
                    delta_roi_pct=_round2(_safe_roi(delta, invest)),
                    steps=[
                        "Elimina ricavi poco profittevoli",
                        "Proteggi il margine sui clienti migliori",
                        "Riduci eccezioni operative che erodono contribuzione",
                    ],
                    meta={
                        "bucket": "efficiency",
                        "ebitda_base": _round2(ebitda0),
                        "mc_rate_base": _round2(mc_rate0),
                    },
                )
            )

        # ============================================================
        # Leve specifiche per settore
        # ============================================================
        out.extend(
            self._sector_specific_opportunities(
                rev=rev,
                cv=cv,
                cf=cf,
                invest=invest,
                mc_rate=mc_rate0,
                utile0=utile0,
            )
        )

        # ============================================================
        # Ordinamento finale
        # ============================================================
        deduped: List[Opportunity] = []
        seen = set()
        for o in out:
            if o.code in seen:
                continue
            seen.add(o.code)
            deduped.append(o)

        deduped.sort(
            key=lambda o: _opportunity_quality_score(
                delta_profit=_asf(o.delta_profit),
                delta_roi_pct=_asf(o.delta_roi_pct),
                bucket=_priority_bucket(o.code),
            ),
            reverse=True,
        )

        return deduped

    # ============================================================
    # Settori
    # ============================================================
    def _sector_specific_opportunities(
        self,
        *,
        rev: float,
        cv: float,
        cf: float,
        invest: float,
        mc_rate: float,
        utile0: float,
    ) -> List[Opportunity]:
        out: List[Opportunity] = []

        if self.sector == "restaurant":
            if cv > 0:
                delta = max(0.0, 0.03 * cv)
                out.append(
                    Opportunity(
                        code="RESTAURANT_FOODCOST",
                        title="Riduci food cost e sprechi di cucina",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Analizza menu engineering",
                            "Taglia scarti e porzioni incoerenti",
                            "Rinegozia materie prime ad alto impatto",
                        ],
                        meta={"bucket": "efficiency", "sector": "restaurant"},
                    )
                )

        elif self.sector == "hotel":
            if rev > 0:
                delta = max(0.0, rev * 0.03 * mc_rate)
                out.append(
                    Opportunity(
                        code="HOTEL_RATE_MIX",
                        title="Ottimizza rate plan e mix occupazione",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Rivedi pricing per giorno / canale",
                            "Spingi camere e servizi ad alta marginalità",
                            "Riduci dipendenza dai canali più costosi",
                        ],
                        meta={"bucket": "growth", "sector": "hotel"},
                    )
                )

        elif self.sector == "saas":
            if rev > 0:
                delta = max(0.0, rev * 0.06 * mc_rate)
                out.append(
                    Opportunity(
                        code="SAAS_EXPANSION",
                        title="Aumenta MRR con upsell e retention strutturata",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Segmenta clienti per utilizzo",
                            "Attiva annualizzazioni e feature gating",
                            "Costruisci piano di expansion revenue",
                        ],
                        meta={"bucket": "growth", "sector": "saas"},
                    )
                )

        elif self.sector in {"agency", "services"}:
            if cf > 0:
                delta = max(0.0, 0.04 * cf)
                out.append(
                    Opportunity(
                        code="SERVICES_UTILIZATION",
                        title="Aumenta utilization e riduci tempo non fatturabile",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Monitora utilization per persona",
                            "Standardizza delivery e handoff",
                            "Taglia attività interne non monetizzate",
                        ],
                        meta={"bucket": "efficiency", "sector": self.sector},
                    )
                )

        elif self.sector in {"retail", "ecommerce"}:
            if rev > 0:
                delta = max(0.0, rev * 0.025 * mc_rate)
                out.append(
                    Opportunity(
                        code="RETAIL_MIX",
                        title="Spingi SKU ad alto margine e riduci promo erosive",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Analizza margine per SKU",
                            "Taglia sconti sui prodotti già forti",
                            "Aumenta visibilità agli articoli ad alta marginalità",
                        ],
                        meta={"bucket": "growth", "sector": self.sector},
                    )
                )

        elif self.sector == "manufacturing":
            if cv > 0:
                delta = max(0.0, 0.04 * cv)
                out.append(
                    Opportunity(
                        code="MANUFACTURING_PROCUREMENT",
                        title="Riduci costo industriale e migliora sourcing",
                        delta_profit=_round2(delta),
                        delta_roi_pct=_round2(_safe_roi(delta, invest)),
                        steps=[
                            "Analizza BOM e costo per componente",
                            "Rinegozia materie prime ad alta incidenza",
                            "Riduci scarti e micro-fermi di produzione",
                        ],
                        meta={"bucket": "efficiency", "sector": "manufacturing"},
                    )
                )

        return out


# ============================================================
# Formatter
# ============================================================
def format_opportunity(o: Opportunity) -> str:
    return (
        f"{o.title} — ΔUtile atteso € {o.delta_profit:,.0f}, "
        f"ΔROI {o.delta_roi_pct:.1f}% | "
        f"Passi: {'; '.join(o.steps)}"
    )