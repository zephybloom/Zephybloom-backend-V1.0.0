# -*- coding: utf-8 -*-
"""
content/nlp/memory.py — Conversational + Business Memory (scalata e persistente)

Obiettivi:
- Unisce short-term conversational memory (finestra ultimi messaggi) con long-term business memory
  (facts, preferenze, soglie, obiettivi, storico KPI ed eventi) in un'unica classe.
- API retro-compatibili con il file precedente, con feature aggiuntive:
  persistenza su disco (JSON), thresholds, goals, KPI history, eventi,
  redazione PII, TTL, trimming, merge sessioni, thread-safety.
- Zero dipendenze esterne (opzionale: usa LLMClient se presente per i riassunti).
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any
from time import time
import re
import json
import os
import tempfile
from pathlib import Path
import datetime as dt
import threading

# Import opzionale del wrapper LLM
try:  # pragma: no cover
    from llm.client import LLMClient, LLMMessage  # type: ignore
except Exception:  # pragma: no cover
    LLMClient = None  # type: ignore
    LLMMessage = None  # type: ignore

ISO_FORMAT = "%Y-%m-%dT%H:%M:%S%z"


def _now_iso() -> str:
    try:
        return dt.datetime.now(dt.timezone.utc).astimezone().strftime(ISO_FORMAT)
    except Exception:
        return dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


# -----------------------------
# Modelli base
# -----------------------------
@dataclass
class Message:
    role: str   # "user" | "assistant" | "system"
    content: str
    ts: float = field(default_factory=time)


@dataclass
class _SummaryCache:
    text: str = ""
    ts: float = 0.0
    window_size: int = 0


# -----------------------------
# MemoryStore
# -----------------------------
class MemoryStore:
    """Conversational + Business Memory con persistenza sicura (JSON)."""

    _EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
    _PHONE = re.compile(r"\+?\d[\d\s\-().]{6,}\d")
    _IBAN = re.compile(r"[A-Z]{2}\d{2}[A-Z0-9]{11,30}")

    def __init__(
        self,
        path: str | Path = "content/db/memory.json",
        *,
        autosave: bool = True,
        max_messages: int = 20,
        message_ttl_s: Optional[int] = None,
        max_chars_per_msg: int = 1200,
        redact_basic_pii: bool = True,
        max_kpi_history: int = 500,
        max_events: int = 1000,
    ) -> None:
        self.path = Path(path)
        self.autosave = bool(autosave)
        self.max_messages = max(1, int(max_messages))
        self.message_ttl_s = int(message_ttl_s) if message_ttl_s is not None else None
        self.max_chars_per_msg = max(50, int(max_chars_per_msg))
        self.redact_basic_pii = bool(redact_basic_pii)
        self.max_kpi_history = max(1, int(max_kpi_history))
        self.max_events = max(1, int(max_events))

        self._lock = threading.RLock()

        # short-term
        self._messages: Dict[str, List[Message]] = {}
        self._summary: Dict[str, _SummaryCache] = {}

        # long-term
        self._facts: Dict[str, Dict[str, str]] = {}
        self._pinned: Dict[str, Dict[str, str]] = {}
        self._thresholds: Dict[str, Dict[str, float]] = {}
        self._goals: Dict[str, List[Dict[str, Any]]] = {}
        self._kpi_history: Dict[str, List[Dict[str, Any]]] = {}
        self._events: Dict[str, List[Dict[str, Any]]] = {}

        self._data: Dict[str, Any] = {"version": "2", "sessions": {}}

        with self._lock:
            try:
                self._ensure_parent()
                if self.path.exists():
                    self._data = self._safe_load(self.path)
                self._inflate_from_data()
            except Exception:
                self._data = {"version": "2", "sessions": {}}

    # -------------------------
    # Persistenza
    # -------------------------
    def save(self) -> None:
        with self._lock:
            self._deflate_to_data()
            self._safe_save(self.path, self._data)

    def _commit(self) -> None:
        if self.autosave:
            try:
                self.save()
            except Exception:
                pass

    def _ensure_parent(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def _inflate_from_data(self) -> None:
        raw_sessions = (self._data or {}).get("sessions", {})
        if not isinstance(raw_sessions, dict):
            return

        for sid, blob in raw_sessions.items():
            try:
                msgs: List[Message] = []
                for m in (blob.get("messages") or []):
                    msgs.append(
                        Message(
                            role=str(m.get("role", "user")),
                            content=str(m.get("content", "")),
                            ts=float(m.get("ts", time())),
                        )
                    )
                self._messages[sid] = msgs[-self.max_messages:]

                s = blob.get("summary") or {}
                if isinstance(s, dict) and s:
                    self._summary[sid] = _SummaryCache(
                        text=str(s.get("text", "")),
                        ts=float(s.get("ts", time())),
                        window_size=int(s.get("window_size", 0)),
                    )

                self._facts[sid] = {str(k): str(v) for k, v in (blob.get("facts") or {}).items()}
                self._pinned[sid] = {str(k): str(v) for k, v in (blob.get("pinned") or {}).items()}
                self._thresholds[sid] = {str(k): float(v) for k, v in (blob.get("thresholds") or {}).items()}
                self._goals[sid] = list(blob.get("goals") or [])
                self._kpi_history[sid] = list(blob.get("kpi_history") or [])[-self.max_kpi_history:]
                self._events[sid] = list(blob.get("events") or [])[-self.max_events:]
            except Exception:
                continue

    def _deflate_to_data(self) -> None:
        sessions: Dict[str, Any] = {}
        all_keys = set(
            list(self._messages.keys())
            + list(self._facts.keys())
            + list(self._pinned.keys())
            + list(self._thresholds.keys())
            + list(self._goals.keys())
            + list(self._kpi_history.keys())
            + list(self._events.keys())
        )

        for sid in all_keys:
            try:
                sessions[sid] = {
                    "messages": [
                        {"role": m.role, "content": m.content, "ts": float(m.ts)}
                        for m in self._messages.get(sid, [])
                    ][-self.max_messages:],
                    "summary": asdict(self._summary[sid]) if sid in self._summary else None,
                    "facts": dict(self._facts.get(sid, {})),
                    "pinned": dict(self._pinned.get(sid, {})),
                    "thresholds": dict(self._thresholds.get(sid, {})),
                    "goals": list(self._goals.get(sid, [])),
                    "kpi_history": list(self._kpi_history.get(sid, []))[-self.max_kpi_history:],
                    "events": list(self._events.get(sid, []))[-self.max_events:],
                }
            except Exception:
                continue

        self._data = {"version": "2", "sessions": sessions}

    @staticmethod
    def _safe_load(path: Path) -> Dict[str, Any]:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return {"version": "2", "sessions": {}}

    @staticmethod
    def _safe_save(path: Path, data: Dict[str, Any]) -> None:
        tmp_dir = path.parent
        try:
            tmp_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        try:
            with tempfile.NamedTemporaryFile("w", delete=False, dir=str(tmp_dir), encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
                fh.flush()
                os.fsync(fh.fileno())
                tmp_name = fh.name
            os.replace(tmp_name, path)
        except Exception:
            try:
                with open(path, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, ensure_ascii=False, indent=2)
            except Exception:
                pass

    # -------------------------
    # Utility interne
    # -------------------------
    def _redact(self, text: str) -> str:
        if not self.redact_basic_pii or not text:
            return text
        t = self._EMAIL.sub("[email]", text)
        t = self._PHONE.sub("[phone]", t)
        t = self._IBAN.sub("[iban]", t)
        return t

    def _trim_content(self, content: str) -> str:
        if not content:
            return ""
        c = str(content).strip()
        if self.max_chars_per_msg and len(c) > self.max_chars_per_msg:
            return c[: self.max_chars_per_msg] + " …"
        return c

    def _purge_expired(self, session_id: str) -> None:
        if self.message_ttl_s is None:
            return
        arr = self._messages.get(session_id, [])
        if not arr:
            return
        now = time()
        kept = [m for m in arr if (now - float(m.ts)) <= self.message_ttl_s]
        if len(kept) != len(arr):
            self._messages[session_id] = kept
            self._summary.pop(session_id, None)

    def _window(self, session_id: str, n: int) -> List[Message]:
        arr = list(self._messages.get(session_id, []))
        if n <= 0:
            return []
        return arr[-n:]

    def _invalidate_summary(self, session_id: str) -> None:
        self._summary.pop(session_id, None)

    def _ensure_session(self, session_id: str) -> None:
        self._messages.setdefault(session_id, [])
        self._facts.setdefault(session_id, {})
        self._pinned.setdefault(session_id, {})
        self._thresholds.setdefault(session_id, {})
        self._goals.setdefault(session_id, [])
        self._kpi_history.setdefault(session_id, [])
        self._events.setdefault(session_id, [])

    # -------------------------
    # Messaggi (Short-term)
    # -------------------------
    def append_message(self, session_id: str, *, role: str, content: str) -> None:
        with self._lock:
            role = (role or "").strip().lower()
            if role not in {"user", "assistant", "system"}:
                role = "user"

            content = self._trim_content(content)
            if self.redact_basic_pii:
                content = self._redact(content)

            self._ensure_session(session_id)
            arr = self._messages[session_id]
            arr.append(Message(role=role, content=content))
            if len(arr) > self.max_messages:
                self._messages[session_id] = arr[-self.max_messages:]

            self._purge_expired(session_id)
            self._invalidate_summary(session_id)
            self._commit()

    def get_window(self, session_id: str, n: int = 10) -> List[Message]:
        with self._lock:
            self._purge_expired(session_id)
            return list(self._window(session_id, n))

    def last_user_message(self, session_id: str) -> Optional[str]:
        with self._lock:
            self._purge_expired(session_id)
            for m in reversed(self._messages.get(session_id, [])):
                if m.role == "user":
                    return m.content
            return None

    def last_assistant_message(self, session_id: str) -> Optional[str]:
        with self._lock:
            self._purge_expired(session_id)
            for m in reversed(self._messages.get(session_id, [])):
                if m.role == "assistant":
                    return m.content
            return None

    def clear_messages(self, session_id: str) -> None:
        with self._lock:
            self._messages.pop(session_id, None)
            self._summary.pop(session_id, None)
            self._commit()

    def forget(self, session_id: str) -> None:
        with self._lock:
            self._messages.pop(session_id, None)
            self._facts.pop(session_id, None)
            self._pinned.pop(session_id, None)
            self._thresholds.pop(session_id, None)
            self._goals.pop(session_id, None)
            self._kpi_history.pop(session_id, None)
            self._events.pop(session_id, None)
            self._summary.pop(session_id, None)
            self._commit()

    def clear_business_memory(self, session_id: str) -> None:
        with self._lock:
            self._facts.pop(session_id, None)
            self._pinned.pop(session_id, None)
            self._thresholds.pop(session_id, None)
            self._goals.pop(session_id, None)
            self._kpi_history.pop(session_id, None)
            self._events.pop(session_id, None)
            self._commit()

    # -------------------------
    # Facts / Prefs / Thresholds / Goals
    # -------------------------
    def get_facts(self, session_id: str) -> Dict[str, str]:
        with self._lock:
            facts = dict(self._pinned.get(session_id, {}))
            facts.update(self._facts.get(session_id, {}))
            return facts

    def update_facts(self, session_id: str, facts: Dict[str, str]) -> None:
        with self._lock:
            self._ensure_session(session_id)
            cur = self._facts[session_id]
            for k, v in (facts or {}).items():
                if v is None:
                    cur.pop(str(k), None)
                else:
                    cur[str(k)] = str(v)
            self._commit()

    def set_fact(self, session_id: str, key: str, value: str, *, pinned: bool = False) -> None:
        with self._lock:
            self._ensure_session(session_id)
            if pinned:
                self._pinned[session_id][str(key)] = str(value)
            else:
                self._facts[session_id][str(key)] = str(value)
            self._commit()

    def delete_fact(self, session_id: str, key: str) -> None:
        with self._lock:
            self._facts.setdefault(session_id, {}).pop(str(key), None)
            self._pinned.setdefault(session_id, {}).pop(str(key), None)
            self._commit()

    def set_threshold(self, session_id: str, metric: str, value: float) -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._thresholds[session_id][str(metric)] = float(value)
            self._commit()

    def get_threshold(self, session_id: str, metric: str, default: Optional[float] = None) -> Optional[float]:
        with self._lock:
            v = self._thresholds.get(session_id, {}).get(str(metric))
            return float(v) if v is not None else default

    def set_goal(self, session_id: str, metric: str, target: float, horizon: str = "12m", note: str = "") -> None:
        with self._lock:
            self._ensure_session(session_id)
            self._goals[session_id].append(
                {
                    "metric": str(metric),
                    "target": float(target),
                    "horizon": str(horizon),
                    "note": str(note or ""),
                    "ts": _now_iso(),
                }
            )
            self._commit()

    def goals(self, session_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._goals.get(session_id, []))

    # -------------------------
    # Company helpers
    # -------------------------
    def remember_company(self, session_id: str, *, name: Optional[str] = None, sector: Optional[str] = None) -> None:
        if name:
            self.set_fact(session_id, "company_name", str(name), pinned=True)
        if sector:
            self.set_fact(session_id, "company_sector", str(sector), pinned=True)
            self.set_fact(session_id, "sector", str(sector), pinned=False)

    def summary_view(self, session_id: str) -> Dict[str, Any]:
        with self._lock:
            facts = self.get_facts(session_id)
            company = {
                "name": facts.get("company_name") or facts.get("ragione_sociale") or "",
                "sector": facts.get("company_sector") or facts.get("sector") or "",
            }
            return {
                "company": company,
                "thresholds": dict(self._thresholds.get(session_id, {})),
                "goals": list(self._goals.get(session_id, [])),
                "last_kpi": self.last_kpi(session_id),
            }

    # -------------------------
    # KPI history & Events
    # -------------------------
    def record_kpi(self, session_id: str, kpi: Dict[str, Any], ts: Optional[str] = None) -> None:
        with self._lock:
            self._ensure_session(session_id)
            snap = {"ts": ts or _now_iso(), "data": dict(kpi or {})}
            arr = self._kpi_history[session_id]
            arr.append(snap)
            if len(arr) > self.max_kpi_history:
                self._kpi_history[session_id] = arr[-self.max_kpi_history:]
            self._commit()

    def last_kpi(self, session_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            hist = self._kpi_history.get(session_id, [])
            if not hist:
                return None
            return dict(hist[-1])

    def push_event(self, session_id: str, etype: str, payload: Optional[Dict[str, Any]] = None) -> None:
        with self._lock:
            self._ensure_session(session_id)
            arr = self._events[session_id]
            arr.append(
                {
                    "ts": _now_iso(),
                    "type": str(etype),
                    "payload": dict(payload or {}),
                }
            )
            if len(arr) > self.max_events:
                self._events[session_id] = arr[-self.max_events:]
            self._commit()

    def history(self, session_id: str, kind: str = "kpi", limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            if kind == "kpi":
                arr = self._kpi_history.get(session_id, [])
            elif kind == "events":
                arr = self._events.get(session_id, [])
            else:
                return []
            return list(arr[-max(1, int(limit)):])

    def get_events_by_type(self, session_id: str, etype: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            arr = self._events.get(session_id, [])
            filt = [e for e in arr if str(e.get("type", "")) == str(etype)]
            return filt[-max(1, int(limit)):]

    # -------------------------
    # Merge sessioni
    # -------------------------
    def merge_sessions(self, source_session_id: str, target_session_id: str, *, forget_source: bool = False) -> None:
        with self._lock:
            if source_session_id == target_session_id:
                return

            self._ensure_session(target_session_id)

            # messages
            merged_msgs = list(self._messages.get(target_session_id, [])) + list(self._messages.get(source_session_id, []))
            merged_msgs = sorted(merged_msgs, key=lambda x: float(x.ts))[-self.max_messages:]
            self._messages[target_session_id] = merged_msgs

            # facts / pinned / thresholds
            self._facts[target_session_id].update(self._facts.get(source_session_id, {}))
            self._pinned[target_session_id].update(self._pinned.get(source_session_id, {}))
            self._thresholds[target_session_id].update(self._thresholds.get(source_session_id, {}))

            # goals
            self._goals[target_session_id].extend(self._goals.get(source_session_id, []))

            # history
            self._kpi_history[target_session_id] = (
                list(self._kpi_history.get(target_session_id, []))
                + list(self._kpi_history.get(source_session_id, []))
            )[-self.max_kpi_history:]

            self._events[target_session_id] = (
                list(self._events.get(target_session_id, []))
                + list(self._events.get(source_session_id, []))
            )[-self.max_events:]

            self._invalidate_summary(target_session_id)

            if forget_source:
                self.forget(source_session_id)
            else:
                self._commit()

    # -------------------------
    # Summarizer
    # -------------------------
    def summarize(self, session_id: str, client: Optional["LLMClient"] = None) -> str:
        with self._lock:
            self._purge_expired(session_id)
            msgs = self.get_window(session_id, n=self.max_messages)
            if not msgs:
                return ""

            cache = self._summary.get(session_id)
            if cache and cache.window_size == len(msgs) and (time() - cache.ts) < 60.0:
                return cache.text

            text = "\n".join([f"{m.role}: {m.content}" for m in msgs])

            if client is not None and LLMClient is not None and LLMMessage is not None:
                try:
                    prompt = "Riassumi in 5 bullet il seguente dialogo CFO in italiano, includendo numeri chiave (€ e %) quando presenti."
                    out = client.generate(
                        [
                            LLMMessage(role="system", content="Sei un assistente CFO. Stile: sintetico, numerico, consulenziale."),
                            LLMMessage(role="user", content=f"{prompt}\n\n---\n{text}\n---"),
                        ],
                        max_tokens=250,
                    )
                    summary = (out or "").strip()
                    self._summary[session_id] = _SummaryCache(
                        text=summary,
                        ts=time(),
                        window_size=len(msgs),
                    )
                    self._commit()
                    return summary
                except Exception:
                    pass

            lines = [l for l in text.splitlines() if any(c in l for c in "€%0123456789")]
            if not lines:
                lines = text.splitlines()[-5:]
            summary = "\n".join(lines[:5]).strip()

            self._summary[session_id] = _SummaryCache(
                text=summary,
                ts=time(),
                window_size=len(msgs),
            )
            self._commit()
            return summary

    # -------------------------
    # Export / Import
    # -------------------------
    def export_state(self, session_id: str) -> Dict[str, Any]:
        with self._lock:
            return {
                "messages": [
                    {"role": m.role, "content": m.content, "ts": float(m.ts)}
                    for m in self._messages.get(session_id, [])
                ],
                "facts": dict(self._facts.get(session_id, {})),
                "pinned": dict(self._pinned.get(session_id, {})),
                "thresholds": dict(self._thresholds.get(session_id, {})),
                "goals": list(self._goals.get(session_id, [])),
                "kpi_history": list(self._kpi_history.get(session_id, [])),
                "events": list(self._events.get(session_id, [])),
                "summary": asdict(self._summary[session_id]) if session_id in self._summary else None,
            }

    def import_state(self, session_id: str, state: Dict[str, Any]) -> None:
        if not isinstance(state, dict):
            return

        with self._lock:
            msgs: List[Message] = []
            for m in (state.get("messages") or []):
                try:
                    msgs.append(
                        Message(
                            role=str(m.get("role", "user")),
                            content=str(m.get("content", "")),
                            ts=float(m.get("ts", time())),
                        )
                    )
                except Exception:
                    continue

            self._messages[session_id] = msgs[-self.max_messages:] if msgs else []
            self._facts[session_id] = {str(k): str(v) for k, v in (state.get("facts") or {}).items()}
            self._pinned[session_id] = {str(k): str(v) for k, v in (state.get("pinned") or {}).items()}
            self._thresholds[session_id] = {str(k): float(v) for k, v in (state.get("thresholds") or {}).items()}
            self._goals[session_id] = list(state.get("goals") or [])
            self._kpi_history[session_id] = list(state.get("kpi_history") or [])[-self.max_kpi_history:]
            self._events[session_id] = list(state.get("events") or [])[-self.max_events:]

            s = state.get("summary")
            if s and isinstance(s, dict):
                try:
                    self._summary[session_id] = _SummaryCache(
                        text=str(s.get("text", "")),
                        ts=float(s.get("ts", time())),
                        window_size=int(s.get("window_size", 0)),
                    )
                except Exception:
                    self._summary.pop(session_id, None)
            else:
                self._summary.pop(session_id, None)

            self._commit()

    # -------------------------
    # Helper per LLM context
    # -------------------------
    def to_context_messages(
        self,
        session_id: str,
        *,
        include_summary: bool = True,
        include_facts: bool = True,
        window_size: int = 10,
    ) -> List[Dict[str, str]]:
        with self._lock:
            parts: List[str] = []

            if include_facts:
                facts = self.get_facts(session_id)
                if facts:
                    parts.append(
                        "Fatti noti (contestuali):\n" +
                        "\n".join(f"- {k}: {v}" for k, v in facts.items())
                    )

            if include_summary:
                s = self.summarize(session_id, client=None)
                if s:
                    parts.append("Riepilogo conversazione (breve):\n" + s)

            system_blob = "\n\n".join(parts).strip()
            out: List[Dict[str, str]] = []

            if system_blob:
                out.append({"role": "system", "content": system_blob})

            msgs = self.get_window(session_id, n=max(1, window_size))
            for m in msgs:
                out.append({"role": m.role, "content": m.content})

            return out

    # -------------------------
    # Config dinamica
    # -------------------------
    def set_max_messages(self, max_messages: int) -> None:
        with self._lock:
            self.max_messages = max(1, int(max_messages))
            for sid, arr in list(self._messages.items()):
                if len(arr) > self.max_messages:
                    self._messages[sid] = arr[-self.max_messages:]
                    self._invalidate_summary(sid)
            self._commit()

    def set_message_ttl(self, ttl_seconds: Optional[int]) -> None:
        with self._lock:
            self.message_ttl_s = int(ttl_seconds) if ttl_seconds is not None else None
            self._commit()

    # -------------------------
    # Debug helper
    # -------------------------
    def repr_session(self, session_id: str) -> str:  # pragma: no cover
        with self._lock:
            return json.dumps(self.export_state(session_id), ensure_ascii=False, indent=2)


# -----------------------------
# Helper compatibile col router
# -----------------------------
def record_interaction(memory: MemoryStore, session_id: str, kind: str, payload: Optional[Dict[str, Any]] = None) -> None:
    """Shorthand usato dal router per registrare un evento conversazionale/di sistema."""
    try:
        memory.push_event(session_id, kind, payload)
    except Exception:
        pass