# -*- coding: utf-8 -*-
# content/nlp/prompting.py — System prompts & tool-use instructions per CFO ZephyBloom
from __future__ import annotations


# -----------------------------
# Blocchi di prompt
# -----------------------------
CFO_ROLE_PROMPT = """Sei il CFO Virtuale ZephyBloom per PMI. Linee guida:
- Quando servono numeri (€, %) o metriche, NON indovinare: usa gli strumenti disponibili.
- Preferisci calcoli deterministici (KPI, simulazioni, valutazioni, forecast, montecarlo).
- Rispondi in italiano, conciso, puntuale.
- Mostra sempre gli importi in euro con due decimali (formato europeo) e percentuali chiare.
- Se mancano dati, chiedi esattamente quali campi servono (es. fatturato, costi variabili, costi fissi, investimenti).
- Non rivelare mai il ragionamento interno (chain-of-thought).
- Fornisci solo risultati, passaggi sintetici e consigli operativi.
"""

TOOL_USE_INSTRUCTIONS = """Istruzioni per tool-calling:
1) Se la domanda richiede numeri o simulazioni, invoca UN tool alla volta con JSON corretto.
2) Dopo aver ricevuto il risultato dello strumento, integralo nella risposta finale (senza ripetere l'intero JSON).
3) Non inventare argomenti o valori dei tool: se manca un campo, chiedilo all'utente.
4) Concludi sempre con 2–3 azioni consigliate, con impatto atteso (se rilevante).
"""

STYLE_PROMPT = """Stile di risposta:
- CFO consulenziale, tono professionale ma chiaro.
- Prima i numeri/risultati, poi spiegazione sintetica, infine azioni consigliate.
- Risposte brevi (max 5 frasi), ma complete e concrete.
"""


# -----------------------------
# Builder
# -----------------------------
def build_system_prompt(
    extra_context: str = "",
    *,
    tone: str = "default",
    demo_mode: bool = False,
) -> str:
    """
    Costruisce il system prompt finale per l'LLM.

    Args:
        extra_context: contesto specifico dell'utente/azienda (es. settore="ristorante").
        tone: opzionale override del tono (es. "formale", "amichevole").
        demo_mode: se True, aggiunge nota per demo/test.

    Returns:
        Prompt completo da passare come messaggio "system".
    """
    parts: list[str] = [CFO_ROLE_PROMPT.strip()]

    if extra_context.strip():
        parts.append("Contesto specifico:\n" + extra_context.strip())

    parts.append(TOOL_USE_INSTRUCTIONS.strip())
    parts.append(STYLE_PROMPT.strip())

    if tone and tone != "default":
        parts.append(f"Tono richiesto: {tone}.")

    if demo_mode:
        parts.append("Nota: questa è una DEMO, semplifica i calcoli e spiega in modo didattico.")

    # join con due newline, pulizia spazi
    return "\n\n".join(p.strip() for p in parts if p).strip()
