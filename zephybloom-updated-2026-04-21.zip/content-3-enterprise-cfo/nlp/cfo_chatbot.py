"""
CFO Chatbot Engine - ZephyBloom
Trasforma il chatbot da template statico a consulente finanziario reale.

Architettura:
1. Intent Recognition (keyword-based + NLP)
2. Slot Extraction (estrai numeri e componenti)
3. Router Intelligente (esegui motore corretto)
4. Decision Engine (interpreta risultati)
5. CFO Response Builder (numeri + diagnosi + azione)
"""

from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import re
import math

# Importa valuation e altre utility
from core.valuation import dcf_gordon

# ⭐ NEW: Decision Engine (Il vero CFO Brain)
from nlp.cfo_decision_engine import create_decision_engine, CompanyHealth

# ===============================================
# 1. INTENT RECOGNITION DATABASE
# ===============================================

class IntentRecognizer:
    """Riconosce intent da text usando keyword matching + NLP"""
    
    INTENTS = {
        # KPI & Metriche Finanziarie
        "kpi_margin": {
            "keywords": ["margine", "margin", "lordo", "netto", "gross", "gross margin"],
            "needs_context": True,
            "engine": "analyze_kpi"
        },
        "kpi_ebitda": {
            "keywords": ["ebitda", "ebit", "operativo", "operating"],
            "needs_context": True,
            "engine": "analyze_kpi"
        },
        "kpi_roi": {
            "keywords": ["roi", "ritorno", "rendimento", "return on investment"],
            "needs_context": True,
            "engine": "compute_roi"
        },
        "kpi_profit": {
            "keywords": ["utile", "profit", "guadagno", "ricavo", "revenue", "fatturato"],
            "needs_context": True,
            "engine": "analyze_kpi"
        },
        
        # Simulazioni
        "simulate_price": {
            "keywords": ["prezzo", "price", "aumento prezzo", "aumentare", "+", "price increase"],
            "regex": r"[\+\-]?\d+\s*%.*(?:prezzo|price)",
            "engine": "simulate"
        },
        "simulate_cost": {
            "keywords": ["costo", "cost", "ridurre", "reduce", "-", "cost reduction"],
            "regex": r"[\+\-]?\d+\s*%.*(?:costo|cost|spese)",
            "engine": "simulate"
        },
        "simulate_volume": {
            "keywords": ["volume", "vendite", "sales", "crescita", "growth"],
            "regex": r"[\+\-]?\d+\s*%.*(?:volume|vendite|sales)",
            "engine": "simulate"
        },
        
        # Analisi Strategica
        "strategy_improve_profit": {
            "keywords": ["migliorare", "increase", "aumentare", "profitto", "profitability", "redditività"],
            "engine": "strategic_analysis"
        },
        "strategy_problems": {
            "keywords": ["problemi", "issues", "problema", "cosa non va", "cosa fare"],
            "engine": "diagnosis"
        },
        "strategy_growth": {
            "keywords": ["crescita", "growth", "espandere", "expand", "acquisire", "acquire"],
            "engine": "growth_strategy"
        },
        
        # Liquidità & Working Capital
        "liquidity_dso": {
            "keywords": ["dso", "days sales", "debiti clienti", "crediti"],
            "engine": "liquidity_analysis"
        },
        "liquidity_ccc": {
            "keywords": ["ccc", "ciclo cassa", "ciclo di cassa", "cash cycle", "working", "capitale circolante"],
            "engine": "liquidity_analysis"
        },
        
        # Definizioni
        "definition": {
            "keywords": ["cos'è", "what is", "definisci", "define", "significa", "spiegare"],
            "regex": r"cos'è|what is|definisci|significa",
            "engine": "explain"
        },
        
        # Valutazione & Enterprise Value
        "valuation_request": {
            "keywords": ["quanto vale", "valuation", "enterprise value", "worth", "valore", "prezzo azioni", "stock price"],
            "regex": r"quanto\s+vale|valuation|enterprise\s+value",
            "engine": "valuation"
        },
        
        # Acquisizione & M&A ROI
        "acquisition_roi": {
            "keywords": ["acquisire", "acquisisco", "acquisition", "acquisizione", "m&a", "merger", "acquisire", "target", "deal", "competitor", "conviene"],
            "regex": r"acquisir|acquisit|m&a|merger|deal|competitor",
            "engine": "acquisition"
        },
        
        # Expert Rules & Prioritizzazione
        "expert_rules": {
            "keywords": ["cosa fare", "cosa prioritizzare", "priorità", "consigli", "strategie prioritarie", "cosa dovrei", "help me", "aiutami", "first step", "primo passo", "come crescere", "crescere", "espandere"],
            "regex": r"cosa\s+(?:fare|prioritizzare|dovrei|fare)?|priorit|consigli|strategie|come\s+crescere",
            "engine": "expert_analysis"
        },
        
        # ⭐ HEALTH CHECK - Il vero Decision Engine
        "health_check": {
            "keywords": ["come sta", "situazione", "analizzami", "status", "diagnosi", "salute", "come vado", "analisi", "valutami"],
            "regex": r"come\s+sta|situazione|analizzami|analisi\s+complet|diagnosi|valutami|status|salute|come\s+vado",
            "engine": "decision"
        },
        
        # Fallback
        "generic": {
            "keywords": [],
            "engine": "ask_clarification"
        }
    }
    
    def recognize(self, text: str) -> Tuple[str, float]:
        """
        Riconosce intent da text.
        
        Returns:
            (intent_name, confidence_score)
        """
        text_lower = text.lower().strip()
        
        best_intent = "generic"
        best_score = 0.0
        
        for intent_name, intent_data in self.INTENTS.items():
            if intent_name == "generic":
                continue
            
            # Keyword matching
            keywords = intent_data.get("keywords", [])
            matches = sum(1 for kw in keywords if kw in text_lower)
            
            if matches > 0:
                score = matches / max(len(keywords), 1)
                if score > best_score:
                    best_intent = intent_name
                    best_score = score
            
            # Regex matching (per numeri e special patterns)
            regex_pattern = intent_data.get("regex")
            if regex_pattern and re.search(regex_pattern, text_lower, re.IGNORECASE):
                best_intent = intent_name
                best_score = max(best_score, 0.95)
        
        return best_intent, best_score


# ===============================================
# 2. SLOT EXTRACTION
# ===============================================

class SlotExtractor:
    """Estrae numeri e componenti dalla domanda"""
    
    @staticmethod
    def extract_percentage(text: str) -> Optional[float]:
        """Estrae percentuale da text: '+15%', '-5%', '20 percent'"""
        # Match: +15%, 15%, -5, 20 percent, etc.
        patterns = [
            r'[\+\-]?\d+(?:\.\d+)?\s*%',
            r'[\+\-]?\d+(?:\.\d+)?\s*percent',
        ]
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                pct_str = match.group(0).replace('%', '').replace('percent', '').strip()
                try:
                    return float(pct_str)
                except:
                    pass
        return None
    
    @staticmethod
    def extract_euro(text: str) -> Optional[float]:
        """Estrae importo in euro: 100k, €50.000, 1M"""
        patterns = [
            r'€\s*[\d.,]+(?:[kmb])?',
            r'[\d.,]+\s*(?:k|m|mila|milioni)(?:\s*€)?',
            r'\d+(?:\.\d+|\,\d+)?.*(?:€|euro)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                num_str = re.sub(r'[€kmilaboni\s]', '', match.group(0))
                try:
                    num = float(num_str.replace(',', '.'))
                    # Scale up if needed
                    if 'k' in match.group(0).lower():
                        num *= 1000
                    elif 'm' in match.group(0).lower():
                        num *= 1_000_000
                    return num
                except:
                    pass
        return None
    
    @staticmethod
    def extract_metric_name(text: str) -> Optional[str]:
        """Estrae nome della metrica richiesta"""
        metrics = {
            "margine": ["margine", "margin", "lordo", "netto"],
            "ebitda": ["ebitda", "ebit", "operativo"],
            "profitto": ["profitto", "utile", "profit", "earnings"],
            "roi": ["roi", "return"],
            "dso": ["dso", "debiti clienti"],
        }
        
        text_lower = text.lower()
        for metric, keywords in metrics.items():
            for kw in keywords:
                if kw in text_lower:
                    return metric
        return None


# ===============================================
# 3. CFO DECISION ENGINE
# ===============================================

@dataclass
class CFOAnalysisResult:
    """Risultato di un'analisi CFO"""
    intent: str
    value: Optional[float] = None
    value_str: Optional[str] = None
    diagnosis: str = ""
    action: str = ""
    confidence: float = 1.0
    tools_used: List[str] = None
    
    def to_response(self) -> Dict[str, Any]:
        """Converte in response dict"""
        return {
            "intent": self.intent,
            "value": self.value,
            "value_str": self.value_str,
            "diagnosis": self.diagnosis,
            "action": self.action,
            "narrative": self._build_narrative(),
            "tools_used": self.tools_used or [],
        }
    
    def _build_narrative(self) -> str:
        """Costruisce narrativa CFO"""
        parts = []
        
        if self.value_str:
            parts.append(f"📊 **IMPATTO**: {self.value_str}")
        
        if self.diagnosis:
            parts.append(f"\n🧠 **ANALISI**:\n{self.diagnosis}")
        
        if self.action:
            parts.append(f"\n🚀 **AZIONE**:\n{self.action}")
        
        return "\n".join(parts) if parts else "Analisi non disponibile"


class CFODecisionEngine:
    """Motor principale che esegue analisi finanziarie"""
    
    def __init__(self):
        self.recognizer = IntentRecognizer()
        self.extractor = SlotExtractor()
    
    def analyze(self, text: str, context: Dict[str, float]) -> CFOAnalysisResult:
        """
        Analisi CFO completa.
        
        Args:
            text: Domanda dell'utente
            context: Dati aziendali (fatturato, costi_variabili, etc.)
        
        Returns:
            CFOAnalysisResult con numeri, diagnosi, azioni
        """
        # Step 1: Riconosci intent
        intent, confidence = self.recognizer.recognize(text)
        
        # Step 2: Estrai numeri
        pct = self.extractor.extract_percentage(text)
        euro = self.extractor.extract_euro(text)
        metric = self.extractor.extract_metric_name(text)
        
        # Step 3: Router intelligente
        if intent.startswith("simulate"):
            return self._simulate_scenario(intent, pct or 0, context)
        elif intent == "definition":
            return self._explain_metric(metric or "ebitda", context)
        elif intent == "health_check":
            return self._health_check_analysis(context)  # ⭐ NEW DECISION ENGINE
        elif intent == "expert_rules":
            return self._expert_rules_analysis(context)
        elif intent == "valuation_request":
            return self._valuation_analysis(context)
        elif intent == "acquisition_roi":
            return self._acquisition_analysis(context)
        elif intent.startswith("kpi"):
            return self._analyze_kpi(metric or "profit", context)
        elif intent.startswith("strategy"):
            return self._strategic_analysis(intent, context)
        elif intent.startswith("liquidity"):
            return self._liquidity_analysis(intent, context)
        else:
            return self._ask_clarification(text, context)
    
    # ========================
    # ENGINE: Health Check (DECISION ENGINE - Il Vero Core)
    # ========================
    
    def _health_check_analysis(self, context: Dict) -> CFOAnalysisResult:
        """
        ⭐ IL VERO CFO BRAIN
        Usa il nuovo Decision Engine per dare decisioni concrete.
        
        Output: Decisioni ordinateper impatto € + azioni concrete
        """
        
        # Usa il NEW Decision Engine
        decision_engine = create_decision_engine()
        decision = decision_engine.analyze(context)
        
        # Converti in CFOAnalysisResult per compatibilità
        return CFOAnalysisResult(
            intent="health_check",
            value=None,
            value_str=decision.headline,
            diagnosis=decision.to_response(),  # L'intera output formattata
            action=None,  # Non usato
            tools_used=["decision_engine", "health_check"],
        )
    
    # ========================
    # ENGINE: Simulazioni
    # ========================
    
    def _simulate_scenario(self, intent: str, delta_pct: float, context: Dict) -> CFOAnalysisResult:
        """Simula impatto di variazioni"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        
        # Calcoli base
        profit_base = fatt - cv - cf
        margin_base = (profit_base / fatt * 100) if fatt > 0 else 0
        
        # Simula
        if "price" in intent:
            # Aumento prezzo = aumento fatturato
            fatt_new = fatt * (1 + delta_pct/100)
            profit_new = fatt_new - cv - cf
            impact = profit_new - profit_base
            diagnosis = f"Un aumento prezzi del {delta_pct:+.1f}% aumenta il fatturato da €{fatt:,.0f} a €{fatt_new:,.0f}."
            diagnosis += f"\nCosti invariati → utile passa da €{profit_base:,.0f} a €{profit_new:,.0f}."
            diagnosis += f"\nImpatto: +€{impact:,.0f} ({impact/profit_base*100:+.1f}% rispetto al caso base)"
            
        elif "cost" in intent:
            # Riduzione costi = aumento profitto
            cv_new = cv * (1 + delta_pct/100)
            profit_new = fatt - cv_new - cf
            impact = profit_new - profit_base
            diagnosis = f"Una variazione costi del {delta_pct:+.1f}% cambia i costi variabili da €{cv:,.0f} a €{cv_new:,.0f}."
            diagnosis += f"\nUtile varia da €{profit_base:,.0f} a €{profit_new:,.0f}."
            diagnosis += f"Impatto: €{impact:+,.0f} ({impact/profit_base*100:+.1f}%)"
            
        else:
            # Volume
            fatt_new = fatt * (1 + delta_pct/100)
            cv_new = cv * (1 + delta_pct/100)
            profit_new = fatt_new - cv_new - cf
            impact = profit_new - profit_base
            diagnosis = f"Una crescita volume del {delta_pct:+.1f}% scala fatturato e costi variabili."
            diagnosis += f"\nUtile: €{profit_base:,.0f} → €{profit_new:,.0f} (€{impact:+,.0f})"
        
        action = f"Questo scenario è realistico solo se: fatturato effettivamente cresce (prezzo/volume) e costi sono proporzionali."
        
        return CFOAnalysisResult(
            intent=intent,
            value=impact,
            value_str=f"€{impact:+,.0f}",
            diagnosis=diagnosis,
            action=action,
            tools_used=["simulate"]
        )
    
    # ========================
    # ENGINE: Analisi KPI
    # ========================
    
    def _analyze_kpi(self, metric: str, context: Dict) -> CFOAnalysisResult:
        """Analizza KPI specifico"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        inv = context.get("investimenti", 100_000)
        
        # Calcoli
        gross_profit = fatt - cv
        gross_margin = (gross_profit / fatt * 100) if fatt > 0 else 0
        ebitda = gross_profit - cf
        ebitda_margin = (ebitda / fatt * 100) if fatt > 0 else 0
        net_profit = ebitda
        net_margin = (net_profit / fatt * 100) if fatt > 0 else 0
        roi = (ebitda / inv * 100) if inv > 0 else 0
        
        if metric == "margine" or metric == "gross":
            value = gross_margin
            diagnosis = f"Margine lordo: {gross_margin:.1f}%\n"
            if gross_margin < 30:
                diagnosis += "⚠️ CRITICO: Margine basso indica costi variabili alti o prezzi bassi."
            elif gross_margin < 40:
                diagnosis += "⚠️ ATTENZIONE: Margine sotto media. Ottimizzare costi o aumentare prezzi."
            else:
                diagnosis += "✅ BUONO: Margine è solido. Focus su ridurre costi fissi."
        
        elif metric == "ebitda":
            value = ebitda_margin
            diagnosis = f"EBITDA Margin: {ebitda_margin:.1f}%\n"
            diagnosis += f"EBITDA assoluto: €{ebitda:,.0f}\n"
            if ebitda_margin < 15:
                diagnosis += "⚠️ Costi fissi molto alti. Valutare ridimensionamento."
            else:
                diagnosis += "✅ EBITDA solido. Buona gestione operativa."
        
        else:  # profit
            value = net_profit
            diagnosis = f"Utile netto: €{net_profit:,.0f}\n"
            diagnosis += f"Margine netto: {net_margin:.1f}%\n"
            if net_profit < 0:
                diagnosis += "🔴 PERDITA. Urgente ridurre costi."
            elif net_margin < 5:
                diagnosis += "⚠️ Profitto basso. Margini troppo stretti."
            else:
                diagnosis += "✅ Profitto sano."
        
        action = f"Focalizzarsi su: ridurre {'costi variabili' if gross_margin < 40 else 'costi fissi'}"
        
        return CFOAnalysisResult(
            intent="kpi_analysis",
            value=value,
            value_str=f"{value:.1f}%" if metric != "profit" else f"€{value:,.0f}",
            diagnosis=diagnosis,
            action=action,
            tools_used=["compute_kpis"]
        )
    
    # ========================
    # ENGINE: Analisi Strategica
    # ========================
    
    def _strategic_analysis(self, intent: str, context: Dict) -> CFOAnalysisResult:
        """Analisi strategica per miglioramenti"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        
        profit = fatt - cv - cf
        margin_gross = ((fatt - cv) / fatt * 100) if fatt > 0 else 0
        margin_net = (profit / fatt * 100) if fatt > 0 else 0
        
        diagnosis = "**Leve principali per aumentare profitto:**\n\n"
        actions = []
        
        # Diagnostica
        if margin_gross < 35:
            diagnosis += f"1️⃣ **Margine lordo basso** ({margin_gross:.1f}%)\n"
            diagnosis += "   Causa: Costi variabili alti respetto alla concorrenza\n"
            actions.append("Negoziati con fornitori per ridurre COGS")
            actions.append("Aumentare prezzi su segmenti premium")
        
        if cf / fatt > 0.35:
            diagnosis += f"2️⃣ **Costi fissi alti** ({cf/fatt*100:.1f}% del fatturato)\n"
            diagnosis += "   Causa: Struttura aziendale sottoutilizzata\n"
            actions.append("Ridurre overhead/spese fisse")
            actions.append("Aumentare fatturato per diluire fissi")
        
        if profit < 0:
            diagnosis += "3️⃣ **PERDITA OPERATIVA**\n"
            diagnosis += "   Urgente: implementare piano di ripresa\n"
            actions.append("Revisione strutturale costi")
            actions.append("Aumento prezzi + riduzione volumi non critica")
        
        action_text = "\n".join([f"• {a}" for a in actions[:3]])
        
        return CFOAnalysisResult(
            intent="strategy_analysis",
            value=None,
            diagnosis=diagnosis,
            action=f"**Prossimi passi:**\n{action_text}",
            tools_used=["analysis"]
        )
    
    # ========================
    # ENGINE: Liquidità
    # ========================
    
    def _liquidity_analysis(self, intent: str, context: Dict) -> CFOAnalysisResult:
        """Analisi liquidità e working capital"""
        
        diagnosis = "**Ciclo di Cassa (CCC) = DSO + DIO - DPO**\n\n"
        
        dso = context.get("dso_days", 30)
        dio = context.get("dio_days", 45)
        dpo = context.get("dpo_days", 30)
        ccc = dso + dio - dpo
        
        diagnosis += f"• DSO (debiti clienti): {dso} giorni\n"
        diagnosis += f"• DIO (magazzino): {dio} giorni  \n"
        diagnosis += f"• DPO (debiti fornitori): {dpo} giorni\n"
        diagnosis += f"**CCC totale: {ccc} giorni**\n\n"
        
        if ccc > 60:
            diagnosis += "⚠️ CCC ALTO: Blocchi molti soldi in working capital.\n"
        elif ccc < 30:
            diagnosis += "✅ CCC BASSO: Ottimale.\n"
        else:
            diagnosis += "⚠️ CCC NORMALE: Margine di miglioramento.\n"
        
        action = f"Ridurre CCC di 10 giorni libera circa €{context.get('fatturato', 1_000_000)/365*10:,.0f} in liquidità."
        
        return CFOAnalysisResult(
            intent="liquidity",
            value=ccc,
            value_str=f"{ccc} giorni",
            diagnosis=diagnosis,
            action=action,
            tools_used=["liquidity_analysis"]
        )
    
    # ========================
    # ENGINE: Spiegazioni
    # ========================
    
    def _explain_metric(self, metric: str, context: Dict) -> CFOAnalysisResult:
        """Spiega una metrica finanziaria"""
        
        definitions = {
            "ebitda": {
                "def": "Utile prima di interessi, tasse, ammortamenti (Earnings Before Interest, Taxes, Depreciation, Amortization)",
                "uso": "Misura la redditività operativa. Non influenzata dalla struttura finanziaria o fiscale.",
                "target": "In media: 15-25% del fatturato per aziende sane"
            },
            "margine": {
                "def": "Percentuale di profitto per ogni euro di vendita",
                "uso": "Indica efficienza: margine = profitto / fatturato * 100",
                "target": "Dipende dal settore: retail 5-10%, SaaS 20-40%"
            },
            "roi": {
                "def": "Ritorno sull'investimento: profitto generato da €1 investito",
                "uso": "ROI = profitto / investimento * 100",
                "target": "Min 10-15% annuale per giustificare il rischio"
            },
            "dso": {
                "def": "Giorni per riscuotere i debiti dai clienti",
                "uso": "DSO alto = soldi bloccati in crediti. Causa problemi di liquidità.",
                "target": "Ridurre a 30-45 giorni"
            }
        }
        
        info = definitions.get(metric or "ebitda", definitions["ebitda"])
        
        diagnosis = f"**{metric or 'EBITDA'}**\n\n"
        diagnosis += f"📖 **Definizione**: {info['def']}\n\n"
        diagnosis += f"💡 **Utilizzo**: {info['uso']}\n\n"
        diagnosis += f"🎯 **Target**: {info['target']}"
        
        return CFOAnalysisResult(
            intent="definition",
            diagnosis=diagnosis,
            action="Usare questo KPI per monitorare la salute finanziaria.",
            tools_used=["education"]
        )
    
    # ========================
    # ENGINE: Expert Rules & Prioritizzazione
    # ========================
    
    def _expert_rules_analysis(self, context: Dict) -> CFOAnalysisResult:
        """
        Applica regole intelligenti per identificare priorità di azione.
        Trasforma dati in strategie concrete, ognuna con impatto stimato.
        """
        
        # Estrai metriche chiave
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        inv = context.get("investimenti", 100_000)
        dso = context.get("dso_days", 30)
        dio = context.get("dio_days", 45)
        dpo = context.get("dpo_days", 30)
        
        # Calcoli
        profit_base = fatt - cv - cf
        margin_gross = ((fatt - cv) / fatt * 100) if fatt > 0 else 0
        margin_net = (profit_base / fatt * 100) if fatt > 0 else 0
        cf_pct = (cf / fatt * 100) if fatt > 0 else 0
        ccc = dso + dio - dpo
        
        # Array di priorità (ordine importanza)
        priorities = []
        
        # RULE 1: Perdita è critica
        if profit_base < 0:
            priorities.append({
                "rank": 1,
                "title": "🔴 RECOVERY PLAN - AZIENDA IN PERDITA",
                "description": f"Utile netto: €{profit_base:,.0f}. Situazione critica.",
                "impact_eur": abs(profit_base),
                "actions": [
                    "1. Ridurre costi fissi di almeno 20-30%",
                    "2. Aumentare prezzi/produttività del 15-25%",
                    "3. Licenziamenti/riorganizzazione strutturale",
                    "4. Negoziare termini con fornitori (estendere DPO)"
                ]
            })
        
        # RULE 2: Margine basso + CCC alto = Working capital è prioritario
        elif margin_gross < 30 and ccc > 60:
            priorities.append({
                "rank": 2,
                "title": "1️⃣ LIBERARE LIQUIDITÀ - Working Capital Optimization",
                "description": f"Margine {margin_gross:.1f}% è basso, CCC {ccc} giorni è alto. Soldi bloccati.",
                "impact_eur": (fatt / 365) * (ccc - 45),  # Stima soldi sbloccabili
                "actions": [
                    f"Ridurre CCC da {ccc} a 45 giorni = €{(fatt/365)*(ccc-45):,.0f} liberati",
                    "→ Accelerare incassi (DSO: 30 giorni max)",
                    "→ Ottenere dilazioni fornitori (DPO: 45-60 giorni)",
                    "→ Ottimizzare stock (DIO: 30 giorni)"
                ]
            })
        
        # RULE 3: Margine basso alone
        elif margin_gross < 30:
            priorities.append({
                "rank": 2,
                "title": "1️⃣ AUMENTARE MARGINE LORDO",
                "description": f"Margine {margin_gross:.1f}% è sotto target. Costi variabili troppo alti.",
                "impact_eur": fatt * 0.05,  # Stima: guadagnare 5%
                "actions": [
                    "Negoziare COGS con fornitori (-10%)",
                    "Aumentare prezzi su segmenti premium (+5-10%)",
                    "Ridurre scarto di produzione/difetti",
                    "Scalare volume per diluire costi fissi"
                ]
            })
        
        # RULE 4: Costi fissi alti
        if cf_pct > 35:
            priorities.append({
                "rank": 2 + (1 if not priorities else 0),
                "title": "2️⃣ RIDURRE COSTI FISSI",
                "description": f"Costi fissi: {cf_pct:.1f}% del fatturato (target: <30%).",
                "impact_eur": fatt * (cf_pct - 30) / 100,
                "actions": [
                    f"Target: ridurre da €{cf:,.0f} a €{fatt*0.30:,.0f}",
                    "Rivedere: canoni, stipendi, outsourcing",
                    "Aumentare produttività per diluire fissi"
                ]
            })
        
        # RULE 5: CCC alto (even if margins OK)
        if ccc > 60 and not any(p["title"].startswith("1️⃣") for p in priorities):
            priorities.append({
                "rank": 2,
                "title": "1️⃣ RIDURRE CICLO DI CASSA",
                "description": f"CCC {ccc} giorni è alto. Ottimizzare working capital.",
                "impact_eur": (fatt / 365) * (ccc - 45),
                "actions": [
                    f"Attualmente: DSO {dso}d, DIO {dio}d, DPO {dpo}d = {ccc}d",
                    f"Target:     DSO 30d,  DIO 35d,  DPO 50d = 15d",
                    f"Beneficio: €{(fatt/365)*40:,.0f} di liquidità liberata"
                ]
            })
        
        # RULE 6: Tutto OK - crescita
        if profit_base > 0 and margin_gross > 30 and cf_pct < 35 and ccc < 60:
            priorities.append({
                "rank": 1,
                "title": "1️⃣ CRESCITA & ACQUISIZIONI",
                "description": f"Fondamentali solidi! Pronto per scala o M&A.",
                "impact_eur": fatt * 0.20,  # Stima 20% crescita
                "actions": [
                    "Investire in vendita/marketing",
                    "Acquisire competitor o complementary business",
                    "Entrare in nuovi mercati geografici",
                    "Sviluppare nuove linee prodotto"
                ]
            })
        
        # Ordina per rank
        priorities.sort(key=lambda x: x["rank"])
        
        # Costruisci narrativa
        diagnosis = "**🎯 PRIORITÀ STRATEGICHE ORDINATE PER IMPATTO:\n\n**"
        
        for i, p in enumerate(priorities[:3], 1):  # Top 3
            diagnosis += f"{p['title']}\n"
            diagnosis += f"{p['description']}\n"
            diagnosis += f"💰 **Impatto stimato**: €{p['impact_eur']:,.0f}\n"
            diagnosis += f"{'':20}\n"
        
        # Costruisci azioni
        action_list = []
        for p in priorities[:3]:
            for act in p["actions"][:2]:  # Top 2 azioni per priorità
                action_list.append(f"• {act}")
        
        action_text = "\n".join(action_list[:6])  # Max 6 azioni
        
        return CFOAnalysisResult(
            intent="expert_rules",
            value=None,
            diagnosis=diagnosis,
            action=f"**Implementa in questo ordine:**\n\n{action_text}",
            tools_used=["expert_rules", "analysis"]
        )
    
    # ========================
    # ENGINE: Valuation (DCF)
    # ========================
    
    def _valuation_analysis(self, context: Dict) -> CFOAnalysisResult:
        """
        Valuta l'azienda usando DCF (Discounted Cash Flow).
        Stima Enterprise Value e Equity Value con multipli.
        """
        
        # Estrai dati (con fallback)
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        inv = context.get("investimenti", 100_000)
        net_debt = context.get("net_debt", 0)  # Opzionale
        
        # Calcoli di base
        ebitda = fatt - cv - cf
        ebitda_margin = (ebitda / fatt * 100) if fatt > 0 else 0
        fcf = ebitda * 0.7  # Approximazione: FCF = EBITDA * 70%
        
        # Parametri di valutazione (da settore)
        wacc = 0.08  # Weighted average cost of capital (8%)
        terminal_growth = 0.025  # Growth perpetuo (2.5%)
        
        # Projected FCF: 5 anni con crescita (conservativa)
        growth_rate = 0.05  # 5% crescita annuale
        fcf_projection = []
        for year in range(1, 6):
            fcf_proj = fcf * ((1 + growth_rate) ** year)
            fcf_projection.append(fcf_proj)
        
        # DCF Valuation
        ev, equity_value, pv_explicit, pv_terminal = dcf_gordon(
            fcf=fcf_projection,
            discount_rate=wacc,
            g=terminal_growth,
            net_debt=net_debt
        )
        
        # Multipli per sanity check
        ev_multiple = ev / max(ebitda, 1)  # EV/EBITDA multiple
        
        # Interpretazione
        diagnosis = f"**VALUTAZIONE AZIENDALE (DCF Analysis)**\n\n"
        diagnosis += f"📊 **Metriche Attuali:**\n"
        diagnosis += f"• Fatturato: €{fatt:,.0f}\n"
        diagnosis += f"• EBITDA: €{ebitda:,.0f} ({ebitda_margin:.1f}% margin)\n"
        diagnosis += f"• FCF proiettato: €{fcf:,.0f}/anno\n\n"
        
        diagnosis += f"💰 **Valutazione:**\n"
        diagnosis += f"• **Enterprise Value (EV): €{ev:,.0f}**\n"
        diagnosis += f"• Equity Value: €{equity_value:,.0f}\n"
        diagnosis += f"• EV/EBITDA Multiple: {ev_multiple:.1f}x\n\n"
        
        # Breakdown DCF
        diagnosis += f"**Breakdown DCF:**\n"
        diagnosis += f"• PV (Explicit 5 anni): €{pv_explicit:,.0f}\n"
        diagnosis += f"• PV (Terminal Value): €{pv_terminal:,.0f}\n"
        diagnosis += f"• Total: €{pv_explicit + pv_terminal:,.0f}\n\n"
        
        # Sensitivity: cosa cambia con diversi WACC
        diagnosis += f"**Sensibilità (cambio WACC):**\n"
        for test_wacc in [0.06, 0.08, 0.10]:
            ev_test, _, _, _ = dcf_gordon(fcf_projection, test_wacc, terminal_growth, net_debt)
            diagnosis += f"• WACC {test_wacc*100:.0f}%: €{ev_test:,.0f}\n"
        
        # Azioni
        actions = []
        
        if ebitda_margin < 15:
            actions.append("🔴 EBITDA margin basso: Migliora redditività prima di trovare buyer")
        elif ebitda_margin > 25:
            actions.append("✅ Margin solido: Azienda attraente per acquisitori")
        
        if ev_multiple < 6:
            actions.append(f"💡 A {ev_multiple:.1f}x EBITDA, sei sotto mercato: Crescere per aumentare valore")
        elif ev_multiple > 12:
            actions.append(f"💡 A {ev_multiple:.1f}x EBITDA, sei sopra media: Liquidity event possibile")
        
        if equity_value <= 0:
            actions.append("⚠️ Equity value negativa: Eliminare net debt prima di exit")
        else:
            actions.append(f"✅ Equity Value: €{equity_value:,.0f} (disponibile ai shareholders)")
        
        action_text = "\n".join(actions)
        
        return CFOAnalysisResult(
            intent="valuation_request",
            value=ev,
            value_str=f"€{ev:,.0f}",
            diagnosis=diagnosis,
            action=action_text,
            tools_used=["dcf_valuation", "multiples"]
        )
    
    # ========================
    # ENGINE: Acquisition ROI
    # ========================
    
    def _acquisition_analysis(self, context: Dict) -> CFOAnalysisResult:
        """
        Analizza ROI di acquisizione di target company.
        Calcola: Synergies, NPV, Payback, IRR.
        
        Context atteso:
        - fatturato, costi_variabili, costi_fissi (acquirer)
        - target_price: Prezzo di acquisizione (€)
        - target_ebitda: EBITDA del target (€)
        - synergy_cost_pct: % cost synergies (default 15%)
        - synergy_revenue_pct: % revenue synergies (default 10%)
        """
        
        # Acquirer
        fatt_acq = context.get("fatturato", 10_000_000)
        cv_acq = context.get("costi_variabili", 6_000_000)
        cf_acq = context.get("costi_fissi", 2_500_000)
        ebitda_acq = fatt_acq - cv_acq - cf_acq
        
        # Target (assumptions se non forniti)
        target_price = context.get("target_price")
        target_ebitda = context.get("target_ebitda")
        
        # Se non forniti, calcola defaults
        if target_price is None:
            target_price = ebitda_acq * 8
        if target_ebitda is None:
            target_ebitda = ebitda_acq * 0.5
        
        target_fatt = target_ebitda / 0.15 if target_ebitda > 0 else 1_000_000  # Assume 15% margin
        
        # Synergies
        synergy_cost_pct = context.get("synergy_cost_pct", 0.15)  # 15% cost synergies
        synergy_revenue_pct = context.get("synergy_revenue_pct", 0.10)  # 10% revenue synergies
        
        # Calculate synergies
        cost_synergy = (cv_acq + target_ebitda * 0.85) * synergy_cost_pct  # Scale cost synergy
        revenue_synergy = target_fatt * synergy_revenue_pct * 0.30  # Only 30% drops to EBITDA
        total_annual_synergy = cost_synergy + revenue_synergy
        
        # M&A costs
        deal_costs = target_price * 0.05  # 5% of deal size (legal, advisory, etc.)
        integration_costs = target_price * 0.10  # 10% integration costs over 2 years
        
        # NPV calculation
        wacc = 0.08
        npv = -target_price - deal_costs - integration_costs
        for year in range(1, 6):
            discount_factor = 1.0 / ((1.0 + wacc) ** year)
            npv += (total_annual_synergy * discount_factor)
        
        # Payback period
        total_costs = target_price + deal_costs + integration_costs
        payback_years = total_costs / max(total_annual_synergy, 1)
        
        # IRR approximation (simple)
        def calc_npv_simple(rate, years=5):
            v = -total_costs
            for y in range(1, years + 1):
                v += (total_annual_synergy / ((1 + rate) ** y))
            return v
        
        irr = 0.15  # Initial guess
        for _ in range(5):  # Quick Newton-Raphson
            npv_test = calc_npv_simple(irr)
            if abs(npv_test) < 1000:
                break
            irr += 0.01 if npv_test > 0 else -0.01
        
        # Verdict
        if npv < 0:
            verdict = "❌ NOT RECOMMENDED"
            recommendation = f"NPV negativo: €{npv:,.0f}. Acquisto distrugge valore."
        elif payback_years > 5:
            verdict = "⚠️ CONSIDER"
            recommendation = f"Payback lungo ({payback_years:.1f} anni). Valutare alternative."
        elif irr < 0.15:
            verdict = "⚠️ MARGINAL"
            recommendation = f"IRR basso ({irr*100:.1f}%). Negoziare prezzo più basso."
        else:
            verdict = "✅ HIGHLY RECOMMENDED"
            recommendation = f"Deal attraente: IRR {irr*100:.1f}%, Payback {payback_years:.1f} anni. Procedere."
        
        # Build diagnosis
        diagnosis = f"**ANALISI ACQUISIZIONE (M&A ROI)**\n\n"
        diagnosis += f"📊 **Acquirer vs Target:**\n"
        diagnosis += f"• Acquirer EBITDA: €{ebitda_acq:,.0f}\n"
        diagnosis += f"• Target Prezzo: €{target_price:,.0f}\n"
        diagnosis += f"• Multiple (Prezzo/Target EBITDA): {target_price/max(target_ebitda,1):.1f}x\n\n"
        
        diagnosis += f"💰 **Deal Economics:**\n"
        diagnosis += f"• Cost Synergies (annuali): €{cost_synergy:,.0f}\n"
        diagnosis += f"• Revenue Synergies (annuali): €{revenue_synergy:,.0f}\n"
        diagnosis += f"• **Total Annual Synergy: €{total_annual_synergy:,.0f}**\n"
        diagnosis += f"• Deal Costs: €{deal_costs:,.0f}\n"
        diagnosis += f"• Integration Costs: €{integration_costs:,.0f}\n\n"
        
        diagnosis += f"📈 **Returns:**\n"
        diagnosis += f"• NPV (5-year): €{npv:,.0f}\n"
        diagnosis += f"• IRR (stima): {irr*100:.1f}%\n"
        diagnosis += f"• Payback Period: {payback_years:.1f} anni\n"
        diagnosis += f"• ROIC Year 1: {(total_annual_synergy * 0.7 / target_price)*100:.1f}%\n\n"
        
        diagnosis += f"🎯 **Verdict: {verdict}**\n"
        diagnosis += recommendation
        
        # Actions
        actions = []
        if npv > 0 and payback_years < 3:
            actions.append(f"💡 Deal sensato: Synergies (€{total_annual_synergy:,.0f}/anno) giustificano il prezzo")
            actions.append(f"→ Aggressivo: Negoziare earnout per ridurre rischio")
            actions.append(f"→ Pianificare integration plan (realizza 80% synergies)")
        else:
            actions.append(f"⚠️ Prezzo seems alto {target_price/max(target_ebitda,1):.1f}x")
            actions.append(f"→ Renegotiate target price a massimo €{target_price * 0.8:,.0f}")
            actions.append(f"→ Far: Increase synergies (consolidate back-office, etc)")
        
        action_text = "\n".join(actions)
        
        return CFOAnalysisResult(
            intent="acquisition_roi",
            value=npv,
            value_str=f"NPV: €{npv:,.0f}",
            diagnosis=diagnosis,
            action=action_text,
            tools_used=["acquisition_analysis", "synergy_modeling", "financial_modeling"]
        )
    
    # ========================
    # ENGINE: Fallback intelligente
    # ========================
    
    def _ask_clarification(self, text: str, context: Dict) -> CFOAnalysisResult:
        """Chiede chiarimento anziché rispondere con template generico"""
        
        diagnosis = "Non ho capito bene la domanda. Puoi chiarire?\n\n"
        diagnosis += "Posso aiutarti con:\n"
        diagnosis += "• **KPI**: Margine, EBITDA, Utile, ROI\n"
        diagnosis += "• **Simulazioni**: '+15% prezzo', '-5% costi', '+10% volumi'\n"
        diagnosis += "• **Strategia**: 'Come aumentare profitto?', 'Quali sono i miei problemi?'\n"
        diagnosis += "• **Liquidità**: 'Come ridurre il ciclo di cassa?'\n"
        diagnosis += "• **Definizioni**: 'Cos'è EBITDA?', 'Cos'è ROI?'"
        
        return CFOAnalysisResult(
            intent="clarification_needed",
            diagnosis=diagnosis,
            action="Riformula la domanda in modo specifico.",
            confidence=0.3,
            tools_used=[]
        )


# ===============================================
# 4. EXPORT MAIN ENGINE
# ===============================================

def create_cfo_engine() -> CFODecisionEngine:
    """Factory function"""
    return CFODecisionEngine()
