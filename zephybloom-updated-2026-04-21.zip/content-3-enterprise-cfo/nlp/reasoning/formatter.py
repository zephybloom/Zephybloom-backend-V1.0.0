# -*- coding: utf-8 -*-
# content/nlp/reasoning/formatter.py

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from nlp.reasoning.models import AnalysisBlock

try:
    from nlp.llm_provider import llm_generate  # type: ignore
    _HAVE_LLM = True
except Exception:
    _HAVE_LLM = False

    def llm_generate(system: str, prompt: str) -> str:
        return ""


DEFAULT_CFO_SYSTEM_PROMPT = (
    "Agisci come un CFO senior per PMI europee. "
    "Non limitarti a descrivere i numeri: prendi posizione. "
    "Scrivi risposte orientate a decisione, priorità e impatto economico. "
    "La risposta deve sempre avere 4 blocchi: "
    "1) Analisi KPI "
    "2) Interpretazione manageriale "
    "3) Azioni prioritarie con impatto economico "
    "4) Decisione consigliata. "
    "Tono: consulenziale, lucido, concreto, autorevole. "
    "Non inventare dati che non esistono."
)


def _safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}


def _fmt_num(x: Any) -> str:
    try:
        v = float(x)
        return f"{v:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
    except Exception:
        return str(x)


def _fmt_pct_maybe_ratio(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)

    if abs(v) <= 1.5:
        return f"{v * 100:.1f}%"
    return f"{v:.1f}%"


def _normalize_analysis_dict(payload: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(payload or {})
    for k, v in list(out.items()):
        if isinstance(v, tuple):
            out[k] = list(v)
    return out


def _looks_like_prompt_echo(txt: str) -> bool:
    low = txt.lower()
    markers = [
        "genera una risposta da cfo senior",
        "dati analisi (json)",
        '"kpi":',
        '"insights":',
        '"recommendations":',
    ]
    score = sum(1 for m in markers if m in low)
    return score >= 2


def _render_kpi_lines(kpi: Dict[str, Any]) -> List[str]:
    lines: List[str] = []

    ordered_keys = [
        "fatturato",
        "sales",
        "ricavi",
        "margine_contribuzione",
        "mc_rate",
        "ebitda",
        "utile",
        "roi",
        "ccc",
        "break_even",
        "opportunities_count",
    ]

    shown = False

    for key in ordered_keys:
        if key not in kpi:
            continue

        value = kpi.get(key)

        if key in {"mc_rate", "roi"}:
            lines.append(f"- {key}: {_fmt_pct_maybe_ratio(value)}")
        elif key == "ccc":
            lines.append(f"- {key}: {_fmt_num(value)} giorni")
        elif key == "opportunities_count":
            try:
                lines.append(f"- {key}: {int(float(value))}")
            except Exception:
                lines.append(f"- {key}: {value}")
        else:
            lines.append(f"- {key}: € {_fmt_num(value)}")

        shown = True

    if not shown:
        lines.append("- KPI disponibili ma non standardizzati")

    return lines


def _render_deterministic_response(analysis: AnalysisBlock) -> str:
    lines: List[str] = []

    lines.append("### 1) Analisi KPI")
    if analysis.kpi:
        lines.extend(_render_kpi_lines(_safe_dict(analysis.kpi)))
    else:
        lines.append("- KPI non disponibili")

    lines.append("")
    lines.append("### 2) Interpretazione manageriale")
    if analysis.insights:
        for item in analysis.insights:
            txt = str(item).strip()
            if txt:
                lines.append(f"- {txt}")
    else:
        lines.append("- Nessuna interpretazione disponibile")

    lines.append("")
    lines.append("### 3) Azioni prioritarie con impatto economico")
    if analysis.recommendations:
        for item in analysis.recommendations:
            txt = str(item).strip()
            if txt:
                lines.append(f"- {txt}")
    else:
        lines.append("- Nessuna azione disponibile")

    lines.append("")
    lines.append("### 4) Decisione consigliata")
    decision = str(analysis.summary or "").strip()
    if not decision:
        decision = "Serve una decisione basata sui dati attuali."
    lines.append(f"- {decision}")

    return "\n".join(lines).strip()


def format_cfo_response(
    analysis: AnalysisBlock,
    system_prompt: Optional[str] = None,
) -> str:
    system = system_prompt or DEFAULT_CFO_SYSTEM_PROMPT

    payload = {
        "kpi": _normalize_analysis_dict(analysis.kpi or {}),
        "insights": list(analysis.insights or []),
        "recommendations": list(analysis.recommendations or []),
        "summary": str(analysis.summary or ""),
        "extras": _normalize_analysis_dict(analysis.extras or {}),
    }

    prompt = (
        "Genera una risposta da CFO senior.\n"
        "Regole:\n"
        "- sii diretto\n"
        "- metti in evidenza priorità e rischio\n"
        "- usa impatti economici dove presenti\n"
        "- niente frasi vuote\n"
        "- chiudi sempre con una decisione consigliata\n\n"
        "Dati analisi (JSON):\n"
        + json.dumps(payload, ensure_ascii=False, indent=2)
    )

    if _HAVE_LLM:
        try:
            txt = llm_generate(system, prompt)
            if isinstance(txt, str) and txt.strip():
                cleaned = txt.strip()
                if not _looks_like_prompt_echo(cleaned):
                    return cleaned
        except Exception:
            pass

    return _render_deterministic_response(analysis)