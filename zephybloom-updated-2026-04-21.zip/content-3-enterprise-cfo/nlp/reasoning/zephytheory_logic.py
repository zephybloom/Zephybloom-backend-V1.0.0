# content/zephytheory/logic.py

from typing import Dict, Any


def zephytheory_logic(kpi: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Core brain:
    - legge KPI
    - trova il problema principale
    - identifica la leva
    - genera azioni concrete
    """

    fatt = float(kpi.get("fatturato", 0))
    utile = float(kpi.get("utile", 0))
    mc_rate = float(kpi.get("mc_rate", 0))
    roi = float(kpi.get("roi", 0))

    # =========================================================
    # 1. DIAGNOSI
    # =========================================================
    if utile <= 0:
        problem = "azienda non profittevole"
        priority = "profit"
    elif mc_rate < 0.3:
        problem = "marginalità bassa"
        priority = "margin"
    elif roi < 0.15:
        problem = "ritorno sugli investimenti basso"
        priority = "efficiency"
    else:
        problem = "crescita limitata"
        priority = "scale"

    # =========================================================
    # 2. LEVA STRATEGICA
    # =========================================================
    if priority == "profit":
        lever = "taglio costi + aumento prezzo"
    elif priority == "margin":
        lever = "ottimizzazione costi variabili"
    elif priority == "efficiency":
        lever = "riallocazione capitale"
    else:
        lever = "aumento fatturato"

    # =========================================================
    # 3. AZIONI
    # =========================================================
    actions = []

    if priority == "profit":
        actions = [
            "Ridurre costi fissi non strategici",
            "Aumentare pricing sui clienti meno sensibili",
            "Eliminare prodotti a bassa marginalità",
        ]

    elif priority == "margin":
        actions = [
            "Rinegoziare fornitori",
            "Aumentare prezzo medio",
            "Ridurre sprechi operativi",
        ]

    elif priority == "efficiency":
        actions = [
            "Tagliare investimenti a basso ROI",
            "Aumentare rotazione capitale",
            "Ottimizzare cash flow",
        ]

    elif priority == "scale":
        actions = [
            "Aumentare acquisition clienti",
            "Upsell su clienti esistenti",
            "Testare nuovi canali marketing",
        ]

    # =========================================================
    # 4. IMPATTO STIMATO
    # =========================================================
    impact = []

    for a in actions[:3]:
        impact.append(f"{a} → impatto stimato positivo su utile")

    return {
        "problem": problem,
        "priority": priority,
        "lever": lever,
        "actions": actions,
        "impact": impact,
    }