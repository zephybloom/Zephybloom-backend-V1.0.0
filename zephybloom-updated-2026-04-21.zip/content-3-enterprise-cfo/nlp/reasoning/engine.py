# -*- coding: utf-8 -*-
# content/nlp/reasoning/engine.py

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional

from nlp.reasoning.models import ReasoningContext, AnalysisBlock
from nlp.reasoning.utils import logger, safe_dict, safe_list
from nlp.reasoning.legacy import LegacyReasoningMixin
from nlp.reasoning.formatter import (
    DEFAULT_CFO_SYSTEM_PROMPT,
    format_cfo_response,
)

try:
    from nlp.reasoning.pipelines import run_reasoning_pipeline
except Exception:
    run_reasoning_pipeline = None  # type: ignore

try:
    from nlp.reasoning.cfo_logic import (
        extract_cfo_snapshot,
        diagnose_business,
        build_cfo_action_plan,
        build_cfo_decision_summary,
    )
    _HAVE_CFO_LOGIC = True
except Exception:
    _HAVE_CFO_LOGIC = False

    def extract_cfo_snapshot(
        kpi_payload: Dict[str, Any],
        fallback_payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        base = dict(fallback_payload or {})
        base.update(kpi_payload or {})
        return base

    def diagnose_business(snapshot: Dict[str, Any], sector: str = "default") -> Dict[str, Any]:
        return {
            "primary_issue": {},
            "issues": [],
            "sector": sector,
        }

    def build_cfo_action_plan(snapshot: Dict[str, Any], sector: str = "default") -> List[Dict[str, Any]]:
        return []

    def build_cfo_decision_summary(
        snapshot: Dict[str, Any],
        diagnosis: Dict[str, Any],
        actions: List[Dict[str, Any]],
    ) -> str:
        return "Analisi CFO completata."


class ReasoningEngine(LegacyReasoningMixin):
    SUPPORTED_INTENTS = {
        "analizza_kpi",
        "simula_scenario",
        "ottimizza_prezzi",
        "diagnosi_cassa",
        "valutazione_azienda",
        "piano_azioni",
        "opportunities",
    }

    INTENT_ALIASES = {
        "analizza_kpi": "analizza_kpi",
        "analizza": "analizza_kpi",
        "kpi": "analizza_kpi",
        "simula_scenario": "simula_scenario",
        "simulate": "simula_scenario",
        "scenario": "simula_scenario",
        "ottimizza_prezzi": "ottimizza_prezzi",
        "pricing": "ottimizza_prezzi",
        "price_opt": "ottimizza_prezzi",
        "diagnosi_cassa": "diagnosi_cassa",
        "cashflow": "diagnosi_cassa",
        "cash": "diagnosi_cassa",
        "valutazione_azienda": "valutazione_azienda",
        "valuation": "valutazione_azienda",
        "dcf": "valutazione_azienda",
        "piano_azioni": "piano_azioni",
        "azioni": "piano_azioni",
        "plan": "piano_azioni",
        "opportunities": "opportunities",
        "opportunita": "opportunities",
    }

    def run(self, cx: ReasoningContext) -> AnalysisBlock:
        intent = self._normalize_intent(cx.intent)

        if intent not in self.SUPPORTED_INTENTS:
            return self._fallback(cx)

        normalized_cx = ReasoningContext(
            intent=intent,
            query=cx.query,
            payload=cx.payload,
            params=cx.params,
            memory=cx.memory,
        )

        try:
            return self._run_pipeline_or_fallback(normalized_cx)
        except Exception as e:
            logger.exception("ReasoningEngine failure on intent=%s", intent)
            return AnalysisBlock(
                kpi={},
                insights=[f"Errore interno nel reasoning ({type(e).__name__})"],
                recommendations=["Riprova con dati minimi o con un intent più specifico."],
                summary="Errore nel motore di reasoning.",
                extras={"error": type(e).__name__, "intent": intent},
            )

    def _normalize_intent(self, intent: str) -> str:
        key = str(intent or "").strip().lower()
        return self.INTENT_ALIASES.get(key, key)

    def _run_pipeline_or_fallback(self, cx: ReasoningContext) -> AnalysisBlock:
        if run_reasoning_pipeline is not None:
            try:
                out = run_reasoning_pipeline(
                    intent=cx.intent,
                    payload=cx.payload,
                    params=cx.params,
                )
                if isinstance(out, dict):
                    return AnalysisBlock(
                        kpi=safe_dict(out.get("kpi")),
                        insights=[str(x) for x in safe_list(out.get("insights"))],
                        recommendations=[str(x) for x in safe_list(out.get("recommendations"))],
                        summary=str(out.get("summary", "") or ""),
                        extras=safe_dict(out.get("extras")) or None,
                    )
            except Exception as e:
                logger.warning("Pipeline esterna fallita, uso fallback legacy: %s", e)

        if cx.intent == "analizza_kpi":
            return self._analizza_kpi(cx)
        if cx.intent == "simula_scenario":
            return self._simula_scenario(cx)
        if cx.intent == "ottimizza_prezzi":
            return self._ottimizza_prezzi(cx)
        if cx.intent == "diagnosi_cassa":
            return self._diagnosi_cassa(cx)
        if cx.intent == "valutazione_azienda":
            return self._valutazione_azienda(cx)
        if cx.intent == "piano_azioni":
            return self._piano_azioni(cx)
        if cx.intent == "opportunities":
            return self._opportunities(cx)

        return self._fallback(cx)

    def _fallback(self, cx: ReasoningContext) -> AnalysisBlock:
        return AnalysisBlock(
            kpi={},
            insights=["Intent non riconosciuto; attivata analisi di fallback."],
            recommendations=[
                "Riformula la richiesta con un obiettivo chiaro.",
                "Usa uno di questi intent: analizza_kpi, simula_scenario, ottimizza_prezzi, diagnosi_cassa, valutazione_azienda, piano_azioni, opportunities.",
            ],
            summary="Fallback attivato.",
            extras={"intent_received": cx.intent},
        )

    def _enhance_as_cfo(
        self,
        *,
        kpi_payload: Dict[str, Any],
        fallback_payload: Optional[Dict[str, Any]] = None,
        sector: str = "default",
    ) -> AnalysisBlock:
        snapshot = extract_cfo_snapshot(kpi_payload, fallback_payload)
        diagnosis = diagnose_business(snapshot, sector=sector)
        actions = build_cfo_action_plan(snapshot, sector=sector)
        summary = build_cfo_decision_summary(snapshot, diagnosis, actions)

        primary = diagnosis.get("primary_issue", {}) or {}
        issues = diagnosis.get("issues", []) or []

        insights: List[str] = []

        if primary:
            impact = float(primary.get("impact_eur", 0.0) or 0.0)
            impact_fmt = f"{impact:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
            insights.append(
                f"Problema prioritario: {primary.get('title', 'n.d.')} | Impatto stimato: € {impact_fmt}"
            )

            why = str(primary.get("why", "")).strip()
            if why:
                insights.append(why)

        for issue in issues[1:3]:
            impact = float(issue.get("impact_eur", 0.0) or 0.0)
            impact_fmt = f"{impact:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
            insights.append(
                f"Criticità secondaria: {issue.get('title', 'n.d.')} | Impatto: € {impact_fmt}"
            )

        recommendations: List[str] = []

        for action in actions:
            impact = float(action.get("impact_eur", 0.0) or 0.0)
            impact_fmt = f"{impact:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
            recommendations.append(
                f"{action.get('title', 'Azione')} | "
                f"Priorità {action.get('priority', 0)}/10 | "
                f"Impatto € {impact_fmt} | "
                f"Perché: {action.get('why', '')} | "
                f"Come: {action.get('how', '')}"
            )

        return AnalysisBlock(
            kpi=snapshot,
            insights=insights,
            recommendations=recommendations,
            summary=summary,
            extras={
                "diagnosis": diagnosis,
                "actions": actions,
                "cfo_logic_enabled": _HAVE_CFO_LOGIC,
            },
        )


def answer_cfo(
    query: str,
    intent: str,
    payload: Dict[str, Any],
    params: Optional[Dict[str, Any]] = None,
    memory: Optional[Dict[str, Any]] = None,
    system_prompt: Optional[str] = None,
    fallback_text: Optional[str] = None,
) -> Dict[str, Any]:
    engine = ReasoningEngine()
    cx = ReasoningContext(
        intent=intent,
        query=query,
        payload=payload or {},
        params=params,
        memory=memory,
    )

    analysis = engine.run(cx)

    try:
        text = format_cfo_response(
            analysis=analysis,
            system_prompt=system_prompt or DEFAULT_CFO_SYSTEM_PROMPT,
        )
    except Exception as e:
        logger.warning("Formatter failed, fallback text used: %s", e)
        text = fallback_text or analysis.summary or "Analisi completata."

    return {
        "text": text,
        "analysis": asdict(analysis),
    }


if __name__ == "__main__":
    fake_payload = {
        "sales": 2_400_000,
        "gross_margin_rate": 0.45,
        "ebitda": 510_000,
        "net_profit": 430_000,
        "ccc_days": 55,
    }

    out = answer_cfo(
        query="Analizza il mio report",
        intent="analizza_kpi",
        payload=fake_payload,
    )

    print(out["text"])