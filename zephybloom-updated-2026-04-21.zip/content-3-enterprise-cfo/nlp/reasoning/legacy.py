# -*- coding: utf-8 -*-
# content/nlp/reasoning/legacy.py

from __future__ import annotations

from typing import Any, Dict, List

from nlp.reasoning.models import ReasoningContext, AnalysisBlock
from nlp.reasoning.utils import (
    logger,
    safe_call,
    safe_dict,
    fmt_num,
    fmt_pct_ratio,
    pick_first_number,
)

# KPI summary
try:
    from core.kpi import compute_kpi_summary  # type: ignore
except Exception:
    compute_kpi_summary = None  # type: ignore

# Scenario simulator
try:
    from core.simulator import simulate_scenario  # type: ignore
except Exception:
    simulate_scenario = None  # type: ignore

# Pricing engine
try:
    from core.pricing import price_ladder_and_optimize  # type: ignore
except Exception:
    price_ladder_and_optimize = None  # type: ignore

# Cash / working capital
try:
    from core.cash import cash_cycle_and_wc  # type: ignore
except Exception:
    cash_cycle_and_wc = None  # type: ignore

# Valuation
try:
    from core.valuation import dcf_valuation, project_eval  # type: ignore
except Exception:
    dcf_valuation = None  # type: ignore
    project_eval = None  # type: ignore


class LegacyReasoningMixin:
    def _analizza_kpi(self, cx: ReasoningContext) -> AnalysisBlock:
        kpi, err = safe_call(compute_kpi_summary, cx.payload)

        insights: List[str] = []
        recommendations: List[str] = []

        if kpi:
            sales = pick_first_number(kpi, ["sales", "ricavi", "fatturato"], 0.0)
            ebitda = pick_first_number(kpi, ["ebitda"], 0.0)
            utile = pick_first_number(kpi, ["net_profit", "utile", "net_income"], 0.0)
            mc_rate = pick_first_number(kpi, ["gross_margin_rate", "mc_rate"], 0.0)
            roi = pick_first_number(kpi, ["roi", "roi_pct"], 0.0)
            ccc = pick_first_number(kpi, ["ccc_days", "ccc"], 0.0)

            if sales > 0 and ebitda != 0:
                insights.append(f"EBITDA/Ricavi ≈ {fmt_pct_ratio(ebitda / sales)}")
            if sales > 0 and utile != 0:
                insights.append(f"Net margin ≈ {fmt_pct_ratio(utile / sales)}")
            if mc_rate:
                insights.append(f"Margine lordo ≈ {fmt_pct_ratio(mc_rate)}")
            if roi:
                insights.append(f"ROI ≈ {fmt_pct_ratio(roi)}")
            if ccc:
                insights.append(f"CCC ≈ {fmt_num(ccc)} giorni")

            if mc_rate and mc_rate < 0.30:
                recommendations.append("Priorità: aumentare marginalità lorda su pricing, mix e costi variabili")
            if sales > 0 and utile <= 0:
                recommendations.append("La struttura sta assorbendo troppo valore: rivedi costi fissi e produttività")
            if ccc and ccc > 60:
                recommendations.append("Riduci DSO e ottimizza scorte per liberare cassa")
            if not recommendations:
                recommendations.extend(
                    [
                        "Difendi il margine sulle linee più profittevoli",
                        "Rialloca budget su attività a maggior ritorno",
                        "Monitora settimanalmente utile, EBITDA e ciclo di cassa",
                    ]
                )
        else:
            insights.append("KPI base non disponibili (adapter mancante o errore).")
            if err:
                insights.append(f"Dettaglio tecnico: {err}")
            recommendations.extend(
                [
                    "Collega o correggi il modulo KPI summary",
                    "Passa un payload con ricavi, costi variabili, costi fissi e investimenti",
                ]
            )

        return AnalysisBlock(
            kpi=kpi or {},
            insights=insights,
            recommendations=recommendations,
            summary="Analisi KPI completata; focus su marginalità, struttura e rotazione di cassa.",
            extras={"adapter_error": err} if err else None,
        )

    def _simula_scenario(self, cx: ReasoningContext) -> AnalysisBlock:
        params = safe_dict(cx.params)
        sim, err = safe_call(simulate_scenario, cx.payload, params)

        insights: List[str] = []
        recommendations: List[str] = []

        if sim:
            delta_utile = pick_first_number(sim, ["delta_net_profit", "delta_utile", "delta_profit"], 0.0)
            utile_post = pick_first_number(sim, ["utile", "net_profit"], 0.0)
            mc_rate = pick_first_number(sim, ["mc_rate", "gross_margin_rate"], 0.0)
            sales_post = pick_first_number(sim, ["sales", "ricavi", "fatturato"], 0.0)

            if delta_utile:
                insights.append(f"Variazione utile stimata: € {fmt_num(delta_utile)}")
            if utile_post:
                insights.append(f"Utile post-scenario: € {fmt_num(utile_post)}")
            if sales_post:
                insights.append(f"Ricavi post-scenario: € {fmt_num(sales_post)}")
            if mc_rate:
                insights.append(f"MC-rate post-scenario ≈ {fmt_pct_ratio(mc_rate)}")

            recommendations.extend(
                [
                    "Valida i driver su un test controllato prima del roll-out pieno",
                    "Definisci guardrail su volume minimo e margine minimo",
                    "Confronta scenario atteso vs scenario reale entro 2–4 settimane",
                ]
            )
        else:
            insights.append("Simulatore scenario non disponibile o parametri non validi.")
            if err:
                insights.append(f"Dettaglio tecnico: {err}")
            recommendations.extend(
                [
                    "Passa payload base + params con leve scenario",
                    "Verifica che il modulo simulate_scenario sia collegato correttamente",
                ]
            )

        return AnalysisBlock(
            kpi=sim or {},
            insights=insights,
            recommendations=recommendations,
            summary="Scenario elaborato; consigliato testare le leve in modo progressivo.",
            extras={"params": params, "adapter_error": err} if (params or err) else None,
        )

    def _ottimizza_prezzi(self, cx: ReasoningContext) -> AnalysisBlock:
        pricing_cfg = safe_dict(safe_dict(cx.params).get("pricing"))
        rez, err = safe_call(price_ladder_and_optimize, cx.payload, pricing_cfg)

        insights: List[str] = []
        recommendations: List[str] = []

        if rez:
            optimum = safe_dict(rez.get("optimum"))
            ladder_rows = rez.get("ladder_rows")
            best_pct = optimum.get("pct")
            best_profit = optimum.get("profit")
            best_price = optimum.get("price")

            if ladder_rows is not None:
                insights.append(f"Numero scenari ladder: {ladder_rows}")
            if best_pct is not None:
                insights.append(f"Delta prezzo ottimale: {fmt_num(best_pct)}%")
            if best_price is not None:
                insights.append(f"Prezzo ottimale stimato: € {fmt_num(best_price)}")
            if best_profit is not None:
                insights.append(f"Utile stimato al best point: € {fmt_num(best_profit)}")

            recommendations.extend(
                [
                    "Applica il nuovo prezzo prima ai cluster meno sensibili",
                    "Supporta il repricing con rafforzamento del valore percepito",
                    "Monitora conversione, churn e ticket medio nelle settimane successive",
                ]
            )
        else:
            insights.append("Motore pricing non disponibile o non collegato.")
            if err:
                insights.append(f"Dettaglio tecnico: {err}")
            recommendations.extend(
                [
                    "Costruisci una ladder prezzi con ipotesi di elasticità",
                    "Testa 2–3 coorti clienti prima di ottimizzare globalmente",
                ]
            )

        return AnalysisBlock(
            kpi=rez or {},
            insights=insights,
            recommendations=recommendations,
            summary="Ottimizzazione prezzo completata; eseguire rollout graduale e misurato.",
            extras={"pricing_cfg": pricing_cfg, "adapter_error": err} if (pricing_cfg or err) else None,
        )

    def _diagnosi_cassa(self, cx: ReasoningContext) -> AnalysisBlock:
        cash, err = safe_call(cash_cycle_and_wc, cx.payload)

        insights: List[str] = []
        recommendations: List[str] = []

        if cash:
            ccc = pick_first_number(cash, ["ccc_days", "ccc"], 0.0)
            wc_need = pick_first_number(cash, ["wc_need", "working_capital_need"], 0.0)
            dso = pick_first_number(cash, ["dso"], 0.0)
            dio = pick_first_number(cash, ["dio"], 0.0)
            dpo = pick_first_number(cash, ["dpo"], 0.0)

            if ccc:
                insights.append(f"CCC ≈ {fmt_num(ccc)} giorni")
            if wc_need:
                insights.append(f"Fabbisogno di capitale circolante: € {fmt_num(wc_need)}")
            if dso:
                insights.append(f"DSO ≈ {fmt_num(dso)} giorni")
            if dio:
                insights.append(f"DIO ≈ {fmt_num(dio)} giorni")
            if dpo:
                insights.append(f"DPO ≈ {fmt_num(dpo)} giorni")

            recommendations.extend(
                [
                    "Riduci DSO con reminder, anticipo incassi e policy più forti",
                    "Ottimizza stock e rotazione su SKU principali",
                    "Allunga DPO dove sostenibile senza stressare i fornitori chiave",
                ]
            )
        else:
            insights.append("Modulo cash / CCC non disponibile.")
            if err:
                insights.append(f"Dettaglio tecnico: {err}")
            recommendations.extend(
                [
                    "Collega il modulo cash_cycle_and_wc",
                    "Passa almeno ricavi, cogs/costi_variabili, DSO, DIO e DPO",
                ]
            )

        return AnalysisBlock(
            kpi=cash or {},
            insights=insights,
            recommendations=recommendations,
            summary="Diagnosi di cassa completata; priorità su incassi, stock e termini di pagamento.",
            extras={"adapter_error": err} if err else None,
        )

    def _valutazione_azienda(self, cx: ReasoningContext) -> AnalysisBlock:
        valuation_cfg = safe_dict(safe_dict(cx.params).get("valuation"))

        dcf, err_dcf = safe_call(dcf_valuation, cx.payload, valuation_cfg)
        proj, err_proj = safe_call(project_eval, cx.payload, valuation_cfg)

        insights: List[str] = []
        recommendations: List[str] = []

        if dcf:
            ev = dcf.get("enterprise_value")
            eq = dcf.get("equity_value")
            wacc_val = dcf.get("wacc_pct") or dcf.get("discount_rate_pct")

            if ev is not None:
                insights.append(f"Enterprise Value stimato: € {fmt_num(ev)}")
            if eq is not None:
                insights.append(f"Equity Value stimato: € {fmt_num(eq)}")
            if wacc_val is not None:
                insights.append(f"WACC / tasso di sconto: {fmt_num(wacc_val)}%")

        if proj:
            irr = proj.get("irr")
            npv = proj.get("npv")
            payback = proj.get("payback_period")

            if irr is not None:
                try:
                    irr_num = float(irr)
                    if abs(irr_num) <= 1.5:
                        insights.append(f"IRR progetto ≈ {irr_num * 100:.1f}%")
                    else:
                        insights.append(f"IRR progetto ≈ {irr_num:.1f}%")
                except Exception:
                    pass
            if npv is not None:
                insights.append(f"NPV progetto ≈ € {fmt_num(npv)}")
            if payback is not None:
                insights.append(f"Payback ≈ {fmt_num(payback)} anni")

        if not insights:
            insights.append("Valutazione non disponibile (adapter mancante o errore).")

        recommendations.extend(
            [
                "Esegui sensitivity su WACC e terminal growth",
                "Confronta il risultato con peer e multipli di mercato",
                "Rendi esplicite le assunzioni chiave prima di prendere decisioni di investimento",
            ]
        )

        return AnalysisBlock(
            kpi={
                "dcf": dcf or {},
                "project": proj or {},
            },
            insights=insights,
            recommendations=recommendations,
            summary="Valutazione completata; allineare le assunzioni con scenario realistico e prudente.",
            extras={
                "valuation_cfg": valuation_cfg,
                "dcf_error": err_dcf,
                "project_error": err_proj,
            },
        )

    def _piano_azioni(self, cx: ReasoningContext) -> AnalysisBlock:
        kpi, err = safe_call(compute_kpi_summary, cx.payload)

        insights: List[str] = []
        recommendations: List[str] = []

        if kpi:
            sales = pick_first_number(kpi, ["sales", "ricavi", "fatturato"], 0.0)
            utile = pick_first_number(kpi, ["utile", "net_profit", "net_income"], 0.0)
            mc_rate = pick_first_number(kpi, ["gross_margin_rate", "mc_rate"], 0.0)

            if sales:
                insights.append(f"Base ricavi attuale: € {fmt_num(sales)}")
            if utile or utile == 0:
                insights.append(f"Base utile attuale: € {fmt_num(utile)}")
            if mc_rate:
                insights.append(f"Marginalità lorda attuale: {fmt_pct_ratio(mc_rate)}")

        insights.extend(
            [
                "Il piano deve essere costruito su 3 direttrici: crescita, margine, cassa",
                "Ogni azione deve avere owner, timing e KPI di verifica",
            ]
        )

        recommendations.extend(
            [
                "Ricavi: spingi upsell, repricing selettivo e offerte a maggiore ticket",
                "Margini: riduci CV con sourcing, standardizzazione e meno sprechi",
                "Cassa: riduci DSO e ottimizza il ciclo di rotazione del capitale circolante",
            ]
        )

        return AnalysisBlock(
            kpi=kpi or {},
            insights=insights,
            recommendations=recommendations,
            summary="Piano d’azione definito; esecuzione consigliata in sprint da 4–6 settimane.",
            extras={"adapter_error": err} if err else None,
        )

    def _opportunities(self, cx: ReasoningContext) -> AnalysisBlock:
        payload = safe_dict(cx.payload)
        sector = str(payload.get("sector", "default"))
        elasticity = pick_first_number(payload, ["price_elasticity", "elasticity"], -1.2)

        insights: List[str] = []
        recommendations: List[str] = []
        out_kpi: Dict[str, Any] = {}

        try:
            from advice.opportunities import OpportunityEngine, format_opportunity  # type: ignore

            engine = OpportunityEngine(sector=sector)
            opps = engine.generate(payload, elasticity=elasticity)
            out_kpi["opportunities_count"] = len(opps)

            if opps:
                for o in opps[:5]:
                    title = getattr(o, "title", "Opportunity")
                    delta_profit = getattr(o, "delta_profit", 0.0)
                    delta_roi = getattr(o, "delta_roi_pct", 0.0)
                    steps = getattr(o, "steps", []) or []

                    insights.append(
                        f"{title}: ΔUtile ≈ € {fmt_num(delta_profit)} | ΔROI ≈ {fmt_num(delta_roi)}%"
                    )

                    if steps:
                        recommendations.append(f"{title} — Passi: {'; '.join([str(s) for s in steps[:3]])}")

                out_kpi["formatted"] = [format_opportunity(o) for o in opps[:5]]
            else:
                insights.append("Nessuna opportunità significativa rilevata sui dati attuali.")
        except Exception as e:
            logger.warning("Opportunities legacy fallback failed: %s", e)
            insights.append("Modulo opportunità non disponibile o non eseguibile.")
            recommendations.extend(
                [
                    "Rivedi pricing dove il cliente percepisce già alto valore",
                    "Riduci costi variabili sulle voci più pesanti",
                    "Snellisci i costi fissi che non accelerano ricavo o controllo",
                ]
            )

        return AnalysisBlock(
            kpi=out_kpi,
            insights=insights,
            recommendations=recommendations,
            summary="Opportunità individuate; conviene attaccare prima le leve che aumentano utile con attrito minimo.",
            extras={"sector": sector, "elasticity": elasticity},
        )