# -*- coding: utf-8 -*-
# content/nlp/reasoning_pipelines.py
# High-level reasoning pipelines for ZephyBloom CFO
# Versione safe: evita recursion su compute_kpis e usa logica deterministica locale

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple, Callable


# =========================================================
# Soft logger
# =========================================================
try:
    import logging

    logger = logging.getLogger("reasoning_pipelines")
    if not logger.handlers:
        logging.basicConfig(level=logging.INFO)
except Exception:
    class _DummyLogger:
        def info(self, *a, **k):
            pass

        def warning(self, *a, **k):
            pass

        def error(self, *a, **k):
            pass

        def exception(self, *a, **k):
            pass

    logger = _DummyLogger()


# =========================================================
# Soft imports adapters
# =========================================================
try:
    from core.kpi import compute_kpi_summary  # type: ignore
except Exception:
    compute_kpi_summary = None  # type: ignore

try:
    from core.scenario import simulate, simulate_matrix  # type: ignore
except Exception:
    simulate = None  # type: ignore
    simulate_matrix = None  # type: ignore

try:
    from core.simulator import simulate_scenario  # type: ignore
except Exception:
    simulate_scenario = None  # type: ignore

try:
    from core.forecast import forecast_series  # type: ignore
except Exception:
    forecast_series = None  # type: ignore

try:
    from core.pricing import price_ladder_and_optimize  # type: ignore
except Exception:
    price_ladder_and_optimize = None  # type: ignore

try:
    from core.cash import cash_cycle_and_wc  # type: ignore
except Exception:
    cash_cycle_and_wc = None  # type: ignore

try:
    from core.finance import dcf_equity, project_eval, wacc  # type: ignore
except Exception:
    dcf_equity = None  # type: ignore
    project_eval = None  # type: ignore
    wacc = None  # type: ignore

try:
    from core.valuation import dcf_valuation  # type: ignore
except Exception:
    dcf_valuation = None  # type: ignore

try:
    from advice.opportunities import OpportunityEngine, format_opportunity  # type: ignore
except Exception:
    OpportunityEngine = None  # type: ignore
    format_opportunity = None  # type: ignore

try:
    from strategy.analysis import (
        strategic_snapshot,
        extract_business_state,
        build_priority_actions,
    )  # type: ignore
except Exception:
    strategic_snapshot = None  # type: ignore
    extract_business_state = None  # type: ignore
    build_priority_actions = None  # type: ignore


# =========================================================
# Helpers
# =========================================================
def _safe_call(
    fn: Optional[Callable[..., Any]],
    *args,
    **kwargs,
) -> Tuple[Optional[dict], Optional[str]]:
    if fn is None:
        return None, "module_missing"

    try:
        out = fn(*args, **kwargs)

        if isinstance(out, dict):
            return out, None

        if hasattr(out, "model_dump"):
            try:
                dumped = out.model_dump()
                if isinstance(dumped, dict):
                    return dumped, None
            except Exception:
                pass

        return {"value": out}, None
    except Exception as e:
        logger.error("Pipeline adapter error on %s: %s", getattr(fn, "__name__", "unknown"), e)
        return None, str(e)


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(float(x))
    except Exception:
        return default


def _safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}


def _safe_list(x: Any) -> List[Any]:
    return x if isinstance(x, list) else []


def _as_float_list(x: Any) -> List[float]:
    if not isinstance(x, list):
        return []

    out: List[float] = []
    for item in x:
        try:
            out.append(float(item))
        except Exception:
            continue
    return out


def _pick_first_number(d: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    for k in keys:
        if k in d:
            try:
                return float(d[k])
            except Exception:
                continue
    return default


def _fmt_num(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)
    return f"{v:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _fmt_pct_ratio(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)

    if abs(v) <= 1.5:
        return f"{v * 100:.1f}%"
    return f"{v:.1f}%"


def _base_profitability_from_payload(payload: Dict[str, Any]) -> Dict[str, float]:
    fatt = _pick_first_number(payload, ["fatturato", "sales", "ricavi"], 0.0)
    cv = _pick_first_number(payload, ["costi_variabili", "cogs"], 0.0)
    cf = _pick_first_number(payload, ["costi_fissi"], 0.0)
    amm = _pick_first_number(payload, ["ammortamenti"], 0.0)
    inv = _pick_first_number(payload, ["investimenti"], 0.0)

    utile = fatt - cv - cf
    ebitda = utile + amm
    mc = fatt - cv
    mc_rate = (mc / fatt) if fatt > 0 else 0.0
    roi = (utile / inv) if inv > 0 else 0.0

    return {
        "fatturato": fatt,
        "costi_variabili": cv,
        "costi_fissi": cf,
        "ammortamenti": amm,
        "investimenti": inv,
        "utile": utile,
        "ebitda": ebitda,
        "margine_contribuzione": mc,
        "mc_rate": mc_rate,
        "roi": roi,
    }


def _rank_recommendations(items: List[str]) -> List[str]:
    clean: List[str] = []
    seen = set()

    for item in items:
        s = str(item or "").strip()
        if not s:
            continue
        key = s.lower()
        if key in seen:
            continue
        seen.add(key)
        clean.append(s)

    return clean


# =========================================================
# Standard output contract
# =========================================================
def make_analysis_block(
    *,
    kpi: Optional[Dict[str, Any]] = None,
    insights: Optional[List[str]] = None,
    recommendations: Optional[List[str]] = None,
    summary: str = "",
    extras: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "kpi": kpi or {},
        "insights": insights or [],
        "recommendations": _rank_recommendations(recommendations or []),
        "summary": str(summary or ""),
        "extras": extras or {},
    }


# =========================================================
# KPI PIPELINE
# =========================================================
def pipeline_analizza_kpi(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    summary_dict, err_summary = _safe_call(compute_kpi_summary, payload)

    merged: Dict[str, Any] = {}
    if summary_dict:
        merged.update(summary_dict)

    base = _base_profitability_from_payload(merged or payload)

    fatt = base["fatturato"]
    utile = base["utile"]
    ebitda = base["ebitda"]
    mc = base["margine_contribuzione"]
    mc_rate = base["mc_rate"]
    roi = base["roi"]

    insights: List[str] = []

    if fatt > 0:
        insights.append(f"Ricavi attuali ≈ € {_fmt_num(fatt)}")
    insights.append(f"EBITDA ≈ € {_fmt_num(ebitda)}")
    insights.append(f"Utile ≈ € {_fmt_num(utile)}")
    insights.append(f"Margine di contribuzione ≈ {_fmt_pct_ratio(mc_rate)}")
    insights.append(f"ROI ≈ {_fmt_pct_ratio(roi)}")

    recommendations: List[str] = []

    if mc_rate < 0.30:
        recommendations.append("Priorità assoluta: migliorare pricing, mix e costi variabili")
    if utile <= 0:
        recommendations.append("Riduci struttura fissa o rialza la contribuzione per tornare in area profitto")
    if roi < 0.10:
        recommendations.append("Rialloca investimenti sulle leve a ritorno più rapido")
    if not recommendations:
        recommendations.extend(
            [
                "Consolida le linee ad alta contribuzione",
                "Rendi più disciplinata la struttura dei costi",
                "Monitora ogni mese utile, EBITDA e ritorno sul capitale",
            ]
        )

    merged.update(
        {
            "fatturato": fatt,
            "costi_variabili": base["costi_variabili"],
            "costi_fissi": base["costi_fissi"],
            "ammortamenti": base["ammortamenti"],
            "investimenti": base["investimenti"],
            "utile": utile,
            "ebitda": ebitda,
            "margine_contribuzione": mc,
            "mc_rate": mc_rate,
            "roi": roi,
        }
    )

    extras = {
        "errors": {
            "summary": None if compute_kpi_summary is None else err_summary,
            "metrics": None,
        }
    }

    return make_analysis_block(
        kpi=merged,
        insights=insights,
        recommendations=recommendations,
        summary="Analisi KPI completata; il focus va messo su marginalità, utile e qualità del capitale impiegato.",
        extras=extras,
    )


# =========================================================
# SCENARIO PIPELINE
# =========================================================
def pipeline_simula_scenario(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    params = _safe_dict(params)

    sim_result, err_a = _safe_call(simulate_scenario, payload, params)
    if sim_result is None and simulate is not None:
        base = _safe_dict(payload)
        sim_result, err_b = _safe_call(simulate, base, params)
        err_used = err_b
    else:
        err_used = err_a

    insights: List[str] = []
    recommendations: List[str] = []

    if sim_result:
        utile = _pick_first_number(sim_result, ["utile", "delta_utile", "delta_profit", "delta_net_profit"], 0.0)
        fatt = _pick_first_number(sim_result, ["fatturato", "sales", "ricavi"], 0.0)
        ebitda = _pick_first_number(sim_result, ["ebitda"], 0.0)
        mc_rate = _pick_first_number(sim_result, ["mc_rate", "gross_margin_rate"], 0.0)

        if fatt:
            insights.append(f"Ricavi post scenario ≈ € {_fmt_num(fatt)}")
        insights.append(f"Impatto utile / utile post scenario ≈ € {_fmt_num(utile)}")
        if ebitda:
            insights.append(f"EBITDA post scenario ≈ € {_fmt_num(ebitda)}")
        if mc_rate:
            insights.append(f"Marginalità post scenario ≈ {_fmt_pct_ratio(mc_rate)}")

        recommendations.extend(
            [
                "Testa lo scenario prima su un perimetro piccolo",
                "Definisci un KPI di stop-loss e uno di validazione",
                "Confronta risultato atteso vs reale entro poche settimane",
            ]
        )
    else:
        insights.append("Scenario non simulabile con gli adapter attuali.")
        recommendations.extend(
            [
                "Passa un payload base coerente con ricavi e costi",
                "Passa params con leve percentuali o assolute",
            ]
        )

    return make_analysis_block(
        kpi=sim_result or {},
        insights=insights,
        recommendations=recommendations,
        summary="Simulazione completata; procedere solo con roll-out progressivi e numeri sotto controllo.",
        extras={"params": params, "adapter_error": err_used},
    )


# =========================================================
# PRICING PIPELINE
# =========================================================
def pipeline_ottimizza_prezzi(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    params = _safe_dict(params)
    pricing_cfg = _safe_dict(params.get("pricing"))

    rez, err = _safe_call(price_ladder_and_optimize, payload, pricing_cfg)

    if rez is None:
        base = _base_profitability_from_payload(payload)
        prezzo = _pick_first_number(payload, ["prezzo_medio", "price"], 0.0)
        cvu = _pick_first_number(payload, ["costo_variabile_unitario", "cvu"], 0.0)
        elasticity = _pick_first_number(payload, ["price_elasticity", "elasticity"], -1.2)

        rez = {
            "price_before": prezzo,
            "cvu": cvu,
            "elasticity": elasticity,
            "estimated_profitability_base": base["utile"],
        }

    insights: List[str] = []
    recommendations: List[str] = []

    optimum = _safe_dict(rez.get("optimum"))
    if optimum:
        if "pct" in optimum:
            insights.append(f"Delta prezzo ottimale ≈ {_fmt_num(optimum.get('pct'))}%")
        if "price" in optimum:
            insights.append(f"Prezzo ottimale ≈ € {_fmt_num(optimum.get('price'))}")
        if "profit" in optimum:
            insights.append(f"Profitto associato ≈ € {_fmt_num(optimum.get('profit'))}")
    else:
        if "price_before" in rez:
            insights.append(f"Prezzo base disponibile ≈ € {_fmt_num(rez.get('price_before'))}")
        if "estimated_profitability_base" in rez:
            insights.append(f"Base utile stimata ≈ € {_fmt_num(rez.get('estimated_profitability_base'))}")

    recommendations.extend(
        [
            "Segmenta il repricing sui clienti meno sensibili",
            "Aumenta il prezzo solo insieme a una narrativa forte di valore",
            "Controlla conversione, churn e ticket medio dopo il test",
        ]
    )

    return make_analysis_block(
        kpi=rez,
        insights=insights,
        recommendations=recommendations,
        summary="Ottimizzazione pricing completata; il repricing va gestito per cluster e con forte controllo dei segnali.",
        extras={"pricing_cfg": pricing_cfg, "adapter_error": err},
    )


# =========================================================
# CASH PIPELINE
# =========================================================
def pipeline_diagnosi_cassa(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cash, err = _safe_call(cash_cycle_and_wc, payload)

    if cash is None:
        fatt = _pick_first_number(payload, ["fatturato", "sales", "ricavi"], 0.0)
        cv = _pick_first_number(payload, ["costi_variabili", "cogs"], 0.0)
        dso = _pick_first_number(payload, ["dso"], 0.0)
        dio = _pick_first_number(payload, ["dio"], 0.0)
        dpo = _pick_first_number(payload, ["dpo"], 0.0)

        ccc = dso + dio - dpo
        cash = {
            "ccc_days": ccc,
            "wc_need_estimate": (fatt / 365.0) * max(dso, 0.0) + (cv / 365.0) * max(dio - dpo, 0.0),
            "dso": dso,
            "dio": dio,
            "dpo": dpo,
        }

    ccc = _pick_first_number(cash, ["ccc_days", "ccc"], 0.0)
    wc_need = _pick_first_number(cash, ["wc_need", "wc_need_estimate", "working_capital_need"], 0.0)
    dso = _pick_first_number(cash, ["dso"], 0.0)
    dio = _pick_first_number(cash, ["dio"], 0.0)
    dpo = _pick_first_number(cash, ["dpo"], 0.0)

    insights: List[str] = []
    insights.append(f"CCC ≈ {_fmt_num(ccc)} giorni")
    if wc_need:
        insights.append(f"Fabbisogno circolante stimato ≈ € {_fmt_num(wc_need)}")
    if dso:
        insights.append(f"DSO ≈ {_fmt_num(dso)} giorni")
    if dio:
        insights.append(f"DIO ≈ {_fmt_num(dio)} giorni")
    if dpo:
        insights.append(f"DPO ≈ {_fmt_num(dpo)} giorni")

    recommendations = [
        "Riduci DSO con reminder e regole di incasso più forti",
        "Ottimizza il magazzino e la rotazione del capitale",
        "Estendi i tempi di pagamento solo dove sostenibile",
    ]

    return make_analysis_block(
        kpi=cash,
        insights=insights,
        recommendations=recommendations,
        summary="Diagnosi di cassa completata; il focus è liberare liquidità senza rompere la macchina operativa.",
        extras={"adapter_error": err},
    )


# =========================================================
# VALUATION PIPELINE
# =========================================================
def pipeline_valutazione_azienda(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    params = _safe_dict(params)
    valuation_cfg = _safe_dict(params.get("valuation"))

    dcf_out, err_dcf = _safe_call(dcf_valuation, payload, valuation_cfg)

    if dcf_out is None and dcf_equity is not None:
        fcf = _as_float_list(payload.get("dcf_fcf"))
        if fcf:
            rate = _pick_first_number(payload, ["discount_rate_pct", "wacc_pct"], 10.0)
            growth = _pick_first_number(payload, ["terminal_growth_pct"], 2.0)
            net_debt = _pick_first_number(payload, ["net_debt"], 0.0)
            dcf_out, err_dcf = _safe_call(
                dcf_equity,
                fcf,
                rate,
                growth,
                net_debt,
            )

    proj_out = None
    err_proj = None
    cfs = _as_float_list(payload.get("cashflows"))
    discount_rate = _pick_first_number(payload, ["discount_rate_pct"], 0.0)

    if cfs and discount_rate and project_eval is not None:
        proj_out, err_proj = _safe_call(project_eval, cfs, discount_rate)

    insights: List[str] = []

    if dcf_out:
        if "enterprise_value" in dcf_out:
            insights.append(f"Enterprise Value ≈ € {_fmt_num(dcf_out.get('enterprise_value'))}")
        if "equity_value" in dcf_out:
            insights.append(f"Equity Value ≈ € {_fmt_num(dcf_out.get('equity_value'))}")
        if "wacc_pct" in dcf_out:
            insights.append(f"WACC ≈ {_fmt_num(dcf_out.get('wacc_pct'))}%")

    if proj_out:
        if "npv" in proj_out:
            insights.append(f"NPV ≈ € {_fmt_num(proj_out.get('npv'))}")
        if "irr" in proj_out:
            irr_val = _safe_float(proj_out.get("irr"), 0.0)
            if abs(irr_val) <= 1.5:
                insights.append(f"IRR ≈ {irr_val * 100:.1f}%")
            else:
                insights.append(f"IRR ≈ {irr_val:.1f}%")
        if "payback_period" in proj_out:
            insights.append(f"Payback ≈ {_fmt_num(proj_out.get('payback_period'))} anni")

    if not insights:
        insights.append("Valutazione non disponibile con gli adapter attuali.")

    recommendations = [
        "Stressa il valore su WACC e terminal growth",
        "Confronta il risultato con peer e multipli comparabili",
        "Rendi trasparenti tutte le assunzioni di fondo prima di decidere",
    ]

    return make_analysis_block(
        kpi={
            "dcf": dcf_out or {},
            "project": proj_out or {},
        },
        insights=insights,
        recommendations=recommendations,
        summary="Valutazione completata; il numero finale ha senso solo se le assunzioni sono credibili e difendibili.",
        extras={
            "valuation_cfg": valuation_cfg,
            "dcf_error": err_dcf,
            "project_error": err_proj,
        },
    )


# =========================================================
# ACTION PLAN PIPELINE
# =========================================================
def pipeline_piano_azioni(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    kpi_block = pipeline_analizza_kpi(payload, params)
    strategic = strategic_snapshot(payload) if callable(strategic_snapshot) else {}
    state = extract_business_state(payload) if callable(extract_business_state) else {}
    problem = str(_safe_dict(strategic).get("problem", ""))
    sector = str(_safe_dict(strategic).get("sector", payload.get("sector", "default")))
    phase = str(_safe_dict(strategic).get("phase", "growth"))

    actions = []
    if callable(build_priority_actions):
        try:
            actions = build_priority_actions(state or {}, problem=problem, sector=sector, phase=phase)
        except Exception as e:
            logger.warning("build_priority_actions failed: %s", e)

    insights = list(kpi_block.get("insights", []))
    if problem:
        insights.append(f"Problema prioritario identificato: {problem}")
    if sector:
        insights.append(f"Settore rilevato: {sector}")
    if phase:
        insights.append(f"Fase business: {phase}")

    recommendations: List[str] = []

    if actions:
        for a in actions[:5]:
            title = str(a.get("title", "")).strip()
            why = str(a.get("why", "")).strip()
            how = str(a.get("how", "")).strip()

            text = title
            if why:
                text += f" — {why}"
            if how:
                text += f" | Come: {how}"
            recommendations.append(text)

    if not recommendations:
        recommendations.extend(
            [
                "Ricavi: lavora su upsell, repricing e offerte a ticket più alto",
                "Margini: riduci CV e aumenta il valore trattenuto per vendita",
                "Cassa: accorcia DSO e migliora la disciplina del working capital",
            ]
        )

    return make_analysis_block(
        kpi=_safe_dict(kpi_block.get("kpi")),
        insights=insights,
        recommendations=recommendations,
        summary="Piano d’azione costruito; ora serve execution rigorosa con owner, timing e KPI di verifica.",
        extras={
            "problem": problem,
            "sector": sector,
            "phase": phase,
            "actions_count": len(actions),
        },
    )


# =========================================================
# OPPORTUNITIES PIPELINE
# =========================================================
def pipeline_opportunities(payload: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    sector = str(payload.get("sector", "default"))
    elasticity = _pick_first_number(payload, ["price_elasticity", "elasticity"], -1.2)

    insights: List[str] = []
    recommendations: List[str] = []
    out_kpi: Dict[str, Any] = {}

    if OpportunityEngine is not None:
        try:
            engine = OpportunityEngine(sector=sector)
            opps = engine.generate(payload, elasticity=elasticity)
            out_kpi["opportunities_count"] = len(opps)

            if opps:
                for o in opps[:5]:
                    title = getattr(o, "title", "Opportunity")
                    delta_profit = getattr(o, "delta_profit", 0.0)
                    delta_roi = getattr(o, "delta_roi_pct", 0.0)

                    insights.append(
                        f"{title}: ΔUtile ≈ € {_fmt_num(delta_profit)} | ΔROI ≈ {_fmt_num(delta_roi)}%"
                    )

                    steps = getattr(o, "steps", []) or []
                    if steps:
                        recommendations.append(f"{title} — Passi: {'; '.join([str(s) for s in steps[:3]])}")

                if format_opportunity is not None:
                    out_kpi["formatted"] = [format_opportunity(o) for o in opps[:5]]
        except Exception as e:
            logger.warning("OpportunityEngine failed: %s", e)
            insights.append("Modulo opportunità disponibile ma non eseguibile sui dati attuali.")
    else:
        insights.append("Modulo opportunità non disponibile.")

    if not recommendations:
        recommendations.extend(
            [
                "Rivedi pricing dove il cliente percepisce già alto valore",
                "Riduci costi variabili sulle voci più pesanti",
                "Snellisci i costi fissi che non accelerano ricavo o controllo",
            ]
        )

    return make_analysis_block(
        kpi=out_kpi,
        insights=insights,
        recommendations=recommendations,
        summary="Opportunità individuate; conviene attaccare prima le leve che aumentano utile con attrito minimo.",
        extras={"sector": sector, "elasticity": elasticity},
    )


# =========================================================
# Dispatcher map
# =========================================================
PIPELINE_MAP: Dict[str, Callable[[Dict[str, Any], Optional[Dict[str, Any]]], Dict[str, Any]]] = {
    "analizza_kpi": pipeline_analizza_kpi,
    "simula_scenario": pipeline_simula_scenario,
    "ottimizza_prezzi": pipeline_ottimizza_prezzi,
    "diagnosi_cassa": pipeline_diagnosi_cassa,
    "valutazione_azienda": pipeline_valutazione_azienda,
    "piano_azioni": pipeline_piano_azioni,
    "opportunities": pipeline_opportunities,
}


def run_reasoning_pipeline(
    intent: str,
    payload: Dict[str, Any],
    params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    key = str(intent or "").strip().lower()
    fn = PIPELINE_MAP.get(key)

    if fn is None:
        return make_analysis_block(
            kpi={},
            insights=[f"Intent pipeline non riconosciuto: {key}"],
            recommendations=[
                "Usa un intent supportato",
                "Oppure crea una nuova pipeline dedicata",
            ],
            summary="Pipeline non trovata.",
            extras={"intent": key},
        )

    try:
        return fn(payload or {}, params)
    except Exception as e:
        logger.exception("run_reasoning_pipeline failed for %s", key)
        return make_analysis_block(
            kpi={},
            insights=[f"Errore pipeline ({type(e).__name__})"],
            recommendations=["Verifica input e adapter collegati."],
            summary="Errore nella pipeline.",
            extras={"intent": key, "error": type(e).__name__},
        )


if __name__ == "__main__":
    sample_payload = {
        "fatturato": 1_200_000,
        "costi_variabili": 650_000,
        "costi_fissi": 320_000,
        "investimenti": 250_000,
        "prezzo_medio": 120,
        "costo_variabile_unitario": 55,
        "dso": 48,
        "dio": 35,
        "dpo": 22,
        "price_elasticity": -1.2,
    }

    result = run_reasoning_pipeline("analizza_kpi", sample_payload)
    print(json.dumps(result, indent=2, ensure_ascii=False))