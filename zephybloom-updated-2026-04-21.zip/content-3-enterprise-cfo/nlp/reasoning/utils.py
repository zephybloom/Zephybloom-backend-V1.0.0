# -*- coding: utf-8 -*-
# content/nlp/reasoning_utils.py

from __future__ import annotations

from typing import Any, Dict, Optional, List, Tuple, Callable


# =========================================================
# Logger soft
# =========================================================
try:
    import logging

    logger = logging.getLogger("reasoning_engine")
    if not logger.handlers:
        logging.basicConfig(level=logging.INFO)
except Exception:
    class _DummyLogger:
        def info(self, *a, **k):
            pass

        def warning(self, *a, **k):
            pass

        def error(self, *a, **k):
            pass

        def exception(self, *a, **k):
            pass

    logger = _DummyLogger()


def safe_call(
    fn: Optional[Callable[..., Any]],
    *args,
    **kwargs,
) -> Tuple[Optional[dict], Optional[str]]:
    if fn is None:
        return None, "module_missing"

    try:
        out = fn(*args, **kwargs)
        if isinstance(out, dict):
            return out, None
        if hasattr(out, "model_dump"):
            try:
                dumped = out.model_dump()
                if isinstance(dumped, dict):
                    return dumped, None
            except Exception:
                pass
        return {"value": out}, None
    except Exception as e:
        logger.error("Adapter error on %s: %s", getattr(fn, "__name__", "unknown"), e)
        return None, str(e)


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}


def safe_list(x: Any) -> List[Any]:
    return x if isinstance(x, list) else []


def fmt_num(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)
    return f"{v:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def fmt_pct_ratio(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)

    if abs(v) <= 1.5:
        return f"{v * 100:.1f}%"
    return f"{v:.1f}%"


def pick_first_number(d: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    for k in keys:
        if k in d:
            try:
                return float(d[k])
            except Exception:
                continue
    return default


def normalize_analysis_dict(payload: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(payload or {})
    for k, v in list(out.items()):
        if isinstance(v, tuple):
            out[k] = list(v)
    return out