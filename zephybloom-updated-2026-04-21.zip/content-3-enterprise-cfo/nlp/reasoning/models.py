# -*- coding: utf-8 -*-
# content/nlp/reasoning_models.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, List


@dataclass
class ReasoningContext:
    intent: str
    query: str
    payload: Dict[str, Any]
    params: Optional[Dict[str, Any]] = None
    memory: Optional[Dict[str, Any]] = None


@dataclass
class AnalysisBlock:
    kpi: Dict[str, Any]
    insights: List[str]
    recommendations: List[str]
    summary: str
    extras: Optional[Dict[str, Any]] = None