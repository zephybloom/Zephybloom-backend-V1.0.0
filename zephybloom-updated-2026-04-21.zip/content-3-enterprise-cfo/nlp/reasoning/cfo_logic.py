# -*- coding: utf-8 -*-
# content/nlp/reasoning/cfo_logic.py

from __future__ import annotations

from typing import Any, Dict, List, Optional


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return default
        return v
    except Exception:
        return default


def _fmt_eur(x: Any) -> str:
    try:
        v = float(x)
        return f"€ {v:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
    except Exception:
        return str(x)


def _fmt_pct_ratio(x: Any) -> str:
    try:
        v = float(x)
    except Exception:
        return str(x)

    if abs(v) <= 1.5:
        return f"{v * 100:.1f}%"
    return f"{v:.1f}%"


def _pick(d: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for key in keys:
        if key in d:
            try:
                return float(d[key])
            except Exception:
                continue
    return default


def extract_cfo_snapshot(kpi: Dict[str, Any], fallback_payload: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
    src = dict(fallback_payload or {})
    src.update(kpi or {})

    fatturato = _pick(src, "fatturato", "sales", "ricavi", default=0.0)
    costi_variabili = _pick(src, "costi_variabili", "cogs", default=0.0)
    costi_fissi = _pick(src, "costi_fissi", default=0.0)
    investimenti = _pick(src, "investimenti", default=0.0)

    utile = _pick(src, "utile", "net_profit", "net_income", default=fatturato - costi_variabili - costi_fissi)
    ebitda = _pick(src, "ebitda", default=utile)
    mc = _pick(src, "margine_contribuzione", default=fatturato - costi_variabili)
    mc_rate = _pick(src, "mc_rate", "gross_margin_rate", default=(mc / fatturato if fatturato > 0 else 0.0))
    roi = _pick(src, "roi", "roi_pct", default=(utile / investimenti if investimenti > 0 else 0.0))
    ccc = _pick(src, "ccc", "ccc_days", default=0.0)
    break_even = _pick(src, "break_even", default=0.0)

    return {
        "fatturato": fatturato,
        "costi_variabili": costi_variabili,
        "costi_fissi": costi_fissi,
        "investimenti": investimenti,
        "utile": utile,
        "ebitda": ebitda,
        "margine_contribuzione": mc,
        "mc_rate": mc_rate,
        "roi": roi,
        "ccc": ccc,
        "break_even": break_even,
    }


def diagnose_business(snapshot: Dict[str, float], sector: str = "default") -> Dict[str, Any]:
    fatt = _safe_float(snapshot.get("fatturato"))
    utile = _safe_float(snapshot.get("utile"))
    ebitda = _safe_float(snapshot.get("ebitda"))
    mc_rate = _safe_float(snapshot.get("mc_rate"))
    roi = _safe_float(snapshot.get("roi"))
    ccc = _safe_float(snapshot.get("ccc"))
    bep = _safe_float(snapshot.get("break_even"))

    issues: List[Dict[str, Any]] = []

    mc_threshold = 0.45 if sector in ("restaurant", "hotel") else 0.35
    roi_threshold = 0.15 if sector in ("restaurant", "hotel") else 0.12
    ccc_threshold = 20.0 if sector in ("restaurant", "hotel") else 60.0

    if fatt > 0 and mc_rate < mc_threshold:
        lost_margin = (mc_threshold - mc_rate) * fatt
        issues.append(
            {
                "code": "LOW_MARGIN",
                "title": "Marginalità insufficiente",
                "severity": 9,
                "impact_eur": max(0.0, lost_margin),
                "why": f"Il margine di contribuzione è {_fmt_pct_ratio(mc_rate)}, sotto una soglia sana di {_fmt_pct_ratio(mc_threshold)}.",
            }
        )

    if utile <= 0:
        issues.append(
            {
                "code": "NEGATIVE_PROFIT",
                "title": "Profitto assente o negativo",
                "severity": 10,
                "impact_eur": abs(utile),
                "why": "L’azienda non sta trattenendo valore economico a fine ciclo operativo.",
            }
        )

    if roi < roi_threshold:
        gap = max(0.0, (roi_threshold - roi)) * max(1.0, snapshot.get("investimenti", 0.0))
        issues.append(
            {
                "code": "LOW_ROI",
                "title": "ROI debole",
                "severity": 8,
                "impact_eur": gap,
                "why": f"Il capitale investito rende {_fmt_pct_ratio(roi)}, sotto il livello atteso di {_fmt_pct_ratio(roi_threshold)}.",
            }
        )

    if ccc > ccc_threshold:
        liquidity_drag = (ccc - ccc_threshold) * (fatt / 365.0) if fatt > 0 else 0.0
        issues.append(
            {
                "code": "LONG_CASH_CYCLE",
                "title": "Ciclo di cassa troppo lungo",
                "severity": 8,
                "impact_eur": max(0.0, liquidity_drag),
                "why": f"Il cash conversion cycle è di {ccc:.0f} giorni, quindi troppa liquidità resta immobilizzata.",
            }
        )

    if fatt > 0 and bep > fatt:
        issues.append(
            {
                "code": "BREAK_EVEN_TOO_HIGH",
                "title": "Break-even sopra i ricavi attuali",
                "severity": 9,
                "impact_eur": bep - fatt,
                "why": "Con la struttura attuale il punto di pareggio richiede più ricavi di quelli oggi generati.",
            }
        )

    if not issues:
        issues.append(
            {
                "code": "NO_CRITICAL_ISSUES",
                "title": "Nessuna criticità grave immediata",
                "severity": 3,
                "impact_eur": 0.0,
                "why": "I numeri non mostrano un’emergenza evidente, quindi ora conviene lavorare su ottimizzazione e accelerazione.",
            }
        )

    issues.sort(key=lambda x: (x["severity"], x["impact_eur"]), reverse=True)
    primary = issues[0]

    return {
        "primary_issue": primary,
        "issues": issues,
    }


def build_cfo_action_plan(snapshot: Dict[str, float], sector: str = "default") -> List[Dict[str, Any]]:
    fatt = _safe_float(snapshot.get("fatturato"))
    cv = _safe_float(snapshot.get("costi_variabili"))
    cf = _safe_float(snapshot.get("costi_fissi"))
    utile = _safe_float(snapshot.get("utile"))
    mc_rate = _safe_float(snapshot.get("mc_rate"))
    ccc = _safe_float(snapshot.get("ccc"))

    actions: List[Dict[str, Any]] = []

    if fatt > 0:
        uplift_price = fatt * 0.01
        actions.append(
            {
                "title": "Rialzo selettivo del prezzo medio",
                "priority": 9 if mc_rate < 0.40 else 7,
                "impact_eur": uplift_price,
                "area": "pricing",
                "why": "Se il mercato lo regge, anche un piccolo repricing migliora subito il contributo lordo.",
                "how": "Test su segmenti premium o clienti meno sensibili al prezzo.",
            }
        )

    if cv > 0:
        saving_cv = cv * 0.02
        actions.append(
            {
                "title": "Riduzione costi variabili",
                "priority": 9,
                "impact_eur": saving_cv,
                "area": "margine",
                "why": "Tagliare sprechi e sourcing pesa direttamente sull’utile.",
                "how": "Audit fornitori, scarti, standard operativi, bundle acquisti.",
            }
        )

    if cf > 0:
        saving_cf = cf * 0.05
        actions.append(
            {
                "title": "Snellimento costi fissi",
                "priority": 8 if utile <= 0 else 6,
                "impact_eur": saving_cf,
                "area": "struttura",
                "why": "Una struttura troppo pesante assorbe redditività e rallenta la crescita.",
                "how": "Tagliare spese non-core, software inutilizzati, ruoli non direttamente produttivi.",
            }
        )

    if fatt > 0 and ccc > 0:
        liquidity_release = max(0.0, (min(ccc, 15.0)) * (fatt / 365.0))
        actions.append(
            {
                "title": "Accorciamento ciclo di cassa",
                "priority": 8 if ccc > 45 else 5,
                "impact_eur": liquidity_release,
                "area": "cassa",
                "why": "Ridurre il tempo di incasso o migliorare rotazione stock libera cassa senza vendere di più.",
                "how": "Reminder automatici, revisione termini pagamento, gestione scorte e DSO.",
            }
        )

    if fatt > 0 and utile > 0:
        growth_push = utile * 0.15
        actions.append(
            {
                "title": "Spinta commerciale sulle linee ad alta contribuzione",
                "priority": 7,
                "impact_eur": growth_push,
                "area": "crescita",
                "why": "Non tutta la crescita vale uguale: va spinta quella che protegge margine.",
                "how": "Upsell, cross-sell, focus sui clienti con LTV più alto.",
            }
        )

    actions.sort(key=lambda x: (x["priority"], x["impact_eur"]), reverse=True)
    return actions[:5]


def build_cfo_decision_summary(
    snapshot: Dict[str, float],
    diagnosis: Dict[str, Any],
    actions: List[Dict[str, Any]],
) -> str:
    primary = diagnosis.get("primary_issue", {}) or {}
    top_action = actions[0] if actions else {}

    primary_title = str(primary.get("title", "nessuna criticità chiara")).strip()
    top_title = str(top_action.get("title", "nessuna azione prioritaria")).strip()
    impact = _fmt_eur(top_action.get("impact_eur", 0.0))

    return (
        f"Oggi la priorità manageriale è '{primary_title}'. "
        f"La prima leva da eseguire è '{top_title}', con un impatto economico potenziale di circa {impact}. "
        "Finché questa leva non viene affrontata, il resto è secondario."
    )