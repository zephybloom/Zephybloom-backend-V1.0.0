# -*- coding: utf-8 -*-
# content/nlp/toolspec.py — Tool spec + invoker sicuro (compatibile con router_llm)
from __future__ import annotations
from typing import Any, Dict, Callable, List, Optional

# Core
from core.metrics import compute_kpis
from core.scenario import simulate
from core.forecast import forecast_series
from core.finance import project_eval, dcf_equity, wacc
from core.montecarlo import mc_scenarios
from advice.opportunities import OpportunityEngine, format_opportunity
from core.validators import normalize_context_numeric

# --- What-if / Pricing / Working capital (robust import) ----------------------
from tools.breakeven import breakeven_tool
from tools.wc import wc_whatif_tool

# Proviamo prima a importare il wrapper pronto; se manca, costruiamo noi il wrapper
# usando price_ladder(...) grezzo. In ultima istanza, forniamo un fallback no-op.
try:
    # wrapper “alto livello” già presente nel progetto?
    from tools.pricing import price_ladder_tool as _price_ladder_tool  # type: ignore
except Exception:
    # ok, proviamo con la funzione base
    try:
        from tools.pricing import price_ladder as _price_ladder_core  # type: ignore

        def _price_ladder_tool(
            *,
            base: Dict[str, float],
            pct_min: float = -20,
            pct_max: float = 20,
            pct_step: float = 1,
        ) -> Dict[str, Any]:
            """
            Wrapper compatibile con il toolspec:
              - legge i campi da 'base'
              - richiama price_ladder(...) e restituisce {'rows': [...], 'best': {...}}
            """
            b = normalize_context_numeric(base or {})
            p0 = float(b.get("prezzo_medio", 0.0) or 0.0)
            fatt = float(b.get("fatturato", 0.0) or 0.0)
            cvu = float(b.get("costo_variabile_unitario", 0.0) or 0.0)
            cf = float(b.get("costi_fissi", 0.0) or 0.0)
            el = float(b.get("price_elasticity", -1.2) or -1.2)

            # costruiamo un range coerente con min/max/step
            lo = float(pct_min)
            hi = float(pct_max)
            step = float(pct_step) if float(pct_step) > 0 else 1.0
            # il nostro price_ladder accetta range simmetrico ±range_pct e step_pct
            range_pct = max(abs(lo), abs(hi))
            rows = _price_ladder_core(
                base_price=p0,
                base_revenue=fatt,
                cost_var_unit=cvu,
                fixed_costs=cf,
                elasticity=el,
                range_pct=range_pct,
                step_pct=step,
            )
            best = rows[0] if rows else None
            return {"rows": rows, "best": best}

    except Exception:
        # fallback finale: non rompiamo mai le importazioni
        def _price_ladder_tool(**kwargs) -> Dict[str, Any]:  # type: ignore
            return {"rows": [], "best": None}


# -------- Tool SPEC (OpenAI/Anthropic-style JSON schema) --------
TOOL_SPECS: Dict[str, Dict[str, Any]] = {
    "compute_kpis": {
        "name": "compute_kpis",
        "description": "Calcola i KPI finanziari principali da input contabili.",
        "parameters": {
            "type": "object",
            "properties": {
                "fatturato": {"type": "number"},
                "costi_variabili": {"type": "number"},
                "costi_fissi": {"type": "number"},
                "investimenti": {"type": "number"},
                "prezzo_medio": {"type": "number"},
                "costo_variabile_unitario": {"type": "number"},
                "cogs": {"type": "number"},
                "ammortamenti": {"type": "number"},
                "dso": {"type": "number"},
                "dio": {"type": "number"},
                "dpo": {"type": "number"},
            },
            "required": ["fatturato", "costi_variabili", "costi_fissi"],
        },
    },
    "simulate": {
        "name": "simulate",
        "description": "Applica variazioni percentuali/assolute a ricavi/costi e ricalcola KPI.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {"type": "object"},
                "delta": {"type": "object"},
            },
            "required": ["base", "delta"],
        },
    },
    "forecast": {
        "name": "forecast",
        "description": "Prevede i ricavi futuri dai valori storici (Holt additivo).",
        "parameters": {
            "type": "object",
            "properties": {
                "history": {"type": "array", "items": {"type": "number"}},
                "periods": {"type": "integer", "default": 6},
            },
            "required": ["history"],
        },
    },
    "valuation": {
        "name": "valuation",
        "description": "Valuta un progetto (NPV/IRR) o l’azienda via DCF con WACC.",
        "parameters": {
            "type": "object",
            "properties": {
                "cashflows": {"type": "array", "items": {"type": "number"}},
                "discount_rate_pct": {"type": "number"},
                "dcf_fcf": {"type": "array", "items": {"type": "number"}},
                "terminal_growth_pct": {"type": "number", "default": 2.0},
                "net_debt": {"type": "number", "default": 0.0},
                "ke": {"type": "number"},
                "kd": {"type": "number"},
                "equity": {"type": "number"},
                "debt": {"type": "number"},
                "tax_rate": {"type": "number"},
            },
        },
    },
    "opportunities": {
        "name": "opportunities",
        "description": "Suggerisce le next-best-actions con impatto stimato via simulazione.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {"type": "object"},
                "price_elasticity": {"type": "number", "default": -1.2},
                "sector": {"type": "string", "default": "default"},
            },
            "required": ["base"],
        },
    },
    "montecarlo": {
        "name": "montecarlo",
        "description": "Esegue Monte Carlo su incertezze per distribuire utile/ROI/BEP.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {"type": "object"},
                "uncertainties": {"type": "object"},
                "n": {"type": "integer", "default": 1000},
            },
            "required": ["base", "uncertainties"],
        },
    },
    "whatif.price_ladder": {
        "name": "whatif.price_ladder",
        "description": "Crea una price ladder con elasticità: restituisce righe (pct, price, qty, revenue, profit) e la riga migliore per profitto.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {
                    "type": "object",
                    "description": "Dati base: prezzo_medio, costo_variabile_unitario, fatturato, costi_fissi, price_elasticity",
                },
                "pct_min": {"type": "number", "default": -20},
                "pct_max": {"type": "number", "default": 20},
                "pct_step": {"type": "number", "default": 1},
            },
            "required": ["base"],
        },
    },
    "whatif.breakeven": {
        "name": "whatif.breakeven",
        "description": "Calcola BEQ e BEP con prezzo medio, CV unitario, CF e (opz.) quantità.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {
                    "type": "object",
                    "description": "prezzo_medio, costo_variabile_unitario, costi_fissi, fatturato e (opz.) qty",
                }
            },
            "required": ["base"],
        },
    },
    "whatif.wc_impact": {
        "name": "whatif.wc_impact",
        "description": "Impatto cambi DSO/DIO/DPO su NWC e cassa rilasciata.",
        "parameters": {
            "type": "object",
            "properties": {
                "base": {
                    "type": "object",
                    "description": "fatturato, cogs/costi_variabili, dso, dio, dpo, dso_delta, dio_delta, dpo_delta",
                }
            },
            "required": ["base"],
        },
    },
}


# --------- Helpers per formato OpenAI tool-calling ---------
def _to_openai_tool(fn_spec: Dict[str, Any]) -> Dict[str, Any]:
    """Converte una spec (name/description/parameters) in tool OpenAI."""
    return {"type": "function", "function": {
        "name": fn_spec["name"],
        "description": fn_spec.get("description", "")[:1024],
        "parameters": fn_spec.get("parameters", {"type": "object", "properties": {}}),
    }}


def get_openai_tools() -> List[Dict[str, Any]]:
    """API module-level (il router la cerca per prima)."""
    return [_to_openai_tool(spec) for spec in TOOL_SPECS.values()]


# -------- Invoker sicuro (white-list dispatch) --------
class ToolInvoker:
    def __init__(self) -> None:
        self._dispatch: Dict[str, Callable[..., Any]] = {
            "compute_kpis": self._call_compute_kpis,
            "simulate": self._call_simulate,
            "forecast": self._call_forecast,
            "valuation": self._call_valuation,
            "opportunities": self._call_opportunities,
            "montecarlo": self._call_montecarlo,
            "whatif.price_ladder": self._call_price_ladder,
            "whatif.breakeven": self._call_breakeven,
            "whatif.wc_impact": self._call_wc_impact,
        }

    # --- compat router_llm: fornisci anche questa API ---
    def get_openai_tools(self) -> List[Dict[str, Any]]:
        return get_openai_tools()

    # --- compat router_llm: expose .invoke oltre a invoke_safe ---
    def invoke(self, name: str, params: Dict[str, Any]) -> Any:
        return self.invoke_safe(name, params)

    def invoke_safe(self, name: str, params: Dict[str, Any]) -> Any:
        if name not in self._dispatch:
            raise ValueError(f"Tool non supportato: {name}")
        return self._dispatch[name](**(params or {}))

    # ---- wrapper singoli ----
    def _call_compute_kpis(self, **kwargs):
        ctx = normalize_context_numeric(kwargs)
        return compute_kpis(**ctx).model_dump()

    def _call_simulate(self, base: Dict[str, float], delta: Dict[str, float] | None = None):
        base = normalize_context_numeric(base or {})
        delta = normalize_context_numeric(delta or {})
        return simulate(base, delta)

    def _call_forecast(self, history: list, periods: int = 6):
        hist = [float(x) for x in (history or [])]
        return {"forecast": forecast_series(hist, periods=max(1, int(periods)))}

    def _call_valuation(
        self,
        cashflows: Optional[list] = None,
        discount_rate_pct: Optional[float] = None,
        dcf_fcf: Optional[list] = None,
        terminal_growth_pct: float = 2.0,
        net_debt: float = 0.0,
        ke: Optional[float] = None,
        kd: Optional[float] = None,
        equity: Optional[float] = None,
        debt: Optional[float] = None,
        tax_rate: Optional[float] = None,
    ):
        # Determina il tasso di sconto: diretto o via WACC se tutti i parametri presenti
        rate = discount_rate_pct
        have_wacc = all(v is not None for v in [ke, kd, equity, debt, tax_rate])
        if rate is None and have_wacc:
            rate = float(wacc(float(ke), float(kd), float(equity), float(debt), float(tax_rate)))  # type: ignore

        out: Dict[str, Any] = {"discount_rate_pct": rate}
        if cashflows and rate is not None:
            out["project_eval"] = project_eval([float(c) for c in cashflows], float(rate))
        if dcf_fcf:
            r = float(rate) if rate is not None else 10.0
            out["dcf"] = dcf_equity([float(x) for x in dcf_fcf], r, float(terminal_growth_pct), float(net_debt))
        return out

    def _call_opportunities(self, base: Dict[str, float], price_elasticity: float = -1.2, sector: str = "default"):
        base = normalize_context_numeric(base)
        engine = OpportunityEngine(sector=sector)
        opps = engine.generate(base, elasticity=float(price_elasticity))
        return {"top_opportunities": [format_opportunity(o) for o in opps[:5]]}

    def _call_montecarlo(self, base: Dict[str, float], uncertainties: Dict[str, Dict[str, float]], n: int = 1000):
        base = normalize_context_numeric(base)
        return mc_scenarios(base, uncertainties, n=max(10, int(n)))

    def _call_price_ladder(
        self,
        base: Dict[str, float],
        pct_min: float = -20,
        pct_max: float = 20,
        pct_step: float = 1,
    ):
        base = normalize_context_numeric(base or {})
        return _price_ladder_tool(
            base=base,
            pct_min=float(pct_min),
            pct_max=float(pct_max),
            pct_step=float(pct_step),
        )

    def _call_breakeven(self, base: Dict[str, float]):
        base = normalize_context_numeric(base or {})
        return breakeven_tool(base)

    def _call_wc_impact(self, base: Dict[str, float]):
        base = normalize_context_numeric(base or {})
        return wc_whatif_tool(base)


# Esport utili
__all__ = [
    "TOOL_SPECS",
    "get_openai_tools",
    "ToolInvoker",
]
