# -*- coding: utf-8 -*-
# content/nlp/consulting.py
from __future__ import annotations

from typing import Any, Dict, List, Tuple, Callable, Optional

from utils.fmt_parse import fmt_number_eu

try:
    from core.scenario import simulate  # type: ignore
except Exception:
    simulate = None  # type: ignore


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _metric_value(kpi: Any, name: str, default: float = 0.0) -> float:
    try:
        return float(getattr(kpi, name, default) or default)
    except Exception:
        try:
            payload = kpi.model_dump() if hasattr(kpi, "model_dump") else {}
            return float(payload.get(name, default) or default)
        except Exception:
            return default


def build_diagnosis(
    *,
    metric: str,
    kpi: Any,
    sector: str,
    tenant_id: str,
    memory: Any,
) -> str:
    try:
        mc_rate = _metric_value(kpi, "mc_rate", 0.0) * 100.0
        ebitda_v = _metric_value(kpi, "ebitda", 0.0)
        utile_v = _metric_value(kpi, "utile", 0.0)
        roi_pct = _metric_value(kpi, "roi", 0.0) * 100.0
        ccc_v = _metric_value(kpi, "ccc", 0.0)

        if memory is not None and hasattr(memory, "get_threshold"):
            th_mc = memory.get_threshold(
                tenant_id,
                "mc_rate_min_pct",
                45.0 if sector in ("restaurant", "hotel") else 35.0,
            )
            th_roi = memory.get_threshold(
                tenant_id,
                "roi_min_pct",
                15.0 if sector in ("restaurant", "hotel") else 12.0,
            )
            th_ccc = memory.get_threshold(
                tenant_id,
                "ccc_max_days",
                20.0 if sector in ("restaurant", "hotel") else 60.0,
            )
        else:
            th_mc = 45.0 if sector in ("restaurant", "hotel") else 35.0
            th_roi = 15.0 if sector in ("restaurant", "hotel") else 12.0
            th_ccc = 20.0 if sector in ("restaurant", "hotel") else 60.0

        hints: List[str] = []

        if metric in ("margine", "executive_summary", "fatturato", "utile", "ebitda"):
            if mc_rate < float(th_mc):
                hints.append(f"MC-rate sotto soglia ({float(th_mc):.0f}%).")
            if utile_v <= 0:
                hints.append("Utile in area critica (≤0).")

        if metric in ("roi", "executive_summary"):
            if roi_pct < float(th_roi):
                hints.append(f"ROI sotto soglia (~{float(th_roi):.0f}%).")

        if metric in ("cashflow", "executive_summary"):
            if ebitda_v <= 0 and utile_v <= 0:
                hints.append("Generazione cassa debole (EBITDA/utile ≤ 0).")
            if ccc_v > float(th_ccc):
                hints.append(f"Ciclo di cassa lungo ({fmt_number_eu(ccc_v, 0)} gg).")

        return " | ".join(hints) if hints else "Parametri entro range, margini di ottimizzazione possibili."
    except Exception:
        return "Analisi rapida non disponibile sui dati forniti."


def compose_consulting_block(
    *,
    metric: str,
    kpi: Any,
    base_data: Dict[str, Any],
    sector: str,
    tenant_id: str,
    memory: Any,
    simulate_fn: Optional[Callable[..., Any]] = None,
) -> str:
    try:
        fatt = _safe_float(base_data.get("fatturato", 0.0), 0.0)
        cv = _safe_float(base_data.get("costi_variabili", 0.0), 0.0)
        cf = _safe_float(base_data.get("costi_fissi", 0.0), 0.0)
        p0 = _safe_float(base_data.get("prezzo_medio", 0.0), 0.0)
        cvu = _safe_float(base_data.get("costo_variabile_unitario", 0.0), 0.0)
        el = _safe_float(base_data.get("price_elasticity", -1.2), -1.2)

        base = {
            "fatturato": fatt,
            "costi_variabili": cv,
            "costi_fissi": cf,
            "prezzo_medio": p0,
            "costo_variabile_unitario": cvu,
            "price_elasticity": el,
        }

        diagnosi = build_diagnosis(
            metric=metric,
            kpi=kpi,
            sector=sector,
            tenant_id=tenant_id,
            memory=memory,
        )

        actions: List[Tuple[str, Dict[str, float]]] = []
        if p0 > 0 and fatt > 0:
            actions.append(("Aumenta prezzo medio dell’1%", {"price_pct": 1.0, "price_elasticity": el}))
        if cf > 0:
            actions.append(("Taglia costi fissi del 5%", {"costi_fissi_pct": -5.0}))
        if cv > 0:
            actions.append(("Riduci costi variabili del 2%", {"costi_variabili_pct": -2.0}))

        lines: List[str] = []
        utile_base = float(fatt - cv - cf)

        sim_fn = simulate_fn or simulate

        for label, delta in actions[:3]:
            utile_after = utile_base
            if sim_fn is not None:
                try:
                    after = sim_fn(base, delta)
                    if isinstance(after, dict):
                        utile_after = float(after.get("utile", utile_base))
                except Exception:
                    utile_after = utile_base

            delta_utile = utile_after - utile_base
            lines.append(f"- {label} — ΔUtile atteso {fmt_number_eu(delta_utile, 0)}")

        triggers: List[str] = []
        if p0 > 0 and fatt > 0:
            triggers.append("[ESEGUI price_ladder step=2% range=±10%]")
            triggers.append("[ESEGUI optimize/price]")
        if fatt > 0:
            triggers.append("[ESEGUI simulate preset='-5% CF, -2% CV, +1% prezzo']")

        block: List[str] = []
        if diagnosi:
            block.append(f"**Diagnosi:** {diagnosi}")
        if lines:
            block.append("**Azioni consigliate (impatto stimato):**\n" + "\n".join(lines))
        if triggers:
            block.append("**Azioni eseguibili:** " + " | ".join(triggers))

        return "\n".join(block)
    except Exception:
        return ""