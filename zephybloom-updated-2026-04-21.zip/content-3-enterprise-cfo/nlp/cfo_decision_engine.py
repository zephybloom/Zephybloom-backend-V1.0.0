"""
ZEPHYBLOOM CFO BRAIN - DECISION ENGINE
Trasforma dati in decisioni concrete che generano soldi.

Filosofia:
- NON spiegare
- DECIDERE + AGIRE + QUANTIFICARE

Ogni risposta è:
📊 NUMERO CHIAVE
🧠 DIAGNOSI (perché)
⚠️ RISCHIO (urgenza)
🎯 AZIONE (cosa fare)
💰 IMPATTO (quanto guadagni)
🔄 FOLLOW-UP (prossimo passo)
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum


class CompanyHealth(Enum):
    """Stato della società"""
    LOSING = "losing"          # Perdita
    CRITICAL = "critical"      # Margine <15%
    STRUGGLING = "struggling"  # Margine 15-25%
    HEALTHY = "healthy"        # Margine 25-35%
    THRIVING = "thriving"      # Margine >35%


class ActionPriority(Enum):
    """Priorità delle azioni"""
    CRITICAL = 1   # Sopravvivenza
    HIGH = 2       # Cambia il gioco
    MEDIUM = 3     # Migliora margins
    LOW = 4        # Nice-to-have


@dataclass
class DecisionAction:
    """Una azione decisionale"""
    priority: ActionPriority
    title: str                          # "Aumentare prezzi"
    description: str                    # Spiegazione concisa
    impact_eur: float                   # Impatto in €
    implementation: str                 # "Entro 30 giorni"
    risk_level: str                     # "low", "medium", "high"
    metric_affected: str                # "margine", "fatturato", ecc.
    
    def __lt__(self, other):
        """Ordina per impact (€) decrescente"""
        if self.priority == other.priority:
            return self.impact_eur > other.impact_eur
        return self.priority.value < other.priority.value


@dataclass
class CFODecision:
    """Output del Decision Engine - Una decisione vera"""
    health_status: CompanyHealth
    headline: str                       # "Sei in perdita. Agisci subito."
    
    # NUMERO CHIAVE
    key_metric: str                     # Es: "Utile netto"
    key_value: float
    key_unit: str                       # "€", "%"
    
    # DIAGNOSI
    diagnosis: str                      # Perché è così
    benchmark: str                      # Vs target/industry
    
    # RISCHIO
    risk_description: str               # Se non agisci
    estimated_loss_eur: float           # Quanto perderai in 12 mesi
    
    # AZIONI (ordinate per impatto)
    actions: List[DecisionAction]       # Top 3-5
    
    # IMPATTO STIMATO
    total_opportunity_eur: float        # Somma impatti
    
    # FOLLOW-UP INTELLIGENTE
    follow_up: str                      # "Vuoi che ti simulo...?"
    
    # TREND ANALYSIS (optional)
    trend_summary: Optional[str] = None # "Revenue ↓ 5.2%, Margin ↓ 2.1%..." 
    
    def to_response(self) -> str:
        """Formatta per risposta user"""
        lines = []
        
        # HEADLINE (attention grabber)
        lines.append(f"🎯 {self.headline}\n")
        
        # TREND ANALISI (if available)
        if self.trend_summary:
            lines.append(self.trend_summary)
            lines.append("")
        
        # NUMERO CHIAVE (subito chiaro)
        lines.append(f"📊 {self.key_metric}: {self.key_value:,.0f}{self.key_unit}")
        lines.append(f"   Benchmark: {self.benchmark}\n")
        
        # DIAGNOSI (perché è così)
        lines.append(f"🧠 DIAGNOSI:")
        lines.append(f"   {self.diagnosis}\n")
        
        # RISCHIO (crea urgenza)
        lines.append(f"⚠️  SE NON AGISCI:")
        lines.append(f"   {self.risk_description}")
        lines.append(f"   Perdita stimata: €{self.estimated_loss_eur:,.0f}/anno\n")
        
        # AZIONI (ordinate)
        lines.append(f"🎯 AZIONI (in ordine di impatto):\n")
        for i, action in enumerate(self.actions, 1):
            lines.append(f"{i}. {action.title}")
            lines.append(f"   → Impatto: +€{action.impact_eur:,.0f}")
            lines.append(f"   → Come: {action.description}")
            lines.append(f"   → Timeline: {action.implementation}")
            lines.append(f"   → Risk: {action.risk_level}\n")
        
        # IMPATTO TOTALE
        lines.append(f"💰 OPPORTUNITÀ TOTALE: +€{self.total_opportunity_eur:,.0f}")
        lines.append(f"   (Se implementi tutto)\n")
        
        # FOLLOW-UP
        lines.append(f"🔄 PROSSIMO PASSO:")
        lines.append(f"   {self.follow_up}")
        
        return "\n".join(lines)


class CFODecisionEngine:
    """
    Il vero CFO Brain.
    
    Input: dati finanziari + (optionale) dati storici per trend
    Output: DECISIONI che generano soldi + context di trend
    """
    
    def analyze(self, context: Dict[str, float], company_name: str = "Your Company", 
                trend_summary: Optional[str] = None) -> CFODecision:
        """
        Analizza azienda come CFO vero.
        
        Args:
            context: Financial metrics (fatturato, costi_variabili, costi_fissi, investimenti)
            company_name: Nome azienda
            trend_summary: Optional trend analysis text (e.g., "📊 Trends (vs last month): ...")
        """
        
        # Extract metriche
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        inv = context.get("investimenti", 100_000)
        
        # Calcoli
        profit = fatt - cv - cf
        margin_gross = ((fatt - cv) / fatt * 100) if fatt > 0 else 0
        margin_net = (profit / fatt * 100) if fatt > 0 else 0
        roi = (profit / inv * 100) if inv > 0 else 0
        
        # ===== TRIGGER SYSTEM =====
        # Determina stato salute
        if profit < 0:
            return self._decision_losing(context, company_name, trend_summary)
        elif margin_gross < 25:
            return self._decision_low_margin(context, company_name, trend_summary)
        elif roi < 15:
            return self._decision_low_roi(context, company_name, trend_summary)
        else:
            return self._decision_healthy(context, company_name, trend_summary)
    
    # ===== DECISION SCENARIOS =====
    
    def _decision_losing(self, context: Dict, company: str, trend_summary: Optional[str] = None) -> CFODecision:
        """Azienda in perdita = CRISIS MODE"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        profit = fatt - cv - cf
        
        # AZIONI CRITICHE (sopravvivenza)
        actions = [
            DecisionAction(
                priority=ActionPriority.CRITICAL,
                title="Tagliare costi fissi (SUBITO)",
                description=f"Ridurre da €{cf:,.0f} a €{fatt*0.25:,.0f} (target 25% fatturato)",
                impact_eur=cf - (fatt * 0.25),
                implementation="30-45 giorni (dismissioni, rinnegozi contratti)",
                risk_level="high",
                metric_affected="utile"
            ),
            DecisionAction(
                priority=ActionPriority.CRITICAL,
                title="Aumentare prezzi",
                description="Rialzo 10-15% su clienti top. Accetta perdita volumi 20%.",
                impact_eur=fatt * 0.08,  # Conservative: +8%
                implementation="2-3 settimane (comunica subito)",
                risk_level="high",
                metric_affected="fatturato"
            ),
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Bloccare spese discrezionali",
                description="0 marketing, 0 travel, 0 nuovi progetti per 90 giorni",
                impact_eur=fatt * 0.05,
                implementation="Immediato (CFO approval required)",
                risk_level="low",
                metric_affected="costi_fissi"
            ),
        ]
        
        total_opportunity = sum(a.impact_eur for a in actions)
        
        return CFODecision(
            health_status=CompanyHealth.LOSING,
            headline=f"🚨 {company} È IN PERDITA. Devi agire in 48 ore.",
            
            key_metric="Utile netto",
            key_value=profit,
            key_unit="€",
            
            diagnosis=f"Stai perdendo €{abs(profit):,.0f}/anno. Costi fissi sono {(cf/fatt*100):.0f}% fatturato (target: <30%). Margine lordo insufficiente.",
            benchmark="Utile deve essere positivo (>0€)",
            
            risk_description=f"Se continui così: insolvenza tra 6-12 mesi. Inability to pagar dipendenti. Business failure.",
            estimated_loss_eur=abs(profit) * 1.2,  # Will get worse
            
            actions=sorted(actions),
            total_opportunity_eur=total_opportunity,
            
            follow_up="Vuoi un piano terzo operativo? Ti faccio un recovery plan giorno-per-giorno.",
            trend_summary=trend_summary,
        )
    
    def _decision_low_margin(self, context: Dict, company: str, trend_summary: Optional[str] = None) -> CFODecision:
        """Margine basso = PRICING o COSTI problem"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        profit = fatt - cv - cf
        margin_gross = ((fatt - cv) / fatt * 100)
        
        actions = [
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Aumentare prezzi",
                description=f"Margine {margin_gross:.0f}% è troppo basso. Rialzo 8-10% + selectivity (top 30% clienti).",
                impact_eur=fatt * 0.06,
                implementation="30 giorni (negoziazione)",
                risk_level="medium",
                metric_affected="margine"
            ),
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Ridurre costi variabili",
                description="COGS optimization. Negoziare con fornitori (-10%). Cambiar supplier se necessario.",
                impact_eur=cv * 0.10,
                implementation="45-60 giorni",
                risk_level="low",
                metric_affected="costi_variabili"
            ),
            DecisionAction(
                priority=ActionPriority.MEDIUM,
                title="Tagliare prodotti low-margin",
                description="Identifica bottom 20% SKU. Discontinua o repricing 15%+.",
                impact_eur=fatt * 0.03,
                implementation="Subito (SKU review)",
                risk_level="low",
                metric_affected="mix_prodotti"
            ),
        ]
        
        total_opportunity = sum(a.impact_eur for a in actions)
        
        return CFODecision(
            health_status=CompanyHealth.STRUGGLING,
            headline=f"⚠️  Margine è {margin_gross:.0f}%. Sotto target (30%+). Devi agire.",
            
            key_metric="Margine lordo",
            key_value=margin_gross,
            key_unit="%",
            
            diagnosis=f"Costi variabili sono {(cv/fatt*100):.0f}% fatturato. Pricing power insufficiente o COGS alta. Root: dipende dal settore, ma pricing è il leva più veloce.",
            benchmark="Target: 30%+ (industria media)",
            
            risk_description=f"Margine basso = poco spazio per errori. Un rallentamento breve ti manda in perdita.",
            estimated_loss_eur=profit * 0.5,  # Will halve if margins compress further
            
            actions=sorted(actions),
            total_opportunity_eur=total_opportunity,
            
            follow_up="Qual è il tuo settore? Posso stimare pricing power realistica. O simuliamo rialzo 8% vs volumi persi?",
            trend_summary=trend_summary,
        )
    
    def _decision_low_roi(self, context: Dict, company: str, trend_summary: Optional[str] = None) -> CFODecision:
        """ROI basso = sotto-investimento o inefficienza asset"""
        
        fatt = context.get("fatturato", 1_000_000)
        cf = context.get("costi_fissi", 300_000)
        cv = context.get("costi_variabili", 400_000)
        inv = context.get("investimenti", 100_000)
        ebitda = fatt - cv - cf
        roi = (ebitda / inv * 100) if inv > 0 else 0
        
        actions = [
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Aumentare fatturato (leva veloce)",
                description=f"ROI {roi:.0f}% è basso. Investimento €{inv:,.0f} non genera abbastanza. Scala volumi +20% senza capex aggiuntivo.",
                impact_eur=fatt * 0.15,  # Revenue lift
                implementation="60-90 giorni (sales push)",
                risk_level="medium",
                metric_affected="fatturato"
            ),
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Ridurre asset capital",
                description=f"€{inv:,.0f} in capex potrebbe essere ridotto. Vendi aset non-core. Valuta lease vs own.",
                impact_eur=inv * 0.30,
                implementation="30-45 giorni",
                risk_level="low",
                metric_affected="investimenti"
            ),
            DecisionAction(
                priority=ActionPriority.MEDIUM,
                title="Ottimizzare asset utilization",
                description="Increase asset throughput. Inventory turns, machine utilization, ecc.",
                impact_eur=fatt * 0.08,
                implementation="Ongoing optimization",
                risk_level="low",
                metric_affected="efficienza"
            ),
        ]
        
        total_opportunity = sum(a.impact_eur for a in actions)
        
        return CFODecision(
            health_status=CompanyHealth.HEALTHY,
            headline=f"📊 ROI è {roi:.0f}%. Sotto target (15%+). Stai sotto-investendo o assets inefficienti.",
            
            key_metric="ROI (Return on Investment)",
            key_value=roi,
            key_unit="%",
            
            diagnosis=f"EBITDA €{ebitda:,.0f} / Investment €{inv:,.0f} = ROI {roi:.0f}%. Basso perché: (a) EBITDA insufficiente OPPURE (b) Capex sovradimensionato.",
            benchmark="Target: 15-20%+ (healthy businesses)",
            
            risk_description=f"ROI basso = capitale inefficiente. Se investi ulteriormente, non generi ritorno. Bloccato in crescita.",
            estimated_loss_eur=inv * (0.15 - (roi/100)) * 1,  # Lost opportunity
            
            actions=sorted(actions),
            total_opportunity_eur=total_opportunity,
            
            follow_up="Vuoi che analizzo dove il capitale è bloccato? Oppure simuliamo crescita fatturato +20%?",
            trend_summary=trend_summary,
        )
    
    def _decision_healthy(self, context: Dict, company: str, trend_summary: Optional[str] = None) -> CFODecision:
        """Azienda sana = CRESCITA aggressiva"""
        
        fatt = context.get("fatturato", 1_000_000)
        cv = context.get("costi_variabili", 400_000)
        cf = context.get("costi_fissi", 300_000)
        profit = fatt - cv - cf
        margin_net = (profit / fatt * 100)
        roi = (profit / context.get("investimenti", 100_000) * 100)
        
        actions = [
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Investire in crescita",
                description=f"Margini solidi ({margin_net:.0f}% netto). Reinvesti €{profit * 0.5:,.0f} in sales/marketing/prodotto. Target: +30% fatturato.",
                impact_eur=fatt * 0.30,
                implementation="Quartale prossimi 12 mesi",
                risk_level="medium",
                metric_affected="fatturato"
            ),
            DecisionAction(
                priority=ActionPriority.HIGH,
                title="Esplorare acquisizioni",
                description=f"Liquidità sufficiente (utile €{profit:,.0f}). Valuta acquisire competitor. Target buyer profile? Pronto a valutare deal €{profit * 5:,.0f}-€{profit * 8:,.0f}.",
                impact_eur=profit * 0.5,  # Synergy value
                implementation="90-180 giorni (deal cycle)",
                risk_level="high",
                metric_affected="crescita_strategica"
            ),
            DecisionAction(
                priority=ActionPriority.MEDIUM,
                title="Ottimizzare pricing (squeeze margins)",
                description=f"Margine {margin_net:.0f}% è buono. Test +5% pricing su segmenti meno price-sensitive. Upside: €{fatt * 0.03:,.0f}.",
                impact_eur=fatt * 0.03,
                implementation="30-60 giorni",
                risk_level="low",
                metric_affected="margine"
            ),
        ]
        
        total_opportunity = sum(a.impact_eur for a in actions)
        
        return CFODecision(
            health_status=CompanyHealth.THRIVING,
            headline=f"✅ {company} è SANA e PRONTA per CRESCITA aggressiva.",
            
            key_metric="Utile netto + Margine",
            key_value=profit,
            key_unit="€",
            
            diagnosis=f"Profitti solidi (€{profit:,.0f}, {margin_net:.0f}% margin). Zero debt risk. Puoi permetterti di investire in crescita. ROI {roi:.0f}% means capital è ben allocato.",
            benchmark="Sopra media industria",
            
            risk_description=f"Se NON cresci: perderai momentum. Competitor scalerà mentre tu stai fermo. Market share erosion.",
            estimated_loss_eur=fatt * 0.15,  # Missed opportunity
            
            actions=sorted(actions),
            total_opportunity_eur=total_opportunity,
            
            follow_up="Vuoi che ti simuliamo una crescita +30%? Oppure ti aiuto a valutare un'acquisizione target?",
            trend_summary=trend_summary,
        )


def create_decision_engine() -> CFODecisionEngine:
    """Factory"""
    return CFODecisionEngine()
