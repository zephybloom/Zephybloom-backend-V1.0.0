# content/api/routes_debug.py
from __future__ import annotations
from typing import Any, Dict
from fastapi import APIRouter
from api.schemas import ParseDebugRequest
from nlp.slot_extraction import extract_slots, _normalize_text

router = APIRouter(tags=["debug"])

@router.post("/debug/parse")
def debug_parse(req: ParseDebugRequest) -> Dict[str, Any]:
    raw = (req.text or "").strip()
    slots = extract_slots(raw)
    merged = {**slots, **(req.context or {})}
    return {
        "text_raw": raw,
        "text_normalized": _normalize_text(raw),
        "slots": slots,
        "merged": merged,
    }
