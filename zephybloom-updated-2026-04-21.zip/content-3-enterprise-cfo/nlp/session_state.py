# -*- coding: utf-8 -*-
# content/nlp/session_state.py

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.schemas import Answer


class ChatSession:
    """
    Memoria conversazionale leggera per:
    - ultimo intent
    - ultimi KPI / contesto numerico
    - facts persistenti della conversazione
    - ultima risposta generata
    - eventuali campi mancanti
    - raccolta dati multi-step
    """

    def __init__(self) -> None:
        self.last_intent: Optional[str] = None
        self.last_kpi: Dict[str, Any] = {}
        self.facts: Dict[str, str] = {}
        self.last_answer: Optional[Answer] = None
        self.missing_fields: List[str] = []

        # multi-step flow
        self.pending_intent: Optional[str] = None
        self.last_requested_field: Optional[str] = None
        self.collected_data: Dict[str, Any] = {}

    def update(
        self,
        intent: Optional[str] = None,
        kpi: Optional[Dict[str, Any]] = None,
        facts: Optional[Dict[str, str]] = None,
        answer: Optional[Answer] = None,
        missing_fields: Optional[List[str]] = None,
        pending_intent: Optional[str] = None,
        last_requested_field: Optional[str] = None,
        collected_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        if intent:
            self.last_intent = str(intent).strip()

        if kpi:
            self.last_kpi = dict(kpi)

        if facts:
            for key, value in facts.items():
                try:
                    k = str(key).strip()
                    v = str(value).strip()
                    if k:
                        self.facts[k] = v
                except Exception:
                    continue

        if answer is not None:
            self.last_answer = answer

        if missing_fields is not None:
            clean: List[str] = []
            for field in missing_fields:
                try:
                    s = str(field).strip()
                    if s:
                        clean.append(s)
                except Exception:
                    continue
            self.missing_fields = clean

        if pending_intent is not None:
            self.pending_intent = str(pending_intent).strip() if str(pending_intent).strip() else None

        if last_requested_field is not None:
            self.last_requested_field = (
                str(last_requested_field).strip()
                if str(last_requested_field).strip()
                else None
            )

        if collected_data is not None and isinstance(collected_data, dict):
            self.collected_data = dict(collected_data)

    def set_last_intent(self, intent: Optional[str]) -> None:
        if intent:
            self.last_intent = str(intent).strip()

    def set_pending_intent(self, intent: Optional[str]) -> None:
        if intent and str(intent).strip():
            self.pending_intent = str(intent).strip()
        else:
            self.pending_intent = None

    def set_last_requested_field(self, field: Optional[str]) -> None:
        if field and str(field).strip():
            self.last_requested_field = str(field).strip()
        else:
            self.last_requested_field = None

    def set_collected_field(self, field: str, value: Any) -> None:
        try:
            f = str(field).strip()
            if f:
                self.collected_data[f] = value
                self.last_kpi[f] = value
        except Exception:
            pass

    def merge_collected_data(self, payload: Optional[Dict[str, Any]]) -> None:
        if not isinstance(payload, dict):
            return
        for key, value in payload.items():
            self.collected_data[key] = value
            self.last_kpi[key] = value

    def merge_kpi(self, payload: Optional[Dict[str, Any]]) -> None:
        if not isinstance(payload, dict):
            return
        for key, value in payload.items():
            self.last_kpi[key] = value

    def set_fact(self, key: str, value: Any) -> None:
        try:
            k = str(key).strip()
            v = str(value).strip()
            if k:
                self.facts[k] = v
        except Exception:
            pass

    def get_fact(self, key: str, default: Optional[str] = None) -> Optional[str]:
        try:
            return self.facts.get(str(key), default)
        except Exception:
            return default

    def clear_missing_fields(self) -> None:
        self.missing_fields = []

    def clear_collection_flow(self) -> None:
        self.pending_intent = None
        self.last_requested_field = None
        self.collected_data = {}
        self.missing_fields = []

    def reset(self) -> None:
        self.last_intent = None
        self.last_kpi = {}
        self.facts = {}
        self.last_answer = None
        self.missing_fields = []
        self.pending_intent = None
        self.last_requested_field = None
        self.collected_data = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "last_intent": self.last_intent,
            "last_kpi": dict(self.last_kpi),
            "facts": dict(self.facts),
            "last_answer": self.last_answer.model_dump() if hasattr(self.last_answer, "model_dump") and self.last_answer else None,
            "missing_fields": list(self.missing_fields),
            "pending_intent": self.pending_intent,
            "last_requested_field": self.last_requested_field,
            "collected_data": dict(self.collected_data),
        }