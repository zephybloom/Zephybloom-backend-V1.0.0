# -*- coding: utf-8 -*-
# content/nlp/llm_provider.py — Facciata provider-agnostic che delega a LLMAdapter (no duplicazioni)
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Optional, Protocol, Any

from api.config import settings
from nlp.llm_adapter import LLMAdapter, LLMResult, DEFAULT_SYSTEM

# ---------------------------------------------
# Tipi messaggi (compatibili con il tuo backend)
# ---------------------------------------------
LLMMessage = Dict[str, str]  # {"role": "system|user|assistant", "content": "..."}


class LLMProvider(Protocol):
    """
    Interfaccia unica per il backend.
    Implementazioni:
      - AdapterLLM: delega a LLMAdapter (OpenAI-ready, tool-calling, retry, budget guardrail, ecc.)
      - MockLLM: per test/MVP
    """
    def chat(
        self,
        messages: List[LLMMessage],
        *,
        system: Optional[str] = None,
        temperature: float = 0.2,
        stream: bool = False,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str: ...


# --------------------
# Utilità comuni
# --------------------
def _apply_system(messages: List[LLMMessage], system: Optional[str]) -> List[LLMMessage]:
    """Inserisce (se presente) il system come primo messaggio, senza alterare l'ordine degli altri."""
    if system:
        return [{"role": "system", "content": system}] + messages
    return messages


def _ensure_roles(messages: List[LLMMessage]) -> List[LLMMessage]:
    """
    Normalizza alias/maiuscole dei ruoli.
    In caso di ruolo ignoto: il primo è 'user', i successivi 'assistant'.
    """
    norm: List[LLMMessage] = []
    for m in messages:
        role = (m.get("role") or "").lower().strip()
        if role not in {"system", "user", "assistant"}:
            role = "user" if not norm else "assistant"
        norm.append({"role": role, "content": str(m.get("content", ""))})
    return norm


def _condense_as_single_user_turn(messages: List[LLMMessage]) -> tuple[str, str]:
    """
    Converte una lista di messaggi multi-turno in:
      - system: primo 'system' (o DEFAULT_SYSTEM se assente),
      - user:   trascrizione compressa dei turni non-system.
    Evitiamo duplicare la logica dell'adapter: qui prepariamo un 'user' unico.
    """
    sys = None
    chunks: List[str] = []
    for m in messages:
        r = m["role"]
        c = m["content"]
        if r == "system":
            # tieni SOLO il primo system
            if sys is None:
                sys = c
            continue
        # etichetta semplice per dare un minimo di contesto all'adapter
        if r == "user":
            chunks.append(f"Utente: {c}")
        elif r == "assistant":
            chunks.append(f"Assistente: {c}")
        else:
            chunks.append(c)

    system = sys or DEFAULT_SYSTEM
    user = "\n".join(chunks).strip()
    return system, user


# --------------------
# Mock (per MVP/test)
# --------------------
@dataclass
class MockLLM(LLMProvider):
    deterministic: bool = False

    def chat(
        self,
        messages: List[LLMMessage],
        *,
        system: Optional[str] = None,
        temperature: float = 0.2,
        stream: bool = False,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        msgs = _ensure_roles(_apply_system(messages, system))
        # Estrai ultimo prompt utente
        user_text = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
        if settings.TEST_MODE or self.deterministic:
            return f"[MOCK][stable] input='{user_text[:180]}'"
        return f"[MOCK] Ho ricevuto: {user_text[:200]} — (provider=mock)"


# --------------------
# Provider basato su LLMAdapter (no duplicazioni OpenAI qui)
# --------------------
@dataclass
class AdapterLLM(LLMProvider):
    """
    Implementazione concreta che delega a LLMAdapter:
      - supporta tool-calling, retry/backoff, budget guardrail, json-mode, ecc.
      - evita di importare o configurare SDK LLM qui (niente duplicazioni).
    """
    adapter: LLMAdapter

    def chat(
        self,
        messages: List[LLMMessage],
        *,
        system: Optional[str] = None,
        temperature: float = 0.2,
        stream: bool = False,              # lo lasciamo per compat, l'adapter ritorna testo completo
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        msgs = _ensure_roles(_apply_system(messages, system))
        sysmsg, user_text = _condense_as_single_user_turn(msgs)
        # Delego tutto all'adapter (configurato via ENV in llm_adapter)
        res: LLMResult = self.adapter.complete(
            system=sysmsg,
            user=user_text,
            tools=kwargs.get("tools"),
            tool_invoker=kwargs.get("tool_invoker"),
            temperature=temperature,
            max_tokens=int(max_tokens or 800),
        )
        return (res.text or "").strip()


# --------------------
# Factory
# --------------------
def get_llm(cfg=settings) -> LLMProvider:
    """
    Sceglie il provider corretto a partire dalla config:
      - LLM_PROVIDER=mock   -> MockLLM (risposte sintetiche, stabili se TEST_MODE)
      - LLM_PROVIDER=openai -> AdapterLLM con LLMAdapter (OpenAI-ready)
      - altro/assente       -> MockLLM

    Nota: le variabili ENV (provider, model, retry, json-mode, budget) sono lette da LLMAdapter.
    Qui non duplichiamo nulla.
    """
    provider = (cfg.LLM_PROVIDER or "mock").lower().strip()

    if provider == "openai":
        # LLMAdapter leggerà OPENAI_API_KEY e resto della config direttamente dagli ENV
        adapter = LLMAdapter(provider="openai", model=cfg.LLM_MODEL, timeout=int(cfg.TIMEOUT_S))
        return AdapterLLM(adapter=adapter)

    # default: mock
    return MockLLM(deterministic=bool(cfg.TEST_MODE))