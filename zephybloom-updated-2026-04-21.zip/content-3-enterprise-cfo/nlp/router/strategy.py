# -*- coding: utf-8 -*-
# content/nlp/router_strategy.py
# Strategic analysis handler extracted from router.py

from __future__ import annotations

from typing import Any, Dict, List

from core.schemas import Answer
from utils.fmt_parse import fmt_number_eu


# =========================================================
# Safe imports
# =========================================================
try:
    from strategy.engine import StrategyEngine  # type: ignore

    HAVE_STRATEGY = True
except Exception:
    HAVE_STRATEGY = False
    StrategyEngine = None  # type: ignore


try:
    from strategy.analysis import (  # type: ignore
        strategic_snapshot,
        extract_business_state,
        build_priority_actions,
    )

    HAVE_STRATEGIC_SNAPSHOT = True
except Exception:
    HAVE_STRATEGIC_SNAPSHOT = False

    def strategic_snapshot(data: Dict[str, Any]) -> Dict[str, Any]:
        return {}

    def extract_business_state(data: Dict[str, Any]) -> Dict[str, Any]:
        return {}

    def build_priority_actions(
        state: Dict[str, float],
        problem: str,
        sector: str = "default",
        phase: str = "growth",
    ) -> List[Dict[str, Any]]:
        return []


# =========================================================
# Helpers
# =========================================================
def top_actions_text(actions: List[Dict[str, Any]], limit: int = 3) -> str:
    rows: List[str] = []

    for action in (actions or [])[:limit]:
        title = str(action.get("title", "")).strip()
        why = str(action.get("why", "")).strip()
        how = str(action.get("how", "")).strip()

        if not title:
            continue

        line = f"- {title}"
        if why:
            line += f" — {why}"
        if how:
            line += f" | Come: {how}"

        rows.append(line)

    return "\n".join(rows)


# =========================================================
# Factory
# =========================================================
def build_strategy_handler(strategy_engine: Any = None):
    """
    Restituisce una funzione handler da usare dentro NLPRouter.
    """

    engine = strategy_engine
    if engine is None and HAVE_STRATEGY and StrategyEngine is not None:
        try:
            engine = StrategyEngine()
        except Exception:
            engine = None

    def handle_strategic_analysis(data: Dict[str, Any], text: str = "") -> Answer:
        if engine is not None:
            try:
                return engine.run(data, prompt_text=text)
            except TypeError:
                try:
                    return engine.run(data)
                except Exception as e:
                    return Answer(
                        intent="strategic_analysis",
                        narrative=f"Errore nell'analisi strategica ({type(e).__name__}).",
                        advisories=[],
                    )
            except Exception as e:
                return Answer(
                    intent="strategic_analysis",
                    narrative=f"Errore nell'analisi strategica ({type(e).__name__}).",
                    advisories=[],
                )

        if HAVE_STRATEGIC_SNAPSHOT:
            try:
                snap = strategic_snapshot(data)

                sector = str(snap.get("sector", data.get("sector", "default")))
                phase = str(snap.get("phase", "growth"))
                problem = str(snap.get("problem", ""))
                explanation = str(snap.get("explanation", ""))
                primary_lever = str(snap.get("primary_lever", ""))

                state = extract_business_state(data) if callable(extract_business_state) else {}
                actions = (
                    build_priority_actions(
                        state or {},
                        problem=problem,
                        sector=sector,
                        phase=phase,
                    )
                    if callable(build_priority_actions)
                    else []
                )

                scorecard = snap.get("scorecard", {})
                if not isinstance(scorecard, dict):
                    scorecard = {}

                parts: List[str] = []

                if problem:
                    parts.append(f"**Problema principale:** {problem}")

                if explanation:
                    parts.append(f"**Lettura:** {explanation}")

                if primary_lever:
                    parts.append(f"**Leva prioritaria:** {primary_lever}")

                if scorecard:
                    score_txt = ", ".join(
                        [
                            f"{k}={fmt_number_eu(float(v) * 100.0, 1)}%"
                            for k, v in scorecard.items()
                            if isinstance(v, (int, float))
                        ]
                    )
                    if score_txt:
                        parts.append(f"**Scorecard strategica:** {score_txt}")

                if actions:
                    parts.append("**Azioni consigliate:**\n" + top_actions_text(actions, limit=3))

                if not parts:
                    parts.append("Analisi strategica generata, ma con segnali ancora deboli.")

                return Answer(
                    intent="strategic_analysis",
                    narrative="\n\n".join(parts),
                    advisories=[],
                )

            except Exception as e:
                return Answer(
                    intent="strategic_analysis",
                    narrative=f"Modulo strategico non disponibile in questa build ({type(e).__name__}).",
                    advisories=[],
                )

        return Answer(
            intent="strategic_analysis",
            narrative="Modulo strategico non disponibile in questa build.",
            advisories=[],
        )

    return handle_strategic_analysis