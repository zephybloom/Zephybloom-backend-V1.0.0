# -*- coding: utf-8 -*-
# content/nlp/router/router.py

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from core.metrics import compute_kpis
from core.schemas import Answer
from nlp.brain.intelligent_questions import brain_decision

try:
    from faq.faq_router import route_faq
    _HAVE_FAQ_ROUTER = True
except Exception:
    _HAVE_FAQ_ROUTER = False

    def route_faq(*args, **kwargs):
        return {
            "matched": False,
            "answer": None,
            "score": 0,
            "item": None,
            "category": None,
        }


# =========================================================
# Reasoning
# =========================================================
try:
    from nlp.reasoning.engine import answer_cfo as _answer_cfo
    _HAVE_REASONING = True
except Exception:
    _HAVE_REASONING = False

    def _answer_cfo(*args, **kwargs):
        return {"text": kwargs.get("fallback_text", ""), "analysis": {}}


# =========================================================
# Router modules
# =========================================================
try:
    from nlp.router.session_state import ChatSession
except Exception:
    try:
        from nlp.router.router_session import ChatSession
    except Exception:
        class ChatSession:
            def __init__(self) -> None:
                self.last_intent: Optional[str] = None
                self.last_kpi: Dict[str, Any] = {}
                self.facts: Dict[str, str] = {}
                self.last_answer: Optional[Answer] = None
                self.missing_fields: List[str] = []

            def update(
                self,
                intent: Optional[str] = None,
                kpi: Optional[Dict[str, Any]] = None,
                facts: Optional[Dict[str, str]] = None,
                answer: Optional[Answer] = None,
                missing_fields: Optional[List[str]] = None,
            ) -> None:
                if intent:
                    self.last_intent = intent
                if kpi:
                    self.last_kpi = kpi
                if facts:
                    self.facts.update(facts)
                if answer:
                    self.last_answer = answer
                if missing_fields is not None:
                    self.missing_fields = missing_fields


try:
    from nlp.router.merge import merge_and_normalize_context
except Exception:
    def merge_and_normalize_context(
        *,
        text: str,
        context: Dict[str, Any],
        session: Any = None,
        tenant_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return dict(context or {})


try:
    from nlp.router.intent_resolver import (
        resolve_intent,
        heuristic_intent,
        maybe_set_session_intent,
    )
except Exception:
    def heuristic_intent(text: str) -> Optional[str]:
        return None

    def maybe_set_session_intent(session: Any, text: str) -> None:
        return None

    def resolve_intent(text: str, catalog: Any, session: Any) -> str:
        try:
            if hasattr(catalog, "match"):
                found = catalog.match(text)
                if found:
                    return str(found)
        except Exception:
            pass
        return getattr(session, "last_intent", None) or "executive_summary"


try:
    from nlp.router.metrics import handle_metric_or_summary
except Exception:
    def handle_metric_or_summary(**kwargs) -> Answer:
        return Answer(
            intent="error",
            narrative="Modulo router.metrics non disponibile.",
            advisories=[],
        )


try:
    from nlp.router.handlers import RouterHandlersMixin
except Exception:
    class RouterHandlersMixin:
        def dispatch_handler(self, intent: str, data: Dict[str, Any], text: str) -> Answer:
            return Answer(
                intent="error",
                narrative=f"Handler non disponibile per intent '{intent}'.",
                advisories=[],
            )

        def compose_consulting_block(
            self,
            metric: str,
            kpi: Any,
            base_data: Dict[str, Any],
            sector: str,
        ) -> str:
            return ""


try:
    from nlp.router.strategy import handle_strategic_analysis
except Exception:
    def handle_strategic_analysis(
        *,
        data: Dict[str, Any],
        text: str,
        strategy_engine: Any,
        have_strategic_snapshot: bool,
        strategic_snapshot_fn: Any,
        extract_business_state_fn: Any,
        build_priority_actions_fn: Any,
        top_actions_text_fn: Any,
        fmt_number_fn: Any,
    ) -> Answer:
        return Answer(
            intent="strategic_analysis",
            narrative="Modulo strategico non disponibile in questa build.",
            advisories=[],
        )


# =========================================================
# Memory
# =========================================================
try:
    from nlp.memory import MemoryStore, record_interaction  # type: ignore
except Exception:
    class MemoryStore:
        def __init__(self) -> None:
            pass

        def summary_view(self, tenant_id: str) -> Dict[str, Any]:
            return {}

        def remember_company(
            self,
            tenant_id: str,
            name: Optional[str] = None,
            sector: Optional[str] = None,
        ) -> None:
            return None

        def record_kpi(self, tenant_id: str, kpi: Dict[str, Any]) -> None:
            return None

        def get_threshold(self, tenant_id: str, key: str, default: float) -> float:
            return float(default)

        def push_event(self, tenant_id: str, kind: str, payload=None) -> None:
            return None

    def record_interaction(memory, tenant_id: str, kind: str, payload=None):
        try:
            if memory:
                memory.push_event(tenant_id, kind, payload)
        except Exception:
            pass


# =========================================================
# Catalog / strategy / formatting
# =========================================================
try:
    from nlp.intents_matcher import IntentsCatalog  # type: ignore
except Exception:
    IntentsCatalog = None  # type: ignore


try:
    from strategy.engine import StrategyEngine
    _HAVE_STRATEGY = True
except Exception:
    StrategyEngine = None  # type: ignore
    _HAVE_STRATEGY = False


try:
    from strategy.analysis import (
        strategic_snapshot,
        extract_business_state,
        build_priority_actions,
    )  # type: ignore
    _HAVE_STRATEGIC_SNAPSHOT = True
except Exception:
    _HAVE_STRATEGIC_SNAPSHOT = False

    def strategic_snapshot(data: Dict[str, Any]) -> Dict[str, Any]:
        return {}

    def extract_business_state(data: Dict[str, Any]) -> Dict[str, Any]:
        return {}

    def build_priority_actions(
        state: Dict[str, float],
        problem: str,
        sector: str = "default",
        phase: str = "growth",
    ):
        return []


try:
    from utils.fmt_parse import fmt_number_eu
except Exception:
    def fmt_number_eu(x: Any, decimals: int = 0) -> str:
        try:
            return f"{float(x):,.{decimals}f}".replace(",", "_").replace(".", ",").replace("_", ".")
        except Exception:
            return str(x)


# =========================================================
# Rules engine
# =========================================================
try:
    from core.rules_engine import evaluate_ruleset as _evaluate_ruleset  # type: ignore
    _HAVE_RULESET = True
    evaluate_rules = None
    load_rules = None
except Exception:
    _HAVE_RULESET = False
    _evaluate_ruleset = None
    try:
        from core.rules_engine import evaluate_rules, load_rules  # type: ignore
    except Exception:
        evaluate_rules = None
        load_rules = None


# =========================================================
# Router
# =========================================================
class NLPRouter(RouterHandlersMixin):
    HANDLER_INTENTS = {
        "simulate",
        "simulate_matrix",
        "forecast",
        "valuation",
        "opportunities",
        "price_opt",
        "sensitivity",
        "tornado",
    }

    BRAIN_SKIPPED_INTENTS = {
        "data_collection",
        "faq",
    }

    def __init__(
        self,
        intents_dir: Optional[str | Path] = None,
        rules_dir: Optional[str | Path] = None,
        *,
        memory: Optional[MemoryStore] = None,
        tenant_id: str = "default",
    ) -> None:
        self.intents_dir = str(intents_dir) if intents_dir else str(Path("content/nlp/intents"))
        self.rules_dir = str(rules_dir) if rules_dir else str(Path("content/knowledge/rules"))
        self.memory = memory or MemoryStore()
        self.tenant_id = tenant_id or "default"

        try:
            self.catalog = IntentsCatalog(self.intents_dir) if IntentsCatalog else self._DummyCatalog()
        except Exception:
            self.catalog = self._DummyCatalog()

        self.session = ChatSession()
        self.strategy_engine = StrategyEngine() if _HAVE_STRATEGY else None

    def handle(self, text: str, context: Dict[str, Any]) -> Answer:
        maybe_set_session_intent(self.session, text)

        self.tenant_id = str((context or {}).get("tenant_id") or self.tenant_id or "default")
        short_mode = bool((context or {}).get("short_answers", False))

        data = merge_and_normalize_context(
            text=text,
            context=context,
            session=self.session,
            tenant_id=self.tenant_id,
        )

        sector = self._resolve_sector(data)
        self._remember_company(context=context, data=data)

        try:
            intent = resolve_intent(
                text=text,
                catalog=self.catalog,
                session=self.session,
            )
        except Exception:
            intent = heuristic_intent(text) or self.session.last_intent or "executive_summary"

        faq_ans = self._run_faq_if_needed(text)
        if faq_ans is not None:
            if short_mode and isinstance(faq_ans.narrative, str):
                faq_ans.narrative = faq_ans.narrative.split(" | ")[0].split("\n")[0][:300]

            self.session.update(
                intent="faq",
                kpi=data,
                answer=faq_ans,
            )
            return faq_ans

        brain_ans = self._run_brain_if_needed(
            intent=intent,
            text=text,
            data=data,
        )
        if brain_ans is not None:
            if short_mode and isinstance(brain_ans.narrative, str):
                brain_ans.narrative = brain_ans.narrative.split(" | ")[0].split("\n")[0][:300]

            self.session.update(
                intent="data_collection",
                kpi=data,
                answer=brain_ans,
                missing_fields=list(getattr(self.session, "missing_fields", []) or []),
            )
            return brain_ans

        ans = self._dispatch_intent(
            intent=intent,
            text=text,
            data=data,
            sector=sector,
        )

        if short_mode and isinstance(ans.narrative, str):
            ans.narrative = ans.narrative.split(" | ")[0].split("\n")[0][:300]

        self.session.update(
            intent=intent,
            kpi=data,
            answer=ans,
            missing_fields=[],
        )

        self._store_kpi_snapshot(data=data, ans=ans)
        return ans

    __call__ = handle

    def _run_faq_if_needed(self, text: str) -> Optional[Answer]:
        if not _HAVE_FAQ_ROUTER:
            return None

        try:
            faq = route_faq(text)
        except Exception:
            return None

        matched = bool(faq.get("matched", False))
        answer = str(faq.get("answer", "") or "").strip()

        if not matched or not answer:
            return None

        return Answer(
            intent="faq",
            narrative=answer,
            advisories=[],
            meta={
                "source": "faq",
                "faq_score": faq.get("score", 0),
                "faq_category": faq.get("category"),
            },
        )

    def _run_brain_if_needed(
        self,
        *,
        intent: str,
        text: str,
        data: Dict[str, Any],
    ) -> Optional[Answer]:
        if intent in self.BRAIN_SKIPPED_INTENTS:
            return None

        try:
            brain = brain_decision(intent, data, text=text)
        except Exception:
            return None

        action = str(brain.get("action", "") or "").strip().lower()
        if action != "ask":
            return None

        questions = brain.get("questions", []) or []
        missing = brain.get("missing", []) or []
        help_lines = brain.get("help", []) or []
        mode = str(brain.get("mode", "") or "").strip()

        clean_questions: List[str] = []
        for q in questions:
            qq = str(q or "").strip()
            if qq:
                clean_questions.append(f"- {qq}")

        clean_help: List[str] = []
        for h in help_lines:
            hh = str(h or "").strip()
            if hh:
                clean_help.append(f"- {hh}")

        if not clean_questions:
            clean_questions = ["- Mi serve almeno un dato in più per darti una risposta precisa."]

        narrative_parts: List[str] = []
        narrative_parts.append("Per aiutarti davvero come CFO, partiamo da questo dato:")
        narrative_parts.append("")
        narrative_parts.extend(clean_questions)

        if clean_help:
            narrative_parts.append("")
            narrative_parts.append("Per semplificare:")
            narrative_parts.extend(clean_help)

        self.session.missing_fields = [str(x) for x in missing if str(x).strip()]

        return Answer(
            intent="data_collection",
            narrative="\n".join(narrative_parts),
            advisories=[],
            meta={
                "brain_action": "ask",
                "brain_mode": mode,
                "missing_fields": self.session.missing_fields,
                "original_intent": intent,
            },
        )

    def _dispatch_intent(
        self,
        *,
        intent: str,
        text: str,
        data: Dict[str, Any],
        sector: str,
    ) -> Answer:
        try:
            if intent == "strategic_analysis":
                return handle_strategic_analysis(
                    data=data,
                    text=text,
                    strategy_engine=self.strategy_engine,
                    have_strategic_snapshot=_HAVE_STRATEGIC_SNAPSHOT,
                    strategic_snapshot_fn=strategic_snapshot,
                    extract_business_state_fn=extract_business_state,
                    build_priority_actions_fn=build_priority_actions,
                    top_actions_text_fn=self._top_actions_text,
                    fmt_number_fn=fmt_number_eu,
                )

            if intent in self.HANDLER_INTENTS:
                return self.dispatch_handler(intent=intent, data=data, text=text)

            return handle_metric_or_summary(
                intent=intent,
                text=text,
                data=data,
                sector=sector,
                tenant_id=self.tenant_id,
                rules_dir=self.rules_dir,
                have_reasoning=_HAVE_REASONING,
                answer_cfo_fn=_answer_cfo,
                compose_consulting_block_fn=self.compose_consulting_block,
                have_ruleset=_HAVE_RULESET,
                evaluate_ruleset_fn=_evaluate_ruleset,
                load_rules_fn=load_rules,
                evaluate_rules_fn=evaluate_rules,
            )

        except Exception as e:
            return Answer(
                intent="error",
                narrative=f"Ho avuto un problema nell'elaborazione ({type(e).__name__}: {str(e)}).",
                advisories=[],
            )

    def _resolve_sector(self, data: Dict[str, Any]) -> str:
        try:
            memory_sector = None
            if self.memory:
                memory_sector = (
                    self.memory.summary_view(self.tenant_id)
                    .get("company", {})
                    .get("sector")
                )

            return str(
                data.get("sector")
                or self.session.facts.get("sector")
                or memory_sector
                or "default"
            )
        except Exception:
            return "default"

    def _remember_company(self, *, context: Dict[str, Any], data: Dict[str, Any]) -> None:
        try:
            company_name = (context or {}).get("company_name")
            sector = data.get("sector")
            if company_name or sector:
                self.memory.remember_company(
                    self.tenant_id,
                    name=company_name,
                    sector=sector,
                )
        except Exception:
            pass

    def _store_kpi_snapshot(self, *, data: Dict[str, Any], ans: Answer) -> None:
        try:
            kpi_snapshot_obj = compute_kpis(**data)
            kpi_snapshot = (
                kpi_snapshot_obj.model_dump()
                if hasattr(kpi_snapshot_obj, "model_dump")
                else {}
            )

            if kpi_snapshot:
                self.memory.record_kpi(self.tenant_id, kpi_snapshot)

            for adv in ans.advisories or []:
                record_interaction(
                    self.memory,
                    self.tenant_id,
                    kind=f"alert:{adv.code}",
                    payload={
                        "severity": getattr(adv, "severity", ""),
                        "title": adv.title,
                        "detail": adv.detail,
                    },
                )
        except Exception:
            pass

    def _top_actions_text(self, actions: List[Dict[str, Any]], limit: int = 3) -> str:
        rows: List[str] = []
        for a in (actions or [])[:limit]:
            title = str(a.get("title", "")).strip()
            why = str(a.get("why", "")).strip()
            how = str(a.get("how", "")).strip()

            if title:
                line = f"- {title}"
                if why:
                    line += f" — {why}"
                if how:
                    line += f" | Come: {how}"
                rows.append(line)

        return "\n".join(rows)

    class _DummyCatalog:
        def match(self, text: Optional[str]) -> Optional[str]:
            return heuristic_intent(text or "")