# -*- coding: utf-8 -*-
# content/nlp/router_sensitivity.py
# Sensitivity and Tornado handlers extracted from router.py

from __future__ import annotations

from typing import Any, Dict

from core.schemas import Answer
from utils.fmt_parse import fmt_number_eu


# =========================================================
# Safe imports
# =========================================================
try:
    from core.metrics import compute_kpis, sensitivity_analysis, tornado_data  # type: ignore

    HAVE_SENSITIVITY = True
except Exception:
    HAVE_SENSITIVITY = False

    def compute_kpis(**kwargs):  # type: ignore
        raise RuntimeError("compute_kpis non disponibile")

    def sensitivity_analysis(*args, **kwargs):  # type: ignore
        return []

    def tornado_data(*args, **kwargs):  # type: ignore
        return []


# =========================================================
# Factory
# =========================================================
def build_sensitivity_handler():
    def handle_sensitivity(data: Dict[str, Any]) -> Answer:
        if not HAVE_SENSITIVITY:
            return Answer(
                intent="sensitivity",
                narrative="Funzione di sensitività non disponibile in questa build.",
                advisories=[],
            )

        try:
            kpi = compute_kpis(**data)

            params = data.get("sensitivity_params")
            if not isinstance(params, dict) or not params:
                params = {
                    "prezzo_medio": (-0.05, 0.05),
                    "costi_fissi": (-0.05, 0.05),
                }

            steps = int(data.get("sensitivity_steps", 5) or 5)
            rows = sensitivity_analysis(kpi, params, steps=steps)

            best = None
            base_utile = float(getattr(kpi, "utile", 0.0))

            for row in rows:
                metrics = row.get("metrics", {}) if isinstance(row, dict) else {}
                try:
                    delta_utile = float(metrics.get("utile", base_utile)) - base_utile
                except Exception:
                    delta_utile = 0.0

                if best is None or abs(delta_utile) > abs(best[1]):
                    best = (row.get("param", "n/a"), delta_utile)

            if best:
                sign = "↑" if best[1] >= 0 else "↓"
                narrative = (
                    f"Sensitività: parametro più impattante su utile = {best[0]} "
                    f"({sign}{fmt_number_eu(abs(best[1]), 0)})."
                )
            else:
                narrative = "Sensitività calcolata."

            return Answer(
                intent="sensitivity",
                narrative=narrative,
                advisories=[],
            )

        except Exception:
            return Answer(
                intent="sensitivity",
                narrative="Errore nel calcolo della sensitività.",
                advisories=[],
            )

    return handle_sensitivity


def build_tornado_handler():
    def handle_tornado(data: Dict[str, Any]) -> Answer:
        if not HAVE_SENSITIVITY:
            return Answer(
                intent="tornado",
                narrative="Funzione Tornado non disponibile in questa build.",
                advisories=[],
            )

        try:
            kpi = compute_kpis(**data)

            deltas = data.get("tornado_deltas")
            if not isinstance(deltas, dict) or not deltas:
                deltas = {
                    "prezzo_medio": 0.10,
                    "costi_fissi": 0.05,
                    "costi_variabili": 0.05,
                }

            metric = str(data.get("tornado_metric", "utile"))
            bars = tornado_data(kpi, deltas, metric=metric)

            if not bars:
                return Answer(
                    intent="tornado",
                    narrative="Nessun dato per Tornado.",
                    advisories=[],
                )

            top = bars[0]
            narrative = (
                f"Tornado: parametro #1 = {top['param']} "
                f"(range impatto {fmt_number_eu(top['range_abs'], 0)} sulla metrica "
                f"'{metric}')."
            )

            return Answer(
                intent="tornado",
                narrative=narrative,
                advisories=[],
            )

        except Exception:
            return Answer(
                intent="tornado",
                narrative="Errore nel calcolo del Tornado.",
                advisories=[],
            )

    return handle_tornado