# -*- coding: utf-8 -*-
# content/nlp/router/merge.py

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.validators import normalize_context_numeric

try:
    from nlp.slot_extraction import extract_slots  # type: ignore
except Exception:
    def extract_slots(text: str) -> Dict[str, Any]:
        return {}


def _as_float_list(value: Any) -> Optional[List[float]]:
    if not isinstance(value, list):
        return None

    out: List[float] = []
    for item in value:
        try:
            out.append(float(item))
        except Exception:
            continue

    return out if out else None


def _as_grid(value: Any) -> Optional[Dict[str, List[float]]]:
    if not isinstance(value, dict):
        return None

    grid: Dict[str, List[float]] = {}
    for k, v in value.items():
        if isinstance(v, list):
            arr: List[float] = []
            for x in v:
                try:
                    arr.append(float(x))
                except Exception:
                    continue
            if arr:
                grid[str(k)] = arr

    return grid if grid else None


def merge_and_normalize_context(
    *,
    text: str,
    context: Dict[str, Any],
    session: Any = None,
    tenant_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Merge robusto:
    - session.last_kpi
    - session.facts
    - context
    - slots estratti dal testo

    Poi normalizza i campi numerici e preserva liste/dict utili
    per forecast, valuation, simulate_matrix, sensitivity, tornado.
    """
    slots = extract_slots(text or "")

    session_last_kpi = {}
    session_facts = {}

    try:
        session_last_kpi = getattr(session, "last_kpi", {}) or {}
    except Exception:
        session_last_kpi = {}

    try:
        session_facts = getattr(session, "facts", {}) or {}
    except Exception:
        session_facts = {}

    merged_raw: Dict[str, Any] = {
        **session_last_kpi,
        **session_facts,
        **(context or {}),
        **(slots or {}),
    }

    numeric_base = {
        k: v
        for k, v in merged_raw.items()
        if not isinstance(v, (list, dict))
    }

    data = normalize_context_numeric(numeric_base)

    numeric_keys = (
        "fatturato",
        "costi_variabili",
        "costi_fissi",
        "investimenti",
        "prezzo_medio",
        "costo_variabile_unitario",
        "cogs",
        "ammortamenti",
        "dso",
        "dio",
        "dpo",
        "fatturato_pct",
        "costi_variabili_pct",
        "costi_fissi_pct",
        "price_pct",
        "prezzo_pct",
        "price_elasticity",
        "qty_pct",
        "fatturato_abs",
        "costi_variabili_abs",
        "costi_fissi_abs",
        "investimenti_abs",
        "discount_rate_pct",
        "terminal_growth_pct",
        "net_debt",
        "ke",
        "kd",
        "equity",
        "debt",
        "tax_rate",
        "periods",
        "sensitivity_steps",
    )

    for k in numeric_keys:
        try:
            data[k] = float(data.get(k, 0.0) or 0.0)
        except Exception:
            data[k] = 0.0

    history = _as_float_list(merged_raw.get("history"))
    if history is not None:
        data["history"] = history

    cashflows = _as_float_list(merged_raw.get("cashflows"))
    if cashflows is not None:
        data["cashflows"] = cashflows

    dcf_fcf = _as_float_list(merged_raw.get("dcf_fcf"))
    if dcf_fcf is not None:
        data["dcf_fcf"] = dcf_fcf

    grid = _as_grid(merged_raw.get("grid"))
    if grid is not None:
        data["grid"] = grid

    sensitivity_params = merged_raw.get("sensitivity_params")
    if isinstance(sensitivity_params, dict):
        data["sensitivity_params"] = sensitivity_params

    tornado_deltas = merged_raw.get("tornado_deltas")
    if isinstance(tornado_deltas, dict):
        data["tornado_deltas"] = tornado_deltas

    if isinstance(merged_raw.get("method"), str):
        data["method"] = str(merged_raw["method"])

    if isinstance(merged_raw.get("forecast_method"), str):
        data["forecast_method"] = str(merged_raw["forecast_method"])

    if isinstance(merged_raw.get("sector"), str):
        data["sector"] = str(merged_raw["sector"])
        try:
            if session is not None and hasattr(session, "facts"):
                session.facts["sector"] = str(merged_raw["sector"])
        except Exception:
            pass

    if isinstance(merged_raw.get("tenant_id"), (str, int)):
        data["tenant_id"] = str(merged_raw["tenant_id"])
    elif tenant_id:
        data["tenant_id"] = str(tenant_id)

    return data