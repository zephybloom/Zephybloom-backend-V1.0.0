# -*- coding: utf-8 -*-
# content/nlp/router/metrics.py

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from core.metrics import compute_kpis
from core.schemas import Advisory, Answer

try:
    from nlp.nlp_answer import answer_metric  # type: ignore
except Exception:
    def answer_metric(metric: str, kpi: Any, sector: str = "default") -> Answer:
        return Answer(intent=metric, narrative=f"{metric}: pronto.", advisories=[])

try:
    from zephytheory.logic import zephytheory_logic
    _HAVE_ZT_LOGIC = True
except Exception:
    _HAVE_ZT_LOGIC = False

    def zephytheory_logic(kpi: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "problem": "",
            "priority": "",
            "lever": "",
            "actions": [],
            "rationale": [],
            "summary": "",
            "scorecard": {},
        }


def force_metric_from_text(text: str) -> Optional[str]:
    low = (text or "").lower()

    if "roi" in low:
        return "roi"
    if any(x in low for x in ("bep", "break-even", "punto di pareggio")):
        return "break_even"
    if "margine" in low or "mc " in low:
        return "margine"
    if "ebitda" in low:
        return "ebitda"
    if "utile" in low or "profitto" in low:
        return "utile"
    if "fatturato" in low or "ricavi" in low:
        return "fatturato"
    if "cash flow" in low or "ciclo di cassa" in low or "ccc" in low or "working capital" in low:
        return "cashflow"
    if "altman" in low or "z-score" in low or "z score" in low:
        return "zscore"

    return None


force_metric = force_metric_from_text


def _clean_text_list(items: Any, limit: Optional[int] = None) -> List[str]:
    out: List[str] = []

    if not isinstance(items, list):
        return out

    seen = set()
    for item in items:
        txt = str(item or "").strip()
        if not txt:
            continue

        key = txt.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(txt)

        if limit is not None and len(out) >= limit:
            break

    return out


def _safe_model_dump(obj: Any) -> Dict[str, Any]:
    if hasattr(obj, "model_dump"):
        try:
            dumped = obj.model_dump()
            if isinstance(dumped, dict):
                return dumped
        except Exception:
            pass
    return obj if isinstance(obj, dict) else {}


def _build_zephytheory_structured_block(
    kpi_payload: Dict[str, Any],
    data: Dict[str, Any],
) -> Dict[str, List[str] | str]:
    if not _HAVE_ZT_LOGIC:
        return {
            "diagnosis_lines": [],
            "why_lines": [],
            "action_lines": [],
            "summary": "",
        }

    try:
        zt = zephytheory_logic(kpi_payload, data)
    except Exception:
        return {
            "diagnosis_lines": [],
            "why_lines": [],
            "action_lines": [],
            "summary": "",
        }

    problem = str(zt.get("problem", "") or "").strip()
    lever = str(zt.get("lever", "") or "").strip()
    summary = str(zt.get("summary", "") or "").strip()

    rationale = _clean_text_list(zt.get("rationale", []), limit=3)
    actions = _clean_text_list(zt.get("actions", []), limit=3)

    diagnosis_lines: List[str] = []
    if problem:
        diagnosis_lines.append(f"Problema principale: {problem}")
    if lever:
        diagnosis_lines.append(f"Leva prioritaria: {lever}")
    if summary:
        diagnosis_lines.append(f"Sintesi strategica: {summary}")

    return {
        "diagnosis_lines": diagnosis_lines,
        "why_lines": rationale,
        "action_lines": actions,
        "summary": summary,
    }


def _merge_narrative_blocks(
    *,
    cfo_text: str,
    zt_block: Dict[str, List[str] | str],
    consulting_block: str,
) -> str:
    parts: List[str] = []

    base_text = str(cfo_text or "").strip()
    if base_text:
        parts.append(base_text)

    diagnosis_lines = zt_block.get("diagnosis_lines", []) or []
    why_lines = zt_block.get("why_lines", []) or []
    action_lines = zt_block.get("action_lines", []) or []

    strategic_sections: List[str] = []

    if diagnosis_lines:
        strategic_sections.append(
            "### Lettura strategica\n" + "\n".join([f"- {x}" for x in diagnosis_lines if str(x).strip()])
        )

    if why_lines:
        strategic_sections.append(
            "### Perché conta\n" + "\n".join([f"- {x}" for x in why_lines if str(x).strip()])
        )

    if action_lines:
        strategic_sections.append(
            "### Azioni strategiche prioritarie\n" + "\n".join([f"- {x}" for x in action_lines if str(x).strip()])
        )

    if strategic_sections:
        parts.append("\n\n".join(strategic_sections))

    consulting_text = str(consulting_block or "").strip()
    if consulting_text:
        parts.append(consulting_text)

    return "\n\n".join([p for p in parts if p]).strip()


def _build_rule_advisories(
    *,
    kpi_payload: Dict[str, Any],
    data: Dict[str, Any],
    sector: str,
    tenant_id: str,
    rules_dir: str,
    have_ruleset: bool,
    evaluate_ruleset_fn: Optional[Callable[..., Any]],
    load_rules_fn: Optional[Callable[..., Any]],
    evaluate_rules_fn: Optional[Callable[..., Any]],
) -> List[Advisory]:
    try:
        if have_ruleset and evaluate_ruleset_fn is not None:
            alerts = evaluate_ruleset_fn(
                rules_dir,
                kpi_payload,
                context=data,
                tenant_id=tenant_id,
                sector=sector,
                hierarchical=True,
            )
        else:
            rules = load_rules_fn(rules_dir) if load_rules_fn is not None else []
            alerts = (
                evaluate_rules_fn(kpi_payload, rules, context=data)
                if evaluate_rules_fn is not None
                else []
            )

        out: List[Advisory] = []
        for a in (alerts or [])[:5]:
            if not isinstance(a, dict):
                continue

            out.append(
                Advisory(
                    code=a.get("code", "RULE"),
                    title=a.get("message", ""),
                    detail=a.get("detail", "") or "",
                    severity=a.get("severity", "info"),
                    suggestions=a.get("suggestions", []) or [],
                    meta=a.get("meta", {}) if isinstance(a.get("meta"), dict) else {},
                )
            )
        return out
    except Exception:
        return []


def handle_metric_or_summary(
    *,
    intent: str,
    text: str,
    data: Dict[str, Any],
    sector: str,
    tenant_id: str,
    rules_dir: str,
    have_reasoning: bool,
    answer_cfo_fn: Callable[..., Dict[str, Any]],
    compose_consulting_block_fn: Callable[..., str],
    have_ruleset: bool,
    evaluate_ruleset_fn: Optional[Callable[..., Any]] = None,
    load_rules_fn: Optional[Callable[..., Any]] = None,
    evaluate_rules_fn: Optional[Callable[..., Any]] = None,
) -> Answer:
    try:
        kpi = compute_kpis(**data)
    except Exception:
        missing = ["fatturato", "costi_variabili", "costi_fissi"]
        return Answer(
            intent="missing_data",
            narrative=f"Per calcolare i KPI servono almeno: {', '.join(missing)}.",
            advisories=[],
        )

    metric_intents = {
        "roi",
        "break_even",
        "margine",
        "fatturato",
        "utile",
        "ebitda",
        "cashflow",
        "zscore",
    }

    forced_metric = force_metric_from_text(text)
    metric = forced_metric or (intent if intent in metric_intents else "executive_summary")

    ans = answer_metric(metric, kpi, sector=sector)

    try:
        consulting_block = compose_consulting_block_fn(
            metric=metric,
            kpi=kpi,
            base_data=data,
            sector=sector,
        )
    except TypeError:
        try:
            consulting_block = compose_consulting_block_fn(metric, kpi, data, sector)
        except Exception:
            consulting_block = ""
    except Exception:
        consulting_block = ""

    kpi_payload = _safe_model_dump(kpi)

    zt_block = _build_zephytheory_structured_block(
        kpi_payload=kpi_payload,
        data=data,
    )

    cfo_text = ""
    if have_reasoning:
        intent_map = {
            "cashflow": "diagnosi_cassa",
            "valuation": "valutazione_azienda",
            "opportunities": "opportunities",
        }
        re_intent = intent_map.get(metric, "analizza_kpi")

        try:
            out = answer_cfo_fn(
                query=text,
                intent=re_intent,
                payload=kpi_payload,
                params=None,
                memory={"tenant_id": tenant_id},
                system_prompt=None,
                fallback_text=ans.narrative,
            )
            if isinstance(out, dict):
                cfo_text = str(out.get("text", "") or "").strip()
        except Exception:
            cfo_text = ""

    if not cfo_text:
        cfo_text = str(ans.narrative or "").strip()

    ans.narrative = _merge_narrative_blocks(
        cfo_text=cfo_text,
        zt_block=zt_block,
        consulting_block=consulting_block,
    )

    rule_advisories = _build_rule_advisories(
        kpi_payload=kpi_payload,
        data=data,
        sector=sector,
        tenant_id=tenant_id,
        rules_dir=rules_dir,
        have_ruleset=have_ruleset,
        evaluate_ruleset_fn=evaluate_ruleset_fn,
        load_rules_fn=load_rules_fn,
        evaluate_rules_fn=evaluate_rules_fn,
    )
    ans.advisories.extend(rule_advisories)

    return ans