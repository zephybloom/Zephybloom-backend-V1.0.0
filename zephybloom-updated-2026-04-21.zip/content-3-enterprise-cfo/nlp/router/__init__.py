# Export NLPRouter from submodule
from nlp.router.router import NLPRouter

__all__ = ["NLPRouter"]
