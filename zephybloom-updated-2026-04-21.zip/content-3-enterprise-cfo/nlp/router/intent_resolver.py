# -*- coding: utf-8 -*-
# content/nlp/router/intent_resolver.py

from __future__ import annotations

from typing import Any, Optional

try:
    from nlp.router.question_map import map_question_to_router_intent
    _HAVE_QUESTION_MAP = True
except Exception:
    _HAVE_QUESTION_MAP = False

    def map_question_to_router_intent(text: str) -> dict:
        return {
            "matched": False,
            "router_intent": None,
            "macro_intent": None,
            "sub_intent": None,
            "key": None,
            "score": 0,
        }


class IntentResolver:
    """
    Resolver centralizzato degli intent:
    1. question_map -> riconoscimento più preciso lato business/user language
    2. euristiche testuali -> fallback robusto
    3. catalog match/match_one -> supporto intent catalog esistente
    4. session fallback -> continuità conversazionale
    """

    STRATEGIC_KEYWORDS = (
        "analisi strategica",
        "analizza il business",
        "analizza business",
        "strategia del business",
        "lettura strategica",
        "strategic analysis",
        "business analysis",
        "analizza il business saas",
        "business saas",
        "azienda saas",
        "modello saas",
        "come crescere",
        "come scalare",
        "cosa dovrei fare",
        "cosa devo fare",
        "pricing",
        "posizionamento",
        "collo di bottiglia",
        "bottleneck",
    )

    @staticmethod
    def heuristic_intent(text: str) -> Optional[str]:
        t = (text or "").lower()

        if any(x in t for x in IntentResolver.STRATEGIC_KEYWORDS):
            return "strategic_analysis"

        if "roi" in t:
            return "roi"

        if ("ottimizz" in t and "prezz" in t) or "prezzo ottimale" in t:
            return "price_opt"

        if any(x in t for x in ("simulate", "simula", "scenario")):
            if any(x in t for x in ("matrice", "griglia", "grid", "matrix", "multipli", "multi-scenario")):
                return "simulate_matrix"
            return "simulate"

        if any(x in t for x in ("forecast", "prevision", "preved")):
            return "forecast"

        if any(x in t for x in ("valuation", "npv", "irr", "dcf")):
            return "valuation"

        if "opportunit" in t:
            return "opportunities"

        if any(x in t for x in ("bep", "break-even", "punto di pareggio")):
            return "break_even"

        if "margine" in t or "mc " in t:
            return "margine"

        if "ebitda" in t:
            return "ebitda"

        if "utile" in t or "profitto" in t:
            return "utile"

        if "fatturato" in t or "ricavi" in t:
            return "fatturato"

        if "cash flow" in t or "ciclo di cassa" in t or "ccc" in t or "working capital" in t:
            return "cashflow"

        if "altman" in t or "z-score" in t or "z score" in t:
            return "zscore"

        if any(x in t for x in ("sensitiv", "sensitivity")):
            return "sensitivity"

        if "tornado" in t:
            return "tornado"

        return None

    @staticmethod
    def resolve_catalog_intent(catalog: Any, text: str) -> Optional[str]:
        if catalog is None:
            return None

        try:
            if hasattr(catalog, "match"):
                found = catalog.match(text)  # type: ignore[attr-defined]
                return str(found) if found else None

            hit = getattr(catalog, "match_one")(text)  # type: ignore[attr-defined]
            return hit["name"] if hit else None
        except Exception:
            return None

    @staticmethod
    def resolve_question_intent(text: str) -> Optional[str]:
        if not _HAVE_QUESTION_MAP:
            return None

        try:
            mapped = map_question_to_router_intent(text)
            if mapped.get("matched"):
                router_intent = mapped.get("router_intent")
                return str(router_intent) if router_intent else None
        except Exception:
            return None

        return None

    @staticmethod
    def resolve(
        *,
        text: str,
        catalog: Any = None,
        session_last_intent: Optional[str] = None,
        default_intent: str = "executive_summary",
    ) -> str:
        # 1. Question map: prima il linguaggio reale dell’imprenditore
        question_intent = IntentResolver.resolve_question_intent(text)

        # 2. Heuristica classica
        heuristic = IntentResolver.heuristic_intent(text)

        # 3. Catalogo esistente
        catalog_intent = IntentResolver.resolve_catalog_intent(catalog, text)

        # Strategic ha priorità forte
        if question_intent == "strategic_analysis" or heuristic == "strategic_analysis":
            return "strategic_analysis"

        # question_map viene prima del catalogo:
        # capisce meglio frasi reali cliente tipo "cosa devo fare"
        if question_intent:
            return question_intent

        if catalog_intent:
            return catalog_intent

        if heuristic:
            return heuristic

        if session_last_intent:
            return session_last_intent

        return default_intent

    @staticmethod
    def maybe_set_session_intent(session: Any, text: str) -> None:
        t = (text or "").lower()
        triggers = ("da ora in poi", "imposta intent", "usa sempre", "default intent")

        if not any(x in t for x in triggers):
            return

        if any(x in t for x in ("strategia", "strategico", "crescere", "scalare", "pricing", "posizionamento")):
            session.last_intent = "strategic_analysis"
        elif "simula" in t or "simulate" in t:
            session.last_intent = "simulate"
        elif "preved" in t or "forecast" in t:
            session.last_intent = "forecast"
        elif any(x in t for x in ("valuation", "npv", "irr", "dcf")):
            session.last_intent = "valuation"
        elif "opportunit" in t:
            session.last_intent = "opportunities"
        elif "prezzo" in t:
            session.last_intent = "price_opt"
        elif "roi" in t:
            session.last_intent = "roi"

    @staticmethod
    def force_metric(text: str) -> Optional[str]:
        low = (text or "").lower()

        if "roi" in low:
            return "roi"

        if any(x in low for x in ("bep", "break-even", "punto di pareggio")):
            return "break_even"

        if "margine" in low or "mc " in low:
            return "margine"

        if "ebitda" in low:
            return "ebitda"

        if "utile" in low or "profitto" in low:
            return "utile"

        if "fatturato" in low or "ricavi" in low:
            return "fatturato"

        if "cash flow" in low or "ciclo di cassa" in low or "ccc" in low or "working capital" in low:
            return "cashflow"

        if "altman" in low or "z-score" in low or "z score" in low:
            return "zscore"

        return None


# =========================================================
# Wrapper functions compatibili col router attuale
# =========================================================
def heuristic_intent(text: str) -> Optional[str]:
    return IntentResolver.heuristic_intent(text)


def resolve_intent(
    text: str,
    catalog: Any,
    session: Any,
) -> str:
    return IntentResolver.resolve(
        text=text,
        catalog=catalog,
        session_last_intent=getattr(session, "last_intent", None),
        default_intent="executive_summary",
    )


def maybe_set_session_intent(session: Any, text: str) -> None:
    IntentResolver.maybe_set_session_intent(session, text)


def force_metric(text: str) -> Optional[str]:
    return IntentResolver.force_metric(text)


class DummyCatalog:
    def match(self, text: Optional[str]) -> Optional[str]:
        return IntentResolver.heuristic_intent(text or "")