"""
Router-LLM fallback implementation.
"""
from __future__ import annotations

import importlib
from typing import Any, Callable, Dict, List, Optional

from core.schemas import Answer
from nlp.llm_adapter import DEFAULT_SYSTEM, LLMAdapter
from nlp.router.router import NLPRouter
from utils.fmt_parse import fmt_number_eu


# -----------------------------
# Utility interne
# -----------------------------
def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _safe_text(x: Any) -> str:
    try:
        return str(x or "").strip()
    except Exception:
        return ""


# -----------------------------
# Fallback minimale di tools (MVP)
# -----------------------------
class _MiniToolInvoker:
    def get_openai_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": "kpi_compute",
                    "description": "Calcola KPI base (MC, BEP, utile, EBITDA, ROI) da ricavi e costi.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "fatturato": {"type": "number"},
                            "costi_variabili": {"type": "number"},
                            "costi_fissi": {"type": "number"},
                            "investimenti": {"type": "number", "default": 0},
                            "ammortamenti": {"type": "number", "default": 0},
                        },
                        "required": ["fatturato", "costi_variabili", "costi_fissi"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "simulate_delta",
                    "description": "Applica delta percentuali/assoluti a ricavi/costi per stimare l'impatto sull'utile.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "fatturato": {"type": "number"},
                            "costi_variabili": {"type": "number"},
                            "costi_fissi": {"type": "number"},
                            "fatturato_pct": {"type": "number", "default": 0},
                            "costi_variabili_pct": {"type": "number", "default": 0},
                            "costi_fissi_pct": {"type": "number", "default": 0},
                        },
                        "required": ["fatturato", "costi_variabili", "costi_fissi"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "strategic_summary",
                    "description": "Riformula una diagnosi strategica del business in modo sintetico e azionabile.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "fatturato": {"type": "number"},
                            "costi_variabili": {"type": "number"},
                            "costi_fissi": {"type": "number"},
                            "utile": {"type": "number"},
                            "ebitda": {"type": "number"},
                            "roi": {"type": "number"},
                            "ltv": {"type": "number"},
                            "cac": {"type": "number"},
                            "churn_rate": {"type": "number"},
                            "nrr": {"type": "number"},
                        },
                        "required": [],
                    },
                },
            },
        ]

    def invoke(self, name: str, args: Dict[str, Any]) -> Any:
        try:
            if name == "kpi_compute":
                fatt = _safe_float(args.get("fatturato", 0.0))
                cv = _safe_float(args.get("costi_variabili", 0.0))
                cf = _safe_float(args.get("costi_fissi", 0.0))
                inv = _safe_float(args.get("investimenti", 0.0))
                amm = _safe_float(args.get("ammortamenti", 0.0))

                mc = fatt - cv
                utile = mc - cf
                ebitda = utile + amm
                roi = (utile / inv * 100.0) if inv > 0 else None
                bep = None
                if fatt > 0 and cv < fatt:
                    mcr = 1.0 - (cv / fatt)
                    if mcr > 0:
                        bep = cf / mcr

                return {
                    "margine_contribuzione": mc,
                    "break_even": bep,
                    "ebitda": ebitda,
                    "utile": utile,
                    "roi": roi,
                }

            if name == "simulate_delta":
                fatt = _safe_float(args.get("fatturato", 0.0))
                cv = _safe_float(args.get("costi_variabili", 0.0))
                cf = _safe_float(args.get("costi_fissi", 0.0))

                fatt *= 1.0 + _safe_float(args.get("fatturato_pct", 0.0)) / 100.0
                cv *= 1.0 + _safe_float(args.get("costi_variabili_pct", 0.0)) / 100.0
                cf *= 1.0 + _safe_float(args.get("costi_fissi_pct", 0.0)) / 100.0

                utile = (fatt - cv) - cf
                return {
                    "fatturato": fatt,
                    "costi_variabili": cv,
                    "costi_fissi": cf,
                    "utile": utile,
                }

            if name == "strategic_summary":
                fatt = _safe_float(args.get("fatturato", 0.0))
                cv = _safe_float(args.get("costi_variabili", 0.0))
                cf = _safe_float(args.get("costi_fissi", 0.0))
                utile = _safe_float(args.get("utile", (fatt - cv - cf)))
                ebitda = _safe_float(args.get("ebitda", utile))
                roi = args.get("roi", None)

                mc_rate = ((fatt - cv) / fatt * 100.0) if fatt > 0 else 0.0
                net_margin = (utile / fatt * 100.0) if fatt > 0 else 0.0

                diagnosis = "business discretamente sano ma con leve di crescita da chiarire"
                if fatt <= 0:
                    diagnosis = "assenza di base dati economica sufficiente"
                elif mc_rate < 30:
                    diagnosis = "marginalità lorda debole"
                elif net_margin < 5:
                    diagnosis = "struttura costi fissi troppo pesante"

                return {
                    "diagnosis": diagnosis,
                    "mc_rate_pct": mc_rate,
                    "net_margin_pct": net_margin,
                    "utile": utile,
                    "ebitda": ebitda,
                    "roi": roi,
                    "ltv": args.get("ltv"),
                    "cac": args.get("cac"),
                    "churn_rate": args.get("churn_rate"),
                    "nrr": args.get("nrr"),
                }

        except Exception as e:
            return {"error": f"tool error: {type(e).__name__}: {e}"}

        return {"error": f"unknown tool '{name}'"}


# -----------------------------
# Router LLM-augmented
# -----------------------------
class NLPRouterLLM(NLPRouter):
    """
    Estende il router deterministico con un fallback LLM consulenziale.

    - Riusa la logica di NLPRouter (intents, KPI, strategy, rules, ecc.)
    - Se presente toolspec dedicato lo usa per tool-calling
    - Altrimenti usa _MiniToolInvoker
    - Invoca LLM solo quando utile davvero
    """

    def __init__(self, *args, llm_adapter: Optional[LLMAdapter] = None, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.llm: LLMAdapter = llm_adapter or LLMAdapter()

        self.toolsource: Optional[Any] = None
        self.toolschema_fn: Optional[Callable[[], List[Dict[str, Any]]]] = None
        self.toolinvoker: Optional[Any] = None

        self._bootstrap_tools()

    def _bootstrap_tools(self) -> None:
        for modname in ("content.nlp.toolspec", "content.tools.toolspec", "toolspec"):
            try:
                mod = importlib.import_module(modname)
                self.toolsource = mod

                if hasattr(mod, "get_openai_tools"):
                    self.toolschema_fn = getattr(mod, "get_openai_tools")

                elif hasattr(mod, "ToolInvoker") and hasattr(mod.ToolInvoker, "get_openai_tools"):
                    self.toolschema_fn = lambda mod=mod: mod.ToolInvoker().get_openai_tools()  # type: ignore[attr-defined]

                if hasattr(mod, "ToolInvoker"):
                    self.toolinvoker = mod.ToolInvoker()  # type: ignore[attr-defined]

                elif hasattr(mod, "invoke"):

                    class _Invoker:
                        def invoke(self, name: str, args: Dict[str, Any]) -> Any:
                            return mod.invoke(name, args)  # type: ignore[misc]

                    self.toolinvoker = _Invoker()

                break
            except Exception:
                continue

        if self.toolinvoker is None:
            self.toolinvoker = _MiniToolInvoker()

        if self.toolschema_fn is None:
            self.toolschema_fn = self.toolinvoker.get_openai_tools  # type: ignore[assignment]

    # -------------------------
    # Entry point
    # -------------------------
    def handle(self, text: str, context: Dict[str, Any]) -> Answer:
        """
        1) Usa il router base per ottenere una risposta deterministica.
        2) Se l'utente chiede consigli, spiegazioni o approfondimenti strategici,
           arricchisce con un parere consulenziale via LLM + tool-calling.
        """
        ans = super().handle(text, context)

        t = _safe_text(text).lower()
        base_intent = _safe_text(getattr(ans, "intent", ""))
        base_narrative = _safe_text(getattr(ans, "narrative", ""))

        if not self._should_use_llm(text=t, base_intent=base_intent, base_narrative=base_narrative):
            return ans

        facts = self._build_facts_snapshot(ans=ans, context=context)
        user_prompt = self._build_user_prompt(
            text=text,
            facts=facts,
            base_answer=base_narrative,
            intent=base_intent,
        )

        try:
            tools_schema = list(self.toolschema_fn()) if callable(self.toolschema_fn) else []

            res = self.llm.complete(
                system=self._build_system_prompt(base_intent, self._wants_strategy(t)),
                user=user_prompt,
                tools=tools_schema,
                tool_invoker=self.toolinvoker,
                temperature=0.2,
                max_tokens=500,
            )

            extra = _safe_text(getattr(res, "text", ""))

            if extra and self._should_merge_llm_text(
                base_text=base_narrative,
                llm_text=extra,
                intent=base_intent,
            ):
                ans.narrative = self._merge_narratives(
                    base_text=base_narrative,
                    llm_text=extra,
                    intent=base_intent,
                )

            self._inject_llm_meta(ans, res)

        except Exception:
            return ans

        return ans

    __call__ = handle

    # -------------------------
    # Decision logic
    # -------------------------
    def _wants_advice(self, text: str) -> bool:
        return any(
            x in text
            for x in (
                "consiglio",
                "consigli",
                "cosa dovrei",
                "cosa devo fare",
                "come posso",
                "spiega",
                "perché",
                "perche",
                "approfondisci",
                "dimmi meglio",
                "analizza meglio",
                "spiegami meglio",
                "dammi priorità",
                "dammi priorita",
                "che faresti",
            )
        )

    def _wants_strategy(self, text: str) -> bool:
        return any(
            x in text
            for x in (
                "strategia",
                "strategico",
                "come crescere",
                "come scalare",
                "posizionamento",
                "pricing",
                "priorità",
                "priorita",
                "collo di bottiglia",
                "bottleneck",
                "leva prioritaria",
                "business model",
                "go to market",
                "gtm",
            )
        )

    def _wants_followup(self, text: str) -> bool:
        return any(
            x in text
            for x in (
                "ok ma",
                "sì ma",
                "si ma",
                "e quindi",
                "quindi",
                "allora",
                "in pratica",
                "quindi cosa",
                "cosa intendi",
            )
        )

    def _is_low_signal_error(self, base_intent: str, base_narrative: str) -> bool:
        return base_intent in {"error", "unknown", "missing_data"} and len(base_narrative) < 160

    def _should_use_llm(self, text: str, base_intent: str, base_narrative: str) -> bool:
        wants_advice = self._wants_advice(text)
        wants_strategy = self._wants_strategy(text)
        wants_followup = self._wants_followup(text)
        too_short = (not base_narrative) or (len(base_narrative) < 24)
        low_signal_error = self._is_low_signal_error(base_intent, base_narrative)

        return wants_advice or wants_strategy or wants_followup or too_short or low_signal_error

    # -------------------------
    # Helpers
    # -------------------------
    def _build_facts_snapshot(self, ans: Answer, context: Dict[str, Any]) -> Dict[str, float]:
        facts: Dict[str, float] = {}
        ctx = context or {}

        for k in (
            "fatturato",
            "costi_variabili",
            "costi_fissi",
            "investimenti",
            "ammortamenti",
            "margine_contribuzione",
            "ebitda",
            "utile",
            "roi",
            "dso",
            "dio",
            "dpo",
            "prezzo_medio",
            "costo_variabile_unitario",
            "ltv",
            "cac",
            "churn_rate",
            "nrr",
            "mrr",
            "arpu",
            "leads",
            "conversion_rate",
            "avg_ticket",
            "ticket_medio",
        ):
            v = ctx.get(k)
            if isinstance(v, (int, float)):
                facts[k] = float(v)

        if getattr(ans, "value", None) is not None:
            try:
                facts["value"] = float(ans.value)  # type: ignore[attr-defined]
            except Exception:
                pass

        return facts

    def _build_system_prompt(self, intent: str, wants_strategy: bool) -> str:
        if intent == "strategic_analysis" or wants_strategy:
            return (
                DEFAULT_SYSTEM
                + " Rispondi come advisor strategico e CFO. "
                + "Sii concreto, diretto, orientato a priorità e decisioni. "
                + "Non ripetere i numeri inutilmente. "
                + "Produci massimo 3 blocchi: diagnosi, priorità, azione."
            )

        return (
            DEFAULT_SYSTEM
            + " Rispondi con massimo 3 bullet brevi, concreti e ordinati per impatto. "
            + "Evita teoria generica. Usa i numeri quando utili. "
            + "Non contraddire la risposta deterministica di base."
        )

    def _build_user_prompt(
        self,
        *,
        text: str,
        facts: Dict[str, float],
        base_answer: str,
        intent: str,
    ) -> str:
        facts_line = ", ".join(f"{k} {fmt_number_eu(v, 0)}" for k, v in facts.items()) if facts else "nessun dato numerico esplicito"

        if intent == "strategic_analysis":
            return (
                "Hai già una diagnosi strategica di base.\n"
                "Il tuo compito è rafforzarla senza contraddirla.\n"
                "Devi:\n"
                "1. chiarire il vero problema principale,\n"
                "2. indicare la leva prioritaria,\n"
                "3. proporre 3 azioni esecutive concrete.\n\n"
                f"Numeri disponibili: {facts_line}\n\n"
                f"Diagnosi base:\n{base_answer}\n\n"
                f"Richiesta utente:\n{text}"
            )

        return (
            "Hai già una risposta deterministica di base.\n"
            "Il tuo compito è arricchirla con consigli pratici senza contraddirla.\n"
            "Fornisci indicazioni concrete, brevi e orientate all'azione.\n\n"
            f"Numeri disponibili: {facts_line}\n\n"
            f"Risposta base:\n{base_answer}\n\n"
            f"Domanda utente:\n{text}"
        )

    def _should_merge_llm_text(self, base_text: str, llm_text: str, intent: str) -> bool:
        base_clean = _safe_text(base_text).lower()
        llm_clean = _safe_text(llm_text).lower()

        if not llm_clean:
            return False

        if llm_clean == base_clean:
            return False

        if llm_clean in base_clean:
            return False

        if len(llm_clean) < 20 and len(base_clean) > 40:
            return False

        if intent in {"error", "missing_data"} and len(llm_clean) < 40:
            return False

        return True

    def _merge_narratives(self, base_text: str, llm_text: str, intent: str) -> str:
        base_clean = _safe_text(base_text)
        llm_clean = _safe_text(llm_text)

        if not base_clean:
            return llm_clean
        if not llm_clean:
            return base_clean
        if llm_clean in base_clean:
            return base_clean

        if intent == "strategic_analysis":
            return (
                base_clean.rstrip()
                + "\n\n"
                + "Executive advisory:\n"
                + llm_clean
            ).strip()

        return (base_clean.rstrip() + "\n\n" + llm_clean).strip()

    def _inject_llm_meta(self, ans: Answer, res: Any) -> None:
        try:
            if getattr(ans, "meta", None) is None:
                ans.meta = {}
            if not isinstance(ans.meta, dict):
                ans.meta = {}

            usage = getattr(res, "usage", None)
            ans.meta["llm_usage"] = {
                "model": getattr(usage, "model", None) if usage is not None else None,
                "tokens": getattr(usage, "total_tokens", None) if usage is not None else None,
                "cost_usd": getattr(usage, "cost_usd", None) if usage is not None else None,
            }
            ans.meta["llm_augmented"] = True
        except Exception:
            pass