# -*- coding: utf-8 -*-
# content/nlp/router/question_map.py

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple


# =========================================================
# Mappa domande → intent
# =========================================================
# Struttura:
# - macro_intent: categoria principale
# - sub_intent: dettaglio operativo
# - patterns: frasi / keyword tipiche
#
# Nota:
# questo file NON deve fare NLP avanzato.
# Deve essere un layer semplice, leggibile e facilmente espandibile.
# =========================================================

QUESTION_MAP: Dict[str, Dict[str, Any]] = {
    "kpi_roi": {
        "macro_intent": "kpi",
        "sub_intent": "roi",
        "patterns": [
            "qual è il roi",
            "quanto è il roi",
            "quanto rende l'investimento",
            "ritorno sull'investimento",
            "sto avendo ritorno",
            "quanto mi rende",
            "quanto rende il capitale",
            "roi attuale",
        ],
    },
    "kpi_utile": {
        "macro_intent": "kpi",
        "sub_intent": "utile",
        "patterns": [
            "qual è l'utile",
            "quanto sto guadagnando",
            "profitto attuale",
            "utile attuale",
            "quanto mi resta",
            "quanto sto tenendo",
            "quanto profitto faccio",
        ],
    },
    "kpi_ebitda": {
        "macro_intent": "kpi",
        "sub_intent": "ebitda",
        "patterns": [
            "qual è l'ebitda",
            "ebitda attuale",
            "quanto è l'ebitda",
            "margine operativo lordo",
        ],
    },
    "kpi_fatturato": {
        "macro_intent": "kpi",
        "sub_intent": "fatturato",
        "patterns": [
            "qual è il fatturato",
            "quanto fatturo",
            "ricavi attuali",
            "quanto sto incassando",
            "quanto vendo",
            "fatturato attuale",
        ],
    },
    "kpi_margine": {
        "macro_intent": "kpi",
        "sub_intent": "margine",
        "patterns": [
            "qual è il margine",
            "margine attuale",
            "marginalità",
            "margine di contribuzione",
            "mc rate",
            "quanto margine ho",
            "sto marginando bene",
        ],
    },
    "kpi_break_even": {
        "macro_intent": "kpi",
        "sub_intent": "break_even",
        "patterns": [
            "break even",
            "punto di pareggio",
            "quando vado in pareggio",
            "quanto manca al pareggio",
            "bep",
        ],
    },
    "kpi_cashflow": {
        "macro_intent": "kpi",
        "sub_intent": "cashflow",
        "patterns": [
            "cash flow",
            "ciclo di cassa",
            "working capital",
            "ccc",
            "come sono messo con la cassa",
            "quanta cassa sto assorbendo",
            "problemi di liquidità",
        ],
    },

    "strategy_growth": {
        "macro_intent": "strategy",
        "sub_intent": "growth",
        "patterns": [
            "come cresco",
            "come scalare",
            "come aumento il fatturato",
            "come cresco di più",
            "come posso crescere",
            "come faccio a fare più soldi",
            "come espandermi",
        ],
    },
    "strategy_profit": {
        "macro_intent": "strategy",
        "sub_intent": "profit",
        "patterns": [
            "come aumento l'utile",
            "come aumentare utile",
            "come faccio più profitto",
            "come aumento il profitto",
            "come migliorare la redditività",
            "come guadagnare di più",
        ],
    },
    "strategy_attack": {
        "macro_intent": "strategy",
        "sub_intent": "attack",
        "patterns": [
            "dove attaccare il business",
            "quale leva useresti",
            "cosa devo fare",
            "cosa dovrei fare",
            "qual è la priorità",
            "dove stiamo perdendo soldi",
            "come attaccheresti questo business",
            "che mossa faresti",
            "da dove parto",
        ],
    },
    "strategy_bottleneck": {
        "macro_intent": "strategy",
        "sub_intent": "bottleneck",
        "patterns": [
            "collo di bottiglia",
            "bottleneck",
            "qual è il problema principale",
            "dov'è il problema",
            "dove sto sbagliando",
            "dove perdo soldi",
            "qual è la criticità",
        ],
    },
    "strategy_pricing": {
        "macro_intent": "strategy",
        "sub_intent": "pricing",
        "patterns": [
            "come alzare i prezzi",
            "posso aumentare i prezzi",
            "mi conviene alzare i prezzi",
            "pricing",
            "strategia di prezzo",
            "come riprezzare",
        ],
    },

    "scenario_pricing": {
        "macro_intent": "scenario",
        "sub_intent": "pricing",
        "patterns": [
            "se aumento i prezzi",
            "se alzo il prezzo",
            "se aumento del 10%",
            "cosa succede se aumento il prezzo",
            "simula aumento prezzi",
            "simula prezzo",
        ],
    },
    "scenario_costs": {
        "macro_intent": "scenario",
        "sub_intent": "costs",
        "patterns": [
            "se riduco i costi",
            "se taglio i costi",
            "cosa succede se riduco i costi",
            "simula riduzione costi",
            "simula costi fissi",
            "simula costi variabili",
        ],
    },
    "scenario_investment": {
        "macro_intent": "scenario",
        "sub_intent": "investment",
        "patterns": [
            "se investo",
            "cosa succede se investo",
            "se aumento l'investimento",
            "simula investimento",
            "simula capex",
        ],
    },
    "scenario_multi": {
        "macro_intent": "scenario",
        "sub_intent": "multi",
        "patterns": [
            "fammi una simulazione",
            "simula scenario",
            "simula più scenari",
            "scenario multiplo",
            "matrice scenari",
            "griglia scenari",
        ],
    },

    "valuation_company": {
        "macro_intent": "valuation",
        "sub_intent": "company",
        "patterns": [
            "quanto vale l'azienda",
            "valuation",
            "valutazione azienda",
            "enterprise value",
            "equity value",
            "quanto vale il business",
            "dcf",
        ],
    },
    "valuation_project": {
        "macro_intent": "valuation",
        "sub_intent": "project",
        "patterns": [
            "npv",
            "irr",
            "payback",
            "questo investimento conviene",
            "valuta progetto",
            "ritorno progetto",
        ],
    },

    "forecast_revenue": {
        "macro_intent": "forecast",
        "sub_intent": "revenue",
        "patterns": [
            "previsione fatturato",
            "forecast ricavi",
            "prevedi i ricavi",
            "quanto fatturerò",
            "proiezione fatturato",
        ],
    },
    "forecast_business": {
        "macro_intent": "forecast",
        "sub_intent": "business",
        "patterns": [
            "forecast",
            "previsione",
            "prevedi andamento",
            "proiezione business",
            "cosa succede nei prossimi mesi",
        ],
    },

    "opportunities": {
        "macro_intent": "opportunities",
        "sub_intent": "opportunities",
        "patterns": [
            "opportunità",
            "dove posso migliorare",
            "leve di miglioramento",
            "dove posso fare più utile",
            "quali opportunità vedi",
            "opportunities",
        ],
    },

    "sector_attack": {
        "macro_intent": "sector",
        "sub_intent": "sector_attack",
        "patterns": [
            "come attaccheresti un dentista",
            "come attaccheresti un ristorante",
            "come attaccheresti un ecommerce",
            "come attaccheresti un business di servizi",
            "analisi per settore",
            "strategia per settore",
        ],
    },

    "followup_deepen": {
        "macro_intent": "followup",
        "sub_intent": "deepen",
        "patterns": [
            "approfondisci",
            "spiegami meglio",
            "entra più nel dettaglio",
            "vai più a fondo",
            "dimmi meglio",
        ],
    },
    "followup_plan": {
        "macro_intent": "followup",
        "sub_intent": "plan",
        "patterns": [
            "fammi un piano",
            "fammi un piano operativo",
            "dammi i passi",
            "cosa faccio adesso",
            "da dove parto",
            "dimmi i prossimi step",
        ],
    },
    "followup_priority": {
        "macro_intent": "followup",
        "sub_intent": "priority",
        "patterns": [
            "qual è la priorità",
            "cosa faccio prima",
            "la prima mossa",
            "qual è la leva principale",
            "da cosa comincio",
        ],
    },
}


# =========================================================
# Helpers base
# =========================================================
def _normalize_text(text: str) -> str:
    return " ".join(str(text or "").lower().strip().split())


def _contains_pattern(text: str, pattern: str) -> bool:
    return _normalize_text(pattern) in _normalize_text(text)


def _score_match(text: str, patterns: List[str]) -> int:
    t = _normalize_text(text)
    score = 0

    for p in patterns:
        pp = _normalize_text(p)
        if not pp:
            continue

        if pp == t:
            score += 100
        elif pp in t:
            score += 10

            # premio se il pattern è abbastanza specifico
            if len(pp.split()) >= 3:
                score += 5

    return score


# =========================================================
# Risoluzione domanda
# =========================================================
def resolve_question_map(text: str) -> Dict[str, Any]:
    """
    Restituisce:
    {
        "matched": bool,
        "key": "...",
        "macro_intent": "...",
        "sub_intent": "...",
        "score": 0,
    }
    """
    best_key: Optional[str] = None
    best_score = 0
    best_payload: Dict[str, Any] = {}

    for key, config in QUESTION_MAP.items():
        patterns = config.get("patterns", []) or []
        score = _score_match(text, patterns)

        if score > best_score:
            best_score = score
            best_key = key
            best_payload = {
                "matched": True,
                "key": key,
                "macro_intent": config.get("macro_intent", ""),
                "sub_intent": config.get("sub_intent", ""),
                "score": score,
            }

    if best_key is None or best_score <= 0:
        return {
            "matched": False,
            "key": None,
            "macro_intent": None,
            "sub_intent": None,
            "score": 0,
        }

    return best_payload


# =========================================================
# Mappa macro-intent → intent router/reasoning
# =========================================================
MACRO_TO_ROUTER_INTENT: Dict[str, str] = {
    "kpi": "executive_summary",
    "strategy": "strategic_analysis",
    "scenario": "simulate",
    "valuation": "valuation",
    "forecast": "forecast",
    "opportunities": "opportunities",
    "sector": "strategic_analysis",
    "followup": "strategic_analysis",
}


SUBINTENT_TO_ROUTER_INTENT: Dict[str, str] = {
    "roi": "roi",
    "utile": "utile",
    "ebitda": "ebitda",
    "fatturato": "fatturato",
    "margine": "margine",
    "break_even": "break_even",
    "cashflow": "cashflow",
    "growth": "strategic_analysis",
    "profit": "strategic_analysis",
    "attack": "strategic_analysis",
    "bottleneck": "strategic_analysis",
    "pricing": "price_opt",
    "company": "valuation",
    "project": "valuation",
    "revenue": "forecast",
    "business": "forecast",
    "opportunities": "opportunities",
    "sector_attack": "strategic_analysis",
    "deepen": "strategic_analysis",
    "plan": "strategic_analysis",
    "priority": "strategic_analysis",
    "costs": "simulate",
    "investment": "simulate",
    "multi": "simulate_matrix",
}


def map_question_to_router_intent(text: str) -> Dict[str, Any]:
    """
    Output:
    {
        "matched": True/False,
        "router_intent": "...",
        "macro_intent": "...",
        "sub_intent": "...",
        "key": "...",
        "score": 0,
    }
    """
    resolved = resolve_question_map(text)

    if not resolved.get("matched"):
        return {
            "matched": False,
            "router_intent": None,
            "macro_intent": None,
            "sub_intent": None,
            "key": None,
            "score": 0,
        }

    sub_intent = resolved.get("sub_intent")
    macro_intent = resolved.get("macro_intent")

    router_intent = (
        SUBINTENT_TO_ROUTER_INTENT.get(str(sub_intent or ""))
        or MACRO_TO_ROUTER_INTENT.get(str(macro_intent or ""))
        or "executive_summary"
    )

    return {
        "matched": True,
        "router_intent": router_intent,
        "macro_intent": macro_intent,
        "sub_intent": sub_intent,
        "key": resolved.get("key"),
        "score": resolved.get("score", 0),
    }


# =========================================================
# Utility per debugging / estensioni future
# =========================================================
def get_patterns_for_intent(key: str) -> List[str]:
    cfg = QUESTION_MAP.get(key, {})
    patterns = cfg.get("patterns", [])
    return patterns if isinstance(patterns, list) else []


def list_all_question_keys() -> List[str]:
    return list(QUESTION_MAP.keys())