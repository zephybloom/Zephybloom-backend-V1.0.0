# -*- coding: utf-8 -*-
# content/nlp/router_handlers.py

from __future__ import annotations

from typing import Any, Dict, List, Optional, Callable

from core.finance import dcf_equity, project_eval, wacc
from core.forecast import forecast_series
from core.scenario import simulate, simulate_matrix
from core.schemas import Answer
from utils.fmt_parse import fmt_number_eu


def diff_line(label: str, a: float, b: float) -> str:
    delta = b - a
    sdelta = ("+" if delta >= 0 else "") + fmt_number_eu(delta, decimals=0)
    return f"{label}: {fmt_number_eu(a, 0)} → {fmt_number_eu(b, 0)} ({sdelta})"


def best_matrix_row(rows: List[Dict[str, Any]], target: str = "utile") -> Optional[Dict[str, Any]]:
    if not rows:
        return None
    try:
        return max(rows, key=lambda r: float(r.get(target, 0.0) or 0.0))
    except Exception:
        return rows[0]


def handle_simulate(
    *,
    data: Dict[str, float],
    tenant_id: str,
    record_interaction_fn: Optional[Callable[..., Any]] = None,
    memory: Any = None,
) -> Answer:
    delta_keys = [
        "fatturato_pct",
        "costi_variabili_pct",
        "costi_fissi_pct",
        "price_pct",
        "prezzo_pct",
        "price_elasticity",
        "qty_pct",
        "fatturato_abs",
        "costi_variabili_abs",
        "costi_fissi_abs",
        "investimenti_abs",
    ]
    delta = {k: data.get(k, 0.0) for k in delta_keys if k in data}

    base = {
        k: data.get(k, 0.0)
        for k in [
            "fatturato",
            "costi_variabili",
            "costi_fissi",
            "investimenti",
            "prezzo_medio",
            "costo_variabile_unitario",
            "cogs",
            "ammortamenti",
            "dso",
            "dio",
            "dpo",
        ]
    }

    try:
        after = simulate(base, delta)
    except Exception:
        after = {}

    narrative = " | ".join(
        [
            diff_line("Ricavi", base["fatturato"], after.get("fatturato", base["fatturato"])),
            diff_line(
                "MC",
                base["fatturato"] - base["costi_variabili"],
                after.get("margine_contribuzione", base["fatturato"] - base["costi_variabili"]),
            ),
            diff_line(
                "Utile",
                base["fatturato"] - base["costi_variabili"] - base["costi_fissi"],
                after.get("utile", base["fatturato"] - base["costi_variabili"] - base["costi_fissi"]),
            ),
        ]
    )

    try:
        if record_interaction_fn is not None:
            record_interaction_fn(memory, tenant_id, "simulate", {"delta": delta, "base": base})
    except Exception:
        pass

    return Answer(intent="simulate", narrative=narrative, advisories=[])


def handle_simulate_matrix(*, data: Dict[str, Any]) -> Answer:
    grid = data.get("grid")
    if not isinstance(grid, dict) or not grid:
        return Answer(
            intent="simulate_matrix",
            narrative="Fornisci 'grid' con le leve da variare (es. prezzo_pct, costi_fissi_delta).",
            advisories=[],
        )

    base = {
        k: data.get(k, 0.0)
        for k in [
            "fatturato",
            "costi_variabili",
            "costi_fissi",
            "investimenti",
            "prezzo_medio",
            "costo_variabile_unitario",
            "cogs",
            "ammortamenti",
            "dso",
            "dio",
            "dpo",
            "price_elasticity",
        ]
    }

    try:
        rows = simulate_matrix(base, grid)
    except Exception:
        rows = []

    if not rows:
        return Answer(
            intent="simulate_matrix",
            narrative="Nessuno scenario generato con la griglia fornita.",
            advisories=[],
        )

    top = best_matrix_row(rows, target=str(data.get("matrix_target", "utile") or "utile")) or rows[0]
    target_metric = str(data.get("matrix_target", "utile") or "utile")

    msg = (
        f"Miglior scenario per {target_metric}: "
        f"utile={fmt_number_eu(top.get('utile', 0.0), 0)}, "
        f"ricavi={fmt_number_eu(top.get('fatturato', 0.0), 0)}, "
        f"ebitda={fmt_number_eu(top.get('ebitda', 0.0), 0)}."
    )
    return Answer(intent="simulate_matrix", narrative=msg, advisories=[])


def handle_forecast(*, data: Dict[str, Any]) -> Answer:
    periods = int(data.get("periods", 6) or 6)
    periods = max(1, min(36, periods))
    method = str(data.get("method") or data.get("forecast_method") or "auto")
    hist = data.get("history", [])

    if not isinstance(hist, list) or not hist:
        base = float(data.get("fatturato", 0.0) or 0.0)
        forecast = [base] * periods
    else:
        try:
            forecast = forecast_series([float(x) for x in hist], periods=periods, method=method)
        except Exception:
            base = float(data.get("fatturato", 0.0) or 0.0)
            forecast = [base] * periods

    s = ", ".join([fmt_number_eu(v, 0) for v in forecast])
    return Answer(
        intent="forecast",
        narrative=f"Previsione prossimi {periods} periodi ({method}): {s}",
        advisories=[],
    )


def handle_valuation(
    *,
    data: Dict[str, Any],
    tenant_id: str,
    record_interaction_fn: Optional[Callable[..., Any]] = None,
    memory: Any = None,
) -> Answer:
    nar_parts: List[str] = []

    cf = data.get("cashflows")
    dr = data.get("discount_rate_pct")

    if isinstance(cf, list) and len(cf) >= 2:
        if not dr:
            nar_parts.append("Per NPV/IRR specifica 'discount_rate_pct'.")
        else:
            try:
                pe = project_eval(cf, dr)
                irr_show = float(pe.get("irr", 0.0))
                if irr_show > 40.0:
                    irr_show = 40.0
                payback = int(pe["payback_period"]) if pe.get("payback_period", -1) >= 0 else -1
                nar_parts.append(
                    f"NPV {fmt_number_eu(pe.get('npv', 0.0), 0)}, "
                    f"IRR {fmt_number_eu(irr_show, 2)}%, "
                    f"Payback {payback} anni."
                )
            except Exception:
                nar_parts.append("Errore nel calcolo NPV/IRR.")

    dcf = data.get("dcf_fcf")
    if isinstance(dcf, list) and len(dcf) >= 2:
        rate = dr
        if not rate:
            have_wacc = all(k in data for k in ("ke", "kd", "equity", "debt", "tax_rate"))
            rate = (
                wacc(data["ke"], data["kd"], data["equity"], data["debt"], data["tax_rate"])
                if have_wacc
                else 10.0
            )

        try:
            out = dcf_equity(
                dcf,
                rate,
                data.get("terminal_growth_pct", 2.0),
                data.get("net_debt", 0.0),
            )
            nar_parts.append(
                f"DCF: EV≈{fmt_number_eu(out.get('enterprise_value', 0.0), 0)}, "
                f"Equity≈{fmt_number_eu(out.get('equity_value', 0.0), 0)} "
                f"(WACC {fmt_number_eu(rate, 2)}%)."
            )
        except Exception:
            nar_parts.append("Errore nel calcolo DCF.")

    if not nar_parts:
        nar_parts.append(
            "Fornisci cashflows [CF0..] e discount_rate_pct per NPV/IRR; "
            "oppure dcf_fcf + parametri per stimare il DCF."
        )

    out_ans = Answer(intent="valuation", narrative=" | ".join(nar_parts), advisories=[])

    try:
        if record_interaction_fn is not None:
            record_interaction_fn(
                memory,
                tenant_id,
                "valuation",
                {
                    "cashflows": cf if isinstance(cf, list) else None,
                    "dcf_fcf": dcf if isinstance(dcf, list) else None,
                },
            )
    except Exception:
        pass

    return out_ans


def handle_price_opt(
    *,
    data: Dict[str, float],
    tenant_id: str,
    record_interaction_fn: Optional[Callable[..., Any]] = None,
    memory: Any = None,
) -> Answer:
    p0 = float(data.get("prezzo_medio", 0.0) or 0.0)
    cvu = float(data.get("costo_variabile_unitario", 0.0) or 0.0)
    fatt = float(data.get("fatturato", 0.0) or 0.0)
    cf = float(data.get("costi_fissi", 0.0) or 0.0)
    el = float(data.get("price_elasticity", -1.2) or -1.2)

    if p0 <= 0 or fatt <= 0:
        return Answer(
            intent="price_opt",
            narrative="Per ottimizzare il prezzo servono prezzo_medio>0 e fatturato>0 (oltre a costi e elasticità).",
            advisories=[],
        )

    q0 = fatt / p0

    def profit(pct: float) -> float:
        p = p0 * (1.0 + pct / 100.0)
        q = q0 * (1.0 + el * (pct / 100.0))
        if q < 0:
            q = 0.0
        return q * (p - cvu) - cf

    grid = [x / 10.0 for x in range(-200, 201)]
    best = max(grid, key=profit)
    best_price = p0 * (1.0 + best / 100.0)
    best_profit = profit(best)

    msg = (
        f"Prezzo ottimale ≈ {fmt_number_eu(best, 1)}% → {fmt_number_eu(best_price, 2)}; "
        f"utile stimato ≈ {fmt_number_eu(best_profit, 0)}."
    )

    out_ans = Answer(intent="price_opt", narrative=msg, advisories=[])

    try:
        if record_interaction_fn is not None:
            record_interaction_fn(
                memory,
                tenant_id,
                "price_opt",
                {
                    "prezzo_medio": p0,
                    "cvu": cvu,
                    "fatturato": fatt,
                    "costi_fissi": cf,
                    "elasticity": el,
                    "best_pct": best,
                    "best_price": best_price,
                    "best_profit": best_profit,
                },
            )
    except Exception:
        pass

    return out_ans


def handle_opportunities(
    *,
    data: Dict[str, Any],
    tenant_id: str,
    record_interaction_fn: Optional[Callable[..., Any]] = None,
    memory: Any = None,
) -> Answer:
    from advice.opportunities import OpportunityEngine, format_opportunity  # type: ignore

    base = {
        k: data.get(k, 0.0)
        for k in [
            "fatturato",
            "costi_variabili",
            "costi_fissi",
            "investimenti",
            "prezzo_medio",
            "costo_variabile_unitario",
            "cogs",
            "ammortamenti",
            "dso",
            "dio",
            "dpo",
            "sector",
            "price_elasticity",
        ]
    }

    try:
        engine = OpportunityEngine(sector=str(data.get("sector", "default")))
        opps = engine.generate(base, elasticity=float(data.get("price_elasticity", -1.2)))
        lines = [format_opportunity(o) for o in opps[:5]]
    except Exception:
        lines = ["Nessuna opportunità disponibile sui dati attuali."]

    out_ans = Answer(intent="opportunities", narrative=" | ".join(lines), advisories=[])

    try:
        if record_interaction_fn is not None:
            record_interaction_fn(memory, tenant_id, "opportunities", {"count": len(lines)})
    except Exception:
        pass

    return out_ans