# -*- coding: utf-8 -*-
# content/nlp/context_builder.py
from __future__ import annotations

from typing import Any, Dict, List, Optional


class ContextBuilder:
    """
    Costruisce il context normalizzato per il router:
    - merge tra sessione, facts, context esterno e slot NLP
    - normalizzazione numerica
    - preservazione di strutture utili come history, cashflows, grid
    """

    NUMERIC_KEYS = (
        "fatturato",
        "costi_variabili",
        "costi_fissi",
        "investimenti",
        "prezzo_medio",
        "costo_variabile_unitario",
        "cogs",
        "ammortamenti",
        "dso",
        "dio",
        "dpo",
        "fatturato_pct",
        "costi_variabili_pct",
        "costi_fissi_pct",
        "price_pct",
        "prezzo_pct",
        "price_elasticity",
        "qty_pct",
        "fatturato_abs",
        "costi_variabili_abs",
        "costi_fissi_abs",
        "investimenti_abs",
        "discount_rate_pct",
        "terminal_growth_pct",
        "net_debt",
        "ke",
        "kd",
        "equity",
        "debt",
        "tax_rate",
        "periods",
        "matrix_target_value",
        "sensitivity_steps",
    )

    @staticmethod
    def _safe_float(x: Any, default: float = 0.0) -> float:
        try:
            return float(x)
        except Exception:
            return default

    @staticmethod
    def _as_float_list(value: Any) -> Optional[List[float]]:
        if not isinstance(value, list):
            return None

        out: List[float] = []
        for item in value:
            try:
                out.append(float(item))
            except Exception:
                continue

        return out if out else None

    @staticmethod
    def _as_grid(value: Any) -> Optional[Dict[str, List[float]]]:
        if not isinstance(value, dict):
            return None

        grid: Dict[str, List[float]] = {}
        for k, v in value.items():
            if not isinstance(v, list):
                continue

            arr: List[float] = []
            for x in v:
                try:
                    arr.append(float(x))
                except Exception:
                    continue

            if arr:
                grid[str(k)] = arr

        return grid if grid else None

    @staticmethod
    def _merge_raw(
        *,
        text: str,
        context: Dict[str, Any],
        session_last_kpi: Optional[Dict[str, Any]],
        session_facts: Optional[Dict[str, str]],
        extract_slots_fn,
    ) -> Dict[str, Any]:
        slots = extract_slots_fn(text or "") if callable(extract_slots_fn) else {}

        merged_raw: Dict[str, Any] = {
            **(session_last_kpi or {}),
            **(session_facts or {}),
            **(context or {}),
            **(slots or {}),
        }
        return merged_raw

    @classmethod
    def build(
        cls,
        *,
        text: str,
        context: Dict[str, Any],
        session_last_kpi: Optional[Dict[str, Any]],
        session_facts: Optional[Dict[str, str]],
        extract_slots_fn,
        normalize_context_numeric_fn,
    ) -> Dict[str, Any]:
        merged_raw = cls._merge_raw(
            text=text,
            context=context,
            session_last_kpi=session_last_kpi,
            session_facts=session_facts,
            extract_slots_fn=extract_slots_fn,
        )

        numeric_base = {
            k: v
            for k, v in merged_raw.items()
            if not isinstance(v, (list, dict))
        }

        if callable(normalize_context_numeric_fn):
            data = normalize_context_numeric_fn(numeric_base)
        else:
            data = dict(numeric_base)

        for k in cls.NUMERIC_KEYS:
            data[k] = cls._safe_float(data.get(k, 0.0), 0.0)

        history = cls._as_float_list(merged_raw.get("history"))
        if history is not None:
            data["history"] = history

        cashflows = cls._as_float_list(merged_raw.get("cashflows"))
        if cashflows is not None:
            data["cashflows"] = cashflows

        dcf_fcf = cls._as_float_list(merged_raw.get("dcf_fcf"))
        if dcf_fcf is not None:
            data["dcf_fcf"] = dcf_fcf

        grid = cls._as_grid(merged_raw.get("grid"))
        if grid is not None:
            data["grid"] = grid

        sensitivity_params = merged_raw.get("sensitivity_params")
        if isinstance(sensitivity_params, dict):
            data["sensitivity_params"] = sensitivity_params

        tornado_deltas = merged_raw.get("tornado_deltas")
        if isinstance(tornado_deltas, dict):
            data["tornado_deltas"] = tornado_deltas

        if isinstance(merged_raw.get("method"), str):
            data["method"] = str(merged_raw["method"])

        if isinstance(merged_raw.get("forecast_method"), str):
            data["forecast_method"] = str(merged_raw["forecast_method"])

        if isinstance(merged_raw.get("matrix_target"), str):
            data["matrix_target"] = str(merged_raw["matrix_target"])

        if isinstance(merged_raw.get("tornado_metric"), str):
            data["tornado_metric"] = str(merged_raw["tornado_metric"])

        if isinstance(merged_raw.get("sector"), str):
            data["sector"] = str(merged_raw["sector"])

        if isinstance(merged_raw.get("tenant_id"), (str, int)):
            data["tenant_id"] = str(merged_raw["tenant_id"])

        return data