# -*- coding: utf-8 -*-
# content/nlp/nlp_answer.py — Scaled, hardened, benchmark-aware & advisory-first
from __future__ import annotations

from functools import lru_cache
from typing import List, Dict, Any, Tuple, Optional

from core.schemas import KPI, Answer, Advisory
from utils.fmt_parse import fmt_eur, fmt_pct


# --- Benchmark (safe import) ---------------------------------------------------
try:
    from core.benchmarks import load_benchmarks, sector_gap_analysis  # type: ignore
except Exception:
    load_benchmarks = None  # type: ignore
    sector_gap_analysis = None  # type: ignore


# -----------------------------
# Helpers interni
# -----------------------------
def _nz(x: float | None, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except Exception:
        return default


def _safe_sector(sector: str | None) -> str:
    s = str(sector or "default").strip().lower()
    return s if s else "default"


def _sev_from_gap(delta_fraction: float) -> str:
    d = abs(float(delta_fraction or 0.0))
    if d >= 0.10:
        return "high"
    if d >= 0.05:
        return "medium"
    if d > 0:
        return "low"
    return "info"


def _zone_roi(roi_frac: float) -> str:
    r = _nz(roi_frac)
    if r < 0:
        return "negativo"
    if r < 0.08:
        return "debole"
    if r < 0.15:
        return "discreto"
    return "forte"


def _zone_margin(mc_rate: float) -> str:
    v = _nz(mc_rate)
    if v < 0.25:
        return "critico"
    if v < 0.40:
        return "sotto pressione"
    if v < 0.55:
        return "discreto"
    return "forte"


def _zone_ccc(ccc: float) -> str:
    x = _nz(ccc)
    if x <= 0:
        return "molto efficiente"
    if x <= 30:
        return "sano"
    if x <= 60:
        return "attenzione"
    return "teso"


def _zone_net_margin(v: float) -> str:
    x = _nz(v)
    if x < 0:
        return "negativo"
    if x < 0.05:
        return "debole"
    if x < 0.12:
        return "discreto"
    return "forte"


def _zone_ebitda(v: float) -> str:
    x = _nz(v)
    if x <= 0:
        return "critico"
    if x < 50000:
        return "fragile"
    return "positivo"


def _tips(intent: str, k: KPI, sector: str = "default") -> List[str]:
    sector = _safe_sector(sector)

    if intent == "roi":
        tips = [
            "Aumenta mix a maggior contribuzione",
            "Riduci investimenti a bassa resa",
            "Rialloca budget verso linee ad alto ritorno",
        ]
        if sector in {"saas", "software"}:
            tips[0] = "Spingi upsell e piani annuali a miglior ritorno"
        return tips

    if intent == "break_even":
        return [
            "Riduci costi fissi non strategici",
            "Aumenta scontrino medio o pricing",
            "Migliora saturazione capacità / utilizzo struttura",
        ]

    if intent == "margine":
        tips = [
            "Rinegozia acquisti e fornitori",
            "Riduci sprechi e inefficienze operative",
            "Aumenta prezzo dove l’elasticità lo consente",
        ]
        if sector in {"restaurant", "ristorazione", "hotel"}:
            tips[1] = "Riduci scarti, porzioni non controllate e inefficienze operative"
        return tips

    if intent == "cashflow":
        return [
            "Riduci DSO con reminder e incentivi al pagamento rapido",
            "Allunga DPO in modo sostenibile",
            "Ottimizza DIO con riordino e controllo stock",
        ]

    if intent == "utile":
        return [
            "Spingi linee/prodotti ad alta contribuzione",
            "Taglia costi indiretti non core",
            "Migliora pricing, mix e produttività",
        ]

    if intent == "ebitda":
        return [
            "Taglia OPEX non produttivi",
            "Automatizza processi ripetitivi",
            "Rialloca spesa su attività con resa più alta",
        ]

    return []


def _summary_signal_lines(k: KPI) -> List[str]:
    lines: List[str] = []

    utile = _nz(k.utile)
    roi = _nz(k.roi)
    mc_rate = _nz(k.mc_rate)
    ccc = _nz(k.ccc)
    nmr = _nz(k.net_margin_rate)

    if utile <= 0:
        lines.append("l’utile è in area critica")
    if mc_rate < 0.30:
        lines.append("la marginalità lorda è debole")
    if roi < 0.10:
        lines.append("il ritorno sul capitale è basso")
    if nmr < 0.05:
        lines.append("il margine netto è fragile")
    if ccc > 60:
        lines.append("la pressione sulla cassa è elevata")

    if not lines:
        lines.append("i numeri sono ordinati ma con margini concreti di ottimizzazione")

    return lines


def _build_metric_narrative(title: str, explanation: str, action_hint: Optional[str] = None) -> str:
    parts = [title]
    if explanation:
        parts.append(explanation)
    if action_hint:
        parts.append(action_hint)
    return " ".join([p for p in parts if p]).strip()


def _dedupe_advisories(items: List[Advisory]) -> List[Advisory]:
    out: List[Advisory] = []
    seen = set()

    for a in items or []:
        key = (str(getattr(a, "code", "")), str(getattr(a, "title", "")))
        if key in seen:
            continue
        seen.add(key)
        out.append(a)

    return out


def _merge_advisories(*groups: List[Advisory]) -> List[Advisory]:
    flat: List[Advisory] = []
    for g in groups:
        flat.extend(g or [])
    return _dedupe_advisories(flat)


@lru_cache(maxsize=8)
def _bench() -> Dict[str, Any]:
    if load_benchmarks is None:
        return {}
    try:
        return load_benchmarks() or {}
    except Exception:
        return {}


def _gap_advisories(sector: str, k: KPI) -> Tuple[List[Advisory], List[str]]:
    advs: List[Advisory] = []
    texts: List[str] = []

    if sector_gap_analysis is None:
        return advs, texts

    try:
        gaps = sector_gap_analysis(sector, k.model_dump(), _bench()) or {}
    except Exception:
        gaps = {}

    if isinstance(gaps.get("mc_rate"), (int, float)) and float(gaps["mc_rate"]) < 0:
        gap = abs(float(gaps["mc_rate"]))
        sev = _sev_from_gap(gap)
        msg = f"MC sotto benchmark di {fmt_pct(gap, assume_fraction=True)}."
        texts.append(msg)
        advs.append(
            Advisory(
                code="GAP_MC",
                title="Margine di contribuzione sotto benchmark",
                detail=msg,
                severity=sev,
                suggestions=[
                    "Rinegozia fornitori e costi variabili",
                    "Spingi mix a più alta contribuzione",
                    "Testa repricing selettivo",
                ],
                meta={"gap_mc": gap},
            )
        )

    if isinstance(gaps.get("net_margin_rate"), (int, float)) and float(gaps["net_margin_rate"]) < 0:
        gap = abs(float(gaps["net_margin_rate"]))
        sev = _sev_from_gap(gap)
        msg = f"Margine netto sotto benchmark di {fmt_pct(gap, assume_fraction=True)}."
        texts.append(msg)
        advs.append(
            Advisory(
                code="GAP_NM",
                title="Margine netto sotto benchmark",
                detail=msg,
                severity=sev,
                suggestions=[
                    "Riduci OPEX non strategici",
                    "Rivedi costi fissi e struttura",
                    "Migliora pricing e produttività",
                ],
                meta={"gap_nm": gap},
            )
        )

    if isinstance(gaps.get("roi"), (int, float)) and float(gaps["roi"]) < 0:
        gap = abs(float(gaps["roi"]))
        sev = _sev_from_gap(gap)
        msg = f"ROI sotto benchmark di {fmt_pct(gap, assume_fraction=True)}."
        texts.append(msg)
        advs.append(
            Advisory(
                code="GAP_ROI",
                title="ROI sotto benchmark",
                detail=msg,
                severity=sev,
                suggestions=[
                    "Riduci capitale allocato su attività a bassa resa",
                    "Concentra investimenti su leve a payback rapido",
                    "Aumenta margine prima di aumentare struttura",
                ],
                meta={"gap_roi": gap},
            )
        )

    return advs, texts


def _intrinsic_summary_advisories(k: KPI, sector: str = "default") -> List[Advisory]:
    out: List[Advisory] = []

    if _nz(k.utile) <= 0:
        out.append(
            Advisory(
                code="UTIL_NEG",
                title="Utile in area critica",
                detail="Il business non sta trattenendo abbastanza valore dopo aver coperto costi variabili e struttura.",
                severity="high",
                suggestions=[
                    "Alza marginalità lorda",
                    "Riduci struttura non produttiva",
                    "Difendi pricing e mix",
                ],
            )
        )

    if _nz(k.mc_rate) < 0.30:
        out.append(
            Advisory(
                code="MC_WEAK",
                title="Marginalità lorda debole",
                detail="Una parte troppo piccola del fatturato resta disponibile per coprire costi fissi e generare utile.",
                severity="high" if _nz(k.mc_rate) < 0.25 else "medium",
                suggestions=_tips("margine", k, sector),
            )
        )

    if _nz(k.roi) < 0.10:
        out.append(
            Advisory(
                code="ROI_WEAK",
                title="ROI sotto soglia operativa",
                detail="Il capitale impiegato rende poco rispetto all’effort e al rischio operativo.",
                severity="medium",
                suggestions=_tips("roi", k, sector),
            )
        )

    if _nz(k.ccc) > 60:
        out.append(
            Advisory(
                code="CCC_HIGH",
                title="Ciclo di cassa elevato",
                detail="Troppa cassa resta assorbita dall’operatività.",
                severity="high",
                suggestions=_tips("cashflow", k, sector),
            )
        )

    return out


def _base_advisories_for_kpi(intent: str, k: KPI, sector: str = "default") -> List[Advisory]:
    out: List[Advisory] = []

    if intent == "roi":
        out.append(
            Advisory(
                code="ROI",
                title="Rendimento del capitale",
                detail="Misura quanto utile stai generando rispetto agli investimenti fatti.",
                severity="info" if _nz(k.roi) >= 0.12 else "medium",
                suggestions=_tips("roi", k, sector),
            )
        )
        return out

    if intent == "break_even":
        out.append(
            Advisory(
                code="BEP",
                title="Punto di pareggio",
                detail="Indica il livello minimo di ricavi necessario per non perdere denaro.",
                severity="info",
                suggestions=_tips("break_even", k, sector),
            )
        )
        return out

    if intent == "margine":
        out.append(
            Advisory(
                code="MC",
                title="Margine di contribuzione",
                detail="Misura quanto valore resta dopo i costi variabili per coprire struttura e utile.",
                severity="high" if _nz(k.mc_rate) < 0.25 else ("medium" if _nz(k.mc_rate) < 0.40 else "info"),
                suggestions=_tips("margine", k, sector),
            )
        )
        return out

    if intent == "utile":
        out.append(
            Advisory(
                code="UTILE",
                title="Redditività finale",
                detail="L’utile sintetizza la capacità reale del business di trattenere valore.",
                severity="high" if _nz(k.utile) <= 0 else "info",
                suggestions=_tips("utile", k, sector),
            )
        )
        return out

    if intent == "ebitda":
        out.append(
            Advisory(
                code="EBITDA",
                title="Margine operativo lordo",
                detail="È una proxy della forza operativa prima della struttura finanziaria e delle componenti non cash.",
                severity="high" if _nz(k.ebitda) <= 0 else "info",
                suggestions=_tips("ebitda", k, sector),
            )
        )
        return out

    if intent == "cashflow":
        out.append(
            Advisory(
                code="CCC",
                title="Ciclo di cassa",
                detail="Misura per quanti giorni la cassa resta assorbita dall’operatività.",
                severity="high" if _nz(k.ccc) > 60 else ("medium" if _nz(k.ccc) > 30 else "info"),
                suggestions=_tips("cashflow", k, sector),
            )
        )
        return out

    return out


# -----------------------------
# Risposte per intent
# -----------------------------
def answer_metric(intent: str, k: KPI, sector: str = "default") -> Answer:
    intent = (intent or "").strip().lower()
    sector = _safe_sector(sector)

    gap_advs, _gap_texts = _gap_advisories(sector, k)

    if intent == "roi":
        roi_val = _nz(k.roi)
        narrative = _build_metric_narrative(
            title=f"ROI attuale: {fmt_pct(roi_val, assume_fraction=True)}.",
            explanation=f"Il ritorno sul capitale è {_zone_roi(roi_val)}.",
            action_hint="Priorità: aumentare utile per euro investito e tagliare capitale a bassa resa.",
        )
        return Answer(
            intent="roi",
            value=roi_val,
            value_str=fmt_pct(roi_val, assume_fraction=True),
            narrative=narrative,
            advisories=_merge_advisories(_base_advisories_for_kpi("roi", k, sector), gap_advs),
        )

    if intent in {"break_even", "bep", "break-even"}:
        be_val = _nz(k.break_even)
        be_qty = _nz(k.break_even_qty)
        extra = f" (~{int(max(0.0, be_qty))} pezzi)" if be_qty > 0 else ""
        narrative = _build_metric_narrative(
            title=f"Punto di pareggio: {fmt_eur(be_val)}{extra}.",
            explanation="Sotto questa soglia la struttura non si autosostiene; sopra inizi a generare utile.",
            action_hint="Leve principali: prezzo, costi variabili unitari e costi fissi.",
        )
        return Answer(
            intent="break_even",
            value=be_val,
            value_str=fmt_eur(be_val),
            narrative=narrative,
            advisories=_base_advisories_for_kpi("break_even", k, sector),
        )

    if intent in {"margine", "mc", "margine_contribuzione"}:
        mc = _nz(k.margine_contribuzione)
        mc_rate = _nz(k.mc_rate)
        narrative = _build_metric_narrative(
            title=f"Margine di contribuzione: {fmt_eur(mc)} ({fmt_pct(mc_rate, assume_fraction=True)}).",
            explanation=f"La marginalità è in area {_zone_margin(mc_rate)}.",
            action_hint="Qui si gioca la qualità economica del business: mix, pricing e costi variabili.",
        )
        return Answer(
            intent="margine",
            value=mc,
            value_str=fmt_eur(mc),
            narrative=narrative,
            advisories=_merge_advisories(_base_advisories_for_kpi("margine", k, sector), gap_advs),
        )

    if intent == "fatturato":
        fatt = _nz(k.fatturato)
        narrative = _build_metric_narrative(
            title=f"Fatturato: {fmt_eur(fatt)}.",
            explanation="Il ricavo da solo non basta: va letto insieme a margine, utile e cassa.",
            action_hint="La vera domanda non è solo quanto vendi, ma quanto trattieni.",
        )
        return Answer(
            intent="fatturato",
            value=fatt,
            value_str=fmt_eur(fatt),
            narrative=narrative,
        )

    if intent == "utile":
        utile = _nz(k.utile)
        nmr = _nz(k.net_margin_rate)
        narrative = _build_metric_narrative(
            title=f"Utile stimato: {fmt_eur(utile)} (Net margin {fmt_pct(nmr, assume_fraction=True)}).",
            explanation=f"La redditività finale è in area {_zone_net_margin(nmr)}.",
            action_hint="Se vuoi scalarlo, bisogna lavorare su margine, efficienza e disciplina dei costi fissi.",
        )
        return Answer(
            intent="utile",
            value=utile,
            value_str=fmt_eur(utile),
            narrative=narrative,
            advisories=_merge_advisories(_base_advisories_for_kpi("utile", k, sector), gap_advs),
        )

    if intent == "ebitda":
        ebitda = _nz(k.ebitda)
        narrative = _build_metric_narrative(
            title=f"EBITDA: {fmt_eur(ebitda)}.",
            explanation=f"La forza operativa è in area {_zone_ebitda(ebitda)}.",
            action_hint="Per migliorarlo servono efficienza operativa, taglio sprechi e migliore allocazione della spesa.",
        )
        return Answer(
            intent="ebitda",
            value=ebitda,
            value_str=fmt_eur(ebitda),
            narrative=narrative,
            advisories=_base_advisories_for_kpi("ebitda", k, sector),
        )

    if intent in {"cashflow", "ccc", "ciclo_cassa"}:
        ccc = _nz(k.ccc)
        narrative = _build_metric_narrative(
            title=f"Cash Conversion Cycle: {int(ccc)} giorni.",
            explanation=f"Il ciclo di cassa è in area {_zone_ccc(ccc)}.",
            action_hint="Leve principali: incassare prima, ruotare meglio lo stock e negoziare meglio i pagamenti.",
        )
        return Answer(
            intent="cashflow",
            value=ccc,
            value_str=f"{int(ccc)} giorni",
            narrative=narrative,
            advisories=_base_advisories_for_kpi("cashflow", k, sector),
        )

    if intent in {"zscore", "altman", "altman_z"}:
        z = _nz(k.altman_z)
        if z < 1.81:
            zone = "alto"
        elif z < 2.99:
            zone = "medio"
        else:
            zone = "basso"

        narrative = _build_metric_narrative(
            title=f"Altman Z-score: {z:.2f} (rischio {zone}).",
            explanation="È una metrica sintetica di robustezza economico-finanziaria: utile come allarme, non sufficiente da sola.",
            action_hint="Va letta insieme a utile, cassa, debito e qualità dei margini.",
        )
        return Answer(
            intent="zscore",
            value=z,
            value_str=f"{z:.2f}",
            narrative=narrative,
        )

    # -----------------------------
    # Executive summary + benchmarking (default)
    # -----------------------------
    adv_from_gaps, gap_texts = _gap_advisories(sector, k)
    intrinsic_advs = _intrinsic_summary_advisories(k, sector)

    fatt = _nz(k.fatturato)
    mc = _nz(k.margine_contribuzione)
    mc_rate = _nz(k.mc_rate)
    utile = _nz(k.utile)
    nmr = _nz(k.net_margin_rate)
    ebitda = _nz(k.ebitda)
    roi = _nz(k.roi)
    ccc = _nz(k.ccc)
    bep = _nz(k.break_even)

    header = " | ".join(
        [
            f"Ricavi {fmt_eur(fatt)}",
            f"MC {fmt_eur(mc)} ({fmt_pct(mc_rate, assume_fraction=True)})",
            f"BEP {fmt_eur(bep)}",
            f"Utile {fmt_eur(utile)} (NM {fmt_pct(nmr, assume_fraction=True)})",
            f"EBITDA {fmt_eur(ebitda)}",
            f"ROI {fmt_pct(roi, assume_fraction=True)}",
            f"CCC {int(ccc)}g",
        ]
    )

    signal_lines = _summary_signal_lines(k)
    signal_text = " | ".join(signal_lines)

    narrative_parts: List[str] = [
        header,
        f"Lettura CFO: {signal_text}.",
    ]

    if gap_texts:
        narrative_parts.append("Benchmark: " + " ".join(gap_texts))

    narrative_parts.append(
        "Focus operativo: proteggere il margine, aumentare la produttività della struttura e mantenere disciplina sulla cassa."
    )

    return Answer(
        intent="executive_summary",
        narrative=" ".join(narrative_parts),
        advisories=_merge_advisories(intrinsic_advs, adv_from_gaps),
    )