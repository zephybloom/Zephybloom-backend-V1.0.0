# -*- coding: utf-8 -*-
# content/nlp/intents_matcher.py — versione scalata e blindata
from __future__ import annotations
import pathlib, re, time, difflib, fnmatch
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Dict, List, Tuple, Any, Optional

import yaml
from utils.fmt_parse import normalize_text

# -----------------------------
# Modello in memoria
# -----------------------------
@dataclass
class IntentPattern:
    raw: str
    kind: str  # "literal" | "regex"
    compiled: Optional[re.Pattern] = None

@dataclass
class IntentDef:
    name: str
    aliases: List[str] = field(default_factory=list)
    patterns: List[IntentPattern] = field(default_factory=list)
    weight: float = 1.0         # boost opzionale (es. settore)
    fuzzy_threshold: float = 0.72

# -----------------------------
# Helpers
# -----------------------------
_LIT_SCORE = 0.98         # match substring literal
_ALIAS_SCORE = 1.00       # match alias esatto
_REGEX_SCORE = 0.95
_FUZZY_FLOOR = 0.50       # non considerare fuzzy sotto questo
_TOP_K_DEFAULT = 3

def _compile_pattern(p: str) -> IntentPattern:
    p = p or ""
    if p.startswith("re:"):
        expr = p[3:].strip()
        try:
            return IntentPattern(raw=p, kind="regex", compiled=re.compile(expr, re.I | re.U))
        except re.error:
            # fallback: trattalo come literal se regex invalida
            return IntentPattern(raw=p, kind="literal", compiled=None)
    return IntentPattern(raw=p, kind="literal", compiled=None)

def _load_yaml_file(path: pathlib.Path) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
            if not isinstance(data, dict):
                return {}
            return data
    except FileNotFoundError:
        return {}
    except Exception:
        return {}

def _token_jaccard(a: str, b: str) -> float:
    sa = set(a.split())
    sb = set(b.split())
    if not sa or not sb:
        return 0.0
    inter = len(sa & sb)
    union = len(sa | sb)
    return inter / union

def _norm(s: str) -> str:
    return normalize_text(s or "")

# -----------------------------
# IntentsCatalog
# -----------------------------
class IntentsCatalog:
    """
    Catalogo intenti con supporto:
    - multi-file YAML (intents.yml|yaml o *.yml|*.yaml nella cartella)
    - alias esatti (mappa O(1))
    - pattern literal (substring) e regex (re:)
    - fuzzy matching (difflib + jaccard) con soglia per-intent
    Ritorna top-k con confidence e ragione del match.
    """

    def __init__(self, root: str | pathlib.Path, enable_hot_reload: bool = False):
        self.root = pathlib.Path(root)
        self.enable_hot_reload = enable_hot_reload
        self._intents: List[IntentDef] = []
        self._alias_map: Dict[str, str] = {}
        self._index_literals: List[Tuple[str, str, float]] = []  # (name, normalized_pattern, weight)
        self._index_regex: List[Tuple[str, re.Pattern, float]] = []  # (name, compiled, weight)
        self._fuzzy_thresholds: Dict[str, float] = {}
        self._mtimes: Dict[pathlib.Path, float] = {}
        self._load_all()

    # ---------- public API ----------
    def match_one(self, text: str) -> Optional[Dict[str, Any]]:
        """Ritorna il best match: {name, score, reason}. Altrimenti None."""
        results = self.match_all(text, k=1)
        return results[0] if results else None

    def match_all(self, text: str, k: int = _TOP_K_DEFAULT) -> List[Dict[str, Any]]:
        """Ritorna top-k match ordinati per score decrescente."""
        t = _norm(text)
        if not t:
            return []
        if self.enable_hot_reload:
            self._maybe_reload()

        # Cache sul testo normalizzato e K
        return self._match_all_cached(t, k)

    # ---------- internal ----------
    @lru_cache(maxsize=4096)
    def _match_all_cached(self, t_norm: str, k: int) -> List[Dict[str, Any]]:
        # Alias exact
        if t_norm in self._alias_map:
            name = self._alias_map[t_norm]
            return [{"name": name, "score": _ALIAS_SCORE, "reason": "alias"}]

        candidates: List[Tuple[str, float, str]] = []  # (name, score, reason)

        # Literal substring
        for name, pat, w in self._index_literals:
            if pat and pat in t_norm:
                candidates.append((name, _LIT_SCORE * w, "literal"))

        # Regex
        for name, creg, w in self._index_regex:
            try:
                if creg.search(t_norm):
                    candidates.append((name, _REGEX_SCORE * w, "regex"))
            except re.error:
                continue

        # Fuzzy (solo se non già sicuro)
        # La fuzzy qui usa una media pesata tra difflib ratio e jaccard
        # per stabilizzare frasi corte/lunghe.
        if not candidates:
            for intent in self._intents:
                th = self._fuzzy_thresholds.get(intent.name, 0.72)
                # confronta con il miglior dei pattern dell'intent
                best_f = 0.0
                for p in intent.patterns:
                    if p.kind == "literal":
                        pat_n = _norm(p.raw)
                        r1 = difflib.SequenceMatcher(None, t_norm, pat_n).ratio()
                        r2 = _token_jaccard(t_norm, pat_n)
                        fscore = 0.65 * r1 + 0.35 * r2
                        best_f = max(best_f, fscore)
                    elif p.kind == "regex" and p.compiled is not None:
                        # una regex non ha senso fuzzy; salta
                        continue
                if best_f >= max(th, _FUZZY_FLOOR):
                    candidates.append((intent.name, best_f * intent.weight, "fuzzy"))

        if not candidates:
            return []

        # Aggregate by name → keep max score per intent
        agg: Dict[str, Tuple[float, str]] = {}
        for name, score, reason in candidates:
            if name not in agg or score > agg[name][0]:
                agg[name] = (score, reason)

        ranked = sorted(
            [{"name": n, "score": s, "reason": r} for n, (s, r) in agg.items()],
            key=lambda x: x["score"],
            reverse=True,
        )
        return ranked[: max(1, k)]

    # ---------- loading ----------
    def _load_all(self) -> None:
        self._intents.clear()
        self._alias_map.clear()
        self._index_literals.clear()
        self._index_regex.clear()
        self._fuzzy_thresholds.clear()
        self._mtimes.clear()

        files = self._discover_files()
        for f in files:
            self._mtimes[f] = f.stat().st_mtime

            data = _load_yaml_file(f)
            intents_raw = data.get("intents", [])
            if not isinstance(intents_raw, list):
                continue

            for it in intents_raw:
                name = it.get("name")
                if not name or not isinstance(name, str):
                    continue
                weight = float(it.get("weight", 1.0))
                fuzzy_th = float(it.get("fuzzy_threshold", 0.72))

                aliases = [a for a in (it.get("aliases") or []) if isinstance(a, str)]
                patterns_raw = [p for p in (it.get("patterns") or []) if isinstance(p, str)]
                patterns = [_compile_pattern(p) for p in patterns_raw]

                idef = IntentDef(
                    name=name,
                    aliases=aliases,
                    patterns=patterns,
                    weight=weight,
                    fuzzy_threshold=fuzzy_th,
                )
                self._intents.append(idef)
                self._fuzzy_thresholds[name] = fuzzy_th

                # alias map
                for a in aliases:
                    self._alias_map[_norm(a)] = name

                # indexes
                for p in patterns:
                    if p.kind == "literal":
                        self._index_literals.append((name, _norm(p.raw), weight))
                    elif p.kind == "regex" and p.compiled is not None:
                        self._index_regex.append((name, p.compiled, weight))

        # invalida cache dopo un load
        self._match_all_cached.cache_clear()

    def _discover_files(self) -> List[pathlib.Path]:
        """Trova intents.yml|yaml oppure tutti i *.yml|*.yaml della cartella."""
        files: List[pathlib.Path] = []
        ymain1 = self.root / "intents.yml"
        ymain2 = self.root / "intents.yaml"
        if ymain1.exists():
            files.append(ymain1)
        if ymain2.exists():
            files.append(ymain2)

        # se non c'è un main, carica tutti i *.yml|*.yaml
        if not files and self.root.exists():
            for pat in ("*.yml", "*.yaml"):
                files.extend(self.root.glob(pat))
        return files

    def _maybe_reload(self) -> None:
        """Hot-reload leggero: se qualche file è cambiato, ricarica."""
        try:
            changed = False
            for f in self._discover_files():
                m = f.stat().st_mtime
                if f not in self._mtimes or m > self._mtimes[f]:
                    changed = True
                    break
            if changed:
                self._load_all()
        except Exception:
            # mai rompere in produzione: al massimo tieni il vecchio indice
            pass
