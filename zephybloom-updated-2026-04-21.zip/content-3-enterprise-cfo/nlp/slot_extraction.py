# -*- coding: utf-8 -*-
# content/nlp/slot_extraction.py — Scalato e hardenizzato
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from utils.fmt_parse import parse_number, parse_percent


# -----------------------------------------
# Sinonimi → chiave canonica
# -----------------------------------------
_CANON: Dict[str, List[str]] = {
    "fatturato": ["fatturato", "ricavi", "revenue", "vendite", "turnover", "sales"],
    "costi_variabili": ["costi variabili", "cv", "variabili", "variable costs"],
    "costi_fissi": ["costi fissi", "cf", "fissi", "fixed costs"],
    "investimenti": ["investimenti", "capex", "investimento", "investments"],
    "prezzo_medio": ["prezzo medio", "prezzo", "pm", "price"],
    "costo_variabile_unitario": [
        "costo variabile unitario",
        "cvu",
        "costo unitario",
        "cvu medio",
        "unit cost",
    ],
    "cogs": ["cogs", "costo del venduto", "cost of goods", "cost of goods sold"],
    "ammortamenti": ["ammortamenti", "ammortamento", "amort", "depreciation"],
    "dso": ["dso", "giorni incasso", "gg incasso", "days sales outstanding"],
    "dio": ["dio", "giorni magazzino", "gg magazzino", "days inventory outstanding"],
    "dpo": ["dpo", "giorni pagamento", "gg pagamento", "days payables outstanding"],
    "price_elasticity": [
        "elasticità",
        "elasticita",
        "price elasticity",
        "elasticità prezzo",
        "elasticità della domanda",
    ],
    # fallback utili
    "margine": ["margine", "mc", "margine contributivo", "gross margin"],
    "net_margin": ["net margin", "margine netto", "utile netto %"],
    "roi": ["roi", "ritorno sugli investimenti", "return on investment"],
    "churn_rate": ["churn", "churn rate", "tasso di churn"],
    "nrr": ["nrr", "net revenue retention"],
    "ltv": ["ltv", "lifetime value"],
    "cac": ["cac", "customer acquisition cost"],
    "arpu": ["arpu"],
    "conversion_rate": ["conversion rate", "tasso di conversione", "conversione"],
    "leads": ["lead", "leads"],
    "avg_ticket": ["avg ticket", "ticket medio", "scontrino medio"],
    "repeat_rate": ["repeat rate", "tasso di riacquisto", "riacquisto"],
    "history": ["history", "storico", "serie storica"],
    "periods": ["periods", "periodi"],
    "discount_rate_pct": ["discount rate", "tasso di sconto", "wacc"],
    "terminal_growth_pct": ["terminal growth", "crescita terminale"],
    "net_debt": ["net debt", "debito netto"],
    "ke": ["ke", "cost of equity", "costo equity"],
    "kd": ["kd", "cost of debt", "costo debito"],
    "equity": ["equity", "patrimonio"],
    "debt": ["debt", "debito"],
    "tax_rate": ["tax rate", "aliquota fiscale", "tasso fiscale"],
}

# Campi che supportano delta percentuale / assoluta
_DELTA_KEYS: Dict[str, str] = {
    "fatturato": "fatturato_pct",
    "costi_variabili": "costi_variabili_pct",
    "costi_fissi": "costi_fissi_pct",
    "prezzo_medio": "price_pct",
}

_ABS_KEYS: Dict[str, str] = {
    "fatturato": "fatturato_abs",
    "costi_variabili": "costi_variabili_abs",
    "costi_fissi": "costi_fissi_abs",
    "investimenti": "investimenti_abs",
}


# -----------------------------------------
# Regex helpers
# -----------------------------------------
def _alts(terms: List[str]) -> str:
    ordered = sorted(set(terms), key=len, reverse=True)
    return r"(?:%s)" % r"|".join(re.escape(x) for x in ordered)


_NUM = r"[-+]?(?:\d{1,3}(?:[\.\s]\d{3})*|\d+)(?:[\,\.]\d+)?(?:\s*(?:k|K|m|M|b|B|mln|mil|milioni|mld|miliardi))?"
_PCTNUM = r"[-+]?(?:\d{1,3}(?:[\,\.]\d+)?)"
_PCTVAL = r"[-+]?(?:\d{1,3}(?:[\,\.]\d+)?)(?:\s*%)?"

_VERB_UP = r"(?:aumenta|alza|incrementa|\+)"
_VERB_DOWN = r"(?:riduci|abbassa|diminuisci|\-)"
_VERB_SET = r"(?:porta|imposta|metti|fissa|setta|impostare|portare|settare)"
_OF_TOK = r"(?:di|del|dello|della|dell'|dei|degli|delle)"

_PP = re.compile(
    r"([-+]?\s*\d+(?:[\,\.]\d+)?)\s*(?:pp|p\.p\.|punti\s*percentuali)\b",
    re.IGNORECASE,
)

_PATTERNS: Dict[str, re.Pattern] = {}
_DELTA_PCT: Dict[str, re.Pattern] = {}
_DELTA_ABS: Dict[str, re.Pattern] = {}
_VERB_DELTA_PCT: Dict[str, re.Pattern] = {}
_VERB_DELTA_ABS: Dict[str, re.Pattern] = {}
_VERB_SET_VALUE: Dict[str, re.Pattern] = {}

for canon, terms in _CANON.items():
    t = _alts(terms)

    # base values
    if canon in {
        "fatturato",
        "costi_variabili",
        "costi_fissi",
        "investimenti",
        "prezzo_medio",
        "costo_variabile_unitario",
        "cogs",
        "ammortamenti",
        "ltv",
        "cac",
        "arpu",
        "avg_ticket",
        "net_debt",
        "equity",
        "debt",
    }:
        p = rf"\b{t}\b\s*[:=]?\s*(?:€\s*)?({_NUM})"
    elif canon in {
        "dso",
        "dio",
        "dpo",
        "price_elasticity",
        "leads",
        "periods",
    }:
        p = rf"\b{t}\b\s*[:=]?\s*({_NUM})"
    elif canon in {
        "roi",
        "net_margin",
        "churn_rate",
        "nrr",
        "conversion_rate",
        "repeat_rate",
        "discount_rate_pct",
        "terminal_growth_pct",
    }:
        p = rf"\b{t}\b\s*[:=]?\s*({_PCTVAL})"
    else:
        p = rf"\b{t}\b\s*[:=]?\s*({_NUM})"

    _PATTERNS[canon] = re.compile(p, flags=re.IGNORECASE)

    # delta only for specific fields
    if canon in _DELTA_KEYS:
        _DELTA_PCT[canon] = re.compile(
            rf"\b{t}\b\s*[:=]?\s*({_PCTNUM})\s*%",
            re.IGNORECASE,
        )

        _DELTA_ABS[canon] = re.compile(
            rf"\b{t}\b\s*[:=]?\s*([+\-]\s*{_NUM})(?!\s*%)\b",
            re.IGNORECASE,
        )

        _VERB_DELTA_PCT[canon] = re.compile(
            rf"(?P<dir>{_VERB_UP}|{_VERB_DOWN}).{{0,32}}?\b{t}\b(?:.*?(?:{_OF_TOK})\s+|.*?\s+)?(?P<val>{_PCTNUM})\s*%",
            re.IGNORECASE,
        )

        _VERB_DELTA_ABS[canon] = re.compile(
            rf"(?P<dir>{_VERB_UP}|{_VERB_DOWN}).{{0,32}}?\b{t}\b.*?(?:{_OF_TOK})?\s+(?P<val>{_NUM})(?!\s*%)\b",
            re.IGNORECASE,
        )

    _VERB_SET_VALUE[canon] = re.compile(
        rf"{_VERB_SET}\s+(?:il|la|i|le)?\s*\b{t}\b.*?(?:a|=)\s*(?:€\s*)?({_NUM}|{_PCTVAL})",
        re.IGNORECASE,
    )

_PCT_FALLBACK = re.compile(
    rf"\b(roi|margine|net margin|gross margin|margine netto|churn|nrr|conversione|conversion rate)\b\s*[:=]?\s*({_PCTVAL})",
    re.IGNORECASE,
)

_HISTORY_LIST = re.compile(
    r"\b(?:history|storico|serie storica)\b\s*[:=]?\s*\[([^\]]+)\]",
    re.IGNORECASE,
)

_PERIODS_INLINE = re.compile(
    r"\b(?:periods|periodi)\b\s*[:=]?\s*(\d+)\b",
    re.IGNORECASE,
)

_METHOD_INLINE = re.compile(
    r"\b(?:method|metodo)\b\s*[:=]?\s*(sma|ema|holt|auto|naive)\b",
    re.IGNORECASE,
)


# -----------------------------------------
# Normalizzazione testo
# -----------------------------------------
def _normalize_text(s: str) -> str:
    if not s:
        return s

    s = str(s)
    s = s.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    s = s.replace("\u2019", "'").replace("\u2018", "'")
    s = s.replace("\uff05", "%")
    s = re.sub(r"([+\-])\s+(\d)", r"\1\2", s)
    s = re.sub(r"\s*%\s*", "%", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _pp_to_pct(m: re.Match) -> str:
    raw = m.group(1)
    try:
        v = parse_percent(raw)
        if v is None:
            v = parse_number(raw)
        if v is None:
            return raw
        return f"{v:.4g}%"
    except Exception:
        return raw


# -----------------------------------------
# Priorità
# -----------------------------------------
def _prefer(out: Dict[str, Any], key: str, val: Any, strength: int, seen: Dict[str, int]) -> None:
    if key not in out or seen.get(key, -1) < strength:
        out[key] = val
        seen[key] = strength


def _sign_from_dir(dir_tok: str) -> float:
    d = (dir_tok or "").lower()
    if re.search(_VERB_DOWN, d, flags=re.IGNORECASE):
        return -1.0
    return 1.0


def _canon_from_fallback(label: str) -> Optional[str]:
    l = (label or "").lower().strip()
    mapping = {
        "roi": "roi",
        "margine": "margine",
        "gross margin": "margine",
        "net margin": "net_margin",
        "margine netto": "net_margin",
        "churn": "churn_rate",
        "nrr": "nrr",
        "conversione": "conversion_rate",
        "conversion rate": "conversion_rate",
    }
    return mapping.get(l)


def _maybe_percent_field(key: str) -> bool:
    return key in {
        "roi",
        "net_margin",
        "churn_rate",
        "nrr",
        "conversion_rate",
        "repeat_rate",
        "discount_rate_pct",
        "terminal_growth_pct",
        "margine",
    }


def _parse_value_for_key(key: str, raw: str) -> Optional[float]:
    if _maybe_percent_field(key):
        return parse_percent(raw)
    return parse_number(raw)


def _parse_history_list(raw: str) -> List[float]:
    out: List[float] = []
    for part in re.split(r"[;,]", raw):
        part = part.strip()
        if not part:
            continue
        v = parse_number(part)
        if v is not None:
            out.append(float(v))
    return out


# -----------------------------------------
# Estrazione principale
# -----------------------------------------
def extract_slots(text: str) -> Dict[str, Any]:
    """
    Estrae:
    - valori base
    - delta % / delta assoluti
    - verbi aumenta/riduci/porta a
    - pp (punti percentuali)
    - campi percentuali
    - history / periods / method
    """
    out: Dict[str, Any] = {}
    if not text:
        return out

    s = _normalize_text(text)
    s = _PP.sub(_pp_to_pct, s)

    seen_strength: Dict[str, int] = {}

    # 0) History list
    m_hist = _HISTORY_LIST.search(s)
    if m_hist:
        hist = _parse_history_list(m_hist.group(1))
        if hist:
            _prefer(out, "history", hist, strength=4, seen=seen_strength)

    # 0b) Periods / method
    m_periods = _PERIODS_INLINE.search(s)
    if m_periods:
        try:
            _prefer(out, "periods", float(m_periods.group(1)), strength=3, seen=seen_strength)
        except Exception:
            pass

    m_method = _METHOD_INLINE.search(s)
    if m_method:
        _prefer(out, "method", m_method.group(1).lower(), strength=3, seen=seen_strength)

    # 1) Verbal delta %
    for canon, rx in _VERB_DELTA_PCT.items():
        for m in rx.finditer(s):
            raw = m.group("val")
            p = parse_percent(raw)
            if p is None:
                continue
            p *= _sign_from_dir(m.group("dir") or "")
            _prefer(out, _DELTA_KEYS[canon], p, strength=5, seen=seen_strength)

    # 2) Verbal delta absolute
    for canon, rx in _VERB_DELTA_ABS.items():
        for m in rx.finditer(s):
            raw = m.group("val")
            v = parse_number(raw)
            if v is None:
                continue
            v *= _sign_from_dir(m.group("dir") or "")
            abs_key = _ABS_KEYS.get(canon)
            if abs_key:
                _prefer(out, abs_key, v, strength=5, seen=seen_strength)

    # 3) Set target values
    for canon, rx in _VERB_SET_VALUE.items():
        for m in rx.finditer(s):
            raw = m.group(1)
            v = _parse_value_for_key(canon, raw)
            if v is not None:
                _prefer(out, canon, v, strength=4, seen=seen_strength)

    # 4) Explicit delta %
    for canon, rx in _DELTA_PCT.items():
        for m in rx.finditer(s):
            p = parse_percent(m.group(1))
            if p is not None:
                _prefer(out, _DELTA_KEYS[canon], p, strength=5, seen=seen_strength)

    # 5) Explicit delta absolute
    for canon, rx in _DELTA_ABS.items():
        for m in rx.finditer(s):
            v = parse_number(m.group(1))
            if v is None:
                continue
            abs_key = _ABS_KEYS.get(canon)
            if abs_key:
                _prefer(out, abs_key, v, strength=5, seen=seen_strength)

    # 6) Base values
    for key, rx in _PATTERNS.items():
        for m in rx.finditer(s):
            raw = m.group(1)
            v = _parse_value_for_key(key, raw)
            if v is not None:
                _prefer(out, key, v, strength=2, seen=seen_strength)

    # 7) Fallback percentages
    for m in _PCT_FALLBACK.finditer(s):
        canon = _canon_from_fallback(m.group(1))
        if not canon:
            continue
        p = parse_percent(m.group(2))
        if p is not None:
            _prefer(out, canon, p, strength=1, seen=seen_strength)

    # 8) Fix leggeri di coerenza
    if "prezzo_pct" in out and "price_pct" not in out:
        out["price_pct"] = out["prezzo_pct"]

    # Se l'utente scrive prezzo +5% possiamo lasciare solo price_pct
    if "prezzo_medio_pct" in out and "price_pct" not in out:
        out["price_pct"] = out["prezzo_medio_pct"]

    # Normalizza periods a int-like float già coerente col resto del router
    if "periods" in out:
        try:
            out["periods"] = float(int(float(out["periods"])))
        except Exception:
            out.pop("periods", None)

    return out