Questa cartella è letta dal NLPRouter per il catalogo intent.
Se già possiedi 'content/intents/intents.yml', copialo qui come:
  content/nlp/intents/intents.yml
In alternativa, modifica il costruttore del router per puntare a 'content/intents'.
