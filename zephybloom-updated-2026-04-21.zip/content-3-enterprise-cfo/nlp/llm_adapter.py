# -*- coding: utf-8 -*-
# content/nlp/llm_adapter.py — provider-agnostic (OpenAI-ready) con tool-calling, retry, budget guardrail
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Callable

from utils.errors import ExternalServiceAppError
from utils.logging_utils import get_logger

# Import "soft": se la lib non c'è o non c'è API key, solleveremo al primo uso.
try:
    # OpenAI SDK (>= 1.x)
    from openai import OpenAI  # type: ignore
except Exception:  # pragma: no cover
    OpenAI = None  # type: ignore

log = get_logger("nlp.llm_adapter")

# -------------------------
# Config da ENV (opzionali)
# -------------------------
ZB_LLM_PROVIDER = os.environ.get("ZB_LLM_PROVIDER", "openai")
ZB_LLM_MODEL = os.environ.get("ZB_LLM_MODEL", "gpt-4o-mini")
ZB_LLM_JSON_MODE = os.environ.get("ZB_LLM_JSON_MODE", "0") == "1"
ZB_LLM_MAX_ROUNDS = int(os.environ.get("ZB_LLM_MAX_ROUNDS", "2"))
ZB_LLM_RETRIES = int(os.environ.get("ZB_LLM_RETRIES", "2"))
ZB_LLM_BUDGET_USD = float(os.environ.get("ZB_LLM_BUDGET_USD", "0"))
ZB_LLM_PROMPT_MAXITEMS = int(os.environ.get("ZB_LLM_PROMPT_MAXITEMS", "18"))


# -------------------------
# Tipi risultato/usage
# -------------------------
@dataclass
class LLMUsage:
    model: str
    provider: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: Optional[float] = None


@dataclass
class LLMResult:
    text: str
    usage: LLMUsage
    raw: Any | None = None


class LLMBudgetError(Exception):
    def __init__(self, message: str, usage: Optional[LLMUsage] = None) -> None:
        super().__init__(message)
        self.usage = usage


# -------------------------
# Adapter
# -------------------------
class LLMAdapter:
    """
    Adapter semplice per LLM con supporto tool-calling e controlli operativi.

    - Provider attuale: OpenAI (>=1.x)
    - Tool-calling con limite di round per evitare loop infiniti
    - Retry/backoff su errori transienti
    - Guardrail di budget per chiamata
    - JSON-mode opzionale
    """

    def __init__(self, provider: str = ZB_LLM_PROVIDER, model: Optional[str] = None, timeout: int = 40) -> None:
        self.provider = provider
        self.model = model or ZB_LLM_MODEL
        self.timeout = timeout

        self._client = None
        if self.provider == "openai":
            if OpenAI is None or not os.environ.get("OPENAI_API_KEY"):
                self._client = None
            else:
                try:
                    self._client = OpenAI()
                except Exception:
                    self._client = None

    # -------------------------
    # API pubblica
    # -------------------------
    def complete(
        self,
        system: str,
        user: str,
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_invoker: Optional[Any] = None,
        temperature: float = 0.2,
        max_tokens: int = 800,
    ) -> LLMResult:
        """
        Chat single-turn con opzionale tool-calling.
        """
        messages: List[Dict[str, Any]] = [
            {"role": "system", "content": str(system or "")},
            {"role": "user", "content": str(user or "")},
        ]
        messages = self._truncate_messages(messages, max_items=ZB_LLM_PROMPT_MAXITEMS)

        json_mode = ZB_LLM_JSON_MODE or (tools is None and str(user or "").strip().startswith("{"))

        if self.provider != "openai":
            raise ExternalServiceAppError(
                "Provider LLM non supportato",
                details={"provider": self.provider},
            )

        resp = self._call_with_retry(
            self._openai_chat,
            messages,
            tools,
            temperature,
            max_tokens,
            json_mode=json_mode,
        )

        rounds = 0
        while True:
            msg = self._extract_message(resp)
            tool_calls = getattr(msg, "tool_calls", None)

            if not tool_calls or tool_invoker is None:
                break

            rounds += 1
            if rounds > max(1, ZB_LLM_MAX_ROUNDS):
                log.info("tool_call_round_limit_reached", extra={"rounds": rounds})
                break

            # aggiungiamo il messaggio assistant con tool_calls alla conversazione
            assistant_tool_message = self._message_to_openai_dict(msg)
            if assistant_tool_message:
                messages.append(assistant_tool_message)

            for tc in tool_calls:
                fn_name = getattr(getattr(tc, "function", None), "name", "") or ""
                fn_args_raw = getattr(getattr(tc, "function", None), "arguments", "") or ""

                try:
                    fn_args = json.loads(fn_args_raw) if fn_args_raw else {}
                    if not isinstance(fn_args, dict):
                        fn_args = {}
                except Exception:
                    fn_args = {}

                try:
                    tool_result = tool_invoker.invoke(fn_name, fn_args)
                    tool_payload = self._safe_json_dumps(tool_result)
                except Exception as e:
                    tool_payload = self._safe_json_dumps({"error": str(e), "tool": fn_name})

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": getattr(tc, "id", ""),
                        "content": tool_payload,
                    }
                )

            messages = self._truncate_messages(messages, max_items=ZB_LLM_PROMPT_MAXITEMS)

            resp = self._call_with_retry(
                self._openai_chat,
                messages,
                tools,
                temperature,
                max_tokens,
                json_mode=json_mode,
            )

        final_msg = self._extract_message(resp)
        text = self._extract_text(final_msg)
        usage = self._usage_from_openai(resp)

        if ZB_LLM_BUDGET_USD > 0 and usage.cost_usd is not None and usage.cost_usd > ZB_LLM_BUDGET_USD:
            log.warning(
                "llm_budget_exceeded",
                extra={
                    "cost_usd": usage.cost_usd,
                    "budget_usd": ZB_LLM_BUDGET_USD,
                    "model": usage.model,
                },
            )
            raise LLMBudgetError("Budget massimo per chiamata superato", usage=usage)

        log.info(
            "llm_complete_ok",
            extra={
                "provider": self.provider,
                "model": usage.model,
                "prompt_tokens": usage.prompt_tokens,
                "completion_tokens": usage.completion_tokens,
                "total_tokens": usage.total_tokens,
                "cost_usd": usage.cost_usd,
            },
        )

        return LLMResult(text=text, usage=usage, raw=resp)

    # -------------------------
    # OpenAI backend
    # -------------------------
    def _openai_chat(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]],
        temperature: float,
        max_tokens: int,
        *,
        json_mode: bool = False,
    ) -> Any:
        if self._client is None:
            raise ExternalServiceAppError(
                "OpenAI non configurato",
                details={
                    "hint": "Installa openai>=1.x e imposta OPENAI_API_KEY",
                    "model": self.model,
                },
            )

        try:
            kwargs: Dict[str, Any] = {
                "model": self.model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "timeout": self.timeout,
            }

            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = "auto"

            if json_mode:
                kwargs["response_format"] = {"type": "json_object"}

            return self._client.chat.completions.create(**kwargs)

        except Exception as e:  # pragma: no cover
            log.exception("OpenAI chat error")
            raise ExternalServiceAppError(
                "Errore chiamando OpenAI",
                details={"error": str(e), "model": self.model},
            )

    def _usage_from_openai(self, resp: Any) -> LLMUsage:
        usage = getattr(resp, "usage", None)

        pt = self._safe_int(
            getattr(usage, "prompt_tokens", None) if usage is not None else None,
            default=0,
        )
        ct = self._safe_int(
            getattr(usage, "completion_tokens", None) if usage is not None else None,
            default=0,
        )
        tt = self._safe_int(
            getattr(usage, "total_tokens", None) if usage is not None else None,
            default=pt + ct,
        )

        result = LLMUsage(
            model=self.model,
            provider=self.provider,
            prompt_tokens=pt,
            completion_tokens=ct,
            total_tokens=tt,
        )
        result.cost_usd = self._estimate_cost(result)
        return result

    def _estimate_cost(self, u: LLMUsage) -> Optional[float]:
        override = os.environ.get("ZB_LLM_PRICES")
        if override:
            try:
                prices: Dict[str, Dict[str, float]] = json.loads(override)
            except Exception:
                prices = {}
        else:
            prices = {
                "gpt-4o": {"prompt": 5.0 / 1_000_000, "completion": 15.0 / 1_000_000},
                "gpt-4o-mini": {"prompt": 0.15 / 1_000_000, "completion": 0.60 / 1_000_000},
            }

        p = prices.get(u.model)
        if not p:
            return None

        prompt_price = float(p.get("prompt", 0.0))
        completion_price = float(p.get("completion", 0.0))

        return (u.prompt_tokens * prompt_price) + (u.completion_tokens * completion_price)

    # -------------------------
    # Helpers privati
    # -------------------------
    def _truncate_messages(self, messages: List[Dict[str, Any]], max_items: int = 18) -> List[Dict[str, Any]]:
        """
        Soft-cap: limita la conversazione senza tokenizzare.
        Mantiene il primo system e gli ultimi (max_items-1) messaggi non-system.
        """
        if len(messages) <= max_items:
            return messages

        head = [m for m in messages if m.get("role") == "system"][:1]
        tail = [m for m in messages if m.get("role") != "system"][-(max_items - 1):]
        return head + tail

    def _call_with_retry(self, fn: Callable[..., Any], *args, **kwargs) -> Any:
        """
        Retry/backoff semplice su errori transienti.
        """
        last_error: Optional[Exception] = None

        for attempt in range(ZB_LLM_RETRIES + 1):
            try:
                return fn(*args, **kwargs)

            except ExternalServiceAppError as e:
                last_error = e
                if attempt < ZB_LLM_RETRIES:
                    sleep_s = 1.5 ** attempt
                    log.warning(
                        "retry_external_service",
                        extra={"attempt": attempt + 1, "sleep_s": sleep_s},
                    )
                    time.sleep(sleep_s)
                    continue
                raise

            except Exception as e:
                last_error = e
                if attempt < ZB_LLM_RETRIES:
                    sleep_s = 1.5 ** attempt
                    log.warning(
                        "retry_generic",
                        extra={"attempt": attempt + 1, "sleep_s": sleep_s},
                    )
                    time.sleep(sleep_s)
                    continue
                raise ExternalServiceAppError(
                    "Errore non gestito in LLMAdapter",
                    details={"error": str(e)},
                )

        if last_error is not None:
            raise last_error

        raise ExternalServiceAppError("Errore sconosciuto in LLMAdapter")

    def _extract_message(self, resp: Any) -> Any:
        try:
            return resp.choices[0].message
        except Exception as e:
            raise ExternalServiceAppError(
                "Risposta provider non valida",
                details={"error": str(e)},
            )

    def _extract_text(self, msg: Any) -> str:
        content = getattr(msg, "content", None)

        if isinstance(content, str):
            return content.strip()

        if isinstance(content, list):
            parts: List[str] = []
            for item in content:
                try:
                    if isinstance(item, dict):
                        if item.get("type") == "text" and item.get("text"):
                            parts.append(str(item["text"]))
                    else:
                        txt = getattr(item, "text", None)
                        if txt:
                            parts.append(str(txt))
                except Exception:
                    continue
            return "\n".join([p for p in parts if p]).strip()

        return ""

    def _message_to_openai_dict(self, msg: Any) -> Optional[Dict[str, Any]]:
        try:
            out: Dict[str, Any] = {"role": "assistant"}

            content = getattr(msg, "content", None)
            if content is not None:
                out["content"] = content
            else:
                out["content"] = ""

            tool_calls = getattr(msg, "tool_calls", None)
            if tool_calls:
                serialized_calls = []
                for tc in tool_calls:
                    serialized_calls.append(
                        {
                            "id": getattr(tc, "id", ""),
                            "type": getattr(tc, "type", "function"),
                            "function": {
                                "name": getattr(getattr(tc, "function", None), "name", ""),
                                "arguments": getattr(getattr(tc, "function", None), "arguments", "") or "",
                            },
                        }
                    )
                out["tool_calls"] = serialized_calls

            return out
        except Exception:
            return None

    def _safe_json_dumps(self, payload: Any) -> str:
        try:
            return json.dumps(payload, ensure_ascii=False)
        except Exception:
            try:
                return json.dumps({"result": str(payload)}, ensure_ascii=False)
            except Exception:
                return '{"result": "serialization_error"}'

    def _safe_int(self, value: Any, default: int = 0) -> int:
        try:
            return int(value)
        except Exception:
            return default


# -------------------------
# Helper ZephyBloom (con system default coerente)
# -------------------------
DEFAULT_SYSTEM = (
    "Sei il CFO virtuale ZephyBloom. Rispondi in italiano, con tono sintetico e consulenziale. "
    "Usa formattazione europea per i numeri (virgola per i decimali) e valuta in euro. "
    "Per le percentuali usa una cifra decimale. Se un dato manca, chiedi solo il minimo necessario per procedere."
)


def complete_zephy(
    user: str,
    context: Optional[Dict[str, Any]] = None,
    *,
    adapter: Optional[LLMAdapter] = None,
    tools: Optional[List[Dict[str, Any]]] = None,
    tool_invoker: Optional[Any] = None,
    system: Optional[str] = None,
    temperature: float = 0.2,
    max_tokens: int = 800,
) -> LLMResult:
    """
    Convenience wrapper ZephyBloom.
    """
    adapter = adapter or LLMAdapter(provider=ZB_LLM_PROVIDER, model=ZB_LLM_MODEL)

    sysmsg = system or DEFAULT_SYSTEM
    if context:
        try:
            ctx_json = json.dumps(context, ensure_ascii=False)
            user_payload = f"{user}\n\nContesto:\n{ctx_json}"
        except Exception:
            user_payload = user
    else:
        user_payload = user

    return adapter.complete(
        sysmsg,
        user_payload,
        tools=tools,
        tool_invoker=tool_invoker,
        temperature=temperature,
        max_tokens=max_tokens,
    )