# content/tools/breakeven.py
from __future__ import annotations
from typing import Dict, Any, Optional, List, Tuple

from utils.math_utils import safe_div


# -----------------------------
# Helper base
# -----------------------------
def _mc_rate(fatturato: float, costi_variabili: float) -> float:
    """MC-rate clampato in [0,1]."""
    if fatturato <= 0:
        return 0.0
    r = (float(fatturato) - float(costi_variabili)) / float(fatturato)
    if r < 0.0:
        return 0.0
    if r > 1.0:
        return 1.0
    return float(r)


def _be_revenue(cf: float, mc_rate: float) -> Optional[float]:
    """Break-even in valore (ricavi) = CF / MC%."""
    if mc_rate <= 0.0:
        return None
    v = float(cf) / float(mc_rate)
    return 0.0 if v < 0 else float(v)


def _be_qty_from_unit(cf: float, price: float, cvu: float) -> Optional[float]:
    """Break-even in quantità dato prezzo e costo variabile unitario."""
    contrib_u = float(price) - float(cvu)
    if contrib_u <= 0.0:
        return None
    q = float(cf) / contrib_u
    return 0.0 if q < 0 else float(q)


# -----------------------------
# 1) API retro-compatibile
# -----------------------------
def breakeven_tool(ctx: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """
    Break-even semplice (compat con versione precedente).
    Input attesi nel ctx:
      - fatturato, costi_variabili, costi_fissi, prezzo_medio (facoltativo)
    Ritorna: be_qty, be_revenue, mc_rate
    """
    fatt = float(ctx.get("fatturato", 0.0) or 0.0)
    cv   = float(ctx.get("costi_variabili", 0.0) or 0.0)
    cf   = float(ctx.get("costi_fissi", 0.0) or 0.0)
    p    = float(ctx.get("prezzo_medio", 0.0) or 0.0)

    mc_rate = _mc_rate(fatt, cv)

    be_revenue = _be_revenue(cf, mc_rate)
    be_qty = (be_revenue / p) if (be_revenue is not None and p > 0) else None
    if be_qty is not None and be_qty < 0:
        be_qty = 0.0

    return {
        "be_qty": be_qty,
        "be_revenue": be_revenue,
        "mc_rate": mc_rate,
    }


# -----------------------------
# 2) Break-even per unit economics
# -----------------------------
def breakeven_by_unit(costi_fissi: float, prezzo: float, costo_variabile_unitario: float) -> Dict[str, Optional[float]]:
    """
    Break-even quantità/ricavi con dati unitari (single SKU).
    """
    q = _be_qty_from_unit(costi_fissi, prezzo, costo_variabile_unitario)
    rev = (q * prezzo) if (q is not None) else None
    mc_r = _mc_rate(prezzo, costo_variabile_unitario) if prezzo > 0 else 0.0
    return {"be_qty": q, "be_revenue": rev, "mc_rate": mc_r}


# -----------------------------
# 3) Break-even multi-prodotto con mix
# -----------------------------
def breakeven_mix(
    costi_fissi: float,
    mix: List[Dict[str, float]],
) -> Dict[str, Optional[float]]:
    """
    Break-even con più prodotti e mix fisso.
    mix: lista di item con chiavi:
      - 'p'   : prezzo unitario
      - 'cvu' : costo variabile unitario
      - 'share' : quota del mix (somma ~ 1.0)
    Output:
      - be_qty_total  : quantità totali (somma sulle unità del paniere mix)
      - be_revenue    : ricavi a BE
      - mc_rate_mix   : MC% medio sul paniere (per ricavi)
      - per_sku_qty   : breakdown quantità per prodotto a BE (in base al mix)
    Formula:
      contrib_mix_u = Σ share_i * (p_i - cvu_i)
      be_qty_total  = CF / contrib_mix_u
      p_avg         = Σ share_i * p_i
      be_revenue    = be_qty_total * p_avg
      mc_rate_mix   = contrib_mix_u / p_avg
    """
    if not mix:
        return {"be_qty_total": None, "be_revenue": None, "mc_rate_mix": 0.0, "per_sku_qty": []}

    # normalizza e filtra voci non sensate
    norm: List[Tuple[float, float, float]] = []
    tot_share = 0.0
    for item in mix:
        try:
            p = float(item.get("p", 0.0) or 0.0)
            cvu = float(item.get("cvu", 0.0) or 0.0)
            sh = float(item.get("share", 0.0) or 0.0)
        except Exception:
            continue
        if p <= 0 or sh <= 0:
            continue
        norm.append((p, cvu, sh))
        tot_share += sh

    if not norm:
        return {"be_qty_total": None, "be_revenue": None, "mc_rate_mix": 0.0, "per_sku_qty": []}

    # rinormalizza share a 1.0 se necessario
    if abs(tot_share - 1.0) > 1e-9:
        norm = [(p, cvu, sh / tot_share) for (p, cvu, sh) in norm]

    contrib_mix_u = sum(sh * (p - cvu) for (p, cvu, sh) in norm)
    if contrib_mix_u <= 0:
        return {"be_qty_total": None, "be_revenue": None, "mc_rate_mix": 0.0, "per_sku_qty": []}

    be_qty_total = float(costi_fissi) / contrib_mix_u
    p_avg = sum(sh * p for (p, _, sh) in norm)
    be_revenue = be_qty_total * p_avg
    mc_rate_mix = safe_div(contrib_mix_u, p_avg, 0.0)

    per_sku_qty = [{"p": p, "cvu": cvu, "share": sh, "qty": be_qty_total * sh} for (p, cvu, sh) in norm]

    return {
        "be_qty_total": max(0.0, be_qty_total),
        "be_revenue": max(0.0, be_revenue),
        "mc_rate_mix": max(0.0, min(1.0, mc_rate_mix)),
        "per_sku_qty": per_sku_qty,
    }


# -----------------------------
# 4) Ladder / scenari di mix
# -----------------------------
def breakeven_ladder_mix(
    costi_fissi: float,
    ladders: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Valuta una serie di scenari (ladder) con mix e prezzi diversi.
    Ogni scenario è un dict:
      {
        "label": "Sconto -5%",
        "mix": [
            {"p": 44.0, "cvu": 28.0, "share": 0.6},
            {"p": 52.0, "cvu": 31.0, "share": 0.4},
        ]
      }
    Ritorna una lista con i risultati BE per ogni scenario.
    """
    out: List[Dict[str, Any]] = []
    for scen in ladders or []:
        label = str(scen.get("label", "scenario"))
        mix = scen.get("mix", []) or []
        res = breakeven_mix(costi_fissi, mix)
        out.append({
            "label": label,
            **res
        })
    return out
