# content/tools/pricing.py
from __future__ import annotations
from typing import Dict, List, Tuple, Optional
from math import log, isfinite

# -----------------------------
# Elasticità (2–3 punti)
# -----------------------------
def estimate_elasticity(points: List[Tuple[float, float]], *, fallback: float = -1.2) -> float:
    """
    Stima elasticità prezzo→quantità da >=2 punti (p, q) via regressione log-log:
      ln q = a + b ln p  =>  elasticità ≈ b  (attesa negativa)
    - Pulisce dati (p>0, q>0), deduplica per (p,q).
    - Fallback su valore prudente se dati insufficienti.
    - Clamp in range ragionevole [-6.0, -0.05] per evitare outlier instabili.
    """
    pts = []
    seen = set()
    for p, q in points or []:
        try:
            pp, qq = float(p), float(q)
            if pp > 0 and qq > 0 and isfinite(pp) and isfinite(qq):
                key = (round(pp, 8), round(qq, 8))
                if key not in seen:
                    pts.append((pp, qq))
                    seen.add(key)
        except Exception:
            continue

    if len(pts) < 2:
        return float(fallback)

    xs = [log(p) for p, _ in pts]
    ys = [log(q) for _, q in pts]
    n = float(len(pts))
    xm = sum(xs) / n
    ym = sum(ys) / n
    num = sum((x - xm) * (y - ym) for x, y in zip(xs, ys))
    den = sum((x - xm) * (x - xm) for x in xs) or 1.0
    b = num / den  # elasticità

    # clamp prudente per stabilità
    if not isfinite(b):
        b = float(fallback)
    b = max(-6.0, min(-0.05, float(b)))
    return b


# -----------------------------
# Ladder prezzi con vincoli
# -----------------------------
def price_ladder(
    base_price: float,
    base_revenue: float,
    cost_var_unit: float,
    fixed_costs: float,
    elasticity: float = -1.2,
    range_pct: float = 10.0,
    step_pct: float = 2.0,
    max_discount_pct: float | None = None,
    max_qty_loss_pct: float | None = None,
    *,
    max_markup_pct: float | None = None,
    min_unit_contrib: float | None = 0.0,
    min_margin_rate: float | None = None,  # può essere frazione (0..1) o % (0..100)
) -> List[Dict[str, float]]:
    """
    Genera scenari su ±range con step e calcola quantità, ricavi, margine e utile.
    Vincoli opzionali:
      - max_discount_pct: sconto massimo consentito (es. 15)
      - max_qty_loss_pct: perdita massima di quantità vs base (es. 20)
      - max_markup_pct: aumento massimo consentito del prezzo (es. 15)
      - min_unit_contrib: margine unitario minimo (p - cvu >= soglia)
      - min_margin_rate: MC% minimo sullo scenario (fra 0..1 o 0..100)

    Ordinamento: per profitto decrescente. Ogni scenario include:
      {pct, price, quantity, revenue, profit, mc, mc_rate}
    """
    try:
        p0 = float(base_price)
        fatt = float(base_revenue)
        cvu = float(cost_var_unit)
        cf = float(fixed_costs)
        el = float(elasticity)
    except Exception:
        return []

    if p0 <= 0.0 or fatt < 0.0:
        return []

    q0 = fatt / p0 if p0 > 0 else 0.0
    if q0 < 0:
        q0 = 0.0

    # normalizza min_margin_rate: accetta 0..1 o 0..100
    mmr = None
    if min_margin_rate is not None:
        try:
            mmr = float(min_margin_rate)
            if mmr > 1.0:  # interpretato come %
                mmr = mmr / 100.0
            mmr = max(0.0, min(0.99, mmr))
        except Exception:
            mmr = None

    lo = -abs(range_pct)
    hi = abs(range_pct)
    step = abs(step_pct) if step_pct not in (None, 0) else 1.0

    def _frange(start: float, stop: float, step: float):
        x = float(start)
        while x <= stop + 1e-12:
            yield round(x, 4)
            x += step

    out: List[Dict[str, float]] = []
    for pct in _frange(lo, hi, step):
        # rispetta vincoli su sconto/aumento
        if max_discount_pct is not None and pct < -abs(max_discount_pct):
            continue
        if max_markup_pct is not None and pct > abs(max_markup_pct):
            continue

        p = p0 * (1.0 + pct / 100.0)
        if p <= 0:
            continue
        q = q0 * (1.0 + el * (pct / 100.0))
        if q < 0:
            q = 0.0

        # vincolo perdita quantità
        if max_qty_loss_pct is not None and q0 > 0:
            loss_pct = (1.0 - (q / q0)) * 100.0
            if loss_pct > abs(max_qty_loss_pct):
                continue

        # vincolo margine unitario
        unit_contrib = p - cvu
        if min_unit_contrib is not None and unit_contrib < float(min_unit_contrib):
            continue

        revenue = p * q
        mc = unit_contrib * q
        mc_rate = (mc / revenue) if revenue > 0 else 0.0

        # vincolo MC% minimo
        if mmr is not None and mc_rate < mmr:
            continue

        profit = mc - cf
        out.append(
            {
                "pct": float(pct),
                "price": float(p),
                "quantity": float(q),
                "revenue": float(revenue),
                "mc": float(mc),
                "mc_rate": float(max(0.0, min(1.0, mc_rate))),
                "profit": float(profit),
            }
        )

    out.sort(key=lambda x: x["profit"], reverse=True)
    return out


# -----------------------------
# Scelta best scenario + nota
# -----------------------------
def ladder_best(
    base_price: float,
    base_revenue: float,
    cost_var_unit: float,
    fixed_costs: float,
    elasticity: float = -1.2,
    **kwargs,
) -> Dict[str, float | str]:
    """
    Restituisce lo scenario con profitto massimo e una nota diagnostica.
    kwargs passati a price_ladder (vincoli etc.).
    """
    ladder = price_ladder(
        base_price=base_price,
        base_revenue=base_revenue,
        cost_var_unit=cost_var_unit,
        fixed_costs=fixed_costs,
        elasticity=elasticity,
        **kwargs,
    )
    if not ladder:
        return {"note": "Nessuno scenario ammissibile con i vincoli correnti."}
    best = ladder[0].copy()
    note = (
        f"Best @ {best['pct']:.1f}% → prezzo {best['price']:.2f}, utile {best['profit']:.0f}, "
        f"MC-rate {best['mc_rate']*100:.1f}%, ricavi {best['revenue']:.0f}."
    )
    best["note"] = note
    return best


# -----------------------------
# range helper (retro-compat)
# -----------------------------
def frange(start: float, stop: float, step: float):
    x = float(start)
    if step is None or step <= 0:
        yield round(x, 4)
        return
    while x <= float(stop) + 1e-12:
        yield round(x, 4)
        x += float(step)
