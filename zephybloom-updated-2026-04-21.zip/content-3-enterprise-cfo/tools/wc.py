# -*- coding: utf-8 -*-
# content/tools/wc.py — CCC what-if + optimizer (scalato)
from __future__ import annotations
from typing import Dict, Any, Tuple, List, Optional
import math

from core.validators import normalize_context_numeric


# -----------------------------
# Helpers numerici sicuri
# -----------------------------
def _f(x: Any) -> float:
    try:
        xf = float(x)
        return xf if math.isfinite(xf) else 0.0
    except Exception:
        return 0.0


def _wc_need(_sales: float, _cogs: float, _dso: float, _dio: float, _dpo: float) -> float:
    """
    Approssimazione del fabbisogno CC:
      WC ≈ AR + Inventory − AP
      AR ≈ sales * DSO / 365
      Inventory ≈ cogs * DIO / 365
      AP ≈ cogs * DPO / 365
    """
    ar = _sales * (_dso / 365.0)
    inv = _cogs * (_dio / 365.0)
    ap = _cogs * (_dpo / 365.0)
    return float(ar + inv - ap)


def _sanitize(base: Dict[str, Any]) -> Tuple[float, float, float, float, float]:
    b = normalize_context_numeric(base or {})
    sales = _f(b.get("fatturato"))
    cogs = _f(b.get("costi_variabili"))  # proxy acquisti
    dso = _f(b.get("dso"))
    dio = _f(b.get("dio"))
    dpo = _f(b.get("dpo"))
    return sales, cogs, dso, dio, dpo


# -----------------------------
# What-if classico (retro-compat)
# -----------------------------
def wc_whatif_tool(base: Dict[str, float]) -> Dict[str, Any]:
    """
    Calcola l'impatto di variazioni DSO/DIO/DPO su CCC e fabbisogno capitale circolante.
    Input attesi in base: fatturato, costi_variabili, dso, dio, dpo (+ opzionali: dso_delta, dio_delta, dpo_delta).
    Ritorna: ccc_before, ccc_after, delta_ccc, wc_need_before/after, delta_cash, ccc(alias).
    """
    sales, cogs, dso, dio, dpo = _sanitize(base)

    # delta opzionali (in giorni, possono essere negativi/positivi)
    ddso = _f(base.get("dso_delta"))
    ddio = _f(base.get("dio_delta"))
    ddpo = _f(base.get("dpo_delta"))

    ccc_before = dso + dio - dpo
    ccc_after = (dso + ddso) + (dio + ddio) - (dpo + ddpo)
    delta_ccc = ccc_after - ccc_before

    need_before = _wc_need(sales, cogs, dso, dio, dpo)
    need_after = _wc_need(sales, cogs, dso + ddso, dio + ddio, dpo + ddpo)
    delta_cash = need_after - need_before  # >0 = più capitale impegnato; <0 = cassa liberata

    return {
        "ccc_before": float(ccc_before),
        "ccc_after": float(ccc_after),
        "delta_ccc": float(delta_ccc),
        "wc_need_before": float(need_before),
        "wc_need_after": float(need_after),
        "delta_cash": float(delta_cash),
        # alias storico
        "ccc": float(ccc_after),
    }


# -----------------------------
# Ottimizzatore CCC (greedy)
# -----------------------------
def optimize_ccc(
    base: Dict[str, Any],
    target_days: float,
    *,
    levers: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """
    Trova un piano semplice per raggiungere un CCC target (in giorni) agendo su DSO/DIO/DPO.
    Strategia greedy: priorizza le leve con maggior impatto cassa per giorno (€/day).

    Parametri:
      base          : dict con fatturato, costi_variabili, dso, dio, dpo
      target_days   : CCC obiettivo (giorni)
      levers        : vincoli massimi (giorni), default prudente
                      {
                        "max_dso_reduction": 15,
                        "max_dio_reduction": 20,
                        "max_dpo_increase": 15
                      }

    Ritorna:
      {
        "ccc_before", "ccc_target", "ccc_after",
        "deltas": {"dso_delta": ..., "dio_delta": ..., "dpo_delta": ...},
        "wc_need_before", "wc_need_after", "delta_cash",
        "steps": [azioni suggerite...]
      }
    """
    sales, cogs, dso, dio, dpo = _sanitize(base)

    ccc_before = dso + dio - dpo
    target = float(target_days)
    # se target > before → peggioramento, non ha senso ottimizzare verso l'alto
    if target >= ccc_before:
        return {
            "ccc_before": float(ccc_before),
            "ccc_target": float(target),
            "ccc_after": float(ccc_before),
            "deltas": {"dso_delta": 0.0, "dio_delta": 0.0, "dpo_delta": 0.0},
            "wc_need_before": _wc_need(sales, cogs, dso, dio, dpo),
            "wc_need_after": _wc_need(sales, cogs, dso, dio, dpo),
            "delta_cash": 0.0,
            "steps": ["Il target è ≥ al CCC attuale: nessuna ottimizzazione necessaria."],
        }

    need_reduction = ccc_before - target  # giorni da ridurre
    # vincoli default
    lv = {
        "max_dso_reduction": 15.0,
        "max_dio_reduction": 20.0,
        "max_dpo_increase": 15.0,
    }
    if isinstance(levers, dict):
        for k in lv.keys():
            if k in levers and isinstance(levers[k], (int, float)):
                lv[k] = float(levers[k])

    # impatto cassa per 1 giorno di leva
    # ridurre DSO di 1g libera sales/365
    # ridurre DIO di 1g libera cogs/365
    # aumentare DPO di 1g libera cogs/365
    cash_per_day = {
        "dso": sales / 365.0,
        "dio": cogs / 365.0,
        "dpo": cogs / 365.0,
    }

    # ordina leve per € / day (decrescente)
    order = sorted(
        ["dso", "dio", "dpo"],
        key=lambda k: cash_per_day.get(k, 0.0),
        reverse=True,
    )

    # capacità massime per leva (in giorni)
    caps = {
        "dso": max(0.0, lv["max_dso_reduction"]),
        "dio": max(0.0, lv["max_dio_reduction"]),
        "dpo": max(0.0, lv["max_dpo_increase"]),
    }

    chosen = {"dso": 0.0, "dio": 0.0, "dpo": 0.0}
    remaining = float(need_reduction)

    for k in order:
        if remaining <= 0.0:
            break
        cap = caps[k]
        if cap <= 0:
            continue
        take = min(cap, remaining)
        chosen[k] = take
        remaining -= take

    # Applica deltas: DSO -= chosen["dso"]; DIO -= chosen["dio"]; DPO += chosen["dpo"]
    ddso = -chosen["dso"]
    ddio = -chosen["dio"]
    ddpo = +chosen["dpo"]

    ccc_after = (dso + ddso) + (dio + ddio) - (dpo + ddpo)
    # clamp per non scendere sotto target di più di 0.1 giorni (rumore)
    if ccc_after < target - 0.1:
        # ricalcola riducendo l'ultima leva usata
        overshoot = target - ccc_after
        # trova l'ultima leva applicata (quella a cash per day minore tra quelle non zero)
        used = [(k, chosen[k], cash_per_day[k]) for k in chosen if chosen[k] > 0]
        if used:
            last = sorted(used, key=lambda t: t[2])[0][0]
            if last == "dso":
                ddso += overshoot
            elif last == "dio":
                ddio += overshoot
            else:
                ddpo -= overshoot
            ccc_after = (dso + ddso) + (dio + ddio) - (dpo + ddpo)

    need_before = _wc_need(sales, cogs, dso, dio, dpo)
    need_after = _wc_need(sales, cogs, dso + ddso, dio + ddio, dpo + ddpo)
    delta_cash = need_after - need_before  # <0 → cassa liberata

    # Suggerimenti operativi per ciascuna leva
    steps: List[str] = []
    if chosen["dso"] > 0:
        steps += [
            "Riduci DSO: fatturazione elettronica tempestiva, reminder automatici, policy credito.",
            "Offri sconti incasso anticipato (1–2%) su clienti selezionati (valuta ROI vs costo).",
            "Fatturazione milestone/acconti su progetti per anticipare AR.",
        ]
    if chosen["dio"] > 0:
        steps += [
            "Riduci DIO: ABC/XYZ e scorte minime per top SKU; Kanban e reorder point rivisti.",
            "Svuota slow-movers/obsolescenza con promo mirate; ottimizza lotti d’acquisto.",
            "Collaborazione fornitori per lead time più stabili e minori safety stock.",
        ]
    if chosen["dpo"] > 0:
        steps += [
            "Aumenta DPO: negozia +7/+15 giorni con fornitori strategici (senza penalità).",
            "Consolida volumi su pochi fornitori per avere potere negoziale; evita late fees.",
            "Valuta dynamic discounting (anticipi quando conviene, altrimenti estendi termini).",
        ]
    if not steps:
        steps = ["Nessuna azione proposta: vincoli troppo stringenti o target già raggiunto."]

    return {
        "ccc_before": float(ccc_before),
        "ccc_target": float(target),
        "ccc_after": float(ccc_after),
        "deltas": {
            "dso_delta": float(ddso),
            "dio_delta": float(ddio),
            "dpo_delta": float(ddpo),
        },
        "wc_need_before": float(need_before),
        "wc_need_after": float(need_after),
        "delta_cash": float(delta_cash),
        "steps": steps,
    }
