#!/bin/bash

###############################################################################
# ZephyBloom Beta - Complete Launch (All terminals)
# 
# This script manages BOTH backend and frontend in the background
# and generates credentials automatically
###############################################################################

set -e

PROJECT_ROOT="/Users/thestar23/Downloads/content-3-enterprise-cfo"
cd "$PROJECT_ROOT"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  ZephyBloom CFO BETA - Complete Launch                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# Step 1: Start Backend
echo -e "${YELLOW}Starting Backend Server...${NC}"
./START_APP.sh > /tmp/backend.log 2>&1 &
BACKEND_PID=$!
echo -e "${GREEN}✓ Backend started (PID: $BACKEND_PID)${NC}"

# Wait for backend to be ready
echo -e "${YELLOW}Waiting for backend to initialize...${NC}"
for i in {1..30}; do
    if curl -s http://localhost:8001/health > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Backend ready${NC}"
        break
    fi
    sleep 1
done

# Step 2: Start Frontend
echo -e "${YELLOW}Starting Frontend Server...${NC}"
cd frontend_react

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}Installing npm dependencies...${NC}"
    npm install --silent
fi

# Create .env if missing
if [ ! -f ".env" ]; then
    cp .env.example .env
fi

npm start > /tmp/frontend.log 2>&1 &
FRONTEND_PID=$!
echo -e "${GREEN}✓ Frontend started (PID: $FRONTEND_PID)${NC}"

cd "$PROJECT_ROOT"

# Wait for frontend
echo -e "${YELLOW}Waiting for frontend to initialize...${NC}"
sleep 10
echo -e "${GREEN}✓ Frontend ready${NC}"

# Step 3: Create accounts
echo -e "${YELLOW}Creating 10 beta accounts...${NC}"

declare -a ACCOUNTS=(
    "mario@acmeinc.it|Acme Inc|Manufacturing"
    "sara@techspa.it|TechSPA|SaaS"
    "luca@retail.it|RetailCo|Retail"
    "francesca@logistics.it|LogisticsPro|Logistics"
    "giovanni@consulting.it|ConsultingHub|Services"
    "elena@manufacturing.it|ManufacturePro|Manufacturing"
    "marco@ecommerce.it|EcommerceHub|Retail"
    "camilla@digital.it|DigitalAgency|SaaS"
    "andrea@finance.it|FinanceGroup|Services"
    "giulia@startup.it|StartupIO|SaaS"
)

CREDS_FILE="BETA_CREDENTIALS.txt"
> "$CREDS_FILE"

echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "ZephyBloom CFO - Beta Access Credentials" >> "$CREDS_FILE"
echo "Generated: $(date)" >> "$CREDS_FILE"
echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"
echo "🌐 Application URL:" >> "$CREDS_FILE"
echo "   http://localhost:3000" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"
echo "ℹ️  First time users MUST change password after login" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"
echo "📋 Beta Test Accounts:" >> "$CREDS_FILE"
echo "═════════════════════════════════════════════════════════" >> "$CREDS_FILE"
echo "" >> "$CREDS_FILE"

COUNT=0
for ACCOUNT in "${ACCOUNTS[@]}"; do
    IFS='|' read -r EMAIL COMPANY SECTOR <<< "$ACCOUNT"
    COUNT=$((COUNT + 1))
    
    python3 scripts/create_pilot_user.py \
        --email "$EMAIL" \
        --company "$COMPANY" \
        --sector "$SECTOR" > /tmp/user_creation.log 2>&1
    
    TEMP_PASSWORD=$(grep "Temporary Password:" /tmp/user_creation.log 2>/dev/null | tail -1 | awk '{print $NF}')
    
    if [ -z "$TEMP_PASSWORD" ]; then
        TEMP_PASSWORD="[Generate new password]"
    fi
    
    echo "Account #$COUNT" >> "$CREDS_FILE"
    echo "───────────────────────────────────────────────────────" >> "$CREDS_FILE"
    echo "Name:             $COMPANY" >> "$CREDS_FILE"
    echo "Email:            $EMAIL" >> "$CREDS_FILE"
    echo "Sector:           $SECTOR" >> "$CREDS_FILE"
    echo "Temp Password:    $TEMP_PASSWORD" >> "$CREDS_FILE"
    echo "First Action:     Change password on login" >> "$CREDS_FILE"
    echo "" >> "$CREDS_FILE"
done

echo -e "${GREEN}✓ Created 10 beta accounts${NC}"

# Output final status
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ ZephyBloom CFO Beta is LIVE!${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  🌐 Web App:          ${BLUE}http://localhost:3000${NC}"
echo -e "  📡 API Backend:      ${BLUE}http://localhost:8001${NC}"
echo -e "  📊 API Docs:         ${BLUE}http://localhost:8001/docs${NC}"
echo ""
echo -e "  📋 Credentials:      ${BLUE}BETA_CREDENTIALS.txt${NC}"
echo ""
echo -e "  Backend PID:         $BACKEND_PID"
echo -e "  Frontend PID:        $FRONTEND_PID"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo ""
echo "📝 Next Steps:"
echo "   1. Go to http://localhost:3000 in your browser"
echo "   2. Test login with first account"
echo "   3. Send BETA_CREDENTIALS.txt to your 10 beta testers"
echo ""
echo "🛑 To stop everything:"
echo "   kill $BACKEND_PID $FRONTEND_PID"
echo ""

# Keep this process alive
wait
