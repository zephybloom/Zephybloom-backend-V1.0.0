"""Add War Room decision memory table.

Created: 2026-04-20
"""

from alembic import op
import sqlalchemy as sa


revision = "002_war_room_decision_memory"
down_revision = "001_initial_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "war_room_decision_memory",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("decision_id", sa.String(128), nullable=False),
        sa.Column("source", sa.String(50), nullable=False, server_default="war_room"),
        sa.Column("sector", sa.String(100), nullable=True),
        sa.Column("decision_type", sa.String(100), nullable=True),
        sa.Column("rank", sa.Integer(), nullable=True),
        sa.Column("owner", sa.String(255), nullable=True),
        sa.Column("status", sa.String(50), nullable=False, server_default="todo"),
        sa.Column("decision", sa.Text(), nullable=True),
        sa.Column("next_action", sa.Text(), nullable=True),
        sa.Column("success_metric_json", sa.Text(), nullable=True),
        sa.Column("evidence_needed_json", sa.Text(), nullable=True),
        sa.Column("follow_up_question", sa.Text(), nullable=True),
        sa.Column("expected_impact_eur", sa.Float(), nullable=True),
        sa.Column("actual_impact_eur", sa.Float(), nullable=True),
        sa.Column("outcome_review_json", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id", "decision_id", name="uq_war_room_decision_tenant_decision"),
    )
    op.create_index("ix_war_room_decision_memory_tenant_id", "war_room_decision_memory", ["tenant_id"])
    op.create_index("ix_war_room_decision_memory_decision_id", "war_room_decision_memory", ["decision_id"])
    op.create_index("ix_war_room_decision_memory_sector", "war_room_decision_memory", ["sector"])
    op.create_index("ix_war_room_decision_memory_decision_type", "war_room_decision_memory", ["decision_type"])
    op.create_index("ix_war_room_decision_memory_status", "war_room_decision_memory", ["status"])
    op.create_index("idx_war_room_decision_tenant_status", "war_room_decision_memory", ["tenant_id", "status"])
    op.create_index("idx_war_room_decision_tenant_sector", "war_room_decision_memory", ["tenant_id", "sector"])


def downgrade() -> None:
    op.drop_index("idx_war_room_decision_tenant_sector", table_name="war_room_decision_memory")
    op.drop_index("idx_war_room_decision_tenant_status", table_name="war_room_decision_memory")
    op.drop_index("ix_war_room_decision_memory_status", table_name="war_room_decision_memory")
    op.drop_index("ix_war_room_decision_memory_decision_type", table_name="war_room_decision_memory")
    op.drop_index("ix_war_room_decision_memory_sector", table_name="war_room_decision_memory")
    op.drop_index("ix_war_room_decision_memory_decision_id", table_name="war_room_decision_memory")
    op.drop_index("ix_war_room_decision_memory_tenant_id", table_name="war_room_decision_memory")
    op.drop_table("war_room_decision_memory")
