"""Add persistent company data room snapshots.

Revision ID: 003_company_data_room_snapshots
Revises: 002_war_room_decision_memory
Create Date: 2026-04-20
"""

from alembic import op
import sqlalchemy as sa


revision = "003_company_data_room_snapshots"
down_revision = "002_war_room_decision_memory"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "company_data_room_snapshots",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("company_id", sa.String(length=128), nullable=False),
        sa.Column("company_name", sa.String(length=255), nullable=False),
        sa.Column("active_sector", sa.String(length=100), nullable=True),
        sa.Column("company_data_json", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("operational_data_by_sector_json", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("import_summary_json", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.UniqueConstraint("tenant_id", "company_id", name="uq_data_room_tenant_company"),
    )
    op.create_index("idx_data_room_tenant_company", "company_data_room_snapshots", ["tenant_id", "company_id"])
    op.create_index("idx_data_room_tenant_sector", "company_data_room_snapshots", ["tenant_id", "active_sector"])
    op.create_table(
        "company_data_room_snapshot_history",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("company_id", sa.String(length=128), nullable=False),
        sa.Column("company_name", sa.String(length=255), nullable=False),
        sa.Column("active_sector", sa.String(length=100), nullable=True),
        sa.Column("company_data_json", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("operational_data_by_sector_json", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("import_summary_json", sa.Text(), nullable=True),
        sa.Column("readiness_score_pct", sa.Float(), nullable=True),
        sa.Column("sector_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("row_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("change_reason", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
    )
    op.create_index("idx_data_room_history_tenant_company", "company_data_room_snapshot_history", ["tenant_id", "company_id"])
    op.create_index("idx_data_room_history_created", "company_data_room_snapshot_history", ["created_at"])


def downgrade() -> None:
    op.drop_index("idx_data_room_history_created", table_name="company_data_room_snapshot_history")
    op.drop_index("idx_data_room_history_tenant_company", table_name="company_data_room_snapshot_history")
    op.drop_table("company_data_room_snapshot_history")
    op.drop_index("idx_data_room_tenant_sector", table_name="company_data_room_snapshots")
    op.drop_index("idx_data_room_tenant_company", table_name="company_data_room_snapshots")
    op.drop_table("company_data_room_snapshots")
