"""
Initial database migration - Create core tables.

Created: 2026-04-14
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic
revision = "001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create initial tables."""
    # Users table
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(255), nullable=True),
        sa.Column("role", sa.String(50), nullable=False, server_default="user"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("email"),
    )
    op.create_index("idx_user_email", "users", ["email"])
    op.create_index("idx_user_active", "users", ["is_active"])

    # Tenants table
    op.create_table(
        "tenants",
        sa.Column("id", sa.String(128), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("owner_id", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_tenant_active", "tenants", ["is_active"])
    op.create_index("idx_tenant_owner", "tenants", ["owner_id"])

    # API Keys table
    op.create_table(
        "api_keys",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(255), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("rate_limit_per_minute", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("key"),
    )
    op.create_index("idx_apikey_active", "api_keys", ["is_active"])
    op.create_index("idx_apikey_tenant", "api_keys", ["tenant_id"])
    op.create_index("idx_apikey_user", "api_keys", ["user_id"])

    # Audit Logs table
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("tenant_id", sa.String(128), nullable=True),
        sa.Column("api_key_id", sa.Integer(), nullable=True),
        sa.Column("endpoint", sa.String(255), nullable=False),
        sa.Column("method", sa.String(10), nullable=False),
        sa.Column("status_code", sa.Integer(), nullable=False),
        sa.Column("response_time_ms", sa.Integer(), nullable=False),
        sa.Column("request_details", sa.Text(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("user_agent", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["api_key_id"], ["api_keys.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_auditlog_action", "audit_logs", ["action"])
    op.create_index("idx_auditlog_tenant", "audit_logs", ["tenant_id"])
    op.create_index("idx_auditlog_user", "audit_logs", ["user_id"])
    op.create_index("idx_auditlog_timestamp", "audit_logs", ["created_at"])
    op.create_index("idx_auditlog_endpoint", "audit_logs", ["endpoint"])

    # Tenant Settings table
    op.create_table(
        "tenant_settings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("rate_limit_per_minute", sa.Integer(), nullable=False, server_default="1000"),
        sa.Column("max_concurrent_requests", sa.Integer(), nullable=False, server_default="50"),
        sa.Column("enable_kpi_engine", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("enable_simulation", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("enable_valuation", sa.Boolean(), nullable=False, server_default="1"),
        sa.Column("max_request_size_mb", sa.Integer(), nullable=False, server_default="10"),
        sa.Column("data_retention_days", sa.Integer(), nullable=False, server_default="90"),
        sa.Column("metadata", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id"),
    )
    op.create_index("idx_tenantsettings_tenant", "tenant_settings", ["tenant_id"])


def downgrade() -> None:
    """Drop all tables."""
    op.drop_table("tenant_settings")
    op.drop_table("audit_logs")
    op.drop_table("api_keys")
    op.drop_table("tenants")
    op.drop_table("users")
