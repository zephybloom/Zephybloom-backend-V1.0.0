"""
Alembic migration setup for database versioning.

Initialize with:
  alembic init -t async alembic
Then configure alembic/env.py to use SQLAlchemy models.
"""

"""
Alembic configuration for ZephyBloom database migrations.

Usage:
  # Create a new migration
  alembic revision --autogenerate -m "Add users table"

  # Apply migrations to database
  alembic upgrade head

  # Downgrade to previous version
  alembic downgrade -1

  # View migration history
  alembic history
"""

import os
import sys
from logging.config import fileConfig
from pathlib import Path

# Add parent directory to path so we can import modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import engine_from_config
from sqlalchemy import pool
from alembic import context

# Import models for autogenerate
from db.models import Base

# this is the Alembic Config object
config = context.config

# Interpret the config file for Python logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Set SQLAlchemy database URL from environment or config
sqlalchemy_url = os.getenv(
    "DATABASE_URL",
    "sqlite:///./zephytheory.db",
)
if not sqlalchemy_url:
    raise RuntimeError("DATABASE_URL environment variable not set")

config.set_main_option("sqlalchemy.url", sqlalchemy_url)

# Set the target metadata for 'autogenerate' support
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
