"""
Quick test of AI integration with mock provider
Run: python3 test_ai_integration.py
"""

from infra.ai_provider import MockCFOGPTProvider, CFOAnalysisAI

def test_mock_provider():
    """Test the mock AI provider returns correct structure"""
    print("🧪 Testing Mock CFO Provider...")
    
    provider = MockCFOGPTProvider()
    
    company_data = {
        "company_name": "Acme Manufacturing",
        "settore": "Manufacturing",
        "company_size": "Large",
        "fatturato": 5_000_000,
        "costi_variabili": 2_100_000,
        "costi_fissi": 1_500_000,
        "investimenti": 500_000,
        "gross_profit": 2_900_000,
        "gross_margin_pct": 58.0,
        "ebitda": 1_400_000,
        "ebitda_margin_pct": 28.0,
        "net_profit": 900_000,
        "net_margin_pct": 18.0,
        "roi_pct": 180.0,
    }
    
    response = provider.analyze(company_data)
    
    print("\n📊 AI RESPONSE STRUCTURE:")
    print(f"  - Key Number: {response.key_number[:60]}...")
    print(f"  - Headline: {response.headline}")
    print(f"  - Diagnostic: {response.diagnostic[:80]}...")
    print(f"  - Risk Assessment: {response.risk_assessment[:80]}...")
    print(f"  - Priority Action: {response.priority_action[:80]}...")
    print(f"  - Other Actions: {len(response.other_actions)} items")
    print(f"  - Estimated Impact: {response.estimated_impact[:60]}...")
    print(f"  - Strategic Advice: {response.strategic_advice[:80]}...")
    
    # Test dict conversion
    response_dict = response.to_dict()
    print("\n✅ Dict conversion successful")
    print(f"  Response has {len(response_dict)} fields")
    
    # Test formatted text
    formatted = response.to_formatted_text()
    print("\n📄 Formatted Response:")
    print("=" * 60)
    print(formatted)
    print("=" * 60)
    
    print("\n✅ Mock Provider Test PASSED\n")
    return True


def test_api_endpoint_structure():
    """Test that the response structure matches API expectations"""
    print("🧪 Testing API Response Structure...")
    
    # Build sample request
    from api.schemas_cfo import AnalyzeRequest
    
    request = AnalyzeRequest(
        fatturato=5_000_000,
        costi_variabili=2_100_000,
        costi_fissi=1_500_000,
        investimenti=500_000,
        settore="manufacturing",
        company_name="Test Company"
    )
    
    print(f"✅ Request created: {request.company_name}")
    print(f"  - Fatturato: €{request.fatturato:,.0f}")
    print(f"  - Costi Variabili: €{request.costi_variabili:,.0f}")
    print(f"  - Costi Fissi: €{request.costi_fissi:,.0f}")
    
    print("\n✅ API Request Structure Test PASSED\n")
    return True


if __name__ == "__main__":
    print("\n🚀 ZephyBloom AI Integration Tests\n")
    
    try:
        test_mock_provider()
        test_api_endpoint_structure()
        print("=" * 60)
        print("✅ ALL TESTS PASSED!")
        print("=" * 60)
        print("\n📝 Next steps:")
        print("1. Set OPENAI_API_KEY environment variable")
        print("2. Test /cfo/ai-analyze endpoint with POST request")
        print("3. Add use_mock=true parameter to test without API key\n")
    except Exception as e:
        print(f"❌ TEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
