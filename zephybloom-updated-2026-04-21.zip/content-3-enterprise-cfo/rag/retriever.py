# content/rag/retriever.py
from __future__ import annotations
from typing import Any, Callable, Dict, List, Tuple, Optional
from pathlib import Path
import json
import math
import logging

# Usiamo utilità dall'indexer (stesso package)
from rag.indexer import (
    ensure_vector_backend,
    InMemoryIndex,
    NoopIndex,
    _hash_vec,  # embedding deterministico per query (compat con dump/backends)
)

logger = logging.getLogger(__name__)

# ------------------------------------------------------------
# Cosine tra vettori densi (liste float)
# ------------------------------------------------------------
def _cosine(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    # a e b dovrebbero essere già normalizzate (vedi _hash_vec), ma ricalcoliamo in sicurezza
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return dot / (na * nb)

# ------------------------------------------------------------
# Lettura indice JSON (dump da InMemoryIndex)
# ------------------------------------------------------------
def _load_json_index(path: str = "content/rag/indexes/index.json") -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {"chunks": [], "backend": "", "dim": 0}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Impossibile leggere indice JSON %s: %s", path, e)
        return {"chunks": [], "backend": "", "dim": 0}

# ------------------------------------------------------------
# Ricerca via backend in memoria (preferita se disponibile)
# ------------------------------------------------------------
def _search_inmemory(query: str, k: int) -> List[Dict[str, Any]]:
    idx = ensure_vector_backend(force=False)
    if isinstance(idx, NoopIndex):
        return []
    if not isinstance(idx, InMemoryIndex):
        # es. backend Qdrant con API di ricerca lato indexer; qui potremmo aggiungere un pass-through
        try:
            return idx.search(query, k=k)  # type: ignore[attr-defined]
        except Exception:
            return []

    # InMemoryIndex: chunks con 'vec' precomputato
    qv = _hash_vec(query or "")
    scored: List[Tuple[float, Dict[str, Any]]] = []
    for it in getattr(idx, "_chunks", []):
        s = _cosine(qv, it.get("vec", []))
        scored.append((s, it))
    scored.sort(key=lambda t: t[0], reverse=True)

    out: List[Dict[str, Any]] = []
    for s, it in scored[:max(1, k)]:
        out.append({
            "doc_id": it.get("doc_id"),
            "chunk_id": it.get("chunk_id"),
            "title": it.get("title"),
            "url": it.get("url"),
            "text": it.get("text", ""),
            "score": float(s),
            "meta": it.get("meta", {}),
        })
    return out

# ------------------------------------------------------------
# Ricerca su dump JSON (fallback)
#   - backend: "memory-hash" → usa _hash_vec per la query
#   - backend: "llm-emb" (futuro) → richiede embed_fn per la query
# ------------------------------------------------------------
def _search_json(query: str, k: int, *, index_path: str, embed_fn: Optional[Callable[[str], List[float]]] = None) -> List[Dict[str, Any]]:
    data = _load_json_index(index_path)
    chunks = data.get("chunks", [])
    backend = (data.get("backend") or "").lower()

    if backend in ("memory-hash", "", None):
        qv = _hash_vec(query or "")
    else:
        if embed_fn is None:
            # Se in futuro salvi un indice con embeddings LLM, devi passare un embed_fn compatibile
            raise ValueError("Indice JSON non hash-based: fornisci embed_fn per trasformare la query.")
        qv = embed_fn(query or "")

    scored: List[Tuple[float, Dict[str, Any]]] = []
    for ch in chunks:
        v = ch.get("vec", [])
        if not isinstance(v, list) or not v:
            continue
        s = _cosine(qv, v)
        scored.append((s, ch))
    scored.sort(key=lambda t: t[0], reverse=True)

    out: List[Dict[str, Any]] = []
    for s, ch in scored[:max(1, k)]:
        out.append({
            "doc_id": ch.get("doc_id"),
            "chunk_id": ch.get("chunk_id"),
            "title": ch.get("title"),
            "url": ch.get("url"),
            "text": ch.get("text", ""),
            "score": float(s),
            "meta": ch.get("meta", {}),
        })
    return out

# ------------------------------------------------------------
# API pubblica
#   - prova backend in-memory (o qdrant pass-through)
#   - se vuoto, fallback al dump JSON
#   - opzionale: embed_fn per indici non hash-based
# ------------------------------------------------------------
def retrieve(
    query: str,
    *,
    top_k: int = 5,
    index_json_path: str = "content/rag/indexes/index.json",
    embed_fn: Optional[Callable[[str], List[float]]] = None,
) -> List[Dict[str, Any]]:
    """
    Ritorna: [{"doc_id","chunk_id","title","url","text","score","meta"} ...]
    Ordine: score decrescente.
    """
    # 1) backend live (InMemory o altro con .search)
    try:
        hits = _search_inmemory(query, k=top_k)
        if hits:
            return hits
    except Exception as e:
        logger.debug("Backend in-memory non disponibile (%s), passo al dump JSON.", e)

    # 2) fallback al dump JSON
    try:
        return _search_json(query, k=top_k, index_path=index_json_path, embed_fn=embed_fn)
    except Exception as e:
        logger.warning("Fallback JSON retrieval fallito: %s", e)
        return []

# ------------------------------------------------------------
# Classe OO (opzionale) per integrazioni
# ------------------------------------------------------------
class Retriever:
    """
    Wrapper OO con opzione embed_fn (per indici LLM futuri).
    Per l’MVP con hash-embedding non serve passare embed_fn.
    """
    def __init__(self, index_json_path: str = "content/rag/indexes/index.json", embed_fn: Optional[Callable[[str], List[float]]] = None):
        self.index_json_path = index_json_path
        self.embed_fn = embed_fn

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        return retrieve(query, top_k=k, index_json_path=self.index_json_path, embed_fn=self.embed_fn)

# ------------------------------------------------------------
# CLI minimale
# ------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    for r in retrieve("price ladder ±10% step 2% utile massimo", top_k=3):
        text_clean = r['text'][:120].replace('\n', ' ')
        print(f"[{r['score']:.3f}] {r.get('title','')} — {text_clean}…")
