# content/rag/indexer.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Iterable, Tuple
from pathlib import Path
import hashlib
import math
import logging
import json
import re

# -------------------------------------------------------------------
# Settings (robusti ai missing attributes)
# -------------------------------------------------------------------
try:
    from api.config import settings  # type: ignore
except Exception:  # fallback ultra-sicuro
    class _S:  # type: ignore
        RAG_DIM = 128
        RAG_BACKEND = "memory"          # "memory" | "qdrant"
        RAG_EAGER_INIT = False
        RAG_COLLECTION = "llm_cfo_chunks"
        QDRANT_URL = "http://localhost:6333"
    settings = _S()  # type: ignore

_DIM: int = int(getattr(settings, "RAG_DIM", 128) or 128)
_BACKEND: str = str(getattr(settings, "RAG_BACKEND", "memory") or "memory").lower()
_EAGER: bool = bool(getattr(settings, "RAG_EAGER_INIT", False))
_QDRANT_COLLECTION = str(getattr(settings, "RAG_COLLECTION", "llm_cfo_chunks") or "llm_cfo_chunks")
_QDRANT_URL = str(getattr(settings, "QDRANT_URL", "http://localhost:6333") or "http://localhost:6333")

logger = logging.getLogger(__name__)

# -------------------------------------------------------------------
# Qdrant (opzionale)
# -------------------------------------------------------------------
_HAS_QDRANT = False
try:
    from qdrant_client import QdrantClient  # type: ignore
    from qdrant_client.http.models import Distance, VectorParams, PointStruct  # type: ignore
    _HAS_QDRANT = True
except Exception:
    _HAS_QDRANT = False

# -------------------------------------------------------------------
# Modello documento
# -------------------------------------------------------------------
@dataclass
class Doc:
    id: str
    text: str
    title: Optional[str] = None
    url: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None


# -------------------------------------------------------------------
# Chunking (migliorato: prova a spezzare per frasi/paragrafi)
# -------------------------------------------------------------------
_SENT = re.compile(r"(?<=[.!?])\s+")
def _split_sentences(text: str) -> List[str]:
    text = (text or "").strip()
    if not text:
        return []
    # evita spezzettamenti eccessivi su sigle: fallback a split lineare se poche maiuscole/punti
    parts = _SENT.split(text)
    if len(parts) <= 1:
        return [text]
    return parts

def _chunk_text(text: str, chunk_size: int = 350, overlap: int = 50) -> List[str]:
    """
    chunk_size/overlap sono in caratteri (coerenti con il tuo uso).
    Heuristics:
      - prova a riempire un chunk con frasi finché non supera chunk_size
      - se una frase è più lunga di chunk_size → fallback a split “duro”
    """
    t = (text or "").strip()
    if not t:
        return []
    out: List[str] = []
    buf: List[str] = []
    cur_len = 0

    def flush():
        nonlocal buf, cur_len, out
        if buf:
            ch = " ".join(buf).strip()
            if ch:
                out.append(ch)
        buf, cur_len = [], 0

    for sent in _split_sentences(t):
        s = sent.strip()
        if not s:
            continue
        if len(s) > chunk_size:
            # spezza duro per lunghe one-liners
            flush()
            i = 0
            while i < len(s):
                j = min(len(s), i + chunk_size)
                out.append(s[i:j].strip())
                i = max(j - overlap, j)
            continue

        if cur_len + len(s) + 1 <= chunk_size:
            buf.append(s)
            cur_len += len(s) + 1
        else:
            # flush chunk corrente con overlap semplice (taglia la coda)
            merged = " ".join(buf).strip()
            if merged:
                out.append(merged)
            # overlap “caratteri”: riprendi la coda del chunk precedente
            if overlap > 0 and merged:
                tail = merged[-overlap:]
                buf, cur_len = [tail, s], len(tail) + 1 + len(s)
            else:
                buf, cur_len = [s], len(s)

    flush()
    return out


# -------------------------------------------------------------------
# Embedder deterministico (hash-based): stabile per test/demo
# -------------------------------------------------------------------
def _hash_vec(text: str, dim: int = _DIM) -> List[float]:
    if not text:
        return [0.0] * dim
    v = [0.0] * dim
    # spartizione semplice per token (split su whitespace)
    for tok in text.split():
        h = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
        idx = h % dim
        sign = -1.0 if ((h >> 8) & 1) else 1.0
        v[idx] += sign
    # normalizzazione L2
    norm = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / norm for x in v]

def _cosine(a: List[float], b: List[float]) -> float:
    s = sum(x * y for x, y in zip(a, b))
    # a e b normalizzate → s ∈ [-1, 1]; riportiamo in [0, 1]
    return (s + 1.0) / 2.0


# -------------------------------------------------------------------
# Backend Noop / InMemory / Qdrant
# -------------------------------------------------------------------
class NoopIndex:
    """Indice neutro: non memorizza nulla. Evita side-effect all'import."""
    def __init__(self) -> None:
        self._emb = None
        self._chunks: List[Dict[str, Any]] = []

    def build(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        return {"added_chunks": 0, "total_chunks": 0}

    def add_docs(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        return {"added_chunks": 0, "total_chunks": 0}

    def search(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        return []


class InMemoryIndex:
    """Fallback veloce senza dipendenze."""
    def __init__(self) -> None:
        self._chunks: List[Dict[str, Any]] = []
        self._emb = "hash-embedder"

    def _prepare_points(self, docs: List[Doc], chunk_size: int, overlap: int) -> List[Dict[str, Any]]:
        points: List[Dict[str, Any]] = []
        for d in docs:
            for i, ch in enumerate(_chunk_text(d.text, chunk_size, overlap)):
                points.append({
                    "doc_id": d.id,
                    "chunk_id": f"{d.id}::ch{i}",
                    "title": d.title,
                    "url": d.url,
                    "text": ch,
                    "vec": _hash_vec(ch),
                    "meta": d.meta or {},
                })
        return points

    def build(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        self._chunks = self._prepare_points(docs, chunk_size, overlap)
        return {"added_chunks": len(self._chunks), "total_chunks": len(self._chunks)}

    def add_docs(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        pts = self._prepare_points(docs, chunk_size, overlap)
        self._chunks.extend(pts)
        return {"added_chunks": len(pts), "total_chunks": len(self._chunks)}

    def search(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        vec = _hash_vec(query or "")
        scored: List[Tuple[float, Dict[str, Any]]] = []
        for p in self._chunks:
            s = _cosine(vec, p["vec"])
            scored.append((s, p))
        scored.sort(key=lambda t: t[0], reverse=True)
        out: List[Dict[str, Any]] = []
        for s, p in scored[:max(1, k)]:
            out.append({
                "doc_id": p["doc_id"],
                "chunk_id": p["chunk_id"],
                "title": p.get("title"),
                "url": p.get("url"),
                "score": float(s),
                "text": p["text"],
                "meta": p.get("meta", {}),
            })
        return out


class QdrantIndex:
    """Backend Qdrant (facoltativo). Usa embeddings deterministiche per MVP."""
    def __init__(self, url: str) -> None:
        if not _HAS_QDRANT:
            raise RuntimeError("Qdrant non disponibile: installa 'qdrant-client'.")
        self._client = QdrantClient(url=url)
        self._ensure_collection()

    def _ensure_collection(self) -> None:
        try:
            cols = [c.name for c in self._client.get_collections().collections]
        except Exception:
            cols = []
        if _QDRANT_COLLECTION not in cols:
            self._client.recreate_collection(
                collection_name=_QDRANT_COLLECTION,
                vectors_config=VectorParams(size=_DIM, distance=Distance.COSINE),
            )

    def _to_points(self, docs: List[Doc], chunk_size: int, overlap: int) -> List['PointStruct']:
        points: List['PointStruct'] = []
        for d in docs:
            for i, ch in enumerate(_chunk_text(d.text, chunk_size, overlap)):
                pid = f"{d.id}::ch{i}"
                vec = _hash_vec(ch)
                payload = {
                    "doc_id": d.id,
                    "chunk_id": pid,
                    "title": d.title,
                    "url": d.url,
                    "text": ch,
                    "meta": d.meta or {},
                }
                points.append(PointStruct(id=pid, vector=vec, payload=payload))
        return points

    def build(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        self._ensure_collection()
        points = self._to_points(docs, chunk_size, overlap)
        if points:
            self._client.upsert(collection_name=_QDRANT_COLLECTION, points=points)
        return {"added_chunks": len(points), "total_chunks": -1}

    def add_docs(self, docs: List[Doc], chunk_size: int = 350, overlap: int = 50) -> Dict[str, int]:
        return self.build(docs, chunk_size, overlap)

    def search(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        vec = _hash_vec(query or "")
        hits = self._client.search(
            collection_name=_QDRANT_COLLECTION,
            query_vector=vec,
            limit=max(1, k),
        )
        out: List[Dict[str, Any]] = []
        for h in hits:
            pl = h.payload or {}
            out.append({
                "doc_id": pl.get("doc_id"),
                "chunk_id": pl.get("chunk_id"),
                "title": pl.get("title"),
                "url": pl.get("url"),
                "score": float(h.score),
                "text": pl.get("text", ""),
                "meta": pl.get("meta", {}),
            })
        return out


# -------------------------------------------------------------------
# Factory & gestione singleton “safe”
# -------------------------------------------------------------------
def _make_index() -> Any:
    backend = _BACKEND
    if backend == "qdrant" and _HAS_QDRANT:
        try:
            return QdrantIndex(url=_QDRANT_URL)
        except Exception as e:
            logger.warning("Qdrant init fallita (%s) → fallback InMemoryIndex", e)
            return InMemoryIndex()
    return InMemoryIndex()

# di default Noop per non avere side-effect all'import
VECTOR_INDEX: Any = NoopIndex()

def ensure_vector_backend(force: bool = False) -> Any:
    """Se serve, inizializza il backend reale in base a settings. Ritorna l'istanza corrente."""
    global VECTOR_INDEX
    if force or isinstance(VECTOR_INDEX, NoopIndex):
        if _EAGER or force:
            VECTOR_INDEX = _make_index()
    return VECTOR_INDEX

def get_vector_index() -> Any:
    """Ritorna l'indice corrente (può essere Noop se non forzato)."""
    return VECTOR_INDEX


# -------------------------------------------------------------------
# Ingest da filesystem (nuovo)
# -------------------------------------------------------------------
_READ_TXT_EXT = {".md", ".markdown", ".txt", ".yml", ".yaml"}

def _read_file(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

def discover_knowledge(knowledge_dir: str = "content/knowledge") -> List[Path]:
    base = Path(knowledge_dir)
    if not base.exists():
        return []
    files: List[Path] = []
    for p in base.rglob("*"):
        if p.is_file() and p.suffix.lower() in _READ_TXT_EXT:
            files.append(p)
    files.sort()
    return files

def load_docs_from_fs(knowledge_dir: str = "content/knowledge") -> List[Doc]:
    docs: List[Doc] = []
    for p in discover_knowledge(knowledge_dir):
        text = _read_file(p)
        if not text.strip():
            continue
        doc_id = hashlib.md5(str(p.resolve()).encode("utf-8")).hexdigest()
        title = p.stem.replace("_", " ").replace("-", " ").strip()
        meta = {"source_path": str(p), "ext": p.suffix.lower()}
        docs.append(Doc(id=doc_id, text=text, title=title, url=None, meta=meta))
    return docs


# -------------------------------------------------------------------
# Build/Add di alto livello + dump JSON (MVP retriever)
# -------------------------------------------------------------------
def build_from_knowledge(
    knowledge_dir: str = "content/knowledge",
    *,
    chunk_size: int = 350,
    overlap: int = 50,
    dump_json_path: Optional[str] = "content/rag/indexes/index.json"
) -> Dict[str, Any]:
    """
    Legge i documenti da knowledge/, costruisce l'indice corrente (reset) e,
    se dump_json_path è valorizzato e il backend è in-memory, salva un indice JSON
    (compatibile con retriever “semplice” basato su cosine sparsa).
    """
    docs = load_docs_from_fs(knowledge_dir)
    idx = ensure_vector_backend(force=True)
    stats = idx.build(docs, chunk_size=chunk_size, overlap=overlap)

    # se siamo su InMemory, possiamo salvare un dump JSON
    if dump_json_path and isinstance(idx, InMemoryIndex):
        out = {
            "chunks": [
                {
                    "doc_id": it["doc_id"],
                    "chunk_id": it["chunk_id"],
                    "title": it.get("title"),
                    "url": it.get("url"),
                    "text": it["text"],
                    "vec": it["vec"],  # sì: pesante, ma ok per MVP
                    "meta": it.get("meta", {}),
                }
                for it in idx._chunks
            ],
            "dim": _DIM,
            "backend": "memory-hash",
        }
        path = Path(dump_json_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        stats["dump_json"] = str(path)

    return stats

def add_from_knowledge(
    knowledge_dir: str = "content/knowledge",
    *,
    chunk_size: int = 350,
    overlap: int = 50,
    dump_json_path: Optional[str] = "content/rag/indexes/index.json"
) -> Dict[str, Any]:
    """Aggiunge (append) nuovi documenti/scansioni alla collezione corrente."""
    docs = load_docs_from_fs(knowledge_dir)
    idx = ensure_vector_backend(force=True)
    stats = idx.add_docs(docs, chunk_size=chunk_size, overlap=overlap)

    if dump_json_path and isinstance(idx, InMemoryIndex):
        # append/overwrite dump coerente all'attuale stato
        out = {
            "chunks": [
                {
                    "doc_id": it["doc_id"],
                    "chunk_id": it["chunk_id"],
                    "title": it.get("title"),
                    "url": it.get("url"),
                    "text": it["text"],
                    "vec": it["vec"],
                    "meta": it.get("meta", {}),
                }
                for it in idx._chunks
            ],
            "dim": _DIM,
            "backend": "memory-hash",
        }
        path = Path(dump_json_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        stats["dump_json"] = str(path)

    return stats


# -------------------------------------------------------------------
# Export per import espliciti
# -------------------------------------------------------------------
__all__ = [
    "Doc",
    "NoopIndex",
    "InMemoryIndex",
    "QdrantIndex",
    "get_vector_index",
    "ensure_vector_backend",
    "build_from_knowledge",
    "add_from_knowledge",
    "load_docs_from_fs",
    "discover_knowledge",
    "_chunk_text",
    "_hash_vec",
]

# -------------------------------------------------------------------
# CLI minimale
# -------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    stats = build_from_knowledge()
    logger.info("Index build: %s", stats)
