# RAG README (MVP)
- ingest: parse/chunk/embed documenti in content/knowledge/
- retrieval: carica indice e fa cosine-similarity top-k
Suggerimento: mantieni indici/versioni in rag/indexes/.
