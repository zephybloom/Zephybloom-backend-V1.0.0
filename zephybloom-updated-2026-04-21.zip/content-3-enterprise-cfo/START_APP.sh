#!/bin/bash

###############################################################################
# ZephyBloom CFO API - Simple Startup Script
# 
# Usage:
#   ./START_APP.sh              (default: localhost:8001)
#   ./START_APP.sh --prod       (production mode)
#   ./START_APP.sh --port 9000  (custom port)
#
###############################################################################

set -e

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Defaults
PORT=8001
ENV="development"
WORKERS=4

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --prod)
      ENV="production"
      WORKERS=8
      shift
      ;;
    --port)
      PORT="$2"
      shift 2
      ;;
    --help)
      echo "Usage: ./START_APP.sh [options]"
      echo ""
      echo "Options:"
      echo "  --prod              Start in production mode (8 workers)"
      echo "  --port <PORT>       Use custom port (default: 8001)"
      echo "  --help              Show this help"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      ./START_APP.sh --help
      exit 1
      ;;
  esac
done

# Print header
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║         ZephyBloom CFO API - Starting Server           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# Step 1: Check Python
echo -e "${YELLOW}[1/5]${NC} Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python3 not found. Install from https://www.python.org/downloads/${NC}"
    exit 1
fi
PYTHON_VERSION=$(python3 --version | awk '{print $2}')
echo -e "${GREEN}✓ Python ${PYTHON_VERSION}${NC}"

# Step 2: Check virtual environment
echo -e "${YELLOW}[2/5]${NC} Checking virtual environment..."
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}  Creating venv...${NC}"
    python3 -m venv venv
fi
source venv/bin/activate
echo -e "${GREEN}✓ Virtual environment activated${NC}"

# Step 3: Install dependencies
echo -e "${YELLOW}[3/5]${NC} Installing dependencies..."
if [ ! -f "requirements.txt" ]; then
    echo -e "${RED}✗ requirements.txt not found${NC}"
    exit 1
fi
python3 -m pip install -q -r requirements.txt 2>&1 | grep -v "already satisfied" || true
echo -e "${GREEN}✓ Dependencies installed${NC}"

# Step 4: Check database
echo -e "${YELLOW}[4/5]${NC} Checking database..."
if [ ! -f "zephytheory.db" ]; then
    echo -e "${YELLOW}  Creating database...${NC}"
    python3 -c "from db.session import init_session_factory; init_session_factory()" 
fi
echo -e "${GREEN}✓ Database ready${NC}"

# Step 5: Start server
echo -e "${YELLOW}[5/5]${NC} Starting FastAPI server..."
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}🚀 Server running!${NC}"
echo ""
echo -e "  Mode:     ${BLUE}${ENV}${NC}"
echo -e "  Port:     ${BLUE}${PORT}${NC}"
echo -e "  Workers:  ${BLUE}${WORKERS}${NC}"
echo ""
echo -e "  📍 API:      ${BLUE}http://localhost:${PORT}${NC}"
echo -e "  📍 Docs:     ${BLUE}http://localhost:${PORT}/docs${NC}"
echo -e "  📍 Health:   ${BLUE}http://localhost:${PORT}/health${NC}"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo ""
echo "Press Ctrl+C to stop the server."
echo ""

# Start server
if [ "$ENV" = "production" ]; then
    python3 -m uvicorn api.main:app \
        --host 0.0.0.0 \
        --port "$PORT" \
        --workers "$WORKERS" \
        --log-level info \
        --access-log
else
    python3 -m uvicorn api.main:app \
        --host 127.0.0.1 \
        --port "$PORT" \
        --reload \
        --log-level debug
fi
