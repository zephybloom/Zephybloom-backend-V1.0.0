# Day 2-3 Playbook: Send Invites & Onboarding

**Timeline:** April 17-18, 2026 (Thursday-Friday)  
**Objective:** Convert interested prospects into confirmed onboardings  
**Target outcome:** 5-7 first users scheduled for Day 4-5

---

## Day 2-3 Strategy Overview

### What Happens

**Day 2 (Thursday):**
- Monitor overnight responses from Day 1
- Follow-up on Day 1 non-responders
- Make warm calls to referral sources
- Send formal invites to interested parties
- Start scheduling onboarding calls

**Day 3 (Friday):**
- Continue follow-ups
- Close interested parties
- Confirm all onboarding appointments
- Prepare support team for Monday launch
- Weekly standup with team

### Expected Conversion Pipeline

```
Day 1 Contacts:      15-20 people
    ↓
Day 2 Responses:     2-3 people interested (10-15%)
    ↓
Day 2-3 Closes:      4-7 people accepted (25-35% of contacts)
    ↓
Day 4-5 Onboarded:   5-7 active users
```

---

## Day 2 Morning (Thursday 9 AM)

### 9:00 AM - Check Overnight Responses

**Action:**
```bash
# Check email for overnight responses
# Filter: "Zephybloom" or "pilot" in subject
# Expected: 0-3 responses (some people checked before bed)

python3 scripts/recruitment_tracker.py report
# Update spreadsheet with overnight responses
```

**Log any responses:**
- [ ] Contact name: ________________ Status: ________________
- [ ] Contact name: ________________ Status: ________________
- [ ] Contact name: ________________ Status: ________________

**If response = "interested":**
→ Move to Template 3 (onboarding confirmation) immediately
→ Schedule call ASAP (same day if possible)

**If response = "not now":**
→ Note and move on
→ Don't push, stay professional

**If response = "question":**
→ Reply same-day with quick answer
→ Use PILOT_USER_GUIDE.md for standard questions
→ Emphasize: confidential, free, 2 weeks, no commitment

---

### 10:00 AM - Follow-up Wave (Non-responders)

**Target:** Day 1 LinkedIn contacts who haven't responded

**Action:**
```bash
# List contacts to follow-up
python3 scripts/recruitment_tracker.py list --status "Contacted" --decision "Pending"
# Should show ~10-12 names (Day 1 contacts)
```

**Follow-up template (LinkedIn):**

```
[Original message]

Hey [Name],

Just wanted to check if you saw my message about ZephyBloom. 
If it's not the right time, totally understand!

But if you're curious about your company's financial health, 
would love to chat. Super low-pressure—just 30 minutes.

Reply here if interested.

[Your Name]
```

**Send to:** All "Contacted" + "Pending" from Day 1 (8-10 people)  
**Time to execute:** 15-20 minutes (2 min per message)

---

### 11:00 AM - Warm Referral Calls

**Target:** Referral sources who received emails on Day 1

**Action:**
- Call 3-5 referral sources (accountants, consultants, partners)
- Ask: "Did you have a chance to think about introducing us to your clients?"
- Goal: Get 2-3 personal intros

**Call script:**

```
Hi [Name], it's [You] from ZephyBloom.

Quick follow-up on my email yesterday about the pilot.

Basically, we're looking for smart business leaders to test 
our financial analysis AI (free, 2 weeks, their data is safe).

Do you know 2-3 CEOs or business owners who might be interested? 
Even just an idea of who to contact would help.

[Listen]

If yes: "Perfect! Can I mention your name?" → Get intro
If no: "No problem! Let me leave you one more option..."
→ Send them direct link to guide, ask for forward if they know anyone

Thanks!
```

**Expected outcome:** 2-3 warm intros or forwarded emails  
**Time:** 15-20 minutes (4-5 min per call)

---

### 12:00 PM - Send Formal Invites (Template 2)

**Target:** Anyone who expressed interest so far

**Action:**
1. Identify all "Interested" contacts from tracking
2. Send templated formal invite
3. Include calendar link for onboarding
4. Log send date to CSV

**Formal invite email:**

```
Subject: ✅ You're In! ZephyBloom Pilot - Next Steps

Hi [Name],

Excited you're interested in testing ZephyBloom CFO Enterprise!

Here's what's next:

**1. Pick your onboarding time** (30 minutes)
[Calendar link: https://calendly.com/zephybloom/pilot-onboarding]

Available slots:
→ Thursday (today) 2-5 PM
→ Friday 9 AM - 5 PM
→ Monday 9 AM - 5 PM
(Pick what works best)

**2. Prepare your company data** (optional, we can find it during call)
→ Annual revenue (last 12 months)
→ Cost of goods sold / variable costs
→ Operating expenses
→ Annual investments/capex
(Your accounting software or P&L statement has these)

**3. Review the user guide** (5 min read)
→ [Link to PILOT_USER_GUIDE.md]
→ Explains what to expect + how the system works

**4. Questions?**
→ Reply to this email
→ Or direct message me on LinkedIn

See you [Day] at [Time]!

[Your Name]
ZephyBloom CFO Enterprise
```

**Send to:** All contacts marked "Interested" (expected: 2-4 people by noon Day 2)

---

### 2:00 PM - Onboarding Call #1 (If scheduled)

**If someone booked for Thursday afternoon:**

**Call structure (30 min):**
1. **Intro** (2 min)
   - Introduce yourself
   - Explain: 30-min walkthrough, totally casual

2. **Their situation** (5 min)
   - "Tell me about your company"
   - "What's one financial question you're wrestling with?"
   - Listen: This helps personalize the demo

3. **System demo** (15 min)
   - Walk through login
   - Input their actual company data together
   - Show real analysis in real-time
   - Explain KPIs + cost of inaction

4. **Feedback** (5 min)
   - "First impression?"
   - "Does this help?"
   - "What's missing?"

5. **Next steps** (3 min)
   - Thank them
   - Explain: feedback form (2 min), optional calls
   - "Use it this week, let us know what you think!"

**Call notes template:**
```
Onboarding Call Note
Company: ________________
Contact: ________________
Date: __________________
Impressions:
□ Excited
□ Interested
□ Cautious
□ Need to think

Key feedback:
_________________________

Action items:
□ Send follow-up
□ Introduce to [person]
□ Adjust demo for next person
```

---

## Day 2 Afternoon (2 PM - 5 PM)

### 2:00 PM - Email Response Management

**Action:**
- Check email every hour for responses
- Any new "interested"? → Send calendar link immediately
- Any questions? → Reply same-day

**Expected response pattern:**
- Morning (9-12): 0-2 responses
- Afternoon (12-5): 1-3 more responses
- Evening (5+): Another 1-2

---

### 3:00 PM - Track & Update

**Action:**
```bash
# Update all responses in tracking system
python3 scripts/recruitment_tracker.py update "[Name]" --status "Interested" --decision "Yes"

# Regenerate report
python3 scripts/recruitment_tracker.py report
```

**Update spreadsheet:**
- Status: Who responded? (Change from "Contacted" to "Interested" or "Declined")
- Decision: What did they say?
- Response date: When?
- Next action: Follow-up or onboarded?

---

### 4:00 PM - Day 2 EOD Summary

**Email to team:**

```
TO: Product Team
SUBJECT: Pilot Recruitment - Day 2 Update

Day 1→2 Summary:
✓ Day 1 contacts: 15 people
✓ Responses: [X] (Y%)
✓ Interested: [X] (will onboard)
✓ Declined/Maybe: [X]
✓ No response yet: [X] (follow-up tomorrow)

Onboardings Scheduled:
→ [Day] [Time]: [Name] [Company]
→ [Day] [Time]: [Name] [Company]
→ [Pending]: [X] people expected to confirm Friday

Conversion Status:
• Target: 5-10 accepted (end of Day 3)
• Current run rate: [X]% conversion
• Status: 🟢 ON TRACK / 🟡 NEED TO ACCELERATE / 🔴 PIVOT NEEDED

Next: Day 3 follow-ups + confirm all onboardings
```

---

## Day 3 Morning (Friday 9 AM)

### 9:00 AM - Overnight Response Check

**Action:**
- Check email for overnight messages
- Any new interested parties?
- Any cancellations?

**Log changes:**
```bash
python3 scripts/recruitment_tracker.py update "[Name]" --status "Interested" --decision "Yes"
```

---

### 10:00 AM - Final Push (Last outreach)

**Target:** Any "Contacted" + "Pending" who haven't responded yet

**Final follow-up message (more direct):**

```
[Original message]

Hi [Name],

Last chance to jump in on the pilot (starting next week).

If you're interested but haven't signed up, reply with your 
preferred onboarding time and we'll lock it in:

→ Slots open Friday 9 AM - 5 PM
→ Or Monday/Tuesday

Just reply "interested" + a preferred time!

No pressure if not the right fit.

[Your Name]
```

**Send to:** Anyone still "Pending" (expected: 5-8 people)  
**Goal:** Convert 2-3 more to "Interested"

---

### 11:00 AM - Confirm All Onboardings

**Action:**
- Go through "Interested" + "Yes" contacts
- Confirm calendar invites were sent
- Check: Do they have confirmed time slots?
- Resend calendar link to anyone who didn't finalize

**Confirmation message:**

```
Just confirming—you're scheduled for:

Onboarding: [Day] at [Time] 
Duration: 30 minutes
Calendar: [Link]

Looking forward to showing you the system!

Please Reply "confirmed" to lock it in.
```

**Target:** 100% confirmation from everyone marked "Interested"

---

### 12:00 PM - Support Team Briefing

**Duration:** 15 minutes

**Agenda:**
1. Who's onboarding Monday/Tuesday? (Show photos + company info)
2. What to expect (typical questions, common issues)
3. Assign buddy: Who supports whom?
4. Review PILOT_USER_GUIDE.md (what we told them)
5. Q&A

**Expected:** All team members ready for Monday

---

### 1:00 PM - Weekend Prep

**Action (for Monday launch):**
- [ ] Staging environment tested (GET /health)
- [ ] Database backups current
- [ ] Monitoring dashboard live
- [ ] Support Slack channel ready
- [ ] Email templates set up (confirmation, support, feedback)
- [ ] API keys generated for all confirmed users
- [ ] Calendar invites confirmed

**Checklist:**
```bash
# Test system is alive
curl https://staging-api.zephybloom.it/health

# Verify backups
ls -lh /backups/pilot/ | tail -1

# Check monitoring is running
python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log
```

---

### 2:00 PM - Final Metrics Review

**Update tracking report:**

```bash
python3 scripts/recruitment_tracker.py report

# Should show something like:
# Total Contacts: 15-20
# Accepted: 5-7 (25-35%)
# Status breakdown: All properly logged
```

**Status check:**
- ✅ 5-7 users confirmed for onboarding? 
- ✅ All have agreed dates/times?
- ✅ API keys ready?
- ✅ Team trained?
- ✅ Support ready?

If all ✅ → READY FOR MONDAY LAUNCH

---

## Day 3 Afternoon & EOD

### 3:00 PM - Referral Source Thank-You

**Send thank-you emails/messages to anyone who helped:**

```
Subject: Thank you for the intro! 🙏

Hi [Name],

Just wanted to thank you for introducing [Company] to ZephyBloom.

They're onboarding with us next week. Excited to get their feedback!

If you know anyone else who'd benefit, keep us in mind for 
wave 2 (starting May).

Thanks again!
[Your Name]
```

**Why:** Builds goodwill, encourages more referrals later

---

### 4:00 PM - Celebrate & Communicate

**EOD Email to Stakeholders:**

```
TO: Product Lead, CEO
SUBJECT: ✅ Pilot Recruitment COMPLETE - 5-7 Users Ready

RECRUITMENT COMPLETE!

Total Outreach: 15-20 contacts
Final Acceptance: 7 users (35-45% conversion)
Status: 🟢 READY FOR MONDAY LAUNCH

Users Confirmed:
1. [Name] - [Company] - [Sector] - Mon [Time]
2. [Name] - [Company] - [Sector] - Tue [Time]
3. [Name] - [Company] - [Sector] - Mon [Time]
4. [Name] - [Company] - [Sector] - Wed [Time]
5. [Name] - [Company] - [Sector] - Tue [Time]
6. [Name] - [Company] - [Sector] - Mon [Time]
7. [Name] - [Company] - [Sector] - Tue [Time]

Company Mix:
• Healthy: 2-3 (growth minded)
• Struggling: 2-3 (looking for help)
• Critical: 1-2 (urgent need)

Sectors:
• SaaS: [#]
• Manufacturing: [#]
• Retail: [#]

System Ready:
✅ Staging environment tested
✅ Monitoring live
✅ Support team trained
✅ Onboarding materials sent
✅ API keys generated
✅ Database backed up

Timeline:
• Mon-Tue (April 20-21): Full onboarding sprint
• Wed-Fri: Active use + feedback collection
• Week 2-3: Weekly calls + analysis
• Day 22 (May 6): Exit interviews
• Day 24 (May 8): Go/No-Go decision

PILOT IS LIVE MONDAY! 🚀
```

---

### 5:00 PM - Final Checklist

**Day 2-3 Complete:**

```
RECRUITMENT
☑ Day 1 follow-ups completed
☑ Warm calls made to referral sources
☑ Formal invites sent
☑ Onboarding calls booked (5-7)
☑ All confirmations locked in
☑ Tracking spreadsheet up-to-date

PREPARATION
☑ Support team trained
☑ System tested (health check)
☑ Monitoring live
☑ API keys generated
☑ Database backups current
☑ Email templates ready

COMMUNICATION
☑ Users: All have calendar invites + materials
☑ Team: Knows who's onboarding + when
☑ Stakeholders: Notified of launch readiness

STATUS: 🟢 READY FOR DAY 4-5 (FIRST USERS ONLINE)
```

---

## Day 2-3 Success Metrics

| Metric | Target | Success Threshold | Status |
|--------|--------|-------------------|--------|
| Day 1 follow-ups | 10-12 | >80% contacted | TBD |
| Warm calls | 3-5 referral sources | ≥3 calls | TBD |
| Conversion rate | 25-35% | ≥20% | TBD |
| Users confirmed | 5-7 | ≥5 | TBD |
| All onboards scheduled | 100% | ≥5 confirmed | TBD |
| Team ready | 100% | All trained | TBD |
| System tested | 100% | Health check pass | TBD |

**Green Light Criteria:** All target metrics met → Ready for Day 4

---

## Contingency Scenarios

### Scenario A: Only 2-3 interested (Low conversion)

**Action:**
1. Extend recruitment into early Day 4
2. Activate backup channels (more community posts)
3. Offer incentives? (Extended trial, discount on v2)
4. Better personal outreach? (Replace email with calls)

**Decision point:** End Day 3
- If trending to 5+: Continue as planned
- If trending to <5: Extend recruitment through Day 4-5

### Scenario B: 10+ interested (High conversion)

**Action:**
1. Prioritize best fit candidates (diverse health/sector)
2. Politely defer extras (schedule for "wave 2")
3. Add to waitlist for May/June
4. Same commitment, spread across more weeks? 

**Decision point:** Pick top 7-8, invite rest to wave 2

### Scenario C: High cancellation rate

**Action:**
1. What changed their mind? (Respond quickly)
2. Last-minute replacement recruitment (call referral sources)
3. Offer different time slots?
4. Adjust messaging if pattern seen?

**Decision point:** Ensure minimum of 5 confirmed by EOD Day 3

---

## Day 2-3 Checklists

### Quick Print Checklist (Tape to Monitor)

```
☐ 9:00  Check overnight responses
☐ 10:00 Follow-up wave (non-responders)
☐ 11:00 Warm referral calls (3-5)
☐ 12:00 Send formal invites (interested parties)
☐ 2:00  Onboarding call #1 (if booked)
☐ 3:00  Check email + respond
☐ 4:00  Track & update CVS
☐ 5:00  EOD summary email

Next day (Day 3):
☐ 9:00  Check overnight responses
☐ 10:00 Final push (last outreach)
☐ 11:00 Confirm all onboardings
☐ 12:00 Support team briefing
☐ 1:00  Weekend prep (system ready?)
☐ 2:00  Final metrics review
☐ 3:00  Thank-you mails
☐ 4:00  EOD stakeholder email
☐ 5:00  Final checklist
```

---

## Day 2-3 Email Calendar

**Sent to users:**
- Day 2 morning: Follow-up (non-responders from Day 1)
- Day 2 noon: Formal invite (to interested parties)
- Day 2 afternoon: Calendar links + prep materials
- Day 3 morning: Final push (last chance)
- Day 3 noon: Confirmation request (lock it in)
- Day 3 evening: Weekend prep + excitement email

**Sent to team/stakeholders:**
- Day 2 EOD: Update email
- Day 3 EOD: Ready-for-launch email

---

## Template Reference

**Use these templates from guides:**
- Template 1: Cold LinkedIn message (Day 1)
- Template 2: Email invite (Day 2) ← **Use in Day 2 at 12:00 PM**
- Template 3: Onboarding confirmation (Day 2) ← **Use immediately after "interested" response**
- Referral follow-up: Direct call script (Day 2) ← **Use at 11:00 AM**

All templates in [RECRUITMENT_PLAYBOOK_DAY1.md](RECRUITMENT_PLAYBOOK_DAY1.md)

---

**END OF DAY 2-3 PLAYBOOK**

Next: Day 4-5 (First Users Online)

