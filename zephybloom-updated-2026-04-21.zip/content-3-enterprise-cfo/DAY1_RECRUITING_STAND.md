# Day 1 Recruitment - Daily Stand Template

**Date:** April 16, 2026  
**Owner:** [Your Name]  
**Time:** 9:00 AM - 5:00 PM

---

## Morning Prep (9:00 AM - 10:00 AM)

- [ ] Opened spreadsheet: `pilot_recruitment.csv`
- [ ] Reviewed templates (saved in drafts)
- [ ] Set calendar alerts for follow-ups
- [ ] Checked email for overnight responses

**Status:** Ready to execute

---

## Execution Log

### Phase 1: LinkedIn Outreach (10:00 AM - 11:30 AM)

**Target:** Contact 5 prospects via LinkedIn

1. **Prospect #1**
   - Name: ________________
   - Company: ________________
   - Sector: ________________
   - Status: Contacted ✓
   - Time: ______

2. **Prospect #2**
   - Name: ________________
   - Company: ________________
   - Sector: ________________
   - Status: Contacted ✓
   - Time: ______

3. **Prospect #3**
   - Name: ________________
   - Company: ________________
   - Sector: ________________
   - Status: Contacted ✓
   - Time: ______

4. **Prospect #4**
   - Name: ________________
   - Company: ________________
   - Sector: ........................
   - Status: Contacted ✓
   - Time: ______

5. **Prospect #5**
   - Name: ________________
   - Company: ________________
   - Sector: ........................
   - Status: Contacted ✓
   - Time: ______

**Summary Phase 1:**
- ✓ LinkedIn contacts: 5
- Time spent: _____ min
- Quality check: All personalized? ☐ Yes ☐ Partial

---

### Phase 2: Email Outreach (2:00 PM - 3:30 PM)

**Target:** Reach 5-7 referral sources

Referral sources contacted:
1. ________________ ✓
2. ________________ ✓
3. ________________ ✓
4. ________________ ✓
5. ________________ ✓

**Optional:**
6. ________________ ✓
7. ________________ ✓

**Summary Phase 2:**
- ✓ Referral emails sent: _____
- Time spent: _____ min
- Expected response rate: 20-30% (contact 2-3 people tomorrow)

---

### Phase 3: Community Outreach (3:30 PM - 4:30 PM)

**Target:** Post in 2-3 relevant groups/communities

Communities used:
- Platform: ________________
  Group: ________________
  Status: Posted ✓
  
- Platform: ________________
  Group: ________________
  Status: Posted ✓
  
- Platform: ________________
  Group: ________________
  Status: Posted ✓

**Summary Phase 3:**
- ✓ Posts made: _____
- Estimated reach: _____ people
- Expected responses: 5-10 DMs (over next 2-3 days)

---

### Phase 4: Tracking Update (4:30 PM - 5:00 PM)

**Data entry completed:**

```bash
# Run this command to update tracking
python3 scripts/recruitment_tracker.py report
```

**Current Status:**
```
Total Contacted Today:     _____
├─ LinkedIn:              5
├─ Email:                 _____
└─ Community:             _____

Total in Pipeline:        _____
├─ New:                   _____
├─ Contacted:             _____
├─ Interesting:           _____
└─ Decided:               _____

Next Actions:
→ Day 2 follow-ups: [list any pending]
→ Referral source calls: [day/time]
→ Monitor responses: Check email 2x daily
```

---

## Evening Reflection (5:00 PM - 5:30 PM)

### What Went Well Today?
- ☐ Got started on time
- ☐ All messages were personalized
- ☐ System is organized
- ☐ Team notified of progress
- Other: ________________

### What Was Challenging?
- ☐ Finding good prospects
- ☐ Writing personalized messages
- ☐ Time management
- ☐ [Other]: ________________

### Day 2 Priorities
1. Follow up on Day 1 contacts (non-responders)
2. Warm outreach to referral sources (phone calls)
3. Continue new outreach (if time)
4. Log all responses

### Daily Metrics

| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| LinkedIn messages sent | 5 | ____ | ✅ 🟡 ❌ |
| Referral emails sent | 5-7 | ____ | ✅ 🟡 ❌ |
| Community posts | 2-3 | ____ | ✅ 🟡 ❌ |
| Responses received | 0-2 (early) | ____ | ✅ 🟡 ❌ |
| Interested expressions | 0-1 | ____ | ✅ 🟡 ❌ |
| Follow-ups scheduled | 0 | ____ | ✅ 🟡 ❌ |

### Overall Day Rating: ☐ ⭐ ☐ ⭐⭐ ☐ ⭐⭐⭐ ☐ ⭐⭐⭐⭐ ☐ ⭐⭐⭐⭐⭐

---

## EOD Report Email

**To:** team@zephybloom.it  
**Subject:** Pilot Recruitment - Day 1 Complete

---

**Day 1 Recruitment Summary**

✅ **Execution Complete**

**Outreach:** 
- 5 LinkedIn messages sent
- 5-7 email referral requests sent
- 2-3 community posts published
- Total contacts attempted: 12-15

**Early Responses:**
- LinkedIn responses: [#]
- Email responses: [#]
- Community interest: [#]
- Total interested: [#]

**Next Steps:**
- Follow-ups on Day 2 (for non-responders)
- Referral source calls (phone)
- Continue new outreach
- Target: 10 companies by Day 5

**Tracking:** [Link to pilot_recruitment.csv]

**Status:** 🟢 ON TRACK

---

## Optional: Additional Notes

**Interesting Leads This Week:**
1. ________________ (reason: ________________)
2. ________________ (reason: ________________)
3. ________________ (reason: ________________)

**Sectors Covered So Far:**
- ☐ SaaS/Tech: [#] companies
- ☐ Manufacturing: [#] companies
- ☐ Retail: [#] companies

**Any Issues?**
- [No issues] ✓
- [Describe]: ________________

---

**End of Day 1**

Next: Day 2 Follow-ups (April 17)

