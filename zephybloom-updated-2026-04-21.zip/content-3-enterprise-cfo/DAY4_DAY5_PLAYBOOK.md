# Day 4-5 Playbook: First Users Online

**Timeline:** April 20-21, 2026 (Monday-Tuesday)  
**Objective:** First users complete onboarding + start using system  
**Target outcome:** All 5-7 users successfully onboarded + excited about product  
**Success indicator:** Users complete first analysis + submit feedback form

---

## Day 4-5 Strategy Overview

### What Happens

**Day 4 (Monday):**
- First 2-3 users arrive for onboarding calls (9 AM - 12 PM)
- Live system demo with their actual data
- They get access immediately after call
- Support team watching closely
- Evening: First feedback trickles in

**Day 5 (Tuesday):**
- Next 2-3 users arrive for onboarding calls
- Day 4 users now actively using (second day of access)
- Monitoring real usage patterns
- Support: Monitor + respond to questions
- Evening: Collect initial impressions

### Critical Success Factors

1. **System Must Be UP** (99.9% uptime)
2. **Users Feel Supported** (responsive support team)
3. **First Analysis Works Perfectly** (build confidence)
4. **Feedback Flows Back** (not blocked by friction)
5. **Team Stays Calm** (expected: normal questions, not emergencies)

---

## System Pre-Launch (Sunday Evening, April 19)

### Final System Check

**[ ] 5:00 PM Sunday - Infrastructure**
```bash
# Run final health checks
curl -v https://staging-api.zephybloom.it/health
# Expected: {"status": "healthy", "version": "1.0", "timestamp": "..."}

# Check database
sqlite3 /var/lib/zephybloom/pilot.db ".tables"
# Should show: users, analyses, feedback, etc.

# Backup before launch
cp /var/lib/zephybloom/pilot.db /backups/pilot/pilot_db_pre_launch.backup

# Start monitoring
nohup python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log --watch 60 > /tmp/monitor.log &
```

**[ ] 5:30 PM Sunday - API Keys**
```bash
# Verify all API keys generated and ready to send
# Format: pilot_key_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# 5-7 keys total, one per user

# Store securely (1Password or equivalent)
# Ready to send in Monday morning email
```

**[ ] 6:00 PM Sunday - Email Templates**
- [ ] Onboarding confirmation email
- [ ] Login credentials email (with API key)
- [ ] Post-analysis feedback form (link ready)
- [ ] Support contact details (email + Slack)

**[ ] 6:30 PM Sunday - Team Readiness**
- [ ] All support staff briefed (who's on duty when?)
- [ ] Slack channel #pilot-support active
- [ ] Response time commitment: <30 min for user questions
- [ ] Escalation path clear (critical issues → ops lead)

**[ ] 7:00 PM Sunday - Monitoring Dashboard**
```bash
# Test monitoring dashboard
python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log
# Should show: metrics, alerts, performance trends

# Verify alerting
# Test alert: error rate >5% should trigger Slack notification
```

**Status:** 🟢 SYSTEM READY FOR LAUNCH

---

## Day 4 Execution (Monday, April 20)

### 8:00 AM - Team Standup

**Duration:** 10 minutes  
**Attendees:** Product, Eng, Support, Ops

**Agenda:**
```
1. Welcome new team members (anyone joining for pilot?)
2. User schedule today (2-3 onboardings at what times?)
3. What to watch for (potential issues?)
4. Support roles (who handles what?)
5. Escalation process (critical issue → ?)
6. Lunch break coverage (support continues 24/7? Or office hours?)
7. Questions?
```

**Communication:**
- [ ] Send Slack reminder with today's users, times, and company info
- [ ] Calendar invites confirmed?
- [ ] All have phone numbers for users?

---

### 8:30 AM - Pre-Call Prep

**For each user scheduled:**

```
User #1: [Name] - [Company] - [Time]
├─ Company info reviewed? ☐
├─ Their revenue/sector noted? ☐
├─ Interview notes from Day 2-3? ☐
├─ Onboarding call script ready? ☐
├─ Live demo data prepared? ☐
└─ Login already created in system? ☐

Repeat for User #2, #3, etc.
```

**System check:**
```bash
# 30 min before first call
curl https://staging-api.zephybloom.it/health
# Response time should be <50ms
# Status: "healthy"

# Load test (light)
ab -n 10 -c 1 https://staging-api.zephybloom.it/cfo/analyze
# All should complete in <100ms
```

---

### 9:00 AM - First Onboarding Call Begins

**Duration:** 30 minutes

**Before call (5 min before):**
- [ ] Zoom/Teams link ready
- [ ] ONBOARDING_CALL_GUIDE open (your script)
- [ ] Their company data ready
- [ ] System tested (logged in, analyzed sample data)
- [ ] Notes doc ready (to log their reactions)

**During call (30 min):**
Use ONBOARDING_CALL_GUIDE.md - follow script exactly

Key moments to watch:
- Reaction to status badge (excited? relieved? shocked?)
- Which recommendation resonates most?
- Do they ask follow-up questions? (Good sign)
- Confidence level: Are they ready to use alone?

**After call (5 min):**
```
Immediately after:
☐ Fill call notes (CALL_NOTES_[User]_[Date].md)
☐ Generate API key & login (if not done)
☐ Send credentials email within 3 minutes
☐ Slack #pilot-support: "[Name] onboarded, expecting first analysis within 1 hour"
```

---

### 12:00 PM - Lunch Break

**Coverage:**
- [ ] Support person stays online (not working, but available)
- [ ] Monitoring dashboard watched
- [ ] Any user messages monitored
- [ ] Lunch suggestions: Team lunch or scattered?

---

### 1:00 PM - Afternoon Monitoring

**Action: Active monitoring mode (every 15 min)**

```
Dashboard check:
├─ Response times: All <100ms? ✓
├─ Error rate: <1%? ✓
├─ Fallback events: Any triggered? [Document if yes]
├─ New analyses: How many completed? [Track]
└─ Feedback submissions: Any yet? [Track]

Slack check:
├─ Any user questions? [Respond <30 min]
├─ Any support escalations? [Investigate]
├─ Any bugs reported? [Log to #pilot-bugs]

Email check:
├─ Any user emails arrived? [Respond same day]
├─ Any unusual patterns? [Document]
```

---

### 2:00 PM - User Behavior Tracking

**Log every user action:**

```
User: [Name] | Company: [Company]
├─ Logged in: ✓ Time: ________
├─ First analysis: Time: ________ | Status shown: HEALTHY/WARNING/CRITICAL
├─ Feedback submitted: ☐ Not yet ☐ Yes, time: ________
├─ Questions asked: ☐ None ☐ Yes: ______________________
├─ Seemed engaged: ☐ Very ☐ Moderate ☐ Not sure
└─ Notes: ______________________

Repeat for each user...
```

---

### 3:00 PM - Quick Team Sync (Optional)

**If issues arise:**

```
"Any issues so far?"
- System performance: ☐ All green ☐ Slight slowness ☐ Critical issue
- User confusion: ☐ None ☐ Questions normal ☐ Major confusion
- Bugs found: ☐ None ☐ [List minor] ☐ [Critical]
- Escalation needed: ☐ No ☐ Yes: ________
```

---

### 4:00 PM - Second Onboarding Call (If scheduled)

Same as 9 AM call structure

---

### 5:00 PM - Daily Metrics Snapshot

**Collect for report:**

```
Day 4 Metrics (end of day):
├─ Users onboarded today: ____ (target: 2-3)
├─ Analyses completed: ____ (target: 2-3 per user)
├─ Feedback submissions: ____ (target: start appearing)
├─ System errors: ____ (target: 0)
├─ User escalations: ____ (target: 0)
├─ Support response time: ____ (target: <30 min avg)
└─ Overall status: 🟢 GREAT / 🟡 GOOD / 🔴 ISSUES

Expected tomorrow:
└─ More users onboarding (2-3)
└─ Day 4 users doing second/third analyses
```

---

### 6:00 PM - Evening Check-In (Async)

**Slack message to team:**

```
Day 4 Launch Summary:
✅ System UP (99.99% uptime)
✅ [X] users onboarded successfully
✅ [X] analyses completed
✅ [X] feedback submissions started
✅ 0 critical issues

Team:
Great work today! Everyone stayed calm and responsive.
Next: Same routine tomorrow for Day 5 users.

On-call tonight: [Name] - respond if critical issue
Otherwise, enjoy your evening!
```

---

### 7:00 PM - Optional (If you want)

**Early feedback email request:**

```
Subject: Quick check-in - how's ZephyBloom going?

Hi [Name],

Had a chance to try the system yet? 

Even just a quick "looks good" or "had an issue" helps. 
No pressure for full feedback yet—just curious how it feels 
using it solo.

Reply anytime!

[Your Name]
```

---

## Day 5 Execution (Tuesday, April 21)

### 8:00 AM - Team Standup

**New info from overnight:**
```
Overnight monitoring:
├─ Any system issues? [Document]
├─ Any user activity? [Track]
├─ Feedback submissions? [Read]
├─ Issues reported? [Log]
└─ General health: 🟢 GREEN
```

**Today's agenda:**
```
1. User schedule: Who's onboarding today? (2-3 more)
2. Day 4 users: Any feedback yet?
3. System status: All systems go?
4. Support needs: Any patterns we're noticing?
5. Escalation process: Any issues today we need to address?
```

---

### 9:00 AM - Onboarding Continue

**Same pattern as Day 4:**
- Onboarding call #1 (9:00 AM - 9:30 AM)
- User gets credentials
- Expected: First analysis within 1 hour
- Support monitoring

---

### 12:00 PM - Mid-Day Metrics Check

**By this point (Day 5 noon):**

```
Total users onboarded: 5-7 ✓
├─ Day 4 users: Completed at least 1 analysis ✓
├─ Day 5 users: Just onboarded (0-1 analysis)
└─ Expected: 10-15 analyses total by end of Day 5

Feedback collected so far:
├─ Day 4 users: 1-2 submitted feedback form
├─ Day 4 users: 1-2 short email responses to check-in
└─ Expected: 2-3 more submissions by Day 5 evening

System performance:
├─ Response time: Average <100ms ✓
├─ Error rate: <1% ✓
├─ Uptime: 99.9%+ ✓
└─ No rollbacks needed ✓

User sentiment (from conversations):
├─ Excited: [#]
├─ Curious: [#]
├─ Skeptical: [#]
└─ Next action: If skeptical, send case study email
```

---

### 2:00 PM - Onboarding Call #2 (If scheduled)

Same 30-min structure

---

### 4:00 PM - Active Feedback Collection

**Send targeted follow-ups to Day 4 users:**

```
To: Day 4 users who haven't submitted feedback yet

Subject: Your experience so far? [Quick 2-min survey]

Hi [Name],

Been a full day! How's ZephyBloom working for you?

Quick 1-minute reaction (reply with number):
1. Not what I expected
2. Okay, but not sure about value
3. Interesting, will explore more
4. Really useful, already seeing insights
5. Wow, this changes how I think about my business

Any specific feedback? Even just "the margins analysis was helpful" 
or "I'm confused about EBITDA" helps us.

Reply here or use the feedback form in your dashboard.

Thanks!
[Your Name]
```

**Expected:** 2-3 responses by evening

---

### 5:00 PM - End of Day 5 Wrap-up

**Comprehensive summary:**

```
PILOT WEEK 1 SUMMARY

Users Onboarded:        5-7 ✅
├─ Day 4: 2-3 users
├─ Day 5: 2-3 users
└─ Pending: 1-2 (scheduled for later)

Analyses Completed:     10-15+ ✅
├─ Day 4 users: 5-8 analyses (avg 2-3 per user)
├─ Day 5 users: 2-4 analyses (just onboarded)
└─ Expected: 3+ analyses per user by end of week

Feedback Collected:     2-4 responses ✅
├─ Feedback forms: 1-2 submitted
├─ Email responses: 1-2 to check-in
├─ Overall rating: Average 4.0/5 (estimated)
└─ Key insight: [Summarize main theme]

System Performance:     EXCELLENT ✅
├─ Uptime: 99.95%
├─ Avg response: 45ms <100ms
├─ Error rate: 0.1% <1%
├─ Fallbacks triggered: 0
└─ Zero critical issues

User Sentiment:
├─ Excited: 3-4 ("This is cool!")
├─ Engaged: 1-2 ("Still exploring")
├─ Cautious: 0-1 ("Not sure yet")
└─ Overall: 🟢 VERY POSITIVE

What's Next (Week 2):
├─ Continue monitoring (daily)
├─ Encourage more analyses (scenario planning)
├─ Collect weekly feedback (Friday)
├─ Support team keeps scaling
└─ Watch for patterns in questions/feedback
```

---

## Critical Incident Response (Day 4-5)

### Scenario 1: System Crash (HTTP 500)

**Trigger:** Error rate >5% for 5 minutes

**Immediate action (< 2 min):**
1. Verify it's real: Check multiple endpoints
2. Alert team: #pilot-alerts in Slack
3. Check logs: `/var/log/zephybloom/errors.log`
4. Identify cause: 
   - Database locked? → PRAGMA optimize
   - Memory leak? → Restart service
   - Bug introduced? → Check recent changes

**Response to users (immediately):**
```
Slack/Email: "Brief maintenance underway. We're investigating. 
Will update in 15 minutes. Apologies for disruption!"

15 min later: Either fixed + back up, or specific ETA
```

**Prevention:** Daily backups, pre-tested rollback

---

### Scenario 2: User Can't Login

**Trigger:** User says "Invalid credentials"

**Debug (< 5 min):**
```bash
# Check user exists in database
sqlite3 /var/lib/zephybloom/pilot.db \
  "SELECT email, api_key FROM users WHERE email='user@example.com';"

# Check API key format (should be pilot_key_XXX...)
# Check database accessible
```

**Fix:**
- If wrong credentials: Resend correct ones
- If database issue: Restart API service
- If API key corrupted: Regenerate

**Response:**
```
"Hi [Name], resetting your login now. 
Check email in 1 min for new credentials. 
Let me know if that works!"
```

---

### Scenario 3: Analysis Gives Wrong Status

**Trigger:** User says "This says HEALTHY but we're losing money"

**Immediate:** Don't argue, LISTEN

**Debug:**
```
"Can you walk me through the numbers it analyzed?"
[Get their inputs]

"And your actual profit is negative, you said?"
[Confirm]

"Okay, let me check what our system calculated... 
[Rerun with their exact numbers]

Here's what I'm seeing: [Share screenshot]
[Point out where discrepancy might be]
```

**Most likely causes:**
1. They gave annual numbers but had monthly in mind
2. They miscounted COGS
3. They're not including all operating expenses
4. System has a bug (unlikely but possible)

**Resolution:**
- If their data error: Guide them to correct inputs
- If calculation bug: Document + escalate to engineering
- If edge case: Have them export, send to support, review

**Response:**
```
"I see the issue now. It's likely [reason].
Here's how to adjust: [steps]
Once you fix that, the analysis should be [correct status].
Sound good?"
```

---

### Scenario 4: User Not Using It

**Trigger:** User onboarded but zero analyses 24+ hours later

**Action (Day 5 afternoon):**

```
"Hi [Name], just checking—got a chance to try ZephyBloom yet?
Sometimes people are busy, sometimes there's a hiccup. 
Let me know if you need help getting started!
[Support email]"

Expected responses:
- "Not yet, but will try tonight" ✅ (good)
- "Had an issue..." ✅ (good, we fix)
- "Seems too complex" ⚠️ (need to help)
- No response × 2 messages = "May drop out"
```

**If they seem lost:**
```
"Happy to do a quick 15-min call to walk through it?
Pick a time: [offer 3 slots]
Or I can email a how-to guide?
What works better?"
```

---

## Daily Communication (Day 4-5)

### Automated Emails

**Day 4 morning (9:00 AM, sent to all users):**
```
Subject: Welcome to the ZephyBloom Pilot! 🚀

Hi Pilot Users,

Today we launch! Your onboarding calls are scheduled 
for [time]. Here's what to expect:

1. 30-min walkthrough (with your actual data)
2. You'll see your company's financial health
3. Get personalized recommendations
4. Ask any questions

After the call? You get instant access. 
Try a few analyses, it takes 2-3 minutes each.

Support is here if you need anything: 
→ Slack: [channel]
→ Email: [email]
→ Phone: [optional - for critical issues]

See you in [X] hours!

[Your Name]
ZephyBloom
```

**Day 4 evening (after first onboardings):**
```
Subject: You're in! Time to explore 👋

Hi [Name],

Great talking to you today! You've got full access now.

Quick recap:
✓ Your company status: [HEALTHY/WARNING/CRITICAL]
✓ Key insight: [Most important recommendation]
✓ Next steps: Try scenario planning (what-if analysis)

Getting started:
1. Log in: [Link]
2. Run analyses: Click "Analyze" anytime
3. Share feedback: 2-min form in dashboard

Questions? Reply here. I'm around.

[Your Name]
```

**Day 5 afternoon (to Day 4 users):**
```
Subject: Your experience so far? [Quick pulse check]

Hi [Name],

Been playing with ZephyBloom for a day now. 
How's it going?

Loving it? Confusing? Something in between?

Would love a quick reaction (literally 1 minute):
[Online form with 1-5 scale + comment box]

Or just reply here.

Can't wait to hear!

[Your Name]
```

---

## Day 4-5 Daily Stand Template

See: [DAY4_DAY5_STAND.md](DAY4_DAY5_STAND.md) for hour-by-hour checklist

---

## Success Metrics (End of Day 5)

**System Health:**
- ✅ Uptime: ≥99.9%
- ✅ Avg response time: <100ms
- ✅ Error rate: <1%
- ✅ Zero critical incidents

**User Adoption:**
- ✅ All 5-7 users onboarded successfully
- ✅ 90%+ have completed first analysis
- ✅ Average 2-3 analyses per user
- ✅ 30%+ have submitted feedback

**User Satisfaction:**
- ✅ No major confusion (expected: 0-1 help requests)
- ✅ At least 1-2 users excited ("this is cool")
- ✅ 0 users have quit/dropped out
- ✅ Average sentiment: Positive (not negative)

**Team Performance:**
- ✅ Support response time: <30 min average
- ✅ Zero escalations (everything handled)
- ✅ Team stayed calm & helpful
- ✅ No burnout signals

---

## Contingencies

### If System Issues Discovered

**Option 1: Minor bug (cosmetic)**
- Fix overnight
- Communicate: "We made a small improvement"

**Option 2: Major bug (functional)**
- Document scope
- Escalate to engineering
- Tell users: "We found issue X. Fixing by [date]"
- No rollback needed (system still functional)

**Option 3: Critical bug (blocks users)**
- Immediate rollback to previous version
- Apologize sincerely
- "Back up now. Investigating issue. Will fix this week"
- Consider extending pilot 1 week to make up for downtime

---

### If Low User Adoption

**Signs:**
- Only 2-3 of 7 users have done any analysis
- Users logging in but not running analyses
- Zero feedback submissions by Day 5 evening

**Actions:**
1. Follow-up calls: "How's it going? What would make this useful?"
2. Send comparison data: "Other users are discovering X about their business"
3. Offer guided scenario: "Try this one 'what-if' analysis"
4. Reduce friction: "Can I do first analysis WITH you, live screen share?"

**Last resort:** Extend onboarding period (reschedule for next week with more support)

---

### If Extremely Hot (All using heavily)

**Signs:**
- All 7 users logging in daily
- 10+ analyses already by Day 5
- Positive feedback flooding in

**Actions:**
1. Celebrate! This is awesome
2. Ask permission: "Could we do a quick case study video with you?"
3. Feature: "You're discovering X—that's gold for other businesses"
4. Plan: Can we onboard wave 2 sooner?

---

## Daily Briefing Template

Print and post:

```
DAY 4 - FIRST USERS LIVE

8:00 AM   Team standup (10 min)
          └─ User schedule review, support roles

8:30 AM   Pre-launch system check
          └─ Health check, API test, credential prep

9:00 AM   Onboarding call #1 (30 min)
          └─ [Name] - [Company] - [Time]

12:00 PM  Lunch break (support continues)

1:00 PM   Active monitoring (every 15 min)
          └─ Response times, errors, user activity

2:00 PM   User behavior tracking
          └─ Log who's using what

3:00 PM   Quick team sync (if issues)

4:00 PM   Onboarding call #2 (if scheduled)

5:00 PM   Daily metrics snapshot
          └─ Update tracking sheet

6:00 PM   Evening check-in (Slack)
          └─ Status update to team

---

DAY 5 - CONTINUING

8:00 AM   Team standup + overnight review

9:00 AM   Onboarding call #3 (30 min)

12:00 PM  Mid-day metrics check
          └─ Total analyses, feedback so far

2:00 PM   Onboarding call #4 (if scheduled)

4:00 PM   Active feedback collection
          └─ Send pulse check emails

5:00 PM   Week 1 wrap-up summary
          └─ Success metrics review
```

---

**END OF DAY 4-5 PLAYBOOK**

Next: Week 1-2 Ongoing (daily monitoring + weekly feedback)

