# Onboarding Call Guide (30 minutes)

**Purpose:** Transform interested prospects into active pilot users  
**Target:** Build trust + get them excited about the system  
**Duration:** 30 minutes total (strict time management)

---

## Pre-Call Preparation (5 minutes before)

### Before You Call

**[ ] Technical Setup**
- Open ZephyBloom staging environment in browser
- Test login works
- Have sample company data ready
- Audio & video tested

**[ ] Information Review**
- Read prospect's company info
- Know: Company, sector, revenue range, decision-maker
- Know: Why they're interested (from conversation)

**[ ] Goals Clarity**
- My goal: They leave excited + start using within 24 hours
- Their goal: Understand what this tool does for them
- Success: They feel it's valuable + understand next steps

**[ ] Mental Checklist**
- ☐ I'm relaxed & enthusiastic (not desperate)
- ☐ I'm ready to listen (not just pitch)
- ☐ I have their company numbers (or their P&L book/software)
- ☐ I understand their sector (SaaS/Mfg/Retail)

---

## Call Script (30 Minutes)

### Segment 1: Intro & Warm-up (2 minutes)

**Your opening:**

```
"Hi [Name]! Great to see you. 
I'm [You] from ZephyBloom.

Quick agenda for today:
→ I'll explain what we do (30 seconds)
→ Let's talk about your company (5 min)
→ Live demo with your actual data (15 min)
→ Your first impression + feedback (5 min)
→ Next steps (3 min)

We'll keep it practical. Sound good?"

[Wait for them to respond. They'll say "yes" or ask a question.]
```

**Why this works:**
- Sets expectations (no surprises)
- Shows respect for their time
- Creates comfort (structured, not rambling)

---

### Segment 2: Their Business (5 minutes)

**Your goal:** Understand their situation + create personalization

**Listen-first questions:**

```
"Tell me about your company—what do you do and how 
long have you been doing it?"

[Listen. Take notes. Show you care.]

"What's one financial question that keeps you up at night? 
Like, what would you LIKE to know about your business?"

[This is gold. This tells you what matters to them.]

"What's your biggest business challenge right now—
financial side?"

[Another listening question. You're diagnosing.]
```

**Your role:** Listener, not talker. Nod, take notes, show interest.

**What to listen for:**
- Are they healthy (growing, profitable)?
- Are they struggling (margins down, costs up)?
- Are they critical (negative profit, cash issues)?
- This helps you tune the demo to their situation.

---

### Segment 3: ZephyBloom Explanation (2 minutes)

**If they ask "What does ZephyBloom do?" say:**

```
"Great question. Basically, we analyze your company's 
finances and show you:

1. Health status (Healthy/Warning/Critical)
2. Your key numbers (margins, profit, ROI)
3. What's working + what needs attention
4. 3-5 specific recommendations you can actually do

All in seconds. And it's AI-powered, so it learns your sector.

The key thing: It's not generic. It's customized to YOUR 
company, YOUR data, YOUR situation.

Make sense?"
```

**Keep it simple:** 3 sentences max. Avoid jargon.

---

### Segment 4: Live Demo (15 minutes)

**This is the star of the call.**

#### Step 1: Input Their Data (3 minutes)

```
"Let's analyze YOUR company right now. 
Do you have your financial numbers handy? 
We need:
→ Annual revenue (last 12 months)
→ Cost of goods sold (or costs that change with production)
→ Operating expenses (salaries, rent, utilities)
→ Annual investments/capex

Do you have these? Or should I pull up a template?"
```

**If they have numbers:** Get them.  
**If they don't:** Use a realistic estimate. 
(You: "Let's assume 1M revenue, 300k COGS, 400k OpEx—adjust if different")

**Pro tip:** Enter their data LIVE as they give it.  
This makes it real (not a canned demo).

#### Step 2: Run Analysis (2 minutes)

```
"Okay, I'm entering these numbers... and hitting analyze...

[Click analyze button in UI]

Here we go! Let me walk you through what we see."
```

**What appears on screen:**
- Status badge (Healthy/Warning/Critical)
- Headline (executive summary)
- KPI snapshot (margins, EBITDA, ROI)
- Diagnosis (what's the main issue)
- Recommendations (3-5 actions)
- Cost of Inaction (urgency signal)

#### Step 3: Walk Through Results (8 minutes)

**Start with status:**

```
"Okay, the system is saying your company is [status].

Does that match YOUR gut feeling? Like, 
do you feel like things are [healthy/warning/critical]?"

[Listen. They might agree or disagree. Either way is learning.]

"Here's WHY we're showing [status]:
Your gross margin is [X]% (for [sector], healthy is [Y]%).
Your net margin is [X]% (benchmark is [Y]%).

So on revenue of 1M, you're netting [profit] annually."
```

**Then dig into diagnosis:**

```
"The #1 thing we see: [main issue from analysis].

Here's why it matters:
[Explain impact in money terms, not percentages]

For example: If you fixed this, 
you could gain back €[amount] annual."
```

**Then review recommendations:**

```
"Given that main issue, here are the 3 things 
that could help most:

1. [Recommendation]: Impact is €[amount]
   Here's how: [brief explanation]
   
2. [Recommendation]: Impact is €[amount]
   Here's how: [brief explanation]
   
3. [Recommendation]: Impact is €[amount]
   Here's how: [brief explanation]

Which one feels most doable to you?"

[They'll usually pick one. This is their action signal.]
```

**The Cost of Inaction (critical slide):**

```
"One more thing—look at this 'Cost of Inaction' number.

It says: If you DON'T fix [issue], 
you'll lose €[quarterly] in Q2 and €[annual] in the year.

So, waiting... costs money. 
Action... saves money.

That's why we show this—to create clarity."
```

**Throughout demo:**
- Ask questions ("Does this match what you're seeing?")
- Normalize their reactions ("Most companies see something like this")
- Show confidence in the system (you believe in it)

---

### Segment 5: Their Reaction (5 minutes)

**Ask for real feedback:**

```
"First impression—what stands out to you? 
Anything surprising? Anything off?"

[Listen. Be quiet. Don't defend. Just take it in.]

"Would this be helpful to look at every quarter? 
Like, tracking changes over time?"

[They'll say yes or explain what's missing.]

"If we added [X feature], would that make this more useful?"

[If they say yes: Great! We have that noted for v2.
If they say no: Cool, tells us product direction.]
```

**Read their energy:**
- Excited? You've got them.
- Skeptical? Ask more questions (don't oversell).
- Confused? Explain 1 thing differently.

---

### Segment 6: Next Steps (3 minutes)

```
"Here's what happens next:

1. You get login access (I'll email credentials)
2. You can re-run analyses anytime (try scenarios)
3. We ask: Give it a try this week, then tell us 
   what you think (2-minute feedback form)
4. Optional: We do check-in calls (you schedule)

That's it. No pressure. Just use it, 
tell us what works and what doesn't.

Questions?"
```

**Lock in commitment:**

```
"Can I count on you to try at least 2 analyses 
this week? Even just scenario planning?"

[Get verbal yes. This is important.]

"And you're good to fill out the feedback form after?"

[Another yes.]

"Perfect. I'll send everything via email after this call. 
Check email in the next 10 min."
```

**End on high note:**

```
"Thanks for your time. Really excited to get 
your feedback on this. You're helping shape 
the future of SME financial tools.

Seriously—your input matters.

Talk soon!"

[End call. Note: All seemed genuine + ready.]
```

---

## Call Notes Template

**Fill this out immediately after call (while fresh):**

```
ONBOARDING CALL NOTES

Company: ________________________    Date: ______________
Contact: ________________________    Duration: __________
Sector: __________________________   Email: ______________
Revenue (approx): ________________   Phone: ______________

SITUATION:
Main challenge: ________________________________
Industry position: ☐ Healthy ☐ Struggling ☐ Critical
Best case: ________________________________
Worst case: ________________________________

DEMO RESULTS:
Status shown: ☐ Healthy ☐ Warning ☐ Critical
Their reaction: ☐ Excited ☐ Interested ☐ Skeptical
Main feedback: ________________________________
Most interested in: [recommendation #1 / #2 / #3]
Questions they asked: ________________________________

ENGAGEMENT SIGNALS:
☐ Will definitely use this week
☐ Will probably use
☐ Unclear/unconvinced
☐ Positive energy throughout
☐ Came with questions
☐ Brought colleague (if yes: name _________)

NEXT STEPS:
☐ Credentials sent
☐ Guide materials sent
☐ Calendar invite for follow-up? ☐ Yes
☐ Any special follow-up needed? ________________

RED FLAGS / NOTES:
☐ None
☐ Seemed uninterested in [topic]
☐ Couldn't access files during call
☐ Asked about features we don't have
☐ Other: ________________________________

CONFIDENCE LEVEL: ☐ 🟢 WILL USE ☐ 🟡 MAYBE ☐ 🔴 UNLIKELY

POST-CALL ACTION:
→ Email credentials by: [time]
→ Include materials: ☐ User guide ☐ Feedback form ☐ Calendar
→ Follow-up call in: [1 week / 2 weeks / as-needed]
```

---

## Key Principles

### Principle 1: Listen More Than Talk
**Aim:** 60% them talking, 40% you talking

- You learn what matters to them
- They feel heard & important
- You can tailor everything to their situation

### Principle 2: Show, Don't Tell
**Demo the actual system with their data.**

- Far more compelling than slideshow
- Builds confidence (it actually works)
- They see themselves using it

### Principle 3: Be Normal
**You're testing a tool, not selling a Rolex.**

- Casual, friendly tone
- Okay to say "I don't know" (honest)
- Okay to admit limitations (build trust)

### Principle 4: Create Urgency (Not Pressure)
**Cost of Inaction slide does the heavy lifting.**

- They see the $ impact
- They want to act
- You're just facilitating (not pushing)

### Principle 5: Celebrate Small Wins
**If they're excited about 1 recommendation, WIN.**

- "That's exactly the kind of insight we're going for!"
- "I'm so glad that hit home"
- Show that their feedback matters

---

## Common Objections & Responses

### Objection 1: "This seems too simple"

```
Your response:
"I hear you—most people expect it to be super complex.
But honestly, that's by design. We wanted it to be:
→ Accurate (based on real financial math)
→ But also actionable (not overwhelming)

The deeper analysis is available too—we can get into 
the details. But we found most founders want the 
headline + next steps. Does that make sense?"
```

### Objection 2: "Can you guarantee accuracy?"

```
Your response:
"Great question. We're as accurate as your input data.
If your numbers are solid, our analysis is solid.
That said—we're analysis, not professional advice.
We always recommend: 
→ Share with your accountant (they'll validate)
→ Use our insights to ask better questions
→ Get a business advisor involved for implementation

We're your thinking partner, not the final word."
```

### Objection 3: "We already use [competitor/spreadsheet/consultant]"

```
Your response:
"Cool—what are you getting from them now?
[Listen]

And what's missing?
[Listen]

Yeah, that's exactly the gap we're trying to fill.
We're not trying to replace [tool]—
we're trying to give you better insights, faster.

Worst case: Try us for 2 weeks, 
see if we add something useful. Fair?"
```

### Objection 4: "I don't have time for this"

```
Your response:
"Totally fair. Here's the beauty—
you don't need time. The system takes 2 minutes.
The analysis comes back in seconds.
The feedback form is 2 minutes.

From you: Maybe 30 minutes total over 2 weeks.
From us: Available whenever you need us.

Can you spare a half-hour over 14 days?"
```

---

## Post-Call Follow-Up (Same Day)

**Email to send within 1 hour of call:**

```
Subject: Your ZephyBloom Onboarding - Next Steps

Hi [Name],

Great talking to you today! Excited you're interested in 
testing the system.

Here's what you need:

1. LOGIN CREDENTIALS
   Email: [email@company.com]
   Password: [temp pwd]
   Link: https://staging-api.zephybloom.it/login
   
2. MATERIALS TO READ (5 min)
   → User Guide: [Link to PILOT_USER_GUIDE.md]
   → FAQ: [Link]
   
3. NEXT STEPS
   → Log in anytime this week
   → Run 2-3 analyses (your actual company data, 
     or try "what-if" scenarios)
   → Fill out feedback form (2 min) after first analysis
   → Optional: We'll call you Friday to check in
   
4. QUESTIONS?
   → Reply to this email (I check constantly)
   → Or [direct phone number]

Can't wait to hear what you think!

[Your Name]
ZephyBloom
```

---

## Success Indicators

**You nailed the call if:**
- ✅ They understood status (Healthy/Warning/Critical) 
- ✅ They could point to 1 valuable insight
- ✅ They said "I'll try this"
- ✅ They asked 2+ questions (engaged!)
- ✅ They left with clear next steps
- ✅ They feel supported (not abandoned)

**You should follow-up if:**
- ⚠️ They seemed skeptical (send extra case studies)
- ⚠️ They had a specific question you couldn't answer (research + reply)
- ⚠️ They mentioned a competitor (acknowledge, explain difference)
- ⚠️ They need a specific feature (note for product team)

---

## Daily Onboarding Call Summary

**If you do multiple calls in a day, log them:**

```
CALLS COMPLETED TODAY

Call 1:
Name: ________________  Time: ________  Result: ☐ ✅ ☐ ⚠️
Company: ________________  Sector: ________________

Call 2:
Name: ________________  Time: ________  Result: ☐ ✅ ☐ ⚠️
Company: ________________  Sector: ________________

Call 3:
Name: ________________  Time: ________  Result: ☐ ✅ ☐ ⚠️
Company: ________________  Sector: ________________

Total calls: ____ | All followed up: ☐ Yes
Confidence all will use: ☐ High ☐ Medium ☐ Low
Any issues to escalate: ☐ None ☐ [describe]
```

---

## Mindset for Success

Remember:
- ✅ You're not selling—you're collaborating
- ✅ They accepted because they're curious
- ✅ Your job is to make it real + exciting
- ✅ Their feedback is gold (not criticism)
- ✅ You're building a community, not closing deals

---

**END OF ONBOARDING CALL GUIDE**

Use this for every call during Days 2-5 and beyond!

