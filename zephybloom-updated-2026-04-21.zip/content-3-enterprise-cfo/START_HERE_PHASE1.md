# 🚀 Phase 1: Start Here - Quick Launch Guide for 100 Clienti

> **Tempo stimato:** 10-15 minuti per setup locale  
> **Team required:** 1 developer  
> **Output:** PostgreSQL running, API ready to test

## ⚡ 3-Step Quick Start

### Step 1: Run Automated Setup (5 minuti)

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# Run the automated setup script
bash scripts/phase1_setup.sh
```

✅ **Questo farà automaticamente:**
- Avvia PostgreSQL + Redis con Docker
- Configura il file .env
- Installa dipendenze Python
- Crea tabelle database
- Crea user admin di test

### Step 2: Set OpenAI Key (1 minuto)

```bash
export ZB_OPENAI_API_KEY="sk-proj-YOUR_KEY_HERE"
```

(Sostituisci con la tua chiave OpenAI da https://platform.openai.com/api-keys)

### Step 3: Avviare il Backend (2 minuti)

```bash
# Attiva virtual environment
source venv/bin/activate

# Avvia il server
python -m uvicorn api.main:app --host 127.0.0.1 --port 8002 --reload
```

**Aspettati di vedere:**
```
INFO:     Uvicorn running on http://127.0.0.1:8002
INFO:     Application startup complete
```

✅ **Setup completo!**

---

## 🧪 Verifica che Tutto Funziona

### Test 1: Health Check
```bash
curl http://localhost:8002/health
```
Expected: `{"status":"healthy"}`

### Test 2: Swagger UI
Apri browser e vai a:
```
http://localhost:8002/docs
```

Dovresti vedere la documentazione interattiva dell'API.

### Test 3: Database Browser
Apri:
```
http://localhost:8081
```
(Adminer - web UI per PostgreSQL)

---

## 📊 Status Verifica

Dopo aver eseguito `phase1_setup.sh`:

| Componente | Status | Come verificare |
|-----------|--------|-----------------|
| Docker | ✅ Running | `docker ps \| grep zephybloom` |
| PostgreSQL | ✅ Ready | `psql -U zephybloom -d zephybloom_dev -c "SELECT 1"` |
| Redis | ✅ Ready | `redis-cli ping` → PONG |
| Python Env | ✅ Installed | `python -m pip list \| grep fastapi` |
| Database | ✅ Migrated | Adminer mostra tabelle |
| Admin User | ✅ Created | email: admin@zephybloom.com |

---

## 🔧 Se Qualcosa Non Funziona

### PostgreSQL connection refused
```bash
# Check if container is running
docker-compose ps

# Restart PostgreSQL
docker-compose restart postgres

# Check logs
docker-compose logs postgres
```

### Python dependencies error
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

### Port 8002 already in use
```bash
# Find process using port 8002
lsof -i :8002

# Kill it
kill -9 <PID>

# Or use different port
python -m uvicorn api.main:app --port 8003
```

### Database migration failed
```bash
# Check database connection
python -c "from db.session import init_session_factory; init_session_factory()"

# If DB is corrupted, reset:
docker-compose down -v
docker-compose up -d postgres
bash scripts/phase1_setup.sh
```

---

## 📋 Checklist Post-Setup

- [ ] Docker containers running (`docker ps`)
- [ ] PostgreSQL accessible
- [ ] Python virtual environment activated
- [ ] API server started on port 8002
- [ ] Health check endpoint responds
- [ ] Swagger UI accessible at /docs
- [ ] Admin user created
- [ ] OpenAI API key set

---

## 🎯 Next: Test-Drive l'API

Solo per sviluppatori che vogliono subito testare l'API:

### Test: Create Tenant

```bash
curl -X POST http://localhost:8002/api/tenants \
  -H "Content-Type: application/json" \
  -d '{"name": "Test Customer", "description": "First test"}'
```

### Test: CFO Analysis

```bash
curl -X POST http://localhost:8002/cfo/ai-analyze \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: default" \
  -d '{
    "fatturato": 1000000,
    "costi_variabili": 400000,
    "costi_fissi": 300000,
    "investimenti": 100000,
    "company_name": "Test Company"
  }'
```

---

## 📚 Documentazione Completa

Per una guida dettagliata con spiegazioni complete, vedi:
- [Phase 1 Setup Guide](./PHASE1_SETUP_100_CLIENTS.md)
- [Database Migration](../scripts/migrate_sqlite_to_postgres.py)
- [Docker Compose](../docker-compose.yml)

---

## 💬 Problemi?

Controlla i logs:
```bash
# API logs
tail -f logs/api.log

# Docker logs
docker-compose logs -f

# Python debug
python -c "from api.main import app; print('API OK')"
```

---

## 🎉 Done!

Hai completato la Fase 1 Setup! Il tuo backend è pronto per i primi 100 clienti.

**Prossimi step in ordine di priorità:**
1. ✅ PostgreSQL deployment (COMPLETATO)
2. → Re-enable authentication (next task)
3. → Docker containerization
4. → SSL/HTTPS setup
5. → Monitoring with Prometheus

Vai al prossimo task: **Task 2 - Re-enable Authentication**
