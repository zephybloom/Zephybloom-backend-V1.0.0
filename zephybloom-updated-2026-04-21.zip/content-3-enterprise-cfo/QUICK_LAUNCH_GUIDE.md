# 🚀 ZephyBloom CFO API - Quick Launch Guide

**Your app is already downloaded on your Mac.**

Everything is in: `/Users/thestar23/Downloads/content-3-enterprise-cfo`

---

## Step 1: Open Terminal

```bash
# Navigate to app folder
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# Make startup script executable
chmod +x START_APP.sh
```

---

## Step 2: Launch the App (One Command)

```bash
./START_APP.sh
```

**Output:**
```
════════════════════════════════════════════════════════
🚀 Server running!

  Mode:     development
  Port:     8001
  Workers:  4

  📍 API:      http://localhost:8001
  📍 Docs:     http://localhost:8001/docs
  📍 Health:   http://localhost:8001/health

════════════════════════════════════════════════════════

Press Ctrl+C to stop the server.
```

**That's it. Server is live.** ✅

---

## Step 3: Access the App

### Option A: API Documentation (for testing)
```
Browser: http://localhost:8001/docs
```
You'll see all endpoints. You can test them directly here.

### Option B: Check System Health
```
Browser: http://localhost:8001/health
```
Should say `"status": "healthy"`

---

## Step 4: Create Your First Pilot User (Day 1)

**Open a NEW terminal tab:**
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

python3 scripts/create_pilot_user.py \
  --email mario@acmeinc.it \
  --company "Acme Inc" \
  --sector "Manufacturing"
```

**Output:**
```
============================================================
✅ PILOT USER CREATED
============================================================
Email:              mario@acmeinc.it
Company:            Acme Inc
Sector:             Manufacturing
Tenant:             acmeinc.it

Temporary Password: Ks7$mQ2!x9Lp
                    (User must change on first login)
============================================================
```

**Copy that password. You'll give it to Mario during the onboarding call.**

---

## Step 5: During Onboarding Call with User

```
You: "Mario, we're ready! You can access ZephyBloom now."
You: "Go to: http://localhost:8001"
You: "Email: mario@acmeinc.it"
You: "Password: Ks7$mQ2!x9Lp"
You: "On first login, change your password to something you remember"

Mario: [Logs in from his browser]
Mario: [Changes password]
Mario: [You do live demo in his browser]
```

---

## Useful Commands

### List all pilot users
```bash
python3 scripts/create_pilot_user.py --list
```

### Delete a user (if needed)
```bash
python3 scripts/create_pilot_user.py --delete mario@acmeinc.it
```

### Start in production mode (8 workers, optimized)
```bash
./START_APP.sh --prod
```

### Start on custom port (e.g., 9000)
```bash
./START_APP.sh --port 9000
```

### Show all options
```bash
./START_APP.sh --help
```

---

## Monitoring While Running

**Open another terminal tab:**
```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# Real-time monitoring dashboard
python3 scripts/pilot_monitoring.py --watch 30

# Export metrics to JSON
python3 scripts/pilot_monitoring.py --export json
```

---

## Stop the Server

In the terminal where the app is running:
```
Press Ctrl+C
```

You'll see:
```
Shutting down
Waiting for application shutdown
Application shutdown complete
```

---

## Troubleshooting

### "Command not found: python3"
**Install Python:**
- Go to https://www.python.org/downloads/
- Download Python 3.9+
- Install it
- Try again

### "zephytheory.db not found"
**It will be created automatically** on first run. Don't worry.

### "Port 8001 already in use"
Use a different port:
```bash
./START_APP.sh --port 9000
```

### "Module not found" error
Your virtual environment may need updating:
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Server won't start / cryptic error
Check the log carefully. Usually it's:
- Python version too old (need 3.9+)
- Missing dependency
- Port in use

**Option:** Start in a clean Python environment:
```bash
rm -rf venv
./START_APP.sh  # Will recreate venv automatically
```

---

## What's Running?

```
✅ FastAPI web server (Python)
✅ SQLite database (local)
✅ Authentication system
✅ Rate limiting
✅ Monitoring tools
✅ All ZephyBloom financial engines
```

Everything you need is already here. **Nothing else to install or configure.**

---

## Timeline

| Date | Action |
|------|--------|
| **Today (April 15)** | Read this guide ✓ |
| **Tomorrow (April 16)** | Run `./START_APP.sh` at 9 AM |
| **Day 4-5 (April 20-21)** | First users log in |
| **April 22 - May 5** | Monitor with `pilot_monitoring.py` |
| **May 6-8** | Exit interviews + decision |

---

## Questions?

Everything is documented in:
- `PILOT_DEPLOYMENT_PLAN.md` - Full strategy
- `LIVE_SUPPORT_RUNBOOK.md` - How to support users
- `WEEK1_WEEK2_MONITORING_GUIDE.md` - How to track success

You're ready. **Go launch.** 🚀
