# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, List, Tuple, Optional

from core.schemas import Answer, Advisory
from strategy.frameworks import (
    extract_business_state,
    diagnose_core_problem,
    build_priority_actions,
    growth_framework,
    pricing_framework,
    positioning_framework,
    operating_framework,
    strategic_scorecard,
    strategic_snapshot,
    _sector_key,
    _business_phase,
)


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _safe_str(x: Any, default: str = "") -> str:
    try:
        s = str(x).strip()
        return s if s else default
    except Exception:
        return default


def _fmt_eur(x: float) -> str:
    try:
        v = float(x)
    except Exception:
        return "-"
    sign = "-" if v < 0 else ""
    v = abs(v)

    if v >= 1_000_000_000:
        return f"{sign}{v/1_000_000_000:.2f} mld €"
    if v >= 1_000_000:
        return f"{sign}{v/1_000_000:.2f} mln €"
    if v >= 1_000:
        return f"{sign}{v/1_000:.1f} k€"
    return f"{sign}€ {v:,.0f}".replace(",", ".")


def _fmt_pct_ratio(x: float) -> str:
    try:
        return f"{float(x) * 100:.1f}%"
    except Exception:
        return "-"


def _fmt_days(x: float) -> str:
    try:
        return f"{float(x):.0f} giorni"
    except Exception:
        return "-"


def _fmt_score(x: float) -> str:
    try:
        value = max(0.0, min(float(x), 1.2))
        return f"{value * 100:.0f}/100"
    except Exception:
        return "-"


def _top_score_areas(scorecard: Dict[str, float]) -> Tuple[List[str], List[str]]:
    """
    Ritorna:
    - aree deboli
    - aree forti
    """
    weak: List[str] = []
    strong: List[str] = []

    mapping = {
        "marginality": "marginalità",
        "profitability": "profitto",
        "capital_efficiency": "efficienza del capitale",
        "cash_discipline": "disciplina di cassa",
        "acquisition_efficiency": "acquisizione",
        "retention_health": "retention",
        "expansion_health": "espansione clienti",
    }

    for key, raw in (scorecard or {}).items():
        label = mapping.get(key, key)
        val = _safe_float(raw, 0.0)
        if val < 0.80:
            weak.append(label)
        elif val >= 1.0:
            strong.append(label)

    return weak, strong


def _problem_to_priority(problem: str) -> str:
    mapping = {
        "assenza di base dati commerciale": "costruire una macchina minima di acquisizione e validazione",
        "domanda non ancora validata": "validare problema, offerta e risposta reale del mercato",
        "marginalità lorda troppo debole": "alzare il valore trattenuto su ogni euro di ricavo",
        "struttura costi fissi troppo pesante": "snellire la struttura e aumentare la produttività",
        "pressione sulla cassa": "ridurre l’assorbimento finanziario dell’operatività",
        "ritorno sul capitale insufficiente": "aumentare la resa del capitale già impiegato",
        "acquisizione clienti poco efficiente": "migliorare CAC, conversione e qualità del traffico",
        "conversione commerciale debole": "rafforzare il processo di vendita e la proposta di valore",
        "ritenzione debole": "aumentare valore percepito e tenuta clienti",
        "espansione debole della base clienti": "monetizzare meglio la base già acquisita",
        "mancanza di accelerazione strategica": "scegliere una sola leva primaria da spingere davvero",
    }
    return mapping.get(problem, "costruire una priorità esecutiva chiara")


class StrategyEngine:
    """
    Layer strategico sopra al CFO engine:
    - legge i numeri
    - identifica il vero collo di bottiglia
    - trasforma KPI in priorità decisionali
    - adatta il focus alla richiesta utente
    - aggiunge lettura operativa, scorecard e next moves
    """

    def run(self, data: Dict[str, Any], prompt_text: str = "") -> Answer:
        data = data or {}

        state = extract_business_state(data)
        sector = _sector_key(data)
        phase = _business_phase(data, state)

        snap = strategic_snapshot(data)
        problem = _safe_str(snap.get("problem"))
        explanation = _safe_str(snap.get("explanation"))
        primary_lever = _safe_str(snap.get("primary_lever"))

        if not problem or not explanation or not primary_lever:
            problem, explanation, primary_lever = diagnose_core_problem(
                state,
                sector=sector,
                phase=phase,
            )

        actions = build_priority_actions(
            state,
            problem,
            sector=sector,
            phase=phase,
        )

        growth = growth_framework(state, phase=phase)
        pricing = pricing_framework(state, sector=sector)
        positioning = positioning_framework(data, phase=phase)
        operating = operating_framework(problem, phase=phase)
        scorecard = strategic_scorecard(state, sector=sector)

        focus_hint = self._infer_focus_from_prompt(prompt_text)
        actions = self._prioritize_actions_by_focus(actions, focus_hint)

        weak_areas, strong_areas = _top_score_areas(scorecard)

        advisory = self._make_advisory(
            state=state,
            problem=problem,
            explanation=explanation,
            actions=actions,
            scorecard=scorecard,
            sector=sector,
            phase=phase,
            weak_areas=weak_areas,
        )

        narrative = self._build_narrative(
            state=state,
            problem=problem,
            explanation=explanation,
            primary_lever=primary_lever,
            actions=actions,
            growth=growth,
            pricing=pricing,
            positioning=positioning,
            operating=operating,
            scorecard=scorecard,
            focus_hint=focus_hint,
            sector=sector,
            phase=phase,
            weak_areas=weak_areas,
            strong_areas=strong_areas,
        )

        meta: Dict[str, Any] = {
            "primary_lever": primary_lever,
            "problem": problem,
            "focus_hint": focus_hint,
            "sector": sector,
            "phase": phase,
            "scorecard": scorecard,
            "weak_areas": weak_areas,
            "strong_areas": strong_areas,
            "growth_framework": growth,
            "pricing_framework": pricing,
            "positioning_framework": positioning,
            "operating_framework": operating,
            "top_actions": actions[:3],
            "execution_priority": _problem_to_priority(problem),
        }

        try:
            return Answer(
                intent="strategic_analysis",
                narrative=narrative,
                advisories=[advisory],
                meta=meta,
            )
        except TypeError:
            return Answer(
                intent="strategic_analysis",
                narrative=narrative,
                advisories=[advisory],
            )

    def _make_advisory(
        self,
        *,
        state: Dict[str, float],
        problem: str,
        explanation: str,
        actions: List[Dict[str, str]],
        scorecard: Dict[str, float],
        sector: str,
        phase: str,
        weak_areas: List[str],
    ) -> Advisory:
        severity = self._severity_from_problem(problem, scorecard, phase=phase)
        suggestions = [a.get("title", "") for a in actions[:3] if a.get("title")]

        advisory_kwargs: Dict[str, Any] = {
            "code": "STRATEGIC_BOTTLENECK",
            "title": f"Collo di bottiglia: {problem}",
            "detail": explanation,
            "severity": severity,
            "suggestions": suggestions,
        }

        meta = {
            "mc_rate": _safe_float(state.get("mc_rate")),
            "net_margin": _safe_float(state.get("net_margin")),
            "roi": _safe_float(state.get("roi")),
            "ccc": _safe_float(state.get("ccc")),
            "sector": sector,
            "phase": phase,
            "scorecard": scorecard,
            "weak_areas": weak_areas,
        }

        try:
            return Advisory(**advisory_kwargs, meta=meta)
        except TypeError:
            return Advisory(**advisory_kwargs)

    def _severity_from_problem(
        self,
        problem: str,
        scorecard: Dict[str, float],
        phase: str = "unknown",
    ) -> str:
        if problem in {
            "assenza di base dati commerciale",
            "domanda non ancora validata",
            "marginalità lorda troppo debole",
            "pressione sulla cassa",
        }:
            return "high"

        if problem in {
            "struttura costi fissi troppo pesante",
            "ritorno sul capitale insufficiente",
            "acquisizione clienti poco efficiente",
            "conversione commerciale debole",
            "ritenzione debole",
            "espansione debole della base clienti",
        }:
            if phase in {"scale", "expansion"}:
                return "high"
            return "medium"

        weak_areas = 0
        for _, v in (scorecard or {}).items():
            if _safe_float(v, 1.0) < 0.80:
                weak_areas += 1

        if weak_areas >= 4:
            return "medium"
        if weak_areas >= 2:
            return "low"
        return "low"

    def _infer_focus_from_prompt(self, prompt_text: str) -> str:
        t = (prompt_text or "").lower()

        if any(x in t for x in ("pricing", "prezzo", "prezzi", "offerta", "pacchetto", "ticket")):
            return "pricing"
        if any(x in t for x in ("posizionamento", "mercato", "brand", "usp", "messaggio")):
            return "positioning"
        if any(x in t for x in ("crescere", "scalare", "growth", "acquisizione", "lead", "espandere")):
            return "growth"
        if any(x in t for x in ("cash", "cassa", "liquidità", "liquidita", "ccc", "incassi", "pagamenti")):
            return "cash"
        if any(x in t for x in ("retention", "churn", "upsell", "nrr", "clienti a rischio")):
            return "retention"
        if any(x in t for x in ("conversione", "closing", "chiusura", "funnel", "vendita", "sales")):
            return "conversion"
        if any(x in t for x in ("costi", "struttura", "produttività", "produttivita", "efficienza")):
            return "efficiency"

        return "general"

    def _prioritize_actions_by_focus(
        self,
        actions: List[Dict[str, str]],
        focus_hint: str,
    ) -> List[Dict[str, str]]:
        if not actions:
            return actions

        def score(action: Dict[str, str]) -> Tuple[int, str]:
            text = f"{action.get('title', '')} {action.get('why', '')} {action.get('how', '')}".lower()
            bonus = 0

            if focus_hint == "pricing" and any(x in text for x in ("pricing", "prezzo", "prezzi", "valore", "pacchetti", "bundle")):
                bonus += 4
            if focus_hint == "positioning" and any(x in text for x in ("mercato", "valore", "offerta", "segment", "messaggio")):
                bonus += 4
            if focus_hint == "growth" and any(x in text for x in ("acquis", "conversion", "upsell", "motore", "canale")):
                bonus += 4
            if focus_hint == "cash" and any(x in text for x in ("cassa", "dso", "dpo", "scorte", "incass", "pagamento")):
                bonus += 4
            if focus_hint == "retention" and any(x in text for x in ("retention", "churn", "cliente", "upsell", "onboarding")):
                bonus += 4
            if focus_hint == "conversion" and any(x in text for x in ("conversion", "pitch", "follow-up", "qualifica", "closing")):
                bonus += 4
            if focus_hint == "efficiency" and any(x in text for x in ("costi", "produttività", "produttivita", "efficienza", "struttura")):
                bonus += 4

            return (-bonus, action.get("title", ""))

        return sorted(actions, key=score)

    def _build_narrative(
        self,
        *,
        state: Dict[str, float],
        problem: str,
        explanation: str,
        primary_lever: str,
        actions: List[Dict[str, str]],
        growth: Dict[str, List[str]],
        pricing: Dict[str, str],
        positioning: Dict[str, str],
        operating: Dict[str, List[str]],
        scorecard: Dict[str, float],
        focus_hint: str,
        sector: str,
        phase: str,
        weak_areas: List[str],
        strong_areas: List[str],
    ) -> str:
        top_actions = actions[:3]
        parts: List[str] = []

        fatturato = _safe_float(state.get("fatturato"))
        utile = _safe_float(state.get("utile"))
        ebitda = _safe_float(state.get("ebitda"))
        mc_rate = _safe_float(state.get("mc_rate"))
        net_margin = _safe_float(state.get("net_margin"))
        roi = _safe_float(state.get("roi"))
        ccc = _safe_float(state.get("ccc"))
        ltv_cac = _safe_float(state.get("ltv_cac"))
        churn = _safe_float(state.get("churn"))
        nrr = _safe_float(state.get("nrr"))
        conversion_rate = _safe_float(state.get("conversion_rate"))

        parts.append(
            "Executive diagnosis:\n"
            f"- Settore: {sector}\n"
            f"- Fase: {phase}\n"
            f"- Fatturato: {_fmt_eur(fatturato)}\n"
            f"- Utile: {_fmt_eur(utile)}\n"
            f"- EBITDA: {_fmt_eur(ebitda)}\n"
            f"- MC: {_fmt_pct_ratio(mc_rate)}\n"
            f"- Margine netto: {_fmt_pct_ratio(net_margin)}\n"
            f"- ROI: {_fmt_pct_ratio(roi)}\n"
            f"- CCC: {_fmt_days(ccc)}"
        )

        extra_metrics: List[str] = []
        if ltv_cac > 0:
            extra_metrics.append(f"- LTV/CAC: {ltv_cac:.2f}x")
        if churn > 0:
            extra_metrics.append(f"- Churn: {_fmt_pct_ratio(churn)}")
        if nrr > 0:
            extra_metrics.append(f"- NRR: {_fmt_pct_ratio(nrr)}")
        if conversion_rate > 0:
            extra_metrics.append(f"- Conversione: {_fmt_pct_ratio(conversion_rate)}")

        if extra_metrics:
            parts.append("Metriche di crescita:\n" + "\n".join(extra_metrics))

        parts.append(
            "Core problem:\n"
            f"- {problem}\n"
            f"- {explanation}\n"
            f"- Leva prioritaria: {primary_lever}"
        )

        if weak_areas:
            parts.append("Aree sotto pressione:\n" + "\n".join([f"- {x}" for x in weak_areas[:5]]))

        if strong_areas:
            parts.append("Aree relativamente forti:\n" + "\n".join([f"- {x}" for x in strong_areas[:4]]))

        if focus_hint != "general":
            parts.append(
                "Focus richiesto dall’utente:\n"
                f"- La richiesta è orientata soprattutto a: {focus_hint}"
            )

        score_lines: List[str] = []
        for key, value in scorecard.items():
            label = {
                "marginality": "Marginalità",
                "profitability": "Profitto",
                "capital_efficiency": "Efficienza capitale",
                "cash_discipline": "Disciplina di cassa",
                "acquisition_efficiency": "Efficienza acquisizione",
                "retention_health": "Salute retention",
                "expansion_health": "Salute espansione",
            }.get(key, key)
            score_lines.append(f"- {label}: {_fmt_score(value)}")

        if score_lines:
            parts.append("Scorecard strategica:\n" + "\n".join(score_lines))

        action_lines: List[str] = []
        for i, a in enumerate(top_actions, start=1):
            title = a.get("title", "Azione")
            why = a.get("why", "")
            how = a.get("how", "")
            action_lines.append(f"{i}. {title}\n   - Perché: {why}\n   - Come: {how}")

        if action_lines:
            parts.append("Azioni prioritarie:\n" + "\n".join(action_lines))

        parts.append(
            "Growth system:\n"
            f"- Acquisition: {', '.join(growth.get('acquisition', []))}\n"
            f"- Conversion: {', '.join(growth.get('conversion', []))}\n"
            f"- Retention: {', '.join(growth.get('retention', []))}\n"
            f"- Expansion: {', '.join(growth.get('expansion', []))}"
        )

        parts.append(
            "Pricing & positioning:\n"
            f"- Pricing posture: {pricing.get('posture', '-')}\n"
            f"- Focus pricing: {pricing.get('focus', '-')}\n"
            f"- Azione pricing: {pricing.get('actions', '-')}\n"
            f"- Packaging: {pricing.get('packaging', '-')}\n"
            f"- Posizionamento: {positioning.get('core_message', '-')}\n"
            f"- Angolo di mercato: {positioning.get('angle', '-')}\n"
            f"- Prova da portare al mercato: {positioning.get('proof', '-')}"
        )

        weekly = operating.get("weekly", [])[:3]
        monthly = operating.get("monthly", [])[:3]
        quarterly = operating.get("quarterly", [])[:3]

        parts.append(
            "Operating rhythm:\n"
            f"- Weekly: {', '.join(weekly) if weekly else '-'}\n"
            f"- Monthly: {', '.join(monthly) if monthly else '-'}\n"
            f"- Quarterly: {', '.join(quarterly) if quarterly else '-'}"
        )

        parts.append(
            "Executive conclusion:\n"
            "Il punto non è fare più attività, ma spingere la leva giusta nell’ordine giusto. "
            f"Oggi la priorità reale è {primary_lever}. "
            "Fino a quando questo collo di bottiglia non viene corretto, ogni tentativo di crescita rischia di aumentare complessità più che valore. "
            "La crescita sana arriverà quando margine, struttura, cassa e motore commerciale inizieranno a muoversi come un sistema unico."
        )

        return "\n\n".join(parts)