# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, List, Tuple


# -------------------------
# Helpers
# -------------------------
def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _safe_str(v: Any, default: str = "") -> str:
    try:
        s = str(v).strip()
        return s if s else default
    except Exception:
        return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _pct(v: Any) -> float:
    """
    Normalizza valori percentuali/ratio:
    - 0.23 -> 0.23
    - 23   -> 0.23
    - 110  -> 1.10
    - 1.10 -> 1.10
    """
    x = _safe_float(v, 0.0)
    if x <= 0:
        return 0.0
    if x > 1.5:
        return x / 100.0
    return x


def _rate_or_zero(v: Any) -> float:
    return max(0.0, _pct(v))


def _nonneg(v: Any) -> float:
    return max(0.0, _safe_float(v, 0.0))


def _sector_key(data: Dict[str, Any]) -> str:
    s = _safe_str(data.get("sector"), "default").lower()
    aliases = {
        "ristorazione": "restaurant",
        "ristorante": "restaurant",
        "pizzeria": "restaurant",
        "hotel": "hotel",
        "albergo": "hotel",
        "saas": "saas",
        "software": "saas",
        "ecommerce": "ecommerce",
        "e-commerce": "ecommerce",
        "retail": "retail",
        "agenzia": "agency",
        "agency": "agency",
        "servizi": "services",
        "service": "services",
        "consulting": "services",
        "consulenza": "services",
        "default": "default",
    }
    return aliases.get(s, s or "default")


def _get_thresholds(sector: str) -> Dict[str, float]:
    """
    Soglie euristiche strategiche.
    I valori sono ratio, non percentuali intere.
    """
    base = {
        "mc_rate_min": 0.35,
        "net_margin_min": 0.08,
        "roi_min": 0.12,
        "ccc_max": 60.0,
        "ltv_cac_min": 3.0,
        "churn_max": 0.05,
        "nrr_min": 1.00,
        "conversion_rate_min": 0.10,
        "repeat_rate_min": 0.20,
    }

    sector_overrides = {
        "restaurant": {
            "mc_rate_min": 0.45,
            "net_margin_min": 0.08,
            "roi_min": 0.15,
            "ccc_max": 20.0,
            "conversion_rate_min": 0.12,
            "repeat_rate_min": 0.15,
        },
        "hotel": {
            "mc_rate_min": 0.50,
            "net_margin_min": 0.10,
            "roi_min": 0.14,
            "ccc_max": 25.0,
            "conversion_rate_min": 0.10,
            "repeat_rate_min": 0.20,
        },
        "saas": {
            "mc_rate_min": 0.70,
            "net_margin_min": 0.05,
            "roi_min": 0.10,
            "ccc_max": 40.0,
            "ltv_cac_min": 3.5,
            "churn_max": 0.04,
            "nrr_min": 1.05,
            "conversion_rate_min": 0.08,
            "repeat_rate_min": 0.30,
        },
        "ecommerce": {
            "mc_rate_min": 0.30,
            "net_margin_min": 0.06,
            "roi_min": 0.12,
            "ccc_max": 45.0,
            "conversion_rate_min": 0.02,
            "repeat_rate_min": 0.18,
        },
        "agency": {
            "mc_rate_min": 0.50,
            "net_margin_min": 0.10,
            "roi_min": 0.15,
            "ccc_max": 35.0,
            "conversion_rate_min": 0.12,
            "repeat_rate_min": 0.25,
        },
        "services": {
            "mc_rate_min": 0.45,
            "net_margin_min": 0.10,
            "roi_min": 0.14,
            "ccc_max": 40.0,
            "conversion_rate_min": 0.10,
            "repeat_rate_min": 0.22,
        },
    }

    out = dict(base)
    out.update(sector_overrides.get(sector, {}))
    return out


def _business_phase(data: Dict[str, Any], state: Dict[str, float]) -> str:
    """
    Fase business:
    - pre-revenue
    - early
    - growth
    - scale
    """
    fatt = state.get("fatturato", 0.0)
    utile = state.get("utile", 0.0)
    leads = state.get("leads", 0.0)
    customers = _safe_float(data.get("customers") or data.get("clienti"))
    mrr = _safe_float(data.get("mrr"))

    if fatt <= 0 and mrr <= 0:
        return "pre-revenue"

    if fatt < 250_000:
        if leads > 0 or customers > 0:
            return "early"
        return "early"

    if fatt < 2_000_000:
        return "growth"

    if utile > 0:
        return "scale"

    return "growth"


def _segment_hint(data: Dict[str, Any], state: Dict[str, float]) -> str:
    avg_ticket = state.get("avg_ticket", 0.0)
    if avg_ticket <= 0:
        return "unknown"
    if avg_ticket < 100:
        return "low_ticket"
    if avg_ticket < 1000:
        return "mid_ticket"
    return "high_ticket"


# -------------------------
# State extraction
# -------------------------
def extract_business_state(data: Dict[str, Any]) -> Dict[str, float]:
    fatt = _nonneg(data.get("fatturato") or data.get("sales") or data.get("revenue"))
    cv = _nonneg(data.get("costi_variabili") or data.get("cogs"))
    cf = _nonneg(data.get("costi_fissi"))
    inv = _nonneg(data.get("investimenti"))
    amm = _nonneg(data.get("ammortamenti"))

    utile = fatt - cv - cf
    ebitda = utile + amm
    mc = fatt - cv
    mc_rate = (mc / fatt) if fatt > 0 else 0.0
    net_margin = (utile / fatt) if fatt > 0 else 0.0
    roi = (utile / inv) if inv > 0 else 0.0

    dso = _nonneg(data.get("dso"))
    dio = _nonneg(data.get("dio"))
    dpo = _nonneg(data.get("dpo"))
    ccc = max(0.0, dso + dio - dpo)

    churn = _rate_or_zero(data.get("churn_rate", 0.0))
    nrr = _rate_or_zero(data.get("nrr", 0.0))
    ltv = _nonneg(data.get("ltv"))
    cac = _nonneg(data.get("cac"))
    ltv_cac = (ltv / cac) if cac > 0 else 0.0

    leads = _nonneg(data.get("leads"))
    avg_ticket = _nonneg(data.get("avg_ticket") or data.get("ticket_medio"))
    repeat_rate = _rate_or_zero(data.get("repeat_rate", 0.0))

    conversion_rate_raw = data.get("conversion_rate", 0.0)
    conversion_rate = _rate_or_zero(conversion_rate_raw)

    if conversion_rate <= 0.0 and leads > 0:
        customers = _nonneg(data.get("customers") or data.get("clienti") or data.get("closed_customers"))
        if customers > 0:
            conversion_rate = customers / leads

    conversion_rate = _clamp(conversion_rate, 0.0, 1.5)

    mrr = _nonneg(data.get("mrr"))
    arpu = _nonneg(data.get("arpu"))
    customers = _nonneg(data.get("customers") or data.get("clienti"))
    payback_months = (cac / arpu) if (cac > 0 and arpu > 0) else 0.0

    return {
        "fatturato": fatt,
        "costi_variabili": cv,
        "costi_fissi": cf,
        "investimenti": inv,
        "ammortamenti": amm,
        "utile": utile,
        "ebitda": ebitda,
        "mc": mc,
        "mc_rate": mc_rate,
        "net_margin": net_margin,
        "roi": roi,
        "dso": dso,
        "dio": dio,
        "dpo": dpo,
        "ccc": ccc,
        "churn": churn,
        "nrr": nrr,
        "ltv": ltv,
        "cac": cac,
        "ltv_cac": ltv_cac,
        "leads": leads,
        "conversion_rate": conversion_rate,
        "avg_ticket": avg_ticket,
        "repeat_rate": repeat_rate,
        "mrr": mrr,
        "arpu": arpu,
        "customers": customers,
        "payback_months": payback_months,
    }


# -------------------------
# Diagnosis
# -------------------------
def diagnose_core_problem(
    state: Dict[str, float],
    sector: str = "default",
    phase: str = "growth",
) -> Tuple[str, str, str]:
    """
    Ritorna:
    - problema principale
    - spiegazione
    - leva prioritaria
    """
    th = _get_thresholds(sector)

    mc_rate = state.get("mc_rate", 0.0)
    net_margin = state.get("net_margin", 0.0)
    ccc = state.get("ccc", 0.0)
    roi = state.get("roi", 0.0)
    fatt = state.get("fatturato", 0.0)
    utile = state.get("utile", 0.0)
    ltv_cac = state.get("ltv_cac", 0.0)
    churn = state.get("churn", 0.0)
    nrr = state.get("nrr", 0.0)
    leads = state.get("leads", 0.0)
    conversion_rate = state.get("conversion_rate", 0.0)
    repeat_rate = state.get("repeat_rate", 0.0)

    if fatt <= 0:
        return (
            "assenza di base dati commerciale",
            "non risultano ricavi sufficienti per formulare una diagnosi strategica affidabile",
            "costruzione motore acquisizione",
        )

    if phase in {"pre-revenue", "early"} and leads <= 0:
        return (
            "domanda non ancora validata",
            "mancano segnali chiari di domanda ripetibile: prima di scalare, va verificato che il mercato risponda davvero",
            "validazione offerta + acquisizione",
        )

    if mc_rate < th["mc_rate_min"]:
        return (
            "marginalità lorda troppo debole",
            "il margine di contribuzione è sotto soglia: stai generando ricavi, ma trattieni troppo poco valore per finanziare crescita e struttura",
            "pricing + costi variabili",
        )

    if net_margin < th["net_margin_min"] and mc_rate >= th["mc_rate_min"]:
        return (
            "struttura costi fissi troppo pesante",
            "la marginalità lorda esiste, ma la struttura assorbe troppo: questo limita utile, flessibilità e capacità di reinvestimento",
            "snellimento struttura + produttività",
        )

    if ccc > th["ccc_max"]:
        return (
            "pressione sulla cassa",
            "il ciclo di conversione della cassa è troppo lungo: il business può sembrare sano nei conti ma soffrire nella liquidità operativa",
            "working capital",
        )

    if roi < th["roi_min"] and utile > 0:
        return (
            "ritorno sul capitale insufficiente",
            "stai producendo utile, ma il capitale impiegato rende meno di quanto dovrebbe rispetto al rischio e allo sforzo operativo",
            "efficienza allocazione capitale",
        )

    if ltv_cac > 0 and ltv_cac < th["ltv_cac_min"]:
        return (
            "acquisizione clienti poco efficiente",
            "il rapporto LTV/CAC è debole: il costo di acquisizione erode troppo il valore che il cliente genera nel tempo",
            "marketing efficiency + conversione",
        )

    if conversion_rate > 0 and conversion_rate < th["conversion_rate_min"] and leads > 0:
        return (
            "conversione commerciale debole",
            "stai generando attenzione, ma una quota troppo bassa di lead si trasforma in clienti o contratti",
            "sales process + proposta di valore",
        )

    if churn > th["churn_max"]:
        return (
            "ritenzione debole",
            "la perdita clienti è troppo elevata: stai riempiendo un secchio bucato e questo riduce la forza del business nel tempo",
            "retention + valore percepito",
        )

    if nrr > 0 and nrr < th["nrr_min"]:
        return (
            "espansione debole della base clienti",
            "la base clienti non cresce abbastanza in valore nel tempo: stai monetizzando poco chi hai già acquisito",
            "upsell + espansione account",
        )

    if repeat_rate > 0 and repeat_rate < th["repeat_rate_min"] and phase in {"growth", "scale"}:
        return (
            "base clienti poco monetizzata",
            "i clienti entrano, ma il riacquisto o la continuità di spesa restano troppo bassi rispetto al potenziale",
            "retention commerciale + account growth",
        )

    return (
        "mancanza di accelerazione strategica",
        "il business appare discretamente sano, ma non emerge ancora una leva dominante di crescita: serve scegliere cosa spingere per primo",
        "growth engine",
    )


# -------------------------
# Actions
# -------------------------
def build_priority_actions(
    state: Dict[str, float],
    problem: str,
    sector: str = "default",
    phase: str = "growth",
) -> List[Dict[str, str]]:
    actions: List[Dict[str, str]] = []
    avg_ticket = state.get("avg_ticket", 0.0)
    segment = "low" if avg_ticket < 100 else "mid" if avg_ticket < 1000 else "high"

    if problem == "assenza di base dati commerciale":
        actions.extend([
            {
                "title": "Costruisci un’offerta iniziale chiara",
                "why": "senza una proposta semplice e comprensibile è difficile validare la domanda reale",
                "how": "definisci un problema specifico, una promessa chiara e un output misurabile per il cliente",
            },
            {
                "title": "Attiva un canale di acquisizione principale",
                "why": "all’inizio serve capire da dove arriva la domanda, non essere ovunque",
                "how": "scegli un solo canale e misuralo per 30 giorni: outbound, ads, referral o partnership",
            },
            {
                "title": "Trasforma i feedback in prodotto",
                "why": "nelle fasi iniziali il mercato ti dice cosa semplificare, cosa togliere e cosa enfatizzare",
                "how": "raccogli obiezioni, call notes e pattern di interesse, poi aggiorna offerta e messaggio",
            },
        ])

    elif problem == "domanda non ancora validata":
        actions.extend([
            {
                "title": "Riduci la complessità dell’offerta",
                "why": "più l’offerta è semplice, più il mercato può rispondere chiaramente",
                "how": "concentra il messaggio su un problema, un target, una trasformazione",
            },
            {
                "title": "Valida con outreach diretto",
                "why": "prima di scalare serve capire se il problema viene percepito davvero",
                "how": "fai 30–50 conversazioni o call con prospect reali e misura interesse, obiezioni e closing",
            },
            {
                "title": "Crea una prova rapida di valore",
                "why": "il mercato converte più facilmente quando vede un prima/dopo tangibile",
                "how": "usa demo, casi studio, simulazioni economiche o audit gratuiti ad alto impatto",
            },
        ])

    elif problem == "marginalità lorda troppo debole":
        actions.extend([
            {
                "title": "Riallinea il pricing",
                "why": "se il cliente percepisce più valore di quanto paghi, stai lasciando margine sul tavolo",
                "how": "testa aumenti selettivi del 5–12% su segmenti premium o meno sensibili al prezzo",
            },
            {
                "title": "Riduci costi variabili",
                "why": "ogni punto di costo variabile tagliato migliora direttamente il margine di contribuzione",
                "how": "rinegozia fornitori, standardizza delivery, elimina sprechi e complessità non monetizzate",
            },
            {
                "title": "Semplifica l’offerta",
                "why": "più complessità operativa spesso significa più costo e meno margine",
                "how": "spingi le offerte più profittevoli e riduci le eccezioni operative",
            },
        ])

    elif problem == "struttura costi fissi troppo pesante":
        actions.extend([
            {
                "title": "Taglia i costi fissi non produttivi",
                "why": "i costi fissi devono sostenere crescita o efficienza, non solo presenza",
                "how": "mappa i costi per funzione e rimuovi ciò che non genera ricavo, velocità o controllo",
            },
            {
                "title": "Aumenta produttività per FTE",
                "why": "una struttura sana genera più output a parità di squadra",
                "how": "introduci automazioni, SOP e KPI per reparto",
            },
            {
                "title": "Converti costi fissi in variabili",
                "why": "riduci il rischio operativo e migliori la flessibilità",
                "how": "sposta parte delle attività su partner, freelance o modelli a performance",
            },
        ])

    elif problem == "pressione sulla cassa":
        actions.extend([
            {
                "title": "Accorcia il DSO",
                "why": "incassare prima libera cassa senza aumentare vendite",
                "how": "anticipo fatture, reminder automatici, sconti piccoli per pagamento rapido",
            },
            {
                "title": "Ottimizza scorte e rotazione",
                "why": "magazzino fermo è cassa immobilizzata",
                "how": "ABC analysis, riordino dinamico, focus su SKU ad alta rotazione",
            },
            {
                "title": "Allunga il DPO con criterio",
                "why": "più tempo di pagamento può alleggerire tensione finanziaria",
                "how": "rinegozia i fornitori strategici senza compromettere il rapporto",
            },
        ])

    elif problem == "ritorno sul capitale insufficiente":
        actions.extend([
            {
                "title": "Sposta capitale verso le leve più redditizie",
                "why": "non tutto l’investimento ha lo stesso ritorno",
                "how": "analizza reparti, canali e linee di offerta per capire cosa genera davvero ritorno",
            },
            {
                "title": "Blocca investimenti non prioritari",
                "why": "capitale disperso su troppe direzioni abbassa il ROI complessivo",
                "how": "rinvia o taglia ciò che non ha payback chiaro o impatto diretto su margine/crescita",
            },
            {
                "title": "Aumenta la resa per euro speso",
                "why": "il vero salto non è spendere di più, ma spendere meglio",
                "how": "introduci review mensili per ogni investimento con KPI attesi vs KPI reali",
            },
        ])

    elif problem == "acquisizione clienti poco efficiente":
        actions.extend([
            {
                "title": "Rialloca budget marketing",
                "why": "non tutti i canali hanno lo stesso CAC e la stessa qualità cliente",
                "how": "taglia i canali peggiori e aumenta spesa solo dove il payback è chiaro",
            },
            {
                "title": "Aumenta conversione lead-to-sale",
                "why": "più conversione abbassa il CAC reale",
                "how": "migliora script, follow-up, qualifica e proposta di valore",
            },
            {
                "title": "Alza LTV prima di scalare",
                "why": "scalare un modello debole amplifica le perdite",
                "how": "introduci upsell, retention e pacchetti annuali",
            },
        ])

    elif problem == "conversione commerciale debole":
        actions.extend([
            {
                "title": "Rafforza la proposta di valore",
                "why": "molti lead non chiudono perché capiscono il prodotto ma non il valore economico",
                "how": "sposta il pitch da descrizione del servizio a outcome, ROI e costo della non azione",
            },
            {
                "title": "Stringi la qualifica",
                "why": "una pipeline gonfia ma poco qualificata abbassa conversione e consuma energie",
                "how": "definisci criteri minimi di fit prima di investire tempo commerciale",
            },
            {
                "title": "Sistema il follow-up",
                "why": "molte vendite non si perdono in call, si perdono dopo",
                "how": "costruisci una sequenza standard di follow-up con timing, prove e gestione obiezioni",
            },
        ])

        if segment == "high":
            actions.append(
                {
                    "title": "Rendi la vendita più consulenziale",
                    "why": "su ticket medi o alti il cliente compra chiarezza strategica, non solo il servizio",
                    "how": "inserisci discovery più profonda, business case e chiusura su priorità economiche",
                }
            )

    elif problem == "ritenzione debole":
        actions.extend([
            {
                "title": "Aumenta il valore percepito nei primi 30 giorni",
                "why": "la retention si decide molto presto",
                "how": "onboarding migliore, quick win chiari, supporto proattivo",
            },
            {
                "title": "Segmenta i clienti a rischio",
                "why": "non tutti i clienti stanno per abbandonare per lo stesso motivo",
                "how": "usa usage, ticket, frequenza e risultati per creare alert",
            },
            {
                "title": "Costruisci offerte di espansione",
                "why": "più il cliente cresce con te, meno è probabile che esca",
                "how": "upsell per maturità, bundle e consulenza ad alto valore",
            },
        ])

    elif problem == "espansione debole della base clienti":
        actions.extend([
            {
                "title": "Disegna una scala di valore",
                "why": "senza gradini di crescita, il cliente resta fermo sul prodotto base",
                "how": "crea pacchetti, bundle o livelli premium coerenti con la maturità del cliente",
            },
            {
                "title": "Attiva trigger di upsell",
                "why": "l’upsell funziona meglio quando è collegato a un momento preciso",
                "how": "collega le proposte premium a soglie di utilizzo, risultati o complessità crescente",
            },
            {
                "title": "Monitora NRR e ricavi per cohort",
                "why": "devi capire quali clienti crescono davvero e quali no",
                "how": "separa le coorti per canale, ticket o segmento e misura espansione nel tempo",
            },
        ])

    elif problem == "base clienti poco monetizzata":
        actions.extend([
            {
                "title": "Aumenta frequenza di riacquisto",
                "why": "la crescita più efficiente passa spesso dai clienti già acquisiti",
                "how": "introduci reminder, ricorrenza commerciale, offerte di continuità o contratti annuali",
            },
            {
                "title": "Segmenta per valore e comportamento",
                "why": "non tutti i clienti hanno lo stesso potenziale di espansione",
                "how": "dividi la base per ticket, frequenza, margine e tasso di risposta commerciale",
            },
            {
                "title": "Costruisci un account growth process",
                "why": "senza ownership chiara, l’espansione clienti resta casuale",
                "how": "assegna trigger, owner e KPI a rinnovi, upsell e cross-sell",
            },
        ])

    else:
        actions.extend([
            {
                "title": "Definisci la leva primaria di crescita",
                "why": "senza priorità chiara si disperdono capitale e attenzione",
                "how": "scegli una sola priorità per trimestre: acquisizione, conversione, retention o pricing",
            },
            {
                "title": "Costruisci dashboard decisionale",
                "why": "la strategia diventa reale solo se misurata",
                "how": "monitora margine, CAC, LTV, conversione, cash cycle, upsell",
            },
            {
                "title": "Introduci un operating rhythm",
                "why": "la crescita richiede disciplina, non solo intuizione",
                "how": "review settimanali, owner chiari, target numerici e correzione rapida",
            },
        ])

    if phase == "scale":
        actions.append(
            {
                "title": "Proteggi la scalabilità del modello",
                "why": "molti business crescono nei ricavi ma si rompono in execution",
                "how": "standardizza processi, ownership e KPI prima di accelerare ancora",
            }
        )

    return actions


# -------------------------
# Frameworks
# -------------------------
def growth_framework(state: Dict[str, float], phase: str = "growth") -> Dict[str, List[str]]:
    base = {
        "acquisition": [
            "canali con CAC sostenibile",
            "messaggio orientato al dolore economico",
            "offerta d’ingresso semplice da capire",
        ],
        "conversion": [
            "qualifica lead più stretta",
            "sales process con follow-up strutturato",
            "chiusura basata su ROI e costo della non azione",
        ],
        "retention": [
            "onboarding forte",
            "misurazione del valore generato",
            "alert precoci sui clienti a rischio",
        ],
        "expansion": [
            "upsell per livello di maturità",
            "bundle ad alto margine",
            "cross-sell solo dopo attivazione reale del cliente",
        ],
    }

    if phase == "early":
        base["acquisition"] = [
            "validazione canale principale",
            "test rapido messaggio/offerta",
            "focus su domanda reale prima della scala",
        ]
        base["conversion"] = [
            "pitch semplice",
            "raccolta obiezioni dal mercato",
            "ottimizzazione della proposta di valore",
        ]

    if phase == "scale":
        base["expansion"].append("account growth strutturato")
        base["retention"].append("customer success guidato da KPI")
        base["acquisition"].append("segmentazione per payback e qualità cliente")

    return base


def pricing_framework(state: Dict[str, float], sector: str = "default") -> Dict[str, str]:
    mc_rate = state.get("mc_rate", 0.0)
    avg_ticket = state.get("avg_ticket", 0.0)
    ltv_cac = state.get("ltv_cac", 0.0)

    if mc_rate < 0.30:
        posture = "pricing probabilmente troppo difensivo"
    elif mc_rate < 0.45:
        posture = "pricing discreto ma ancora migliorabile"
    else:
        posture = "pricing potenzialmente già forte, da raffinare per segmenti"

    if avg_ticket > 0 and avg_ticket < 100:
        packaging = "ticket medio basso: valuta bundle, annuali o premium tier"
    elif avg_ticket >= 100:
        packaging = "ticket medio già discreto: lavora su segmentazione e ancoraggio del valore"
    else:
        packaging = "ticket medio non disponibile: valuta pricing e packaging insieme"

    if ltv_cac > 0 and ltv_cac < 3.0:
        actions = "prima migliora conversione e retention, poi testa prezzo per segmento e revisione packaging"
    else:
        actions = "test di prezzo per segmento, revisione packaging, ancoraggio del valore prima del prezzo"

    return {
        "posture": posture,
        "focus": "prezzo non come numero assoluto ma come riflesso del valore percepito",
        "actions": actions,
        "packaging": packaging,
    }


def positioning_framework(data: Dict[str, Any], phase: str = "growth") -> Dict[str, str]:
    sector = _sector_key(data)

    sector_angles = {
        "restaurant": "margine, food cost, controllo numeri e decisioni operative rapide",
        "hotel": "occupazione, marginalità camera, pricing e controllo della struttura",
        "saas": "riduzione churn, aumento LTV e crescita ordinata dell’MRR",
        "ecommerce": "margine, conversione, AOV e cash discipline",
        "agency": "margine per cliente, standardizzazione delivery e crescita senza caos",
        "services": "più controllo economico, più efficienza, meno decisioni a istinto",
        "default": "riduzione errori, aumento margine, accelerazione decisionale",
    }

    if phase == "early":
        proof = "demo, audit, simulazioni economiche, feedback del mercato"
    else:
        proof = "casi, benchmark, simulazioni economiche, prima/dopo"

    return {
        "sector": sector,
        "core_message": "non vendere il prodotto: vendi il risultato economico e strategico che il cliente ottiene",
        "proof": proof,
        "angle": sector_angles.get(sector, sector_angles["default"]),
        "positioning_line": "trasforma i numeri in decisioni, e le decisioni in crescita controllata",
    }


def operating_framework(problem: str, phase: str = "growth") -> Dict[str, List[str]]:
    weekly = [
        "review KPI chiave",
        "analisi scostamenti",
        "decisione su 1-3 azioni correttive",
    ]
    monthly = [
        "review economica completa",
        "valutazione canali/offerte",
        "allocazione capitale e team",
    ]
    quarterly = [
        "definizione leva primaria",
        "revisione priorità strategiche",
        "taglio iniziative a basso impatto",
    ]

    if phase == "scale":
        monthly.append("review performance per owner/funzione")
        quarterly.append("stress test della scalabilità operativa")

    if problem == "pressione sulla cassa":
        weekly.append("monitoraggio incassi e pagamenti")
    if problem in {"acquisizione clienti poco efficiente", "conversione commerciale debole"}:
        weekly.append("review funnel commerciale")
    if problem in {"ritenzione debole", "espansione debole della base clienti", "base clienti poco monetizzata"}:
        weekly.append("review churn / upsell / clienti a rischio")

    return {
        "weekly": weekly,
        "monthly": monthly,
        "quarterly": quarterly,
    }


def strategic_scorecard(state: Dict[str, float], sector: str = "default") -> Dict[str, float]:
    th = _get_thresholds(sector)

    def ratio_score(actual: float, target: float) -> float:
        if target <= 0:
            return 0.0
        return _clamp(actual / target, 0.0, 1.2)

    def inverse_score(actual: float, limit: float) -> float:
        if limit <= 0:
            return 0.0
        if actual <= 0:
            return 1.0
        return _clamp(limit / actual, 0.0, 1.2)

    scores = {
        "marginality": ratio_score(state.get("mc_rate", 0.0), th["mc_rate_min"]),
        "profitability": ratio_score(state.get("net_margin", 0.0), th["net_margin_min"]),
        "capital_efficiency": ratio_score(state.get("roi", 0.0), th["roi_min"]),
        "cash_discipline": inverse_score(state.get("ccc", 0.0), th["ccc_max"]),
    }

    ltv_cac = state.get("ltv_cac", 0.0)
    conv = state.get("conversion_rate", 0.0)
    churn = state.get("churn", 0.0)
    nrr = state.get("nrr", 0.0)

    acq_scores: List[float] = []
    if ltv_cac > 0:
        acq_scores.append(ratio_score(ltv_cac, th["ltv_cac_min"]))
    if conv > 0:
        acq_scores.append(ratio_score(conv, th["conversion_rate_min"]))
    if acq_scores:
        scores["acquisition_efficiency"] = sum(acq_scores) / len(acq_scores)

    if churn > 0:
        scores["retention_health"] = inverse_score(churn, th["churn_max"])
    if nrr > 0:
        scores["expansion_health"] = ratio_score(nrr, th["nrr_min"])

    return scores


def strategic_snapshot(data: Dict[str, Any]) -> Dict[str, Any]:
    sector = _sector_key(data)
    state = extract_business_state(data)
    phase = _business_phase(data, state)
    problem, explanation, lever = diagnose_core_problem(state, sector=sector, phase=phase)

    return {
        "sector": sector,
        "phase": phase,
        "segment_hint": _segment_hint(data, state),
        "problem": problem,
        "explanation": explanation,
        "primary_lever": lever,
        "scorecard": strategic_scorecard(state, sector=sector),
        "operating_framework": operating_framework(problem, phase=phase),
    }