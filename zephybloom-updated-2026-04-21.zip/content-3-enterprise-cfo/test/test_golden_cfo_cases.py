"""
Golden CFO cases.

These tests protect semantic behavior while the CFO logic scales. They assert
that representative companies keep producing the expected constraint, posture,
and guardrail behavior.
"""

import pytest

from core.analysis import analyze_company
from core.cfo_intelligence import build_cfo_insight_pack


GOLDEN_CASES = [
    {
        "id": "saas_healthy_scale",
        "payload": {
            "fatturato": 1_500_000,
            "costi_variabili": 270_000,
            "costi_fissi": 520_000,
            "investimenti": 80_000,
            "settore": "saas",
            "company_name": "Scale SaaS",
        },
        "expected_status": "healthy",
        "expected_constraint": "growth_quality",
        "expected_posture": "scale_selectively",
    },
    {
        "id": "saas_low_gross_margin",
        "payload": {
            "fatturato": 1_200_000,
            "costi_variabili": 540_000,
            "costi_fissi": 300_000,
            "investimenti": 40_000,
            "settore": "saas",
            "company_name": "Thin SaaS",
        },
        "expected_status": "warning",
        "expected_constraint": "unit_economics",
        "expected_posture": "repair_unit_economics",
    },
    {
        "id": "retail_loss_making",
        "payload": {
            "fatturato": 700_000,
            "costi_variabili": 520_000,
            "costi_fissi": 260_000,
            "investimenti": 20_000,
            "settore": "retail",
            "company_name": "Loss Retail",
        },
        "expected_status": "critical",
        "expected_constraint": "profitability",
        "expected_posture": "stabilize",
    },
    {
        "id": "manufacturing_cash_cycle",
        "payload": {
            "fatturato": 2_000_000,
            "costi_variabili": 1_100_000,
            "costi_fissi": 450_000,
            "investimenti": 60_000,
            "settore": "manufacturing",
            "company_name": "Cash Factory",
            "dso_days": 75,
            "dio_days": 65,
            "dpo_days": 35,
        },
        "expected_status": "healthy",
        "expected_constraint": "cash_cycle",
        "expected_posture": "scale_selectively",
    },
    {
        "id": "services_operating_leverage",
        "payload": {
            "fatturato": 900_000,
            "costi_variabili": 300_000,
            "costi_fissi": 520_000,
            "investimenti": 10_000,
            "settore": "services",
            "company_name": "Heavy Services",
        },
        "expected_status": "healthy",
        "expected_constraint": "operating_leverage",
        "expected_posture": "scale_selectively",
    },
]


def test_golden_cfo_cases_keep_expected_semantics():
    for case in GOLDEN_CASES:
        analysis = analyze_company(**case["payload"])
        insight = build_cfo_insight_pack(analysis, settore=case["payload"]["settore"])

        assert analysis.status.value == case["expected_status"], case["id"]
        assert insight["primary_constraint"]["type"] == case["expected_constraint"], case["id"]
        assert insight["strategic_posture"] == case["expected_posture"], case["id"]
        assert insight["next_best_move"]["move"], case["id"]
        assert insight["confidence"] >= 0.8, case["id"]


CHAT_GOLDEN_CASES = [
    {
        "id": "kpi_profit_short",
        "message": "utile",
        "company_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "settore": "saas",
            "company_name": "Golden Chat Co",
        },
        "assertions": [
            lambda body: "Utile netto" in body["response"],
            lambda body: "Cosa farei adesso" in body["response"],
            lambda body: body["conversation_state"]["intent"] == "kpi_profit",
        ],
    },
    {
        "id": "definition_roi",
        "message": "osa è il roi",
        "company_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "settore": "saas",
            "company_name": "Golden Chat Co",
        },
        "assertions": [
            lambda body: "ROI = Utile / Investimenti" in body["response"],
            lambda body: body["conversation_state"]["intent"] == "faq",
        ],
    },
    {
        "id": "data_input_channels",
        "message": "Per canali vendita mi servono: sales_channels, average_ticket, average_order_value.",
        "company_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "settore": "restaurant",
            "company_name": "Golden Chat Co",
        },
        "assertions": [
            lambda body: "blocco dati dei canali vendita" in body["response"],
            lambda body: body["conversation_state"]["message_kind"] == "data_input",
        ],
    },
    {
        "id": "restaurant_growth_strategy",
        "message": "ok visto che ho un ristorante come posso fare una strategia per acquisire piu clienti",
        "company_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "settore": "restaurant",
            "company_name": "Golden Restaurant",
        },
        "assertions": [
            lambda body: "ristorante" in body["response"].lower(),
            lambda body: "google maps" in body["response"].lower(),
            lambda body: "io non partirei dagli sconti" in body["response"].lower(),
        ],
    },
    {
        "id": "ecommerce_product_priority",
        "message": "quale prodotto devo spingere?",
        "company_data": {
            "fatturato": 600_000,
            "costi_variabili": 250_000,
            "costi_fissi": 90_000,
            "investimenti": 80_000,
            "settore": "ecommerce",
            "company_name": "Golden Shop",
        },
        "operational_data_by_sector": {
            "ecommerce": {
                "sku_sales": [
                    {"sku": "Hero Product", "price": 75, "purchase_cost": 24, "shipping_cost": 7, "monthly_units": 500},
                    {"sku": "Low Margin Product", "price": 50, "purchase_cost": 35, "shipping_cost": 8, "monthly_units": 100},
                ]
            }
        },
        "assertions": [
            lambda body: "Data Room CFO - prodotti da spingere" in body["response"],
            lambda body: "Hero Product" in body["response"],
            lambda body: body["conversation_state"]["intent"] == "company_data_room",
        ],
    },
    {
        "id": "simulation_ecommerce_priority",
        "message": "simula +10% prezzo e +5% volume",
        "company_data": {
            "fatturato": 600_000,
            "costi_variabili": 250_000,
            "costi_fissi": 90_000,
            "investimenti": 80_000,
            "settore": "ecommerce",
            "company_name": "Golden Shop",
        },
        "operational_data": {
            "annual_revenue": 600000,
            "fixed_costs": 90000,
            "invested_capital": 80000,
            "average_order_value": 75,
            "monthly_orders": 800,
            "customer_acquisition_cost": 18,
            "monthly_ad_spend": 12000,
            "payment_fees_pct": 2,
            "return_rate_pct": 5,
            "sku_sales": [
                {"sku": "Hero Product", "price": 75, "purchase_cost": 24, "shipping_cost": 7, "monthly_units": 500}
            ],
        },
        "assertions": [
            lambda body: "Simulazione Ecommerce CFO" in body["response"],
            lambda body: body["conversation_state"]["brain_action"] == "run_simulation",
        ],
    },
    {
        "id": "war_room_weekly_priority",
        "message": "cosa devo fare questa settimana per crescere?",
        "company_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "settore": "saas",
            "company_name": "Golden Chat Co",
        },
        "assertions": [
            lambda body: ("Agenda CFO di questa settimana" in body["response"]) or ("War Room CFO di questa settimana" in body["response"]),
            lambda body: body["conversation_state"]["brain_action"] == "war_room",
        ],
    },
]


@pytest.mark.parametrize("case", CHAT_GOLDEN_CASES, ids=[case["id"] for case in CHAT_GOLDEN_CASES])
def test_golden_chat_cases_keep_expected_behavior(authenticated_client, case):
    payload = {
        "message": case["message"],
        "company_data": case["company_data"],
        "chat_history": [],
    }
    if "operational_data" in case:
        payload["operational_data"] = case["operational_data"]
    if "operational_data_by_sector" in case:
        payload["operational_data_by_sector"] = case["operational_data_by_sector"]

    response = authenticated_client.post("/cfo/chat", json=payload)

    assert response.status_code == 200, case["id"]
    body = response.json()

    for assertion in case["assertions"]:
        assert assertion(body), case["id"]
