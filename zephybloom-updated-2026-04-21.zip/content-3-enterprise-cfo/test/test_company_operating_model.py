from core.company_operating_model import build_company_operating_model


def test_operating_model_builds_company_memory_and_questions():
    model = build_company_operating_model(
        company_data={
            "company_name": "Risto Test",
            "fatturato": 900000,
            "costi_variabili": 300000,
            "costi_fissi": 180000,
            "investimenti": 120000,
            "settore": "restaurant",
        },
        operational_data_by_sector={
            "restaurant": {
                "annual_revenue": 900000,
                "variable_costs": 300000,
                "fixed_costs": 180000,
                "invested_capital": 120000,
                "opening_days_per_month": 25,
                "average_ticket": 36,
            }
        },
        active_sector="restaurant",
    )

    assert model["version"] == "company-operating-model-v1"
    assert model["company"]["annual_revenue"] == 900000
    assert model["active_sector"] == "restaurant"
    assert model["overall_readiness_pct"] > 0
    assert model["premium_outputs"]["single_company_memory"] is True
    assert model["active_sector_model"]["sector"] == "restaurant"
    assert model["active_sector_model"]["can_answer_precisely"] is False
    assert model["next_questions"]
    assert any(signal["type"] == "data_gap" for signal in model["cfo_signals"])


def test_operating_model_tracks_universal_entities_and_data_quality():
    model = build_company_operating_model(
        company_data={
            "company_name": "MultiCo",
            "fatturato": 1200000,
            "costi_variabili": 520000,
            "costi_fissi": 310000,
            "investimenti": 160000,
            "settore": "ecommerce",
            "customers": [{"name": "Segmento A", "revenue": 300000}],
            "suppliers": [{"name": "Supplier A", "annual_spend": 90000}],
            "sales_channels": [{"channel": "Meta Ads", "cac": 24}],
            "recurring_costs": [{"name": "Software", "monthly_cost": 1200}],
            "receivables": 80000,
            "payables": 55000,
        },
        operational_data_by_sector={
            "ecommerce": {
                "annual_revenue": 1200000,
                "fixed_costs": 310000,
                "invested_capital": 160000,
                "average_order_value": 80,
                "monthly_orders": 1200,
                "customer_acquisition_cost": 22,
                "monthly_ad_spend": 26000,
                "sku_sales": [
                    {"sku": "Hero", "price": 80, "purchase_cost": 30, "shipping_cost": 7, "monthly_units": 900}
                ],
                "inventory": [{"sku": "Hero", "stock_units": 500, "stock_value": 15000}],
            }
        },
        active_sector="ecommerce",
    )

    assert model["premium_outputs"]["data_quality_score"] is True
    assert model["premium_outputs"]["universal_entity_catalog"] is True
    assert model["entity_catalog"]["customers"]["present"] is True
    assert model["entity_catalog"]["products"]["present"] is True
    assert model["entity_catalog"]["payment_terms"]["present"] is True
    assert model["data_quality"]["score_pct"] > 40
    assert model["data_quality"]["level"] in {"directional", "analysis_ready", "board_ready"}
    assert "answer_policy" in model["data_quality"]
