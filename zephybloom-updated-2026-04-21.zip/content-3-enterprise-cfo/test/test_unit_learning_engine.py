"""
Unit tests for learning engine

Tests for:
- Decision outcome recording
- Adjustment factor calculation
- Pattern detection
- Success rate tracking
"""

import pytest
from core.learning_engine import LearningEngine


@pytest.fixture
def learning_engine():
    """Fresh learning engine instance for each test."""
    return LearningEngine()


class TestLearningEngineBasics:
    """Test basic learning engine functionality."""
    
    def test_engine_initialization(self, learning_engine):
        """Engine should initialize with empty state."""
        assert learning_engine is not None
        assert learning_engine.state is not None
        assert len(learning_engine.state.decision_metrics) == 0
    
    def test_record_single_outcome(self, learning_engine):
        """Should record a single decision outcome."""
        learning_engine.record_decision_outcome(
            decision_type="Cost Reduction",
            expected_impact_eur=100_000,
            actual_impact_eur=95_000,
        )
        
        assert "Cost Reduction" in learning_engine.state.decision_metrics
        metric = learning_engine.state.decision_metrics["Cost Reduction"]
        assert metric.total_count == 1


class TestAdjustmentFactors:
    """Test adjustment factor calculation."""
    
    def test_adjustment_factor_unknown_type(self, learning_engine):
        """Unknown decision type should return 1.0 (no adjustment)."""
        factor = learning_engine.get_adjustment_factor("Unknown Type")
        assert factor == 1.0
    
    def test_adjustment_factor_perfect_estimate(self, learning_engine):
        """Perfect estimates should have factor close to 1.0."""
        learning_engine.record_decision_outcome(
            decision_type="Price Optimization",
            expected_impact_eur=100_000,
            actual_impact_eur=100_000,  # Perfect match
        )
        
        factor = learning_engine.get_adjustment_factor("Price Optimization")
        assert 0.8 <= factor <= 1.2  # Should stay close to 1.0
    
    def test_adjustment_factor_underestimate(self, learning_engine):
        """Consistent underestimation should increase adjustment factor."""
        # Record underestimates
        for _ in range(3):
            learning_engine.record_decision_outcome(
                decision_type="Revenue Growth",
                expected_impact_eur=100_000,
                actual_impact_eur=120_000,  # Actual > expected
            )
        
        factor = learning_engine.get_adjustment_factor("Revenue Growth")
        assert factor > 1.0, "Should increase factor for underestimates"
    
    def test_adjustment_factor_overestimate(self, learning_engine):
        """Consistent overestimation should decrease adjustment factor."""
        # Record overestimates
        for _ in range(3):
            learning_engine.record_decision_outcome(
                decision_type="Cost Cut",
                expected_impact_eur=100_000,
                actual_impact_eur=70_000,  # Actual < expected
            )
        
        factor = learning_engine.get_adjustment_factor("Cost Cut")
        assert factor < 1.0, "Should decrease factor for overestimates"


class TestSuccessTracking:
    """Test success rate and pattern detection."""
    
    def test_success_rate_calculation(self, learning_engine):
        """Should track success rate correctly."""
        # Record 3 successes (within 20% variance)
        for i in range(3):
            learning_engine.record_decision_outcome(
                decision_type="Margin Improvement",
                expected_impact_eur=100_000,
                actual_impact_eur=95_000,  # -5%, within 20%
            )
        
        metric = learning_engine.state.decision_metrics["Margin Improvement"]
        assert metric.total_count == 3
        assert metric.success_count == 3
        assert metric.success_rate == 1.0
    
    def test_pattern_detection_successful(self, learning_engine):
        """Should identify most successful decision types."""
        # Record high-success decisions
        for i in range(5):
            learning_engine.record_decision_outcome(
                decision_type="Supply Chain Optimization",
                expected_impact_eur=50_000,
                actual_impact_eur=48_000,  # -4%, success
            )
        
        # Record low-success decisions
        for i in range(3):
            learning_engine.record_decision_outcome(
                decision_type="Market Expansion",
                expected_impact_eur=100_000,
                actual_impact_eur=40_000,  # -60%, failure
            )
        
        # Should identify Supply Chain as most successful
        assert "Supply Chain Optimization" in learning_engine.state.most_successful_types
        assert "Market Expansion" in learning_engine.state.most_difficult_types


@pytest.mark.negativity
class TestLearningEngineEdgeCases:
    """Test learning engine handling of edge cases."""
    
    def test_zero_expected_impact(self, learning_engine):
        """Should handle zero expected impact gracefully."""
        # Will have division by zero internally, should not crash
        learning_engine.record_decision_outcome(
            decision_type="Test Decision",
            expected_impact_eur=0,
            actual_impact_eur=1000,
        )
        
        # Should not raise exception
        assert learning_engine.state is not None
    
    def test_negative_impacts(self, learning_engine):
        """Should handle negative impacts (losses)."""
        learning_engine.record_decision_outcome(
            decision_type="Failed Initiative",
            expected_impact_eur=100_000,
            actual_impact_eur=-50_000,  # Made things worse
        )
        
        metric = learning_engine.state.decision_metrics["Failed Initiative"]
        assert metric.total_count == 1
    
    def test_extreme_variance(self, learning_engine):
        """Should handle extreme variance in outcomes."""
        learning_engine.record_decision_outcome(
            decision_type="High Risk Decision",
            expected_impact_eur=100_000,
            actual_impact_eur=1_000_000,  # 10x actual vs expected
        )
        
        metric = learning_engine.state.decision_metrics["High Risk Decision"]
        assert metric.total_count == 1
        # Adjustment factor should be clamped to [0.5, 1.5]
        factor = learning_engine.get_adjustment_factor("High Risk Decision")
        assert 0.5 <= factor <= 1.5
    
    def test_many_decision_types(self, learning_engine):
        """Should handle many different decision types."""
        for i in range(20):
            learning_engine.record_decision_outcome(
                decision_type=f"Decision Type {i}",
                expected_impact_eur=100_000,
                actual_impact_eur=95_000,
            )
        
        assert len(learning_engine.state.decision_metrics) == 20
