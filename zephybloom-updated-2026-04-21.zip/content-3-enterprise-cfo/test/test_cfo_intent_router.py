from core.cfo_intent_router import CFOIntent, MessageKind, is_single_kpi_intent, route_cfo_intent


def test_routes_sales_variants_to_growth_strategy():
    examples = [
        "come posso vendere di piu",
        "come posso aumentare il fatturato",
        "cosa mi consigli per far crescere la mia attività",
        "come aumentare le vendite",
        "ciao come posso aumentare il fattuato",
        "come faccio a venddere di piu ai clienti",
    ]

    for question in examples:
        result = route_cfo_intent(question)
        assert result.intent == CFOIntent.GROWTH_STRATEGY
        assert result.confidence >= 0.8


def test_routes_cost_questions_to_cost_optimization():
    examples = [
        "dove conviene tagliare i costi",
        "come posso abbassare o diminuire i costi",
        "ridurre spese fornitori",
        "come aumento il marggine senza rovinare la crescita",
        "dove converrebbe abbasare i costi",
    ]

    for question in examples:
        result = route_cfo_intent(question)
        assert result.intent == CFOIntent.COST_OPTIMIZATION
        assert result.confidence >= 0.8


def test_routes_weakness_questions_to_diagnosis():
    examples = [
        "quali sono i miei punti deboli",
        "dove posso migliorare l'azienda",
        "quali problemi ho",
        "dove sto perdendo soldi",
        "quale commesa mi blocca la cassa",
        "quali sono i miei punti carenti",
        "dove posso migliorare",
    ]

    for question in examples:
        result = route_cfo_intent(question)
        assert result.intent == CFOIntent.WEAKNESS_DIAGNOSIS


def test_routes_margin_detail_questions_to_data_specific_intents():
    assert route_cfo_intent("quant'è il mio utile per cliente").intent == CFOIntent.CUSTOMER_PROFITABILITY
    assert route_cfo_intent("quali sono i prodotti che ho con piu margine").intent == CFOIntent.PRODUCT_MARGIN
    assert route_cfo_intent("quali prodotti nel mio settore costano meno di quanto li prendo io").intent == CFOIntent.PROCUREMENT_BENCHMARK


def test_routes_single_kpis():
    assert route_cfo_intent("roi").intent == CFOIntent.KPI_ROI
    assert route_cfo_intent("utile").intent == CFOIntent.KPI_PROFIT
    assert route_cfo_intent("ebitda").intent == CFOIntent.KPI_EBITDA
    assert is_single_kpi_intent(route_cfo_intent("cos'è l'utile?"))


def test_routes_sales_improvement_to_growth_not_generic_weakness():
    result = route_cfo_intent("come posso migliorare le vendite")

    assert result.intent == CFOIntent.GROWTH_STRATEGY
    assert result.reason == "sales_improvement_phrase"


def test_classifies_data_input_followup_and_simulation_message_kinds():
    assert route_cfo_intent("Per canali vendita mi servono: sales_channels, average_ticket.").message_kind == MessageKind.DATA_INPUT
    assert route_cfo_intent("vai").message_kind == MessageKind.FOLLOW_UP
    assert route_cfo_intent("simula +10% prezzo e -5% costi").message_kind == MessageKind.SIMULATION_REQUEST
    assert route_cfo_intent("cos'è il roi?").message_kind == MessageKind.DEFINITION_REQUEST


def test_routes_dirty_typos_and_human_variants():
    assert route_cfo_intent("osa è il roi").intent == CFOIntent.DEFINITION
    assert route_cfo_intent("come faccio a vendere di piu").intent == CFOIntent.GROWTH_STRATEGY
    assert route_cfo_intent("come acquisisco clienti").intent == CFOIntent.GROWTH_STRATEGY
    assert route_cfo_intent("come abassare i costi").intent == CFOIntent.COST_OPTIMIZATION
    assert route_cfo_intent("dove sto perdend soldi").intent == CFOIntent.WEAKNESS_DIAGNOSIS
    assert route_cfo_intent("guadagnare di piu").intent == CFOIntent.KPI_PROFIT
