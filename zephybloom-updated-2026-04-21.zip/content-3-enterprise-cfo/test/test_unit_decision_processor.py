"""
Unit tests for decision processor module

Tests for:
- Decision generation from analysis
- Ranking by impact/urgency/risk/effort
- Dominant action selection
- Decision ordering consistency
"""

import pytest
from core.analysis import analyze_company


class TestDecisionGeneration:
    """Test basic decision generation."""
    
    def test_generates_at_least_one_decision(self, healthy_saas_company):
        """Should generate at least one decision."""
        analysis = analyze_company(**healthy_saas_company)
        
        assert analysis is not None
        assert analysis.recommended_actions is not None
        assert len(analysis.recommended_actions) >= 1
        
        # Decisions should have meaningful titles
        for action in analysis.recommended_actions:
            assert action.title is not None
            assert len(action.title) > 0
    
    def test_decisions_have_required_fields(self, healthy_saas_company):
        """Each decision should have impact, priority, steps."""
        analysis = analyze_company(**healthy_saas_company)
        
        for action in analysis.recommended_actions:
            # Must have basic fields
            assert hasattr(action, 'title')
            assert hasattr(action, 'description')
            assert hasattr(action, 'impatto_euro')
            
            # Impact should be meaningful
            assert action.impatto_euro is not None
            assert action.impatto_euro > 0


class TestDecisionRanking:
    """Test decision ranking by various factors."""
    
    def test_decisions_ranked_by_impact(self, healthy_saas_company):
        """Decisions should be ordered by impact (highest first)."""
        analysis = analyze_company(**healthy_saas_company)
        
        actions = analysis.recommended_actions
        if len(actions) > 1:
            # Check that impact generally decreases
            impacts = [a.impatto_euro for a in actions]
            # First impact should be significant
            assert impacts[0] > 0
    
    def test_healthy_vs_struggling_decision_priority(
        self, healthy_saas_company, struggling_company
    ):
        """Struggling company should have more urgent problems."""
        healthy_analysis = analyze_company(**healthy_saas_company)
        struggling_analysis = analyze_company(**struggling_company)
        
        # Both should have recommendations
        assert len(healthy_analysis.recommended_actions) > 0
        assert len(struggling_analysis.recommended_actions) > 0
        
        # Struggling company's first action impact
        # should be more significant
        struggling_first_impact = struggling_analysis.recommended_actions[0].impatto_euro
        assert struggling_first_impact > 0


class TestDominantAction:
    """Test dominant action (single override action) selection."""
    
    def test_dominant_action_present_for_healthy_company(self, healthy_saas_company):
        """Healthy company should have a single dominant action."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Dominant action = top priority recommendation
        assert len(analysis.recommended_actions) > 0
        dominant = analysis.recommended_actions[0]
        
        # Dominant action should be clear and actionable
        assert dominant.title is not None
        assert len(dominant.title) > 0
        assert dominant.description is not None
    
    def test_dominant_action_for_critical_company(self, loss_making_company):
        """Critical company should have urgent dominant action."""
        analysis = analyze_company(**loss_making_company)
        
        # Should have urgent recommendations
        assert len(analysis.recommended_actions) > 0
        
        # First action should address the crisis
        first_action = analysis.recommended_actions[0]
        assert first_action.impatto_euro > 0


class TestDecisionOrdering:
    """Test consistent ordering of decisions."""
    
    def test_decisions_maintain_order_across_calls(self, healthy_saas_company):
        """Decision order should be consistent."""
        result1 = analyze_company(**healthy_saas_company)
        result2 = analyze_company(**healthy_saas_company)
        
        actions1_titles = [a.title for a in result1.recommended_actions]
        actions2_titles = [a.title for a in result2.recommended_actions]
        
        # Same company should produce same order
        assert actions1_titles == actions2_titles
    
    def test_top_decisions_properly_ordered(self, healthy_saas_company):
        """Top 3-5 decisions should be properly ranked."""
        analysis = analyze_company(**healthy_saas_company)
        
        top_decisions = analysis.recommended_actions[:5]
        assert len(top_decisions) > 0
        
        # Each should have clear impact
        for decision in top_decisions:
            assert decision.impatto_euro > 0
            assert decision.title is not None


@pytest.mark.negativity
class TestDecisionProcessorEdgeCases:
    """Test decision processor with edge case data."""
    
    def test_decisions_for_break_even_company(self, break_even_company):
        """Should generate relevant decisions for break-even company."""
        analysis = analyze_company(**break_even_company)
        
        assert len(analysis.recommended_actions) > 0
        # Should recommend growth or cost optimization
        titles = [a.title for a in analysis.recommended_actions]
        assert any(t is not None for t in titles)
    
    def test_decisions_for_high_growth_company(self, high_growth_saas_company):
        """Should handle high-growth scenarios differently."""
        analysis = analyze_company(**high_growth_saas_company)
        
        assert len(analysis.recommended_actions) > 0
        # May recommend cost discipline despite growth mode
        assert analysis.recommended_actions[0].impatto_euro > 0
    
    def test_decisions_for_minimal_data(self, minimal_company):
        """Should generate decisions even with minimal data."""
        analysis = analyze_company(**minimal_company)
        
        assert len(analysis.recommended_actions) > 0
        first_action = analysis.recommended_actions[0]
        assert first_action.title is not None


@pytest.mark.negativity
class TestDecisionConsistency:
    """Test consistency and coherence of decisions."""
    
    def test_no_duplicate_decisions(self, healthy_saas_company):
        """Should not recommend duplicate actions."""
        analysis = analyze_company(**healthy_saas_company)
        
        titles = [a.title for a in analysis.recommended_actions]
        unique_titles = set(titles)
        
        # All titles should be unique
        assert len(titles) == len(unique_titles)
    
    def test_all_decisions_are_actionable(self, healthy_saas_company):
        """Every decision should have actionable steps."""
        analysis = analyze_company(**healthy_saas_company)
        
        for action in analysis.recommended_actions:
            # Should have actionable description
            assert action.description is not None
            assert len(action.description) >= 10
    
    def test_decision_impact_values_are_realistic(self, healthy_saas_company):
        """Decision impacts should be realistic relative to revenue."""
        analysis = analyze_company(**healthy_saas_company)
        revenue = healthy_saas_company["fatturato"]
        
        for action in analysis.recommended_actions:
            # Impact should be positive but not exceed revenue*3
            assert action.impatto_euro > 0
            assert action.impatto_euro <= revenue * 3


class TestDecisionSectorAwareness:
    """Test that decisions are sector-aware."""
    
    def test_manufacturing_vs_saas_decisions(
        self, healthy_manufacturing_company, healthy_saas_company
    ):
        """Different sectors should get different decision priorities."""
        manuf_analysis = analyze_company(**healthy_manufacturing_company)
        saas_analysis = analyze_company(**healthy_saas_company)
        
        # Both should have decisions
        assert len(manuf_analysis.recommended_actions) > 0
        assert len(saas_analysis.recommended_actions) > 0
        
        # Likely different top priorities due to sector differences
        manuf_first = manuf_analysis.recommended_actions[0].title
        saas_first = saas_analysis.recommended_actions[0].title
        # May or may not be different, but both should be relevant
        assert manuf_first is not None
        assert saas_first is not None
