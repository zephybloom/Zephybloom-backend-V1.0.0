from core.data_requirements import assess_data_completeness
from core.sector_adapters import get_sector_spec


def test_restaurant_adapter_requests_operational_data():
    spec = get_sector_spec("restaurant")

    keys = {field.key for field in spec.required_fields}

    assert "ingredient_costs" in keys
    assert "recipe_quantities" in keys
    assert "staff_roles" in keys
    assert "average_daily_covers" in keys
    assert "recommended_price_for_target_margin" in spec.key_kpis


def test_restaurant_completeness_finds_missing_recipe_and_staff_data():
    result = assess_data_completeness(
        "restaurant",
        {
            "annual_revenue": 800000,
            "variable_costs": 310000,
            "fixed_costs": 210000,
            "invested_capital": 120000,
            "opening_days_per_month": 26,
            "average_ticket": 36,
        },
    )

    missing_keys = {field.key for field in result.missing_required}

    assert result.sector == "restaurant"
    assert result.readiness_level in {"discovery_needed", "directional"}
    assert "ingredient_costs" in missing_keys
    assert "recipe_quantities" in missing_keys
    assert "staff_roles" in missing_keys
    assert result.can_answer_precisely is False
    assert result.next_questions


def test_unknown_sector_uses_default_adapter():
    result = assess_data_completeness("unknown_sector", {"annual_revenue": 100000})

    assert result.sector == "default"
    assert result.sector_name == "Azienda generica"
    assert result.required_present == 1
    assert result.required_total >= 4
