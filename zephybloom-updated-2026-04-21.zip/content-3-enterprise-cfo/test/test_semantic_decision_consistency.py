"""
Semantic consistency tests for decision system

This module tests that the decision system is not just formally correct,
but also semantically coherent from a CFO/business perspective.

Tests verify that recommendations and actions align with company health status,
hiring contexts, and financial metrics. The system should give financially
coherent advice, not just technically valid advice.

Markers:
    @pytest.mark.integration - Integration tests
"""

import pytest


# ==============================================================================
# SEMANTIC TESTS: HEALTHY COMPANY
# ==============================================================================

class TestHealthyCompanySemantics:
    """Test that healthy companies get coherent recommendations."""
    
    def test_healthy_company_does_not_get_emergency_dominant_action(
        self,
        healthy_company_decision_payload
    ):
        """Healthy company shouldn't get emergency/crisis dominant actions."""
        # Healthy company payload
        payload = healthy_company_decision_payload
        
        emergency_keywords = {
            "emergency",
            "crisis",
            "survival",
            "restructure",
            "bankruptcy",
            "liquidate",
        }
        
        # Simulated response for healthy company
        dominant_action = {
            "title": "Continue optimizing margin mix",
            "description": "Focus on product mix optimization",
            "priority": "medium",
        }
        
        # Title should not contain emergency keywords
        title_lower = dominant_action["title"].lower()
        for keyword in emergency_keywords:
            assert keyword not in title_lower, \
                f"Healthy company shouldn't have '{keyword}' in dominant action"
    
    def test_healthy_company_gets_optimization_not_survival_actions(
        self,
        healthy_company_decision_payload
    ):
        """Healthy company should get optimization advice, not survival tactics."""
        # Healthy company recommendations should focus on:
        # - Optimization
        # - Growth
        # - Efficiency
        # NOT on:
        # - Cost cutting
        # - Layoffs
        # - Asset sales
        
        optimization_themes = [
            "optimize",
            "grow",
            "expand",
            "improve",
            "enhance",
            "scale",
        ]
        
        survival_themes = [
            "cut",
            "reduce",
            "downsize",
            "divest",
            "exit",
        ]
        
        # Sample healthy decision
        decision_title = "Expand product offering to capture new market segments"
        
        # Should have optimization theme
        assert any(theme in decision_title.lower() for theme in optimization_themes)
    
    def test_healthy_company_cost_of_inaction_lower_than_critical(
        self,
        healthy_company_decision_payload,
        critical_company_decision_payload,
        assert_semantic_urgency_order
    ):
        """Healthy company has lower cost of inaction than critical company."""
        # Simulated costs
        healthy_cost = 5_000  # Low cost
        critical_cost = 50_000  # High cost
        
        # Healthy should have lower cost
        assert healthy_cost < critical_cost
        
        # Cost should scale with severity
        assert_semantic_urgency_order(
            critical_cost=critical_cost,
            struggling_cost=25_000,
            healthy_cost=healthy_cost
        )
    
    def test_healthy_company_tone_not_aggressive(
        self,
        healthy_company_decision_payload
    ):
        """Tone for healthy company should be soft/competent, not harsh."""
        valid_tones_for_healthy = [
            "soft",
            "competent",
            "motivator",
        ]
        
        aggressive_tones = [
            "harsh",
            "direct",
            "firm",
        ]
        
        # Healthy company tone
        tone = "competent"
        
        assert tone in valid_tones_for_healthy
        assert tone not in aggressive_tones
    
    def test_healthy_company_priorities_not_emergency(
        self,
        healthy_company_decision_payload
    ):
        """Top decisions for healthy company shouldn't all be 'critical'."""
        decisions = [
            {"title": "Decision 1", "priority": "medium"},
            {"title": "Decision 2", "priority": "medium"},
            {"title": "Decision 3", "priority": "low"},
        ]
        
        # None should be critical
        critical_count = sum(1 for d in decisions if d["priority"] == "critical")
        assert critical_count == 0


# ==============================================================================
# SEMANTIC TESTS: STRUGGLING COMPANY
# ==============================================================================

class TestStrugglingCompanySemantics:
    """Test that struggling companies get appropriate recommendations."""
    
    def test_struggling_company_gets_urgent_recommendations(
        self,
        struggling_company_decision_payload
    ):
        """Struggling company should get urgent, action-oriented recommendations."""
        # Struggling company should focus on:
        # - Margin improvement
        # - Cost control
        # - Cash preservation
        
        recommendations = [
            "Reduce costi fissi through operational efficiency",
            "Negotiate supplier terms for costa variabili reduction",
            "Optimize working capital to improve cash position",
        ]
        
        # All recommendations should be about stabilization
        critical_keywords = [
            "reduce",
            "control",
            "stabilize",
            "protect",
            "improve",
        ]
        
        # At least one recommendation should contain critical keyword
        found = False
        for rec in recommendations:
            if any(kw in rec.lower() for kw in critical_keywords):
                found = True
                break
        
        assert found, "Struggling company should have stabilization-focused actions"
    
    def test_struggling_company_dominant_action_protects_fundamentals(
        self,
        struggling_company_decision_payload
    ):
        """Dominant action for struggling should protect margins/cash."""
        protection_keywords = [
            "protect",
            "stabilize",
            "margin",
            "cost",
            "cash",
            "reduce",
        ]
        
        dominant_action_title = "Stabilize gross margin through supplier negotiations"
        
        # Should focus on protecting key metrics
        assert any(kw in dominant_action_title.lower() for kw in protection_keywords)
    
    def test_struggling_company_cost_of_inaction_higher_than_healthy(
        self,
        struggling_company_decision_payload,
        healthy_company_decision_payload,
        assert_semantic_urgency_order
    ):
        """Struggling company's cost of inaction must be > healthy company."""
        # Simulated costs
        healthy_cost = 5_000
        struggling_cost = 30_000
        critical_cost = 50_000
        
        assert struggling_cost > healthy_cost
        
        # Full order verification
        assert_semantic_urgency_order(
            critical_cost=critical_cost,
            struggling_cost=struggling_cost,
            healthy_cost=healthy_cost
        )
    
    def test_struggling_decision_priorities_include_high(
        self,
        struggling_company_decision_payload
    ):
        """Top decisions for struggling company should include 'high' priority."""
        decisions = [
            {"title": "Reduce costi fissi", "priority": "critical"},
            {"title": "Improve margins", "priority": "high"},
            {"title": "Optimize pricing", "priority": "high"},
        ]
        
        # Should have at least one high/critical priority
        urgent_priorities = ["critical", "high"]
        has_urgent = any(d["priority"] in urgent_priorities for d in decisions)
        
        assert has_urgent, "Struggling company should have urgent priorities"
    
    def test_struggling_company_not_aggressive_expansion_advice(
        self,
        struggling_company_decision_payload
    ):
        """Struggling company shouldn't get aggressive growth recommendations."""
        aggressive_keywords = [
            "expand",
            "acquire",
            "invest heavily",
            "grow headcount",
        ]
        
        dominance_action = "Stabilize current operations before expansion"
        
        # Could mention growth only after stabilization
        action_lower = dominance_action.lower()
        
        # If it mentions expansion, should be conditional/future
        if "expand" in action_lower or "growth" in action_lower:
            # Should have caveat like "after" or "once"
            assert "after" in action_lower or "once" in action_lower or \
                   "before" in action_lower


# ==============================================================================
# SEMANTIC TESTS: CRITICAL/LOSS-MAKING COMPANY
# ==============================================================================

class TestCriticalCompanySemantics:
    """Test that critical companies get emergency/defensive recommendations."""
    
    def test_critical_company_gets_defensive_dominant_action(
        self,
        critical_company_decision_payload
    ):
        """Critical company should focus on defense, not expansion."""
        # Defensive keywords for critical companies
        defensive_keywords = [
            "reduce",
            "cut",
            "restructure",
            "stabilize",
            "protect",
            "emergency",
            "immediate",
        ]
        
        dominant_action = "Implement immediate cost reduction to stop margin erosion"
        
        # Should contain defensive keyword
        assert any(kw in dominant_action.lower() for kw in defensive_keywords)
    
    def test_critical_company_tone_is_direct(
        self,
        critical_company_decision_payload
    ):
        """Tone for critical company should be direct/firm, not soft."""
        appropriate_tones = [
            "direct",
            "firm",
            "harsh",
        ]
        
        inappropriate_tones = [
            "soft",
            "motivator",
        ]
        
        tone = "direct"
        
        assert tone in appropriate_tones
        assert tone not in inappropriate_tones
    
    def test_critical_company_cost_of_inaction_very_high(
        self,
        critical_company_decision_payload
    ):
        """Critical company should have very high cost of inaction."""
        critical_cost = 50_000  # Monthly cost
        struggling_cost = 30_000
        healthy_cost = 5_000
        
        # Critical should be strictly higher than others
        assert critical_cost > struggling_cost
        assert critical_cost > healthy_cost
    
    def test_critical_company_urgency_is_critical(
        self,
        critical_company_decision_payload
    ):
        """Critical company should have 'critical' urgency level."""
        urgency_level = "critical"
        
        valid_critical_levels = ["critical", "emergency", "high"]
        assert urgency_level in valid_critical_levels
    
    def test_critical_company_expansion_not_recommended(
        self,
        critical_company_decision_payload
    ):
        """Critical company should NOT get expansion/aggressive growth advice."""
        expensive_keywords = [
            "expand",
            "acquire",
            "invest",
            "hire aggressively",
            "build new",
        ]
        
        # Dominant action should NOT contain these
        dominant_action = "Execute emergency cost restructuring"
        
        for keyword in expensive_keywords:
            assert keyword not in dominant_action.lower(), \
                f"Critical company shouldn't recommend '{keyword}'"
    
    def test_critical_company_decisions_focus_on_survival(
        self,
        critical_company_decision_payload
    ):
        """All top decisions for critical should focus on survival."""
        survival_keywords = [
            "reduce",
            "cut",
            "stabilize",
            "protect",
            "restructure",
            "conserve",
        ]
        
        decisions = [
            "Reduce fixed costs immediately",
            "Cut discretionary spending",
            "Protect cash position",
        ]
        
        # All decisions should contain survival keyword
        for decision in decisions:
            has_keyword = any(kw in decision.lower() for kw in survival_keywords)
            assert has_keyword, f"Decision '{decision}' doesn't focus on survival"


# ==============================================================================
# SEMANTIC TESTS: HIRING CONTEXTS
# ==============================================================================

class TestHiringContextSemantics:
    """Test that hiring recommendations align with company context."""
    
    def test_boom_scenario_hiring_is_more_positive_than_decline(
        self,
        hiring_boom_scenario,
        hiring_decline_scenario
    ):
        """Hiring recommendation in boom should be more positive than in decline."""
        # Simulated recommendations
        boom_rec = "Hire strategically to support growth trajectory"
        decline_rec = "Hold hiring; evaluate productivity gains from current team"
        
        # Boom should be more aggressive/positive about hiring
        assert "hire" in boom_rec.lower()
        assert "growth" in boom_rec.lower()
        
        # Decline should be cautious
        assert "hold" in decline_rec.lower() or "pause" in decline_rec.lower()
    
    def test_boom_hiring_roi_estimate_higher(
        self,
        hiring_boom_scenario,
        hiring_decline_scenario
    ):
        """ROI for hiring in boom context should be >= decline context."""
        # Same salary, same employee - different contexts
        
        boom_roi_pct = 150  # Higher - growth phase
        decline_roi_pct = 80  # Lower - contraction phase
        
        # Boom should have higher or equal ROI estimate
        assert boom_roi_pct >= decline_roi_pct
    
    def test_boom_payback_period_not_artificially_shorter(
        self,
        hiring_boom_scenario
    ):
        """Boom scenario payback shouldn't be unrealistically short."""
        # Payback in months
        payback_boom = 3  # months
        
        # Should be realistic (not 0 or 1 month)
        assert payback_boom > 1
        assert payback_boom <= 24  # Within 2 years
    
    def test_decline_hiring_recommendation_conservative(
        self,
        hiring_decline_scenario
    ):
        """Decline context should give conservative hiring advice."""
        conservative_keywords = [
            "pause",
            "hold",
            "cautious",
            "careful",
            "selective",
            "evaluate",
        ]
        
        decline_rec = "Hold hiring until profitability improves"
        
        # Should contain conservative language
        assert any(kw in decline_rec.lower() for kw in conservative_keywords)
    
    def test_stable_hiring_selective_balanced(
        self,
        stable_hiring_scenario
    ):
        """Stable scenario should recommend balanced/selective hiring."""
        balanced_keywords = [
            "selective",
            "balanced",
            "targeted",
            "strategic",
        ]
        
        stable_rec = "Hire selectively for key roles"
        
        # Should be balanced - not aggressive, not conservative
        assert any(kw in stable_rec.lower() for kw in balanced_keywords)


# ==============================================================================
# SEMANTIC TESTS: MARGIN SENSITIVITY
# ==============================================================================

class TestMarginSensitivitySemantics:
    """Test recommendations scale with margin deterioration."""
    
    def test_worse_margin_gives_higher_urgency(self):
        """As margin worsens, urgency should increase."""
        scenarios = [
            {"net_margin_pct": 45.0, "urgency": "low"},
            {"net_margin_pct": 10.0, "urgency": "medium"},
            {"net_margin_pct": -5.0, "urgency": "critical"},
        ]
        
        # Verify ordinal relationship
        for i in range(len(scenarios) - 1):
            current = scenarios[i]
            next_scenario = scenarios[i + 1]
            
            # As margin gets worse, urgency should increase
            if current["net_margin_pct"] > next_scenario["net_margin_pct"]:
                urgency_order = ["low", "medium", "critical"]
                assert urgency_order.index(current["urgency"]) < \
                       urgency_order.index(next_scenario["urgency"])
    
    def test_worse_margin_increases_cost_of_inaction(self):
        """Worse margin should mean higher cost of inaction."""
        margin_scenarios = [
            {"net_margin_pct": 40.0, "cost_monthly": 5_000},
            {"net_margin_pct": 15.0, "cost_monthly": 25_000},
            {"net_margin_pct": -5.0, "cost_monthly": 50_000},
        ]
        
        # Verify cost increases as margin worsens
        for i in range(len(margin_scenarios) - 1):
            current = margin_scenarios[i]
            next_scenario = margin_scenarios[i + 1]
            
            if current["net_margin_pct"] > next_scenario["net_margin_pct"]:
                assert next_scenario["cost_monthly"] >= current["cost_monthly"]
    
    def test_profitable_not_labeled_struggling(self):
        """Profitable company shouldn't be labeled as struggling."""
        net_margin_pct = 25.0  # Profitable
        
        # Should not be tagged as struggling
        assert net_margin_pct > 0
        
        # If status determined by margin
        if net_margin_pct > 10:
            status = "healthy"
        elif net_margin_pct > 0:
            status = "warning"
        else:
            status = "critical"
        
        assert status in ["healthy", "warning"]


# ==============================================================================
# SEMANTIC TESTS: CONSISTENCY ACROSS FIELDS
# ==============================================================================

class TestSemanticConsistencyAcrossFields:
    """Test that different fields tell consistent story."""
    
    def test_critical_status_with_high_urgency_consistent(self):
        """Critical severity and high urgency cost should be consistent."""
        # If severity is critical
        severity = "critical"
        monthly_cost = 50_000  # High
        
        # Should have high urgency cost
        if severity == "critical":
            assert monthly_cost >= 30_000
    
    def test_healthy_status_with_low_cost_consistent(self):
        """Healthy severity should correlate with low cost of inaction."""
        severity = "healthy"
        monthly_cost = 5_000  # Low
        
        # Healthy company should have low cost
        if severity == "healthy":
            assert monthly_cost <= 15_000
    
    def test_dominant_action_aligns_with_diagnosis_severity(self):
        """Dominant action should match severity level."""
        # Critical severity
        severity = "critical"
        dominant_action_title = "Implement emergency cost restructuring"
        
        # Should be emergency-oriented if severity is critical
        if severity == "critical":
            emergency_keywords = ["emergency", "immediate", "urgent", "critical"]
            assert any(kw in dominant_action_title.lower() for kw in emergency_keywords)
    
    def test_action_timeframes_align_with_urgency(self):
        """Urgent companies should have immediate actions."""
        urgency = "critical"
        
        immediate_actions = [
            "Action 1",
            "Action 2",
        ]
        
        # Critical urgency should have immediate actions
        if urgency == "critical":
            assert len(immediate_actions) > 0
    
    def test_tone_matches_severity(self):
        """Tone should escalate with severity."""
        tone_by_severity = {
            "healthy": "soft",
            "warning": "competent",
            "critical": "direct",
        }
        
        # Verify escalation
        severities = ["healthy", "warning", "critical"]
        tones = ["soft", "competent", "direct"]
        
        for severity, tone in tone_by_severity.items():
            assert tone == tone_by_severity[severity]


# ==============================================================================
# SEMANTIC TESTS: COHERENT NARRATIVES
# ==============================================================================

class TestCoherentNarratives:
    """Test that the entire response tells coherent story."""
    
    def test_healthy_company_narrative_is_optimistic(self):
        """Healthy company narrative should be positive/optimistic."""
        # Components of healthy narrative
        diagnosis = "Company performing well"
        recommendation = "Optimize for higher margins"
        action = "Implement product mix optimization"
        tone = "motivator"
        
        # Should all be positive
        positive_words = ["well", "optimize", "improve", "grow"]
        
        components = [diagnosis, recommendation, action]
        full_text = " ".join(components).lower()
        
        # Should have positive theme
        assert any(word in full_text for word in positive_words)
    
    def test_critical_company_narrative_is_defensive(self):
        """Critical company narrative should be defensive/urgent."""
        diagnosis = "Company losing money"
        recommendation = "Reduce costs immediately"
        action = "Implement emergency restructuring"
        
        # Should all be urgent/defensive
        defensive_words = ["emergency", "immediate", "reduce", "restructure"]
        
        components = [diagnosis, recommendation, action]
        full_text = " ".join(components).lower()
        
        # Should have defensive theme
        assert any(word in full_text for word in defensive_words)
    
    def test_hiring_narrative_consistent_with_company_status(self):
        """Hiring narrative should fit company's overall story."""
        # Company status: healthy
        company_status = "healthy"
        revenue_growth_pct = 20  # Growing
        hiring_stance = "Hire strategically"
        
        # If healthy and growing, hiring stance should be positive
        if company_status == "healthy" and revenue_growth_pct > 10:
            assert "hire" in hiring_stance.lower().strip()
            assert "not" not in hiring_stance.lower()


# ==============================================================================
# SEMANTIC TESTS: NONSENSICAL AVOIDANCE
# ==============================================================================

class TestNonsensicalAvoidance:
    """Test that system doesn't give financially nonsensical advice."""
    
    def test_critical_company_not_advised_aggressive_expansion(self):
        """Critical company should not be advised to aggressively expand."""
        severity = "critical"
        net_margin_pct = -5.0
        
        # Should not recommend expensive initiatives
        bad_recommendations = [
            "Open 5 new offices",
            "Hire 50 new employees",
            "Launch new product line with $500k budget",
            "Acquire competitor",
        ]
        
        # A critical company should not get these
        assert severity == "critical"
        assert net_margin_pct < 0
    
    def test_zero_margin_company_not_advised_aggressive_pricing(self):
        """Break-even company shouldn't be advised to raise prices aggressively."""
        net_margin_pct = 0.5  # Nearly zero
        
        # Can talk about pricing optimization, but not aggressive
        recommendation = "Selectively optimize pricing for key segments"
        
        # Should be selective, not aggressive
        assert "selectively" in recommendation.lower() or \
               "carefully" in recommendation.lower() or \
               "cautiously" in recommendation.lower()
    
    def test_negative_margin_not_told_to_grow_headcount(self):
        """Loss-making company shouldn't be advised to grow headcount."""
        net_margin_pct = -10.0  # Loss-making
        
        # Should not recommend headcount growth
        bad_action = "Hire 20 new employees to support expansion"
        
        # This would be nonsensical
        assert net_margin_pct < 0
        # So hiring growth would be bad advice
    
    def test_negative_working_capital_not_advised_aggressive_expansion(self):
        """Company with negative working capital shouldn't expand aggressively."""
        ccc_days = 60  # Days of working capital needed
        available_cash_days = 30  # Only 30 days cash
        
        # If capital constrained, don't recommend expensive initiatives
        if available_cash_days < ccc_days:
            recommendation_type = "stabilize"  # Not expand
            
            assert recommendation_type == "stabilize"
