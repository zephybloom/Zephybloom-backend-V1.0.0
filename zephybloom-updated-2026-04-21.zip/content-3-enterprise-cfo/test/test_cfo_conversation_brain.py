from core.business_model_schema import DataCompletenessResult
from core.cfo_conversation_brain import ConversationAction, decide_conversation_action
from core.cfo_intent_router import CFOIntent


def _readiness(can_answer_precisely=False):
    return DataCompletenessResult(
        sector="restaurant",
        sector_name="Ristorante",
        required_total=4,
        required_present=2,
        optional_total=2,
        optional_present=0,
        required_coverage_pct=50,
        optional_coverage_pct=0,
        answer_precision_pct=37.5,
        readiness_level="discovery_needed",
        missing_required=[],
        missing_optional=[],
        next_questions=[],
        can_answer_precisely=can_answer_precisely,
        key_kpis=[],
        decision_rules=[],
        simulation_templates=[],
        supported_questions=[],
    )


def test_conversation_brain_routes_kpi_to_direct_answer():
    decision = decide_conversation_action("roi", "default")

    assert decision.action == ConversationAction.FAQ_OR_KPI
    assert decision.intent_result.intent == CFOIntent.KPI_ROI
    assert decision.next_best_prompt


def test_conversation_brain_routes_missing_product_margin_to_data_gate():
    decision = decide_conversation_action(
        "quali piatti hanno più margine?",
        "restaurant",
        readiness=_readiness(can_answer_precisely=False),
        has_operational_data=False,
    )

    assert decision.action == ConversationAction.ASK_FOR_DATA
    assert decision.reason == "precision_guardrail_missing_data"
    assert decision.next_best_prompt


def test_conversation_brain_routes_scenario_to_simulation():
    decision = decide_conversation_action(
        "se aumento i prezzi del 5% cosa succede?",
        "restaurant",
        readiness=_readiness(can_answer_precisely=True),
        has_operational_data=True,
    )

    assert decision.action == ConversationAction.RUN_SIMULATION
    assert decision.should_use_operational_data is True
    assert "scenario" in decision.next_best_prompt.lower()


def test_conversation_brain_routes_strategy_to_playbook():
    decision = decide_conversation_action(
        "come posso vendere di più?",
        "ecommerce",
        readiness=_readiness(can_answer_precisely=True),
        has_operational_data=True,
    )

    assert decision.action == ConversationAction.DECISION_PLAYBOOK
    assert decision.intent_result.intent == CFOIntent.GROWTH_STRATEGY
    assert "simuli" in decision.next_best_prompt.lower()


def test_conversation_brain_routes_weekly_priority_to_war_room():
    decision = decide_conversation_action(
        "cosa devo fare questa settimana?",
        "construction",
        readiness=_readiness(can_answer_precisely=True),
        has_operational_data=True,
    )

    assert decision.action == ConversationAction.WAR_ROOM
    assert decision.reason == "war_room_priority_request"
    assert decision.should_use_operational_data is True
