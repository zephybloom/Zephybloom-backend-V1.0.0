"""
Unit tests for tone manager

Tests for:
- Tone selection based on severity
- Tone selection based on profile
- Available tones enum
"""

import pytest
from core.tone_manager import ToneManager, CFOTone


@pytest.fixture
def tone_manager():
    """Fresh tone manager for each test."""
    return ToneManager()


class TestToneSelection:
    """Test tone selection logic."""
    
    def test_select_tone_info_level(self, tone_manager):
        """Info-level issues should use competent/soft tones."""
        tone = tone_manager.select_tone("info", "data_driven")
        assert tone in [CFOTone.SOFT, CFOTone.COMPETENT]
    
    def test_select_tone_warning_level(self, tone_manager):
        """Warning-level issues should use firm/competent tones."""
        tone = tone_manager.select_tone("warning", "data_driven")
        assert tone in [CFOTone.COMPETENT, CFOTone.FIRM]
    
    def test_select_tone_critical_level_cooperative(self, tone_manager):
        """Critical issues with cooperative profile should be firm."""
        tone = tone_manager.select_tone("critical", "data_driven")
        assert tone in [CFOTone.FIRM, CFOTone.DIRECT]
    
    def test_select_tone_critical_level_resistive(self, tone_manager):
        """Critical issues with resistive profile should be harsh."""
        tone = tone_manager.select_tone("critical", "resistive")
        assert tone in [CFOTone.DIRECT, CFOTone.HARSH]
    
    def test_select_tone_repeated_ignoring(self, tone_manager):
        """Repeated ignored advice should escalate tone."""
        tone_0_ignores = tone_manager.select_tone(
            "critical",
            "resistive",
            previous_ignored_advice=0
        )
        
        tone_2_ignores = tone_manager.select_tone(
            "critical",
            "resistive",
            previous_ignored_advice=2
        )
        
        # Should use harsh tone when advice has been ignored
        assert tone_2_ignores == CFOTone.HARSH


class TestToneEnumValidity:
    """Test CFOTone enum validity."""
    
    def test_all_tones_are_strings(self):
        """All tones should be string enums."""
        for tone in CFOTone:
            assert isinstance(tone.value, str)
    
    def test_tone_values_are_lowercase(self):
        """Tone values should be lowercase."""
        for tone in CFOTone:
            assert tone.value == tone.value.lower()
    
    def test_expected_tones_exist(self):
        """Should have all expected tone types."""
        expected = {
            'soft', 'competent', 'firm', 'direct',
            'harsh', 'manager', 'motivator'
        }
        actual = {tone.value for tone in CFOTone}
        assert expected == actual


class TestAudienceAwareTone:
    """Test tone selection based on audience."""
    
    def test_tone_for_entrepreneur(self, tone_manager):
        """Should select appropriate tone for entrepreneur audience."""
        tone = tone_manager.select_tone(
            "warning",
            "data_driven",
            audience="entrepreneur"
        )
        assert tone is not None
        assert isinstance(tone, CFOTone)
    
    def test_tone_for_investor(self, tone_manager):
        """Should select manager tone for investor audience."""
        tone = tone_manager.select_tone(
            "critical",
            "data_driven",
            audience="investor"
        )
        assert tone in [CFOTone.MANAGER, CFOTone.FIRM]
    
    def test_tone_for_team(self, tone_manager):
        """Should select motivating tone for team audience."""
        tone = tone_manager.select_tone(
            "info",
            "gut_feeling",
            audience="team"
        )
        assert tone in [CFOTone.COMPETENT, CFOTone.MOTIVATOR]


@pytest.mark.negativity
class TestToneManagerEdgeCases:
    """Test tone manager with edge cases."""
    
    def test_unknown_severity_level(self, tone_manager):
        """Should handle unknown severity levels gracefully."""
        # Should default to competent tone
        tone = tone_manager.select_tone("unknown_level", "data_driven")
        assert tone in [CFOTone.COMPETENT, CFOTone.SOFT]
    
    def test_unknown_profile_type(self, tone_manager):
        """Should handle unknown profile types gracefully."""
        tone = tone_manager.select_tone("warning", "unknown_profile")
        assert tone is not None
        assert isinstance(tone, CFOTone)
    
    def test_negative_ignored_advice_count(self, tone_manager):
        """Should handle negative ignored advice count."""
        tone = tone_manager.select_tone(
            "critical",
            "resistive",
            previous_ignored_advice=-5  # Negative (invalid)
        )
        assert tone is not None
    
    def test_very_high_ignored_advice_count(self, tone_manager):
        """Should cap behavior with very high ignored advice count."""
        tone_high = tone_manager.select_tone(
            "critical",
            "resistive",
            previous_ignored_advice=100
        )
        # Should use harsh or direct tone
        assert tone_high in [CFOTone.HARSH, CFOTone.DIRECT]
