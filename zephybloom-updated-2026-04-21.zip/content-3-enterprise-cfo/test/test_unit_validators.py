"""
Unit tests for validators module

Tests for:
- Value clamping
- KPI invariants
- Sector validation
- Numeric normalization
"""

import pytest
from core.validators import (
    clamp_pct100,
    clamp_rate01,
    clamp_nonneg,
    normalize_context_numeric,
)


class TestValueClamping:
    """Test numeric value clamping functions."""
    
    def test_clamp_pct100_below_range(self):
        """Percentage values below 0 should clamp to 0."""
        assert clamp_pct100(-50.0) == 0.0
        assert clamp_pct100(-1.0) == 0.0
    
    def test_clamp_pct100_in_range(self):
        """Percentage values in [0, 100] should pass through."""
        assert clamp_pct100(0.0) == 0.0
        assert clamp_pct100(50.0) == 50.0
        assert clamp_pct100(100.0) == 100.0
    
    def test_clamp_pct100_above_range(self):
        """Percentage values above 100 should clamp to 100."""
        assert clamp_pct100(150.0) == 100.0
        assert clamp_pct100(200.0) == 100.0
        assert clamp_pct100(1000.0) == 100.0
    
    def test_clamp_rate01_below_range(self):
        """Rate values below 0 should clamp to 0."""
        assert clamp_rate01(-0.5) == 0.0
        assert clamp_rate01(-1.0) == 0.0
    
    def test_clamp_rate01_in_range(self):
        """Rate values in [0, 1] should pass through."""
        assert clamp_rate01(0.0) == 0.0
        assert clamp_rate01(0.5) == 0.5
        assert clamp_rate01(1.0) == 1.0
    
    def test_clamp_rate01_above_range(self):
        """Rate values above 1 should clamp to 1."""
        assert clamp_rate01(1.5) == 1.0
        assert clamp_rate01(2.0) == 1.0
    
    def test_clamp_nonneg_negative(self):
        """Negative values should clamp to 0."""
        assert clamp_nonneg(-100) == 0
        assert clamp_nonneg(-0.001) == 0.0
    
    def test_clamp_nonneg_positive(self):
        """Non-negative values should pass through."""
        assert clamp_nonneg(0) == 0
        assert clamp_nonneg(100) == 100
        assert clamp_nonneg(1_000_000) == 1_000_000


class TestContextNormalization:
    """Test numeric context normalization."""
    
    def test_normalize_empty_dict(self):
        """Empty dict should pass through unchanged."""
        result = normalize_context_numeric({})
        assert result == {}
    
    def test_normalize_preserves_non_numeric(self):
        """Non-numeric fields should pass through unchanged."""
        context = {
            "company_name": "TestCorp",
            "sector": "saas",
            "age_years": 3,
        }
        result = normalize_context_numeric(context)
        assert result.get("company_name") == "TestCorp"
        assert result.get("sector") == "saas"
    
    def test_normalize_clamps_percentage_keys(self):
        """Percentage keys should be clamped to [0, 100]."""
        context = {
            "gross_margin_pct": 150.0,
            "net_margin_pct": -50.0,
        }
        result = normalize_context_numeric(context)
        assert result.get("gross_margin_pct") == 100.0
        assert result.get("net_margin_pct") == 0.0
    
    def test_normalize_clamps_rate_keys(self):
        """Rate keys should be clamped to [0, 1]."""
        context = {
            "roi_pct_per_dollar": 1.5,
        }
        result = normalize_context_numeric(context)
        assert result.get("roi_pct_per_dollar") <= 1.0
    
    def test_normalize_clamps_currency_to_nonneg(self):
        """Currency should not go below 0."""
        context = {
            "fatturato": -100_000,
            "costi_fissi": -50_000,
        }
        result = normalize_context_numeric(context)
        assert result.get("fatturato") == 0
        assert result.get("costi_fissi") == 0


@pytest.mark.negativity
class TestValidatorsEdgeCases:
    """Test validators with edge cases and boundary conditions."""
    
    def test_clamp_pct100_boundary_values(self):
        """Test clamping at exact boundaries."""
        assert clamp_pct100(0.0) == 0.0
        assert clamp_pct100(100.0) == 100.0
        assert clamp_pct100(-0.0) == 0.0
    
    def test_clamp_very_large_values(self):
        """Test clamping with very large values."""
        assert clamp_pct100(1e6) == 100.0
        assert clamp_nonneg(1e10) == 1e10
    
    def test_clamp_very_small_values(self):
        """Test clamping with very small values."""
        assert clamp_pct100(-1e6) == 0.0
        assert clamp_rate01(1e-10) == 1e-10
    
    def test_normalize_with_nan_values(self):
        """Should handle NaN values gracefully."""
        context = {"value": float('nan')}
        # Should not raise exception
        result = normalize_context_numeric(context)
        assert result is not None
