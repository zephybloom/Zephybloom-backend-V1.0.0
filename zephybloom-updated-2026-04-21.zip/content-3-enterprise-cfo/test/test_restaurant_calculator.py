from core.restaurant_calculator import analyze_restaurant, simulate_restaurant


def test_restaurant_calculator_returns_dish_margin_and_target_price():
    result = analyze_restaurant({
        "annual_revenue": 900000,
        "variable_costs": 300000,
        "fixed_costs": 180000,
        "invested_capital": 120000,
        "opening_days_per_month": 25,
        "average_daily_covers": 90,
        "average_ticket": 36,
        "target_food_cost_pct": 30,
        "ingredient_costs": {
            "mozzarella": 0.006,
            "farina": 0.001,
            "pomodoro": 0.003,
        },
        "menu_items": [
            {
                "name": "Margherita",
                "price": 9,
                "monthly_units": 1200,
                "recipe": [
                    {"ingredient": "mozzarella", "quantity": 120},
                    {"ingredient": "farina", "quantity": 180},
                    {"ingredient": "pomodoro", "quantity": 80},
                ],
            }
        ],
        "staff_roles": [
            {"role": "Cuoco", "count": 2, "monthly_cost": 2400},
            {"role": "Sala", "count": 3, "monthly_cost": 1600},
        ],
    })

    dish = result["top_dishes_by_profit"][0]

    assert dish["name"] == "Margherita"
    assert dish["recipe_cost_eur"] == 1.14
    assert dish["food_cost_pct"] == 12.67
    assert dish["recommended_price_for_target_margin_eur"] == 3.8
    assert result["summary"]["labour_cost_pct"] == 12.8
    assert result["summary"]["break_even_covers_per_day"] > 0
    assert result["recommendations"]


def test_restaurant_calculator_flags_expensive_dish_to_fix():
    result = analyze_restaurant({
        "annual_revenue": 300000,
        "fixed_costs": 90000,
        "opening_days_per_month": 22,
        "average_daily_covers": 35,
        "average_ticket": 22,
        "target_food_cost_pct": 30,
        "ingredient_costs": {"pesce": 8},
        "menu_items": [
            {
                "name": "Piatto pesce",
                "price": 18,
                "monthly_units": 100,
                "recipe": [{"ingredient": "pesce", "quantity": 1}],
            }
        ],
        "staff_roles": [{"role": "Chef", "count": 1, "monthly_cost": 3000}],
    })

    assert result["dishes_to_fix"][0]["name"] == "Piatto pesce"
    assert result["dishes_to_fix"][0]["decision"] == "reprice_or_reduce_recipe_cost"


def test_restaurant_simulation_compares_base_and_scenario():
    data = {
        "annual_revenue": 900000,
        "variable_costs": 300000,
        "fixed_costs": 180000,
        "invested_capital": 120000,
        "opening_days_per_month": 25,
        "average_daily_covers": 90,
        "average_ticket": 36,
        "target_food_cost_pct": 30,
        "ingredient_costs": {"mozzarella": 0.006, "farina": 0.001},
        "menu_items": [
            {
                "name": "Margherita",
                "price": 9,
                "monthly_units": 1200,
                "recipe": [
                    {"ingredient": "mozzarella", "quantity": 120},
                    {"ingredient": "farina", "quantity": 180},
                ],
            }
        ],
        "staff_roles": [{"role": "Sala", "count": 2, "monthly_cost": 1600}],
    }

    result = simulate_restaurant(data, {"price_delta_pct": 10, "covers_delta_pct": 5})

    assert result["delta"]["net_profit_eur"] > 0
    assert result["simulated"]["summary"]["annual_revenue_eur"] > result["base"]["summary"]["annual_revenue_eur"]
    assert result["decision"].startswith(("GO", "TEST"))
