from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta

from core.decision_memory import (
    build_decision_memory_summary,
    get_decision_memory,
    list_decision_memory,
    remember_war_room_decisions,
    update_decision_status,
    update_decision_outcome,
)
from db.models import Base, Tenant, User, WarRoomDecisionMemory


def _session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    user = User(email="memory@example.com", password_hash="x", full_name="Memory User")
    session.add(user)
    session.flush()
    session.add(Tenant(id="tenant-db", name="Tenant DB", owner_id=user.id))
    session.commit()
    return session


def test_decision_memory_persists_war_room_decision_and_outcome():
    session = _session()
    war_room = {
        "decision_queue": [
            {
                "decision_id": "wr-01-construction-cashrecovery",
                "sector": "construction",
                "type": "cashrecovery",
            }
        ],
        "execution_tracker": [
            {
                "decision_id": "wr-01-construction-cashrecovery",
                "rank": 1,
                "sector": "construction",
                "owner": "CEO",
                "status": "todo",
                "decision": "Recupera SAL",
                "next_action": "Fattura WIP non fatturato",
                "success_metric": {"kpi": "cash gap", "target": "<= EUR 0"},
                "evidence_needed": ["SAL", "incassi"],
                "follow_up_question": "Hai incassato?",
            }
        ],
    }

    saved = remember_war_room_decisions("tenant-db", war_room, session=session)

    assert saved[0]["decision_id"] == "wr-01-construction-cashrecovery"
    assert list_decision_memory("tenant-db", session=session)[0]["status"] == "todo"

    updated = update_decision_outcome(
        tenant_id="tenant-db",
        decision_id="wr-01-construction-cashrecovery",
        was_implemented=True,
        actual_impact_eur=22000,
        expected_impact_eur=25000,
        outcome_review={"status": "near_target"},
        decision_context={"source": "war_room", "sector": "construction", "decision_type": "cashrecovery"},
        session=session,
    )

    detail = get_decision_memory("tenant-db", "wr-01-construction-cashrecovery", session=session)
    summary = build_decision_memory_summary("tenant-db", session=session)

    assert updated["status"] == "done"
    assert detail["actual_impact_eur"] == 22000
    assert detail["success_metric"]["kpi"] == "cash gap"
    assert summary["completed_decisions"] == 1
    assert summary["actual_impact_eur"] == 22000


def test_decision_memory_flags_stale_open_decisions():
    session = _session()
    old_decision = WarRoomDecisionMemory(
        tenant_id="tenant-db",
        decision_id="wr-99-restaurant-datablocker",
        source="war_room",
        sector="restaurant",
        decision_type="datablocker",
        status="todo",
        rank=1,
        decision="Completa dati menu",
        next_action="Raccogli ingredienti",
        created_at=datetime.utcnow() - timedelta(days=20),
        updated_at=datetime.utcnow() - timedelta(days=20),
    )
    session.add(old_decision)
    session.commit()

    decisions = list_decision_memory("tenant-db", session=session)
    summary = build_decision_memory_summary("tenant-db", session=session)

    assert decisions[0]["is_stale"] is True
    assert decisions[0]["age_days"] >= 20
    assert summary["stale_open_decisions"] == 1
    assert summary["memory_quality"] == "needs_cleanup"
    assert summary["memory_quality_notes"]


def test_decision_memory_archives_and_skips_duplicate_open_decisions():
    session = _session()
    first_war_room = {
        "decision_queue": [
            {"decision_id": "wr-01-restaurant-marginrecovery", "sector": "restaurant", "type": "marginrecovery"}
        ],
        "execution_tracker": [
            {
                "decision_id": "wr-01-restaurant-marginrecovery",
                "rank": 1,
                "sector": "restaurant",
                "owner": "CEO",
                "status": "todo",
                "decision": "Recupera margine menu",
                "next_action": "Ricalcola food cost",
            }
        ],
    }
    second_war_room = {
        "decision_queue": [
            {"decision_id": "wr-02-restaurant-marginrecovery", "sector": "restaurant", "type": "marginrecovery"}
        ],
        "execution_tracker": [
            {
                "decision_id": "wr-02-restaurant-marginrecovery",
                "rank": 2,
                "sector": "restaurant",
                "owner": "CEO",
                "status": "todo",
                "decision": "Nuovo recupero margine",
                "next_action": "Rivedi menu engineering",
            }
        ],
    }

    remember_war_room_decisions("tenant-db", first_war_room, session=session)
    duplicate = remember_war_room_decisions("tenant-db", second_war_room, session=session)

    assert duplicate[0]["status"] == "duplicate_skipped"
    assert duplicate[0]["duplicate_of"] == "wr-01-restaurant-marginrecovery"
    assert len(list_decision_memory("tenant-db", status="todo", session=session)) == 1

    archived = update_decision_status(
        tenant_id="tenant-db",
        decision_id="wr-01-restaurant-marginrecovery",
        status="archived",
        reason="Sostituita da una review più precisa",
        session=session,
    )
    summary = build_decision_memory_summary("tenant-db", session=session)

    assert archived["status"] == "archived"
    assert archived["outcome_review"]["archived_reason"] == "Sostituita da una review più precisa"
    assert summary["archived_decisions"] == 1
    assert summary["open_decisions"] == 0
