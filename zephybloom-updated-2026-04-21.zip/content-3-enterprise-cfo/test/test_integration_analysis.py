"""
Integration tests for analysis module

Tests for:
- CFO analysis engine
- Diagnosis generation
- KPI calculation
- Recommendation generation
"""

import pytest
from core.analysis import CFOAnalysisEngine, analyze_company
from test.conftest import assert_valid_kpi_snapshot, assert_valid_diagnosis, assert_valid_recommendations


class TestAnalysisEngineInitialization:
    """Test analysis engine creation and configuration."""
    
    def test_engine_creation_default_sector(self):
        """Should create engine with default sector."""
        engine = CFOAnalysisEngine()
        assert engine is not None
        assert engine.sector == "default"
    
    def test_engine_creation_manufacturing(self):
        """Should create engine for manufacturing sector."""
        engine = CFOAnalysisEngine(sector="manufacturing")
        assert engine.sector == "manufacturing"
        assert "gross_margin_min_pct" in engine.thresholds
    
    def test_engine_creation_saas(self):
        """Should create engine for SaaS sector."""
        engine = CFOAnalysisEngine(sector="saas")
        assert engine.sector == "saas"
    
    def test_engine_creation_retail(self):
        """Should create engine for retail sector."""
        engine = CFOAnalysisEngine(sector="retail")
        assert engine.sector == "retail"


class TestHealthyCompanyAnalysis:
    """Test analysis of healthy companies."""
    
    def test_analyze_healthy_saas(self, healthy_saas_company):
        """Should recognize healthy SaaS company."""
        result = analyze_company(**healthy_saas_company)
        
        assert result is not None
        assert result.status in ["healthy", "warning", "critical"]
        assert result.headline is not None
        assert_valid_kpi_snapshot(result.kpi_snapshot)
    
    def test_analyze_healthy_manufacturing(self, healthy_manufacturing_company):
        """Should recognize healthy manufacturing company."""
        result = analyze_company(**healthy_manufacturing_company)
        
        assert result is not None
        assert result.status is not None
        assert_valid_kpi_snapshot(result.kpi_snapshot)
    
    def test_healthy_company_has_recommendations(self, healthy_saas_company):
        """Even healthy companies should have improvement recommendations."""
        result = analyze_company(**healthy_saas_company)
        
        assert result.recommended_actions is not None
        assert len(result.recommended_actions) > 0
        assert_valid_recommendations(result.recommended_actions)


class TestStrugglingCompanyAnalysis:
    """Test analysis of struggling companies."""
    
    def test_analyze_struggling_company(self, struggling_company):
        """Should identify struggling companies."""
        result = analyze_company(**struggling_company)
        
        assert result is not None
        # Struggling company should have warning or critical status
        assert result.status in ["warning", "critical"]
        assert result.headline is not None


class TestKPICalculation:
    """Test KPI calculation accuracy."""
    
    def test_gross_margin_calculation(self, healthy_saas_company):
        """Should calculate gross margin correctly."""
        result = analyze_company(**healthy_saas_company)
        
        # Expected: (1_000_000 - 250_000) / 1_000_000 = 75%
        expected_gross = 75.0
        assert result.kpi_snapshot.gross_margin_pct == expected_gross
    
    def test_net_margin_calculation(self, healthy_saas_company):
        """Should calculate net margin correctly."""
        result = analyze_company(**healthy_saas_company)
        
        # Expected: (1_000_000 - 250_000 - 300_000) / 1_000_000 = 45%
        expected_net = 45.0
        assert result.kpi_snapshot.net_margin_pct == expected_net
    
    def test_ebitda_calculation(self, healthy_saas_company):
        """Should calculate EBITDA correctly."""
        result = analyze_company(**healthy_saas_company)
        
        # Expected: (1_000_000 - 250_000 - 300_000) = 450_000
        expected_ebitda = 450_000
        assert result.kpi_snapshot.ebitda_eur == expected_ebitda
    
    def test_margin_hierarchy(self, healthy_saas_company):
        """Gross margin should always be >= Net margin."""
        result = analyze_company(**healthy_saas_company)
        
        assert result.kpi_snapshot.gross_margin_pct >= result.kpi_snapshot.net_margin_pct


class TestDiagnosisGeneration:
    """Test diagnosis generation."""
    
    def test_diagnosis_exists(self, healthy_saas_company):
        """Analysis should include diagnosis."""
        result = analyze_company(**healthy_saas_company)
        
        assert result.diagnosis is not None
        assert_valid_diagnosis(result.diagnosis)
    
    def test_diagnosis_identifies_problems(self, struggling_company):
        """Should identify problems in struggling company."""
        result = analyze_company(**struggling_company)
        
        assert result.diagnosis is not None
        # Struggling company should have identified problems
        assert result.diagnosis.problema_principale is not None


@pytest.mark.negativity
class TestAnalysisEdgeCases:
    """Test analysis with edge cases."""
    
    def test_analyze_break_even_company(self, break_even_company):
        """Should handle break-even company correctly."""
        result = analyze_company(**break_even_company)
        
        assert result is not None
        assert result.kpi_snapshot is not None
        # Net margin should be close to 0
        assert -5 < result.kpi_snapshot.net_margin_pct < 5
    
    def test_analyze_loss_making_company(self, loss_making_company):
        """Should handle loss-making company correctly."""
        result = analyze_company(**loss_making_company)
        
        assert result is not None
        assert result.status in ["warning", "critical"]
        assert result.kpi_snapshot.net_margin_pct < 0
    
    def test_analyze_minimal_company(self, minimal_company):
        """Should handle minimal company data."""
        result = analyze_company(**minimal_company)
        
        assert result is not None
        assert result.kpi_snapshot is not None
    
    def test_analyze_high_growth_company(self, high_growth_saas_company):
        """Should recognize high-growth company pattern."""
        result = analyze_company(**high_growth_saas_company)
        
        assert result is not None
        # High growth company may have warning due to high OpEx
        assert result.status in ["healthy", "warning"]


@pytest.mark.negativity
class TestAnalysisWithInvalidData:
    """Test analysis error handling."""
    
    def test_analyze_with_zero_fatturato(self):
        """Should handle zero revenue."""
        result = analyze_company(
            fatturato=0,
            costi_variabili=0,
            costi_fissi=0,
            investimenti=0,
            company_name="NoRevenue"
        )
        
        assert result is not None
        # Should have some status
        assert result.status is not None
    
    def test_analyze_with_costi_greater_than_fatturato(self):
        """Should handle costs exceeding revenue."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=80_000,
            costi_fissi=50_000,  # Total costs = 130_000 > revenue
            investimenti=10_000,
            company_name="LossMaker"
        )
        
        assert result is not None
        assert result.kpi_snapshot.net_margin_pct < 0
    
    def test_analyze_with_extremely_high_margins(self):
        """Should handle unrealistic high margins."""
        result = analyze_company(
            fatturato=1_000_000,
            costi_variabili=10_000,  # Only 1% COGS
            costi_fissi=10_000,
            investimenti=50_000,
            company_name="HighMarginCo"
        )
        
        assert result is not None
        assert result.kpi_snapshot.gross_margin_pct > 90
