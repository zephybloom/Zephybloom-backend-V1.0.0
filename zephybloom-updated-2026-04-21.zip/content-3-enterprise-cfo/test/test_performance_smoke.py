"""
Performance and smoke tests

Tests for:
- Latency benchmarks
- Throughput testing
- Cold vs warm start
- Cache effectiveness
"""

import pytest
import time
from core.analysis import CFOAnalysisEngine, analyze_company
from api.main import app
from fastapi.testclient import TestClient


@pytest.fixture
def client(authenticated_client):
    """FastAPI test client with authentication."""
    return authenticated_client



class TestAnalysisLatency:
    """Test latency of core analysis operations."""
    
    @pytest.mark.performance
    def test_single_analysis_latency(self, healthy_saas_company):
        """Single analysis should complete in <100ms."""
        start = time.perf_counter()
        result = analyze_company(**healthy_saas_company)
        elapsed = time.perf_counter() - start
        
        assert result is not None
        # Target: <100ms for single analysis
        assert elapsed < 0.100, f"Analysis took {elapsed:.3f}s, target <0.100s"
    
    @pytest.mark.performance
    def test_engine_initialization_latency(self):
        """Engine creation should be fast (<10ms)."""
        start = time.perf_counter()
        engine = CFOAnalysisEngine(sector="saas")
        elapsed = time.perf_counter() - start
        
        # Target: <10ms for initialization
        assert elapsed < 0.010, f"Initialization took {elapsed:.3f}s, target <0.010s"
    
    @pytest.mark.performance
    def test_struggling_company_analysis_latency(self, struggling_company):
        """Analysis should be fast regardless of company health."""
        start = time.perf_counter()
        result = analyze_company(**struggling_company)
        elapsed = time.perf_counter() - start
        
        assert result is not None
        assert elapsed < 0.100, f"Analysis took {elapsed:.3f}s, target <0.100s"


class TestAPIEndpointLatency:
    """Test API endpoint response times."""
    
    @pytest.mark.performance
    def test_analyze_endpoint_latency(self, client, valid_analyze_payload):
        """POST /cfo/analyze should respond in <150ms."""
        start = time.perf_counter()
        response = client.post("/cfo/analyze", json=valid_analyze_payload)
        elapsed = time.perf_counter() - start
        
        assert response.status_code == 200
        # API adds HTTP/serialization overhead, so slightly higher target
        assert elapsed < 0.150, f"Endpoint took {elapsed:.3f}s, target <0.150s"
    
    @pytest.mark.performance
    def test_health_endpoint_latency(self, client):
        """GET /health should respond in <20ms."""
        start = time.perf_counter()
        response = client.get("/health")
        elapsed = time.perf_counter() - start
        
        assert response.status_code == 200
        assert elapsed < 0.020, f"Health check took {elapsed:.3f}s, target <0.020s"
    
    @pytest.mark.performance
    def test_simulate_endpoint_latency(self, client, valid_simulate_payload):
        """POST /cfo/simulate should respond in <150ms."""
        start = time.perf_counter()
        response = client.post("/cfo/simulate", json=valid_simulate_payload)
        elapsed = time.perf_counter() - start
        
        assert response.status_code == 200
        assert elapsed < 0.150, f"Simulate took {elapsed:.3f}s, target <0.150s"


class TestBatchProcessingLatency:
    """Test latency with multiple analyses."""
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_ten_analyses_sequential(self, healthy_saas_company):
        """Should process 10 analyses in reasonable time."""
        start = time.perf_counter()
        
        for i in range(10):
            result = analyze_company(**healthy_saas_company)
            assert result is not None
        
        elapsed = time.perf_counter() - start
        avg_per_analysis = elapsed / 10
        
        # Should average <100ms per analysis
        assert avg_per_analysis < 0.100, \
            f"Average {avg_per_analysis:.3f}s per analysis, target <0.100s"
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_api_batch_requests(self, client, valid_analyze_payload):
        """Should handle multiple concurrent API requests efficiently."""
        start = time.perf_counter()
        
        for i in range(5):
            response = client.post("/cfo/analyze", json=valid_analyze_payload)
            assert response.status_code == 200
        
        elapsed = time.perf_counter() - start
        avg_per_request = elapsed / 5
        
        # Average response time should be <150ms
        assert avg_per_request < 0.150, \
            f"Average {avg_per_request:.3f}s per request, target <0.150s"


class TestColdVsWarmStart:
    """Test performance differences between first and subsequent calls."""
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_first_vs_subsequent_analyses(self, healthy_saas_company):
        """Subsequent analyses should not be slower than first."""
        # First analysis (cold start)
        start = time.perf_counter()
        result1 = analyze_company(**healthy_saas_company)
        first_time = time.perf_counter() - start
        
        # Second analysis (warm start)
        start = time.perf_counter()
        result2 = analyze_company(**healthy_saas_company)
        second_time = time.perf_counter() - start
        
        assert result1 is not None
        assert result2 is not None
        
        # Warm start should not be significantly slower
        # Allow 20% variance due to system scheduling
        assert second_time < first_time * 1.2, \
            f"Warm start {second_time:.3f}s slower than cold {first_time:.3f}s"


class TestThroughput:
    """Test throughput (operations per second)."""
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_minimum_throughput(self, healthy_saas_company):
        """Should maintain minimum throughput for analyses."""
        operations = 0
        start = time.perf_counter()
        
        # Try to complete as many analyses as possible in 1 second
        while time.perf_counter() - start < 1.0:
            result = analyze_company(**healthy_saas_company)
            assert result is not None
            operations += 1
        
        # Should complete at least 10 analyses per second
        assert operations >= 10, \
            f"Only {operations} analyses/sec, target >=10"


class TestMemoryStability:
    """Test memory usage stability under load."""
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_repeated_analyses_no_leak(self, healthy_saas_company):
        """Should not have memory leaks with repeated analyses."""
        # Run 100 analyses
        results = []
        for i in range(100):
            result = analyze_company(**healthy_saas_company)
            results.append(result)
        
        # All should complete successfully
        assert len(results) == 100
        assert all(r is not None for r in results)


@pytest.mark.performance
class TestEngineInitializationPerformance:
    """Test engine initialization for different sectors."""
    
    def test_manufacturing_engine_init(self):
        """Manufacturing engine initialization."""
        start = time.perf_counter()
        engine = CFOAnalysisEngine(sector="manufacturing")
        elapsed = time.perf_counter() - start
        
        assert engine is not None
        assert elapsed < 0.010
    
    def test_saas_engine_init(self):
        """SaaS engine initialization."""
        start = time.perf_counter()
        engine = CFOAnalysisEngine(sector="saas")
        elapsed = time.perf_counter() - start
        
        assert engine is not None
        assert elapsed < 0.010
    
    def test_retail_engine_init(self):
        """Retail engine initialization."""
        start = time.perf_counter()
        engine = CFOAnalysisEngine(sector="retail")
        elapsed = time.perf_counter() - start
        
        assert engine is not None
        assert elapsed < 0.010


@pytest.mark.performance
class TestResponseSerialization:
    """Test response serialization performance."""
    
    @pytest.mark.slow
    def test_response_json_serialization(self, healthy_saas_company):
        """JSON serialization should be fast."""
        result = analyze_company(**healthy_saas_company)
        
        start = time.perf_counter()
        # Simulate JSON serialization (what FastAPI does)
        import json
        json_str = json.dumps(result.__dict__, default=str)
        elapsed = time.perf_counter() - start
        
        # Should serialize in <10ms
        assert elapsed < 0.010, f"Serialization took {elapsed:.3f}s"
        assert len(json_str) > 0


class TestLatencyConsistency:
    """Test consistency of response times."""
    
    @pytest.mark.performance
    @pytest.mark.slow
    def test_latency_variance(self, healthy_saas_company):
        """Response times should be consistent (low variance)."""
        times = []
        
        for i in range(20):
            start = time.perf_counter()
            result = analyze_company(**healthy_saas_company)
            elapsed = time.perf_counter() - start
            times.append(elapsed)
            assert result is not None
        
        import statistics
        mean_time = statistics.mean(times)
        stdev = statistics.stdev(times) if len(times) > 1 else 0
        
        # At sub-millisecond speeds, scheduler noise dominates the ratio.
        if mean_time < 0.001:
            assert max(times) < 0.010, f"Latency spike: max={max(times):.3f}s"
            return

        # Standard deviation should be <20% of mean
        if mean_time > 0:
            variance_ratio = stdev / mean_time
            assert variance_ratio < 0.20, \
                f"High variance: stdev={stdev:.3f}s, mean={mean_time:.3f}s"
