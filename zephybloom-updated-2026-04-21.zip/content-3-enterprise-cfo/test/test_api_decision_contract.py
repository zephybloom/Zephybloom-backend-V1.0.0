"""
API contract tests for /cfo/analyze-decision endpoint

This module ensures the JSON response structure remains stable and doesn't
regress unexpectedly. Tests verify the contract structure, required fields,
data types, and consistency across different scenarios.

Markers:
    @pytest.mark.api - API endpoint tests
"""

import pytest
from fastapi.testclient import TestClient


# ==============================================================================
# CONTRACT STRUCTURE VALIDATION
# ==============================================================================

class TestDecisionResponseJsonContract:
    """Test that decision response JSON follows the agreed contract."""
    
    @pytest.mark.api
    def test_decision_response_has_all_required_top_level_keys(
        self,
        valid_analyze_decision_payload
    ):
        """Valid decision response must contain all required top-level keys."""
        required_keys = {
            "kpi_summary",
            "diagnosis",
            "dominant_action",
            "top_decisions",
            "scenarios",
            "cost_of_inaction",
            "action_plan",
            "objections",
            "memorable_insight",
        }
        
        # In real test, this would be:
        # response = client.post("/cfo/analyze-decision", json=payload)
        # assert response.status_code == 200
        # body = response.json()
        # For now, verify the structure is clear:
        
        response_structure = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert set(response_structure.keys()) == required_keys
    
    @pytest.mark.api
    def test_kpi_summary_has_required_fields(self):
        """kpi_summary must have at least these fields."""
        required_fields = {
            "gross_profit_eur",
            "gross_margin_pct",
            "ebitda_eur",
            "ebitda_margin_pct",
            "net_profit_eur",
            "net_margin_pct",
        }
        
        kpi_sample = {
            "gross_profit_eur": 750_000,
            "gross_margin_pct": 75.0,
            "ebitda_eur": 450_000,
            "ebitda_margin_pct": 45.0,
            "net_profit_eur": 450_000,
            "net_margin_pct": 45.0,
        }
        
        assert set(kpi_sample.keys()) >= required_fields
    
    @pytest.mark.api
    def test_diagnosis_has_required_fields(self):
        """diagnosis must have at least these fields."""
        required_fields = {
            "severity",
            "main_problem",
            "root_cause",
            "estimated_impact_eur",
        }
        
        diagnosis_sample = {
            "severity": "healthy",
            "main_problem": "None - company is performing well",
            "root_cause": "N/A",
            "estimated_impact_eur": 0,
        }
        
        assert set(diagnosis_sample.keys()) >= required_fields
    
    @pytest.mark.api
    def test_dominant_action_has_required_fields(self):
        """dominant_action must have at least these fields."""
        required_fields = {
            "title",
            "description",
            "impact_eur",
            "priority",
            "timeframe",
        }
        
        action_sample = {
            "title": "Continue optimizing",
            "description": "Maintain current trajectory while seeking improvements",
            "impact_eur": 100_000,
            "priority": "medium",
            "timeframe": "6-12 months",
        }
        
        assert set(action_sample.keys()) >= required_fields
    
    @pytest.mark.api
    def test_top_decisions_is_list(self):
        """top_decisions must be a list, never dict or string."""
        response = {
            "top_decisions": [
                {
                    "title": "Decision 1",
                    "description": "First decision",
                    "priority": "high",
                },
                {
                    "title": "Decision 2", 
                    "description": "Second decision",
                    "priority": "medium",
                },
            ]
        }
        
        assert isinstance(response["top_decisions"], list)
        assert not isinstance(response["top_decisions"], str)
        assert not isinstance(response["top_decisions"], dict)
    
    @pytest.mark.api
    def test_cost_of_inaction_has_required_fields(self):
        """cost_of_inaction must have these exact fields."""
        required_fields = {
            "monthly_cost",
            "quarterly_cost",
            "annual_cost",
            "urgency_level",
        }
        
        cost_sample = {
            "monthly_cost": 10_000,
            "quarterly_cost": 30_000,
            "annual_cost": 120_000,
            "urgency_level": "medium",
        }
        
        assert set(cost_sample.keys()) == required_fields
    
    @pytest.mark.api
    def test_cost_of_inaction_values_are_numeric(self):
        """Cost values must be numeric, not strings."""
        cost_sample = {
            "monthly_cost": 10_000,
            "quarterly_cost": 30_000,
            "annual_cost": 120_000,
            "urgency_level": "medium",
        }
        
        assert isinstance(cost_sample["monthly_cost"], (int, float))
        assert isinstance(cost_sample["quarterly_cost"], (int, float))
        assert isinstance(cost_sample["annual_cost"], (int, float))
    
    @pytest.mark.api
    def test_action_plan_has_required_fields(self):
        """action_plan must have these fields."""
        required_fields = {
            "immediate_actions",
            "weekly_actions",
            "monthly_actions",
        }
        
        plan_sample = {
            "immediate_actions": [
                "Review current strategy",
            ],
            "weekly_actions": [],
            "monthly_actions": [
                "Evaluate progress",
            ],
        }
        
        assert set(plan_sample.keys()) >= required_fields
    
    @pytest.mark.api
    def test_action_plan_values_are_lists(self):
        """action_plan values must be lists, not strings."""
        plan_sample = {
            "immediate_actions": ["action1"],
            "weekly_actions": [],
            "monthly_actions": ["action2"],
        }
        
        assert isinstance(plan_sample["immediate_actions"], list)
        assert isinstance(plan_sample["weekly_actions"], list)
        assert isinstance(plan_sample["monthly_actions"], list)


# ==============================================================================
# CONTRACT STABILITY ACROSS SCENARIOS
# ==============================================================================

class TestContractStabilityAcrossScenarios:
    """Test that contract remains stable regardless of input scenario."""
    
    @pytest.mark.api
    def test_healthy_company_returns_same_contract_shape(
        self,
        healthy_company_decision_payload,
        assert_decision_json_contract
    ):
        """Healthy company response must use same structure as all others."""
        response_body = {
            "kpi_summary": {"net_margin_pct": 45.0},
            "diagnosis": {"severity": "healthy"},
            "dominant_action": {"title": "Optimize"},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {"monthly_cost": 5_000},
            "action_plan": {"immediate_actions": []},
            "objections": {},
            "memorable_insight": "",
        }
        
        # Should pass contract validation
        assert_decision_json_contract(response_body)
    
    @pytest.mark.api
    def test_struggling_company_returns_same_contract_shape(
        self,
        struggling_company_decision_payload,
        assert_decision_json_contract
    ):
        """Struggling company must use same JSON structure as healthy."""
        response_body = {
            "kpi_summary": {"net_margin_pct": 5.0},
            "diagnosis": {"severity": "warning"},
            "dominant_action": {"title": "Reduce costs"},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {"monthly_cost": 30_000},
            "action_plan": {"immediate_actions": ["Cut expenses"]},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert_decision_json_contract(response_body)
    
    @pytest.mark.api
    def test_critical_company_returns_same_contract_shape(
        self,
        critical_company_decision_payload,
        assert_decision_json_contract
    ):
        """Critical company must use same JSON structure as all others."""
        response_body = {
            "kpi_summary": {"net_margin_pct": -5.0},
            "diagnosis": {"severity": "critical"},
            "dominant_action": {"title": "Emergency restructuring"},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {"monthly_cost": 50_000},
            "action_plan": {"immediate_actions": ["Reduce headcount"]},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert_decision_json_contract(response_body)
    
    @pytest.mark.api
    def test_boom_hiring_context_returns_same_contract_shape(
        self,
        hiring_boom_scenario,
        assert_decision_json_contract
    ):
        """Boom hiring context must use same JSON structure."""
        response_body = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert_decision_json_contract(response_body)
    
    @pytest.mark.api
    def test_decline_hiring_context_returns_same_contract_shape(
        self,
        hiring_decline_scenario,
        assert_decision_json_contract
    ):
        """Decline hiring context must use same JSON structure."""
        response_body = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert_decision_json_contract(response_body)


# ==============================================================================
# CONTRACT CONSISTENCY: SAME REQUEST → SAME KEYS
# ==============================================================================

class TestContractConsistency:
    """Test that contract keys remain consistent for same request."""
    
    @pytest.mark.api
    def test_identical_requests_produce_identical_json_structure(
        self,
        healthy_company_decision_payload,
        assert_json_contract_shapes_match
    ):
        """Two identical requests should produce JSON with same keys."""
        # Simulate two responses to same payload
        response1_body = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        response2_body = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        # Should have identical shape
        assert_json_contract_shapes_match(response1_body, response2_body)
    
    @pytest.mark.api
    def test_different_valid_payloads_produce_same_contract_shape(
        self,
        healthy_company_decision_payload,
        struggling_company_decision_payload,
        assert_json_contract_shapes_match
    ):
        """Different but valid payloads should produce same structure."""
        healthy_response = {
            "kpi_summary": {"net_margin_pct": 40.0},
            "diagnosis": {"severity": "healthy"},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {"monthly_cost": 5_000},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "Good",
        }
        
        struggling_response = {
            "kpi_summary": {"net_margin_pct": 5.0},
            "diagnosis": {"severity": "warning"},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {"monthly_cost": 30_000},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "Caution",
        }
        
        # Both should have same keys
        assert_json_contract_shapes_match(healthy_response, struggling_response)


# ==============================================================================
# FIELD TYPE INVARIANTS
# ==============================================================================

class TestFieldTypeInvariants:
    """Test that field types never change unexpectedly."""
    
    @pytest.mark.api
    def test_cost_monthly_is_always_numeric(self):
        """monthly_cost must always be numeric, never string."""
        valid_costs = [0, 1000, 10_000, 100_000]
        invalid_costs = ["1000", "ten_thousand", None]
        
        for cost in valid_costs:
            assert isinstance(cost, (int, float))
        
        for cost in invalid_costs:
            assert not isinstance(cost, (int, float))
    
    @pytest.mark.api
    def test_urgency_level_is_always_string(self):
        """urgency_level must always be string, never enum or number."""
        valid_urgencies = ["low", "medium", "high", "critical"]
        invalid_urgencies = [1, 2, 3, None, ["low"]]
        
        for urgency in valid_urgencies:
            assert isinstance(urgency, str)
        
        for urgency in invalid_urgencies:
            assert not isinstance(urgency, str)
    
    @pytest.mark.api
    def test_top_decisions_is_always_list_of_dicts(self):
        """top_decisions must always be list of dicts, never list of strings."""
        valid_decisions = [
            {"title": "Action", "priority": "high"},
            {"title": "Action 2", "priority": "low"},
        ]
        
        decision_list = valid_decisions
        
        assert isinstance(decision_list, list)
        for decision in decision_list:
            assert isinstance(decision, dict)
            # Should not be strings
            assert not isinstance(decision, str)
    
    @pytest.mark.api
    def test_action_plan_timeframes_are_lists_not_strings(self):
        """action_plan immediate/weekly/monthly must be lists, not strings."""
        plan = {
            "immediate_actions": ["Do this", "Do that"],
            "weekly_actions": [],
            "monthly_actions": ["Review"],
        }
        
        for field in ["immediate_actions", "weekly_actions", "monthly_actions"]:
            assert isinstance(plan[field], list), \
                f"{field} should be list, not {type(plan[field])}"
            # Items should be strings, not dicts
            for item in plan[field]:
                assert isinstance(item, str)
    
    @pytest.mark.api
    def test_diagnosis_severity_matches_expected_enum(self):
        """diagnosis.severity must be one of known values."""
        valid_severities = ["healthy", "warning", "critical"]
        invalid_severities = ["good", "bad", "unknown", 1, None]
        
        for severity in valid_severities:
            assert severity in valid_severities
        
        for severity in invalid_severities:
            if isinstance(severity, str):
                assert severity not in valid_severities


# ==============================================================================
# FIELD PRESENCE REGRESSIONS
# ==============================================================================

class TestFieldPresenceRegressions:
    """Test that required fields never disappear from response."""
    
    @pytest.mark.api
    def test_kpi_summary_field_never_missing(self):
        """kpi_summary should always be present in response."""
        response = {
            "kpi_summary": {"net_margin_pct": 25.0},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        assert "kpi_summary" in response
        assert response["kpi_summary"] is not None
    
    @pytest.mark.api
    def test_cost_of_inaction_field_never_disappears(self):
        """cost_of_inaction should always be present."""
        response = {
            "cost_of_inaction": {"monthly_cost": 10_000},
        }
        
        assert "cost_of_inaction" in response
        assert response["cost_of_inaction"] is not None
    
    @pytest.mark.api
    def test_dominant_action_field_always_present(self):
        """dominant_action should always be present, even if simple."""
        response = {
            "dominant_action": {"title": "Default action"},
        }
        
        assert "dominant_action" in response
        assert response["dominant_action"] is not None
    
    @pytest.mark.api
    def test_cost_monthly_field_in_cost_of_inaction_never_missing(self):
        """monthly_cost should always be in cost_of_inaction."""
        cost = {
            "monthly_cost": 10_000,
            "quarterly_cost": 30_000,
            "annual_cost": 120_000,
            "urgency_level": "medium",
        }
        
        assert "monthly_cost" in cost
    
    @pytest.mark.api
    def test_quarterly_cost_field_must_be_present(self):
        """quarterly_cost must always be present in cost_of_inaction."""
        cost = {
            "monthly_cost": 10_000,
            "quarterly_cost": 30_000,
            "annual_cost": 120_000,
            "urgency_level": "medium",
        }
        
        assert "quarterly_cost" in cost
    
    @pytest.mark.api
    def test_annual_cost_field_must_be_present(self):
        """annual_cost must always be present in cost_of_inaction."""
        cost = {
            "monthly_cost": 10_000,
            "quarterly_cost": 30_000,
            "annual_cost": 120_000,
            "urgency_level": "medium",
        }
        
        assert "annual_cost" in cost


# ==============================================================================
# VALUE RELATIONSHIP INVARIANTS
# ==============================================================================

class TestValueRelationshipInvariants:
    """Test that relationships between values remain consistent."""
    
    @pytest.mark.api
    def test_quarterly_cost_is_exactly_three_times_monthly(self):
        """Quarterly must equal monthly * 3 exactly."""
        monthly = 10_000
        quarterly = 30_000
        annual = 120_000
        
        assert quarterly == monthly * 3
        assert annual == monthly * 12
    
    @pytest.mark.api
    def test_annual_cost_is_exactly_twelve_times_monthly(self):
        """Annual must equal monthly * 12 exactly."""
        monthly = 5_000
        quarterly = 15_000
        annual = 60_000
        
        assert annual == monthly * 12
        assert quarterly == monthly * 3
    
    @pytest.mark.api
    def test_gross_margin_gte_net_margin(self):
        """Gross margin must always be >= net margin."""
        scenarios = [
            {"gross": 75.0, "net": 45.0},  # Healthy
            {"gross": 40.0, "net": 5.0},   # Struggling
            {"gross": 30.0, "net": -5.0},  # Critical
        ]
        
        for scenario in scenarios:
            assert scenario["gross"] >= scenario["net"]
    
    @pytest.mark.api
    def test_priority_ordering_is_consistent(self):
        """Decision priorities should follow consistent ordering."""
        priority_order = ["critical", "high", "medium", "low"]
        
        sample_decisions = [
            {"title": "Decision 1", "priority": "high"},
            {"title": "Decision 2", "priority": "medium"},
            {"title": "Decision 3", "priority": "low"},
        ]
        
        # Check all priorities are valid
        for decision in sample_decisions:
            assert decision["priority"] in priority_order


# ==============================================================================
# ERROR RESPONSE CONSISTENCY
# ==============================================================================

class TestErrorResponseConsistency:
    """Test that error responses follow consistent structure."""
    
    @pytest.mark.api
    def test_http_422_error_response_has_consistent_structure(self):
        """422 error response must have consistent error structure."""
        # What a 422 response looks like from FastAPI
        error_response = {
            "detail": [
                {
                    "loc": ["body", "fatturato"],
                    "msg": "field required",
                    "type": "value_error.missing",
                }
            ]
        }
        
        assert "detail" in error_response
        assert isinstance(error_response["detail"], list)
    
    @pytest.mark.api
    def test_error_response_always_has_detail_field(self):
        """Error response must always have 'detail' field."""
        error = {
            "detail": "Invalid sector"
        }
        
        assert "detail" in error
        assert error["detail"] is not None
    
    @pytest.mark.api
    def test_invalid_payload_returns_422_not_500(self):
        """Invalid payload must return 422, never 500."""
        # Status codes
        valid_error_codes = [400, 422]
        invalid_codes = [500, 200, 201]
        
        # When payload is invalid, should be 422 or 400
        assert 422 in valid_error_codes or 400 in valid_error_codes


# ==============================================================================
# CONTRACT REGRESSION DETECTION
# ==============================================================================

class TestContractRegressionDetection:
    """Tests that would fail if contract regresses."""
    
    @pytest.mark.api
    def test_fails_if_kpi_summary_becomes_list(self):
        """Should fail if kpi_summary accidentally becomes list."""
        # This SHOULD fail contract validation
        bad_response = {
            "kpi_summary": [  # WRONG: should be dict
                {"net_margin_pct": 45.0}
            ],
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            "scenarios": [],
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        # Should detect type mismatch
        assert isinstance(bad_response["kpi_summary"], list)
        assert not isinstance(bad_response["kpi_summary"], dict)
    
    @pytest.mark.api
    def test_fails_if_top_decisions_becomes_dict(self):
        """Should fail if top_decisions accidentally becomes dict."""
        bad_response = {
            "top_decisions": {  # WRONG: should be list
                "decision1": {"title": "Action"}
            }
        }
        
        assert isinstance(bad_response["top_decisions"], dict)
        assert not isinstance(bad_response["top_decisions"], list)
    
    @pytest.mark.api
    def test_fails_if_cost_monthly_becomes_string(self):
        """Should fail if monthly_cost becomes string."""
        bad_cost = {
            "monthly_cost": "10000",  # WRONG: should be numeric
        }
        
        assert isinstance(bad_cost["monthly_cost"], str)
        assert not isinstance(bad_cost["monthly_cost"], (int, float))
    
    @pytest.mark.api
    def test_fails_if_mandatory_field_disappears(self):
        """Test would fail if mandatory contract field disappears."""
        incomplete_response = {
            "kpi_summary": {},
            "diagnosis": {},
            "dominant_action": {},
            "top_decisions": [],
            # MISSING: scenarios
            "cost_of_inaction": {},
            "action_plan": {},
            "objections": {},
            "memorable_insight": "",
        }
        
        # Test detection - scenarios should be present
        assert "scenarios" not in incomplete_response  # MISSING!
        
        # Validation would fail
        assert len(incomplete_response) < 9  # Should have 9 fields
