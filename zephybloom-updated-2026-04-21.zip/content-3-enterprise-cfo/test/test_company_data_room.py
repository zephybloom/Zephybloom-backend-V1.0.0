from core.company_data_room import build_company_data_room


def test_company_data_room_prioritizes_missing_restaurant_entities():
    data_room = build_company_data_room(
        company_data={
            "company_name": "Risto Test",
            "fatturato": 900000,
            "costi_variabili": 300000,
            "costi_fissi": 180000,
            "investimenti": 120000,
            "settore": "restaurant",
            "staff_roles": [{"role": "Cuoco", "count": 2, "monthly_cost": 2400}],
        },
        operational_data_by_sector={
            "restaurant": {
                "annual_revenue": 900000,
                "average_ticket": 36,
                "opening_days_per_month": 25,
            }
        },
        active_sector="restaurant",
    )

    assert data_room["version"] == "company-data-room-v1"
    assert data_room["active_sector"] == "restaurant"
    assert data_room["readiness_score_pct"] > 0
    assert data_room["sector_entities"]["coverage_pct"] < 100
    assert "menu_items" in data_room["sector_entities"]["missing_entities"]
    assert "ingredient_costs" in data_room["sector_entities"]["missing_entities"]
    assert data_room["priority_gaps"]
    assert data_room["next_questions"]
    assert data_room["guided_collection"]["schema_version"] == "data-room-guided-collection-v1"
    assert data_room["guided_collection"]["first_step"]["destination"] == "operational_data_by_sector.restaurant"
    first_keys = {field["key"] for field in data_room["guided_collection"]["first_step"]["fields"]}
    assert "menu_items" in first_keys
    assert "ingredient_costs" in first_keys
    assert data_room["premium_outputs"]["structured_company_memory"] is True
    assert data_room["premium_outputs"]["dynamic_collection_schema"] is True


def test_company_data_room_reaches_high_readiness_with_operational_entities():
    data_room = build_company_data_room(
        company_data={
            "company_name": "Shop Test",
            "fatturato": 600000,
            "costi_variabili": 250000,
            "costi_fissi": 90000,
            "investimenti": 80000,
            "settore": "ecommerce",
            "sales_channels": [{"channel": "Meta Ads", "revenue": 200000}],
            "customers": [{"segment": "repeat", "revenue": 150000}],
        },
        operational_data_by_sector={
            "ecommerce": {
                "sku_sales": [{"sku": "Hero", "price": 75, "purchase_cost": 24, "monthly_units": 500}],
                "purchase_costs": {"Hero": 24},
                "monthly_orders": 800,
                "customer_acquisition_cost": 18,
                "return_rate_pct": 5,
            }
        },
        active_sector="ecommerce",
    )

    assert data_room["sector_entities"]["can_answer_sector_questions"] is True
    assert data_room["sector_entities"]["coverage_pct"] == 100
    assert data_room["readiness_score_pct"] >= 30
    assert data_room["readiness_level"] in {"guided_collection_needed", "analysis_ready", "cfo_ready"}
