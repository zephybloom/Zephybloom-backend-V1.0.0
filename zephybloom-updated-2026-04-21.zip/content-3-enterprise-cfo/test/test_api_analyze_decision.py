"""
API endpoint tests for /cfo/analyze-decision

Tests for:
- POST /cfo/analyze-decision with valid payload → 200
- Response JSON structure completeness
- Invalid payload handling → 422
- Missing required fields → 422
- Healthy/warning/critical scenarios
- Response schema stability
"""

import pytest
from fastapi.testclient import TestClient
from api.main import app
from test.conftest import assert_valid_decision_result


@pytest.fixture
def client(authenticated_client):
    """FastAPI test client with authentication."""
    return authenticated_client



class TestAnalyzeDecisionEndpointBasics:
    """Test basic endpoint functionality."""
    
    def test_endpoint_exists(self, client):
        """Endpoint should be available."""
        # This will either return 200 or 422, not 404
        response = client.post(
            "/cfo/analyze-decision",
            json={
                "fatturato": 1_000_000,
                "costi_variabili": 400_000,
                "costi_fissi": 300_000,
                "investimenti": 100_000,
                "company_name": "Test",
                "sector": "saas",
                "employee_count": 25,
                "monthly_salary_avg": 4_000,
                "hiring_context": "stable",
            }
        )
        
        # Should not be 404 (endpoint exists)
        assert response.status_code != 404
    
    def test_endpoint_requires_post(self, client):
        """Endpoint should require POST method."""
        response = client.get("/cfo/analyze-decision")
        assert response.status_code in [404, 405]  # Not found or method not allowed


class TestAnalyzeDecisionValidRequest:
    """Test successful requests."""
    
    def test_analyze_decision_valid_payload_returns_200(
        self, client, valid_analyze_decision_payload
    ):
        """Valid request should return 200."""
        response = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        
        assert response.status_code == 200
    
    def test_analyze_decision_response_has_json(
        self, client, valid_analyze_decision_payload
    ):
        """Response should be valid JSON."""
        response = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, dict)
    
    def test_analyze_decision_response_structure(
        self, client, valid_analyze_decision_payload
    ):
        """Response should have expected structure."""
        response = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Core decision response fields
        assert "dominant_action" in data or "status" in data
        assert "recommended_actions" in data or "headline" in data


class TestAnalyzeDecisionHealthyCompany:
    """Test decision API with healthy company."""
    
    def test_analyze_decision_healthy_saas(self, client, healthy_saas_company):
        """Should analyze healthy SaaS company."""
        payload = {
            "fatturato": healthy_saas_company["fatturato"],
            "costi_variabili": healthy_saas_company["costi_variabili"],
            "costi_fissi": healthy_saas_company["costi_fissi"],
            "investimenti": healthy_saas_company["investimenti"],
            "company_name": "HealthySaaS",
            "sector": healthy_saas_company["sector"],
            "employee_count": 25,
            "monthly_salary_avg": 4_500,
            "hiring_context": "stable",
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should recognize healthy status
        if "status" in data:
            assert data["status"] in ["healthy", "warning"]
    
    def test_analyze_decision_healthy_manufacturing(
        self, client, healthy_manufacturing_company
    ):
        """Should analyze healthy manufacturing company."""
        payload = {
            "fatturato": healthy_manufacturing_company["fatturato"],
            "costi_variabili": healthy_manufacturing_company["costi_variabili"],
            "costi_fissi": healthy_manufacturing_company["costi_fissi"],
            "investimenti": healthy_manufacturing_company["investimenti"],
            "company_name": "HealthyManuf",
            "sector": healthy_manufacturing_company["sector"],
            "employee_count": 50,
            "monthly_salary_avg": 3_500,
            "hiring_context": "stable",
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200


class TestAnalyzeDecisionWarningCompany:
    """Test decision API with warning-level company."""
    
    def test_analyze_decision_struggling_company(self, client, struggling_company):
        """Should analyze struggling company."""
        payload = {
            "fatturato": struggling_company["fatturato"],
            "costi_variabili": struggling_company["costi_variabili"],
            "costi_fissi": struggling_company["costi_fissi"],
            "investimenti": struggling_company["investimenti"],
            "company_name": "Struggling",
            "sector": struggling_company["sector"],
            "employee_count": 20,
            "monthly_salary_avg": 3_000,
            "hiring_context": "decline",
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should identify warning/critical status
        if "status" in data:
            assert data["status"] in ["warning", "critical"]


class TestAnalyzeDecisionCriticalCompany:
    """Test decision API with critical company."""
    
    def test_analyze_decision_loss_making_company(self, client, loss_making_company):
        """Should analyze loss-making company."""
        payload = {
            "fatturato": loss_making_company["fatturato"],
            "costi_variabili": loss_making_company["costi_variabili"],
            "costi_fissi": loss_making_company["costi_fissi"],
            "investimenti": loss_making_company["investimenti"],
            "company_name": "LossMaker",
            "sector": loss_making_company["sector"],
            "employee_count": 15,
            "monthly_salary_avg": 2_800,
            "hiring_context": "hold",
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should be critical
        if "status" in data:
            assert data["status"] == "critical"


class TestAnalyzeDecisionInvalidPayloads:
    """Test error handling for invalid payloads."""
    
    def test_analyze_decision_missing_fatturato(self, client):
        """Should return 422 for missing revenue."""
        response = client.post("/cfo/analyze-decision", json={
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_missing_employee_count(self, client):
        """Should return 422 for missing employee count."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "monthly_salary_avg": 4_000,
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_missing_salary(self, client):
        """Should return 422 for missing salary."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_missing_hiring_context(self, client):
        """Should return 422 for missing hiring context."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
        })
        
        assert response.status_code == 422


@pytest.mark.negativity
class TestAnalyzeDecisionInvalidData:
    """Test error handling for invalid data types."""
    
    def test_analyze_decision_negative_fatturato(self, client):
        """Should return 422 for negative revenue."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": -1_000_000,  # Invalid
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_negative_salary(self, client):
        """Should return 422 for negative salary."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": -4_000,  # Invalid
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_invalid_hiring_context(self, client):
        """Should return 422 for invalid hiring context."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
            "hiring_context": "invalid_context",  # Invalid
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_invalid_sector(self, client):
        """Should return 422 for invalid sector."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "unknown_sector",  # Invalid
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422
    
    def test_analyze_decision_string_numbers(self, client):
        """Should return 422 for non-numeric values."""
        response = client.post("/cfo/analyze-decision", json={
            "fatturato": "not_a_number",
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
            "hiring_context": "stable",
        })
        
        assert response.status_code == 422


@pytest.mark.negativity
class TestAnalyzeDecisionMalformedRequest:
    """Test handling of badly formatted requests."""
    
    def test_analyze_decision_malformed_json(self, client):
        """Should handle malformed JSON."""
        response = client.post(
            "/cfo/analyze-decision",
            content="not json",
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code in [400, 422]
    
    def test_analyze_decision_empty_payload(self, client):
        """Should handle empty payload."""
        response = client.post(
            "/cfo/analyze-decision",
            json={}
        )
        
        assert response.status_code == 422


class TestAnalyzeDecisionHiringScenarios:
    """Test response for different hiring scenarios."""
    
    def test_analyze_decision_boom_scenario(self, client, hiring_boom_scenario):
        """Should process hiring boom scenario."""
        payload = {
            "fatturato": hiring_boom_scenario["fatturato"],
            "costi_variabili": hiring_boom_scenario["costi_variabili"],
            "costi_fissi": hiring_boom_scenario["costi_fissi"],
            "investimenti": hiring_boom_scenario["investimenti"],
            "company_name": "BoomCo",
            "sector": hiring_boom_scenario["sector"],
            "employee_count": hiring_boom_scenario["employee_count"],
            "monthly_salary_avg": hiring_boom_scenario["monthly_salary_avg"],
            "hiring_context": hiring_boom_scenario["hiring_context"],
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200
    
    def test_analyze_decision_decline_scenario(self, client, hiring_decline_scenario):
        """Should process hiring decline scenario."""
        payload = {
            "fatturato": hiring_decline_scenario["fatturato"],
            "costi_variabili": hiring_decline_scenario["costi_variabili"],
            "costi_fissi": hiring_decline_scenario["costi_fissi"],
            "investimenti": hiring_decline_scenario["investimenti"],
            "company_name": "DeclineCo",
            "sector": hiring_decline_scenario["sector"],
            "employee_count": hiring_decline_scenario["employee_count"],
            "monthly_salary_avg": hiring_decline_scenario["monthly_salary_avg"],
            "hiring_context": hiring_decline_scenario["hiring_context"],
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200
    
    def test_analyze_decision_stable_scenario(self, client, stable_hiring_scenario):
        """Should process stable scenario."""
        payload = {
            "fatturato": stable_hiring_scenario["fatturato"],
            "costi_variabili": stable_hiring_scenario["costi_variabili"],
            "costi_fissi": stable_hiring_scenario["costi_fissi"],
            "investimenti": stable_hiring_scenario["investimenti"],
            "company_name": "StableCo",
            "sector": stable_hiring_scenario["sector"],
            "employee_count": stable_hiring_scenario["employee_count"],
            "monthly_salary_avg": stable_hiring_scenario["monthly_salary_avg"],
            "hiring_context": stable_hiring_scenario["hiring_context"],
        }
        
        response = client.post("/cfo/analyze-decision", json=payload)
        
        assert response.status_code == 200


@pytest.mark.api
class TestAnalyzeDecisionResponseConsistency:
    """Test response consistency and schema stability."""
    
    def test_response_schema_stable_across_calls(
        self, client, valid_analyze_decision_payload
    ):
        """Response schema should be consistent."""
        response1 = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        response2 = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        
        data1 = response1.json()
        data2 = response2.json()
        
        # Same keys in response
        assert set(data1.keys()) == set(data2.keys())
    
    def test_error_response_format_422(self, client):
        """Error responses should have consistent format."""
        response = client.post("/cfo/analyze-decision", json={})
        
        assert response.status_code == 422
        data = response.json()
        
        # FastAPI standard error format
        assert "detail" in data
    
    def test_success_response_has_content(self, client, valid_analyze_decision_payload):
        """Success responses should have meaningful content."""
        response = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should not be empty
        assert len(data) > 0
        assert isinstance(data, dict)


@pytest.mark.slow
@pytest.mark.api
class TestAnalyzeDecisionBatchPerformance:
    """Test performance with multiple requests."""
    
    def test_multiple_requests_successful(
        self, client, valid_analyze_decision_payload
    ):
        """Should handle multiple requests."""
        for i in range(5):
            response = client.post("/cfo/analyze-decision", json=valid_analyze_decision_payload)
            assert response.status_code == 200
    
    def test_different_payloads_all_succeed(self, client, healthy_saas_company, 
                                             struggling_company, loss_making_company):
        """Different data should all process successfully."""
        test_companies = [
            ("Healthy", healthy_saas_company),
            ("Struggling", struggling_company),
            ("Critical", loss_making_company),
        ]
        
        for name, company in test_companies:
            payload = {
                "fatturato": company["fatturato"],
                "costi_variabili": company["costi_variabili"],
                "costi_fissi": company["costi_fissi"],
                "investimenti": company["investimenti"],
                "company_name": name,
                "sector": company["sector"],
                "employee_count": 25,
                "monthly_salary_avg": 4_000,
                "hiring_context": "stable",
            }
            
            response = client.post("/cfo/analyze-decision", json=payload)
            assert response.status_code == 200
