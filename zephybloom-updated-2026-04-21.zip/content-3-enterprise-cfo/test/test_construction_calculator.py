from core.construction_calculator import analyze_construction, simulate_construction


def test_construction_calculator_returns_margin_cash_gap_and_wip():
    result = analyze_construction({
        "fixed_costs": 80000,
        "invested_capital": 120000,
        "projects": [
            {
                "project": "Cantiere A",
                "contract_value": 240000,
                "materials_cost": 82000,
                "labor_cost": 46000,
                "subcontractor_cost": 28000,
                "other_cost": 10000,
                "progress_pct": 65,
                "billed_pct": 45,
                "collected_pct": 25,
                "delay_weeks": 2,
                "penalty_pct_per_week": 0.5,
                "change_orders_approved": 12000,
                "change_orders_unapproved": 8000,
            },
            {
                "project": "Cantiere B",
                "contract_value": 180000,
                "materials_cost": 70000,
                "labor_cost": 42000,
                "subcontractor_cost": 30000,
                "progress_pct": 40,
                "billed_pct": 50,
                "collected_pct": 50,
            },
        ],
    })

    assert result["summary"]["project_count"] == 2
    assert result["summary"]["cash_gap_eur"] > 0
    assert result["summary"]["wip_unbilled_eur"] > 0
    assert result["projects_by_cash_risk"][0]["project"] == "Cantiere A"
    assert result["recommendations"]


def test_construction_simulation_compares_cash_gap_and_margin():
    data = {
        "fixed_costs": 80000,
        "invested_capital": 120000,
        "projects": [
            {
                "project": "Cantiere A",
                "contract_value": 240000,
                "materials_cost": 82000,
                "labor_cost": 46000,
                "subcontractor_cost": 28000,
                "other_cost": 10000,
                "progress_pct": 65,
                "billed_pct": 45,
                "collected_pct": 25,
            }
        ],
    }

    result = simulate_construction(data, {"collected_delta_pct": 20, "billed_delta_pct": 15})

    assert result["delta"]["cash_gap_eur"] < 0
    assert result["simulated"]["summary"]["collected_eur"] > result["base"]["summary"]["collected_eur"]
    assert result["decision"].startswith(("GO", "TEST", "CASH"))
