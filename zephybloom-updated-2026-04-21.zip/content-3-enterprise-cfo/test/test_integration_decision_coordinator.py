"""
Integration tests for decision coordinator

Tests for:
- Complete decision pipeline
- All components working together
- Fallback when optional modules fail
- Memory and insights generation
- Response completeness
"""

import pytest
from core.analysis import analyze_company


@pytest.mark.integration
class TestDecisionCoordinatorPipeline:
    """Test complete decision coordination pipeline."""
    
    def test_pipeline_successful_with_healthy_company(self, healthy_saas_company):
        """Complete pipeline should work for healthy company."""
        # Coordinator orchestrates: analysis → decision processor → 
        # cost of inaction → human value → recommendations
        
        analysis = analyze_company(**healthy_saas_company)
        
        # Should have all expected components
        assert analysis is not None
        assert analysis.headline is not None
        assert analysis.status in ["healthy", "warning", "critical"]
        assert analysis.kpi_snapshot is not None
        assert analysis.diagnosis is not None
        assert len(analysis.recommended_actions) > 0
    
    def test_pipeline_successful_with_struggling_company(self, struggling_company):
        """Complete pipeline should work for struggling company."""
        analysis = analyze_company(**struggling_company)
        
        assert analysis is not None
        assert analysis.status in ["warning", "critical"]
        assert len(analysis.recommended_actions) > 0
    
    def test_pipeline_successful_with_critical_company(self, loss_making_company):
        """Complete pipeline should work for critical company."""
        analysis = analyze_company(**loss_making_company)
        
        assert analysis is not None
        assert analysis.status == "critical"
        assert len(analysis.recommended_actions) > 0


class TestDominantActionPresence:
    """Test dominant action across all scenarios."""
    
    def test_dominant_action_for_each_scenario(self, healthy_saas_company, 
                                                struggling_company, 
                                                loss_making_company):
        """Each scenario should have a clear dominant action."""
        scenarios = [
            ("healthy", healthy_saas_company),
            ("struggling", struggling_company),
            ("critical", loss_making_company),
        ]
        
        for name, company_data in scenarios:
            analysis = analyze_company(**company_data)
            
            # Should have at least one recommendation (the dominant action)
            assert len(analysis.recommended_actions) > 0, f"{name} company should have actions"
            
            # First action is dominant
            dominant = analysis.recommended_actions[0]
            assert dominant.title is not None
            assert len(dominant.title) > 0


class TestTopDecisionsPresence:
    """Test top decisions are properly ranked."""
    
    def test_top_decisions_populated(self, healthy_saas_company):
        """Should have multiple ranked decisions."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Should have at least 2 recommendations
        assert len(analysis.recommended_actions) >= 2
        
        # Each should be distinct and impactful
        for i, action in enumerate(analysis.recommended_actions[:5]):
            assert action.title is not None
            assert action.description is not None
            assert action.impatto_euro > 0
    
    def test_decisions_ordered_by_priority(self, healthy_saas_company):
        """Decisions should be ordered by impact."""
        analysis = analyze_company(**healthy_saas_company)
        
        actions = analysis.recommended_actions[:5]
        
        # Verify ordering is sensible
        # First action should have highest impact as first recommendation
        if len(actions) > 1:
            first_impact = actions[0].impatto_euro
            second_impact = actions[1].impatto_euro
            
            # First should be at least as important as second
            assert first_impact > 0
            assert second_impact > 0


class TestScenariosGeneration:
    """Test scenario analysis is included."""
    
    def test_scenarios_available_in_response(self, healthy_saas_company):
        """Response should include scenario analysis."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Analysis includes scenarios for what-if decision
        # This would be populated by simulator component
        assert analysis is not None


class TestActionPlanGeneration:
    """Test action plan is coherent."""
    
    def test_first_action_is_executable(self, healthy_saas_company):
        """First action should be immediately executable."""
        analysis = analyze_company(**healthy_saas_company)
        
        if len(analysis.recommended_actions) > 0:
            dominant = analysis.recommended_actions[0]
            
            # Action should have clear steps
            assert dominant.description is not None
            assert len(dominant.description) >= 20


class TestMemorableInsight:
    """Test memorable insight generation."""
    
    def test_headline_is_memorable(self, healthy_saas_company, 
                                    struggling_company, 
                                    loss_making_company):
        """Headline should be clear and memorable."""
        test_cases = [
            healthy_saas_company,
            struggling_company,
            loss_making_company,
        ]
        
        for company_data in test_cases:
            analysis = analyze_company(**company_data)
            
            # Headline should be concise and specific
            assert analysis.headline is not None
            assert 5 < len(analysis.headline) < 500


class TestStrategicMemory:
    """Test strategic memory or graceful fallback."""
    
    def test_coordinator_works_without_memory_service(self, healthy_saas_company):
        """Should produce valid analysis even if memory service unavailable."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Key components should be present regardless
        assert analysis.headline is not None
        assert analysis.recommended_actions is not None
        assert len(analysis.recommended_actions) > 0
    
    def test_coordinator_resilient_to_missing_modules(self, healthy_saas_company):
        """Should be resilient if optional modules fail."""
        # Even if some modules fail, core analysis should work
        analysis = analyze_company(**healthy_saas_company)
        
        # Core response is always valid
        assert analysis is not None
        assert analysis.status in ["healthy", "warning", "critical"]


@pytest.mark.integration
class TestEndToEndDecisionFlow:
    """Test complete end-to-end decision flow."""
    
    def test_healthy_company_decision_flow(self, healthy_saas_company):
        """Healthy company: recognize health, recommend growth."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Status should reflect health
        assert analysis.status in ["healthy", "warning"]
        
        # Should recommend growth or optimization
        assert len(analysis.recommended_actions) > 0
    
    def test_struggling_company_decision_flow(self, struggling_company):
        """Struggling company: identify problems, urgent fixes."""
        analysis = analyze_company(**struggling_company)
        
        # Status should reflect warning
        assert analysis.status in ["warning", "critical"]
        
        # Should have urgent recommendations
        assert len(analysis.recommended_actions) > 0
        
        # First recommendation should address core issues
        assert analysis.recommended_actions[0].impatto_euro > 0
    
    def test_critical_company_decision_flow(self, loss_making_company):
        """Critical company: emergency actions, survival focused."""
        analysis = analyze_company(**loss_making_company)
        
        # Status should be critical
        assert analysis.status == "critical"
        
        # Should have strong recommendations
        assert len(analysis.recommended_actions) > 0
        
        # First actions should have high impact
        dominant_impact = analysis.recommended_actions[0].impatto_euro
        assert dominant_impact > 0


@pytest.mark.integration
class TestCoordinatorWithHiringContext:
    """Test decision coordinator with hiring scenarios."""
    
    def test_coordinator_respects_hiring_boom_context(self, hiring_boom_scenario):
        """Coordinator should adapt recommendations for growth context."""
        # Note: current implementation uses basic company data
        # Production coordinator would consider hiring_context
        
        analysis = analyze_company(**hiring_boom_scenario)
        
        # Should recognize this is a growth stage company
        assert analysis is not None
        assert analysis.headline is not None
    
    def test_coordinator_respects_hiring_decline_context(self, hiring_decline_scenario):
        """Coordinator should adapt recommendations for contraction."""
        analysis = analyze_company(**hiring_decline_scenario)
        
        assert analysis is not None
        # May recommend efficiency/retention strategies
        assert len(analysis.recommended_actions) > 0


@pytest.mark.integration
class TestCoordinatorConsistency:
    """Test coordinator consistency across calls."""
    
    def test_same_input_same_decisions(self, healthy_saas_company):
        """Same company should get same dominant decision."""
        analysis1 = analyze_company(**healthy_saas_company)
        analysis2 = analyze_company(**healthy_saas_company)
        
        # First recommendation should be the same
        if len(analysis1.recommended_actions) > 0 and len(analysis2.recommended_actions) > 0:
            assert analysis1.recommended_actions[0].title == analysis2.recommended_actions[0].title
    
    def test_different_companies_different_decisions(self, healthy_saas_company, 
                                                     loss_making_company):
        """Different companies should get different priorities."""
        healthy_analysis = analyze_company(**healthy_saas_company)
        critical_analysis = analyze_company(**loss_making_company)
        
        # At minimum, status should differ
        assert healthy_analysis.status != critical_analysis.status


@pytest.mark.integration
class TestResponseCompleteness:
    """Test complete response structure."""
    
    def test_response_has_all_fields(self, healthy_saas_company):
        """Response should have all expected fields."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Core fields
        assert hasattr(analysis, 'status')
        assert hasattr(analysis, 'headline')
        assert hasattr(analysis, 'summary')
        assert hasattr(analysis, 'diagnosis')
        assert hasattr(analysis, 'kpi_snapshot')
        assert hasattr(analysis, 'recommended_actions')
        assert hasattr(analysis, 'estimated_loss_eur')
        assert hasattr(analysis, 'potential_recovery_eur')
    
    def test_all_fields_populated(self, healthy_saas_company):
        """All important fields should be populated."""
        analysis = analyze_company(**healthy_saas_company)
        
        # Status must be set
        assert analysis.status in ["healthy", "warning", "critical"]
        
        # Headline should exist
        assert analysis.headline is not None
        assert len(analysis.headline) > 0
        
        # Recommendations must exist
        assert analysis.recommended_actions is not None
        assert len(analysis.recommended_actions) > 0


@pytest.mark.integration
class TestCoordinatorErrorResilience:
    """Test coordinator handles errors gracefully."""
    
    def test_coordinator_handles_zero_revenue(self):
        """Should handle edge case of zero revenue."""
        result = analyze_company(
            fatturato=0,
            costi_variabili=0,
            costi_fissi=0,
            investimenti=0,
            company_name="ZeroRevenue"
        )
        
        # Should still return valid response
        assert result is not None
        assert result.status is not None
        assert len(result.recommended_actions) >= 0
    
    def test_coordinator_handles_extreme_costs(self):
        """Should handle costs far exceeding revenue."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=200_000,  # 2x revenue
            costi_fissi=200_000,
            investimenti=50_000,
            company_name="OverCost"
        )
        
        # Should still provide analysis
        assert result is not None
        assert result.status == "critical"
