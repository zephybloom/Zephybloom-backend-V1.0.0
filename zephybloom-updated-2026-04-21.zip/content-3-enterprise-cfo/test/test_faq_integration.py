"""
FAQ integration tests for controlled CFO knowledge.
"""

from faq.faq_router import route_faq
from faq.validate_faq import validate_structure
from infra.ai_provider import CFOGPTProvider

import yaml


def test_route_faq_loads_repo_faq_by_default():
    result = route_faq("Spiegami il ROI")

    assert result["matched"] is True
    assert result["score"] >= 60
    assert "ROI" in result["answer"]


def test_validate_faq_accepts_flat_repo_format():
    with open("faq/faq.yml", "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    issues, stats = validate_structure(data)
    errors = [issue for issue in issues if issue.level == "ERROR"]

    assert errors == []
    assert stats.total_entries > 0
    assert stats.total_variants >= stats.total_entries


def test_ai_provider_context_includes_faq_knowledge():
    provider = CFOGPTProvider.__new__(CFOGPTProvider)
    context = provider._build_company_context(
        {
            "company_name": "FAQCo",
            "fatturato": 800000,
            "costi_variabili": 300000,
            "costi_fissi": 250000,
            "investimenti": 50000,
            "settore": "services",
            "faq_context": {
                "matched_question": "Cos'è il ROI?",
                "category": "kpi_roi_definition",
                "answer": "ROI = Utile / Investimenti x 100.",
            },
        }
    )

    assert "FAQ_KNOWLEDGE VERIFICATA" in context
    assert "Cos'è il ROI?" in context
    assert "ROI = Utile" in context
