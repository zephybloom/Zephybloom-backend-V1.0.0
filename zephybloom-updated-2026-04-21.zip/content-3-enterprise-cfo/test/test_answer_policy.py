"""
Semantic guardrail tests for CFO AI answers.
"""

from core.answer_policy import build_safe_cfo_answer, validate_cfo_answer
from infra.ai_provider import CFOAnalysisAI, CFOGPTProvider


def _answer(text: str) -> CFOAnalysisAI:
    return CFOAnalysisAI(
        key_number=text,
        headline=text,
        diagnostic=text,
        risk_assessment=text,
        priority_action=text,
        other_actions=[],
        estimated_impact=text,
        why_it_matters=text,
        strategic_advice=text,
    )


def test_blocks_aggressive_growth_when_company_needs_stabilization():
    insight = {
        "health_label": "Stabilization required",
        "strategic_posture": "stabilize",
        "primary_constraint": {"type": "profitability"},
    }
    answer = _answer("Stabilization required, scalare aggressivamente e crescita aggressiva subito.")

    validation = validate_cfo_answer(answer, insight)

    assert validation.is_valid is False
    assert validation.blocked_terms


def test_accepts_profitability_answer_for_critical_company():
    insight = {
        "health_label": "Stabilization required",
        "strategic_posture": "stabilize",
        "primary_constraint": {"type": "profitability"},
    }
    answer = _answer("Stabilization required: priorita su margine, profitto, costi e cassa.")

    validation = validate_cfo_answer(answer, insight)

    assert validation.is_valid is True
    assert validation.blocked_terms == []


def test_requires_cash_language_for_cash_cycle_constraint():
    insight = {
        "health_label": "Viable but constrained",
        "strategic_posture": "optimize",
        "primary_constraint": {"type": "cash_cycle"},
    }
    answer = _answer("Viable but constrained: lavoriamo solo sul brand e sulla comunicazione.")

    validation = validate_cfo_answer(answer, insight)

    assert validation.is_valid is False
    assert "Cash cycle constraint" in validation.warnings[0]


def test_builds_safe_fallback_from_insight():
    insight = {
        "health_label": "Stabilization required",
        "strategic_posture": "stabilize",
        "primary_constraint": {
            "type": "profitability",
            "summary": "The company is losing money after fixed costs.",
            "risk_window": "0-90 days",
        },
        "next_best_move": {
            "focus": "profitability",
            "move": "Restore positive net margin before funding growth.",
            "supporting_action": "Reduce fixed costs",
        },
        "capital_efficiency": {"roi_pct": -20.0, "target_roi_pct": 18.0},
        "watch_metrics": ["net_margin_pct", "ebitda_margin_pct"],
        "benchmark_gaps": [],
    }

    fallback = build_safe_cfo_answer(
        insight=insight,
        base_analysis={
            "potential_recovery_eur": 120000,
            "kpi_snapshot": {"net_margin_pct": -8.0},
        },
    )

    assert "Restore positive net margin" in fallback.priority_action
    assert "stabilize" in fallback.strategic_advice
    assert "120,000" in fallback.estimated_impact


def test_ai_provider_context_includes_binding_cfo_insight():
    provider = CFOGPTProvider.__new__(CFOGPTProvider)
    context = provider._build_company_context(
        {
            "company_name": "GuardedCo",
            "fatturato": 500000,
            "costi_variabili": 300000,
            "costi_fissi": 260000,
            "investimenti": 20000,
            "settore": "retail",
            "industry_insight": {
                "health_label": "Stabilization required",
                "strategic_posture": "stabilize",
                "primary_constraint": {
                    "type": "profitability",
                    "summary": "The company is losing money.",
                    "risk_window": "0-90 days",
                },
                "next_best_move": {
                    "move": "Restore positive net margin before funding growth.",
                },
                "watch_metrics": ["net_margin_pct", "cash_runway"],
            },
        }
    )

    assert "CFO_INSIGHT VINCOLANTE" in context
    assert "Strategic posture: stabilize" in context
    assert "Primary constraint: profitability" in context
