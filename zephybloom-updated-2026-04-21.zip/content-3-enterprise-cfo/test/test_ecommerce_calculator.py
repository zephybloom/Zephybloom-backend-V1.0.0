from core.ecommerce_calculator import analyze_ecommerce, simulate_ecommerce


def test_ecommerce_calculator_returns_sku_margin_and_break_even_cac():
    result = analyze_ecommerce({
        "annual_revenue": 600000,
        "fixed_costs": 90000,
        "invested_capital": 80000,
        "average_order_value": 75,
        "monthly_orders": 800,
        "customer_acquisition_cost": 18,
        "monthly_ad_spend": 12000,
        "payment_fees_pct": 2,
        "return_rate_pct": 5,
        "sku_sales": [
            {
                "sku": "Hero Product",
                "price": 75,
                "purchase_cost": 24,
                "shipping_cost": 7,
                "monthly_units": 500,
            },
            {
                "sku": "Low Margin Product",
                "price": 40,
                "purchase_cost": 31,
                "shipping_cost": 6,
                "monthly_units": 300,
            },
        ],
    })

    assert result["summary"]["break_even_cac_eur"] > 0
    assert result["top_skus_by_profit"][0]["sku"] == "Hero Product"
    assert result["skus_to_fix"][0]["sku"] == "Low Margin Product"
    assert result["recommendations"]


def test_ecommerce_simulation_compares_base_and_scenario():
    data = {
        "annual_revenue": 600000,
        "fixed_costs": 90000,
        "invested_capital": 80000,
        "average_order_value": 75,
        "monthly_orders": 800,
        "customer_acquisition_cost": 18,
        "monthly_ad_spend": 12000,
        "payment_fees_pct": 2,
        "return_rate_pct": 5,
        "sku_sales": [
            {
                "sku": "Hero Product",
                "price": 75,
                "purchase_cost": 24,
                "shipping_cost": 7,
                "monthly_units": 500,
            }
        ],
    }

    result = simulate_ecommerce(data, {"price_delta_pct": 5, "volume_delta_pct": 10, "return_rate_delta_pct": -1})

    assert result["delta"]["net_profit_eur"] > 0
    assert result["simulated"]["summary"]["annual_revenue_eur"] > result["base"]["summary"]["annual_revenue_eur"]
    assert result["decision"].startswith(("GO", "TEST"))
