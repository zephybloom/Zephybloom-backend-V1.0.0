"""
Tests for the deterministic CFO intelligence layer.
"""

from core.analysis import analyze_company
from core.cfo_intelligence import build_cfo_insight_pack


def test_healthy_saas_gets_scaling_posture():
    analysis = analyze_company(
        fatturato=1_200_000,
        costi_variabili=240_000,
        costi_fissi=420_000,
        investimenti=60_000,
        settore="saas",
        company_name="Healthy SaaS",
    )

    insight = build_cfo_insight_pack(analysis, settore="saas")

    assert insight["version"] == "cfo-intelligence-v1"
    assert insight["industry"]["code"] == "saas"
    assert insight["strategic_posture"] in {"scale_selectively", "optimize"}
    assert insight["primary_constraint"]["type"] == "growth_quality"
    assert insight["confidence"] >= 0.8


def test_loss_making_company_prioritizes_profitability():
    analysis = analyze_company(
        fatturato=800_000,
        costi_variabili=420_000,
        costi_fissi=520_000,
        investimenti=30_000,
        settore="manufacturing",
        company_name="Loss Making Factory",
    )

    insight = build_cfo_insight_pack(analysis, settore="manufacturing")

    assert insight["health_label"] == "Stabilization required"
    assert insight["primary_constraint"]["type"] == "profitability"
    assert insight["strategic_posture"] == "stabilize"
    assert insight["primary_constraint"]["risk_window"] == "0-90 days"
    assert "Restore positive net margin" in insight["next_best_move"]["move"]


def test_benchmark_gaps_are_sector_normalized():
    analysis = analyze_company(
        fatturato=1_000_000,
        costi_variabili=650_000,
        costi_fissi=250_000,
        investimenti=10_000,
        settore="retail",
        company_name="Retail Gap",
    )

    insight = build_cfo_insight_pack(analysis, settore="retail")
    gross_gap = next(
        gap for gap in insight["benchmark_gaps"] if gap["metric"] == "gross_margin_pct"
    )

    assert gross_gap["current_pct"] == 35.0
    assert gross_gap["median_pct"] == 35.0
    assert gross_gap["gap_to_median_points"] == 0.0
