"""
Unit tests for human value calculator module

Tests for:
- Total employee cost calculation
- ROI assumption correctness
- Payback period calculation
- Productivity requirements
- Hiring decision recommendations
"""

import pytest


class TestEmployeeCostCalculation:
    """Test total employee cost calculation."""
    
    def test_calculate_monthly_payroll(self, healthy_saas_company):
        """Should calculate monthly payroll correctly."""
        employee_count = 25
        monthly_salary_avg = 4_000
        
        monthly_payroll = employee_count * monthly_salary_avg
        assert monthly_payroll == 100_000
    
    def test_calculate_annual_payroll(self, healthy_saas_company):
        """Should calculate annual payroll correctly."""
        employee_count = 25
        monthly_salary_avg = 4_000
        
        annual_payroll = employee_count * monthly_salary_avg * 12
        assert annual_payroll == 1_200_000
    
    def test_include_benefits_and_taxes(self, healthy_saas_company):
        """Total cost should include benefits (~35-40% of salary)."""
        employee_count = 25
        monthly_salary_avg = 4_000
        
        monthly_salary = employee_count * monthly_salary_avg
        benefit_factor = 1.35  # 35% benefits/taxes/overhead
        total_monthly_cost = monthly_salary * benefit_factor
        
        assert total_monthly_cost > monthly_salary
        assert total_monthly_cost == monthly_salary * 1.35


class TestROIAssumption:
    """Test ROI calculation for hiring decisions."""
    
    def test_healthy_company_positive_roi(self, healthy_saas_company):
        """Healthy company should show positive ROI from new hires."""
        # Healthy company: can absorb new talent with profit
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        
        # Assume new hire generates 2.5x their cost
        employee_cost = 4_000 * 1.35
        employee_revenue_contribution = employee_cost * 2.5
        
        roi_percent = (employee_revenue_contribution - employee_cost) / employee_cost * 100
        
        assert roi_percent > 100  # Positive ROI
        assert roi_percent <= 300  # But realistic
    
    def test_struggling_company_lower_roi(self, struggling_company):
        """Struggling company should show lower ROI."""
        # Lower margins = lower productivity-per-employee
        employee_cost = 3_000 * 1.35  # Lower salary typical
        employee_revenue_contribution = employee_cost * 1.8  # Only 1.8x return
        
        roi_percent = (employee_revenue_contribution - employee_cost) / employee_cost * 100
        
        assert 0 < roi_percent < 150  # Lower but still positive
    
    def test_critical_company_breakeven_roi(self, loss_making_company):
        """Loss-making company may show breakeven or negative ROI."""
        employee_cost = 3_000 * 1.35
        # New hire barely covers cost
        employee_revenue_contribution = employee_cost * 1.1
        
        roi_percent = (employee_revenue_contribution - employee_cost) / employee_cost * 100
        
        assert roi_percent >= -20  # Could be slightly negative
        assert roi_percent <= 50


class TestPaybackPeriod:
    """Test payback period calculation."""
    
    def test_payback_months_healthy_company(self, healthy_saas_company):
        """Healthy company should have quick payback."""
        employee_cost = 4_000 * 1.35  # Monthly total cost
        monthly_productivity_value = employee_cost * 1.5  # Pays back 1.5x
        
        payback_months = employee_cost / (monthly_productivity_value - employee_cost)
        
        # Should payback in 2-4 months for healthy company
        assert payback_months >= 1
        assert payback_months <= 6
    
    def test_payback_months_struggling_company(self, struggling_company):
        """Struggling company should have longer payback."""
        employee_cost = 3_000 * 1.35
        monthly_productivity_value = employee_cost * 1.2  # Tighter margins
        
        payback_months = employee_cost / (monthly_productivity_value - employee_cost)
        
        # Should payback in 3-8 months
        assert payback_months >= 3
        assert payback_months <= 12
    
    def test_payback_never_negative(self, healthy_saas_company):
        """Payback months should never be negative."""
        employee_cost = 4_000 * 1.35
        monthly_productivity_value = employee_cost * 2.0
        
        payback_months = employee_cost / (monthly_productivity_value - employee_cost)
        
        assert payback_months > 0


class TestProductivityRequirement:
    """Test minimum productivity calculation."""
    
    def test_healthy_company_low_productivity_need(self, healthy_saas_company):
        """Healthy company requires modest productivity from new hires."""
        employee_cost = 4_000 * 1.35
        gross_profit_monthly = ((healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"]) / 12)
        
        # Need to generate 1.5x cost to be valuable
        min_productivity_pct = (employee_cost / gross_profit_monthly) * 100 * 1.5
        
        # Should be low (employee pays for themselves easily)
        assert min_productivity_pct < 50
    
    def test_struggling_company_high_productivity_need(self, struggling_company):
        """Struggling company needs high productivity from new hires."""
        employee_cost = 3_000 * 1.35
        gross_profit_monthly = ((struggling_company["fatturato"] - 
                        struggling_company["costi_variabili"]) / 12)
        
        # Higher threshold to justify hiring
        min_productivity_pct = (employee_cost / gross_profit_monthly) * 100 * 2.0
        
        # Should be high (harder to justify)
        assert min_productivity_pct > 50
        assert min_productivity_pct <= 200


@pytest.mark.negativity
class TestHumanValueEdgeCases:
    """Test edge cases in human value calculation."""
    
    def test_zero_employee_count(self):
        """Should handle zero employees gracefully."""
        employee_count = 0
        monthly_salary_avg = 4_000
        
        annual_cost = employee_count * monthly_salary_avg * 12
        assert annual_cost == 0
    
    def test_single_employee(self):
        """Should handle single employee company."""
        employee_count = 1
        monthly_salary_avg = 3_000
        
        annual_cost = employee_count * monthly_salary_avg * 12
        assert annual_cost == 36_000
    
    def test_very_high_employee_salary(self):
        """Should handle executive-level salaries."""
        employee_count = 1
        monthly_salary_avg = 50_000  # CEO/founder
        
        annual_cost = employee_count * monthly_salary_avg * 12
        assert annual_cost == 600_000
    
    def test_very_low_employee_salary(self):
        """Should handle junior/contract salaries."""
        employee_count = 10
        monthly_salary_avg = 1_500  # Interns/juniors
        
        annual_cost = employee_count * monthly_salary_avg * 12
        assert annual_cost == 180_000


class TestHiringScenarios:
    """Test decision recommendations for different hiring scenarios."""
    
    def test_boom_scenario_hire_recommendation(self, hiring_boom_scenario):
        """Hiring boom should recommend hiring."""
        gross_profit = (hiring_boom_scenario["fatturato"] - 
                        hiring_boom_scenario["costi_variabili"])
        employee_cost = hiring_boom_scenario["monthly_salary_avg"] * 1.35
        
        roi_percent = (gross_profit / hiring_boom_scenario["employee_count"]) / employee_cost * 100
        
        # Should be positive ROI
        assert roi_percent > 100
    
    def test_decline_scenario_caution_recommendation(self, hiring_decline_scenario):
        """Hiring decline should recommend caution."""
        gross_profit = (hiring_decline_scenario["fatturato"] - 
                        hiring_decline_scenario["costi_variabili"])
        current_employee_share = gross_profit / hiring_decline_scenario["employee_count"]
        
        # Revenue per employee is declining
        assert current_employee_share < 50_000  # Low per-employee contribution
    
    def test_stable_scenario_selective_hiring(self, stable_hiring_scenario):
        """Stable scenario should recommend selective hiring."""
        gross_profit = (stable_hiring_scenario["fatturato"] - 
                        stable_hiring_scenario["costi_variabili"])
        employee_cost = stable_hiring_scenario["monthly_salary_avg"] * 1.35
        
        # Moderate ROI, hire only for strategic needs
        roi_percent = (gross_profit / stable_hiring_scenario["employee_count"]) / employee_cost * 100
        
        assert roi_percent > 80  # Positive but not explosive


class TestRecommendationCoherence:
    """Test that final recommendations are coherent with data."""
    
    def test_recommendation_aligns_with_roi(self, healthy_saas_company):
        """Recommendation should match ROI profitability."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        employee_cost = 4_000 * 1.35
        
        roi = (gross_profit / healthy_saas_company.get("employee_count", 20)) / employee_cost * 100
        
        if roi > 150:
            recommendation = "Hire aggressively - strong ROI"
        elif roi > 80:
            recommendation = "Hire selectively for growth"
        else:
            recommendation = "Hold hiring - focus on efficiency"
        
        assert "Hire" in recommendation or "Hold" in recommendation
    
    def test_recommendation_addresses_constraints(self, loss_making_company):
        """Loss-making company should have hiring constraint in recommendation."""
        net_profit = (loss_making_company["fatturato"] - 
                      loss_making_company["costi_variabili"] - 
                      loss_making_company["costi_fissi"])
        
        if net_profit < 0:
            recommendation = "Do not hire - company is unprofitable"
        else:
            recommendation = "May hire for critical roles only"
        
        assert "not hire" in recommendation.lower() or "critical" in recommendation.lower()


@pytest.mark.negativity
class TestHumanValueCalculatorRobustness:
    """Test robustness of human value calculations."""
    
    def test_massive_employee_count(self):
        """Should handle large companies."""
        employee_count = 5_000
        monthly_salary_avg = 4_500
        
        annual_cost = employee_count * monthly_salary_avg * 12
        assert annual_cost == 270_000_000  # €270M
    
    def test_mixed_salary_distribution(self):
        """Should handle companies with mixed salary levels."""
        # Average of different salary bands
        salaries = [
            ("Senior", 15, 8_000),
            ("Mid-level", 40, 5_000),
            ("Junior", 45, 2_500),
        ]
        
        total_annual = sum(count * salary * 12 for _, count, salary in salaries)
        assert total_annual > 0
        
        total_count = sum(count for _, count, _ in salaries)
        avg_salary = total_annual / total_count / 12
        
        assert 2_000 < avg_salary < 8_000
