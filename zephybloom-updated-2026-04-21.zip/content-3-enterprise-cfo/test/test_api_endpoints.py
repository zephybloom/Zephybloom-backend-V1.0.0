"""
API endpoint integration tests

Tests for:
- /health endpoint
- /cfo/analyze endpoint
- /cfo/simulate endpoint
- Error handling (422, 500)
"""

import pytest
from fastapi.testclient import TestClient
from api.main import app
from test.conftest import assert_valid_kpi_snapshot, assert_valid_recommendations


@pytest.fixture
def client(authenticated_client):
    """FastAPI test client with authentication."""
    return authenticated_client



class TestHealthEndpoint:
    """Test /health endpoint."""
    
    def test_health_endpoint_status_200(self, client):
        """Should return 200 OK."""
        response = client.get("/health")
        assert response.status_code == 200
    
    def test_health_endpoint_response_format(self, client):
        """Should return valid health response."""
        response = client.get("/health")
        data = response.json()
        
        assert "status" in data
        assert data["status"] in ["healthy", "degraded", "unhealthy"]


class TestCFOAIAnalyzeEndpoint:
    """Test /cfo/ai-analyze endpoint guardrails."""

    def test_ai_analyze_returns_industry_insight_and_validation(self, client, loss_making_company):
        """AI analysis should expose deterministic insight and answer validation."""
        response = client.post(
            "/cfo/ai-analyze?use_mock=true",
            json=loss_making_company,
        )

        assert response.status_code == 200
        body = response.json()

        assert body["status"] == "success"
        assert body["industry_insight"]["primary_constraint"]["type"] == "profitability"
        assert "data_readiness" in body
        assert "answer_precision_pct" in body["data_readiness"]
        assert body["answer_validation"]["response_source"] in {"ai", "deterministic_fallback"}
        assert "is_valid" in body["answer_validation"]
        assert body["ai_response"]["priority_action"]


class TestCFOUnitEconomicsEndpoint:
    """Test premium granular unit economics endpoint."""

    def test_unit_economics_endpoint_returns_product_and_customer_rankings(self, client):
        response = client.post(
            "/cfo/unit-economics",
            json={
                "rows": [
                    {
                        "customer": "Cliente A",
                        "product": "Premium Pack",
                        "supplier": "Supplier 1",
                        "quantity": 10,
                        "unit_price": 500,
                        "purchase_price": 180,
                    },
                    {
                        "customer": "Cliente B",
                        "product": "Low Margin Pack",
                        "supplier": "Supplier 2",
                        "quantity": 20,
                        "unit_price": 100,
                        "purchase_price": 85,
                    },
                ]
            },
        )

        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "success"
        assert body["premium_outputs"]["can_answer_product_margin"] is True
        assert body["unit_economics"]["top_products_by_margin"][0]["product"] == "Premium Pack"


class TestCFODataRequirementsEndpoint:
    """Test sector-specific data readiness endpoint."""

    def test_data_requirements_endpoint_returns_restaurant_questions(self, client):
        response = client.post(
            "/cfo/data-requirements",
            json={
                "sector": "restaurant",
                "provided_data": {
                    "annual_revenue": 900000,
                    "variable_costs": 360000,
                    "fixed_costs": 260000,
                    "invested_capital": 100000,
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        readiness = body["data_readiness"]
        missing_keys = {field["key"] for field in readiness["missing_required"]}

        assert body["status"] == "success"
        assert body["premium_outputs"]["prevents_random_answers"] is True
        assert readiness["sector"] == "restaurant"
        assert "ingredient_costs" in missing_keys
        assert "recipe_quantities" in missing_keys
        assert readiness["next_questions"]


class TestCFOWarRoomEndpoint:
    """Test unified CFO War Room endpoint."""

    def test_war_room_aggregates_vertical_decisions(self, client):
        from core.decision_memory import clear_decision_memory

        clear_decision_memory()
        response = client.post(
            "/cfo/war-room",
            json={
                "active_sector": "construction",
                "operational_data_by_sector": {
                    "restaurant": {
                        "annual_revenue": 900000,
                        "variable_costs": 300000,
                        "fixed_costs": 180000,
                        "invested_capital": 120000,
                        "opening_days_per_month": 25,
                        "average_daily_covers": 90,
                        "average_ticket": 36,
                        "target_food_cost_pct": 30,
                        "ingredient_costs": {"mozzarella": 0.006},
                        "menu_items": [
                            {
                                "name": "Margherita",
                                "price": 9,
                                "monthly_units": 1200,
                                "recipe": [{"ingredient": "mozzarella", "quantity": 120}],
                            }
                        ],
                        "staff_roles": [{"role": "Cuoco", "count": 2, "monthly_cost": 2400}],
                    },
                    "construction": {
                        "fixed_costs": 80000,
                        "invested_capital": 120000,
                        "projects": [
                            {
                                "project": "Cantiere A",
                                "contract_value": 240000,
                                "materials_cost": 82000,
                                "labor_cost": 46000,
                                "subcontractor_cost": 28000,
                                "other_cost": 10000,
                                "progress_pct": 65,
                                "billed_pct": 45,
                                "collected_pct": 25,
                            }
                        ],
                    },
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        war_room = body["war_room"]

        assert body["status"] == "success"
        assert body["premium_outputs"]["cross_sector_prioritization"] is True
        assert body["premium_outputs"]["execution_playbook"] is True
        assert body["decision_memory"]["remembered_count"] >= 1
        assert body["decision_memory"]["summary"]["open_decisions"] >= 1
        assert war_room["version"] == "unified-cfo-war-room-v2"
        assert war_room["sector_count"] == 2
        assert war_room["priority_decision"]["decision"]
        assert war_room["priority_decision"]["board_instruction"]
        assert war_room["priority_decision"]["execution_plan"]["this_week"]
        assert war_room["priority_decision"]["execution_plan"]["kpis"]
        assert war_room["executive_summary"]["headline"]
        assert war_room["executive_summary"]["do_now"]
        assert war_room["executive_summary"]["do_not_do"]
        assert war_room["decision_queue"]
        assert war_room["decision_queue"][0]["decision_id"].startswith("wr-")
        assert war_room["decision_queue"][0]["next_action"]
        assert war_room["decision_queue"][0]["success_metric"]["kpi"]
        assert war_room["decision_queue"][0]["evidence_needed"]
        assert war_room["weekly_agenda"]
        assert war_room["weekly_agenda"][0]["decision_id"].startswith("wr-")
        assert war_room["weekly_agenda"][0]["owner"]
        assert war_room["execution_tracker"]
        assert war_room["execution_tracker"][0]["status"] == "todo"
        assert war_room["execution_tracker"][0]["follow_up_question"]
        assert war_room["stop_go_board"]
        assert war_room["portfolio_summary"]["readiness_avg_pct"] > 0
        assert {card["sector"] for card in war_room["sector_cards"]} == {"restaurant", "construction"}
        assert all("playbook" in card for card in war_room["sector_cards"])
        assert all("go_no_go" in card for card in war_room["sector_cards"])

    def test_war_room_includes_previous_decision_memory_context(self, client):
        from core.decision_memory import clear_decision_memory
        from db.session import get_session_sync

        db = get_session_sync()
        try:
            clear_decision_memory(session=db)
        finally:
            db.close()
        payload = {
            "active_sector": "construction",
            "operational_data_by_sector": {
                "construction": {
                    "fixed_costs": 80000,
                    "invested_capital": 120000,
                    "projects": [
                        {
                            "project": "Cantiere A",
                            "contract_value": 240000,
                            "materials_cost": 82000,
                            "labor_cost": 46000,
                            "subcontractor_cost": 28000,
                            "other_cost": 10000,
                            "progress_pct": 65,
                            "billed_pct": 45,
                            "collected_pct": 25,
                        }
                    ],
                }
            },
        }
        first = client.post("/cfo/war-room", json=payload)
        decision_id = first.json()["war_room"]["execution_tracker"][0]["decision_id"]
        feedback = client.post(
            f"/cfo/decision/{decision_id}/feedback",
            json={"was_implemented": True, "actual_impact_eur": 30000, "expected_impact_eur": 25000},
        )
        assert feedback.status_code == 200

        second = client.post("/cfo/war-room", json=payload)
        assert second.status_code == 200
        memory_context = second.json()["war_room"]["memory_context"]

        assert memory_context["summary"]["completed_decisions"] >= 1
        assert memory_context["best_decision"]["decision_id"] == decision_id
        assert decision_id in memory_context["recommended_memory_action"]
        assert "quality" in memory_context
        assert "status" in memory_context["quality"]
        assert "Replica" in second.json()["war_room"]["executive_summary"]["diagnosis"]


class TestCFOWarRoomFeedbackEndpoint:
    """Test War Room decision outcome feedback."""

    def test_war_room_decision_feedback_records_learning_context(self, client):
        from core.decision_memory import clear_decision_memory
        from core.learning_engine import LearningEngine, set_learning_engine

        clear_decision_memory()
        set_learning_engine(LearningEngine())
        war_room_response = client.post(
            "/cfo/war-room",
            json={
                "active_sector": "construction",
                "operational_data_by_sector": {
                    "construction": {
                        "fixed_costs": 80000,
                        "invested_capital": 120000,
                        "projects": [
                            {
                                "project": "Cantiere A",
                                "contract_value": 240000,
                                "materials_cost": 82000,
                                "labor_cost": 46000,
                                "subcontractor_cost": 28000,
                                "other_cost": 10000,
                                "progress_pct": 65,
                                "billed_pct": 45,
                                "collected_pct": 25,
                            }
                        ],
                    }
                },
            },
        )
        decision_id = war_room_response.json()["war_room"]["execution_tracker"][0]["decision_id"]

        response = client.post(
            f"/cfo/decision/{decision_id}/feedback",
            json={
                "was_implemented": True,
                "actual_impact_eur": 22000,
                "expected_impact_eur": 25000,
                "lessons_learned": "SAL incassato più velocemente del previsto",
            },
        )

        assert response.status_code == 200
        body = response.json()
        context = body["accuracy_report"]["decision_context"]

        assert body["status"] == "success"
        assert context["source"] == "war_room"
        assert context["sector"] == "construction"
        assert context["decision_type"] in {"cashrecovery", "cash-recovery", "datablocker", "data-blocker"}
        assert body["accuracy_report"]["actual_impact_eur"] == 22000
        assert body["accuracy_report"]["outcome_review"]["status"] == "near_target"
        assert body["accuracy_report"]["outcome_review"]["variance_pct"] == -12.0
        assert body["accuracy_report"]["memory_record"]["status"] == "done"

        memory = client.get("/cfo/memory/decisions")
        assert memory.status_code == 200
        memory_body = memory.json()
        assert memory_body["summary"]["completed_decisions"] >= 1
        assert any(item["decision_id"] == decision_id for item in memory_body["decisions"])

        detail = client.get(f"/cfo/memory/decisions/{decision_id}")
        assert detail.status_code == 200
        assert detail.json()["decision"]["actual_impact_eur"] == 22000

    def test_feedback_requires_actual_impact_when_implemented(self, client):
        response = client.post(
            "/cfo/decision/wr-01-restaurant-marginrecovery/feedback",
            json={"was_implemented": True},
        )

        assert response.status_code == 422

    def test_memory_decision_status_endpoint_archives_decision(self, client):
        war_room_response = client.post(
            "/cfo/war-room",
            json={
                "active_sector": "construction",
                "operational_data_by_sector": {
                    "construction": {
                        "fixed_costs": 80000,
                        "invested_capital": 120000,
                        "projects": [
                            {
                                "project": "Cantiere B",
                                "contract_value": 240000,
                                "materials_cost": 82000,
                                "labor_cost": 46000,
                                "subcontractor_cost": 28000,
                                "other_cost": 10000,
                                "progress_pct": 65,
                                "billed_pct": 45,
                                "collected_pct": 25,
                            }
                        ],
                    }
                },
            },
        )
        decision_id = war_room_response.json()["war_room"]["execution_tracker"][0]["decision_id"]

        response = client.patch(
            f"/cfo/memory/decisions/{decision_id}",
            json={"status": "archived", "reason": "Non più prioritaria"},
        )

        assert response.status_code == 200
        body = response.json()
        assert body["decision"]["status"] == "archived"
        assert body["summary"]["archived_decisions"] >= 1
        assert body["premium_outputs"]["decision_lifecycle"] is True


class TestCFOOperatingModelEndpoint:
    """Test normalized Company Operating Model endpoint."""

    def test_operating_model_endpoint_returns_data_roadmap(self, client):
        response = client.post(
            "/cfo/operating-model",
            json={
                "active_sector": "restaurant",
                "company_data": {
                    "company_name": "Risto Test",
                    "fatturato": 900000,
                    "costi_variabili": 300000,
                    "costi_fissi": 180000,
                    "investimenti": 120000,
                    "settore": "restaurant",
                },
                "operational_data_by_sector": {
                    "restaurant": {
                        "annual_revenue": 900000,
                        "variable_costs": 300000,
                        "fixed_costs": 180000,
                        "invested_capital": 120000,
                        "opening_days_per_month": 25,
                    }
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        model = body["operating_model"]

        assert body["status"] == "success"
        assert body["premium_outputs"]["ready_for_chat_context"] is True
        assert model["version"] == "company-operating-model-v1"
        assert model["active_sector"] == "restaurant"
        assert model["overall_readiness_pct"] > 0
        assert model["next_questions"]


class TestCFODataRoomEndpoint:
    """Test Company Data Room endpoint."""

    def test_data_room_endpoint_returns_cfo_gap_roadmap(self, client):
        response = client.post(
            "/cfo/data-room",
            json={
                "active_sector": "restaurant",
                "company_data": {
                    "company_name": "Risto Test",
                    "fatturato": 900000,
                    "costi_variabili": 300000,
                    "costi_fissi": 180000,
                    "investimenti": 120000,
                    "settore": "restaurant",
                },
                "operational_data_by_sector": {
                    "restaurant": {
                        "annual_revenue": 900000,
                        "average_ticket": 36,
                    }
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        data_room = body["data_room"]

        assert body["premium_outputs"]["structured_company_memory"] is True
        assert data_room["version"] == "company-data-room-v1"
        assert data_room["active_sector"] == "restaurant"
        assert data_room["areas"]
        assert data_room["priority_gaps"]
        assert data_room["next_questions"]
        assert data_room["guided_collection"]["first_step"]
        assert data_room["guided_collection"]["first_step"]["fields"]
        assert "menu_items" in data_room["sector_entities"]["missing_entities"]

    def test_data_room_can_be_saved_and_reloaded(self, client):
        save_response = client.post(
            "/cfo/data-room",
            json={
                "company_id": "persist-shop",
                "save": True,
                "active_sector": "ecommerce",
                "company_data": {
                    "company_name": "Persist Shop",
                    "fatturato": 600000,
                    "costi_variabili": 250000,
                    "costi_fissi": 90000,
                    "investimenti": 80000,
                    "settore": "ecommerce",
                },
                "operational_data_by_sector": {
                    "ecommerce": {
                        "sku_sales": [
                            {"sku": "Hero", "price": 75, "purchase_cost": 24, "monthly_units": 500}
                        ]
                    }
                },
            },
        )

        assert save_response.status_code == 200
        assert save_response.json()["saved"] is True

        get_response = client.get("/cfo/data-room", params={"company_id": "persist-shop"})

        assert get_response.status_code == 200
        body = get_response.json()
        assert body["snapshot"]["company_id"] == "persist-shop"
        assert body["snapshot"]["operational_data_by_sector"]["ecommerce"]["sku_sales"][0]["sku"] == "Hero"
        assert body["data_room"]["active_sector"] == "ecommerce"

    def test_data_room_import_rows_and_chat_uses_saved_snapshot(self, client):
        import_response = client.post(
            "/cfo/data-room/import",
            json={
                "company_id": "Saved Shop",
                "company_name": "Saved Shop",
                "active_sector": "ecommerce",
                "entity": "sku_sales",
                "rows": [
                    {"sku": "Saved Hero", "price": 100, "purchase_cost": 30, "shipping_cost": 10, "monthly_units": 300},
                    {"sku": "Saved Low", "price": 60, "purchase_cost": 45, "shipping_cost": 5, "monthly_units": 80},
                ],
            },
        )

        assert import_response.status_code == 200
        assert import_response.json()["imported"]["row_count"] == 2

        chat_response = client.post("/cfo/chat", json={
            "message": "quale prodotto devo spingere?",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Saved Shop",
            },
            "chat_history": [],
        })

        assert chat_response.status_code == 200
        body = chat_response.json()
        assert "Data Room CFO - prodotti da spingere" in body["response"]
        assert "Saved Hero" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"

    def test_data_room_context_returns_saved_readiness(self, client):
        client.post(
            "/cfo/data-room/import",
            json={
                "company_id": "Context Shop",
                "company_name": "Context Shop",
                "active_sector": "ecommerce",
                "entity": "sales_channels",
                "rows": [
                    {"channel": "Email", "revenue": 60000, "cost": 3000, "margin_pct": 55},
                ],
            },
        )

        response = client.get("/cfo/data-room/context", params={"company_id": "Context Shop"})

        assert response.status_code == 200
        body = response.json()
        assert body["has_saved_data_room"] is True
        assert body["context"]["active_sector"] == "ecommerce"
        assert body["context"]["available_sectors"] == ["ecommerce"]
        assert body["premium_outputs"]["chat_context_ready"] is True

    def test_war_room_uses_saved_data_room_when_request_has_no_operational_data(self, client):
        client.post(
            "/cfo/data-room/import",
            json={
                "company_id": "War Shop",
                "company_name": "War Shop",
                "active_sector": "ecommerce",
                "entity": "sku_sales",
                "rows": [
                    {"sku": "War Hero", "price": 100, "purchase_cost": 30, "shipping_cost": 10, "monthly_units": 300},
                ],
            },
        )

        response = client.post("/cfo/war-room", json={
            "company_id": "War Shop",
            "active_sector": "ecommerce",
            "operational_data_by_sector": {},
        })

        assert response.status_code == 200
        body = response.json()
        assert body["data_room_context"]["loaded_saved_snapshot"] is True
        assert body["data_room_context"]["sector_count"] == 1
        assert body["war_room"]["sector_count"] >= 1
        assert body["war_room"]["decision_queue"]

    def test_monthly_report_uses_saved_data_room_company_data(self, client):
        client.post(
            "/cfo/data-room",
            json={
                "company_id": "Report Shop",
                "save": True,
                "active_sector": "ecommerce",
                "company_data": {
                    "company_name": "Report Shop",
                    "fatturato": 600000,
                    "costi_variabili": 250000,
                    "costi_fissi": 90000,
                    "investimenti": 80000,
                    "settore": "ecommerce",
                },
                "operational_data_by_sector": {
                    "ecommerce": {
                        "sku_sales": [
                            {"sku": "Report Hero", "price": 75, "purchase_cost": 24, "monthly_units": 500}
                        ]
                    }
                },
            },
        )

        response = client.post("/cfo/report/monthly", json={
            "company_id": "Report Shop",
            "company_name": "Report Shop",
            "company_data": {},
            "operational_data_by_sector": {},
        })

        assert response.status_code == 200
        body = response.json()
        assert body["data_room_context"]["loaded_saved_snapshot"] is True
        assert body["report"]["sections"]["financial_snapshot"]["revenue_eur"] == 600000

    def test_data_room_history_tracks_snapshot_deltas(self, client):
        client.post(
            "/cfo/data-room/import",
            json={
                "company_id": "History Shop",
                "company_name": "History Shop",
                "active_sector": "ecommerce",
                "entity": "sku_sales",
                "rows": [
                    {"sku": "One", "price": 100, "purchase_cost": 40, "monthly_units": 10},
                ],
            },
        )
        client.post(
            "/cfo/data-room/import",
            json={
                "company_id": "History Shop",
                "company_name": "History Shop",
                "active_sector": "ecommerce",
                "entity": "sku_sales",
                "rows": [
                    {"sku": "One", "price": 100, "purchase_cost": 40, "monthly_units": 10},
                    {"sku": "Two", "price": 80, "purchase_cost": 30, "monthly_units": 20},
                ],
            },
        )

        response = client.get("/cfo/data-room/history", params={"company_id": "History Shop"})

        assert response.status_code == 200
        body = response.json()
        summary = body["history_summary"]
        assert summary["has_history"] is True
        assert summary["snapshot_count"] >= 2
        assert summary["delta"]["row_count"] == 1
        assert body["premium_outputs"]["readiness_delta"] is True

    def test_answer_quality_endpoint_flags_ungrounded_operational_claim(self, client):
        response = client.post("/cfo/answer-quality", json={
            "question": "quale prodotto devo spingere?",
            "response": "Il prodotto Hero è sicuramente il migliore da spingere.",
            "intent": "manual_review",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "settore": "ecommerce",
            },
            "operational_data_by_sector": {},
            "active_sector": "ecommerce",
        })

        assert response.status_code == 200
        body = response.json()
        assert body["answer_quality"]["policy"] == "needs_review"
        assert body["premium_outputs"]["anti_random_answer_guardrail"] is True


class TestCFOMemoryEndpoint:
    """Test monthly CFO memory and chat recall."""

    def test_memory_snapshot_summary_and_chat_recall(self, client):
        company_id = "MemoryCo"
        jan = client.post("/cfo/memory/snapshot", json={
            "company_id": company_id,
            "company_name": company_id,
            "measurement_date": "2026-01-15T00:00:00",
            "industry": "restaurant",
            "metrics": {
                "fatturato": 100000,
                "costi_variabili": 45000,
                "costi_fissi": 25000,
                "investimenti": 50000,
            },
        })
        feb = client.post("/cfo/memory/snapshot", json={
            "company_id": company_id,
            "company_name": company_id,
            "measurement_date": "2026-02-15T00:00:00",
            "industry": "restaurant",
            "metrics": {
                "fatturato": 115000,
                "costi_variabili": 58000,
                "costi_fissi": 27000,
                "investimenti": 50000,
            },
        })

        assert jan.status_code == 200
        assert feb.status_code == 200
        assert feb.json()["premium_outputs"]["trend_ready"] is True

        summary = client.get(f"/cfo/memory/summary?company_id={company_id}")
        assert summary.status_code == 200
        body = summary.json()["memory_summary"]
        assert body["has_memory"] is True
        assert len(body["periods"]) >= 2
        assert "MemoryCo" in body["executive_memory"]
        assert body["next_memory_actions"]

        chat = client.post("/cfo/chat", json={
            "message": "sto migliorando rispetto al mese scorso?",
            "company_data": {
                "fatturato": 115000,
                "costi_variabili": 58000,
                "costi_fissi": 27000,
                "investimenti": 50000,
                "settore": "restaurant",
                "company_name": company_id,
            },
            "chat_history": [],
        })
        assert chat.status_code == 200
        assert "Memoria CFO" in chat.json()["response"]
        assert "Momentum" in chat.json()["response"]


class TestCFOReportEndpoint:
    """Test monthly CFO report endpoint."""

    def test_monthly_report_endpoint_returns_board_ready_report(self, client):
        response = client.post("/cfo/report/monthly", json={
            "company_id": "ReportCo",
            "company_name": "ReportCo",
            "period": "2026-04",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "construction",
            },
            "operational_data_by_sector": {
                "construction": {
                    "fixed_costs": 80000,
                    "invested_capital": 120000,
                    "projects": [
                        {
                            "project": "Cantiere A",
                            "contract_value": 240000,
                            "materials_cost": 82000,
                            "labor_cost": 46000,
                            "subcontractor_cost": 28000,
                            "other_cost": 10000,
                            "progress_pct": 65,
                            "billed_pct": 45,
                            "collected_pct": 25,
                        }
                    ],
                }
            },
        })

        assert response.status_code == 200
        body = response.json()
        report = body["report"]

        assert body["premium_outputs"]["board_ready_report"] is True
        assert report["version"] == "monthly-cfo-report-v1"
        assert report["sections"]["executive_summary"]["headline"]
        assert report["sections"]["financial_snapshot"]["net_profit_eur"] == 300000
        assert report["sections"]["war_room"]["priority_decision"]["decision"]
        assert report["sections"]["ceo_brief"]["action_7_days"]
        assert report["sections"]["finance_brief"]["kpi_watchlist"]
        assert report["sections"]["board_decisions"]
        assert report["sections"]["team_questions"]
        assert report["sections"]["next_30_days"]
        assert "Report CFO Mensile" in report["markdown"]
        assert "Decisioni da board" in report["markdown"]

    def test_monthly_report_pdf_endpoint_returns_pdf(self, client):
        response = client.post("/cfo/report/monthly/pdf", json={
            "company_id": "ReportCo",
            "company_name": "ReportCo",
            "period": "2026-04",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "construction",
            },
            "operational_data_by_sector": {},
        })

        assert response.status_code == 200
        assert response.headers["content-type"] == "application/pdf"
        assert response.headers["x-cfo-report-version"] == "monthly-cfo-report-v1"
        assert response.content.startswith(b"%PDF-1.4")
        assert b"%%EOF" in response.content
        assert b"Scorecard finanziaria" in response.content
        assert b"Decisioni da board" in response.content
        assert b"Domande CFO al team" in response.content


class TestCFODecisionPlaybookEndpoint:
    """Test CFO Decision Playbook endpoint."""

    def test_decision_playbook_endpoint_returns_30_60_90_plan(self, client):
        response = client.post(
            "/cfo/decision-playbook",
            json={
                "active_sector": "restaurant",
                "question": "come posso aumentare il margine?",
                "company_data": {
                    "company_name": "Risto Test",
                    "fatturato": 900000,
                    "costi_variabili": 330000,
                    "costi_fissi": 210000,
                    "investimenti": 120000,
                    "settore": "restaurant",
                },
                "operational_data_by_sector": {
                    "restaurant": {
                        "annual_revenue": 900000,
                        "variable_costs": 330000,
                        "fixed_costs": 210000,
                        "invested_capital": 120000,
                        "opening_days_per_month": 25,
                        "average_daily_covers": 90,
                        "average_ticket": 36,
                        "ingredient_costs": {"mozzarella": 0.006},
                        "menu_items": [
                            {
                                "name": "Margherita",
                                "price": 9,
                                "monthly_units": 1200,
                                "recipe": [{"ingredient": "mozzarella", "quantity": 120}],
                            }
                        ],
                    }
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        decision = body["playbook"]["decision"]

        assert body["status"] == "success"
        assert body["premium_outputs"]["actions_30_60_90"] is True
        assert decision["actions"]["30_days"]
        assert decision["kpis_to_monitor"]
        assert decision["recommended_simulation"]


class TestCFORestaurantAnalysisEndpoint:
    """Test restaurant-specific CFO calculator."""

    def _restaurant_payload(self):
        return {
            "annual_revenue": 900000,
            "variable_costs": 300000,
            "fixed_costs": 180000,
            "invested_capital": 120000,
            "opening_days_per_month": 25,
            "average_daily_covers": 90,
            "average_ticket": 36,
            "target_food_cost_pct": 30,
            "ingredient_costs": {
                "mozzarella": 0.006,
                "farina": 0.001,
                "pomodoro": 0.003,
            },
            "menu_items": [
                {
                    "name": "Margherita",
                    "price": 9,
                    "monthly_units": 1200,
                    "recipe": [
                        {"ingredient": "mozzarella", "quantity": 120},
                        {"ingredient": "farina", "quantity": 180},
                        {"ingredient": "pomodoro", "quantity": 80},
                    ],
                }
            ],
            "staff_roles": [
                {"role": "Cuoco", "count": 2, "monthly_cost": 2400},
                {"role": "Sala", "count": 3, "monthly_cost": 1600},
            ],
        }

    def test_restaurant_endpoint_returns_food_cost_and_target_price(self, client):
        response = client.post("/cfo/restaurant/analyze", json={"data": self._restaurant_payload()})

        assert response.status_code == 200
        body = response.json()
        dish = body["restaurant_analysis"]["top_dishes_by_profit"][0]

        assert body["premium_outputs"]["calculates_food_cost"] is True
        assert dish["name"] == "Margherita"
        assert dish["recommended_price_for_target_margin_eur"] == 3.8

    def test_restaurant_simulation_endpoint_returns_delta_and_decision(self, client):
        response = client.post(
            "/cfo/restaurant/simulate",
            json={
                "data": self._restaurant_payload(),
                "scenario": {
                    "name": "Prezzo e coperti",
                    "price_delta_pct": 5,
                    "covers_delta_pct": 10,
                    "ingredient_cost_delta_pct": -3,
                },
            },
        )

        assert response.status_code == 200
        body = response.json()
        simulation = body["restaurant_simulation"]

        assert body["premium_outputs"]["returns_go_no_go_decision"] is True
        assert simulation["delta"]["net_profit_eur"] > 0
        assert simulation["decision"].startswith(("GO", "TEST", "CAUTION"))

    def test_chat_returns_restaurant_calculation_when_operational_data_exists(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quali piatti del menu hanno più margine?",
            "company_data": {
                "fatturato": 900000,
                "costi_variabili": 300000,
                "costi_fissi": 180000,
                "investimenti": 120000,
                "settore": "restaurant",
                "company_name": "Risto Test",
            },
            "operational_data": self._restaurant_payload(),
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Analisi ristorante" in body["response"]
        assert "Margherita" in body["response"]
        assert "Break-even" in body["response"]

    def test_chat_runs_restaurant_scenario_from_natural_language(self, client):
        response = client.post("/cfo/chat", json={
            "message": "se aumento i prezzi del 5% e i coperti del 10% cosa succede?",
            "company_data": {
                "fatturato": 900000,
                "costi_variabili": 300000,
                "costi_fissi": 180000,
                "investimenti": 120000,
                "settore": "restaurant",
                "company_name": "Risto Test",
            },
            "operational_data": self._restaurant_payload(),
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Simulazione CFO" in body["response"]
        assert "Delta utile annuo" in body["response"]
        assert "Decisione CFO" in body["response"]


class TestCFOEcommerceAnalysisEndpoint:
    """Test ecommerce-specific CFO calculator."""

    def _ecommerce_payload(self):
        return {
            "annual_revenue": 600000,
            "fixed_costs": 90000,
            "invested_capital": 80000,
            "average_order_value": 75,
            "monthly_orders": 800,
            "customer_acquisition_cost": 18,
            "monthly_ad_spend": 12000,
            "payment_fees_pct": 2,
            "return_rate_pct": 5,
            "sku_sales": [
                {
                    "sku": "Hero Product",
                    "price": 75,
                    "purchase_cost": 24,
                    "shipping_cost": 7,
                    "monthly_units": 500,
                },
                {
                    "sku": "Low Margin Product",
                    "price": 40,
                    "purchase_cost": 31,
                    "shipping_cost": 6,
                    "monthly_units": 300,
                },
            ],
        }

    def test_ecommerce_endpoint_returns_sku_margin_and_cac(self, client):
        response = client.post("/cfo/ecommerce/analyze", json={"data": self._ecommerce_payload()})

        assert response.status_code == 200
        body = response.json()
        analysis = body["ecommerce_analysis"]

        assert body["premium_outputs"]["calculates_break_even_cac"] is True
        assert analysis["top_skus_by_profit"][0]["sku"] == "Hero Product"
        assert analysis["skus_to_fix"][0]["sku"] == "Low Margin Product"

    def test_ecommerce_simulation_endpoint_returns_delta_and_decision(self, client):
        response = client.post("/cfo/ecommerce/simulate", json={
            "data": self._ecommerce_payload(),
            "scenario": {"price_delta_pct": 5, "volume_delta_pct": 10, "return_rate_delta_pct": -1},
        })

        assert response.status_code == 200
        body = response.json()
        simulation = body["ecommerce_simulation"]

        assert body["premium_outputs"]["returns_go_no_go_decision"] is True
        assert simulation["delta"]["net_profit_eur"] > 0
        assert simulation["decision"].startswith(("GO", "TEST", "CAUTION"))

    def test_chat_runs_ecommerce_scenario_from_natural_language(self, client):
        response = client.post("/cfo/chat", json={
            "message": "se aumento i prezzi del 5% e gli ordini del 10% cosa succede?",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Shop Test",
            },
            "operational_data": self._ecommerce_payload(),
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Simulazione Ecommerce CFO" in body["response"]
        assert "Delta utile annuo" in body["response"]
        assert "Decisione CFO" in body["response"]


class TestCFOConstructionAnalysisEndpoint:
    """Test construction-specific CFO calculator."""

    def _construction_payload(self):
        return {
            "fixed_costs": 80000,
            "invested_capital": 120000,
            "projects": [
                {
                    "project": "Cantiere A",
                    "contract_value": 240000,
                    "materials_cost": 82000,
                    "labor_cost": 46000,
                    "subcontractor_cost": 28000,
                    "other_cost": 10000,
                    "progress_pct": 65,
                    "billed_pct": 45,
                    "collected_pct": 25,
                    "delay_weeks": 2,
                    "penalty_pct_per_week": 0.5,
                }
            ],
        }

    def test_construction_endpoint_returns_project_cash_gap_and_wip(self, client):
        response = client.post("/cfo/construction/analyze", json={"data": self._construction_payload()})

        assert response.status_code == 200
        body = response.json()
        analysis = body["construction_analysis"]

        assert body["premium_outputs"]["calculates_cash_gap"] is True
        assert analysis["summary"]["cash_gap_eur"] > 0
        assert analysis["summary"]["wip_unbilled_eur"] > 0
        assert analysis["projects_by_cash_risk"][0]["project"] == "Cantiere A"

    def test_construction_simulation_endpoint_returns_cash_gap_delta(self, client):
        response = client.post("/cfo/construction/simulate", json={
            "data": self._construction_payload(),
            "scenario": {"collected_delta_pct": 20, "billed_delta_pct": 15},
        })

        assert response.status_code == 200
        body = response.json()
        simulation = body["construction_simulation"]

        assert body["premium_outputs"]["calculates_cash_gap_delta"] is True
        assert simulation["delta"]["cash_gap_eur"] < 0
        assert simulation["decision"].startswith(("GO", "TEST", "CASH"))

    def test_chat_runs_construction_scenario_from_natural_language(self, client):
        response = client.post("/cfo/chat", json={
            "message": "se i materiali aumentano del 10% e incasso il SAL del 15% cosa succede?",
            "company_data": {
                "fatturato": 240000,
                "costi_variabili": 166000,
                "costi_fissi": 80000,
                "investimenti": 120000,
                "settore": "construction",
                "company_name": "Build Test",
            },
            "operational_data": self._construction_payload(),
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Simulazione Construction CFO" in body["response"]
        assert "Delta cash gap" in body["response"]
        assert "Decisione CFO" in body["response"]


class TestCFOChatControlledResponses:
    """Test FAQ-aware and deterministic chat responses."""

    def _chat(self, client, message):
        return client.post("/cfo/chat", json={
            "message": message,
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "saas",
                "company_name": "ChatCo",
            },
            "chat_history": [],
        })

    def test_chat_uses_faq_for_roi_definition(self, client):
        response = self._chat(client, "cosa è il roi?")

        assert response.status_code == 200
        body = response.json()
        assert "ROI = Utile / Investimenti" in body["response"]
        assert "ridurre costi fissi" not in body["response"].lower()

    def test_chat_short_profit_uses_profit_kpi_not_ebitda_faq(self, client):
        response = self._chat(client, "utile")

        assert response.status_code == 200
        body = response.json()
        assert "Utile netto" in body["response"]
        assert "EBITDA =" not in body["response"]
        assert "Cosa farei adesso" in body["response"]

    def test_chat_sales_improvement_returns_strategy_not_zero_simulation(self, client):
        response = self._chat(client, "come posso migliorare le vendite")

        assert response.status_code == 200
        body = response.json()
        assert "io non inseguirei volume generico" in body["response"].lower()
        assert "+0.0%" not in body["response"]
        assert "EUR +0" not in body["response"]

    def test_chat_weakness_synonym_punti_carenti(self, client):
        response = self._chat(client, "quali sono i miei punti carenti")

        assert response.status_code == 200
        body = response.json()
        assert "quadro che vedo" in body["response"].lower()
        assert "Non ho capito" not in body["response"]

    def test_chat_where_can_i_improve_returns_real_diagnosis(self, client):
        response = self._chat(client, "dove posso migliorare")

        assert response.status_code == 200
        body = response.json()
        assert "Dove migliorare" in body["response"]
        assert "**Prossimi passi:**" not in body["response"]

    def test_chat_confirms_data_collection_block_instead_of_misrouting(self, client):
        response = client.post("/cfo/chat", json={
            "message": "Per canali vendita mi servono: sales_channels, average_ticket, average_order_value. Mi servono per distinguere crescita sana da fatturato comprato a margine basso.",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "restaurant",
                "company_name": "ChatCo",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "blocco dati dei canali vendita" in body["response"]
        assert "commesse/cantieri" not in body["response"]
        assert body["conversation_state"]["message_kind"] == "data_input"

    def test_chat_restaurant_growth_strategy_is_sector_specific(self, client):
        response = client.post("/cfo/chat", json={
            "message": "ok visto che ho un ristorante come posso fare una strategia per acquisire piu clienti",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "restaurant",
                "company_name": "RistoCo",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "ristorante" in body["response"].lower()
        assert "io non partirei dagli sconti" in body["response"].lower()
        assert "google maps" in body["response"].lower()
        assert "partnership locali" in body["response"].lower()

    def test_chat_simulation_priority_beats_generic_growth_path(self, client):
        response = client.post("/cfo/chat", json={
            "message": "simula +10% prezzo e +5% volume",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Shop Test",
            },
            "operational_data": {
                "annual_revenue": 600000,
                "fixed_costs": 90000,
                "invested_capital": 80000,
                "average_order_value": 75,
                "monthly_orders": 800,
                "customer_acquisition_cost": 18,
                "monthly_ad_spend": 12000,
                "payment_fees_pct": 2,
                "return_rate_pct": 5,
                "sku_sales": [
                    {
                        "sku": "Hero Product",
                        "price": 75,
                        "purchase_cost": 24,
                        "shipping_cost": 7,
                        "monthly_units": 500,
                    }
                ],
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Simulazione Ecommerce CFO" in body["response"]
        assert body["conversation_state"]["brain_action"] == "run_simulation"

    def test_chat_war_room_priority_beats_generic_strategy(self, client):
        response = client.post("/cfo/chat", json={
            "message": "cosa devo fare questa settimana per crescere?",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "saas",
                "company_name": "ChatCo",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Agenda CFO di questa settimana" in body["response"] or "War Room CFO di questa settimana" in body["response"]
        assert body["conversation_state"]["brain_action"] == "war_room"

    def test_chat_answers_growth_with_primary_constraint(self, client):
        response = self._chat(client, "come posso scalare l'attivita")

        assert response.status_code == 200
        body = response.json()
        assert "Vincolo principale" in body["response"]
        assert "scala il fatturato" in body["response"]
        assert "Piano 30 giorni" in body["response"]
        assert "Simulazione consigliata" in body["response"]
        assert "Prossimo passo CFO" in body["response"]

    def test_chat_uses_decision_playbook_for_cost_strategy(self, client):
        response = self._chat(client, "quali costi posso tagliare senza danneggiare la crescita?")

        assert response.status_code == 200
        body = response.json()
        assert "Riduzione costi" in body["response"]
        assert "Piano 30 giorni" in body["response"]
        assert "KPI da monitorare" in body["response"]
        assert "Costo dell'inazione" in body["response"]
        assert "Prossimo passo CFO" in body["response"]
        assert body["conversation_state"]["suggested_action"] == "run_simulation"
        assert body["conversation_state"]["next_best_prompt"]

    def test_chat_resolves_short_followup_from_previous_answer(self, client):
        response = client.post("/cfo/chat", json={
            "message": "ok fallo",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "saas",
                "company_name": "ChatCo",
            },
            "chat_history": [
                {
                    "role": "assistant",
                    "content": (
                        "Riduzione costi senza danneggiare crescita\n\n"
                        "Prossimo passo CFO: Vuoi che separi tagli sicuri, tagli rischiosi e costi da rinegoziare?"
                    ),
                }
            ],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Riduzione costi" in body["response"]
        assert "Piano 30 giorni" in body["response"]
        assert "Prossimo passo CFO" in body["response"]

    def test_chat_short_followup_runs_recommended_ecommerce_simulation(self, client):
        payload = {
            "annual_revenue": 600000,
            "fixed_costs": 90000,
            "invested_capital": 80000,
            "average_order_value": 75,
            "monthly_orders": 800,
            "customer_acquisition_cost": 18,
            "monthly_ad_spend": 12000,
            "payment_fees_pct": 2,
            "return_rate_pct": 5,
            "sku_sales": [
                {
                    "sku": "Hero Product",
                    "price": 75,
                    "purchase_cost": 24,
                    "shipping_cost": 7,
                    "monthly_units": 500,
                }
            ],
        }
        response = client.post("/cfo/chat", json={
            "message": "simula",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Shop Test",
            },
            "operational_data": payload,
            "chat_history": [
                {
                    "role": "assistant",
                    "content": "Simulazione consigliata: +5% prezzo, +10% volume, +5% costi variabili",
                }
            ],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Simulazione Ecommerce CFO" in body["response"]
        assert "Delta utile annuo" in body["response"]

    def test_chat_turns_followup_into_weekly_execution_agenda(self, client):
        response = client.post("/cfo/chat", json={
            "message": "vai",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "saas",
                "company_name": "ChatCo",
            },
            "chat_history": [
                {
                    "role": "assistant",
                    "content": "Prossimo passo CFO: Vuoi che trasformi questo piano in priorita' settimanali con impatto stimato?",
                }
            ],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Agenda CFO di questa settimana" in body["response"]
        assert "Le 3 priorita" in body["response"]
        assert "Owner:" in body["response"]
        assert "KPI:" in body["response"]
        assert body["conversation_state"]["was_follow_up"] is True
        assert body["conversation_state"]["suggested_action"] == "weekly_execution"

    def test_chat_uses_war_room_for_cross_sector_weekly_priority(self, client):
        response = client.post("/cfo/chat", json={
            "message": "cosa devo fare questa settimana?",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "construction",
                "company_name": "MultiCo",
            },
            "operational_data_by_sector": {
                "restaurant": {
                    "annual_revenue": 900000,
                    "variable_costs": 300000,
                    "fixed_costs": 180000,
                    "invested_capital": 120000,
                    "opening_days_per_month": 25,
                    "average_daily_covers": 90,
                    "average_ticket": 36,
                    "target_food_cost_pct": 30,
                    "ingredient_costs": {"mozzarella": 0.006},
                    "menu_items": [
                        {
                            "name": "Margherita",
                            "price": 9,
                            "monthly_units": 1200,
                            "recipe": [{"ingredient": "mozzarella", "quantity": 120}],
                        }
                    ],
                    "staff_roles": [{"role": "Cuoco", "count": 2, "monthly_cost": 2400}],
                },
                "construction": {
                    "fixed_costs": 80000,
                    "invested_capital": 120000,
                    "projects": [
                        {
                            "project": "Cantiere A",
                            "contract_value": 240000,
                            "materials_cost": 82000,
                            "labor_cost": 46000,
                            "subcontractor_cost": 28000,
                            "other_cost": 10000,
                            "progress_pct": 65,
                            "billed_pct": 45,
                            "collected_pct": 25,
                        }
                    ],
                },
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "War Room CFO di questa settimana" in body["response"]
        assert "Executive summary" in body["response"]
        assert "Decisione prioritaria" in body["response"]
        assert "Coda decisionale" in body["response"]
        assert "Stop/Go control" in body["response"]
        assert "Controllo esecuzione" in body["response"]
        assert "wr-" in body["response"]
        assert body["conversation_state"]["suggested_action"] == "weekly_execution"

    def test_chat_answers_from_decision_memory(self, client):
        from core.decision_memory import clear_decision_memory

        clear_decision_memory()
        war_room = client.post(
            "/cfo/war-room",
            json={
                "active_sector": "construction",
                "operational_data_by_sector": {
                    "construction": {
                        "fixed_costs": 80000,
                        "invested_capital": 120000,
                        "projects": [
                            {
                                "project": "Cantiere A",
                                "contract_value": 240000,
                                "materials_cost": 82000,
                                "labor_cost": 46000,
                                "subcontractor_cost": 28000,
                                "other_cost": 10000,
                                "progress_pct": 65,
                                "billed_pct": 45,
                                "collected_pct": 25,
                            }
                        ],
                    }
                },
            },
        )
        decision_id = war_room.json()["war_room"]["execution_tracker"][0]["decision_id"]
        feedback = client.post(
            f"/cfo/decision/{decision_id}/feedback",
            json={"was_implemented": True, "actual_impact_eur": 22000, "expected_impact_eur": 25000},
        )
        assert feedback.status_code == 200

        response = client.post("/cfo/chat", json={
            "message": "quali decisioni sono aperte e cosa ha funzionato?",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 400000,
                "costi_fissi": 300000,
                "investimenti": 100000,
                "settore": "construction",
                "company_name": "DecisionCo",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Memoria decisioni CFO" in body["response"]
        assert "Decisioni completate" in body["response"]
        assert decision_id in body["response"]
        assert body["conversation_state"]["intent"] == "decision_memory_summary"

    def test_chat_clarifies_vague_question_instead_of_random_answer(self, client):
        response = self._chat(client, "aiuto")

        assert response.status_code == 200
        body = response.json()
        assert "restringiamo il campo" in body["response"]
        assert "Data quality" in body["response"]
        assert "Opzioni rapide" in body["response"]
        assert "Prossimo passo CFO" in body["response"]

    def test_chat_estimates_net_from_daily_receipt(self, client):
        response = self._chat(client, "oggi ho incassato 27k quanto mi rimane di netto all'azienda?")

        assert response.status_code == 200
        body = response.json()
        assert "€8.100" in body["response"]
        assert "stima proporzionale" in body["response"].lower()

    def test_chat_asks_restaurant_data_before_product_margin_answer(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quali piatti del menu hanno più margine?",
            "company_data": {
                "fatturato": 900000,
                "costi_variabili": 360000,
                "costi_fissi": 260000,
                "investimenti": 100000,
                "settore": "restaurant",
                "company_name": "Risto Test",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "non ti do una risposta inventata" in body["response"]
        assert "Ingredienti" in body["response"] or "ingredienti" in body["response"]
        assert "ricetta" in body["response"].lower()
        assert "Prossimo passo CFO" in body["response"]

    def test_chat_uses_operating_model_for_data_roadmap(self, client):
        response = client.post("/cfo/chat", json={
            "message": "che dati ti servono per analizzare meglio la mia azienda?",
            "company_data": {
                "fatturato": 900000,
                "costi_variabili": 300000,
                "costi_fissi": 180000,
                "investimenti": 120000,
                "settore": "restaurant",
                "company_name": "Risto Test",
            },
            "operational_data_by_sector": {
                "restaurant": {
                    "annual_revenue": 900000,
                    "variable_costs": 300000,
                    "fixed_costs": 180000,
                    "invested_capital": 120000,
                    "opening_days_per_month": 25,
                }
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "readiness complessiva" in body["response"]
        assert "Domande che ti farei ora" in body["response"]
        assert "Decisione CFO" in body["response"]

    def test_chat_uses_data_room_for_product_push_when_data_exists(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quale prodotto devo spingere?",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Shop Test",
            },
            "operational_data_by_sector": {
                "ecommerce": {
                    "sku_sales": [
                        {
                            "sku": "Hero Product",
                            "price": 75,
                            "purchase_cost": 24,
                            "shipping_cost": 7,
                            "monthly_units": 500,
                        },
                        {
                            "sku": "Low Margin Product",
                            "price": 50,
                            "purchase_cost": 35,
                            "shipping_cost": 8,
                            "monthly_units": 100,
                        },
                    ]
                }
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Data Room CFO - prodotti da spingere" in body["response"]
        assert "Hero Product" in body["response"]
        assert "Decisione CFO" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"
        quality = body["conversation_state"]["answer_quality"]
        assert quality["quality_level"] in {"high", "medium"}
        assert any(source["type"] == "data_room" for source in quality["sources"])

    def test_chat_asks_data_room_fields_when_product_data_missing(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quale prodotto devo spingere?",
            "company_data": {
                "fatturato": 900000,
                "costi_variabili": 360000,
                "costi_fissi": 260000,
                "investimenti": 100000,
                "settore": "restaurant",
                "company_name": "Risto Test",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Data Room CFO - prodotti/margini" in body["response"]
        assert "Qui non invento" in body["response"]
        assert "Prossimo step" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"
        assert body["conversation_state"]["answer_quality"]["policy"] == "asks_for_missing_data"

    def test_chat_uses_data_room_for_construction_cash_gap(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quale commessa mi blocca la cassa?",
            "company_data": {
                "fatturato": 1000000,
                "costi_variabili": 650000,
                "costi_fissi": 140000,
                "investimenti": 120000,
                "settore": "construction",
                "company_name": "Build Test",
            },
            "operational_data_by_sector": {
                "construction": {
                    "projects": [
                        {
                            "project": "Cantiere A",
                            "contract_value": 240000,
                            "materials_cost": 82000,
                            "labor_cost": 46000,
                            "subcontractor_cost": 28000,
                            "other_cost": 10000,
                            "progress_pct": 65,
                            "billed_pct": 45,
                            "collected_pct": 25,
                        },
                        {
                            "project": "Cantiere B",
                            "contract_value": 180000,
                            "materials_cost": 50000,
                            "labor_cost": 30000,
                            "subcontractor_cost": 12000,
                            "progress_pct": 40,
                            "billed_pct": 50,
                            "collected_pct": 60,
                        },
                    ]
                }
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Data Room CFO - commesse/cantieri" in body["response"]
        assert "Cantiere A" in body["response"]
        assert "cash gap" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"

    def test_chat_uses_data_room_for_sales_channel_priority(self, client):
        response = client.post("/cfo/chat", json={
            "message": "quale canale marketing devo scalare?",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "Shop Test",
            },
            "operational_data_by_sector": {
                "ecommerce": {
                    "sales_channels": [
                        {"channel": "Meta Ads", "revenue": 120000, "cost": 25000, "margin_pct": 45},
                        {"channel": "Email", "revenue": 60000, "cost": 3000, "margin_pct": 55},
                    ]
                }
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Data Room CFO - canali vendita" in body["response"]
        assert "Email" in body["response"]
        assert "ROAS" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"

    def test_chat_uses_data_room_for_hotel_revenue_levers(self, client):
        response = client.post("/cfo/chat", json={
            "message": "come sta andando il mio hotel su camere adr e ota?",
            "company_data": {
                "fatturato": 1200000,
                "costi_variabili": 420000,
                "costi_fissi": 520000,
                "investimenti": 250000,
                "settore": "hotel",
                "company_name": "Hotel Test",
            },
            "operational_data_by_sector": {
                "hotel": {
                    "rooms": 42,
                    "occupancy_rate": 74,
                    "adr": 118,
                    "ota_commissions": 17,
                }
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Data Room CFO - hotel" in body["response"]
        assert "RevPAR" in body["response"]
        assert "OTA" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room"

    def test_chat_answers_data_room_history_changes(self, client):
        for rows in [
            [{"sku": "One", "price": 100, "purchase_cost": 40, "monthly_units": 10}],
            [
                {"sku": "One", "price": 100, "purchase_cost": 40, "monthly_units": 10},
                {"sku": "Two", "price": 80, "purchase_cost": 30, "monthly_units": 20},
            ],
        ]:
            client.post(
                "/cfo/data-room/import",
                json={
                    "company_id": "History Chat",
                    "company_name": "History Chat",
                    "active_sector": "ecommerce",
                    "entity": "sku_sales",
                    "rows": rows,
                },
            )

        response = client.post("/cfo/chat", json={
            "message": "cosa è cambiato nello storico Data Room?",
            "company_data": {
                "fatturato": 600000,
                "costi_variabili": 250000,
                "costi_fissi": 90000,
                "investimenti": 80000,
                "settore": "ecommerce",
                "company_name": "History Chat",
            },
            "chat_history": [],
        })

        assert response.status_code == 200
        body = response.json()
        assert "Storico Data Room CFO" in body["response"]
        assert "Delta dall'ultima versione" in body["response"]
        assert body["conversation_state"]["intent"] == "company_data_room_history"


class TestAnalyzeEndpoint:
    """Test /cfo/analyze endpoint."""
    
    def test_analyze_valid_request(self, client, valid_analyze_payload):
        """Should analyze company data."""
        response = client.post("/cfo/analyze", json=valid_analyze_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify response structure
        assert "status" in data
        assert "headline" in data
        assert "summary" in data
        assert "kpi_snapshot" in data
        assert "diagnosis" in data
        assert "recommended_actions" in data
    
    def test_analyze_valid_request_returns_valid_kpis(self, client, valid_analyze_payload):
        """Should return valid KPI snapshot."""
        response = client.post("/cfo/analyze", json=valid_analyze_payload)
        
        assert response.status_code == 200
        data = response.json()
        assert_valid_kpi_snapshot(data["kpi_snapshot"])
    
    def test_analyze_valid_request_has_recommendations(self, client, valid_analyze_payload):
        """Should provide recommendations."""
        response = client.post("/cfo/analyze", json=valid_analyze_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        assert len(data["recommended_actions"]) > 0
        assert_valid_recommendations(data["recommended_actions"])
    
    def test_analyze_returns_reasonable_status(self, client, valid_analyze_payload):
        """Should return health status."""
        response = client.post("/cfo/analyze", json=valid_analyze_payload)
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] in ["healthy", "warning", "critical"]
    
    @pytest.mark.negativity
    def test_analyze_missing_required_field(self, client):
        """Should return 422 for missing fatturato."""
        response = client.post("/cfo/analyze", json={
            "costi_variabili": 100_000,
            "costi_fissi": 50_000,
            "investimenti": 10_000
        })
        
        assert response.status_code == 422
        assert "detail" in response.json()
    
    @pytest.mark.negativity
    def test_analyze_invalid_data_type(self, client):
        """Should return 422 for invalid data type."""
        response = client.post("/cfo/analyze", json={
            "fatturato": "not_a_number",
            "costi_variabili": "also_invalid",
            "costi_fissi": 50_000,
            "investimenti": 10_000
        })
        
        assert response.status_code == 422
    
    @pytest.mark.negativity
    def test_analyze_negative_revenue(self, client):
        """Should return 422 for negative revenue."""
        response = client.post("/cfo/analyze", json={
            "fatturato": -100_000,
            "costi_variabili": 50_000,
            "costi_fissi": 30_000,
            "investimenti": 10_000
        })
        
        assert response.status_code == 422
    
    @pytest.mark.negativity
    def test_analyze_with_zero_revenue(self, client):
        """Should handle zero revenue gracefully."""
        response = client.post("/cfo/analyze", json={
            "fatturato": 0,
            "costi_variabili": 0,
            "costi_fissi": 0,
            "investimenti": 0,
            "company_name": "ZeroRevenue"
        })
        
        # Should either succeed with edge case data
        # or return validation error
        assert response.status_code in [200, 422]


class TestSimulateEndpoint:
    """Test /cfo/simulate endpoint."""
    
    def test_simulate_valid_request(self, client, valid_simulate_payload):
        """Should simulate scenario."""
        response = client.post("/cfo/simulate", json=valid_simulate_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify response structure
        assert "base_analysis" in data
        assert "scenario_analysis" in data
        assert "impact" in data
    
    def test_simulate_returns_impact(self, client, valid_simulate_payload):
        """Should return financial impact."""
        response = client.post("/cfo/simulate", json=valid_simulate_payload)
        
        assert response.status_code == 200
        data = response.json()
        
        impact = data["impact"]
        assert "revenue_impact" in impact or "cost_impact" in impact
    
    @pytest.mark.negativity
    def test_simulate_missing_required_field(self, client):
        """Should return 422 for missing base_financials."""
        response = client.post("/cfo/simulate", json={
            "scenario_name": "Test Scenario"
        })
        
        assert response.status_code == 422


class TestErrorHandling:
    """Test error handling."""
    
    @pytest.mark.negativity
    def test_malformed_json(self, client):
        """Should handle malformed JSON."""
        response = client.post(
            "/cfo/analyze",
            content="not json",
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code in [400, 422]
    
    @pytest.mark.negativity
    def test_endpoint_not_found(self, client):
        """Should return 404 for non-existent endpoint."""
        response = client.get("/cfo/nonexistent")
        
        assert response.status_code == 404
    
    @pytest.mark.negativity
    def test_wrong_method(self, client, valid_analyze_payload):
        """Should return 405 for wrong HTTP method."""
        response = client.get("/cfo/analyze")  # Should be POST
        
        assert response.status_code == 405


@pytest.mark.integration
class TestAnalyzeEndpointWithRealData:
    """Test analyze endpoint with realistic financial data."""
    
    def test_analyze_healthy_saas_scenario(self, client, healthy_saas_company):
        """Should analyze healthy SaaS company via API."""
        payload = {
            "fatturato": healthy_saas_company["fatturato"],
            "costi_variabili": healthy_saas_company["costi_variabili"],
            "costi_fissi": healthy_saas_company["costi_fissi"],
            "investimenti": healthy_saas_company["investimenti"],
            "company_name": "HealthySaaS"
        }
        
        response = client.post("/cfo/analyze", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        # Healthy company status
        assert data["status"] in ["healthy", "warning"]
    
    def test_analyze_struggling_scenario(self, client, struggling_company):
        """Should identify struggling company via API."""
        payload = {
            "fatturato": struggling_company["fatturato"],
            "costi_variabili": struggling_company["costi_variabili"],
            "costi_fissi": struggling_company["costi_fissi"],
            "investimenti": struggling_company["investimenti"],
            "company_name": "StrugglingCo"
        }
        
        response = client.post("/cfo/analyze", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        # Struggling company should have warning/critical
        assert data["status"] in ["warning", "critical"]
        
        # Should have identified problems
        assert data["diagnosis"]["problema_principale"] is not None
    
    def test_analyze_loss_making_scenario(self, client, loss_making_company):
        """Should handle loss-making company via API."""
        payload = {
            "fatturato": loss_making_company["fatturato"],
            "costi_variabili": loss_making_company["costi_variabili"],
            "costi_fissi": loss_making_company["costi_fissi"],
            "investimenti": loss_making_company["investimenti"],
            "company_name": "LossMaker"
        }
        
        response = client.post("/cfo/analyze", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        assert data["status"] == "critical"
        assert data["kpi_snapshot"]["net_margin_pct"] < 0
