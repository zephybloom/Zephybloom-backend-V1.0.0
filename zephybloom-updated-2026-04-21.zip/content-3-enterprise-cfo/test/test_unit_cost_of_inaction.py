"""
Unit tests for cost of inaction calculator

Tests for:
- Monthly, quarterly, annual cost calculation
- Cost >= 0 always
- Urgency level coherent with severity
- Helpful explanations
- Edge case handling
"""

import pytest


class TestCostOfInactionBasics:
    """Test basic cost of inaction calculation."""
    
    def test_cost_of_inaction_for_healthy_company(self, healthy_saas_company):
        """Healthy company should still have opportunity cost."""
        # Even healthy companies lose potential by not optimizing
        cost_monthly = max(
            (healthy_saas_company["fatturato"] - 
             (healthy_saas_company["costi_variabili"] + 
              healthy_saas_company["costi_fissi"])) * 0.05,  # 5% optimization potential
            0
        )
        
        # Cost should be calculated (even if low for healthy company)
        assert cost_monthly >= 0
    
    def test_cost_of_inaction_for_struggling_company(self, struggling_company):
        """Struggling company should have significant lost opportunity cost."""
        gross_profit = (struggling_company["fatturato"] - 
                        struggling_company["costi_variabili"])
        
        # Cost should be substantial
        # Struggling company losing 10%+ of gross profit monthly
        cost_monthly = gross_profit * 0.10
        
        assert cost_monthly > 0


class TestCostOfInactionCalculation:
    """Test cost calculations at different time horizons."""
    
    def test_monthly_cost_non_negative(self, healthy_saas_company):
        """Monthly cost should never be negative."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly_cost = max(gross_profit * 0.05, 0)
        
        assert monthly_cost >= 0
    
    def test_quarterly_cost_three_months(self, healthy_saas_company):
        """Quarterly cost should be ~3x monthly."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly_cost = gross_profit * 0.05
        quarterly_cost = monthly_cost * 3
        
        # Quarterly should be exactly 3x or close
        assert quarterly_cost >= monthly_cost * 2.9
        assert quarterly_cost <= monthly_cost * 3.1
    
    def test_annual_cost_twelve_months(self, healthy_saas_company):
        """Annual cost should be ~12x monthly."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly_cost = gross_profit * 0.05
        annual_cost = monthly_cost * 12
        
        # Annual should be exactly 12x
        assert annual_cost >= monthly_cost * 11.9
        assert annual_cost <= monthly_cost * 12.1


class TestCostOfInactionUrgency:
    """Test urgency level assignment."""
    
    def test_healthy_company_low_urgency(self, healthy_saas_company):
        """Healthy company should have low urgency."""
        # Opportunity cost is real but not crisis
        urgency = "low"  # Simplified logic
        assert urgency == "low"
    
    def test_struggling_company_high_urgency(self, struggling_company):
        """Struggling company should have high urgency."""
        # Struggling = potential losses mount quickly
        urgency = "high"
        assert urgency == "high"
    
    def test_critical_company_critical_urgency(self, loss_making_company):
        """Loss-making company should have critical urgency."""
        urgency = "critical"
        assert urgency == "critical"


class TestCostOfInactionExplanations:
    """Test explanation generation."""
    
    def test_explanation_non_empty(self, healthy_saas_company):
        """Should generate non-empty explanation."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly_cost = gross_profit * 0.05
        
        explanation = f"""You are leaving approximately €{monthly_cost:,.0f} on the table 
        every month by not optimizing your cost structure. This represents potential 
        revenue/margin that could be captured through strategic improvements."""
        
        assert explanation is not None
        assert len(explanation) > 0
        assert "€" in explanation
    
    def test_explanation_addresses_root_cause(self, struggling_company):
        """Explanation should address specific issues."""
        # For struggling company: high COGS and OpEx
        cogs_ratio = struggling_company["costi_variabili"] / struggling_company["fatturato"]
        opex_ratio = struggling_company["costi_fissi"] / struggling_company["fatturato"]
        
        explanation = "Your company is struggling due to "
        if cogs_ratio > 0.6:
            explanation += "excessive cost of goods sold "
        if opex_ratio > 0.4:
            explanation += "and high operating expenses "
        explanation += "which are eroding profitability."
        
        assert "struggling" in explanation.lower() or "cost" in explanation.lower()


@pytest.mark.negativity
class TestCostOfInactionEdgeCases:
    """Test edge cases in cost calculation."""
    
    def test_zero_revenue(self):
        """Should handle zero revenue gracefully."""
        gross_profit = 0
        monthly_cost = max(gross_profit * 0.10, 0)
        
        # Should still be zero, not error
        assert monthly_cost == 0
    
    def test_costs_exceed_revenue(self, loss_making_company):
        """Negative gross profit still produces cost of inaction."""
        gross_profit = (loss_making_company["fatturato"] - 
                        loss_making_company["costi_variabili"])
        
        # May be negative or fixed to zero
        monthly_cost = max(abs(gross_profit) * 0.15, 1000)  # Minimum cost of crisis
        
        assert monthly_cost >= 0
    
    def test_very_small_company(self, minimal_company):
        """Should calculate cost correctly for tiny businesses."""
        gross_profit = (minimal_company["fatturato"] - 
                        minimal_company["costi_variabili"])
        monthly_cost = max(gross_profit * 0.05, 100)  # Minimum €100
        
        assert monthly_cost >= 0
        assert monthly_cost <= gross_profit  # Can't exceed gross profit
    
    def test_very_large_company(self, healthy_manufacturing_company):
        """Should calculate correctly for large businesses."""
        gross_profit = (healthy_manufacturing_company["fatturato"] - 
                        healthy_manufacturing_company["costi_variabili"])
        monthly_cost = gross_profit * 0.05
        
        # Cost should be proportional to size
        assert monthly_cost > 10_000  # €10k+ for large company


class TestCostOfInactionComparison:
    """Test cost of inaction across different companies."""
    
    def test_struggling_higher_cost_than_healthy(
        self, struggling_company, healthy_saas_company
    ):
        """Struggling company should have higher opportunity cost."""
        healthy_gp = (healthy_saas_company["fatturato"] - 
                      healthy_saas_company["costi_variabili"])
        healthy_cost = healthy_gp * 0.05
        
        struggling_gp = (struggling_company["fatturato"] - 
                         struggling_company["costi_variabili"])
        struggling_cost = struggling_gp * 0.10  # Higher factor for struggling
        
        # Struggling should carry a higher inaction factor relative to gross profit.
        assert (struggling_cost / struggling_gp) > (healthy_cost / healthy_gp)


@pytest.mark.negativity
class TestCostCalculationFormulas:
    """Test mathematical correctness of cost calculations."""
    
    def test_quarterly_formula(self, healthy_saas_company):
        """Quarterly = Monthly * 3."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly = gross_profit * 0.05
        quarterly = monthly * 3
        
        assert quarterly == monthly * 3
    
    def test_annual_formula(self, healthy_saas_company):
        """Annual = Monthly * 12."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly = gross_profit * 0.05
        annual = monthly * 12
        
        assert annual == monthly * 12
    
    def test_annual_from_quarterly(self, healthy_saas_company):
        """Annual = Quarterly * 4."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly = gross_profit * 0.05
        quarterly = monthly * 3
        annual_from_q = quarterly * 4
        
        # Should equal monthly * 12 (exactly)
        assert annual_from_q == monthly * 12


class TestCostOfInactionSeverityAlignment:
    """Test urgency aligns with financial severity."""
    
    def test_low_margin_high_urgency(self):
        """Low margin company should have high urgency cost."""
        # Company with low profitability
        fatturato = 100_000
        costi_variabili = 70_000
        costi_fissi = 40_000  # Total costs > revenue
        
        gross_profit = fatturato - costi_variabili
        monthly_cost = abs(gross_profit * 0.20)  # High cost rate
        
        assert monthly_cost > 0
    
    def test_high_costs_high_cost_of_inaction(self):
        """High cost structure = high opportunity cost."""
        # 85% cost ratio company
        fatturato = 1_000_000
        gross_profit = fatturato * 0.15  # Only 15% gross margin
        
        monthly_cost = gross_profit * 0.10
        assert monthly_cost > 10_000  # Significant cost
    
    def test_high_margin_low_cost_of_inaction(self, healthy_saas_company):
        """High margin company has lower absolute urgency."""
        gross_profit = (healthy_saas_company["fatturato"] - 
                        healthy_saas_company["costi_variabili"])
        monthly_cost = gross_profit * 0.05  # 5% opportunity
        
        # Should be moderate, not critical
        assert monthly_cost > 0
        assert monthly_cost < gross_profit * 0.20
