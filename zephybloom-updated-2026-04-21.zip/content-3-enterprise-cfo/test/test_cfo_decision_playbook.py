from core.cfo_decision_playbook import build_decision_playbook


def test_decision_playbook_returns_growth_plan_for_ecommerce():
    playbook = build_decision_playbook(
        company_data={
            "company_name": "Shop Test",
            "fatturato": 900000,
            "costi_variabili": 420000,
            "costi_fissi": 220000,
            "investimenti": 120000,
            "settore": "ecommerce",
        },
        operational_data_by_sector={
            "ecommerce": {
                "annual_revenue": 900000,
                "fixed_costs": 220000,
                "invested_capital": 120000,
                "average_order_value": 75,
                "monthly_orders": 1000,
                "customer_acquisition_cost": 20,
                "monthly_ad_spend": 18000,
                "sku_sales": [
                    {"sku": "Hero", "price": 75, "purchase_cost": 28, "shipping_cost": 7, "monthly_units": 700}
                ],
            }
        },
        active_sector="ecommerce",
        question="come posso vendere di più?",
    )

    decision = playbook["decision"]

    assert playbook["version"] == "cfo-decision-playbook-v1"
    assert playbook["intent"] == "growth_strategy"
    assert playbook["premium_outputs"]["actions_30_60_90"] is True
    assert decision["priority"] == "high"
    assert "30_days" in decision["actions"]
    assert "CAC" in " ".join(decision["kpis_to_monitor"]).upper()
    assert "SKU" in " ".join(decision["actions"]["30_days"])


def test_decision_playbook_returns_cost_plan():
    playbook = build_decision_playbook(
        company_data={
            "company_name": "Ops Test",
            "fatturato": 1000000,
            "costi_variabili": 500000,
            "costi_fissi": 330000,
            "investimenti": 100000,
            "settore": "default",
            "suppliers": [{"name": "Supplier A", "annual_spend": 120000}],
            "recurring_costs": [{"name": "Software", "monthly_cost": 2500}],
        },
        operational_data_by_sector={},
        active_sector="default",
        question="quali costi posso tagliare senza danneggiare la crescita?",
    )

    decision = playbook["decision"]

    assert playbook["intent"] == "cost_optimization"
    assert decision["title"] == "Riduzione costi senza danneggiare crescita"
    assert "fornitori" in " ".join(decision["actions"]["30_days"]).lower()
    assert decision["recommended_simulation"]
    assert decision["cost_of_inaction"]
