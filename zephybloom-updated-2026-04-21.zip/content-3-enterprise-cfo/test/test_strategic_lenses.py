from core.analysis import analyze_company
from core.cfo_intelligence import build_cfo_insight_pack
from core.cfo_intent_router import CFOIntent, route_cfo_intent
from core.strategic_lenses import build_cfo_war_room


def test_war_room_builds_score_lenses_and_decision_for_growth():
    analysis = analyze_company(
        fatturato=1_000_000,
        costi_variabili=400_000,
        costi_fissi=300_000,
        investimenti=100_000,
        settore="default",
        company_name="WarRoomCo",
    )
    insight = build_cfo_insight_pack(analysis, "default")
    intent = route_cfo_intent("come posso vendere di piu")

    war_room = build_cfo_war_room(analysis, insight, intent)

    assert war_room["version"] == "cfo-war-room-v1"
    assert 0 <= war_room["business_quality_score"] <= 100
    assert len(war_room["lenses"]) == 5
    assert war_room["final_decision"]["action"] == "TEST_GROWTH"
    assert war_room["what_breaks_first"]
    assert war_room["next_30_days"]


def test_war_room_stabilizes_loss_making_company():
    analysis = analyze_company(
        fatturato=500_000,
        costi_variabili=420_000,
        costi_fissi=160_000,
        investimenti=50_000,
        settore="default",
        company_name="LossCo",
    )
    insight = build_cfo_insight_pack(analysis, "default")

    war_room = build_cfo_war_room(analysis, insight, route_cfo_intent("come crescere"))

    assert war_room["final_decision"]["action"] == "STABILIZE"
    assert any(item["area"] in {"Margine", "Costi fissi", "Cassa"} for item in war_room["what_breaks_first"])
