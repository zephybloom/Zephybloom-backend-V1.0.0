from core.cfo_answer_quality import build_answer_quality


def test_answer_quality_high_when_data_room_and_operational_data_exist():
    quality = build_answer_quality(
        question="quale prodotto devo spingere?",
        response="Data Room CFO - prodotti da spingere. Primo prodotto: Hero.",
        intent="company_data_room",
        data_quality_pct=78,
        readiness_level="analysis_ready",
        company_data={"fatturato": 600000, "costi_variabili": 250000, "costi_fissi": 90000, "investimenti": 80000, "settore": "ecommerce"},
        operational_data_by_sector={"ecommerce": {"sku_sales": [{"sku": "Hero"}]}},
        data_room={"readiness_score_pct": 78, "active_sector": "ecommerce", "priority_gaps": []},
    )

    assert quality["quality_level"] == "high"
    assert quality["policy"] == "grounded_answer"
    assert any(source["type"] == "data_room" for source in quality["sources"])


def test_answer_quality_flags_operational_answer_without_operational_data():
    quality = build_answer_quality(
        question="quale prodotto devo spingere?",
        response="Il prodotto migliore da spingere è Hero con margine alto.",
        intent="fallback_engine",
        data_quality_pct=20,
        readiness_level="missing_data",
        company_data={"fatturato": 600000, "costi_variabili": 250000, "costi_fissi": 90000, "settore": "ecommerce"},
        operational_data_by_sector={},
        data_room=None,
    )

    assert quality["quality_level"] == "low"
    assert quality["policy"] == "needs_review"
    assert quality["unsupported_claims"]
