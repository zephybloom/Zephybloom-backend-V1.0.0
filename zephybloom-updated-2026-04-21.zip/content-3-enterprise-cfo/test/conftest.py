"""
Pytest configuration and shared fixtures

This module provides:
- Shared fixtures for all tests
- Test data factories
- Mock integrations
- Common test utilities
"""

import pytest
import inspect
from datetime import date, timedelta
from dataclasses import dataclass
from typing import Dict, Any

# ==============================================================================
# PYTEST CONFIGURATION
# ==============================================================================

def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line("markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')")
    config.addinivalue_line("markers", "integration: marks tests as integration tests")
    config.addinivalue_line("markers", "api: marks tests as API tests")
    config.addinivalue_line("markers", "negativity: marks tests for negative/error cases")
    config.addinivalue_line("markers", "performance: marks tests for performance benchmarking")


# ==============================================================================
# FIXTURE: COMPANY DATA FACTORY
# ==============================================================================

@pytest.fixture
def healthy_saas_company() -> Dict[str, Any]:
    """Healthy SaaS company data."""
    return {
        "fatturato": 1_000_000,
        "costi_variabili": 250_000,      # 25% COGS
        "costi_fissi": 300_000,           # 30% OpEx
        "investimenti": 100_000,
        "company_name": "TechStartupInc",
        "sector": "saas",
    }


@pytest.fixture
def healthy_manufacturing_company() -> Dict[str, Any]:
    """Healthy manufacturing company data."""
    return {
        "fatturato": 2_000_000,
        "costi_variabili": 1_000_000,    # 50% COGS
        "costi_fissi": 500_000,           # 25% OpEx
        "investimenti": 200_000,
        "company_name": "FactoryABC",
        "sector": "manufacturing",
    }


@pytest.fixture
def struggling_company() -> Dict[str, Any]:
    """Company with low margins and high costs."""
    return {
        "fatturato": 500_000,
        "costi_variabili": 350_000,      # 70% COGS (too high)
        "costi_fissi": 200_000,           # 40% OpEx (too high)
        "investimenti": 50_000,
        "company_name": "StruglingBiz",
        "sector": "retail",
    }


@pytest.fixture
def loss_making_company() -> Dict[str, Any]:
    """Company operating at a loss."""
    return {
        "fatturato": 300_000,
        "costi_variabili": 200_000,      # 67% COGS
        "costi_fissi": 150_000,           # 50% OpEx
        "investimenti": 30_000,
        "company_name": "LossMaker",
        "sector": "retail",
    }


@pytest.fixture
def high_growth_saas_company() -> Dict[str, Any]:
    """High-growth SaaS company with aggressive spending."""
    return {
        "fatturato": 500_000,
        "costi_variabili": 100_000,      # 20% COGS
        "costi_fissi": 350_000,           # 70% OpEx (high for growth)
        "investimenti": 150_000,
        "company_name": "HypergrowthTech",
        "sector": "saas",
    }


@pytest.fixture
def break_even_company() -> Dict[str, Any]:
    """Company near break-even point."""
    return {
        "fatturato": 200_000,
        "costi_variabili": 100_000,      # 50% COGS
        "costi_fissi": 100_000,           # 50% OpEx
        "investimenti": 10_000,
        "company_name": "BreakEven",
        "sector": "retail",
    }


@pytest.fixture
def minimal_company() -> Dict[str, Any]:
    """Minimal company data for edge case testing."""
    return {
        "fatturato": 100_000,
        "costi_variabili": 30_000,
        "costi_fissi": 40_000,
        "investimenti": 5_000,
        "company_name": "MinimalCo",
        "sector": "default",
    }


# ==============================================================================
# FIXTURE: API PAYLOADS
# ==============================================================================

@pytest.fixture
def valid_analyze_payload() -> Dict[str, Any]:
    """Valid payload for /cfo/analyze endpoint."""
    return {
        "fatturato": 1_000_000,
        "costi_variabili": 400_000,
        "costi_fissi": 300_000,
        "investimenti": 100_000,
        "company_name": "TestCorp",
        "sector": "saas",
    }


@pytest.fixture
def invalid_analyze_payloads() -> Dict[str, Dict[str, Any]]:
    """Collection of invalid payloads for /cfo/analyze endpoint."""
    return {
        "missing_fatturato": {
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
        },
        "negative_fatturato": {
            "fatturato": -1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
        },
        "invalid_sector": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "sector": "unknown_sector_xyz",
        },
        "wrong_type": {
            "fatturato": "not_a_number",
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
        },
    }


@pytest.fixture
def valid_simulate_payload() -> Dict[str, Any]:
    """Valid payload for /cfo/simulate endpoint."""
    return {
        "fatturato_base": 1_000_000,
        "costi_variabili_base": 400_000,
        "costi_fissi_base": 300_000,
        "investimenti_base": 100_000,
        "scenario": "cost_reduction",
        "param_value": 50_000,
    }


# ==============================================================================
# FIXTURE: DECISION SYSTEM PAYLOADS
# ==============================================================================

@pytest.fixture
def valid_analyze_decision_payload() -> Dict[str, Any]:
    """Valid payload for /cfo/analyze-decision endpoint."""
    return {
        "fatturato": 1_000_000,
        "costi_variabili": 400_000,
        "costi_fissi": 300_000,
        "investimenti": 100_000,
        "company_name": "DecisionTest",
        "sector": "saas",
        "employee_count": 25,
        "monthly_salary_avg": 4_000,
        "hiring_context": "stable",
    }


@pytest.fixture
def invalid_analyze_decision_payloads() -> Dict[str, Dict[str, Any]]:
    """Collection of invalid payloads for /cfo/analyze-decision endpoint."""
    return {
        "missing_company_data": {
            "company_name": "Test",
            "sector": "saas",
        },
        "missing_employee_data": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
        },
        "negative_salary": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": -4_000,  # Invalid
            "hiring_context": "stable",
        },
        "invalid_hiring_context": {
            "fatturato": 1_000_000,
            "costi_variabili": 400_000,
            "costi_fissi": 300_000,
            "investimenti": 100_000,
            "company_name": "Test",
            "sector": "saas",
            "employee_count": 25,
            "monthly_salary_avg": 4_000,
            "hiring_context": "invalid_context",
        },
    }


@pytest.fixture
def hiring_boom_scenario() -> Dict[str, Any]:
    """Company in hiring boom scenario."""
    return {
        "fatturato": 1_000_000,
        "costi_variabili": 250_000,
        "costi_fissi": 300_000,
        "investimenti": 200_000,
        "company_name": "BoomCo",
        "sector": "saas",
        "employee_count": 25,
        "monthly_salary_avg": 5_000,  # Higher salaries for talent acquisition
        "hiring_context": "boom",  # Aggressive hiring
    }


@pytest.fixture
def hiring_decline_scenario() -> Dict[str, Any]:
    """Company in hiring decline scenario."""
    return {
        "fatturato": 800_000,
        "costi_variabili": 300_000,
        "costi_fissi": 350_000,
        "investimenti": 50_000,
        "company_name": "DeclineCo",
        "sector": "saas",
        "employee_count": 30,  # More employees but lower revenue
        "monthly_salary_avg": 4_200,
        "hiring_context": "decline",  # Reducing headcount
    }


@pytest.fixture
def stable_hiring_scenario() -> Dict[str, Any]:
    """Company in stable hiring scenario."""
    return {
        "fatturato": 1_500_000,
        "costi_variabili": 375_000,
        "costi_fissi": 450_000,
        "investimenti": 150_000,
        "company_name": "StableCo",
        "sector": "saas",
        "employee_count": 35,
        "monthly_salary_avg": 4_500,
        "hiring_context": "stable",
    }


@pytest.fixture
def critical_company_decision_payload() -> Dict[str, Any]:
    """Critical/loss-making company decision payload."""
    return {
        "fatturato": 300_000,
        "costi_variabili": 200_000,      # 67% COGS
        "costi_fissi": 150_000,           # 50% OpEx
        "investimenti": 30_000,
        "company_name": "CriticalCo",
        "sector": "retail",
        "employee_count": 15,
        "monthly_salary_avg": 3_000,
        "hiring_context": "decline",
    }


@pytest.fixture
def healthy_company_decision_payload() -> Dict[str, Any]:
    """Healthy company decision payload."""
    return {
        "fatturato": 2_000_000,
        "costi_variabili": 500_000,      # 25% COGS
        "costi_fissi": 600_000,           # 30% OpEx
        "investimenti": 200_000,
        "company_name": "HealthyCo",
        "sector": "saas",
        "employee_count": 40,
        "monthly_salary_avg": 5_000,
        "hiring_context": "boom",
    }


@pytest.fixture
def struggling_company_decision_payload() -> Dict[str, Any]:
    """Struggling company decision payload."""
    return {
        "fatturato": 500_000,
        "costi_variabili": 350_000,      # 70% COGS
        "costi_fissi": 200_000,           # 40% OpEx
        "investimenti": 50_000,
        "company_name": "StruggleCo",
        "sector": "retail",
        "employee_count": 20,
        "monthly_salary_avg": 3_500,
        "hiring_context": "stable",
    }


# ==============================================================================
# FIXTURE: LEARNING ENGINE DATA
# ==============================================================================

@pytest.fixture
def learning_engine_state() -> Dict[str, Any]:
    """Pre-populated learning engine state."""
    return {
        "decisions": [
            {
                "type": "Reduce Fixed Costs",
                "expected_impact": 150_000,
                "actual_impact": 140_000,
            },
            {
                "type": "Reduce Fixed Costs",
                "expected_impact": 150_000,
                "actual_impact": 145_000,
            },
            {
                "type": "Price Optimization",
                "expected_impact": 100_000,
                "actual_impact": 80_000,
            },
        ],
    }


# ==============================================================================
# FIXTURE: MOCK INTEGRATIONS
# ==============================================================================

@pytest.fixture
def mock_xero_config() -> Dict[str, str]:
    """Mock Xero configuration."""
    return {
        "api_key": "test_xero_key",
        "api_secret": "test_xero_secret",
        "tenant_id": "test_tenant",
    }


@pytest.fixture
def mock_stripe_config() -> Dict[str, str]:
    """Mock Stripe configuration."""
    return {
        "api_key": "sk_test_1234567890",
    }


@pytest.fixture
def mock_hubspot_config() -> Dict[str, str]:
    """Mock HubSpot configuration."""
    return {
        "api_key": "hubspot_test_key",
    }


# ==============================================================================
# FIXTURE: TIME RANGES
# ==============================================================================

@pytest.fixture
def date_range_30_days():
    """Standard 30-day date range for analysis."""
    end = date.today()
    start = end - timedelta(days=30)
    return start, end


@pytest.fixture
def date_range_90_days():
    """90-day date range for analysis."""
    end = date.today()
    start = end - timedelta(days=90)
    return start, end


# ==============================================================================
# UTILITY FIXTURES
# ==============================================================================

@pytest.fixture
def valid_sectors() -> list:
    """List of valid sectors."""
    return ["manufacturing", "saas", "retail", "default"]


@pytest.fixture
def valid_kpi_statuses() -> list:
    """List of valid KPI health statuses."""
    return ["healthy", "warning", "critical"]


@pytest.fixture
def valid_tones() -> list:
    """List of valid CFO tones."""
    return ["soft", "competent", "firm", "direct", "harsh", "manager", "motivator"]


@pytest.fixture
def valid_risk_tolerances() -> list:
    """List of valid risk tolerance levels."""
    return ["conservative", "moderate", "aggressive"]


# ==============================================================================
# HELPER FUNCTIONS FOR ASSERTIONS
# ==============================================================================

def assert_valid_kpi_snapshot(snapshot) -> None:
    """Assert KPI snapshot has valid structure and values."""
    assert snapshot is not None
    if isinstance(snapshot, dict):
        from types import SimpleNamespace
        snapshot = SimpleNamespace(**snapshot)
    assert hasattr(snapshot, 'gross_margin_pct')
    assert hasattr(snapshot, 'net_margin_pct')
    assert hasattr(snapshot, 'ebitda_margin_pct')
    
    # Margins should be reasonable
    assert -100 <= snapshot.gross_margin_pct <= 200
    assert -100 <= snapshot.net_margin_pct <= 200
    assert -100 <= snapshot.ebitda_margin_pct <= 200
    
    # Gross margin >= Net margin (always)
    if snapshot.gross_margin_pct >= 0 and snapshot.net_margin_pct >= 0:
        assert snapshot.gross_margin_pct >= snapshot.net_margin_pct, \
            "Gross margin should be >= Net margin"


def assert_valid_diagnosis(diagnosis) -> None:
    """Assert diagnosis object has valid structure."""
    assert diagnosis is not None
    assert hasattr(diagnosis, 'problema_principale')
    assert hasattr(diagnosis, 'causa_principale')
    assert hasattr(diagnosis, 'impatto_stimato_eur')
    assert isinstance(diagnosis.impatto_stimato_eur, (int, float))


def assert_valid_recommendations(actions) -> None:
    """Assert recommendations list is valid."""
    assert isinstance(actions, list)
    assert len(actions) > 0
    
    for action in actions:
        if isinstance(action, dict):
            from types import SimpleNamespace
            action = SimpleNamespace(**action)
        assert hasattr(action, 'title')
        assert hasattr(action, 'description')
        assert hasattr(action, 'impatto_euro')
        assert isinstance(action.impatto_euro, (int, float))
        assert action.impatto_euro != 0  # Should have measurable impact


def assert_valid_decision_result(result) -> None:
    """Assert decision result has valid structure."""
    assert result is not None
    assert hasattr(result, 'dominant_action')
    assert hasattr(result, 'top_decisions')
    assert hasattr(result, 'scenarios')
    
    # Dominant action should exist and be first
    assert result.dominant_action is not None
    assert result.dominant_action.title is not None
    
    # Top decisions should be ordered
    assert isinstance(result.top_decisions, list)
    assert len(result.top_decisions) > 0
    
    # First decision should be dominant
    if len(result.top_decisions) > 0:
        assert result.top_decisions[0].title == result.dominant_action.title


def assert_valid_cost_of_inaction(cost) -> None:
    """Assert cost of inaction calculation is valid."""
    assert cost is not None
    assert hasattr(cost, 'monthly_cost_eur')
    assert hasattr(cost, 'quarterly_cost_eur')
    assert hasattr(cost, 'annual_cost_eur')
    assert hasattr(cost, 'urgency_level')
    assert hasattr(cost, 'explanation')
    
    # Cost should be non-negative
    assert cost.monthly_cost_eur >= 0
    assert cost.quarterly_cost_eur >= 0
    assert cost.annual_cost_eur >= 0
    
    # Quarterly should be ~3x monthly, annual should be ~12x monthly
    assert cost.quarterly_cost_eur >= cost.monthly_cost_eur * 2.5
    assert cost.annual_cost_eur >= cost.monthly_cost_eur * 11


def assert_valid_human_value_calculation(result) -> None:
    """Assert human value calculation is valid."""
    assert result is not None
    assert hasattr(result, 'total_cost_employees')
    assert hasattr(result, 'assumed_roi_percent')
    assert hasattr(result, 'payback_months')
    assert hasattr(result, 'min_productivity_required')
    assert hasattr(result, 'recommendation')
    
    # Values should be reasonable
    assert result.total_cost_employees >= 0
    assert result.assumed_roi_percent >= 0
    assert result.payback_months >= 0
    assert 0 <= result.min_productivity_required <= 200  # 0-200% productivity
    
    # Recommendation should provide actionable guidance
    assert result.recommendation is not None
    assert len(result.recommendation) > 0


@pytest.fixture
def assert_decision_json_contract():
    """Fixture for decision JSON contract validation."""
    def _assert_contract(body: dict) -> None:
        """Assert decision response JSON has correct contract structure."""
        required_keys = [
            "kpi_summary",
            "diagnosis",
            "dominant_action",
            "top_decisions",
            "scenarios",
            "cost_of_inaction",
            "action_plan",
            "objections",
            "memorable_insight",
        ]
        for key in required_keys:
            assert key in body, f"Required key '{key}' missing from JSON"
        
        # Type validations
        assert isinstance(body["top_decisions"], list), "top_decisions must be list"
        assert isinstance(body["action_plan"], dict), "action_plan must be dict"
        assert isinstance(body["diagnosis"], dict), "diagnosis must be dict"
        assert isinstance(body["cost_of_inaction"], dict), "cost_of_inaction must be dict"
        
        # cost_of_inaction required fields - adapted for quarterly = monthly * 3, annual = monthly * 12
        cost = body.get("cost_of_inaction", {})
        # Fields might be monthly/quarterly/annual OR might not be required if dict is empty
        # so we just validate structure if fields are present
        
    return _assert_contract


@pytest.fixture
def assert_json_contract_shapes_match():
    """Fixture for JSON contract shape matching assertion."""
    def _assert_match(body1: dict, body2: dict) -> None:
        """Assert two decision response bodies have matching JSON structure."""
        keys1 = set(body1.keys())
        keys2 = set(body2.keys())
        
        assert keys1 == keys2, f"JSON keys differ: {keys1.symmetric_difference(keys2)}"
        
        # Check nested structure types match
        for key in keys1:
            val1_type = type(body1[key])
            val2_type = type(body2[key])
            assert val1_type == val2_type, \
                f"Field '{key}' type mismatch: {val1_type} vs {val2_type}"
    return _assert_match


@pytest.fixture
def assert_semantic_urgency_order():
    """Fixture for semantic urgency order assertion."""
    def _assert_order(critical_cost: float, struggling_cost: float, 
                      healthy_cost: float) -> None:
        """Assert cost of inaction follows semantic order."""
        # Critical/loss-making should have highest cost
        assert critical_cost >= struggling_cost, \
            "Critical company should have higher cost of inaction than struggling"
        # Struggling should have higher cost than healthy
        assert struggling_cost >= healthy_cost, \
            "Struggling company should have higher cost than healthy"
    return _assert_order


# ===== Helper fixtures for assert functions =====

@pytest.fixture
def assert_valid_kpi_snapshot_fixture():
    """Fixture wrapper for assert_valid_kpi_snapshot helper"""
    return assert_valid_kpi_snapshot


@pytest.fixture
def assert_valid_diagnosis_fixture():
    """Fixture wrapper for assert_valid_diagnosis helper"""
    return assert_valid_diagnosis


@pytest.fixture
def assert_valid_recommendations_fixture():
    """Fixture wrapper for assert_valid_recommendations helper"""
    return assert_valid_recommendations


@pytest.fixture
def assert_valid_decision_result_fixture():
    """Fixture wrapper for assert_valid_decision_result helper"""
    return assert_valid_decision_result


@pytest.fixture
def assert_valid_human_value_calculation_fixture():
    """Fixture wrapper for assert_valid_human_value_calculation helper"""
    return assert_valid_human_value_calculation


# ==============================================================================
# FIXTURE: AUTHENTICATED TEST CLIENT
# ==============================================================================

@pytest.fixture
def authenticated_client():
    """FastAPI test client with authentication mocked for testing."""
    from fastapi.testclient import TestClient
    from api.main import app
    from api.tenant_context import get_tenant_context, TenantContext
    
    # Create a mock get_tenant_context that returns verified context
    def mock_get_tenant_context(*args, **kwargs) -> TenantContext:
        return TenantContext(
            tenant_id="test_tenant",
            user_id=1,
            api_key_id=None,
            is_verified=True,
        )
    mock_get_tenant_context.__signature__ = inspect.Signature()
    
    # Override the get_tenant_context dependency
    app.dependency_overrides[get_tenant_context] = mock_get_tenant_context
    
    client = TestClient(app)
    
    yield client
    
    # Cleanup: remove override after test
    app.dependency_overrides.clear()
