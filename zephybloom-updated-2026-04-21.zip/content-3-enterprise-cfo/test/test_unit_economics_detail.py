from core.unit_economics_detail import analyze_unit_economics


ROWS = [
    {
        "customer": "Cliente A",
        "product": "Premium Pack",
        "supplier": "Supplier 1",
        "quantity": 10,
        "unit_price": 500,
        "purchase_price": 180,
        "commissions": 100,
    },
    {
        "customer": "Cliente B",
        "product": "Low Margin Pack",
        "supplier": "Supplier 2",
        "quantity": 20,
        "unit_price": 100,
        "purchase_price": 85,
        "logistics_cost": 200,
    },
    {
        "customer": "Cliente A",
        "product": "Premium Pack",
        "supplier": "Supplier 1",
        "quantity": 5,
        "unit_price": 500,
        "purchase_price": 180,
    },
]


def test_unit_economics_ranks_products_customers_and_suppliers():
    result = analyze_unit_economics(ROWS)

    assert result["row_count"] == 3
    assert result["totals"]["revenue_eur"] == 9500
    assert result["top_products_by_margin"][0]["product"] == "Premium Pack"
    assert result["top_customers_by_profit"][0]["customer"] == "Cliente A"
    assert result["suppliers_to_renegotiate"][0]["supplier"] == "Supplier 1"
    assert result["recommendations"]


def test_unit_economics_flags_low_margin_products():
    result = analyze_unit_economics(ROWS)

    products_to_fix = [item["product"] for item in result["products_to_fix"]]
    assert "Low Margin Pack" in products_to_fix
