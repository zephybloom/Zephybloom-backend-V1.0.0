from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from core.cfo_report import build_monthly_cfo_report
from core.cfo_report_pdf import render_monthly_report_pdf
from core.decision_memory import remember_war_room_decisions
from db.models import Base, Tenant, User


def _session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    user = User(email="report@example.com", password_hash="x", full_name="Report User")
    session.add(user)
    session.flush()
    session.add(Tenant(id="tenant-report", name="Tenant Report", owner_id=user.id))
    session.commit()
    return session


def test_monthly_cfo_report_combines_kpis_war_room_and_memory():
    session = _session()
    remember_war_room_decisions(
        "tenant-report",
        {
            "decision_queue": [
                {"decision_id": "wr-01-construction-cashrecovery", "sector": "construction", "type": "cashrecovery"}
            ],
            "execution_tracker": [
                {
                    "decision_id": "wr-01-construction-cashrecovery",
                    "rank": 1,
                    "sector": "construction",
                    "owner": "CEO",
                    "status": "todo",
                    "decision": "Recupera SAL",
                    "next_action": "Fattura WIP non fatturato",
                    "success_metric": {"kpi": "cash gap", "target": "<= EUR 0"},
                }
            ],
        },
        session=session,
    )

    report = build_monthly_cfo_report(
        tenant_id="tenant-report",
        company_id="ReportCo",
        company_name="ReportCo",
        period="2026-04",
        company_data={
            "fatturato": 1000000,
            "costi_variabili": 400000,
            "costi_fissi": 300000,
            "investimenti": 100000,
            "settore": "construction",
        },
        operational_data_by_sector={
            "construction": {
                "fixed_costs": 80000,
                "invested_capital": 120000,
                "projects": [
                    {
                        "project": "Cantiere A",
                        "contract_value": 240000,
                        "materials_cost": 82000,
                        "labor_cost": 46000,
                        "subcontractor_cost": 28000,
                        "other_cost": 10000,
                        "progress_pct": 65,
                        "billed_pct": 45,
                        "collected_pct": 25,
                    }
                ],
            }
        },
        session=session,
    )

    assert report["version"] == "monthly-cfo-report-v1"
    assert report["period"] == "2026-04"
    assert report["sections"]["financial_snapshot"]["net_profit_eur"] == 300000
    assert report["sections"]["decision_memory"]["summary"]["open_decisions"] == 1
    assert report["sections"]["war_room"]["priority_decision"]["decision"]
    assert report["sections"]["next_30_days"][0]["action"] == "Fattura WIP non fatturato"
    assert report["sections"]["ceo_brief"]["action_7_days"] == "Fattura WIP non fatturato"
    assert report["sections"]["finance_brief"]["kpi_watchlist"]
    assert {item["decision"] for item in report["sections"]["board_decisions"]} == {
        "APPROVARE",
        "BLOCCARE",
        "MONITORARE",
        "CHIEDERE",
    }
    assert report["sections"]["team_questions"]
    assert "Report CFO Mensile" in report["markdown"]
    assert "Decisioni da board" in report["markdown"]
    assert "Domande CFO al team" in report["markdown"]
    assert report["premium_outputs"]["ready_for_pdf_export"] is True
    assert report["premium_outputs"]["board_decisions"] is True


def test_monthly_cfo_report_pdf_renderer_returns_valid_pdf_bytes():
    session = _session()
    report = build_monthly_cfo_report(
        tenant_id="tenant-report",
        company_id="ReportCo",
        company_name="ReportCo",
        period="2026-04",
        company_data={
            "fatturato": 1000000,
            "costi_variabili": 400000,
            "costi_fissi": 300000,
            "investimenti": 100000,
            "settore": "construction",
        },
        operational_data_by_sector={},
        session=session,
    )

    pdf = render_monthly_report_pdf(report)

    assert pdf.startswith(b"%PDF-1.4")
    assert b"%%EOF" in pdf
    assert len(pdf) > 1000
    assert b"Scorecard finanziaria" in pdf
    assert b"Messaggio board" in pdf
    assert b"Decisioni da board" in pdf
    assert b"Domande CFO al team" in pdf
    assert b"Sintesi CEO" in pdf
    assert b"CFO AI Report" in pdf
