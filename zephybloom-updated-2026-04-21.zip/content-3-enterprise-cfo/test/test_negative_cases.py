"""
Negative case and error handling tests

Tests for:
- Error resilience
- Edge case handling
- Input validation
- Boundary conditions
- Database/external integration failures
"""

import pytest
from core.analysis import analyze_company
from core.validators import clamp_pct100, clamp_rate01, clamp_nonneg, normalize_context_numeric
from api.main import app
from fastapi.testclient import TestClient


@pytest.fixture
def client(authenticated_client):
    """FastAPI test client with authentication."""
    return authenticated_client



class TestZeroRevenueScenarios:
    """Test handling of zero or near-zero revenue."""
    
    def test_zero_revenue_with_zero_costs(self):
        """Should handle zero revenue and zero costs."""
        result = analyze_company(
            fatturato=0,
            costi_variabili=0,
            costi_fissi=0,
            investimenti=0,
            company_name="ZeroCo"
        )
        
        assert result is not None
        assert result.kpi_snapshot is not None
    
    def test_zero_revenue_with_costs(self):
        """Should handle zero revenue with positive costs."""
        result = analyze_company(
            fatturato=0,
            costi_variabili=0,
            costi_fissi=100_000,
            investimenti=50_000,
            company_name="CostsNoCash"
        )
        
        assert result is not None
        # Should be critical given costs but no revenue
        assert result.status == "critical"
        assert result.kpi_snapshot.net_margin_pct < -100


class TestNegativeValuesHandling:
    """Test handling of negative financial values."""
    
    @pytest.mark.negativity
    def test_negative_fatturato_rejected(self, client):
        """API should reject negative revenue."""
        response = client.post("/cfo/analyze", json={
            "fatturato": -500_000,
            "costi_variabili": 100_000,
            "costi_fissi": 50_000,
            "investimenti": 10_000
        })
        
        assert response.status_code == 422
    
    @pytest.mark.negativity
    def test_negative_costs_in_validation(self):
        """Validators should handle negative values."""
        # Negative values should be clamped to 0
        result = clamp_nonneg(-100)
        assert result == 0
    
    @pytest.mark.negativity
    def test_negative_margin_calculation(self):
        """Should calculate negative margins correctly."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=70_000,
            costi_fissi=80_000,  # Total costs exceed revenue
            investimenti=10_000,
            company_name="Unprofitable"
        )
        
        assert result is not None
        assert result.kpi_snapshot.gross_margin_pct > 0
        assert result.kpi_snapshot.net_margin_pct < 0


class TestExtremeValuesHandling:
    """Test handling of extremely large or small values."""
    
    def test_very_large_revenue(self):
        """Should handle billion-euro revenues."""
        result = analyze_company(
            fatturato=1_000_000_000,  # 1 billion EUR
            costi_variabili=300_000_000,
            costi_fissi=200_000_000,
            investimenti=100_000_000,
            company_name="MegaCorp"
        )
        
        assert result is not None
        assert result.kpi_snapshot.gross_margin_pct > 0
    
    def test_very_small_revenue(self):
        """Should handle micro-scale revenues."""
        result = analyze_company(
            fatturato=1_000,  # 1,000 EUR
            costi_variabili=300,
            costi_fissi=400,
            investimenti=100,
            company_name="MicroCo"
        )
        
        assert result is not None
        assert result.kpi_snapshot is not None
    
    def test_extreme_margin_clamping(self):
        """Margins should be clamped to [0, 100]."""
        # Test over 100%
        result = clamp_pct100(150.0)
        assert result == 100.0
        
        # Test below 0%
        result = clamp_pct100(-50.0)
        assert result == 0.0


class TestCostExceedsRevenueScenarios:
    """Test handling when costs exceed revenue (loss-making companies)."""
    
    def test_variable_costs_exceed_revenue(self):
        """Should handle variable costs > revenue."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=120_000,  # > revenue
            costi_fissi=10_000,
            investimenti=5_000,
            company_name="VariableOver"
        )
        
        assert result is not None
        assert result.kpi_snapshot.gross_margin_pct < 0
    
    def test_total_costs_exceed_revenue(self):
        """Should handle total costs > revenue."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=60_000,
            costi_fissi=60_000,  # Total = 120k > 100k revenue
            investimenti=20_000,
            company_name="TotalOver"
        )
        
        assert result is not None
        assert result.status in ["warning", "critical"]
        assert result.kpi_snapshot.net_margin_pct < 0
    
    def test_fixed_costs_only_exceed_contribution_margin(self):
        """Should handle fixed costs > gross profit."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=40_000,
            costi_fissi=80_000,  # Fixed > (revenue - variable)
            investimenti=10_000,
            company_name="FixedOver"
        )
        
        assert result is not None
        # Gross profit = 60k, but fixed costs = 80k
        assert result.kpi_snapshot.net_margin_pct < 0


class TestDataValidationEdgeCases:
    """Test validation edge cases."""
    
    @pytest.mark.negativity
    def test_normalize_with_missing_keys(self):
        """Should handle missing keys gracefully."""
        context = {"fatturato": 1_000_000}
        result = normalize_context_numeric(context)
        
        assert result is not None
        assert result["fatturato"] == 1_000_000
    
    @pytest.mark.negativity
    def test_normalize_with_non_numeric_values(self):
        """Should preserve non-numeric values."""
        context = {
            "fatturato": 1_000_000,
            "company_name": "TestCo",
            "sector": "saas"
        }
        result = normalize_context_numeric(context)
        
        assert result["company_name"] == "TestCo"
        assert result["sector"] == "saas"
    
    @pytest.mark.negativity
    def test_normalize_with_nan_values(self):
        """Should handle NaN values gracefully."""
        import math
        context = {
            "fatturato": 1_000_000,
            "special_metric": math.nan
        }
        # Should not raise exception
        result = normalize_context_numeric(context)
        assert result is not None
    
    @pytest.mark.negativity
    def test_clamp_rate_boundaries(self):
        """Rate clamping should work at boundaries."""
        assert clamp_rate01(-0.5) == 0.0
        assert clamp_rate01(0.0) == 0.0
        assert clamp_rate01(0.5) == 0.5
        assert clamp_rate01(1.0) == 1.0
        assert clamp_rate01(1.5) == 1.0


class TestDivisionByZeroProtection:
    """Test protection against division by zero."""
    
    @pytest.mark.negativity
    def test_margin_calculation_with_zero_revenue(self):
        """Should not crash when calculating margins with zero revenue."""
        result = analyze_company(
            fatturato=0,
            costi_variabili=0,
            costi_fissi=0,
            investimenti=0,
            company_name="ZeroRevenue"
        )
        
        # Should not raise ZeroDivisionError
        assert result is not None
        assert hasattr(result, 'kpi_snapshot')
    
    @pytest.mark.negativity
    def test_roi_calculation_with_zero_investment(self):
        """Should handle ROI calculation with zero investment."""
        result = analyze_company(
            fatturato=1_000_000,
            costi_variabili=300_000,
            costi_fissi=200_000,
            investimenti=0,  # Zero investment
            company_name="NoInvest"
        )
        
        assert result is not None
        # Should either not calculate ROI or use safe division


class TestRecommendationQuality:
    """Test quality of recommendations under various financial conditions."""
    
    def test_recommendations_for_healthy_company(self):
        """Healthy company should still get improvement recommendations."""
        result = analyze_company(
            fatturato=1_000_000,
            costi_variabili=250_000,
            costi_fissi=200_000,
            investimenti=100_000,
            company_name="Healthy"
        )
        
        assert result is not None
        assert len(result.recommended_actions) > 0
        
        # All recommendations should have required fields
        for action in result.recommended_actions:
            assert action.title is not None
            assert action.description is not None
    
    def test_recommendations_for_critical_company(self):
        """Critical company should receive urgent recommendations."""
        result = analyze_company(
            fatturato=100_000,
            costi_variabili=80_000,
            costi_fissi=50_000,
            investimenti=10_000,
            company_name="Critical"
        )
        
        assert result is not None
        assert result.status == "critical"
        
        # Should have recommendations addressing the crisis
        assert len(result.recommended_actions) > 0
        
        # Should identify cost reduction as priority
        titles = [a.title for a in result.recommended_actions]
        # At least one should address costs or revenue
        assert any("cost" in t.lower() or "revenue" in t.lower() 
                   for t in titles)


@pytest.mark.api
@pytest.mark.negativity
class TestAPIErrorResponses:
    """Test API error response formats."""
    
    def test_api_missing_field_error_format(self, client):
        """Should return properly formatted 422 errors."""
        response = client.post("/cfo/analyze", json={
            "costi_variabili": 100_000
        })
        
        assert response.status_code == 422
        data = response.json()
        assert "detail" in data
    
    def test_api_invalid_type_error_format(self, client):
        """Should return properly formatted validation errors."""
        response = client.post("/cfo/analyze", json={
            "fatturato": "not_a_number",
            "costi_variabili": 100_000,
            "costi_fissi": 50_000,
            "investimenti": 10_000
        })
        
        assert response.status_code == 422
        data = response.json()
        assert "detail" in data
        assert isinstance(data["detail"], list)
    
    def test_api_malformed_request_handling(self, client):
        """Should handle malformed requests gracefully."""
        response = client.post(
            "/cfo/analyze",
            content="{invalid json",
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code in [400, 422]


@pytest.mark.negativity
class TestSectorSpecificEdgeCases:
    """Test sector-specific edge cases."""
    
    def test_manufacturing_with_high_opex(self):
        """Manufacturing company with unusually high OpEx."""
        result = analyze_company(
            fatturato=2_000_000,
            costi_variabili=1_000_000,  # 50% COGS
            costi_fissi=1_200_000,      # 60% OpEx (unusually high)
            investimenti=500_000,
            company_name="HighOpexManuf",
            settore="manufacturing"
        )
        
        assert result is not None
        assert result.kpi_snapshot.net_margin_pct < 5
    
    def test_saas_with_low_margin(self):
        """SaaS company with atypically low margin."""
        result = analyze_company(
            fatturato=500_000,
            costi_variabili=250_000,  # 50% COGS (high for SaaS)
            costi_fissi=300_000,      # 60% OpEx (high for SaaS)
            investimenti=200_000,
            company_name="HighCostSaas",
            settore="saas"
        )
        
        assert result is not None
        # Should identify margin issues
        assert result.status in ["warning", "critical"]
