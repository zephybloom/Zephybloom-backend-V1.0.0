import http from 'k6/http';
import { check, sleep } from 'k6';

// Configuration for local testing
export const options = {
  vus: 20,           // Local: 20 concurrent users (lighter than prod 100)
  duration: '2m',    // Run for 2 minutes (faster iteration)
  
  stages: [
    { duration: '10s', target: 20 },   // Ramp up to 20 VUs in 10s
    { duration: '1m30s', target: 20 }, // Stay for 1:30
    { duration: '20s', target: 0 },    // Ramp down
  ],

  thresholds: {
    http_req_duration: ['p(95)<1000', 'p(99)<2000'],  // Local thresholds (looser)
    http_req_failed: ['rate<0.1'],                     // <10% failure
  },
};

// Test endpoints
export default function () {
  const BASE_URL = 'http://localhost:8003'; // Change to 8443 for HTTPS
  
  // 1. Health check (should be instant)
  let res = http.get(`${BASE_URL}/health`);
  check(res, {
    'health status 200': (r) => r.status === 200,
    'health response time < 100ms': (r) => r.timings.duration < 100,
  });

  sleep(0.5);

  // 2. Swagger/Docs (return HTML)
  res = http.get(`${BASE_URL}/docs`);
  check(res, {
    'docs status 200': (r) => r.status === 200,
    'docs returns HTML': (r) => r.headers['content-type'].includes('text/html'),
  });

  sleep(1);

  // 3. Get routes (internal diagnostics)
  res = http.get(`${BASE_URL}/__routes__`);
  check(res, {
    'routes endpoint 200': (r) => r.status === 200 || r.status === 403, // May be protected
    'routes response time < 500ms': (r) => r.timings.duration < 500,
  });

  sleep(0.5);
}

// Summary will show in console when test completes
export function handleSummary(data) {
  console.log('Load Test Summary');
  console.log('================');
  console.log(`Total Requests: ${data.metrics.http_reqs.value || 0}`);
  console.log(`Failed: ${data.metrics.http_req_failed.value || 0}`);
  console.log(`Duration: ${data.metrics.http_req_duration.value || 0}ms (avg)`);
}
