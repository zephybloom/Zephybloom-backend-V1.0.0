import http from 'k6/http';
import { check, sleep } from 'k6';

// Test configuration
export const options = {
  // Target: 100 concurrent users
  vus: 100,
  // Run for 5 minutes
  duration: '5m',
  
  // Ramp-up: start with 10 users, reach 100 in 30 seconds
  stages: [
    { duration: '30s', target: 100 },   // Ramp up
    { duration: '4m', target: 100 },    // Stay at 100 VUs
    { duration: '30s', target: 0 },     // Ramp down
  ],

  // Thresholds for Pass/Fail
  thresholds: {
    http_req_duration: ['p(95)<500', 'p(99)<1000'], // 95th percentile < 500ms, 99th < 1000ms
    http_req_failed: ['rate<0.1'],                    // Error rate < 10%
  },

  // Reporting
  ext: {
    loadimpact: {
      projectID: 1, // Change this to your actual project ID
      name: 'ZephyBloom CFO API - 100 Users Load Test'
    }
  }
};

// Test function - runs for each VU
export default function () {
  // API endpoint configuration
  const baseUrl = __ENV.API_URL || 'http://localhost:8002';
  const tenantId = `tenant-${__VU}`; // Each VU gets their own tenant

  // Test 1: Health check
  const healthRes = http.get(`${baseUrl}/health`);
  check(healthRes, {
    'Health status is 200': (r) => r.status === 200,
    'Health response time': (r) => r.timings.duration < 100,
  });

  sleep(0.5);

  // Test 2: CFO Analysis
  const analyzePayload = JSON.stringify({
    fatturato: 1000000 + __VU * 1000,  // Vary the amount by VU
    costi_variabili: 400000,
    costi_fissi: 300000,
    investimenti: 100000,
    company_name: `Company-${__VU}`,
    settore: 'manufacturing',
  });

  const analyzeRes = http.post(
    `${baseUrl}/cfo/ai-analyze`,
    analyzePayload,
    {
      headers: {
        'Content-Type': 'application/json',
        'X-Tenant-Id': tenantId,
      },
      timeout: '30s',
    }
  );

  check(analyzeRes, {
    'CFO Analysis status is 200 or 422': (r) => r.status === 200 || r.status === 422,
    'CFO Analysis response time < 2 sec': (r) => r.timings.duration < 2000,
    'CFO Analysis has response': (r) => r.body.length > 0,
  });

  sleep(1);

  // Test 3: Simulate scenario
  const simulatePayload = JSON.stringify({
    fatturato: 1000000 + __VU * 1000,
    costi_variabili: 400000,
    costi_fissi: 300000,
    investimenti: 100000,
    company_name: `Company-${__VU}`,
    settore: 'manufacturing',
    scenario: {
      type: 'cost_reduction',
      target_amount_eur: 50000,
    },
  });

  const simulateRes = http.post(
    `${baseUrl}/cfo/simulate`,
    simulatePayload,
    {
      headers: {
        'Content-Type': 'application/json',
        'X-Tenant-Id': tenantId,
      },
      timeout: '30s',
    }
  );

  check(simulateRes, {
    'Simulate status is 200 or 422': (r) => r.status === 200 || r.status === 422,
    'Simulate response time < 2 sec': (r) => r.timings.duration < 2000,
  });

  sleep(2);
}
