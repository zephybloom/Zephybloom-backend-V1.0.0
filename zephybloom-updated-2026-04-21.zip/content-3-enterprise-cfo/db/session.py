"""
Database session and connection management for FastAPI.

Provides:
- Session dependency injection for FastAPI routes
- Connection pooling
- Transaction management
- Async session factory (if needed for async routes)
"""

from __future__ import annotations
from typing import Generator, Optional

from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy import create_engine

from api.config import settings
from db.models import Base, init_db

# Global session factory
_SessionLocal: Optional[sessionmaker] = None


def init_session_factory():
    """Initialize the global session factory - call this in main.py startup."""
    global _SessionLocal
    if _SessionLocal is not None:
        return _SessionLocal  # Already initialized
    
    # Determine pool size based on environment
    pool_size = int(settings.DB_POOL_SIZE or 20)
    max_overflow = int(settings.DB_MAX_OVERFLOW or 40)
    
    # For production, ensure reasonable minimums
    if settings.ENV == "production":
        pool_size = max(pool_size, 50)
        max_overflow = max(max_overflow, 100)
    
    engine = create_engine(
        settings.DATABASE_URL,
        echo=settings.DB_ECHO or settings.DEBUG,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_recycle=3600,  # Recycle connections after 1 hour
        pool_pre_ping=True,  # Test connection before using
        connect_args={
            "timeout": 10,  # Connection timeout
            "check_same_thread": False,  # For SQLite only
        } if "sqlite" in settings.DATABASE_URL else {},
    )
    _SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
    # Create all tables
    Base.metadata.create_all(engine)
    print(
        f"✅ Database initialized: {settings.DATABASE_URL} "
        f"(pool_size={pool_size}, max_overflow={max_overflow})"
    )
    return _SessionLocal


def get_session() -> Generator[Session, None, None]:
    """
    FastAPI dependency for database session.
    
    Usage in route:
        @router.get("/data")
        def get_data(db: Session = Depends(get_session)):
            user = db.query(User).first()
            return user
    """
    # Auto-initialize if not already done
    if _SessionLocal is None:
        init_session_factory()
    
    session = _SessionLocal()
    try:
        yield session
    finally:
        session.close()


def get_session_sync() -> Session:
    """Get a synchronous session (for scripts, CLI, etc.)."""
    if _SessionLocal is None:
        init_session_factory()
    return _SessionLocal()


