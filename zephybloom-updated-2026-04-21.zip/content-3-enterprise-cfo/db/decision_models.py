"""
Database models for Strategic Memory and Decision History

Tracks company decisions over time for:
- Trend analysis (revenue/margin/cash changes)
- Decision effectiveness (did we follow through? did it work?)
- Historical context (why did we make this choice?)
"""

from datetime import datetime
from typing import Optional, List
from sqlalchemy import Column, String, Float, Integer, DateTime, Boolean, JSON, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Company(Base):
    """Company profile"""
    __tablename__ = "companies"
    
    id = Column(String, primary_key=True)
    name = Column(String, required=True)
    sector = Column(String)
    size = Column(String)  # small, medium, large
    phase = Column(String)  # startup, growth, scale, harvest
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationships
    snapshots = relationship("CompanySnapshot", back_populates="company", cascade="all, delete-orphan")
    decisions = relationship("CompanyDecision", back_populates="company", cascade="all, delete-orphan")
    recommendations = relationship("Recommendation", back_populates="company", cascade="all, delete-orphan")


class CompanySnapshot(Base):
    """Monthly financial snapshot"""
    __tablename__ = "company_snapshots"
    
    id = Column(String, primary_key=True)
    company_id = Column(String, ForeignKey("companies.id"), required=True)
    
    # Financial metrics
    fatturato = Column(Float)  # Revenue
    gross_profit = Column(Float)
    gross_margin_pct = Column(Float)
    
    ebitda = Column(Float)
    ebitda_margin_pct = Column(Float)
    
    net_profit = Column(Float)
    net_margin_pct = Column(Float)
    
    working_capital = Column(Float)
    cash_balance = Column(Float)
    ccc_days = Column(Integer)  # Cash conversion cycle
    
    # Operational metrics
    headcount = Column(Integer)
    headcount_cost_total = Column(Float)
    headcount_cost_pct = Column(Float)  # As % of revenue
    
    # Growth metrics
    yoy_revenue_growth = Column(Float)
    yoy_margin_growth = Column(Float)
    
    # Date
    snapshot_date = Column(DateTime, required=True)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationships
    company = relationship("Company", back_populates="snapshots")


class CompanyDecision(Base):
    """Recorded strategic decision"""
    __tablename__ = "company_decisions"
    
    id = Column(String, primary_key=True)
    company_id = Column(String, ForeignKey("companies.id"), required=True)
    
    # Decision details
    title = Column(String, required=True)
    description = Column(String)
    verdict = Column(String)  # GO, MAYBE, WAIT, BUILD_FIRST
    
    # Impact
    expected_impact_eur = Column(Float)
    expected_timeline_days = Column(Integer)
    priority_score = Column(Float)  # 0-100
    
    # Follow-up
    was_implemented = Column(Boolean, default=False)
    implementation_date = Column(DateTime)
    actual_impact_eur = Column(Float)  # Record actual outcome
    
    # Context
    entrepreneur_objections = Column(String)  # Free text: what resistance?
    market_conditions = Column(String)  # Market context at decision time
    
    # Dates
    decision_date = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationships
    company = relationship("Company", back_populates="decisions")


class Recommendation(Base):
    """Individual recommendation to entrepreneur"""
    __tablename__ = "recommendations"
    
    id = Column(String, primary_key=True)
    company_id = Column(String, ForeignKey("companies.id"), required=True)
    
    # Recommendation
    title = Column(String, required=True)
    description = Column(String)
    category = Column(String)  # margin, cash, hiring, strategy, etc.
    
    # Context
    tone = Column(String)  # SOFT, COMPETENT, FIRM, DIRECT, HARSH, MANAGER, MOTIVATOR
    confidence_pct = Column(Float)  # How sure are we?
    
    # Impact
    estimated_impact_eur = Column(Float)
    effort_hours = Column(Integer)
    roi_score = Column(Float)
    
    # Follow-up
    entrepreneur_response = Column(String)  # What did they say? (GO/MAYBE/NO/WAIT)
    was_accepted = Column(Boolean)
    outcome = Column(String)  # What actually happened?
    
    # Action plan
    action_plan_24h = Column(JSON)  # Dict of actions
    action_plan_7gg = Column(JSON)
    action_plan_30gg = Column(JSON)
    
    # Dates
    recommendation_date = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationships
    company = relationship("Company", back_populates="recommendations")


class TrendAnalysis(Base):
    """Pre-computed trend analysis"""
    __tablename__ = "trend_analyses"
    
    id = Column(String, primary_key=True)
    company_id = Column(String, ForeignKey("companies.id"), required=True)
    
    # Trend periods
    period = Column(String)  # 1m, 3m, 6m, 12m
    
    # Deltas
    revenue_change_pct = Column(Float)
    margin_change_pp = Column(Float)  # percentage points
    cash_change_pct = Column(Float)
    headcount_change_pct = Column(Float)
    
    # Narrative
    narrative = Column(String)  # Human-readable summary
    
    # Recommendation impact
    recommendations_count = Column(Integer)
    recommendations_accepted_pct = Column(Float)
    average_outcome_score = Column(Float)  # How much did recommendations help? 0-10
    
    # Dates
    analysis_date = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)


class WowMoment(Base):
    """Memorable insight from analysis"""
    __tablename__ = "wow_moments"
    
    id = Column(String, primary_key=True)
    company_id = Column(String, ForeignKey("companies.id"), required=True)
    
    # Insight
    title = Column(String, required=True)
    description = Column(String)
    category = Column(String)  # opportunity, warning, insight, pattern
    
    # Impact
    memorability_score = Column(Float)  # 1-10
    entrepreneurial_value = Column(String)  # What's the value? In words.
    
    # Data backing
    supporting_metric_name = Column(String)
    supporting_metric_value = Column(Float)
    
    # Dates
    moment_date = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)


# ===== Helper functions =====

def get_company_snapshots(session, company_id: str, months: int = 12) -> List[CompanySnapshot]:
    """Get recent snapshots for a company"""
    from datetime import timedelta
    cutoff = datetime.now() - timedelta(days=30 * months)
    return session.query(CompanySnapshot).filter(
        CompanySnapshot.company_id == company_id,
        CompanySnapshot.snapshot_date >= cutoff,
    ).order_by(CompanySnapshot.snapshot_date).all()


def get_decision_effectiveness(session, company_id: str) -> float:
    """Score: 0-100. How good were the decisions?"""
    decisions = session.query(CompanyDecision).filter(
        CompanyDecision.company_id == company_id,
        CompanyDecision.was_implemented == True,
    ).all()
    
    if not decisions:
        return 50.0  # Default: unknown
    
    # Score: (actual impact / expected impact) * 100
    # Capped at 150 (overperformed) or 0 (negative)
    scores = []
    for d in decisions:
        if d.expected_impact_eur and d.actual_impact_eur:
            score = min(150, max(0, (d.actual_impact_eur / d.expected_impact_eur) * 100))
            scores.append(score)
    
    return sum(scores) / len(scores) if scores else 50.0


def get_trend_narrative(session, company_id: str, period: str = "3m") -> Optional[str]:
    """Get narrative for a company's trend"""
    analysis = session.query(TrendAnalysis).filter(
        TrendAnalysis.company_id == company_id,
        TrendAnalysis.period == period,
    ).order_by(TrendAnalysis.analysis_date.desc()).first()
    
    return analysis.narrative if analysis else None
