"""
SQLAlchemy database models for ZephyBloom CFO API.

Tables:
  - users: Authentication and user profiles
  - api_keys: API key management per user/tenant
  - tenants: Multi-tenant organization contexts
  - audit_logs: Compliance and debugging logs
  - tenant_settings: Tenant-specific configurations

All models support multi-tenancy via tenant_id foreign key.
"""

from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, Text,
    ForeignKey, Index, UniqueConstraint, create_engine
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

Base = declarative_base()


class User(Base):
    """User account with authentication."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=True)
    role = Column(String(50), nullable=False, default="user")  # admin, user, viewer
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    tenants = relationship("Tenant", back_populates="owner")
    api_keys = relationship("APIKey", back_populates="user", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user")

    __table_args__ = (
        Index("idx_user_email", "email"),
        Index("idx_user_active", "is_active"),
    )


class Tenant(Base):
    """Organization/workspace container for multi-tenancy."""
    __tablename__ = "tenants"

    id = Column(String(128), primary_key=True)  # slug-based: "acme-corp"
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    owner = relationship("User", back_populates="tenants")
    api_keys = relationship("APIKey", back_populates="tenant", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="tenant")
    settings = relationship("TenantSettings", back_populates="tenant", uselist=False, cascade="all, delete-orphan")

    __table_args__ = (
        Index("idx_tenant_active", "is_active"),
        Index("idx_tenant_owner", "owner_id"),
    )


class APIKey(Base):
    """API key for programmatic access with rate limiting."""
    __tablename__ = "api_keys"

    id = Column(Integer, primary_key=True)
    key = Column(String(255), unique=True, nullable=False, index=True)  # hashed
    name = Column(String(255), nullable=False)  # "Mobile App", "Data Pipeline", etc.
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False)
    rate_limit_per_minute = Column(Integer, default=100, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=True)  # Optional expiry
    
    # Relationships
    user = relationship("User", back_populates="api_keys")
    tenant = relationship("Tenant", back_populates="api_keys")

    __table_args__ = (
        Index("idx_apikey_active", "is_active"),
        Index("idx_apikey_tenant", "tenant_id"),
        Index("idx_apikey_user", "user_id"),
        UniqueConstraint("tenant_id", "name", name="uq_apikey_tenant_name"),
    )


class AuditLog(Base):
    """Compliance and debugging log for all actions."""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    action = Column(String(100), nullable=False)  # "kpi_compute", "simulate", "login", etc.
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=True)
    api_key_id = Column(Integer, ForeignKey("api_keys.id"), nullable=True)
    endpoint = Column(String(255), nullable=False)  # "/api/kpi/compute"
    method = Column(String(10), nullable=False)  # GET, POST, etc.
    status_code = Column(Integer, nullable=False)
    response_time_ms = Column(Integer, nullable=False)
    request_details = Column(Text, nullable=True)  # JSON
    error_message = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv4 or IPv6
    user_agent = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")
    tenant = relationship("Tenant", back_populates="audit_logs")

    __table_args__ = (
        Index("idx_auditlog_action", "action"),
        Index("idx_auditlog_tenant", "tenant_id"),
        Index("idx_auditlog_user", "user_id"),
        Index("idx_auditlog_timestamp", "created_at"),
        Index("idx_auditlog_endpoint", "endpoint"),
    )


class TenantSettings(Base):
    """Tenant-specific configuration (features, rate limits, etc.)."""
    __tablename__ = "tenant_settings"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), unique=True, nullable=False)
    rate_limit_per_minute = Column(Integer, default=1000, nullable=False)  # Default for all tenant APIs
    max_concurrent_requests = Column(Integer, default=50, nullable=False)
    enable_kpi_engine = Column(Boolean, default=True, nullable=False)
    enable_simulation = Column(Boolean, default=True, nullable=False)
    enable_valuation = Column(Boolean, default=True, nullable=False)
    max_request_size_mb = Column(Integer, default=10, nullable=False)
    data_retention_days = Column(Integer, default=90, nullable=False)
    custom_settings = Column(Text, nullable=True)  # JSON for extensibility
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    tenant = relationship("Tenant", back_populates="settings")

    __table_args__ = (
        Index("idx_tenantsettings_tenant", "tenant_id"),
    )


class Decision(Base):
    """Tracks strategic decisions made by the CFO AI system."""
    __tablename__ = "decisions"

    id = Column(String(128), primary_key=True)  # UUID: decision_20260415_acme_001
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    company_id = Column(String(128), nullable=False, index=True)  # Company being analyzed
    company_name = Column(String(255), nullable=False)
    company_size_eur = Column(Float, nullable=False)  # Annual revenue at time of decision
    industry = Column(String(100), nullable=False)  # saas, retail, manufacturing, etc.
    
    # Decision details
    decision_title = Column(String(255), nullable=False)  # "Increase Gross Margin", etc.
    decision_description = Column(Text, nullable=False)
    decision_verdict = Column(String(50), nullable=False)  # "GO", "MAYBE", "WAIT", "BUILD_FIRST"
    
    # Expected impact
    expected_impact_eur = Column(Float, nullable=False)  # What we expected to happen
    expected_timeframe_days = Column(Integer, nullable=False, default=90)  # 24h, 7gg, 30gg
    priority = Column(String(50), nullable=False)  # "CRITICAL", "HIGH", "MEDIUM", "LOW"
    
    # Implementation tracking
    was_implemented = Column(Boolean, nullable=True)  # YES/NO/PARTIALLY (null = no feedback yet)
    implementation_date = Column(DateTime(timezone=True), nullable=True)
    implementation_notes = Column(Text, nullable=True)
    
    # Feedback
    actual_impact_eur = Column(Float, nullable=True)  # What actually happened
    lessons_learned = Column(Text, nullable=True)
    mistakes = Column(Text, nullable=True)
    success_factors = Column(Text, nullable=True)
    
    # Metadata
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    feedback_received_at = Column(DateTime(timezone=True), nullable=True)  # When feedback was given
    
    # Relationships
    tenant = relationship("Tenant")

    __table_args__ = (
        Index("idx_decision_tenant", "tenant_id"),
        Index("idx_decision_company", "company_id"),
        Index("idx_decision_industry", "industry"),
        Index("idx_decision_verdict", "decision_verdict"),
        Index("idx_decision_created", "created_at"),
        Index("idx_decision_with_feedback", "was_implemented"),
    )


class DecisionAccuracy(Base):
    """Aggregated accuracy metrics per tenant and timeframe."""
    __tablename__ = "decision_accuracy"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    
    # Timeframe
    period_start = Column(DateTime(timezone=True), nullable=False)  # e.g., beginning of month
    period_end = Column(DateTime(timezone=True), nullable=False)
    
    # Metrics
    total_decisions = Column(Integer, default=0, nullable=False)
    decisions_with_feedback = Column(Integer, default=0, nullable=False)
    implemented_count = Column(Integer, default=0, nullable=False)
    implementation_rate = Column(Float, default=0.0, nullable=False)  # Percentage 0-1
    
    # Accuracy (for those implemented)
    target_hit_count = Column(Integer, default=0, nullable=False)  # Within 20% of target
    accuracy_rate = Column(Float, default=0.0, nullable=False)  # Percentage 0-1
    
    # Variance analysis
    average_variance_pct = Column(Float, default=0.0, nullable=False)  # Avg % deviation from target
    max_positive_variance_pct = Column(Float, nullable=True)
    max_negative_variance_pct = Column(Float, nullable=True)
    
    # Success/failure patterns (JSON string)
    success_decision_types = Column(Text, nullable=True)  # ["Pricing", "Cost Reduction", ...]
    failure_decision_types = Column(Text, nullable=True)  # ["Hiring", "Capital Investment", ...]
    
    # Learning adjustments applied
    threshold_adjustments = Column(Text, nullable=True)  # JSON: {"pricing": 0.8, "hiring": 1.5}
    
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    tenant = relationship("Tenant")

    __table_args__ = (
        Index("idx_accuracy_tenant", "tenant_id"),
        Index("idx_accuracy_period", "period_start", "period_end"),
    )


class WarRoomDecisionMemory(Base):
    """Persistent memory for War Room decisions and outcomes."""
    __tablename__ = "war_room_decision_memory"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    decision_id = Column(String(128), nullable=False, index=True)

    source = Column(String(50), default="war_room", nullable=False)
    sector = Column(String(100), nullable=True, index=True)
    decision_type = Column(String(100), nullable=True, index=True)
    rank = Column(Integer, nullable=True)
    owner = Column(String(255), nullable=True)
    status = Column(String(50), default="todo", nullable=False, index=True)

    decision = Column(Text, nullable=True)
    next_action = Column(Text, nullable=True)
    success_metric_json = Column(Text, nullable=True)
    evidence_needed_json = Column(Text, nullable=True)
    follow_up_question = Column(Text, nullable=True)

    expected_impact_eur = Column(Float, nullable=True)
    actual_impact_eur = Column(Float, nullable=True)
    outcome_review_json = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    tenant = relationship("Tenant")

    __table_args__ = (
        UniqueConstraint("tenant_id", "decision_id", name="uq_war_room_decision_tenant_decision"),
        Index("idx_war_room_decision_tenant_status", "tenant_id", "status"),
        Index("idx_war_room_decision_tenant_sector", "tenant_id", "sector"),
    )


class CompanyMetricsHistory(Base):
    """Historical financial metrics for trend analysis."""
    __tablename__ = "company_metrics_history"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    company_id = Column(String(128), nullable=False, index=True)  # Company identifier for tenant
    company_name = Column(String(255), nullable=False)
    
    # Period of measurement (e.g., April 2026, May 2026)
    period_month = Column(Integer, nullable=False)  # 1-12
    period_year = Column(Integer, nullable=False)
    period_date = Column(DateTime(timezone=True), nullable=False, index=True)  # First day of month for sorting
    
    # Key financial metrics (all in EUR)
    fatturato = Column(Float, nullable=False)  # Revenue
    costi_variabili = Column(Float, nullable=False)  # Variable costs
    costi_fissi = Column(Float, nullable=False)  # Fixed costs
    investimenti = Column(Float, nullable=True)  # Capital expenditures
    
    # Derived metrics (calculated)
    gross_profit = Column(Float, nullable=False)  # fatturato - costi_variabili
    gross_margin_pct = Column(Float, nullable=False)  # (gross_profit / fatturato) * 100
    ebitda = Column(Float, nullable=False)  # gross_profit - costi_fissi
    ebitda_margin_pct = Column(Float, nullable=False)  # (ebitda / fatturato) * 100
    net_profit = Column(Float, nullable=False)  # fatturato - costi_variabili - costi_fissi
    net_margin_pct = Column(Float, nullable=False)  # (net_profit / fatturato) * 100
    roi_pct = Column(Float, nullable=True)  # (net_profit / investimenti) * 100 if investimenti > 0
    
    # Additional context
    industry = Column(String(100), nullable=True)  # saas, retail, manufacturing, etc.
    company_size = Column(String(50), nullable=True)  # small, medium, large
    notes = Column(Text, nullable=True)  # Free-form notes on this period
    
    # Metadata
    data_quality = Column(String(50), default="actual", nullable=False)  # actual, estimated, projected
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relationships
    tenant = relationship("Tenant")
    
    __table_args__ = (
        Index("idx_metrics_tenant", "tenant_id"),
        Index("idx_metrics_company", "company_id"),
        Index("idx_metrics_period", "period_year", "period_month"),
        Index("idx_metrics_date", "period_date"),
        Index("idx_metrics_tenant_company", "tenant_id", "company_id"),
        UniqueConstraint("tenant_id", "company_id", "period_year", "period_month", 
                        name="uq_metrics_tenant_company_period"),
    )


class CompanyDataRoomSnapshot(Base):
    """Persistent structured Data Room per tenant/company."""
    __tablename__ = "company_data_room_snapshots"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    company_id = Column(String(128), nullable=False, index=True)
    company_name = Column(String(255), nullable=False)
    active_sector = Column(String(100), nullable=True, index=True)

    company_data_json = Column(Text, nullable=False, default="{}")
    operational_data_by_sector_json = Column(Text, nullable=False, default="{}")
    import_summary_json = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    tenant = relationship("Tenant")

    __table_args__ = (
        UniqueConstraint("tenant_id", "company_id", name="uq_data_room_tenant_company"),
        Index("idx_data_room_tenant_company", "tenant_id", "company_id"),
        Index("idx_data_room_tenant_sector", "tenant_id", "active_sector"),
    )


class CompanyDataRoomSnapshotHistory(Base):
    """Version history for persistent Data Room snapshots."""
    __tablename__ = "company_data_room_snapshot_history"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(String(128), ForeignKey("tenants.id"), nullable=False, index=True)
    company_id = Column(String(128), nullable=False, index=True)
    company_name = Column(String(255), nullable=False)
    active_sector = Column(String(100), nullable=True, index=True)

    company_data_json = Column(Text, nullable=False, default="{}")
    operational_data_by_sector_json = Column(Text, nullable=False, default="{}")
    import_summary_json = Column(Text, nullable=True)
    readiness_score_pct = Column(Float, nullable=True)
    sector_count = Column(Integer, nullable=False, default=0)
    row_count = Column(Integer, nullable=False, default=0)
    change_reason = Column(String(100), nullable=True)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False, index=True)

    tenant = relationship("Tenant")

    __table_args__ = (
        Index("idx_data_room_history_tenant_company", "tenant_id", "company_id"),
        Index("idx_data_room_history_created", "created_at"),
    )


# Database session factory (to be used in main.py)
def create_db_engine(database_url: str):
    """Create SQLAlchemy engine from database URL."""
    return create_engine(
        database_url,
        echo=False,  # Set to True for SQL debugging
        pool_size=20,
        max_overflow=40,
        pool_pre_ping=True,  # Test connections before using
    )


def get_session_factory(database_url: str):
    """Create sessionmaker factory."""
    engine = create_db_engine(database_url)
    return sessionmaker(bind=engine, expire_on_commit=False)


def init_db(database_url: str):
    """Initialize database with all tables."""
    engine = create_db_engine(database_url)
    Base.metadata.create_all(engine)
    return engine
