"""
Cache decorator for expensive computations.

Features:
- Redis backend with fallback to in-memory LRU
- TTL support
- Automatic key generation
- Graceful degradation if cache unavailable
"""

from __future__ import annotations
import json
import hashlib
import time
import inspect
from typing import Callable, Optional, Any, Dict
from functools import wraps
import logging

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

from functools import lru_cache

log = logging.getLogger(__name__)

# Global cache instance
_redis_client: Optional[Any] = None
_in_memory_cache: Dict[str, Any] = {}


def init_cache(redis_url: Optional[str] = None) -> None:
    """Initialize cache backend."""
    global _redis_client
    if redis_url and REDIS_AVAILABLE:
        try:
            _redis_client = redis.from_url(redis_url, decode_responses=True)
            _redis_client.ping()
            log.info("✅ Cache: Redis connected")
        except Exception as e:
            log.warning(f"⚠️ Cache: Redis failed, using in-memory: {e}")


def _get_cache_key(prefix: str, data: Dict[str, Any]) -> str:
    """Generate cache key from prefix and data."""
    data_str = json.dumps(data, sort_keys=True, default=str)
    data_hash = hashlib.md5(data_str.encode()).hexdigest()
    return f"{prefix}:{data_hash}"


def cached(
    prefix: str = "cache",
    ttl: int = 600,
    max_in_memory: int = 1000,
) -> Callable:
    """
    Decorator to cache function results.
    
    Args:
        prefix: Cache key prefix
        ttl: Time-to-live in seconds (Redis only)
        max_in_memory: Max entries in-memory before LRU eviction
        
    Usage:
        @cached("cfo", ttl=600)
        def expensive_analysis(fatturato, settore):
            return compute_analysis(fatturato, settore)
    """
    def decorator(func: Callable) -> Callable:
        signature = inspect.signature(func)

        async def _store_result(cache_key: str, result: Any) -> Any:
            # Store in Redis
            if _redis_client:
                try:
                    result_json = json.dumps(result, default=str)
                    _redis_client.setex(cache_key, ttl, result_json)
                except Exception as e:
                    log.warning(f"Cache set error: {e}")

            # Store in memory with LRU eviction
            if len(_in_memory_cache) >= max_in_memory:
                oldest_key = min(
                    _in_memory_cache.keys(),
                    key=lambda k: _in_memory_cache[k]["expires_at"]
                )
                del _in_memory_cache[oldest_key]

            _in_memory_cache[cache_key] = {
                "value": result,
                "expires_at": time.time() + ttl,
            }

            return result

        def _cache_key(args: tuple, kwargs: Dict[str, Any]) -> str:
            cache_data = {
                "args": [str(a) for a in args],
                "kwargs": {k: str(v) for k, v in kwargs.items()},
            }
            return _get_cache_key(prefix, cache_data)

        def _get_cached(cache_key: str) -> tuple[bool, Any]:
            if _redis_client:
                try:
                    cached_value = _redis_client.get(cache_key)
                    if cached_value is not None:
                        return True, json.loads(cached_value)
                except Exception as e:
                    log.warning(f"Cache get error: {e}")

            if cache_key in _in_memory_cache:
                cached_entry = _in_memory_cache[cache_key]
                if time.time() < cached_entry["expires_at"]:
                    return True, cached_entry["value"]
                del _in_memory_cache[cache_key]

            return False, None

        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs) -> Any:
                cache_key = _cache_key(args, kwargs)
                hit, value = _get_cached(cache_key)
                if hit:
                    return value

                result = await func(*args, **kwargs)
                return await _store_result(cache_key, result)

            async_wrapper.__signature__ = signature  # type: ignore[attr-defined]
            return async_wrapper

        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            cache_key = _cache_key(args, kwargs)
            hit, value = _get_cached(cache_key)
            if hit:
                return value

            result = func(*args, **kwargs)
            # Reuse the same storage logic without forcing sync callers to await.
            if _redis_client:
                try:
                    result_json = json.dumps(result, default=str)
                    _redis_client.setex(cache_key, ttl, result_json)
                except Exception as e:
                    log.warning(f"Cache set error: {e}")

            if len(_in_memory_cache) >= max_in_memory:
                oldest_key = min(
                    _in_memory_cache.keys(),
                    key=lambda k: _in_memory_cache[k]["expires_at"]
                )
                del _in_memory_cache[oldest_key]

            _in_memory_cache[cache_key] = {
                "value": result,
                "expires_at": time.time() + ttl,
            }

            return result

        wrapper.__signature__ = signature  # type: ignore[attr-defined]
        return wrapper
    return decorator


def clear_cache(prefix: Optional[str] = None) -> None:
    """Clear cache entries."""
    global _in_memory_cache
    if prefix:
        # Clear in-memory
        _in_memory_cache = {
            k: v for k, v in _in_memory_cache.items()
            if not k.startswith(f"{prefix}:")
        }
        # Clear Redis
        if _redis_client:
            try:
                cursor = 0
                while True:
                    cursor, keys = _redis_client.scan(
                        cursor,
                        match=f"{prefix}:*",
                        count=100,
                    )
                    if keys:
                        _redis_client.delete(*keys)
                    if cursor == 0:
                        break
            except Exception as e:
                log.warning(f"Cache clear error: {e}")
    else:
        _in_memory_cache.clear()
        if _redis_client:
            try:
                _redis_client.flushdb()
            except Exception:
                pass
