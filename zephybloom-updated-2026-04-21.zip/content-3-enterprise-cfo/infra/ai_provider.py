"""
OpenAI/ChatGPT Integration for CFO Analysis
Provides Claude-style responses with professional CFO template
"""

import os
import json
import re
from typing import Dict, Optional, List
from dataclasses import dataclass
from enum import Enum

from api.config import settings

try:
    from openai import OpenAI
except ImportError:
    raise ImportError("openai not installed. Run: pip install openai")


class AIProvider(str, Enum):
    """Supported AI providers"""
    OPENAI = "openai"
    MOCK = "mock"


@dataclass
class CFOAnalysisAI:
    """AI-powered CFO analysis response"""
    headline: str
    diagnostic: str  # 🧠 DIAGNOSI
    risk_assessment: str  # ⚠️ RISCHIO
    priority_action: str  # 🎯 AZIONE PRIORITARIA
    other_actions: List[str]  # 📈 ALTRE AZIONI
    estimated_impact: str  # 💥 IMPATTO STIMATO
    why_it_matters: str  # 🧭 PERCHÉ CONTA
    strategic_advice: str  # 🧠 CONSIGLIO STRATEGICO
    key_number: Optional[str] = None  # 📊 NUMERO CHIAVE

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON response"""
        return {
            "key_number": self.key_number or "N/A",
            "headline": self.headline,
            "diagnostic": self.diagnostic,
            "risk_assessment": self.risk_assessment,
            "priority_action": self.priority_action,
            "other_actions": self.other_actions,
            "estimated_impact": self.estimated_impact,
            "why_it_matters": self.why_it_matters,
            "strategic_advice": self.strategic_advice,
        }

    def to_formatted_text(self) -> str:
        """Convert to formatted text response with emoji template"""
        other_actions_text = "\n".join(f"• {_clean_field(action)}" for action in self.other_actions)
        
        return f"""📊 NUMERO CHIAVE
{_clean_field(self.key_number) or 'N/A'}

{_clean_field(self.headline)}

🧠 DIAGNOSI
{_clean_field(self.diagnostic)}

⚠️ RISCHIO
{_clean_field(self.risk_assessment)}

🎯 AZIONE PRIORITARIA
{_clean_field(self.priority_action)}

📈 ALTRE AZIONI
{other_actions_text}

💥 IMPATTO STIMATO
{_clean_field(self.estimated_impact)}

🧭 PERCHÉ CONTA
{_clean_field(self.why_it_matters)}

🧠 CONSIGLIO STRATEGICO
{_clean_field(self.strategic_advice)}"""


SECTION_LABEL_RE = re.compile(
    r"^\s*(?:[📊🧠⚠️🎯📈💥🧭]\s*)?"
    r"(?:NUMERO CHIAVE|DIAGNOSI|RISCHIO|AZIONE PRIORITARIA|ALTRE AZIONI|IMPATTO STIMATO|PERCH[ÉE] CONTA|CONSIGLIO STRATEGICO)\s*:?\s*",
    re.IGNORECASE,
)


def _clean_field(value: Optional[str]) -> str:
    """Remove leaked template labels and simple repeated text from model fields."""
    if not value:
        return ""

    text = str(value).strip()
    text = SECTION_LABEL_RE.sub("", text).strip()
    text = re.sub(r"\s+", " ", text)

    # Some models repeat the same sentence immediately after a colon.
    parts = [part.strip() for part in re.split(r"\s+:\s+", text) if part.strip()]
    if len(parts) >= 2 and parts[0] == parts[1]:
        text = parts[0]

    midpoint = len(text) // 2
    if len(text) > 40 and text[:midpoint].strip() == text[midpoint:].strip():
        text = text[:midpoint].strip()

    return text.strip()


class CFOGPTProvider:
    """ChatGPT provider for CFO analysis"""
    
    SYSTEM_PROMPT = """Tu sei un CFO Senior con 25+ anni di esperienza in multinazionali da €100M-500M+.
Hai expertise in: Financial Strategy, M&A, Cash Flow, Digital Transformation, Board Reporting.

REGOLE CRITICHE DI REASONING:
1. ANALIZZA IL CONTESTO PRIMA DI RISPONDERE:
   - Estrai salute finanziaria: sano / warning / critico
   - Confronta SEMPRE con benchmark settore fornito
   - Riconosci quando la situazione è POSITIVA (margini sopra media, crescita, ROI forte)
   - Non dare warning generici se dati sono forti

2. IDENTIFICA IL VERO PROBLEMA (non il sintomo):
   - Se Gross Margin è SOPRA media settore → non è il problema
   - Se Costi cresciti ma Prezzi fermi → problema è pricing, non volume
   - Se EBITDA/Revenue è forte → azienda sta bene, focus su CRESCITA non turnaround

3. CONSIGLIO DEVE ESSERE SPECIFICO AL CONTESTO:
   - Per azienda in crescita: focus su scaling, capex strategy, reinvestimento
   - Per azienda mature: focus su ottimizzazione, margi, working capital
   - Leggi i TRENDS per capire direction
   - Se CFO_INSIGHT.primary_constraint è fornito, NON contraddirlo
   - Se CFO_INSIGHT.strategic_posture = stabilize, NON proporre crescita aggressiva
   - Non inventare numeri: usa solo numeri presenti nei dati, oppure dichiara assunzioni

4. FORMATO RESPOSTA - SEMPRE questi elementi con emoji (in ordine):
📊 NUMERO CHIAVE: Il KPI #1 che decide la sorte economica (es: "Margine sopra media, crescita sostenuta da price power")
🧠 DIAGNOSI: Root cause analysis in 2 frasi. Se salute è buona: spiega COME mai è buona
⚠️ RISCHIO: Scenario downside CONCRETO nei prossimi 6-12 mesi (€ impact). Se no threat major: spiega la conservazione
🎯 AZIONE PRIORITARIA: La singola cosa che maximizza ROI nei prossimi 30-90 giorni
📈 ALTRE AZIONI: Secondary plays (3-4 max), ordinate per impatto €
💥 IMPATTO STIMATO: €/€ quantification. Es: "€180K risparmi in 6 mesi + €50K working capital release"
🧭 PERCHÉ CONTA: Strategic implication per board/owner. Crescita? Resilienza? Market share?
🧠 CONSIGLIO STRATEGICO: La tua opinione senior. Cosa faresti se fossi CEO. Forward-looking.

STILE:
- Diretto, no politesse, no marketing language
- Numeri concreti ed specifici (€, %)
- Urgenza chiara: SETTIMANE vs MESI vs TRIMESTRI
- Cita i dati usati per la conclusione
- Contraddittore: se dati dicono "no problema" → NON inventi problemi"""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """
        Initialize ChatGPT provider
        
        Args:
            api_key: OpenAI API key (default: settings/env var)
            model: Model to use (default: settings.LLM_MODEL)
        """
        self.api_key = (
            api_key
            or settings.OPENAI_API_KEY
            or os.getenv("OPENAI_API_KEY")
            or os.getenv("ZB_OPENAI_API_KEY")
        )
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY/ZB_OPENAI_API_KEY environment variable not set")
        
        self.client = OpenAI(api_key=self.api_key)
        self.model = model or settings.LLM_MODEL or os.getenv("ZB_LLM_MODEL") or "gpt-4o-mini"
        self.max_tokens = 2000

    def analyze(
        self,
        company_data: Dict,
        specific_question: Optional[str] = None,
        trend_context: Optional[str] = None,
    ) -> CFOAnalysisAI:
        """
        Analyze company data and return AI-powered CFO response
        
        Args:
            company_data: Dictionary with company financials
                - fatturato, costi_variabili, costi_fissi, investimenti
                - optional: gross_profit, ebitda, net_profit, roi_pct
            specific_question: Optional specific question from CEO
            trend_context: Optional historical trends context
            
        Returns:
            CFOAnalysisAI object with structured response
        """
        
        # Build context from company data
        context = self._build_company_context(company_data, trend_context)
        
        # Build user prompt
        if specific_question:
            prompt = f"""Analizza questa situazione aziendale e rispondi alla domanda specifica:

DATI AZIENDALI:
{context}

DOMANDA DEL CEO:
{specific_question}

Rispondi con il formato template descritto."""
        else:
            prompt = f"""Analizza questa situazione aziendale e fornisci una diagnosi strategica:

DATI AZIENDALI:
{context}

Rispondi con il formato template descritto."""
        
        try:
            # Call OpenAI API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=0.2,
            )
            
            # Extract response text
            response_text = response.choices[0].message.content
            
            # Parse response into structured format
            return self._parse_response(response_text, company_data)
            
        except Exception as e:
            raise RuntimeError(f"OpenAI API error: {str(e)}")

    def _build_company_context(self, company_data: Dict, trend_context: Optional[str] = None) -> str:
        """Build text context from company data with intelligence"""
        fatturato = company_data.get("fatturato", 0)
        costi_variabili = company_data.get("costi_variabili", 0)
        costi_fissi = company_data.get("costi_fissi", 0)
        investimenti = company_data.get("investimenti", 0)
        settore = company_data.get("settore", "manufacturing").lower()
        
        # Calculate basic metrics
        gross_profit = fatturato - costi_variabili
        gross_margin = (gross_profit / fatturato * 100) if fatturato > 0 else 0
        ebitda = gross_profit - costi_fissi
        ebitda_margin = (ebitda / fatturato * 100) if fatturato > 0 else 0
        net_profit = ebitda - investimenti
        net_margin = (net_profit / fatturato * 100) if fatturato > 0 else 0
        roi = (net_profit / investimenti * 100) if investimenti > 0 else 0
        
        # BENCHMARK SETTORE (for intelligent comparison)
        benchmarks = {
            "saas": {"gross_margin": 75, "ebitda_margin": 40, "net_margin": 20, "roi": 40},
            "manufacturing": {"gross_margin": 35, "ebitda_margin": 15, "net_margin": 8, "roi": 15},
            "retail": {"gross_margin": 25, "ebitda_margin": 10, "net_margin": 3, "roi": 10},
            "tech": {"gross_margin": 70, "ebitda_margin": 35, "net_margin": 15, "roi": 35},
            "default": {"gross_margin": 30, "ebitda_margin": 18, "net_margin": 10, "roi": 20},
        }
        
        bench = benchmarks.get(settore, benchmarks["default"])
        
        # HEALTH ASSESSMENT
        margin_vs_bench = gross_margin - bench["gross_margin"]
        ebitda_vs_bench = ebitda_margin - bench["ebitda_margin"]
        
        if gross_margin >= bench["gross_margin"] * 0.95 and ebitda_margin >= bench["ebitda_margin"] * 0.85:
            health = "HEALTHY ✅"
            health_color = "verde"
        elif gross_margin >= bench["gross_margin"] * 0.85 or ebitda_margin >= bench["ebitda_margin"] * 0.70:
            health = "CAUTION ⚠️"
            health_color = "yellow"
        else:
            health = "CRITICAL 🔴"
            health_color = "red"
        
        context = f"""AZIENDA: {company_data.get('company_name', 'N/A')}
SETTORE: {settore.upper()}
DIMENSIONE: {company_data.get('company_size', 'Medium')} Azienda

═══════════════════════════════════════════
NUMERI ATTUALI:
═══════════════════════════════════════════
FATTURATO: €{fatturato:,.0f}
Costi Variabili: €{costi_variabili:,.0f} ({costi_variabili/fatturato*100:.1f}% di revenue)
GROSS PROFIT: €{gross_profit:,.0f} → {gross_margin:.1f}%
Costi Fissi: €{costi_fissi:,.0f} ({costi_fissi/fatturato*100:.1f}% di revenue)
EBITDA: €{ebitda:,.0f} → {ebitda_margin:.1f}%
Investimenti: €{investimenti:,.0f}
NET PROFIT: €{net_profit:,.0f} → {net_margin:.1f}%
ROI: {roi:.1f}%

═══════════════════════════════════════════
ASSESSMENT vs BENCHMARK SETTORE ({settore.upper()}):
═══════════════════════════════════════════
STATUS FINANZIARIO: {health}

Gross Margin:
- Azienda: {gross_margin:.1f}%
- Benchmark: {bench['gross_margin']:.1f}%
- Differenza: {margin_vs_bench:+.1f}pp → {"SOPRA MEDIA ✅" if margin_vs_bench > 0 else "SOTTO MEDIA ⚠️"}

EBITDA Margin:
- Azienda: {ebitda_margin:.1f}%
- Benchmark: {bench['ebitda_margin']:.1f}%
- Differenza: {ebitda_vs_bench:+.1f}pp → {"SOPRA MEDIA ✅" if ebitda_vs_bench > 0 else "SOTTO MEDIA ⚠️"}

Net Margin:
- Azienda: {net_margin:.1f}%
- Benchmark: {bench['net_margin']:.1f}%
- Differenza: {net_margin - bench['net_margin']:+.1f}pp → {"competitivo" if abs(net_margin - bench['net_margin']) < 2 else "da verificare"}

ROI:
- Azienda: {roi:.1f}%
- Benchmark: {bench['roi']:.1f}%"""
        
        if trend_context:
            context += f"\n\n═══════════════════════════════════════════\nTRENDS STORICI & CONTESTO:\n═══════════════════════════════════════════\n{trend_context}"

        insight = company_data.get("industry_insight")
        if insight:
            context += (
                "\n\n═══════════════════════════════════════════\n"
                "CFO_INSIGHT VINCOLANTE:\n"
                "═══════════════════════════════════════════\n"
                f"Health label: {insight.get('health_label')}\n"
                f"Strategic posture: {insight.get('strategic_posture')}\n"
                f"Primary constraint: {insight.get('primary_constraint', {}).get('type')}\n"
                f"Constraint summary: {insight.get('primary_constraint', {}).get('summary')}\n"
                f"Risk window: {insight.get('primary_constraint', {}).get('risk_window')}\n"
                f"Next best move: {insight.get('next_best_move', {}).get('move')}\n"
                f"Watch metrics: {', '.join(insight.get('watch_metrics', []))}\n"
            )

        faq_context = company_data.get("faq_context")
        if faq_context:
            context += (
                "\n\n═══════════════════════════════════════════\n"
                "FAQ_KNOWLEDGE VERIFICATA:\n"
                "═══════════════════════════════════════════\n"
                f"Matched question: {faq_context.get('matched_question')}\n"
                f"Category: {faq_context.get('category')}\n"
                f"Answer:\n{faq_context.get('answer')}\n"
            )
        
        return context

    def _parse_response(self, response_text: str, company_data: Dict) -> CFOAnalysisAI:
        """
        Parse ChatGPT response into structured CFOAnalysisAI
        
        Handles both template format and free text responses
        """
        
        # Try to extract sections from template response
        sections = {
            "key_number": self._extract_section(response_text, "📊 NUMERO CHIAVE"),
            "headline": self._extract_section(response_text, "NUMERO CHIAVE"),  # fallback
            "diagnostic": self._extract_section(response_text, "🧠 DIAGNOSI"),
            "risk_assessment": self._extract_section(response_text, "⚠️ RISCHIO"),
            "priority_action": self._extract_section(response_text, "🎯 AZIONE PRIORITARIA"),
            "other_actions": self._extract_bullet_points(response_text, "📈 ALTRE AZIONI"),
            "estimated_impact": self._extract_section(response_text, "💥 IMPATTO STIMATO"),
            "why_it_matters": self._extract_section(response_text, "🧭 PERCHÉ CONTA"),
            "strategic_advice": self._extract_section(response_text, "🧠 CONSIGLIO STRATEGICO"),
        }
        
        # Create headline from key_number if available
        headline = _clean_field(sections.get("key_number", "Analisi Finanziaria Completata"))
        if len(headline) > 150:
            headline = headline[:150] + "..."
        
        return CFOAnalysisAI(
            headline=headline,
            key_number=_clean_field(sections.get("key_number")),
            diagnostic=_clean_field(sections.get("diagnostic", "")),
            risk_assessment=_clean_field(sections.get("risk_assessment", "")),
            priority_action=_clean_field(sections.get("priority_action", "")),
            other_actions=[_clean_field(action) for action in sections.get("other_actions", []) if _clean_field(action)],
            estimated_impact=_clean_field(sections.get("estimated_impact", "")),
            why_it_matters=_clean_field(sections.get("why_it_matters", "")),
            strategic_advice=_clean_field(sections.get("strategic_advice", "")),
        )

    def _extract_section(self, text: str, marker: str, lines: int = 5) -> str:
        """Extract section content after a marker"""
        if marker not in text:
            return ""
        
        parts = text.split(marker)
        if len(parts) < 2:
            return ""
        
        content = parts[1]
        
        # Remove next marker if present
        markers = ["📊", "🧠", "⚠️", "🎯", "📈", "💥", "🧭"]
        for next_marker in markers:
            if next_marker in content:
                content = content.split(next_marker)[0]
                break
        
        # Clean and limit lines
        lines_list = [line.strip() for line in content.split('\n') if line.strip()]
        return '\n'.join(lines_list[:lines]).strip()

    def _extract_bullet_points(self, text: str, marker: str) -> List[str]:
        """Extract bullet points from a section"""
        section = self._extract_section(text, marker, lines=20)
        
        bullet_points = []
        for line in section.split('\n'):
            line = line.strip()
            if line.startswith('•') or line.startswith('-') or line.startswith('*'):
                # Remove bullet char and clean
                clean = line.lstrip('•-* ').strip()
                if clean:
                    bullet_points.append(clean)
            elif line and not line.startswith(('📊', '🧠', '⚠️', '🎯', '📈', '💥', '🧭')):
                # Include non-bullet lines as separate points
                if len(line) > 10:
                    bullet_points.append(line)
        
        return bullet_points[:4]  # Max 4 other actions


class MockCFOGPTProvider:
    """Mock provider for testing (no API key required)"""
    
    def analyze(self, company_data: Dict, specific_question: Optional[str] = None, trend_context: Optional[str] = None) -> CFOAnalysisAI:
        """Return deterministic mock CFO analysis based on provided data."""
        insight = company_data.get("industry_insight") or {}
        primary = insight.get("primary_constraint", {})
        next_move = insight.get("next_best_move", {})
        faq_context = company_data.get("faq_context") or {}
        gross_margin = company_data.get("gross_margin_pct", 0)
        net_margin = company_data.get("net_margin_pct", 0)
        roi = company_data.get("roi_pct", 0)
        health_label = insight.get("health_label", "Needs CFO review")
        constraint_type = primary.get("type", "financial_review")
        constraint_summary = primary.get("summary", "Financial model requires review.")
        move = next_move.get("move", "Improve profitability.")
        watch_metrics = insight.get("watch_metrics", [])[:3]

        other_actions = [f"Monitorare {metric}" for metric in watch_metrics]
        if faq_context:
            other_actions.append(f"Usare FAQ verificata: {faq_context.get('matched_question')}")
        other_actions = other_actions[:4] or ["Aggiornare KPI CFO", "Validare benchmark", "Preparare scenario operativo"]

        return CFOAnalysisAI(
            key_number=f"Gross margin {gross_margin:.1f}%, net margin {net_margin:.1f}%, ROI {roi:.1f}%",
            headline=f"{health_label}: {constraint_type}",
            diagnostic=f"{health_label}. {constraint_summary}",
            risk_assessment=f"Finestra rischio: {primary.get('risk_window', 'da verificare')}.",
            priority_action=move,
            other_actions=other_actions,
            estimated_impact="Impatto da confermare con simulazione scenario dedicata.",
            why_it_matters="Il brief usa KPI, benchmark, vincolo principale e knowledge FAQ prima della narrazione AI.",
            strategic_advice=f"Postura consigliata: {insight.get('strategic_posture', 'review')}.",
        )


def get_ai_provider(provider_type: str = "openai") -> object:
    """
    Factory function to get AI provider instance
    
    Args:
        provider_type: "openai" or "mock"
        
    Returns:
        Provider instance
    """
    if provider_type == "mock":
        return MockCFOGPTProvider()
    elif provider_type == "openai":
        try:
            return CFOGPTProvider()
        except ValueError as e:
            print(f"Warning: {e}. Falling back to mock provider.")
            return MockCFOGPTProvider()
    else:
        raise ValueError(f"Unknown provider: {provider_type}")
