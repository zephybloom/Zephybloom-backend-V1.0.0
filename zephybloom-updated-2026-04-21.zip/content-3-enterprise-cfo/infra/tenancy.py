# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import Optional, Any

DEFAULT_TENANT = "default"
_MAX_TENANT_LEN = 120

# Consenti solo caratteri sicuri per tenant id
_SAFE_TENANT_RE = re.compile(r"[^a-zA-Z0-9_\-:.]")


def _safe_tenant(value: Any) -> str:
    """
    Normalizza un tenant id in stringa sicura.

    Regole:
    - None -> DEFAULT_TENANT
    - cast robusto a stringa
    - trim spazi
    - rimuove caratteri non sicuri
    - limita lunghezza
    - fallback a DEFAULT_TENANT se vuoto
    """
    if value is None:
        return DEFAULT_TENANT

    try:
        tenant = str(value).strip()
    except Exception:
        return DEFAULT_TENANT

    if not tenant:
        return DEFAULT_TENANT

    # Rimuove caratteri strani/non sicuri
    tenant = _SAFE_TENANT_RE.sub("", tenant)

    if not tenant:
        return DEFAULT_TENANT

    return tenant[:_MAX_TENANT_LEN]


def get_tenant_id(
    request: Optional[Any] = None,
    x_tenant_id: Optional[str] = None,
    tenant_q: Optional[str] = None,
) -> str:
    """
    Supporta due modalità:

    1) get_tenant_id(request)
       Estrae:
       - header X-Tenant-Id
       - header x-tenant-id
       - query param tenant_id

    2) get_tenant_id(x_tenant_id="abc", tenant_q="xyz")
       Usa direttamente i valori passati

    Priorità:
    - x_tenant_id esplicito
    - tenant_q esplicito
    - header request
    - query request
    - DEFAULT_TENANT
    """
    req_header_tenant: Optional[str] = None
    req_query_tenant: Optional[str] = None

    if request is not None:
        try:
            headers = getattr(request, "headers", None)
            if headers is not None:
                req_header_tenant = (
                    headers.get("X-Tenant-Id")
                    or headers.get("x-tenant-id")
                )
        except Exception:
            req_header_tenant = None

        try:
            query_params = getattr(request, "query_params", None)
            if query_params is not None:
                req_query_tenant = query_params.get("tenant_id")
        except Exception:
            req_query_tenant = None

    return _safe_tenant(
        x_tenant_id
        or tenant_q
        or req_header_tenant
        or req_query_tenant
        or DEFAULT_TENANT
    )