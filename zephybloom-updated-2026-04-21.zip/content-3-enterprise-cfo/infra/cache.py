# content/infra/cache.py
from __future__ import annotations
from typing import Any, Callable, Dict, Optional, Tuple
import functools
import json
import time
import hashlib
import os

try:
    import redis  # type: ignore
    _HAS_REDIS = True
except Exception:
    _HAS_REDIS = False

def _hash_key(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

class BaseCache:
    def get(self, key: str) -> Optional[str]: ...
    def set(self, key: str, value: str, ttl: int | None = None) -> None: ...

class InMemoryCache(BaseCache):
    def __init__(self) -> None:
        self._store: Dict[str, Tuple[float, str]] = {}

    def get(self, key: str) -> Optional[str]:
        item = self._store.get(key)
        if not item: return None
        exp, val = item
        if exp and exp < time.time():
            self._store.pop(key, None)
            return None
        return val

    def set(self, key: str, value: str, ttl: int | None = None) -> None:
        exp = 0.0 if not ttl else time.time() + int(ttl)
        self._store[key] = (exp, value)

class RedisCache(BaseCache):
    def __init__(self, url: str) -> None:
        self._r = redis.from_url(url)

    def get(self, key: str) -> Optional[str]:
        v = self._r.get(key)
        return v.decode("utf-8") if v else None

    def set(self, key: str, value: str, ttl: int | None = None) -> None:
        if ttl:
            self._r.setex(key, int(ttl), value)
        else:
            self._r.set(key, value)

def _default_cache() -> BaseCache:
    url = os.getenv("REDIS_URL") or ""
    if _HAS_REDIS and url:
        try:
            return RedisCache(url)
        except Exception:
            pass
    return InMemoryCache()

CACHE: BaseCache = _default_cache()

def cacheable(key_builder: Optional[Callable[..., str]] = None, ttl: int = 300):
    """
    @cacheable(lambda *a, **k: f"forecast:{tenant}:{json.dumps(k,sort_keys=True)}", ttl=120)
    """
    def deco(fn: Callable[..., Any]):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            kb = key_builder(*args, **kwargs) if key_builder else f"{fn.__name__}:{args}:{sorted(kwargs.items())}"
            key = _hash_key(kb)
            found = CACHE.get(key)
            if found is not None:
                try:
                    return json.loads(found)
                except Exception:
                    return found
            res = fn(*args, **kwargs)
            try:
                CACHE.set(key, json.dumps(res, ensure_ascii=False), ttl=ttl)
            except Exception:
                pass
            return res
        return wrapper
    return deco
