"""
Circuit breaker pattern for resilience.

Prevents cascading failures in external service calls (LLM, databases, etc.)

States:
- CLOSED: Normal operation, requests pass through
- OPEN: Service failing, requests fail immediately
- HALF_OPEN: Testing if service recovered

Configuration:
- fail_max: Number of failures before opening circuit
- reset_timeout: Seconds to wait before trying again
- success_threshold: Number of successes needed to close
"""

from __future__ import annotations
import time
import logging
from enum import Enum
from typing import Callable, Any, Optional, Dict
from functools import wraps

log = logging.getLogger(__name__)


class CircuitState(str, Enum):
    """Circuit breaker states."""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Service failing
    HALF_OPEN = "half_open"  # Testing recovery


class CircuitBreakerException(Exception):
    """Raised when circuit is open."""
    pass


class CircuitBreaker:
    """Circuit breaker for service calls."""
    
    def __init__(
        self,
        name: str = "default",
        fail_max: int = 5,
        reset_timeout: int = 60,
        success_threshold: int = 2,
    ):
        """
        Args:
            name: Circuit breaker identifier
            fail_max: Failures before opening circuit
            reset_timeout: Seconds to wait before re-trying
            success_threshold: Successes needed to close in HALF_OPEN
        """
        self.name = name
        self.fail_max = fail_max
        self.reset_timeout = reset_timeout
        self.success_threshold = success_threshold
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.last_state_change = time.time()
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute function through circuit breaker.
        
        Raises:
            CircuitBreakerException: If circuit is OPEN
            Original exception: If function fails in CLOSED/HALF_OPEN
        """
        # Check if should transition from OPEN to HALF_OPEN
        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitState.HALF_OPEN
                self.success_count = 0
                log.info(f"🔄 Circuit '{self.name}' HALF_OPEN - testing recovery")
            else:
                raise CircuitBreakerException(
                    f"Circuit '{self.name}' is OPEN (reset in {self._time_until_reset()}s)"
                )
        
        # Execute function
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
    
    def _on_success(self) -> None:
        """Handle successful call."""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.success_threshold:
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                log.info(f"✅ Circuit '{self.name}' CLOSED - service recovered")
        elif self.state == CircuitState.CLOSED:
            self.failure_count = 0
    
    def _on_failure(self) -> None:
        """Handle failed call."""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.state == CircuitState.HALF_OPEN:
            # Immediately re-open
            self.state = CircuitState.OPEN
            log.warning(f"❌ Circuit '{self.name}' OPEN - recovery failed")
        elif self.state == CircuitState.CLOSED:
            if self.failure_count >= self.fail_max:
                self.state = CircuitState.OPEN
                log.warning(
                    f"❌ Circuit '{self.name}' OPEN - {self.failure_count} failures"
                )
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.reset_timeout
    
    def _time_until_reset(self) -> int:
        """Seconds until circuit can attempt reset."""
        if self.last_failure_time is None:
            return 0
        elapsed = time.time() - self.last_failure_time
        return max(0, self.reset_timeout - int(elapsed))
    
    def __repr__(self) -> str:
        return (
            f"CircuitBreaker(name={self.name}, state={self.state}, "
            f"failures={self.failure_count}/{self.fail_max})"
        )


# Global circuit breakers
_breakers: Dict[str, CircuitBreaker] = {}


def get_breaker(name: str = "default", **kwargs) -> CircuitBreaker:
    """Get or create a circuit breaker."""
    if name not in _breakers:
        _breakers[name] = CircuitBreaker(name=name, **kwargs)
    return _breakers[name]


def circuit_breaker(
    name: str = "default",
    fail_max: int = 5,
    reset_timeout: int = 60,
) -> Callable:
    """
    Decorator for circuit breaker pattern.
    
    Usage:
        @circuit_breaker("llm_calls", fail_max=3, reset_timeout=30)
        def call_llm(prompt):
            return llm_client.complete(prompt)
    """
    def decorator(func: Callable) -> Callable:
        breaker = get_breaker(
            name or func.__name__,
            fail_max=fail_max,
            reset_timeout=reset_timeout,
        )
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            return breaker.call(func, *args, **kwargs)
        
        return wrapper
    return decorator
