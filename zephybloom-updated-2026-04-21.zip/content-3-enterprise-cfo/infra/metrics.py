"""
Prometheus metrics for monitoring.

Tracks:
- Request latency per endpoint
- Error rates
- Cache hit rates
- Database connections
- Circuit breaker state
"""

from __future__ import annotations
import time
import logging
import inspect
from typing import Callable, Optional
from functools import wraps
from enum import Enum

try:
    from prometheus_client import (
        Counter, Histogram, Gauge, CollectorRegistry,
        generate_latest, CONTENT_TYPE_LATEST
    )
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Stub classes if Prometheus unavailable
    class Counter:
        def __init__(self, *args, **kwargs): pass
        def inc(self, *args, **kwargs): pass
    class Histogram:
        def __init__(self, *args, **kwargs): pass
        def observe(self, *args, **kwargs): pass
    class Gauge:
        def __init__(self, *args, **kwargs): pass
        def set(self, *args, **kwargs): pass
        def inc(self, *args, **kwargs): pass
        def dec(self, *args, **kwargs): pass

log = logging.getLogger(__name__)

# Create registry
registry = CollectorRegistry() if PROMETHEUS_AVAILABLE else None

# =====================================================
# METRICS
# =====================================================

if PROMETHEUS_AVAILABLE:
    # Request metrics
    http_request_duration_seconds = Histogram(
        "http_request_duration_seconds",
        "HTTP request latency",
        ["method", "endpoint", "status"],
        registry=registry,
    )
    
    http_requests_total = Counter(
        "http_requests_total",
        "Total HTTP requests",
        ["method", "endpoint", "status"],
        registry=registry,
    )
    
    http_errors_total = Counter(
        "http_errors_total",
        "Total HTTP errors",
        ["method", "endpoint", "error_type"],
        registry=registry,
    )
    
    # Cache metrics
    cache_hits_total = Counter(
        "cache_hits_total",
        "Cache hits",
        ["cache_type"],
        registry=registry,
    )
    
    cache_misses_total = Counter(
        "cache_misses_total",
        "Cache misses",
        ["cache_type"],
        registry=registry,
    )
    
    cache_size_bytes = Gauge(
        "cache_size_bytes",
        "Current cache size",
        ["cache_type"],
        registry=registry,
    )
    
    # Database metrics
    db_connections_active = Gauge(
        "db_connections_active",
        "Active database connections",
        registry=registry,
    )
    
    db_connection_pool_size = Gauge(
        "db_connection_pool_size",
        "Database connection pool size",
        registry=registry,
    )
    
    db_query_duration_seconds = Histogram(
        "db_query_duration_seconds",
        "Database query latency",
        ["query_type"],
        registry=registry,
    )
    
    # Circuit breaker metrics
    circuit_breaker_state = Gauge(
        "circuit_breaker_state",
        "Circuit breaker state (0=CLOSED, 1=HALF_OPEN, 2=OPEN)",
        ["breaker_name"],
        registry=registry,
    )
    
    circuit_breaker_failures = Counter(
        "circuit_breaker_failures",
        "Circuit breaker failures",
        ["breaker_name"],
        registry=registry,
    )
    
    # Rate limit metrics
    rate_limit_hits_total = Counter(
        "rate_limit_hits_total",
        "Rate limit hits (exceeded)",
        ["limit_type"],
        registry=registry,
    )
    
    # CFO analysis metrics
    cfo_analysis_duration_seconds = Histogram(
        "cfo_analysis_duration_seconds",
        "CFO analysis computation time",
        ["sector"],
        registry=registry,
    )
    
    cfo_analyses_total = Counter(
        "cfo_analyses_total",
        "Total CFO analyses performed",
        ["sector", "status"],
        registry=registry,
    )

else:
    # Stub implementations
    http_request_duration_seconds = Histogram()
    http_requests_total = Counter()
    http_errors_total = Counter()
    cache_hits_total = Counter()
    cache_misses_total = Counter()
    cache_size_bytes = Gauge()
    db_connections_active = Gauge()
    db_connection_pool_size = Gauge()
    db_query_duration_seconds = Histogram()
    circuit_breaker_state = Gauge()
    circuit_breaker_failures = Counter()
    rate_limit_hits_total = Counter()
    cfo_analysis_duration_seconds = Histogram()
    cfo_analyses_total = Counter()


# =====================================================
# DECORATORS
# =====================================================

def track_request_metrics(endpoint: str) -> Callable:
    """Decorator to track request metrics (latency, errors)."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            method = kwargs.get("method", "UNKNOWN")
            start_time = time.time()
            status = "success"
            
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                http_errors_total.labels(
                    method=method,
                    endpoint=endpoint,
                    error_type=type(e).__name__,
                ).inc()
                raise
            finally:
                duration = time.time() - start_time
                http_request_duration_seconds.labels(
                    method=method,
                    endpoint=endpoint,
                    status=status,
                ).observe(duration)
                http_requests_total.labels(
                    method=method,
                    endpoint=endpoint,
                    status=status,
                ).inc()
        
        return wrapper
    return decorator


def track_cache_metrics(cache_type: str = "default") -> Callable:
    """Decorator to track cache hit/miss rates."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # This is a simplified version
            # In practice, the decorated function should return (result, is_hit) tuple
            result = func(*args, **kwargs)
            return result
        
        return wrapper
    return decorator


def track_analysis_metrics(sector: str) -> Callable:
    """Decorator to track CFO analysis metrics."""
    def decorator(func: Callable) -> Callable:
        signature = inspect.signature(func)

        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                status = "success"

                try:
                    result = await func(*args, **kwargs)
                    return result
                except Exception:
                    status = "error"
                    raise
                finally:
                    duration = time.time() - start_time
                    cfo_analysis_duration_seconds.labels(sector=sector).observe(duration)
                    cfo_analyses_total.labels(sector=sector, status=status).inc()

            async_wrapper.__signature__ = signature  # type: ignore[attr-defined]
            return async_wrapper

        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            status = "success"
            
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                raise
            finally:
                duration = time.time() - start_time
                cfo_analysis_duration_seconds.labels(sector=sector).observe(duration)
                cfo_analyses_total.labels(sector=sector, status=status).inc()

        wrapper.__signature__ = signature  # type: ignore[attr-defined]
        return wrapper
    return decorator


# =====================================================
# EXPORT METRICS
# =====================================================

def get_metrics_endpoint() -> tuple[bytes, str]:
    """
    Generate Prometheus metrics in text format.
    
    Usage in FastAPI:
        @app.get("/metrics")
        def metrics():
            content, content_type = get_metrics_endpoint()
            return Response(content, media_type=content_type)
    """
    if PROMETHEUS_AVAILABLE:
        return generate_latest(registry), CONTENT_TYPE_LATEST
    else:
        return b"Prometheus not installed", "text/plain"
