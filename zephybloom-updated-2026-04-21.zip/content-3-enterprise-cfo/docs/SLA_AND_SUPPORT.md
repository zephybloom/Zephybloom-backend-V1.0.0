# ZephyBloom CFO API - SLA & Support Documentation

## Service Level Agreement (SLA)

### Uptime Guarantee
- **Target Uptime:** 99.5% per month
- **Excluded Downtime:**
  - Scheduled maintenance (4 hours/month, announced 7 days ahead)
  - Customer-caused issues (misconfiguration, DDoS)
  - Third-party service failures (PostgreSQL, external APIs)

**Uptime Calculation:**
```
Uptime % = (Total Minutes - Downtime Minutes) / Total Minutes × 100
Downtime = Period when >10% requests fail
```

### Performance Targets

| Metric | Target | SLA Impact |
|--------|--------|-----------|
| API Response Time (p95) | <500ms | -5% credit if exceeded |
| API Response Time (p99) | <1000ms | -5% credit if exceeded |
| Error Rate | <1% | -10% credit if exceeded |
| Monthly Uptime | 99.5% | Service credit if below |

### Service Credits (Applied to next billing cycle)

| Uptime Target | Credit |
|---------------|--------|
| 99.0% - 99.49% | 10% of monthly fee |
| 98.0% - 98.99% | 25% of monthly fee |
| 95.0% - 97.99% | 50% of monthly fee |
| <95% | 100% of monthly fee |

**Credit Request Process:**
1. Report incident within 7 days of occurrence
2. Provide affected date/time and error logs
3. We verify via monitoring data
4. Credit applied within 30 days

---

## Support Process

### Support Channels

| Channel | Response Time | Use Case |
|---------|---------------|----------|
| **Email** | 24 business hours | Non-urgent questions, feature requests |
| **Support Portal** | 12 business hours | Bug reports, password resets |
| **Phone** | On-demand (Enterprise) | Critical production issues |
| **Slack** | 24 business hours | General questions (Enterprise only) |

### Support Hours
- **Standard Support:** Monday - Friday, 9 AM - 5 PM CET
- **Emergency Support:** 24/7/365 (Enterprise plans only)
- **Holiday Hours:** Limited support on Italian/European holidays

### Issue Severity Levels

| Severity | Definition | Response Time | Resolution Time |
|----------|-----------|----------------|-----------------|
| **P1 - Critical** | System completely down, data loss risk | 1 hour | 4 hours |
| **P2 - High** | Major feature broken, significant impact | 2 hours | 8 hours |
| **P3 - Medium** | Minor feature broken, workaround exists | 8 hours | 24 hours |
| **P4 - Low** | Documentation issue, cosmetic bug | 24 hours | 7 days |

**P1 Criteria (Automatic Escalation):**
- API completely unavailable (>30 min)
- Data loss or corruption detected
- Security vulnerability exposed
- >50% request failure rate

---

## Incident Management

### Incident Lifecycle

1. **Detection** (Automated)
   - Prometheus alerts trigger on:
     - Response time >1000ms p99
     - Error rate >5%
     - CPU >80%
     - Disk >90%
   - Notification sent to on-call engineer

2. **Response**
   - P1: Engineer on call within 30 minutes
   - P2: Engineer assigned within 2 hours
   - P3/P4: Triaged and assigned next business day

3. **Mitigation**
   - Implement temporary fix (if needed for uptime)
   - Notify affected customers
   - Document root cause

4. **Resolution**
   - Deploy permanent fix
   - Verify monitoring confirms fix
   - Customer confirmation

5. **Post-Incident**
   - Root cause analysis within 24 hours
   - Customer communication email
   - Documentation update (if applicable)

### Status Page
- **URL:** https://status.zephybloom.com
- **Updates:** Real-time incident tracking
- **Notifications:** Optional email/SMS subscription
- **Historical Data:** 90-day incident history

---

## Monitoring & Diagnostics

### What We Monitor

**System Health:**
```
grafana-dashboards:
- API Response Times (p50, p95, p99)
- Error Rates by Endpoint
- Database Connection Pool
- Cache Hit Rates
- Queue Depth (if applicable)
```

**Business Metrics:**
```
- Active Tenants
- API Calls/Day
- Revenue Run Rate
- Failed Transactions
```

### Customer Access to Monitoring

**Included (All Plans):**
- System status page
- Basic API health endpoint (`GET /health`)
- Monthly uptime report

**Premium (Pro/Enterprise):**
- Dedicated Grafana dashboard per tenant
- Custom alerts configuration
- Weekly performance reports
- Quarterly business reviews

### Health Check Endpoint

```bash
curl https://api.zephybloom.com/health

Response:
{
  "status": "healthy",
  "timestamp": "2024-04-20T18:30:00Z",
  "services": {
    "api": "healthy",
    "database": "healthy",
    "cache": "healthy",
    "external_apis": "healthy"
  },
  "response_time_ms": 45,
  "uptime_days": 31
}
```

---

## Rate Limiting & Quotas

### API Rate Limits

| Plan | Requests/Min | Concurrent | Burst |
|------|-------------|-----------|-------|
| **Starter** | 100 | 10 | 150 |
| **Pro** | 500 | 50 | 750 |
| **Enterprise** | Custom | Custom | Custom |

### Rate Limit Headers

```http
X-RateLimit-Limit: 500
X-RateLimit-Remaining: 487
X-RateLimit-Reset: 1713618660

429 Too Many Requests

{
  "status": 429,
  "detail": "Rate limit exceeded. Reset in 45 seconds.",
  "retry_after": 45
}
```

### Quota Management
- Limits reset every minute
- Burst allowance for short spikes
- Contact sales for increased quotas

---

## Escalation Policy

### Support Escalation Path

```
Tier 1: Support Team (Level 1 Issues)
   ↓ (Unresolved in 2 hours)
Tier 2: Engineering ([Level 2 Issues - Complex Bugs)
   ↓ (Unresolved in 4 hours)
Tier 3: Senior Engineering (Architecture Issues)
   ↓ (Critical issues only)
CTO Review (Potential design changes)
```

### Business Escalation

**Enterprise customers** have additional escalation:
- Account Manager notification after 4 hours P2/P3
- Director of Support involvement for unresolved P2 >8 hours
- CEO notification for unresolved P1 >24 hours
- Service credit + compensation discussion

---

## Planned Maintenance

### Maintenance Windows

**Standard Maintenance:**
- **Window:** First Tuesday of month, 2 AM - 4 AM CET
- **Notice:** 7 days advance notification
- **Duration:** Max 2 hours
- **Expected downtime:** ≤5 minutes

**Emergency Maintenance:**
- No advance notice required
- Impacts <1% of customers
- Full root cause + status update within 4 hours

### Maintenance Communication

1. **Pre-Maintenance (7 days before)**
   - Email to all account contacts
   - In-app banner notification
   - Status page update

2. **During Maintenance**
   - Status page real-time updates
   - Technical details posted (if applicable)

3. **Post-Maintenance**
   - Confirmation email within 1 hour
   - Summary of changes made
   - Performance impact report

---

## Data & Security

### Data Protection

| Aspect | Commitment |
|--------|-----------|
| Encryption in Transit | TLS 1.3 |
| Encryption at Rest | AES-256 |
| Backup Frequency | Daily |
| Backup Retention | 30 days |
| Recovery Time Objective | <4 hours |
| Recovery Point Objective | <1 hour |

### Data Residency
- **Default:** EU (Frankfurt data center)
- **Options:** Available on request
- **Compliance:** GDPR, SOC 2 Type II

### Security Incident Report
If security issue discovered:
1. Notification within 48 hours
2. Detailed incident report within 7 days
3. Remediation timeline provided
4. Post-incident review offered

---

## Communication Preferences

### Notification Settings (Customer Control)

```
System Status
- ✓ Incidents (automatic)
- ✓ Planned maintenance (7 days notice)
- ☐ Performance degradation (≥5% impact)
- ☐ API usage warnings (80% of quota)

Support
- ✓ Support responses
- ☐ Weekly digest
- ☐ Product updates

Billing
- ✓ Invoice delivery
- ✓ Payment failures
- ☐ Usage reports
```

Update preferences in account settings / notifications.

---

## Support Best Practices

### Required Information for Bug Reports

To expedite resolution, include:

```
1. Issue Description
   - What happened (actual vs. expected)
   - When it first occurred
   - Frequency (always/intermittent)

2. Steps to Reproduce
   - Exact API calls or UI actions
   - Sample data (sanitized)

3. Environment Details
   - API version
   - Programming language/SDK version
   - Request/error IDs (from logs)

4. Screenshots/Logs
   - Error messages/stack traces
   - Network request capture (redacted)
   - Relevant application logs

5. Impact
   - Number of users affected
   - Business impact
   - Workaround status
```

### Optimization Recommendations

**API Performance:**
- Batch requests when possible
- Use caching headers properly
- Monitor rate limit headers
- Implement exponential backoff for retries

**Database:**
- Index frequently filtered fields
- Use pagination for large datasets
- Archive old data (>1 year)

**Cost Optimization:**
- Review API usage monthly
- Consolidate multiple keys into one
- Use bulk endpoints where available

---

## SLA Exceptions & Limitations

### Not Covered by SLA

- **Planned maintenance** (announced >24 hours)
- **Force Majeure** (natural disasters, war, terrorism)
- **Third-party failures** (ISP, cloud hosting, external APIs)
- **Customer-caused issues:**
  - Misconfigured API calls
  - DDoS attacks from customer IP
  - Invalid rate limiting setup
  - Expired credentials
- **Beta features** (explicitly marked as "beta")

### Your Responsibilities

To maintain SLA:
1. Keep authentication credentials secure
2. Implement proper error handling + retries
3. Monitor API usage and rate limits
4. Report issues promptly (within 7 days)
5. Maintain current API version (upgrade within 90 days of deprecation)

---

## Disaster Recovery

### Backup & Recovery

| Component | Backup Frequency | Recovery Time | Retention |
|-----------|-----------------|---------------|-----------|
| Database | Every 6 hours | <30 min | 30 days |
| Configuration | On change | <5 min | 12 months |
| API Keys | On change | Immediate (regenerate) | N/A |

### Failover

**Automatic Failover:**
- Database → Replica (if configured)
- Cache → In-memory fallback
- External APIs → Graceful degradation

**Geographic Failover:**
- Enterprise: Multi-region available
- Standard: Warm standby (contact sales)

### Disaster Recovery Testing

- **Frequency:** Quarterly
- **Scope:** Full system recovery
- **Results:** Shared in quarterly business review

---

## Contact & Escalation

### Support Contact Information

**Primary Support**
- 📧 Email: support@zephybloom.com
- 🌐 Portal: https://support.zephybloom.com
- 📞 Phone: +39-XXX-XXXX (Enterprise only, 24/7)
- 💬 Slack: #support (Enterprise only)

**Escalation**
- 📧 Engineering: engineering@zephybloom.com
- 📧 Sales/Partnership: sales@zephybloom.com
- 📧 Security: security@zephybloom.com
- 🔒 Security Issues (PGP key): [Available on security page]

**Executive Escalation (Enterprise)**
- Director of Support: director-support@zephybloom.com
- VP of Engineering: vp-engineering@zephybloom.com

**Hours of Operation**
- Business Days: 9 AM - 5 PM CET (Mon-Fri)
- Holidays: Limited coverage (Italian/European public holidays)
- Emergency: 24/7/365 (Enterprise plans)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0 | 2024-04-20 | Production SLA, Enterprise features |
| 1.0 | 2024-01-01 | Initial SLA (Beta) |

**Next Review:** Q3 2024 (based on customer feedback)

---

## Approval & Signature

**Document Owner:** VP of Engineering  
**Last Updated:** 2024-04-20  
**Next Review:** 2024-07-20  

This SLA is valid for all ZephyBloom CFO API customers and Enterprise agreements supersede conflicting terms.

For questions: support@zephybloom.com
