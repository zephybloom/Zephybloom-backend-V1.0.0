# CFO Financial Analytics Platform - Frontend Specifications for Lovable

## 🎯 Project Overview
Build a modern, dark-themed financial analytics dashboard for CFO decision-making. The frontend connects to a Python FastAPI backend running on `http://127.0.0.1:8001`.

## 📱 Core Pages Required

### 1. **Login Page** (`/login`)
- Email/Password form
- Register option
- JWT token storage (localStorage)
- Redirect to dashboard on success
- Error handling with clear messages
- **Design**: Dark mode, centered card, company logo space

### 2. **Dashboard** (`/dashboard`) - HERO PAGE
**Hero Section (Above the fold):**
- 3 Large KPI Cards (Revenue, Profit, Growth %)
  - Big number display
  - Trend indicator (↑ +5.2% vs YoY)
  - Color coded: cyan, green, orange

**Analytics Section:**
- Line Chart: Revenue & Profit trend (12 months)
- Circular Gauge: Profit Margin vs Target
- KPI Mini Cards: Gross Margin, EBITDA, Net Margin, Debt Ratio

**Header:**
- "Refresh" button (triggers /cfo/analyze)
- "Edit Data" button (opens input wizard modal)

### 3. **Data Input Wizard** (Modal/Page)
- **Step 1**: Basic Company Info
  - Company Name (text)
  - Industry (dropdown: Tech, Finance, Healthcare, Retail, Manufacturing, Energy, Telecom)
  - Country (dropdown: Italy, Germany, France, Spain, England, USA)
  
- **Step 2**: Financial Data
  - Annual Revenue (€ number)
  - Cost of Goods Sold (€)
  - Operating Expenses (€)
  
- **Step 3**: KPI Targets
  - Target Profit Margin (%)
  - Target Growth Rate (%)
  - Debt Ratio Target (%)
  
- **Step 4**: Review & Confirm
  - Show summary of all data
  - Confirm button

**UX Features:**
- Progress bar at top
- Previous/Next buttons
- Validation with error messages
- Input hints with currency formatting
- Disabled steps until valid

### 4. **Simulator Page** (`/simulate`)
- Input fields: Revenue Delta (%), Cost Delta (%), Investment amount
- Run Simulation button
- Show results: New Revenue, New Profit, Impact comparison
- Visual before/after comparison (bars or cards)

### 5. **Chat Page** (`/chat`)
- Chat interface with message history
- Input field at bottom
- Send button
- Display AI responses from backend
- Timestamp on messages
- Clear conversation button

## 🎨 Design System - Dark Mode

**Colors:**
- Background: `#0f1419` (main)
- Surface: `#1a1f2e` (cards)
- Primary: `#00bcd4` (cyan accent)
- Success: `#4caf50` (green)
- Warning: `#ff9800` (orange)
- Error: `#f44336` (red)
- Secondary: `#7c4dff` (purple)
- Text Primary: `#e0e0e0`
- Text Secondary: `#b0bec5`
- Border: `#37474f`

**Typography:**
- Font: Roboto, Inter (sans-serif)
- H1: 2.5rem, bold
- H4: 1.5rem, bold
- Body: 0.95rem, regular

**Components:**
- Cards with gradient background + hover glow effect (cyan border)
- Smooth transitions (0.3s ease)
- Rounded corners (8px)
- Clean spacing (Material-UI Grid)

## 🔌 API Integration

### Base URL
`http://127.0.0.1:8001`

### Authentication
```
POST /auth/login
Body: { "email": "user@example.com", "password": "password" }
Response: { "access_token": "JWT_TOKEN", "token_type": "bearer", "expires_in": 86400, "user_id": 1, "tenant_id": "tenant-slug" }

POST /auth/register
Body: { "email": "new@example.com", "password": "password", "full_name": "John Doe" }
```

**Headers for Protected Endpoints:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

### Core Endpoints

#### **POST /cfo/analyze**
Analyzes financial data and returns KPIs and recommendations.

**Request:**
```json
{
  "fatturato": 1000000,
  "costi_variabili": 400000,
  "costi_fissi": 300000,
  "investimenti": 100000,
  "settore": "default",
  "company_name": "My Company",
  "dso_days": 30,
  "dio_days": 45,
  "dpo_days": 30
}
```

**Response:**
```json
{
  "status": "healthy|warning|critical",
  "headline": "Company is performing well",
  "summary": "Detailed analysis text",
  "kpi_snapshot": {
    "gross_profit_eur": 600000,
    "gross_margin_pct": 60.0,
    "ebitda_eur": 300000,
    "ebitda_margin_pct": 30.0,
    "net_profit_eur": 200000,
    "net_margin_pct": 20.0
  },
  "recommended_actions": [
    {
      "title": "Increase sales",
      "description": "Focus on high-margin products",
      "impatto_euro": 50000,
      "priorita": "high"
    }
  ]
}
```

#### **POST /cfo/simulate**
Runs what-if scenarios.

**Request:**
```json
{
  "scenario_name": "Growth Scenario",
  "revenue_delta_pct": 20,
  "cost_delta_pct": -5,
  "investment_amount": 50000
}
```

**Response:**
```json
{
  "scenario_name": "Growth Scenario",
  "base_metrics": { ... },
  "projected_metrics": { ... },
  "impact": {
    "revenue_change": 200000,
    "profit_change": 150000,
    "roi": 3.0
  }
}
```

#### **POST /cfo/chat**
AI-powered financial question answering.

**Request:**
```json
{
  "message": "How can I improve my profit margin?",
  "context": { "company_data": {...} }
}
```

**Response:**
```json
{
  "response": "To improve your profit margin, consider...",
  "sources": ["analysis_report", "industry_benchmark"]
}
```

## 📊 State Management
Use React Context or similar for:
- `AuthContext`: user, token, isAuthenticated
- `CompanyContext`: companyData, currentAnalysis

## 🎯 Test Credentials
```
Email: demo@example.com
Password: DemoPassword123
```

## ✨ Special Features
1. **Auto-save**: Save company data to localStorage
2. **Charts**: Use Recharts library for trend visualization
3. **Responsive**: Mobile-friendly (80/20 desktop/mobile focus)
4. **Error Handling**: Show user-friendly errors, not API errors
5. **Loading States**: Spinners during API calls
6. **Input Validation**: Client-side validation with error messages

## 🚀 Deployment Ready
- Env var: `REACT_APP_API_URL` (defaults to http://127.0.0.1:8001)
- Build command: `npm run build`
- No external API keys needed (self-contained backend)

---

**Start Prompt for Lovable:**
```
Create a modern dark-themed financial analytics dashboard (CFO platform) in React.
Requirements:
- Dark mode design: #0f1419 background, #00bcd4 cyan accents
- 5 pages: Login, Dashboard (hero + analytics), Simulator, Chat, (Data Wizard modal)
- Dashboard has 3 hero KPI cards + revenue trend chart + profit gauge
- Form wizard for company data input (4 steps with validation)
- Integrate with FastAPI backend: POST /auth/login, /cfo/analyze, /cfo/simulate, /cfo/chat
- Use JWT auth with localStorage token storage
- Charts: Recharts library for line chart and gauge
- Test with demo@example.com / DemoPassword123
- Mobile responsive, professional UI
```
