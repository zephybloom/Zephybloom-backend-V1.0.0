# Deploy vero: frontend + backend

Obiettivo: ottenere un link pubblico stabile, condivisibile, senza localhost e senza tunnel temporanei.

## Architettura consigliata

- Frontend: Vercel
- Backend API: Railway
- Database: PostgreSQL su Railway

## 1. Deploy backend su Railway

Repo root: questa cartella.

Railway userà:
- `railway.toml`
- `requirements.txt`
- start command FastAPI già presente

### Variabili minime backend da impostare su Railway

- `ZB_ENV=production`
- `ZB_OPENAI_API_KEY=...`
- `ZB_LLM_PROVIDER=openai`
- `ZB_LLM_MODEL=gpt-4o-mini`
- `ZB_DATABASE_URL=...` oppure database Railway collegato
- `ZB_JWT_SECRET=...`
- `ZB_CORS_ORIGINS=https://your-frontend-domain.vercel.app`
- `ZB_CORS_ALLOW_CREDENTIALS=true`

### URL atteso backend

Esempio:

`https://your-backend-name.up.railway.app`

## 2. Deploy frontend su Vercel

Cartella frontend:

`zephybloom_frontend`

### Impostazioni build Vercel

- Framework: Vite
- Root directory: `zephybloom_frontend`
- Build command: `npm run build`
- Output directory: `dist`

### Variabile ambiente frontend

- `VITE_API_URL=https://your-backend-name.up.railway.app`

Il frontend in produzione chiamerà il backend pubblico tramite questa variabile.

## 3. Aggiornare CORS backend

Quando Vercel assegna il dominio frontend, aggiungi quel dominio in Railway:

- `ZB_CORS_ORIGINS=https://your-frontend-domain.vercel.app`

Se usi un dominio custom:

- `ZB_CORS_ORIGINS=https://app.tuodominio.com`

## 4. Verifiche finali

### Backend

- `/health`
- `/docs`
- login
- `/cfo/chat`

### Frontend

- login
- dashboard
- chat CFO
- onboarding data room

## 5. Ordine pratico consigliato

1. Pubblica backend su Railway
2. Copia URL backend
3. Pubblica frontend su Vercel con `VITE_API_URL`
4. Aggiorna CORS backend con dominio frontend
5. Test finale end-to-end
