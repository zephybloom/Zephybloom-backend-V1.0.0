# Health Dashboard & Monitoring Guide

## Quick Start (5 minutes)

### 1. Access Grafana Dashboard

**Local Development:**
```bash
docker-compose -f docker-compose.monitoring.yml up -d
```

- **Grafana:** http://localhost:3000
- **Prometheus:** http://localhost:9090
- **Default credentials:** admin / admin

### 2. View API Health

```bash
# System health status
curl https://api.zephybloom.com/health

# FastAPI metrics (Prometheus format)
curl https://api.zephybloom.com/metrics
```

### 3. Check Status Page

- **URL:** https://status.zephybloom.com
- **Uptime:** Last 30/90 days
- **Incidents:** Real-time alerts
- **History:** All past incidents

---

## Dashboard Overview

### Dashboard 1: System Overview
**Location:** Grafana → System Overview

**Panels:**
- **API Status:** Green = healthy, Red = down, Yellow = degraded
- **Request Volume:** Requests/second over time
- **Error Rate:** % of failed requests
- **P50/P95/P99 Response Times:** Latency percentiles
- **Database Connections:** Active vs. max pool
- **Cache Hit Rate:** % of cache hits

**Alert Triggers:**
```
🔴 RED: Error rate >5% for 5 minutes
🟡 YELLOW: Response time p99 >1000ms for 10 minutes
🔵 BLUE: System healthy, all metrics normal
```

### Dashboard 2: Business Metrics
**Location:** Grafana → Business Metrics

**Panels:**
- **Active Tenants:** Total customer count
- **API Calls/Day:** Total volume trend
- **Revenue Run Rate:** € per month (if integrated)
- **Top Endpoints:** Most-used API routes
- **Failed Transactions:** Payment failures, if applicable

### Dashboard 3: Infrastructure
**Location:** Grafana → Infrastructure

**Panels:**
- **Database CPU:** PostgreSQL CPU usage
- **Database Memory:** PostgreSQL RAM consumption
- **Disk Usage:** Storage capacity vs. used
- **Network I/O:** Bytes in/out per second
- **Container Status:** Docker container health

---

## Key Metrics Explained

### Response Time Metrics

| Metric | Good | Warning | Critical |
|--------|------|---------|----------|
| **P50** (median) | <250ms | <450ms | >450ms |
| **P95** | <500ms | <800ms | >800ms |
| **P99** | <1000ms | <2000ms | >2000ms |

**What It Means:**
```
P50: 50% of requests faster than this
P95: 95% of requests faster than this
P99: 99% of requests faster than this (worst 1%)
```

**Example:**
```
If P95 = 500ms:
- 95% of users experience <500ms response
- 5% experience >500ms (slow)
```

### Error Rate

```
Error Rate = Failed Requests / Total Requests × 100

Target: <1%
Alert: >5% for 5 minutes
Critical: >10% or >30 min sustained
```

**Common Causes:**
- Invalid requests (check logs)
- Database connection issues
- Rate limit exceeded
- Service temporarily down

### Database Metrics

| Metric | Healthy | Warning | Action |
|--------|---------|---------|--------|
| **Connections** | <20 | >80% of max | Increase pool, review queries |
| **Query Time** | <100ms avg | >500ms avg | Index missing fields, optimize |
| **Disk Usage** | <70% | >85% | Archive old data, expand disk |
| **Replication Lag** | <1s | >5s | Check network, increase resources |

### Cache Metrics

```
Cache Hit Rate = Cache Hits / (Cache Hits + Misses) × 100

Target: >80%
- If <60%: Check if TTL too short, or high churn
- If >95%: Cache possibly too large, review eviction

Memory Usage:
- If >90%: Reduce TTL or eviction policy
- If <50%: Memory underutilized (can optimize costs)
```

---

## Monitoring by Use Case

### Use Case 1: Detect If System Is Down

```bash
# Quick check
curl https://api.zephybloom.com/health

# Detailed diagnosis
curl https://api.zephybloom.com/metrics | grep -i error
```

**Grafana Dashboard:**
1. System Overview → API Status panel (red = down)
2. Request Volume → should be 0
3. Error Rate → should show 100%

### Use Case 2: Performance Is Slow

**Step 1: Check Response Time**
```
Grafana → System Overview → Response Time (P95/P99)
If P95 > 500ms → Actual slowness confirmed
```

**Step 2: Identify Bottleneck**
```
Is it:
- API? → Response time spikes in System Overview
- Database? → Database CPU/query time high in Infrastructure dashboard
- Cache? → Cache hit rate <60% suggests cache miss storm
- External API? → Check external API endpoint response time
```

**Step 3: Check Logs**
```bash
# Docker logs
docker logs content-api-1 | grep ERROR

# Kubernetes
kubectl logs -f pod-name -n production

# Last 100 errors
curl -s https://api.zephybloom.com/logs?level=ERROR&limit=100
```

### Use Case 3: Error Rate Spike

Step 1: Confirm error rate high
```
Grafana → System Overview → Error Rate panel
If >5% → Alert should be triggered
```

Step 2: Drill down into errors
```
Grafana → System Overview → Error Distribution
(By endpoint, status code, error type)

Example:
- 40% → 500 Internal Server Error
- 30% → 429 Too Many Requests (rate limit)
- 20% → 400 Bad Request (invalid payload)
- 10% → 503 Service Unavailable (dependency)
```

Step 3: Check specific endpoint
```
Grafana → System Overview → Top Failed Endpoints
Click on endpoint → see error messages
```

### Use Case 4: Customer Complains About Rate Limiting

```bash
# Check customer's current rate limit
curl -I https://api.zephybloom.com/health \
  -H "X-API-Key: customer_key" \
  -H "X-Tenant-Id: customer_id"

# Response headers
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1713618660
```

**If rate limited (429):**
```
# Check if actual limit exceeded
X-RateLimit-Remaining: 0 → Yes, over limit

# Check reset time
X-RateLimit-Reset: Unix timestamp
date -d @1713618660  # Convert to readable time
```

**Increase limit:**
```sql
-- Database: update rate limit
UPDATE tenants 
SET rate_limit_per_minute = 500 
WHERE id = 'customer_id';
```

---

## Setting Up Custom Alerts

### Alert 1: Response Time Exceeds Threshold

**Prometheus Query:**
```
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 0.5
```

**Grafana Alert:**
1. Dashboard → Edit Panel
2. Alert tab → Create Alert
3. Condition: `p95_response_time > 500ms for 10 min`
4. Notification: Slack, Email, PagerDuty

### Alert 2: Error Rate Spike

**Prometheus Query:**
```
rate(http_requests_failed[5m]) / rate(http_requests_total[5m]) > 0.05
```

**Trigger:** Error rate >5% for 5 minutes → Page on-call engineer

### Alert 3: Database Connection Pool Exhausted

**Prometheus Query:**
```
pg_stat_database_numbackends > pg_stat_database_max_numbackends * 0.8
```

**Trigger:** >80% connections used → Alert to DBA team

---

## Common Issues & Diagnosis

### Issue 1: High CPU Usage

**Check Dashboard:**
```
Grafana → Infrastructure → Database CPU
If > 70% sustained → investigate
```

**Quick Diagnosis:**
```sql
-- Find slow queries
SELECT query, calls, mean_time 
FROM pg_stat_statements 
ORDER BY mean_time DESC LIMIT 5;

-- Check for full table scans
EXPLAIN ANALYZE SELECT * FROM large_table WHERE unindexed_field = X;
```

**Quick Fix:**
```sql
-- Add missing index
CREATE INDEX idx_users_tenant ON users(tenant_id);

-- Analyze query performance
ANALYZE users;
```

### Issue 2: Memory Leak (Increasing Memory Over Time)

**Check Dashboard:**
```
Grafana → Infrastructure → Memory Over Time
If >90% and increasing daily → likely leak
```

**Diagnosis:**
```bash
# Check process memory
docker stats content-api-1

# Check for memory-intensive operations
docker logs content-api-1 | grep -i memory
```

**Quick Fix:**
```bash
# Restart container (temporary)
docker restart content-api-1

# Long-term: Check logs for:
# - Circular imports
# - Unclosed connections
# - Large data structures not cleaned up
```

### Issue 3: API Response Time Slow But Server Health Good

**Possible Cause:** External API dependency slow

**Check:**
```
Grafana → Business Metrics → External API Latency
If >5000ms → external API is bottleneck
```

**Fix:**
1. Add timeout on external API call (fail fast)
2. Implement fallback/cache
3. Add circuit breaker pattern

---

## Maintenance & Scaling Decisions

### When to Scale (Use Dashboard to Decide)

**Scale UP (increase resources):**
- CPU >75% sustained
- Memory >85% sustained
- Database connections >80% of max
- Disk usage >80%

**Scale OUT (add more instances):**
- Response time p99 >1s despite low resource usage
- Error rate >5% during peak hours
- Request volume nearing current capacity (scale at 70%)

### Pre-Maintenance Checklist

```
1 Day Before:
☐ Check current error rate (should be <1%)
☐ Check backup status (should have completed today)
☐ Notify users (status page + email)

Maintenance Window:
☐ Start backup
☐ Stop traffic (nginx shutdown)
☐ Apply updates
☐ Run smoke tests:
  - curl /health
  - curl /docs (Swagger)
  - Test 3-5 key endpoints
☐ Resume traffic (nginx start)
☐ Monitor error rate for 30 min

After Maintenance:
☐ Post status update
☐ Confirm monitoring normal
☐ Document what changed
```

---

## Escalation Paths

If dashboard shows critical issue:

```
P1 - System Down
↓
Notify on-call engineer immediately
↓
Attempt failover / restart
↓
If not resolved in 30 min → Page manager
↓
If not resolved in 1 hour → All-hands incident

P2 - Major Performance Degradation
↓
Create incident ticket
↓
Assign to on-call engineer
↓
If not resolved in 4 hours → Escalate to manager

P3 - Minor issues or warnings
↓
Log ticket
↓
Assign to regular sprint
↓
No escalation unless customer impact
```

---

## Customer Access

### Enterprise Customers: Custom Dashboard

**Request via Support:**
```
Subject: Custom Grafana Dashboard for [Tenant ID]

Include:
- Specific metrics of interest
- Required time range
- Any custom calculations needed

We'll create within 24 hours.
```

**Example Custom Dashboards:**
```
1. Cost per API call (business metric)
2. Feature usage breakdown (product metric)
3. Performance by endpoint (technical metric)
4. Tenant-specific SLA tracking (compliance metric)
```

---

## Additional Resources

- **Status Page:** https://status.zephybloom.com
- **Prometheus Docs:** https://prometheus.io/docs
- **Grafana Docs:** https://grafana.com/docs
- **SQL Performance:** https://wiki.postgresql.org/wiki/Performance_Optimization
- **Support Contact:** support@zephybloom.com
