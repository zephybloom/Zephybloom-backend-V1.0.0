# Phase 1: 100 Clienti - Setup Guide

## 📋 Panoramica

Questa guida copre il setup della Fase 1 per supportare i **primi 100 clienti** in produzione.

**Timeline:** 4-6 settimane  
**Team:** 1 backend dev + 1 DevOps (part-time)  
**Costo esteso:** €60-100/mese

---

## ⚡ Setup Rapido (per sviluppatori)

Se stai sviluppando localmente:

```bash
# 1. Installaer le dipendenze
pip install -r requirements.txt

# 2. Avviare PostgreSQL + Redis con Docker
docker-compose up -d

# 3. Configurare env
cp .env.example .env
# Editare .env con:
# ZB_DATABASE_URL=postgresql://zephybloom:zephybloom_dev_password_change_in_prod@localhost:5432/zephybloom_dev

# 4. Inizializzare il database
python -m alembic upgrade head
# (oppure se non c'è Alembic, FastAPI creerà le tabelle automaticamente)

# 5. Avviare il backend
export ZB_OPENAI_API_KEY="sk-proj-..."
python -m uvicorn api.main:app --host 127.0.0.1 --port 8002 --reload

# 6. Test rapido
curl http://localhost:8002/health
```

**Risultato atteso:** Status 200 ✅

---

## 🔧 Task 1: PostgreSQL Setup & Migration

### Passo 1.1: Installare PostgreSQL

#### Option A: Docker (Consigliato per sviluppo)
```bash
docker-compose up -d postgres

# Verificare
docker ps | grep postgres
docker logs zephybloom-postgres
```

#### Option B: macOS (Homebrew)
```bash
brew install postgresql@15
brew services start postgresql@15

# Accedere al server
psql -U postgres
```

#### Option C: AWS RDS (Per fase successiva)
- Crea RDS instance su AWS
- Userà lo stesso SQL, solo URL diverso

### Passo 1.2: Creare database e utente

```bash
# Fare login al PostgreSQL
docker exec -it zephybloom-postgres psql -U postgres

# SQL commands:
CREATE USER zephybloom WITH PASSWORD 'zephybloom_dev_password_change_in_prod';
CREATE DATABASE zephybloom_dev OWNER zephybloom;
GRANT ALL PRIVILEGES ON DATABASE zephybloom_dev TO zephybloom;
ALTER ROLE zephybloom CREATEDB;
\q

# Verificare la connessione
psql -U zephybloom -d zephybloom_dev -h localhost
```

### Passo 1.3: Migrare da SQLite a PostgreSQL

```bash
# Impostare le variabili di ambiente
export DATABASE_URL_SQLITE="sqlite:///./zephytheory.db"
export DATABASE_URL_POSTGRES="postgresql://zephybloom:zephybloom_dev_password_change_in_prod@localhost:5432/zephybloom_dev"

# Run migration in dry-run first
python3 scripts/migrate_sqlite_to_postgres.py --dry-run

# Se output è OK, eseguire la migrazione reale
python3 scripts/migrate_sqlite_to_postgres.py

# Verificare i dati
psql -U zephybloom -d zephybloom_dev -c "SELECT COUNT(*) FROM users;"
```

### Passo 1.4: Aggiornare config.py

Verificare che `api/config.py` legga da `DATABASE_URL` env var:

```python
DATABASE_URL: str = os.getenv(
    "DATABASE_URL",
    "sqlite:///./zephytheory.db"  # default fallback
)
```

---

## 🔐 Task 2: Re-enable Authentication

### Passo 2.1: Abilitare JWT

In `api/config.py`:

```python
JWT_REQUIRED = True  # cambiar a True
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret")  # generate proper secret
```

### Passo 2.2: Abilitare tenant isolation

Alle queries in `api/routes_*.py`, aggiungere filtro `tenant_id`:

```python
# PRIMA (vulnerable):
users = db.query(User).all()

# DOPO (secure):
tenant_id = tenant_context.tenant_id
users = db.query(User).filter(User.tenant_id == tenant_id).all()
```

Eseguire questo script per trovare query non-tenantized:

```bash
grep -r "db.query(" api/ --include="*.py" | grep -v "tenant_id" | head -20
```

### Passo 2.3: Test di isolamento

```python
# Test: verify user of tenant A cannot see tenant B data
def test_tenant_isolation():
    # Create users in different tenants
    # Query as user A
    # Verify cannot see user B's data
```

---

## 🐳 Task 3: Docker Containerization

### Passo 3.1: Creare Dockerfile

```dockerfile
# backend.Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Installa dipendenze di sistema
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Copia requirements e installa
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copia source code
COPY . .

# Espone la porta
EXPOSE 8002

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8002/health || exit 1

# Run
CMD ["uvicorn", "api.main:app", "--host", "0.0.0.0", "--port", "8002"]
```

Salva come `Dockerfile` (root folder)

### Passo 3.2: Build e test del container

```bash
# Build
docker build -t zephybloom-api:v1 .

# Run con variabili di ambiente
docker run -e "ZB_OPENAI_API_KEY=sk-proj-..." \
           -e "ZB_DATABASE_URL=postgresql://..." \
           -p 8002:8002 \
           zephybloom-api:v1

# Verificare
curl http://localhost:8002/health
```

### Passo 3.3: Docker Compose orchestration

È già fornito in `docker-compose.yml` — include **postgres, redis, adminer**

```bash
docker-compose up -d
docker-compose logs -f
```

---

## 🔒 Task 4: SSL/HTTPS & Domain Setup

### Passo 4.1: Acquistare dominio

- Godaddy, Namecheap, Route53 (€5-15/anno)
- Scegliere: `api.zephybloom.com`

### Passo 4.2: Setup Let's Encrypt SSL (gratuito)

```bash
# Instella certbot
brew install certbot

# Genera certificato (per nginx/reverse proxy)
certbot certonly --standalone -d api.zephybloom.com

# Certificati in: /etc/letsencrypt/live/api.zephybloom.com/
```

### Passo 4.3: Nginx di reverse proxy

Crea `nginx.conf`:

```nginx
server {
    listen 443 ssl http2;
    server_name api.zephybloom.com;

    ssl_certificate /etc/letsencrypt/live/api.zephybloom.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.zephybloom.com/privkey.pem;

    location / {
        proxy_pass http://localhost:8002;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 80;
    server_name api.zephybloom.com;
    return 301 https://$server_name$request_uri;
}
```

---

## 📊 Task 5: Monitoring Basics

### Passo 5.1: Abilitare Prometheus

In `api/config.py`:

```python
PROMETHEUS_ENABLED = True
```

Nel `api/main.py`, add Prometheus middleware:

```python
from prometheus_client import make_asgi_app
from starlette.middleware.wsgi import WSGIMiddleware

app.add_middleware_middleware(
    WSGIMiddleware,
    make_asgi_app()
)
```

### Passo 5.2: Grafana dashboard

```bash
# Avviare Grafana
docker run -p 3000:3000 grafana/grafana

# Access: http://localhost:3000 (user: admin, pass: admin)

# Add Prometheus data source:
# URL: http://localhost:9090
```

### Passo 5.3: Setup Sentry (optional, consigliato)

```bash
pip install sentry-sdk

# In api/main.py:
import sentry_sdk

sentry_sdk.init(
    dsn="https://YOUR_SENTRY_DSN@sentry.io/12345",
    traces_sample_rate=0.1,
)
```

---

## ✅ Checklist Pre-Produzione

- [ ] PostgreSQL database creato e testato
- [ ] Dati migrati da SQLite
- [ ] JWT enforcement abilitato
- [ ] Tenant isolation verificato in tutte le queries
- [ ] Rate limiting testato
- [ ] Dockerfile builda e runa senza errori
- [ ] Health check endpoint funziona
- [ ] SSL certificate provisionato
- [ ] CORS configurato per frontend domain
- [ ] Prometheus metrics visibili
- [ ] Backup database configurato (daily alle 2 AM)
- [ ] Error handling e logging verificato
- [ ] Load test: 50 concurrent users per 5 minuti (response time < 500ms)

---

## 🚀 Deployment

Una volta completati i tasks:

```bash
# 1. Deploy sul server
docker-compose up -d

# 2. Run migrations
docker-compose exec api python -m alembic upgrade head

# 3. Verificare
curl https://api.zephybloom.com/health
```

---

## 📞 Troubleshooting

**PostgreSQL connection refused**
```bash
docker-compose logs postgres
# Verifica username/password in DATABASE_URL
```

**Migrations failed**
```bash
docker-compose exec postgres psql -U zephybloom -d zephybloom_dev -c "\dt"
# List tables
```

**CORS errors**
- Verifica `ZB_CORS_ORIGINS` in .env
- Include frontend URL

**SSL certificate expired**
```bash
certbot renew --dry-run  # test
certbot renew             # renewit
```

---

## 📈 Monitoring Readiness

```bash
# Check Prometheus scrape targets
curl http://localhost:9090/api/v1/targets

# Check API metrics
curl http://localhost:8002/metrics

# Check PostgreSQL connections
psql -U zephybloom -d zephybloom_dev \
  -c "SELECT count(*) FROM pg_stat_activity;"
```

**Next:** Task 6: Tenant Isolation (in sequel)
