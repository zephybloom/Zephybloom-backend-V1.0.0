# Task 2: Re-enable Authentication Enforcement

## 📋 Obiettivo

Abilitare JWT enforcement e implementare tenant isolation completa per garantire che nessun cliente veda i dati di altri clienti.

**Criticità:** 🔴 CRITICA - Questo è un requisito per andare in produzione  
**Tempo estimato:** 2-3 giorni  
**Output:** Sistema con autenticazione obbligatoria and tenant data isolation verificata

---

## ⚠️ Problema Attuale

Attualmente il sistema ha **fallback di sicurezza disabilitati**:

```python
# ❌ CURRENT: Consente accesso non autenticato
JWT_REQUIRED = False
await get_tenant_context()  # Returns default tenant se non autenticato
```

Questo significa:
- ❌ Chiunque accede senza credenziali
- ❌ Non si filtra per tenant_id nelle query
- ❌ Non è production-ready

---

## ✅ Soluzione

### Step 1: Scansione Sicurezza (5 minuti)

Trovare tutte le query che non filtrano per tenant_id:

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# Scansione automatica
python3 scripts/scan_tenant_isolation.py
```

Output atteso:
```
⚠️  Found X potential issues:

📄 api/routes_cfo.py
   Line 45: db.query(CompanyMetrics).filter(...)
   ☝️  ADD: .filter(CompanyMetrics.tenant_id == tenant_id)

📄 api/routes_auth.py
   Line 120: db.query(User).all()
   ☝️  ADD: .filter(User.tenant_id == tenant_id)
```

### Step 2: Creare Migration Script

Modello per aggiungere `tenant_id` filtering:

**PRIMA (❌ Unsafe):**
```python
@router.get("/companies")
def list_companies(db: Session = Depends(get_session)):
    companies = db.query(Company).all()  # Espone TUTTI i dati!
    return companies
```

**DOPO (✅ Safe):**
```python
@router.get("/companies")
def list_companies(
    db: Session = Depends(get_session),
    tenant: TenantContext = Depends(require_auth),  # ← Richiede autenticazione
):
    tenant_id = tenant.tenant_id
    companies = db.query(Company).filter(
        Company.tenant_id == tenant_id  # ← Filtra per tenant
    ).all()
    return companies
```

### Step 3: Fix Tutte le Routes

Per ogni file in `api/routes_*.py`:

1. **Aggiungere import:**
   ```python
   from api.tenant_context import TenantContext, require_auth
   from fastapi import Depends
   ```

2. **Aggiungere `tenant: TenantContext = Depends(require_auth)`** a ogni endpoint

3. **Aggiungere filtro `tenant_id == tenant.tenant_id`** a ogni query

**Checklist per:`api/routes_*.py`:**

- [ ] `routes_auth.py` - Login/signup/user endpoints
- [ ] `routes_cfo.py` - CFO analysis endpoints (critical)
- [ ] `routes_cfo_advanced.py` - Advanced CFO endpoints
- [ ] `routes_cfo_strategy.py` - Strategy endpoints
- [ ] `routes_advice.py` - Advice endpoints
- [ ] `routes_alerts.py` - Alerts endpoints
- [ ] `routes_chat.py` - Chat endpoints
- [ ] `routes_knowledge.py` - Knowledge endpoints
- [ ] `routes_kpi.py` - KPI endpoints
- [ ] `routes_simulate.py` - Simulation endpoints
- [ ] `routes_valuation.py` - Valuation endpoints
- [ ] `other routes...`

---

## 🔐 Authentication Flow (diagramma)

```
┌─────────────────────────┐
│   Client Request        │
│  (with credentials)     │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────────────────────────┐
│ get_tenant_context() FastAPI Dependency    │
│  ├─ Extract JWT/API Key from headers       │
│  ├─ Verify token/key validity              │
│  └─ Return TenantContext with tenant_id    │
└────────────┬────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────┐
│ require_auth() Dependency                  │
│  ├─ Check if authenticated (JWT_REQUIRED)  │
│  ├─ Check if tenant is active              │
│  └─ Raise 401/403 if not valid             │
└────────────┬────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────┐
│ Route Handler                               │
│  @router.post("/endpoint")                 │
│  def handler(tenant: TenantContext = ...)  │
│    ├─ Get tenant_id from context           │
│    ├─ Query with .filter(               │  │
│    │   Model.tenant_id == tenant_id        │
│    │ )                                      │
│    └─ Return only tenant-specific data     │
└────────────┬────────────────────────────────┘
             │
             ▼
┌─────────────────────────┐
│   Return Response       │
│   (tenant-isolated)     │
└─────────────────────────┘
```

---

## 🧪 Testing Tenant Isolation

### Test 1: Verify JWT rejection (no credentials)

```bash
# ❌ Should fail with 401 Unauthorized
curl -X GET http://localhost:8002/cfo/companies \
  -H "Content-Type: application/json"

# Expected: 401 Unauthorized
# {"detail": "Not authenticated"}
```

### Test 2: Verify different tenants are isolated

```bash
# Create two test tenants
TENANT_A_JWT=$(curl -X POST http://localhost:8002/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "user_a@company.com", "password": "password"}' \
  | jq -r '.access_token')

TENANT_B_JWT=$(curl -X POST http://localhost:8002/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "user_b@other.com", "password": "password"}' \
  | jq -r '.access_token')

# Create data in tenant A
curl -X POST http://localhost:8002/companies \
  -H "Authorization: Bearer $TENANT_A_JWT" \
  -H "Content-Type: application/json" \
  -d '{"name": "Company A", "revenue": 1000000}'

# Try to read from tenant B  
curl -X GET http://localhost:8002/companies \
  -H "Authorization: Bearer $TENANT_B_JWT" \
  -H "Content-Type: application/json"

# Expected: Empty list [] - Tenant B should NOT see Tenant A's data!
# ✅ If you get [], tenant isolation works!
# ❌ If you see Company A, there's a security hole!
```

### Test 3: Verify API Key isolation

```bash
# Create API key for tenant A
TENANT_A_KEY=$(curl -X POST http://localhost:8002/api-keys \
  -H "Authorization: Bearer $TENANT_A_JWT" \
  -H "Content-Type: application/json" \
  -d '{"name": "Key A"}' | jq -r '.key')

# Use API key from tenant A to access tenant B's endpoint
curl -X GET http://localhost:8002/companies \
  -H "X-API-Key: $TENANT_A_KEY" \
  -H "X-Tenant-Id: tenant_b"

# Expected:
# ✅ Should only show tenant A's data (not tenant B)
# ❌ Should NOT allow accessing tenant B even with explicit header
```

### Test 4: Automated test suite

Copia questo in `test_tenant_isolation.py`:

```python
import pytest
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

@pytest.fixture
def tenant_a_jwt():
    # Login as tenant A user
    response = client.post("/auth/login", json={
        "email": "user_a@test.com",
        "password": "password"
    })
    return response.json()["access_token"]

@pytest.fixture
def tenant_b_jwt():
    # Login as tenant B user
    response = client.post("/auth/login", json={
        "email": "user_b@test.com",
        "password": "password"
    })
    return response.json()["access_token"]

def test_tenant_a_cannot_see_tenant_b_data(tenant_a_jwt, tenant_b_jwt):
    # Create data in tenant B
    client.post(
        "/companies",
        headers={"Authorization": f"Bearer {tenant_b_jwt}"},
        json={"name": "Secret Company", "revenue": 5000000}
    )
    
    # Access as tenant A
    response = client.get(
        "/companies",
        headers={"Authorization": f"Bearer {tenant_a_jwt}"}
    )
    
    # Should not see Secret Company
    companies = response.json()
    assert all(c["name"] != "Secret Company" for c in companies)

def test_unauthenticated_requests_rejected():
    response = client.get("/companies")
    assert response.status_code == 401

def test_api_key_respects_tenant():
    # Create API key for tenant A
    # Use it to access tenant B endpoint
    # Should fail or return empty
    pass
```

Run tests:
```bash
pytest test_tenant_isolation.py -v
```

---

## 📋 Implementation Checklist

### Phase 1: Security Configuration

- [ ] Update `.env` with `ZB_JWT_REQUIRED=true`
- [ ] Generate strong `ZB_JWT_SECRET` (minimum 48 chars)
- [ ] Update `api/config.py` to load JWT settings
- [ ] Run security scan: `python scripts/scan_tenant_isolation.py`

### Phase 2: Add Tenant Filtering to All Routes

For each `api/routes_*.py`:

```bash
# Count how many queries need fixing
grep -n "db.query" api/routes_cfo.py | wc -l
```

Then for EACH route:

- [ ] Import `TenantContext, require_auth`
- [ ] Add `tenant: TenantContext = Depends(require_auth)` parameter
- [ ] Add `.filter(Model.tenant_id == tenant.tenant_id)` to all queries
- [ ] Test endpoint remains functional

### Phase 3: Test & Verify

- [ ] Run unit tests: `pytest test_tenant_isolation.py`
- [ ] Manual test: Try accessing without JWT (should fail)
- [ ] Manual test: Try accessing other tenant's data (should return empty)
- [ ] Load test: Verify no performance degradation

### Phase 4: Audit & Documentation

- [ ] Document authentication flow in README
- [ ] Create onboarding guide for new developers
- [ ] Verify CORS correctly configured for frontend
- [ ] Document how to create API keys for customers

---

## 🚀 Quick Fix Template

If you want to fix routes quickly, use this template:

**In `api/routes_cfo.py` or any route file:**

```python
# ========== FIX TEMPLATE ==========
# COPY-PASTE this for each route that needs fixing

# OLD (❌ NOT SAFE)  
@router.get("/cfo/companies")
def get_companies(db: Session = Depends(get_session)):
    companies = db.query(Company).all()
    return companies

# NEW (✅ SAFE)
@router.get("/cfo/companies")
def get_companies(
    db: Session = Depends(get_session),
    tenant: TenantContext = Depends(require_auth),  # ← ADD THIS
):
    companies = db.query(Company).filter(
        Company.tenant_id == tenant.tenant_id  # ← ADD THIS
    ).all()
    return companies
```

---

## ⚡ Enablement Sequence

**DO IN THIS ORDER:**

1. ✅ Run `python scripts/scan_tenant_isolation.py` (find issues)
2. ✅ Fix routes one by one (test after each)
3. ✅ Run test suite: `pytest test_tenant_isolation.py`
4. ✅ Manual testing with 2 different users
5. ✅ Set `JWT_REQUIRED=true` in production config
6. ✅ Automated daily security scan in CI/CD

---

## 📞 Troubleshooting

**"401 Unauthorized" everywhere**
- Check JWT_REQUIRED setting
- Verify you're sending Authorization header
- Verify JWT token is not expired
- Check JWT_SECRET matches

**"403 Forbidden"**
- Tenant not found in database
- Check tenant_id in token
- Verify tenant is active

**Still seeing other tenant's data?**
- Query is missing `.filter(tenant_id == ...)`
- Check SQL logs: `ZB_DB_ECHO=true`
- Run security scan again

---

## 📚 Files Modified

When complete, these files should be changed:

- `api/config.py` - JWT_REQUIRED, JWT_SECRET added
- `api/routes_cfo.py` - Tenant filtering added
- `api/routes_cfo_advanced.py` - Tenant filtering added  
- `api/routes_auth.py` - Tenant filtering added
- (All other routes...)
- `test_tenant_isolation.py` - NEW file with tests

---

**Next:** After Task 2 is complete, proceed to **Task 3: Docker Containerization**
