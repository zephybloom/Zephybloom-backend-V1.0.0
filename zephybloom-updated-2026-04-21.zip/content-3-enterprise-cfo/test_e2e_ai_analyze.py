#!/usr/bin/env python3
"""
End-to-end test of /cfo/ai-analyze endpoint with proper tenant setup
"""

from fastapi.testclient import TestClient
from api.main import app
from db.session import get_session, init_db
from db.models import Tenant
from sqlalchemy.orm import Session

# Initialize database first
init_db()

# Create test client
client = TestClient(app)

def setup_test_tenant():
    """Create a test tenant in the database"""
    print("\n🔧 Setting up test tenant...\n")
    
    session = next(get_session())
    
    # Check if test tenant exists
    test_tenant = session.query(Tenant).filter_by(tenant_id="test-tenant").first()
    
    if not test_tenant:
        # Create test tenant
        test_tenant = Tenant(
            tenant_id="test-tenant",
            name="Test Tenant",
            is_active=True
        )
        session.add(test_tenant)
        session.commit()
        print("✅ Test tenant created")
    else:
        print("✅ Test tenant already exists")
    
    session.close()


def test_ai_analyze_with_mock():
    """Test /cfo/ai-analyze endpoint with mock provider"""
    print("🧪 Testing /cfo/ai-analyze Endpoint (Mock Provider)\n")
    
    test_request = {
        "fatturato": 5_000_000,
        "costi_variabili": 2_100_000,
        "costi_fissi": 1_500_000,
        "investimenti": 500_000,
        "settore": "manufacturing",
        "company_name": "Acme Inc"
    }
    
    try:
        response = client.post(
            "/cfo/ai-analyze?use_mock=true",
            json=test_request,
            headers={
                "X-Tenant-ID": "test-tenant",
                "X-API-Key": "test-key"
            }
        )
        
        print(f"📡 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            print("\n✅ SUCCESS - Response received:")
            print(f"  - Status: {data.get('status')}")
            print(f"  - Company: {data.get('company', {}).get('name')}")
            
            # Check AI response
            ai = data.get('ai_response', {})
            print(f"\n🤖 AI Response Fields:")
            print(f"  - Key Number: {ai.get('key_number', '')[:50]}...")
            print(f"  - Diagnostic: {ai.get('diagnostic', '')[:50]}...")
            print(f"  - Risk: {ai.get('risk_assessment', '')[:50]}...")
            print(f"  - Action: {ai.get('priority_action', '')[:50]}...")
            print(f"  - Other Actions: {len(ai.get('other_actions', []))} items")
            
            # Check formatted response
            formatted = data.get('formatted_text', '')
            if formatted:
                lines = formatted.split('\n')
                print(f"\n📄 Formatted Response ({len(lines)} lines):")
                for i, line in enumerate(lines[:10]):
                    print(f"    {line}")
                if len(lines) > 10:
                    print(f"    ... ({len(lines) - 10} more lines)")
            
            print(f"\n✅ Test PASSED!")
            return True
        
        else:
            print(f"\n❌ Request failed with status {response.status_code}")
            print(f"Response: {response.json()}")
            return False
    
    except Exception as e:
        print(f"❌ Test error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("=" * 70)
    print("🚀 ZephyBloom /cfo/ai-analyze Endpoint E2E Test")
    print("=" * 70)
    
    # Setup
    setup_test_tenant()
    
    # Test the endpoint
    test_ai_analyze_with_mock()
    
    print("\n" + "=" * 70)
