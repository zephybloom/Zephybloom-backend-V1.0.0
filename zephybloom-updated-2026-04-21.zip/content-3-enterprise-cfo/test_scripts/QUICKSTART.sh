#!/bin/bash
#
# ZephyBloom Phase 1 Quick Start Guide
# Run this to set up and test the complete Phase 1 implementation
#

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo "=========================================="
echo "ZephyBloom Phase 1 - Quick Start"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

# Step 1: Check virtual environment
echo -e "${BLUE}[1/5]${NC} Checking virtual environment..."
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

if [ ! -f "venv/bin/activate" ]; then
    echo "❌ Failed to create virtual environment"
    exit 1
fi
echo -e "${GREEN}✓${NC} Virtual environment ready"
echo ""

# Step 2: Install dependencies
echo -e "${BLUE}[2/5]${NC} Installing dependencies..."
if [ ! -f "requirements.txt" ]; then
    echo "❌ requirements.txt not found"
    exit 1
fi
./venv/bin/pip install -q -r requirements.txt 2>/dev/null
echo -e "${GREEN}✓${NC} Dependencies installed"
echo ""

# Step 3: Initialize database
echo -e "${BLUE}[3/5]${NC} Initializing database..."
rm -f zephytheory.db
./venv/bin/python3 -c "
from db.session import init_session_factory
init_session_factory()
print('✓ Database initialized')
"
echo ""

# Step 4: Start API server
echo -e "${BLUE}[4/5]${NC} Starting API server..."

# Kill any existing process on port 8888
lsof -ti:8888 2>/dev/null | xargs kill -9 2>/dev/null || true
sleep 1

# Start new server
./venv/bin/python3 run_api_phase1.py > /tmp/api.log 2>&1 &
API_PID=$!
sleep 3

# Check if server is running
if ! kill -0 $API_PID 2>/dev/null; then
    echo "❌ Failed to start API server"
    echo "See /tmp/api.log for details"
    cat /tmp/api.log
    exit 1
fi

echo -e "${GREEN}✓${NC} API server running (PID: $API_PID)"
echo "   URL: http://127.0.0.1:8888"
echo ""

# Step 5: Run endpoint tests
echo -e "${BLUE}[5/5]${NC} Running endpoint tests..."
echo ""

# Test health
HEALTH=$(curl -s http://127.0.0.1:8888/health 2>/dev/null | grep -c "healthy" || echo "0")
if [ "$HEALTH" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Health check: PASS"
else
    echo -e "❌ Health check: FAIL"
    kill $API_PID
    exit 1
fi

# Test registration
REGISTER=$(curl -s -X POST http://127.0.0.1:8888/api/v1/auth/register \
    -H "Content-Type: application/json" \
    -d '{
      "email": "demo@example.com",
      "password": "DemoPass123",
      "full_name": "Demo User"
    }' 2>/dev/null)

if echo "$REGISTER" | grep -q "success"; then
    USER_ID=$(echo "$REGISTER" | grep -o '"user_id":[0-9]*' | cut -d':' -f2)
    echo -e "${GREEN}✓${NC} Registration: PASS (User #$USER_ID)"
else
    echo -e "❌ Registration: FAIL"
    kill $API_PID
    exit 1
fi

# Test login
LOGIN=$(curl -s -X POST http://127.0.0.1:8888/api/v1/auth/login \
    -H "Content-Type: application/json" \
    -d '{
      "email": "demo@example.com",
      "password": "DemoPass123"
    }' 2>/dev/null)

if echo "$LOGIN" | grep -q "access_token"; then
    TOKEN=$(echo "$LOGIN" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
    echo -e "${GREEN}✓${NC} Login: PASS (Token: ${TOKEN:0:20}...)"
else
    echo -e "❌ Login: FAIL"
    kill $API_PID
    exit 1
fi

# Test API key creation
API_KEY=$(curl -s -X POST http://127.0.0.1:8888/api/v1/auth/api-keys \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d '{"name": "Demo Key"}' 2>/dev/null)

if echo "$API_KEY" | grep -q "sk_"; then
    echo -e "${GREEN}✓${NC} API Key Creation: PASS"
else
    echo -e "❌ API Key Creation: FAIL"
    kill $API_PID
    exit 1
fi

echo ""
echo "=========================================="
echo -e "${GREEN}✅ All tests passed!${NC}"
echo "=========================================="
echo ""
echo "API Server Details:"
echo "  URL: http://127.0.0.1:8888"
echo -e "  ${BLUE}API Docs:${NC} http://127.0.0.1:8888/docs"
echo -e "  ${BLUE}ReDoc:${NC} http://127.0.0.1:8888/redoc"
echo ""
echo "Database:"
echo "  File: $PROJECT_DIR/zephytheory.db"
echo "  Tables: users, tenants, api_keys, audit_logs, tenant_settings"
echo ""
echo "Running in background (PID: $API_PID)"
echo "Stop with: kill $API_PID"
echo ""
echo "Demo Credentials:"
echo "  Email: demo@example.com"
echo "  Password: DemoPass123"
echo "  Token: $TOKEN"
echo ""
