# Test Scripts & Utilities

This folder contains utility scripts for setting up and testing the ZephyBloom API.

## 🚀 Quick Start Script

### QUICKSTART.sh
One-command setup and testing:
```bash
bash QUICKSTART.sh
```

**What it does:**
1. Creates/verifies virtual environment
2. Installs all dependencies from requirements.txt
3. Initializes database (SQLite)
4. Starts API server on http://127.0.0.1:8888
5. Runs automatic endpoint tests
6. Displays demo credentials

**Expected output:**
```
✅ Virtual environment ready
✅ Dependencies installed
✅ Database initialized
✅ API server running (PID: 12345)
✅ All tests passed!
```

---

## 🧪 Individual Scripts

### run_api_phase1.py
Start the minimal test API server:

```bash
python3 run_api_phase1.py
```

**Features:**
- Minimal FastAPI app with only authentication endpoints
- Automatic database initialization on startup
- CORS configured
- Listens on: http://127.0.0.1:8888
- Reload enabled (auto-restart on file changes)

**Stop the server:**
```bash
lsof -ti:8888 | xargs kill -9
```

### init_db.py
Initialize the SQLite database with all tables:

```bash
python3 init_db.py
```

**What it does:**
1. Creates SQLite database file (zephytheory.db)
2. Creates 5 tables (users, tenants, api_keys, audit_logs, tenant_settings)
3. Sets up indexes and constraints
4. Verifies database connection

**Use when:**
- Setting up for the first time
- Database got corrupted
- Need to reset with fresh schema

### verify_imports.py
Verify all key modules can be imported:

```bash
python3 verify_imports.py
```

**Checks:**
- ✅ api.main
- ✅ api.config
- ✅ api.auth_service
- ✅ api.routes_auth
- ✅ db.models
- ✅ db.session
- ✅ core (if available)
- ✅ nlp (if available)
- ✅ rag (if available)

**Example output:**
```
Testing imports...
✅ api.main imported successfully
✅ api.config imported successfully
✅ api.auth_service imported successfully
✅ api.routes_auth imported successfully
✅ db.models imported successfully
✅ db.session imported successfully
✅ nlp.router imported successfully
✅ core.kpi_engine imported successfully
✅ rag.retriever imported successfully

✅ All 9 modules imported successfully!
```

---

## 📋 Usage Guide

### Scenario 1: Fresh Setup
```bash
# 1. Run complete setup with tests
bash QUICKSTART.sh

# API will be running at: http://127.0.0.1:8888
```

### Scenario 2: Existing Setup - Restart API
```bash
# Kill existing process (if any)
lsof -ti:8888 | xargs kill -9 2>/dev/null || true

# Start fresh
python3 run_api_phase1.py
```

### Scenario 3: Reset Database
```bash
# Stop API server first
lsof -ti:8888 | xargs kill -9 2>/dev/null || true

# Reinitialize database
python3 init_db.py

# Restart API
python3 run_api_phase1.py
```

### Scenario 4: Check Module Imports
```bash
# Verify all modules are importable
python3 verify_imports.py
```

---

## 🔧 Configuration

All scripts use settings from:
- `.env` file (if exists)
- `.env.example` (as fallback)
- Environment variables
- Hardcoded defaults

### Key Settings
```
DATABASE_URL=sqlite:///./zephytheory.db
JWT_SECRET_KEY=your-secret-key-here
REDIS_URL=redis://localhost:6379
DEBUG=False
```

---

## 🆘 Troubleshooting

### "Port 8888 already in use"
```bash
# Find process using port
lsof -ti:8888

# Kill it
lsof -ti:8888 | xargs kill -9

# Retry
python3 run_api_phase1.py
```

### "Database initialization failed"
```bash
# Remove old database
rm ../zephytheory.db

# Reinitialize
python3 init_db.py

# Restart API
python3 run_api_phase1.py
```

### "ImportError: No module named..."
```bash
# Verify all modules
python3 verify_imports.py

# Check virtual environment is activated
which python3  # Should show path with /venv/

# Reinstall dependencies
pip install -r ../requirements.txt
```

### "API not responding"
```bash
# Check if process is running
ps aux | grep python3

# Check API logs
tail -50 /tmp/api_phase1.log

# Restart
python3 run_api_phase1.py
```

---

## 📊 Related Files

| File | Purpose | Location |
|------|---------|----------|
| requirements.txt | Python dependencies | Root |
| .env.example | Configuration template | Root |
| setup.py | Package setup | Root |
| zephytheory.db | SQLite database | Root |
| test_phase1_endpoints.sh | Endpoint tests | ../test_reports/ |

---

## 🚀 Environment Variables

```bash
# Database
DATABASE_URL=sqlite:///./zephytheory.db

# JWT
JWT_SECRET_KEY=your-secret-key-here-at-least-32-chars
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=24

# Rate Limiting
REDIS_URL=redis://localhost:6379
RATE_LIMIT_API_KEY=100
RATE_LIMIT_TENANT=1000  
RATE_LIMIT_IP=30

# Server
DEBUG=False
HOST=127.0.0.1
PORT=8888
```

Set these in `.env` file at project root.

---

## 📈 API Information

Once running at http://127.0.0.1:8888:

| Endpoint | Purpose |
|----------|---------|
| /health | Health check |
| /docs | Swagger UI |
| /redoc | ReDoc documentation |
| /openapi.json | OpenAPI schema |
| /api/v1/auth/* | Authentication endpoints |

---

## ✅ Verification Checklist

After setup, verify everything works:

```bash
# 1. Check imports
python3 verify_imports.py
# Expected: ✅ All 9 modules imported successfully

# 2. Start API
python3 run_api_phase1.py &

# 3. Check health
curl http://127.0.0.1:8888/health
# Expected: {"status": "healthy", ...}

# 4. Run all tests
cd ../test_reports
bash test_phase1_endpoints.sh
# Expected: 6+ tests passing
```

---

**Last Updated:** April 14, 2026  
**Version:** 1.0.0-phase1  
**Status:** ✅ Ready to Use
