#!/usr/bin/env python3
"""
Verify all modules can be imported correctly.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

print("🔍 Testing module imports...\n")

tests = [
    ("db.models", "User, Tenant, APIKey, AuditLog"),
    ("db.session", "get_session"),
    ("api.config", "settings"),
    ("api.auth_service", "AuthService"),
    ("api.rate_limiter", "RateLimiter"),
    ("api.schemas_validation", "UserRegisterRequest"),
    ("api.middleware_ratelimit", "RateLimitMiddleware"),
    ("api.tenant_context", "TenantContext"),
    ("api.routes_auth", "router"),
]

success = 0
failed = 0

for module, items in tests:
    try:
        __import__(module)
        print(f"✅ {module:<40} ({items})")
        success += 1
    except Exception as e:
        print(f"❌ {module:<40} ERROR: {str(e)[:60]}")
        failed += 1

print(f"\n{'='*70}")
print(f"✅ Successful: {success} | ❌ Failed: {failed}")

if failed == 0:
    print("\n🎉 All imports working! Ready to start the API.")
    sys.exit(0)
else:
    print(f"\n⚠️  Fix {failed} import issue(s) before running API.")
    sys.exit(1)
