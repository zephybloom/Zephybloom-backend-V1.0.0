#!/usr/bin/env python3
"""
Initialize database by creating all tables.

Usage:
    python init_db.py
"""

import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from db.models import Base, User, Tenant, APIKey, AuditLog, TenantSettings
from api.config import settings

def init_db():
    """Create all database tables."""
    # Get database URL
    db_url = getattr(settings, 'DATABASE_URL', 'sqlite:///./zephytheory.db')
    
    print(f"📊 Initializing database: {db_url}")
    
    # Create engine and tables
    from sqlalchemy import create_engine
    engine = create_engine(db_url, echo=False)
    
    try:
        # Create all tables
        Base.metadata.create_all(engine)
        print("✅ Database tables created successfully!")
        
        # List created tables
        print("\n📋 Created tables:")
        for table in Base.metadata.sorted_tables:
            print(f"  - {table.name}")
        
        return True
    except Exception as e:
        print(f"❌ Error creating tables: {e}")
        return False

if __name__ == "__main__":
    success = init_db()
    sys.exit(0 if success else 1)
