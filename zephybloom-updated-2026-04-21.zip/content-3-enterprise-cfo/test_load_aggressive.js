/**
 * AGGRESSIVE LOAD TEST - ZephyBloom CFO API
 * 
 * This script performs an extreme load test to verify scalability improvements
 * 
 * Test Profile:
 * - Ramp-up: 0 → 500 VUs over 30 seconds
 * - Sustain: 500 concurrent users for 60 seconds
 * - Ramp-down: 500 → 0 over 15 seconds
 * - Total duration: ~105 seconds
 * 
 * Requests:
 * - 80% POST /cfo/analyze (with caching)
 * - 20% GET /health (baseline)
 * 
 * Expected metrics after optimizations:
 * - p95 latency: <50ms
 * - p99 latency: <100ms
 * - Error rate: <0.5%
 */

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend, Counter, Gauge } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');
const healthCheckDuration = new Trend('health_check_duration');
const analyzeCheckDuration = new Trend('analyze_duration');
const analyzeErrorRate = new Rate('analyze_errors');
const cacheHits = new Counter('cache_hits');
const cacheMisses = new Counter('cache_misses');
const activeVUs = new Gauge('active_vus');

// Test configuration
export const options = {
  stages: [
    // Ramp up: 0-500 VUs over 30 seconds
    { duration: '30s', target: 500 },
    // Sustain: 500 VUs for 60 seconds
    { duration: '60s', target: 500 },
    // Ramp down: 500-0 VUs over 15 seconds
    { duration: '15s', target: 0 },
  ],
  
  thresholds: {
    'http_req_duration': ['p(95)<50', 'p(99)<100'],  // p95<50ms, p99<100ms
    'errors': ['rate<0.005'],  // <0.5% error rate
    'analyze_duration': ['p(95)<100'],  // Analysis p95 < 100ms
  },
  
  // System tuning
  maxRedirects: 0,
  timeout: '30s',
};

// API configuration
const BASE_URL = __ENV.BASE_URL || 'http://localhost:8000';
const API_KEY = __ENV.API_KEY || 'test-api-key';
const TENANT_ID = __ENV.TENANT_ID || 'test-tenant';

/**
 * Generate random CFO analysis request
 */
function generateAnalysisRequest() {
  // Random revenue between 500k and 5M
  const fatturato = Math.floor(Math.random() * 4_500_000) + 500_000;
  // Variable costs 30-50% of revenue
  const ratio_var = 0.3 + Math.random() * 0.2;
  const costi_variabili = Math.floor(fatturato * ratio_var);
  // Fixed costs 20-40% of revenue
  const ratio_fix = 0.2 + Math.random() * 0.2;
  const costi_fissi = Math.floor(fatturato * ratio_fix);
  // Investments 5-15% of revenue
  const investimenti = Math.floor(fatturato * (0.05 + Math.random() * 0.1));
  
  const settori = ['manufacturing', 'saas', 'retail', 'default'];
  const settore = settori[Math.floor(Math.random() * settori.length)];
  
  return {
    fatturato,
    costi_variabili,
    costi_fissi,
    investimenti,
    settore,
    company_name: `Company-${Math.floor(Math.random() * 10000)}`,
  };
}

/**
 * Main test function
 */
export default function() {
  const vu = __VU;  // Virtual user ID
  activeVUs.add(1);
  
  // 80% of requests to /cfo/analyze, 20% to /health
  if (Math.random() < 0.8) {
    analyzeTest();
  } else {
    healthTest();
  }
  
  activeVUs.add(-1);
  
  // Small sleep between requests (more realistic)
  sleep(Math.random() * 0.5);
}

/**
 * POST /cfo/analyze test
 */
function analyzeTest() {
  const payload = generateAnalysisRequest();
  
  const response = http.post(
    `${BASE_URL}/cfo/analyze`,
    JSON.stringify(payload),
    {
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': API_KEY,
        'X-Tenant-Id': TENANT_ID,
      },
      timeout: '30s',
    }
  );
  
  // Track cache behavior
  const cacheHeader = response.headers['X-Cache-Status'];
  if (cacheHeader === 'HIT') {
    cacheHits.add(1);
  } else {
    cacheMisses.add(1);
  }
  
  // Track latency
  analyzeCheckDuration.add(response.timings.duration);
  
  // Validate response
  const success = check(response, {
    'POST /cfo/analyze status 200': (r) => r.status === 200,
    'analyze response has headline': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.headline !== undefined;
      } catch {
        return false;
      }
    },
    'analyze response time < 100ms': (r) => r.timings.duration < 100,
  });
  
  if (!success) {
    analyzeErrorRate.add(1);
  }
  
  errorRate.add(!success);
}

/**
 * GET /health baseline test
 */
function healthTest() {
  const response = http.get(
    `${BASE_URL}/health`,
    {
      headers: {
        'X-Tenant-Id': TENANT_ID,
      },
      timeout: '10s',
    }
  );
  
  healthCheckDuration.add(response.timings.duration);
  
  const success = check(response, {
    'GET /health status 200': (r) => r.status === 200,
    'health response has status ok': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.status === 'ok';
      } catch {
        return false;
      }
    },
  });
  
  errorRate.add(!success);
}

/**
 * Setup function - run once before all VUs
 */
export function setup() {
  console.log('🚀 Starting aggressive load test...');
  console.log(`📍 Target: ${BASE_URL}`);
  console.log(`👥 Max VUs: 500`);
  console.log(`⏱️  Duration: ~105 seconds`);
  console.log(`📊 Distribution: 80% /cfo/analyze, 20% /health`);
  
  // Warm-up request
  const warmupResponse = http.get(`${BASE_URL}/health`);
  console.log(`✅ Warm-up: ${warmupResponse.status}`);
  
  return { startTime: new Date() };
}

/**
 * Teardown function - run once after all VUs
 */
export function teardown(data) {
  const endTime = new Date();
  const duration = (endTime - new Date(data.startTime)) / 1000;
  console.log(`\n✅ Load test completed in ${duration.toFixed(1)}s`);
  console.log('📊 Check results above');
}
