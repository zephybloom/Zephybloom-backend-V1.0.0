# ZephyBloom CFO Enterprise - Pilot User Guide

**Version:** 1.0  
**Date:** 15 Aprile 2026  
**Language:** 🇮🇹 Italiano + 🇬🇧 English  

---

## Welcome / Benvenuto! 👋

Grazie di partecipare al pilota di ZephyBloom CFO Enterprise. Sei tra i 5-10 partner selezionati per testare questa nuova piattaforma di analisi finanziaria intelligente.

**What you'll do:**
- Provide your company's financial data
- Review AI-generated analysis
- Get strategic recommendations
- Share feedback (we read every comment!)

**What's in it for you:**
- Free access during pilot (2-3 weeks)
- Personalized financial insights
- Direct support channel
- Potential continued access post-pilot

---

## Getting Started / Cominciate

### 1. Login

```
URL: https://staging-api.zephybloom.it/
Username: [your email]
Password: [sent separately]
```

**First time?**
- Click "Forgot password" → Check email for reset link
- Use the reset link to create your password
- Your API key is in account settings

### 2. API Key Setup (Developers Only)

If you're integrating via API:

```bash
# Your unique API key (keep secret!)
export ZEPHYBLOOM_API_KEY="YOUR_KEY_HERE"

# Test connection
curl -H "Authorization: Bearer $ZEPHYBLOOM_API_KEY" \
     https://staging-api.zephybloom.it/health
# Expected: {"status": "healthy"}
```

### 3. Your Dashboard

Once logged in, you'll see:
- **Quick Analysis:** Analyze your company in 3 minutes
- **My Companies:** List of analyses you've run
- **Feedback:** Submit impressions & suggestions
- **Support:** Contact us with questions

---

## Analyzing Your Company / Analizzare la Tua Azienda

### Step 1: Enter Financial Data

You'll need 4 numbers (from your last full year):

1. **Fatturato** (Revenue)
   - Total sales, all products/services
   - Example: €1,500,000

2. **Costi Variabili** (Cost of Goods Sold)
   - Raw materials, direct labor, shipping
   - Scales with production volume
   - Example: €600,000

3. **Costi Fissi** (Operating Expenses)
   - Rent, salaries, utilities, insurance
   - Fixed regardless of sales
   - Example: €400,000

4. **Investimenti** (Investments/Capex)
   - Equipment, software, R&D
   - Annual spend on improvements
   - Example: €100,000

> **💡 Pro Tip:** Use your last 12-month P&L or business accounting software

### Step 2: Select Your Industry

Choose your sector for accurate comparison:
- 🏭 **Manifattura** (Manufacturing)
- 💻 **SaaS / Tech**
- 🏪 **Retail** (E-commerce, Boutique, Restaurant)
- 🏗️ **Altro** (Other)

> Your sector affects the "healthy" benchmarks. A SaaS company with 70% margin is healthy; a retailer with 70% margin is exceptional!

### Step 3: Click "Analyze"

The AI analyzes your financials and returns within **seconds**:

- ✅ **Status** (Healthy, Warning, or Critical)
- 📊 **Your KPIs** (Margins, Profitability, ROI)
- 🔍 **What's Working** (Your strengths)
- ⚠️ **What Needs Attention** (Your challenges)
- 💡 **3-5 Recommendations** (Actionable next steps)
- 📉 **Cost of Inaction** (Impact of not acting)

---

## Understanding the Results / Interpretare i Risultati

### Status Legend

**🟢 HEALTHY**
- Business is performing well
- Margins healthy for your sector
- Focus: Growth opportunities
- Urgency: Plan strategically

**🟡 WARNING**
- One or more metrics concerning
- Profitability declining or weak
- Focus: Address weak areas
- Urgency: Fix within 1-2 months

**🔴 CRITICAL**
- Urgent financial issues
- Negative or near-zero profit
- Focus: Immediate action required
- Urgency: Fix immediately

### Understanding KPIs

**Gross Margin %** (Gross Profit / Revenue)
- Shows: Pricing power & production efficiency
- Formula: (Revenue - COGS) / Revenue × 100%
- Healthy range: 30-75% (varies by sector)
- **Too low?** → Review pricing or COGS

**EBITDA Margin %** (Operating Profit before taxes / Revenue)
- Shows: Operational efficiency
- Formula: (Revenue - COGS - OpEx) / Revenue × 100%
- Healthy range: 15-40%
- **Too low?** → Review operating expenses

**Net Margin %** (Net Profit / Revenue)
- Shows: Bottom-line profitability
- Formula: (Net Profit) / Revenue × 100%
- Healthy range: 5-20%
- **Negative?** → Losing money, fix immediately

**ROI %** (Return on Investment)
- Shows: How well investments generate profit
- Formula: (Net Profit / Investment) × 100%
- Healthy: >15% annually
- **Low?** → Investments not generating returns

### Cost of Inaction

This metric shows: **What happens if you don't act?**

Example:
```
Current Monthly Loss: -€5,000

Cost of Inaction:
  • Quarterly (3 months):  -€15,000 (M × 3)
  • Annual (12 months):    -€60,000 (M × 12)

Action: Fix within 60 days = Saves €60,000 in annual losses
```

**This creates urgency.** A -€5,000/month problem is tolerable. A -€60,000/year problem demands immediate action.

---

## Recommendations / Recommendations

The AI generates 3-5 specific recommendations. Each includes:

1. **Title** - What to do
2. **Description** - Why it matters
3. **Impact** - Expected financial benefit (€)
4. **Priority** - Critical, High, Medium, Low
5. **Steps** - How to implement (specific, actionable)

### Example Recommendation

```
Title: Reduce Fixed Costs by 15%

Description:
Your fixed costs are 48% of revenue (healthy: <35%).
Reducing rent, staff, or overhead could free up €60,000/year.

Impact: €60,000 annual savings
Priority: CRITICAL
Steps:
  1. Audit all subscription services (software, tools) → eliminate unused ones
  2. Renegotiate with top 3 vendors → target 10% discounts
  3. Review staffing needs → eliminate redundancy
  4. Consolidate workspace → reduce rent by 20-30%
  Timeline: 30-60 days to implement fully
```

### How to Use Recommendations

**For Immediate Action (Week 1):**
- Delegate to relevant team member
- Set deadline (most important = this week)
- Track progress

**For Medium-term (Month 1-2):**
- Add to quarterly planning
- Assign owner & budget
- Monthly check-in

**For Strategic Planning (Month 3+):**
- Include in annual strategy
- Consider competitive advantage
- Link to growth initiatives

---

## Feedback / Feedback

We need **your honest feedback**. Not "does this make sense?" but "will this actually help my business?"

### Ways to Give Feedback

**Option 1: Web Form (Easiest)**
1. After analyzing, click "💬 Give Feedback"
2. Rate 1-5 stars on each dimension
3. Write any comments
4. Submit (takes 2 minutes)

**Option 2: Quick Survey**
- Email: pilot-support@zephybloom.it
- Subject: "Feedback on analysis [date]"
- Copy-paste the form below:

```
Company: [Name]
Sector: [SaaS/Manifattura/Retail/Altro]
Date: [Analysis date]

1. Did the status (Healthy/Warning/Critical) match your gut feeling?
   Rating: 1-5 ⭐

2. Were the recommendations practical to implement?
   Rating: 1-5 ⭐

3. Did the analysis change how you think about your business?
   Rating: 1-5 ⭐

4. What was most valuable?
   [Free text]

5. What confused you?
   [Free text]

6. What would make this more useful?
   [Free text]
```

**Option 3: Slack Chat**
- Join private Slack channel (link in onboarding email)
- Ask questions, share ideas, real-time feedback

**Option 4: Check-in Call**
- Schedule with pilot-support@zephybloom.it
- 30 minutes, Tuesday 2 PM (or flexible)
- Screen-share your analysis, discuss

### Feedback We Care About

✅ **Useful:**
- "The cost of inaction woke me up"
- "I didn't know our margin was that low"
- "These steps actually work"

✅ **Confusing:**
- "What does EBITDA mean?"
- "The recommendation contradicts another"
- "Numbers don't match my accounting"

✅ **Missing:**
- "I need to see sector benchmarks"
- "Can you project next quarter?"
- "What about my competitors?"

---

## Common Questions / Domande Comuni

### Q: Is my data confidential?
**A:** Yes. Your data is:
- Encrypted (TLS 1.3) in transit
- Encrypted at rest in our database
- Not shared with anyone
- Deleted after pilot unless you consent
- GDPR compliant

### Q: Why is the status different from my accountant's opinion?
**A:** Possible reasons:
1. Different time period (you = last 3 months, we = last 12 months)
2. Different accounting method (cash vs accrual)
3. Different definitions (e.g., "healthy" margin varies by sector)
4. One-time events (big customer, unexpected expense)

**What to do:** Share the analysis with your accountant. They'll validate.

### Q: Can I change the data and re-analyze?
**A:** Yes! Click "New Analysis" and try different scenarios:
- "What if we raised prices 10%?"
- "What if we cut 2 staff members?"
- "What if we landed this big customer?"

This is powerful for planning.

### Q: The recommendation doesn't apply to my business.
**A:** That's possible! The AI analyzes financials, not your unique situation. Use your judgment:
- ✅ Accept recommendations that fit
- ❌ Reject ones that don't
- 💬 Tell us why (helps us improve)

### Q: Can I export the analysis?
**A:** Yes. Click the **"Download PDF"** button to get a report.
Share with:
- Your accountant
- Your board/investors
- Your team

### Q: Who should I contact if something breaks?
**A:** Email pilot-support@zephybloom.it
- **Subject:** [ISSUE] Describe problem
- **Include:**
  - Your company name
  - What you were trying to do
  - Screenshot (if applicable)
  - Error message
- **Response time:** <4 hours (usually 1 hour)

---

## Advanced / Advanced Users API

### For Developers: Integrate via API

If you want to embed analysis into your app:

```bash
# 1. Get your API key from account settings

# 2. Analyze via API
curl -X POST https://staging-api.zephybloom.it/cfo/analyze \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "fatturato": 1500000,
    "costi_variabili": 600000,
    "costi_fissi": 400000,
    "investimenti": 100000,
    "settore": "saas"
  }'

# 3. Response (instant):
{
  "status": "healthy",
  "headline": "Business performing well",
  "summary": "Strong margins...",
  "kpi_snapshot": {
    "gross_margin_pct": 60,
    "ebitda_margin_pct": 35,
    "net_margin_pct": 15,
    "roi_pct": 150
  },
  "recommended_actions": [...],
  "cost_of_inaction": {
    "monthly_cost_eur": 0,
    "quarterly_cost_eur": 0,
    "annual_cost_eur": 0
  }
}
```

**Documentation:** https://dev.zephybloom.it/docs
**Questions:** dev-support@zephybloom.it

---

## Schedule / Calendario

**Your pilot experience:**

```
Week 1 (Today):     Onboarding, first analysis
Week 2:             Continue analysis, gather feedback (optional call)
Week 3:             Final feedback, wrap-up
Week 4:             Decide: Continue? Pause? Integrate?
```

**Key dates:**
- **Tuesday 2 PM:** Optional check-in calls (weekly)
- **Friday EOD:** Survey (quick, 2 min)
- **Day 22:** Exit interview (30 min)

---

## Support / Supporto

### Get Help

**For Technical Issues:**
- Email: pilot-support@zephybloom.it
- Slack: #pilot-support-channel
- Response: <4 hours

**For Data/Privacy Questions:**
- Email: privacy@zephybloom.it
- Response: <24 hours

**For Executive Questions:**
- Contact: [Name], Product Lead
- Email: [email]
- Response: <1 business day

### Escalation

**My analysis shows negative profit! Help!**
→ Emergency call: email "URGENT" + phone number

**The numbers don't match my accounting!**
→ Schedule deep-dive call with CFO team

**I have big ideas for the product!**
→ Save for end-of-pilot feedback session

---

## Thank You! 🙏

You're helping us build the future of SME financial intelligence. Your feedback directly shapes the product.

**We're here to help. Reach out anytime.**

**Next step:** Log in and analyze your company!

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 15 Apr 2026 | Initial pilot guide |

