# ZEPHYTHEORY CFO — MASTER ROADMAP (VERSIONE DEFINITIVA)

## 🎯 OBIETTIVO STRATEGICO

Costruire un sistema che **legge i dati finanziari → individua problemi → simula scenari → guida decisioni → quantifica impatto**.

### Due verità fondamentali:
- 👉 **NON è un tool** (tanti input, pochi output)
- 👉 **NON è una dashboard** (tanti numeri, poco insight)
- **🔴 È un CFO operativo che prende decisioni CON te**

---

## ⚙️ FASE 1 — BASE FINANZIARIA (FOUNDATION)

**Obiettivo:** Creare un motore che capisce i numeri come un CFO reale

### Dati minimi richiesti:
- fatturato
- costi variabili
- costi fissi
- investimenti
- prezzo medio
- costo variabile unitario

### KPI da calcolare (100% deterministici):
- Utile netto
- EBITDA
- Margine % (lordo, operativo, netto)
- Margine di contribuzione
- Break-even (unità e €)
- ROI
- Cash flow base
- Working capital

### Output NON solo numeri, ma DIAGNOSI:
```
SBAGLIATO: "Il margine è 12%"
CORRETTO: "Stai trattenendo troppo poco margine rispetto al volume (12% vs 18% settore). 
           Il problema NON è il fatturato ma la struttura dei costi. 
           Se non lo correggi, crescerai senza creare valore."
```

---

## ⚙️ FASE 2 — INTERPRETAZIONE CFO (CORE INTELLIGENCE)

**Obiettivo:** Trasformare i numeri in decisioni

### Il sistema DEVE sempre rispondere così:

1. **DIAGNOSI** — Cosa sta succedendo
2. **PROBLEMA PRINCIPALE** — La cosa che limita la crescita
3. **OPPORTUNITÀ** — Dove può migliorare
4. **AZIONI CONCRETE** — Cosa fare concretamente

### Esempio output CORRETTO:

```
❌ SBAGLIATO:
"Il margine è 12%"

✅ CORRETTO:
"Stai trattenendo troppo poco margine rispetto al volume che generi. 
Il problema non è il fatturato ma la struttura dei costi. 
Se non lo correggi, crescerai senza creare valore.

AZIONE IMMEDIATA:
1. Riduci costi fissi del 15% (impact: +€45K utile)
2. Aumenta prezzo medio del 3% (impact: +€18K utile)
3. Risultato: margine netto da 12% a 18% in 6 mesi"
```

---

## ⚙️ FASE 3 — SIMULAZIONI STRATEGICHE

**Obiettivo:** Permettere all'utente di testare decisioni

### Simulare:
- Aumento fatturato (% o €)
- Riduzione costi (% o €)
- Aumento prezzo
- Investimenti (capex, opex)
- Variazione volumi

### Output obbligatorio:
```
PRIMA:
- Fatturato: €1.5M
- Marginale lordo: €900K (60%)
- Utile netto: €450K (30%)

DOPO (simulazione):
- Fatturato: €1.95M (+30%)
- Margine lordo: €1.17M (60%)
- Utile netto: €585K (30%)
- Delta utile: +€135K
```

### Livello superiore: Tripl-scenario
- 📉 **Pessimistico:** -20% domanda, costi fissi stabili
- 📊 **Realistico:** +5% domanda naturale
- 📈 **Aggressivo:** +30% domanda, 10% cost reduction

---

## ⚙️ FASE 4 — CFO DECISIONALE (GAME CHANGER)

**Obiettivo:** Il sistema NON aspetta domande → GUIDA LUI

### Deve dire (autonomamente):
```
"La PRIORITÀ NON è crescere"
"Devi ridurre i costi prima di investire"
"Stai investendo troppo rispetto al ritorno"
"Casa capirai in 18 mesi è il dipendente, la crescita è secondaria"
```

**Questo è il punto di rottura.** La differenza tra un tool e un consulente.

---

## ⚙️ FASE 5 — ENGINE SCENARI AVANZATI

### 🧠 Calcolo 1: VALORE ASSUNZIONE DIPENDENTE

**Input:**
- Costo dipendente (RAL + contributi)
- Produttività attesa (€ generati)
- Tempo onboarding (mesi)
- Periodo (boom o crisi)

**Logica — Caso Boom:**
```
Scenario: Più domanda → capacità limitata
↓
Dipendente:
- aumenta fatturato direttamente
- riduce colli di bottiglia
- genera opportunità nuove

Formula:
Valore = (Incremento fatturato - Costo totale onboarding) - (Opportunità perse senza)
ROI = Valore / Costo dipendente

Output CFO:
"Assumere ora è vantaggioso se riesci a generare €X aggiuntivi.
Sotto questa soglia, il dipendente riduce il margine."
```

**Logica — Caso Crisi:**
```
Scenario: Crisi → rischio sovracosti
↓
Dipendente:
- aumenta costi fissi
- non aumenta proporzionalmente fatturato
- peggiora margine

Output CFO:
"NON assumere. Il costo sarà difficile da sostenere."
```

---

### 🧠 Calcolo 2: SCELTE STRATEGICHE QUANTIFICATE

Il sistema deve calcolare:

**A. Aumento prezzo (es. +5%)**
```
Input:
- Prezzo attuale
- Elasticità domanda (settore)
- Volume attuale

Output:
- Nuovo ricavo
- Nuovi clienti persi
- Nuovo utile
- Decisione: "Conveniente se elasticità < 0.8"
```

**B. Riduzione costi (es. -20%)**
```
Input:
- Costo attuale
- Aree di riduzione
- Rischio operativo

Output:
- Nuovo utile
- Rischi (quality, service, compliance)
- Break-even della riduzione
```

**C. Investimenti (es. macchinari €200K)**
```
Input:
- Costo investimento
- Incremento produttività
- Durata asset

Output:
- Payback period
- ROI (5 anni)
- Break-even dell'investimento
- Decisione: "Investimento positivo, payback in 18 mesi"
```

---

### 🧠 Calcolo 3: SCENARI COMPLESSI

**Esempio da supportare:**
```
"Se aumento prezzo del 5% ma perdo il 10% dei clienti,
e allo stesso tempo riduco costi del 12%,
cosa succede al mio utile in 12 mesi?"
```

**Output obbligatorio:**
```
PRIMA: €450K utile, €1.5M fatturato
DOPO:  €520K utile, €1.58M fatturato (+15.5%)

Delta: +€70K (+15.5% su utile)
Rischi: 
- 10% clienti persi = potenziale di riacquisto?
- 12% costo reduction = sostenibile?

DECISIONE: "Sì, ma monitora retention clienti"
```

---

## ⚙️ FASE 6 — MEMORIA CFO

**Obiettivo:** Diventa un consulente continuo che ricorda

### Memorizza:
- KPI storici (trend mensilali/annuali)
- Decisioni prese (e impatto reale vs previsto)
- Errori (pattern ricorrenti)
- Miglioramenti (cosa ha funzionato)

### Output:
```
"Tre mesi fa avevi:
- Margine netto: 18%
- Utile: €270K

Oggi:
- Margine netto: 12%
- Utile: €180K

PEGGIORAMENTO DEL 33% in 3 mesi.

Cosa è cambiato?
1. Costi fissi +€50K (nuovo dipendente?)
2. Margine lordo stabile
3. Volume fatturato stabile

Problema: costi fissi non controllati.
Azione: audita struttura di costo."
```

---

## ⚙️ FASE 7 — SISTEMA CONSULENZIALE (ALEX THEORY MODE)

**Il tono deve essere:**
- Diretto (senza giri di parole)
- Chiaro (numeri, non ipotesi)
- Senza filtri (la verità, anche se scomoda)
- Orientato al risultato (cosa fare, non cosa temere)

### Ogni risposta DEVE avere:

1. **VERITÀ** — Cosa sta succedendo
2. **IMPATTO** — Quanto ti costa
3. **AZIONE** — Cosa fare (concrete steps)

### Esempio risposta completa:

```
DOMANDA UTENTE:
"Devo assumere un nuovo commerciale per crescere il fatturato?"

RISPOSTA CFO (ALEX THEORY):

VERITÀ:
"Hai ragione che il commerciale potrebbe generare €300K fatturato.
Ma i numeri dicono che se lo assumi, il tuo costo RAL + contributi sarà €45K/anno.
Questo riduce il margine netto da 30% a 27% ("costo nascosto" del commerciale)."

IMPATTO:
"Assunto il commerciale:
- Fatturato: €1.5M → €1.8M (+€300K)
- Utile netto: €450K → €486K (+€36K)
- ROI commerciale: 80% (ha pagato se genera €300K+)

MA:
- Se genera solo €150K? Il ROI è negativo (-€20K utile)
- Se genera €200K? ROI marginale (0%)

Soglia di break-even: il commerciale deve generare €220K."

AZIONE:
1. Definisci compenso variabile (non fisso) 
   → Paga €20K fisso + 3% su fatturato generato
   → Risk = split tra azienda e commerciale

2. Test per 3 mesi
   → Vedi se riesce a generare €18K/mese (dati mensili)
   → Se no, non continuare

3. Se continui, monitora
   → Mese 4-6: ridurrai il margine se sottoperforma
   → Usa questo dato per negoziare"

DECISIONE: "Assumi, ma con compenso variabile. Il rischio è controllato."
```

---

## ⚙️ FASE 8 — LIVELLO TOP MONDO

**Qui batte tutti i competitor.**

### 1. PRIORITÀ AUTOMATICHE
```
Dashboard principale mostra:
- OGGI (adesso): cosa fare
- QUESTA SETTIMANA: priorità 1, 2, 3
- QUESTO MESE: decisioni importanti
- PROSSIMI 3 MESI: piano strategico

Non è l'utente che decide le priorità.
È il sistema che guida l'utente.
```

### 2. ALERT CRITICI
```
Logica:
- Se cash flow nei prossimi 60 giorni
  diventa negativo → ALERT RED
  
- Se margine scende sotto soglia settore
  → ALERT YELLOW
  
- Se un KPI devia dal trend
  → ALERT INFO (esplicativo)

Output:
"ALERT: Attenzione, il cash flow nei prossimi 2 mesi potrebbe diventare negativo
se continui con la spesa corrente e non incassi i clienti.

Azione immediata:
1. Accelera incassi (+15 giorni)
2. Rimanda spese non critiche (-€30K)
3. Risultato: cash flow positivo"
```

### 3. PIANO D'AZIONE DATO DAL SISTEMA

Il sistema propone un piano, non l'utente che lo chiede:

```
PIANO PER MIGLIORARE UTILE NETTO DA €450K a €600K

Step 1 (Settimana 1-4): QUICK WIN
- Ridurre costi fissi del 10% (€45K reduction)
- Impact immediato: +€45K utile
- Risk: basso (efficienza, non tagli)
- Owner: CFO

Step 2 (Settimana 5-8): MEDIUM TERM
- Aumentare prezzo medio del 3% (elasticità controllata)
- Impact: +€45K fatturato → +€27K utile (60% margin)
- Risk: medio (perdita 5% clienti = -€15K)
- Owner: Sales

Step 3 (Settimana 9-12): STRATEGIC
- Investire €100K in automation
- ROI: 2 anni
- Impact a regime: -€20K costi, +€25K capacità
- Risk: alto (implementation)
- Owner: Operations

RISULTATO FINALE:
Utile netto: €450K → €597K (+€147K = +32.6%)
Timeline: 12 settimane
Risk profile: medio-basso (60% azioni low-risk, 40% medium-risk)
```

### 4. VALORE OGNI DECISIONE

Ogni scelta deve rispondere a 4 domande:

```
SCELTA: "Assumere commerciale €45K/anno"

1. QUANTO GUADAGNI?
   "Se genera €300K fatturato: +€36K utile annuo (80% ROI)"

2. QUANTO PERDI?
   "Se fallisce o genera <€150K: -€20K utile"

3. RISCHIO?
   "Dipende da 2 fattori: mercato (-30% risk), performer (-50% risk)
   Risk totale: medio"

4. TIMING?
   "Ora è il momento? Sì, perché:
   - Margine è sano (30%)
   - Cash flow è positivo
   - Mercato è in crescita"
```

---

## 🚀 RISULTATO FINALE

Se fatto bene, il prodotto diventa:

### ✅ Non sostituibile
Nessun altro tool fa queste cose.

### ✅ Percepito come consulente reale
Non è uno strumento, è un partner.

### ✅ Facile da vendere
CFO reale costerebbe €3-5K/mese.
Questo costa €200-500/mese.
ROI ovvio per l'imprenditore.

---

## 📌 TASK PRIORITARI PER BACKEND

### PRIORITY 1 (Questa settimana):
1. ✅ Potenziare engine KPI
   - Aggiungere: break-even, margine di contribuzione, cash flow
   - Precisione totale

2. ✅ Implementare "diagnosi CFO"
   - Non solo KPI, ma interpretazione
   - Output: diagnosi + problema + azione

### PRIORITY 2 (Prossima settimana):
3. ✅ Creare modulo simulazioni multi-scenario
   - Pessimistico / Realistico / Aggressivo

4. ✅ Implementare calcolo ROI decisioni
   - Prezzo, costi, investimenti

5. ✅ Creare modulo assunzione dipendenti
   - Calcolo VA dipendente
   - Decisi autonoma: assumere sì/no

### PRIORITY 3 (Due settimane):
6. ✅ Implementare memoria KPI
   - Trend storico, variazioni, anomalie

7. ✅ Migliorare output consulenziale
   - Tono CFO, senza giri di parole

8. ✅ Aggiungere priorità automatiche
   - Il sistema guida, non aspetta

9. ✅ Creare alert sistema
   - Cash flow, margine, deviazioni

---

## ⚠️ VERITÀ FINALE

### Il successo NON dipende da:
- Quanti KPI hai
- Quante feature hai
- Quanti colori sulla dashboard

### Dipende SOLO da questo:
### 👉 **QUANTO IL SISTEMA FA PRENDERE DECISIONI MIGLIORI AL CFO/IMPRENDITORE**

Se il tuo sistema fa un'azione che genera €100K di utile in più → SUCCESSO.
Se il tuo sistema ha 50 KPI ma nessuno sa cosa fare → FALLIMENTO.

---

**Data creazione:** 14 aprile 2026  
**Status:** MASTER ROADMAP DEFINITIVA  
**Proprietario:** Zephytheory Project  
**Versione:** 1.0 - FINAL
