# Pilot Deployment - Quick Reference Guide

**For Operations & Support Teams**

---

## Daily Morning Checklist (5 min)

```bash
# 1. System alive?
curl https://staging-api.zephybloom.it/health
# Expected: {"status": "healthy", "version": "1.0"}

# 2. Any overnight errors?
tail -50 /var/log/zephybloom/errors.log

# 3. Backup completed?
ls -lh /backups/pilot/*backup | tail -1
# Should be within last 24 hours

# 4. Database OK?
sqlite3 /var/lib/zephybloom/pilot.db "SELECT COUNT(*) FROM pilot_users;"

# 5. All services running?
systemctl status zephybloom-api zephybloom-monitoring
```

**If ❌ anything fails:** EMAIL OPS LEAD IMMEDIATELY

---

## Monitoring Dashboard (Quick Commands)

```bash
# Real-time dashboard
python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log --watch 30

# Export today's metrics
python3 scripts/pilot_monitoring.py --log-file /var/log/zephybloom/pilot.log \
  --export metrics_$(date +%Y%m%d).json

# Check specific endpoint performance
grep "POST /cfo/analyze" /var/log/zephybloom/pilot.log | \
  jq -r '.response_time_ms' | \
  awk '{sum+=$1; sumsq+=$1*$1; n++} END {
    mean=sum/n;
    sd=sqrt(sumsq/n - mean*mean);
    printf "Endpoint /cfo/analyze:\n";
    printf "  Requests: %d\n", n;
    printf "  Avg: %.2fms\n  StdDev: %.2fms\n", mean, sd
  }'

# Find slowest requests
grep "response_time_ms" /var/log/zephybloom/pilot.log | \
  jq -r '[.response_time_ms, .endpoint, .tenant_id] | @csv' | \
  sort -t, -k1 -rn | head -10
```

---

## Support Response Templates

### Urgent Issue

**From:** pilot-support@zephybloom.it
**To:** User
**Subject:** We're on it! ZephyBloom Issue #[ticket]

```
Hi [Name],

Thanks for reporting this. I'm looking into it right now.

You reported: [their issue in one sentence]

What I'm checking:
□ System logs for errors
□ Your specific request
□ Database integrity
□ Similar issues from others

Next: I'll email you back within [1 hour/2 hours] with either:
• The fix
• Workaround instructions
• Timeline for resolution

In the meantime, here's what you can try:
[If applicable: specific steps]

Thanks for your patience!
[Name], ZephyBloom Support
```

### Clarifying Question

**Subject:** Quick question about your issue

```
Hi [Name],

One more detail to help me debug faster:

You analyzed company: [company name], sector: [sector]
With revenue: €[amount]

You said: [their issue]

To help: Can you share (if comfortable):
□ Your exact inputs (revenue, costs, investment)?
□ Screenshot of the result?
□ What you expected instead?
□ When did this happen?

Reply to this email and I'll investigate immediately.

Thanks!
[Name]
```

### Issue Resolved

**Subject:** ✅ Fixed! ZephyBloom Issue #[ticket]

```
Hi [Name],

Great news! We've resolved your issue.

**The Problem:** [What was wrong]

**The Fix:** [What we changed]

**Action for you:** [Do they need to do anything?]

**Verification:** Please try [action] again and let me know if it works.

If you still see the issue, reply here and we'll escalate immediately.

Thanks for helping us improve!
[Name]
```

---

## Escalation Flowchart

```
User Issue Reported
       ↓
   [TRIAGE]
   • Severity? (Critical / High / Medium / Low)
   • Can I fix it? (Yes / No)
       ↓
   [CRITICAL?]
   ├─→ YES: Call ops-team@zephybloom.it
   │        Email user immediately
   │        Assign ticket 🔴 URGENT
   │
   └─→ NO: Continue...
       ↓
   [CAN I FIX?]
   ├─→ YES: Troubleshoot, implement fix, verify
   │        Follow-up email within 4 hours
   │        Close ticket ✅
   │
   └─→ NO: Escalate to engineering
        Send full ticket + logs
        Tell user: "ETA [time]"
        Update every 2 hours
```

---

## Common Issues & Fixes

### Issue: User Can't Login

**Symptom:** "Invalid API key" or "User not found"

**Debug:**
```bash
# Check user exists
sqlite3 /var/lib/zephybloom/pilot.db \
  "SELECT email, api_key FROM pilot_users WHERE email='user@example.com';"

# Check API key format
# Should be: pilot_key_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX (36 chars)
echo "pilot_key_xxx" | wc -c  # Should be 37 (36 + newline)
```

**Fix:**
- Resend API key via email
- or: Reset password in web dashboard
- or: Generate new API key

### Issue: Analysis Returns Status "UNKNOWN"

**Symptom:** Response has status field but it's not "healthy|warning|critical"

**Debug:**
```bash
# Check what went wrong
grep "tenant_id=USER_XXX" /var/log/zephybloom/pilot.log | \
  grep "error_type" | tail -1

# Possible causes:
# - Invalid inputs (revenue < 0, costs > revenue)
# - Missing fallback value
# - Module crashed
```

**Fix:**
1. If invalid inputs: Ask user to verify numbers
2. If module crash: Check logs for which module failed
3. If fallback failed: Escalate to engineering (critical)

### Issue: Response Time Slow (>500ms)

**Symptom:** User reports "taking forever to get results"

**Debug:**
```bash
# Check system load
top -b -n 1 | head -10  # CPU, memory

# Check database performance
sqlite3 /var/lib/zephybloom/pilot.db "PRAGMA optimize;"

# Check log for slow queries
grep "response_time_ms.*[5-9][0-9][0-9]" /var/log/zephybloom/pilot.log | \
  jq -r '.endpoint' | sort | uniq -c | sort -rn
```

**Fix:**
1. If CPU/memory high: Scale resources
2. If database slow: Vacuum database
3. If specific endpoint slow: Escalate to engineering

### Issue: Data Privacy / "Is My Data Safe?"

**Symptom:** User asks about data handling

**Response Template:**
```
Yes, your data is safe with us.

Here's exactly what happens to your financial data:

1. ENCRYPTION:
   • Your data is encrypted when stored
   • Your data is encrypted when transmitted (TLS 1.3)
   • Only our system can read it

2. RETENTION:
   • During pilot (now - Week 3): We keep your data
   • After pilot: We DELETE all your data within 30 days
   • Exception: You can ask to keep it (we ask permission)

3. PRIVACY:
   • We don't share your data with anyone
   • We don't sell your data
   • We don't use it to train AI on your case
   • We use anonymized aggregates for learning only

4. COMPLIANCE:
   • We follow GDPR (EU data regulations)
   • You can request all your data anytime
   • You can request deletion anytime

5. BACKUP:
   • Daily backup: In case of disaster
   • Same encryption as production

Questions? Reply or call [number].
```

---

## Weekly Reporting (Friday 5 PM)

**Executive Summary Email**

```
Subject: Pilot Update - Week [N] Summary

TO: [CFO / Product Lead]

HEADLINE:
✅ Pilot ongoing, 5/10 companies active, metrics green

METRICS:
• API Uptime: 99.95% ✅
• Avg Response: 45ms ✅
• Error Rate: 0.2% ✅
• Users: 5 active (1 deployed this week)
• Analyses: 12 completed
• Feedback Responses: 4/5 (80%)

USER FEEDBACK SUMMARY:
• Avg Satisfaction: 4.1/5 ⭐
• Would Recommend: 80%
• Top Praise: "Cost of Inaction motivated action"
• Top Concern: "Wants competitor benchmarks"

ISSUES:
• Critical: None
• High: None
• Medium: Display formatting edge case (minor UI issue)

NEXT WEEK:
• Add users 6, 7, 8 (planned Day 15)
• Weekly sync calls with 3 companies
• Review medium priority UI issue
• On track for Green Light decision (Day 23)

RISK ASSESSMENT:
🟢 GREEN - All systems nominal, no blockers visible
```

---

## Slack Notifications

### Status at 9 AM

```
:zephybloom: Good morning! Here's today's status:

System: :white_check_mark: UP (99.95% uptime this week)
Errors: :white_check_mark: 0 critical overnight
Database: :white_check_mark: All systems green

Users: 5 active, 12 analyses this week
Next: User 6 onboarding today

Questions? #pilot-support
```

### Alert Example (Urgent)

```
:rotating_light: :warning: ALERT - High Error Rate Detected!

Error Rate: 5.2% (last 30 min) - ABOVE THRESHOLD

Endpoint: POST /cfo/analyze
Status: Investigating

Action: Please check your systems
Timeline: Update in 15 min

More: See #pilot-ops-alert
```

---

## Documentation Links

**Team Wiki:**
- Pilot Plan: [link to PILOT_DEPLOYMENT_PLAN.md]
- User Guide: [link to PILOT_USER_GUIDE.md]
- Feedback System: [link to PILOT_FEEDBACK_SYSTEM.md]
- Deployment Checklist: [link to DEPLOYMENT_READINESS_CHECKLIST.md]

**URLs:**
- Staging API: https://staging-api.zephybloom.it
- API Docs: https://staging-api.zephybloom.it/docs
- Monitoring: http://staging.local:8001/monitor
- Support Request: pilot-support@zephybloom.it

**Contacts:**
- On-call Lead: [Name] [Phone]
- Product Owner: [Name] [Email]
- Engineering Lead: [Name] [Email]
- Privacy Officer: [Name] [Email]

---

## Success Mantras 💪

**Remember:**
- ✅ 154/154 critical tests passed
- ✅ 315+/347 total tests passed
- ✅ JSON contract is stable
- ✅ Fallback mechanisms work
- ✅ Performance is sub-millisecond

**This system is solid. Trust it.**

When users worry: "Don't worry, it's been tested extensively."
When you're tired: "This is the easy part. You've got this."
When things break (rarely): "We'll fix it. Document, learn, move on."

---

**Last Updated:** 15 April 2026
**Status:** ✅ PILOT LIVE
**Next Phase:** Monitor → Analyze → Scale

