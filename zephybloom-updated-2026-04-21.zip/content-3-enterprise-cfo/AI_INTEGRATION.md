# 🤖 ZephyBloom AI Integration Guide

## Overview

ZephyBloom's CFO API now includes **AI-powered financial analysis** using OpenAI's ChatGPT GPT-4o model. This provides intelligent, conversational financial advice in the professional "Alex Theory" template format.

## Features

✅ **AI-Powered Analysis**: Uses ChatGPT to generate intelligent CFO insights  
✅ **Template Format**: Responses follow the "Alex Theory" template with emoji indicators  
✅ **Trend Context**: AI analysis includes historical trend data  
✅ **Multi-language**: Configurable for Italian, English, etc.  
✅ **Mock Mode**: Test without OpenAI API key  
✅ **Low Cost**: ~€0.002 per analysis query  

## Setup

### 1. Get OpenAI API Key

1. Go to: https://platform.openai.com/api-keys
2. Create a new API key
3. Copy the key (format: `sk-...`)

### 2. Configure Environment

#### Option A: Local Development
```bash
# Copy example to .env
cp .env.example .env

# Edit .env and add your OpenAI key
OPENAI_API_KEY=sk-YOUR_KEY_HERE
OPENAI_MODEL=gpt-4o
USE_MOCK_AI=false
```

#### Option B: Railroad/Production
Set environment variables in your hosting platform:
- `OPENAI_API_KEY`: Your OpenAI API key
- `OPENAI_MODEL`: gpt-4o (or gpt-4-turbo, gpt-3.5-turbo)

### 3. Install Dependencies
```bash
pip install openai>=1.3.9
```
(Already in requirements.txt, no additional install needed)

## Usage

### New Endpoint: POST /cfo/ai-analyze

Combines financial analysis with AI-powered CFO insights.

#### Request
```bash
curl -X POST http://localhost:8000/cfo/ai-analyze \
  -H "X-Tenant-ID: tenant-001" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "fatturato": 5000000,
    "costi_variabili": 2100000,
    "costi_fissi": 1500000,
    "investimenti": 500000,
    "settore": "manufacturing",
    "company_name": "Acme Inc"
  }'
```

#### Query Parameters
- `use_mock=true` - Use mock AI provider (for testing, no API key needed)
- `specific_question=string` - Ask a specific question about the company

#### Response
```json
{
  "status": "success",
  "timestamp": 1713352623.456,
  "company": {
    "name": "Acme Inc",
    "sector": "manufacturing"
  },
  "base_analysis": {
    "status": "healthy",
    "headline": "Company health assessment",
    "kpi_snapshot": {...}
  },
  "ai_response": {
    "key_number": "📊 Gross Margin...",
    "headline": "...",
    "diagnostic": "🧠 Diagnosis...",
    "risk_assessment": "⚠️ Risk assessment...",
    "priority_action": "🎯 Action...",
    "other_actions": [...],
    "estimated_impact": "💥 Impact...",
    "why_it_matters": "🧭 Why it matters...",
    "strategic_advice": "🧠 Strategic advice..."
  },
  "formatted_text": "📊 NUMERO CHIAVE\n...\n🧠 CONSIGLIO STRATEGICO\n...",
  "trend_context": "Historical trends..."
}
```

### Testing Without API Key

#### Mock Mode
Use the `use_mock=true` parameter to test without an API key:

```bash
curl -X POST http://localhost:8000/cfo/ai-analyze?use_mock=true \
  -H "X-Tenant-ID: tenant-001" \
  -H "Content-Type: application/json" \
  -d '{...}'
```

#### Test Script
```bash
python3 test_ai_integration.py
python3 test_endpoint_ai_analyze.py
```

## Response Template

All AI responses follow the **"Alex Theory"** CFO template:

```
📊 NUMERO CHIAVE
The most critical KPI for this situation

Headline summary

🧠 DIAGNOSI
Root cause analysis in 2-3 sentences

⚠️ RISCHIO
Impact if no action is taken (financial numbers)

🎯 AZIONE PRIORITARIA
The #1 thing to do next week

📈 ALTRE AZIONI
• Secondary action 1
• Secondary action 2
• Secondary action 3

💥 IMPATTO STIMATO
Estimated savings/gains in EUR

🧭 PERCHÉ CONTA
Why this action is strategically important

🧠 CONSIGLIO STRATEGICO
Senior-level strategic recommendation
```

## API Costs

**Pricing Model**: ~€0.002 - €0.003 per analysis

- **OpenAI GPT-4o**: $0.005 input / $0.015 output tokens
- **Average query**: ~150 input + 200 output tokens = €0.0025
- **Monthly cost** (assuming 1000 queries): ~€2.50

### Cost Optimization

1. Use `gpt-3.5-turbo` for cost savings (~€0.0003 per query)
2. Cache responses for repeat questions
3. Use mock provider in development/testing

## Configuration Options

### AI Provider Settings
```python
from infra.ai_provider import get_ai_provider

# Use OpenAI (requires OPENAI_API_KEY env var)
provider = get_ai_provider("openai")

# Use mock provider (for testing)
provider = get_ai_provider("mock")
```

### Custom System Prompt
Edit the `SYSTEM_PROMPT` in `infra/ai_provider.py` to customize AI behavior:

```python
SYSTEM_PROMPT = """Tu sei un CFO Senior...
[customize for your needs]
"""
```

## Troubleshooting

### "OPENAI_API_KEY not set"
```bash
# Check if key is in .env
cat .env | grep OPENAI_API_KEY

# If not set, add it:
export OPENAI_API_KEY=sk-YOUR_KEY

# Test:
python3 -c "import os; print(os.getenv('OPENAI_API_KEY'))"
```

### "API key invalid"
- Verify key starts with `sk-`
- Check key hasn't expired on OpenAI dashboard
- Verify account has credits

### Response timeout
- Check OpenAI API status: https://status.openai.com/
- Try again (transient issue)
- Use mock provider to test without API

## Integration with Frontend

### Lovable Integration
```javascript
const response = await fetch(`${API_BASE_URL}/cfo/ai-analyze?use_mock=false`, {
  method: 'POST',
  headers: {
    'X-Tenant-ID': tenantId,
    'X-API-Key': apiKey,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    fatturato: 5000000,
    costi_variabili: 2100000,
    costi_fissi: 1500000,
    investimenti: 500000,
    settore: 'manufacturing'
  })
});

const data = await response.json();
console.log(data.formatted_text);  // Display to user
```

### React Dashboard Integration
```jsx
const [aiResponse, setAiResponse] = useState(null);

const handleAiAnalyze = async () => {
  const response = await fetch('/cfo/ai-analyze?use_mock=true', {
    method: 'POST',
    headers: {
      'X-Tenant-ID': tenantId,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(companyData)
  });
  
  const data = await response.json();
  setAiResponse(data.ai_response);
};
```

## Architecture

```
Client (Lovable/Frontend)
    ↓
POST /cfo/ai-analyze
    ↓
FastAPI Route (api/routes_cfo.py)
    ↓
Base Analysis (core/analysis.py)
    ↓
Company Data → AI Provider
    ↓
openai.ChatCompletion.create()
    ↓
ChatGPT GPT-4o
    ↓
Response Parsing (CFOAnalysisAI)
    ↓
JSON Response with formatted_text
    ↓
Client displays response
```

## Security

### API Key Management
- ✅ Store in environment variables (not in code)
- ✅ Use different keys for dev/prod
- ✅ Rotate keys periodically
- ✅ Monitor usage for unusual patterns

### Data Privacy
- ✅ Company data sent securely over HTTPS
- ✅ No PII stored in OpenAI logs
- ✅ Option to use on-premise LLMs

## Advanced Usage

### Custom Questions
```bash
curl -X POST 'http://localhost:8000/cfo/ai-analyze?specific_question=How%20can%20we%20improve%20margins%20by%2025%25%3F' \
  ...
```

### Trend Context
Responses automatically include historical trend data if available:
```json
"trend_context": "Revenue up 8% MoM, Gross margin down 2%, EBITDA stable"
```

### Fallback to Mock
If OpenAI API fails, endpoint automatically falls back to mock provider:
```python
try:
    provider = CFOGPTProvider()
except ValueError:
    provider = MockCFOGPTProvider()  # Fallback
```

## Support

For issues:
1. Check error message in response
2. Review logs: `tail -f debug.log`
3. Test with mock provider first
4. Verify OpenAI account has credits

## References

- OpenAI API Docs: https://platform.openai.com/docs
- Model Pricing: https://openai.com/pricing
- Railway Deployment: https://railway.app/docs
- ZephyBloom Architecture: `PHASE2_CFO_IMPLEMENTATION.md`
