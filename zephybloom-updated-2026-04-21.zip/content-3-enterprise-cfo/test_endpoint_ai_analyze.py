#!/usr/bin/env python3
"""
End-to-end test of /cfo/ai-analyze endpoint
Simulates a POST request without needing to start the server
"""

from fastapi.testclient import TestClient
from api.main import app
import json
import os

# Create test client
client = TestClient(app)

# Test data
test_request = {
    "fatturato": 5_000_000,
    "costi_variabili": 2_100_000,
    "costi_fissi": 1_500_000,
    "investimenti": 500_000,
    "settore": "manufacturing",
    "company_name": "Acme Inc"
}

def test_ai_analyze_with_mock():
    """Test /cfo/ai-analyze endpoint with mock provider"""
    print("\n🧪 Testing /cfo/ai-analyze Endpoint (Mock Provider)\n")
    
    # First, get auth token (or use mock token if auth is disabled in dev)
    # For this test, we'll try without auth to see if it's required
    
    try:
        # Test with mock=true parameter to skip OpenAI API
        response = client.post(
            "/cfo/ai-analyze?use_mock=true",
            json=test_request,
            headers={
                "X-Tenant-ID": "test-tenant",
                "Authorization": "Bearer test-token"
            }
        )
        
        print(f"📡 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            print("\n✅ SUCCESS - Response received:")
            print(f"  - Status: {data.get('status')}")
            print(f"  - Company: {data.get('company', {}).get('name')}")
            print(f"  - Timestamp: {data.get('timestamp')}")
            
            # Check base analysis
            base = data.get('base_analysis', {})
            print(f"\n📊 Base Analysis:")
            print(f"  - Status: {base.get('status')}")
            print(f"  - Headline: {base.get('headline')[:60]}...")
            print(f"  - Net Profit: €{base.get('kpi_snapshot', {}).get('net_profit_eur', 0):,.0f}")
            
            # Check AI response
            ai = data.get('ai_response', {})
            print(f"\n🤖 AI Response:")
            print(f"  - Key Number: {ai.get('key_number', '')[:60]}...")
            print(f"  - Diagnostic: {ai.get('diagnostic', '')[:80]}...")
            print(f"  - Risk Assessment: {ai.get('risk_assessment', '')[:80]}...")
            print(f"  - Priority Action: {ai.get('priority_action', '')[:80]}...")
            
            # Check formatted text
            formatted = data.get('formatted_text', '')
            print(f"\n📄 Formatted Response (first 500 chars):")
            print(formatted[:500])
            print("...")
            
            print(f"\n✅ Test PASSED - /cfo/ai-analyze endpoint is working!")
            return True
        
        elif response.status_code == 401:
            print("\n⚠️  Auth required - testing with valid token...")
            print(f"Response detail: {response.json()}")
            return False
        
        else:
            print(f"\n❌ Request failed with status {response.status_code}")
            print(f"Response: {response.json()}")
            return False
    
    except Exception as e:
        print(f"❌ Test error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_endpoint_exists():
    """Check that the endpoint is registered"""
    print("\n🧪 Checking if /cfo/ai-analyze endpoint exists\n")
    
    # List all routes
    print("📋 Available endpoints:")
    cfo_routes = [route.path for route in app.routes if '/cfo' in route.path]
    
    for route in sorted(cfo_routes):
        print(f"  - {route}")
    
    if "/cfo/ai-analyze" in cfo_routes:
        print("\n✅ /cfo/ai-analyze endpoint is registered!")
        return True
    else:
        print("\n❌ /cfo/ai-analyze endpoint NOT found!")
        return False


if __name__ == "__main__":
    print("=" * 70)
    print("🚀 ZephyBloom /cfo/ai-analyze Endpoint Test")
    print("=" * 70)
    
    # Check endpoints
    if test_endpoint_exists():
        # Test the endpoint
        test_ai_analyze_with_mock()
    else:
        print("\n⚠️  Endpoint not found, skipping test")
    
    print("\n" + "=" * 70)
