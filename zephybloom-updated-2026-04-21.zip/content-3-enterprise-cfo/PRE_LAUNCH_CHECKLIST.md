# Pre-Launch Checklist (April 15 Evening)

**Run these 5 tests tonight to confirm everything works tomorrow morning.**

---

## ✅ Test 1: Can You Start the Server? (2 min)

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo

# This should start without errors
chmod +x START_APP.sh
./START_APP.sh &

# Wait 5 seconds for startup
sleep 5

# Test the health endpoint
curl http://localhost:8001/health
```

**Expected output:**
```json
{
  "status": "healthy",
  "timestamp": "2026-04-15T...",
  "version": "1.0.0"
}
```

**If you see `"status": "healthy"` → ✅ PASS**

Stop the server with `Ctrl+C` in the first terminal.

---

## ✅ Test 2: Can You Create a Pilot User? (2 min)

```bash
# Still in the project folder
python3 scripts/create_pilot_user.py \
  --email test@example.com \
  --company "Test Company" \
  --sector "SaaS"
```

**Expected output:**
```
✅ PILOT USER CREATED
================================================
Email:              test@example.com
Company:            Test Company
Sector:             SaaS
Tenant:             example.com

Temporary Password: [Random password shown]
                    (User must change on first login)
================================================
```

**If you see the password and "CREATED" → ✅ PASS**

---

## ✅ Test 3: Can You List Pilot Users? (1 min)

```bash
python3 scripts/create_pilot_user.py --list
```

**Expected output:**
```
================================================================================
PILOT USERS
================================================================================
Email                          Company                  Created        
--------------------------------------------------------------------------------
test@example.com               Test Company             2026-04-15     
================================================================================
```

**If you see the user you just created → ✅ PASS**

---

## ✅ Test 4: Can You Access API Docs? (2 min)

```bash
# Start server again
./START_APP.sh &

# Wait 5 seconds
sleep 5

# In your browser, go to:
# http://localhost:8001/docs
```

You should see:
- Swagger UI documentation
- A list of endpoints (POST /cfo/analyze, POST /cfo/chat, etc.)
- Green "Authorize" button (optional authentication)

**If you see the Swagger interface → ✅ PASS**

Stop server with `Ctrl+C`.

---

## ✅ Test 5: Can You Run One Analysis? (3 min)

```bash
# Start server one more time
./START_APP.sh &
sleep 5

# Test the /health endpoint first
curl http://localhost:8001/health

# Then test the /cfo/analyze endpoint
curl -X POST http://localhost:8001/cfo/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "fatturato": 1000000,
    "costi_variabili": 400000,
    "costi_fissi": 300000,
    "investimenti": 100000,
    "company_name": "Test Company",
    "settore": "saas"
  }'
```

**Expected output (should be JSON with analysis):**
```json
{
  "status": "warning",
  "headline": "Financial analysis shows...",
  "summary": "...",
  "kpi_snapshot": {
    "gross_profit_eur": 600000,
    "gross_margin_pct": 60.0,
    ...
  },
  "estimated_loss_eur": 50000,
  "potential_recovery_eur": ...,
  "recommended_actions": [...]
}
```

**If you see JSON analysis → ✅ PASS**

Stop server with `Ctrl+C`.

---

## 📋 Summary

If ALL 5 tests pass, you're ready for tomorrow:

```
✅ Test 1: Server starts              PASS / FAIL
✅ Test 2: Create pilot user          PASS / FAIL
✅ Test 3: List pilot users           PASS / FAIL
✅ Test 4: Access API docs            PASS / FAIL
✅ Test 5: Run analysis               PASS / FAIL

Overall: ✅ READY / ⚠️  NEEDS DEBUG
```

---

## If Something Fails

**Common fixes:**

| Problem | Fix |
|---------|-----|
| `python3: command not found` | Install Python 3.9+ from python.org |
| `Port 8001 already in use` | Use different port: `./START_APP.sh --port 9000` |
| `Module not found` | Update dependencies: `pip install -r requirements.txt` |
| `Database error` | Delete and recreate: `rm zephytheory.db && ./START_APP.sh` |
| `Permission denied on START_APP.sh` | Fix permissions: `chmod +x START_APP.sh` |

**If still stuck:**
- Check that you're in the right folder: `pwd` should show `content-3-enterprise-cfo`
- Check Python version: `python3 --version` should be 3.9+
- Check all files exist: `ls -la api/main.py db/models.py requirements.txt`

---

## Tomorrow at 9 AM

When you're ready to launch:

```bash
cd /Users/thestar23/Downloads/content-3-enterprise-cfo
./START_APP.sh
```

**That's it. Server will be running.**

Then follow: `DAY1_RECRUITING_STAND.md` for your recruitment timeline.

---

**You've got this.** ✅ 🚀
