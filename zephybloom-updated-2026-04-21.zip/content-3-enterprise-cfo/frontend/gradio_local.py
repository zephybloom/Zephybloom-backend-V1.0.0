from __future__ import annotations

# content/frontend/gradio_local.py — UI locale (KPI, What-if, Pricing, Forecast, Valuation, WC, Alerts, Chat CFO)
import os
import json
from typing import Any, Dict, List, Optional, Tuple

import gradio as gr
import requests

# ---------- Settings fallback ----------
try:
    from content.api.config import settings
except Exception:
    class _S:
        BACKEND_BASE_URL = os.getenv("ZB_BACKEND_BASE_URL", "http://127.0.0.1:8000")
        APP_API_KEY = os.getenv("ZB_APP_API_KEY")
    settings = _S()  # type: ignore

# ---------- HTTP helpers ----------
def _base_url() -> str:
    url = getattr(settings, "BACKEND_BASE_URL", None) or "http://127.0.0.1:8000"
    return url.rstrip("/")

def _headers() -> Dict[str, str]:
    h = {"Content-Type": "application/json"}
    app_key = getattr(settings, "APP_API_KEY", None) or os.getenv("ZB_APP_API_KEY")
    if app_key:
        h["X-API-KEY"] = app_key
    return h

def api_get(path: str, params: Optional[Dict[str, Any]] = None) -> Tuple[bool, Any]:
    try:
        r = requests.get(f"{_base_url()}{path}", params=params, headers=_headers(), timeout=15)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:500])
    except Exception as e:
        return False, str(e)

def api_post(path: str, payload: Dict[str, Any]) -> Tuple[bool, Any]:
    try:
        r = requests.post(f"{_base_url()}{path}", data=json.dumps(payload), headers=_headers(), timeout=30)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:800])
    except Exception as e:
        return False, str(e)

# ---------- Defaults ----------
DEF = dict(
    fatturato=1_200_000.0,
    costi_variabili=660_000.0,
    costi_fissi=300_000.0,
    ammortamenti=50_000.0,
    investimenti=200_000.0,
    prezzo_medio=40.0,
    costo_variabile_unitario=22.0,
    dso=35.0, dio=30.0, dpo=30.0,
    price_elasticity=-1.2,
)

# ---------- Formatters ----------
def _fmt_eur(x: Any, decimals: int = 0) -> str:
    try:
        v = float(x)
        s = f"{abs(v):,.{decimals}f}".replace(",", " ").replace(".", ",").replace(" ", ".")
        return f"{'-' if v < 0 else ''}€ {s}"
    except Exception:
        return "€ 0"

def _fmt_pct(x: Any, decimals: int = 1) -> str:
    try:
        v = float(x)
        return f"{v:.{decimals}f}%".replace(".", ",")
    except Exception:
        return "0,0%"

def _fmt_eu(x: Any, d: int = 0) -> str:
    try:
        v = float(x)
        return f"{v:,.{d}f}".replace(",", " ").replace(".", ",").replace(" ", ".")
    except Exception:
        return "0"

# ---------- Actions ----------
def act_kpi(fatt, cv, cf, amm, inv, p0, cvu, dso, dio, dpo):
    payload = {
        "fatturato": fatt, "costi_variabili": cv, "costi_fissi": cf,
        "ammortamenti": amm, "investimenti": inv,
        "prezzo_medio": p0, "costo_variabile_unitario": cvu,
        "dso": dso, "dio": dio, "dpo": dpo,
    }
    ok, out = api_post("/kpi/compute", payload)
    if not ok:
        return f"❌ {out}", None
    lines = [
        f"Ricavi: {_fmt_eur(out.get('fatturato', 0))}",
        f"Utile: {_fmt_eur(out.get('utile', 0))}",
        f"EBITDA: {_fmt_eur(out.get('ebitda', 0))}",
        f"MC: {_fmt_eur(out.get('margine_contribuzione', 0))} ({_fmt_pct((out.get('mc_rate', 0) or 0)*100)})",
        f"BEP ricavi: {_fmt_eur(out.get('break_even', 0))}",
    ]
    return "\n".join(lines), out

def act_simulate(fatt, cv, cf, amm, inv, p0, cvu, f_pct, cv_pct, cf_pct, price_pct, el):
    base = {
        "fatturato": fatt, "costi_variabili": cv, "costi_fissi": cf,
        "ammortamenti": amm, "investimenti": inv,
        "prezzo_medio": p0, "costo_variabile_unitario": cvu,
    }
    delta = {
        "fatturato_pct": f_pct, "costi_variabili_pct": cv_pct, "costi_fissi_pct": cf_pct,
        "price_pct": price_pct, "price_elasticity": el,
    }
    ok, out = api_post("/simulate", {"base": base, "delta": delta})
    if not ok:
        return f"❌ {out}", None
    txt = (
        f"Ricavi {_fmt_eur(out.get('fatturato', 0))} | "
        f"Utile {_fmt_eur(out.get('utile', 0))} | "
        f"EBITDA {_fmt_eur(out.get('ebitda', 0))} | "
        f"MC {_fmt_eur(out.get('margine_contribuzione', 0))} "
        f"({_fmt_pct((out.get('mc_rate', 0) or 0)*100)})"
    )
    return txt, out

def act_optimize_price(fatt, cf, p0, cvu, el):
    base = {
        "fatturato": fatt, "costi_fissi": cf,
        "prezzo_medio": p0, "costo_variabile_unitario": cvu,
        "price_elasticity": el,
    }
    ok, out = api_post("/optimize/price", {"base": base})
    if not ok:
        return f"❌ {out}"
    return f"Prezzo ottimale: {out.get('best_pct',0):+.1f}% → {_fmt_eur(out.get('best_price',0))}; Utile: {_fmt_eur(out.get('best_profit',0))}"

def act_price_ladder(fatt, cf, p0, cvu, el, pct_min, pct_max, pct_step):
    base = {
        "fatturato": fatt, "costi_fissi": cf,
        "prezzo_medio": p0, "costo_variabile_unitario": cvu,
        "price_elasticity": el,
    }
    ok, out = api_post("/whatif/price_ladder", {
        "base": base, "pct_min": pct_min, "pct_max": pct_max, "pct_step": pct_step
    })
    if not ok:
        return f"❌ {out}", None
    rows = out.get("rows", []) or []
    table = [["Δ%", "Prezzo", "Q.ty", "Ricavi", "Utile"]]
    for r in rows:
        table.append([
            f"{r['pct']:+.1f}%",
            _fmt_eur(r["price"]),
            _fmt_eu(r["quantity"], 0),
            _fmt_eur(r["revenue"]),
            _fmt_eur(r["profit"]),
        ])
    best = out.get("best")
    best_txt = "—"
    if best:
        best_txt = f"Best {best['pct']:+.1f}% → prezzo {_fmt_eur(best['price'])}, utile {_fmt_eur(best['profit'])}"
    return best_txt, table

def act_forecast(history_csv: str, periods: int, method: str):
    try:
        hist = [float(x.strip().replace(",", ".")) for x in history_csv.split(",") if x.strip()]
    except Exception:
        return "Formato storico non valido.", None
    ok, out = api_post("/forecast", {"history": hist, "periods": periods, "method": method})
    if not ok:
        return f"❌ {out}", None
    fc = out.get("forecast", [])
    s = ", ".join(_fmt_eu(v, 0) for v in fc)
    # come output semplice usiamo una tabella (x, y)
    table = [["t", "forecast"]]
    for i, v in enumerate(fc, 1):
        table.append([i, v])
    return f"Forecast: {s}", table

def act_valuation_project(cashflows_csv: str, rate: float):
    try:
        cfs = [float(x.strip().replace(",", ".")) for x in cashflows_csv.split(",") if x.strip()]
    except Exception:
        return "Formato CF non valido.", None
    ok, out = api_post("/valuation", {"cashflows": cfs, "discount_rate_pct": rate})
    if not ok:
        return f"❌ {out}", None
    pe = out.get("project_eval", {})
    txt = f"NPV {_fmt_eur(pe.get('npv',0))}, IRR {_fmt_pct(pe.get('irr',0),2)}, Payback {int(pe.get('payback_period',-1))} anni"
    return txt, pe

def act_valuation_dcf(fcf_csv: str, wacc: float, g: float, net_debt: float):
    try:
        fcf = [float(x.strip().replace(",", ".")) for x in fcf_csv.split(",") if x.strip()]
    except Exception:
        return "Formato FCF non valido.", None
    ok, out = api_post("/valuation", {
        "dcf_fcf": fcf, "discount_rate_pct": wacc, "terminal_growth_pct": g, "net_debt": net_debt
    })
    if not ok:
        return f"❌ {out}", None
    d = out.get("dcf", {})
    txt = f"EV {_fmt_eur(d.get('enterprise_value',0))}, Equity {_fmt_eur(d.get('equity_value',0))} (WACC {_fmt_eu(d.get('wacc_pct',0),2)}%)"
    return txt, d

def act_wc(fatt, cv, dso, dio, dpo, ddso, ddio, ddpo):
    base = {
        "fatturato": fatt, "costi_variabili": cv,
        "dso": dso, "dio": dio, "dpo": dpo,
        "dso_delta": ddso, "dio_delta": ddio, "dpo_delta": ddpo,
    }
    ok, out = api_post("/whatif/wc_impact", {"base": base})
    if not ok:
        return f"❌ {out}"
    return (
        f"CCC: {_fmt_eu(out.get('ccc_before',0),0)} → {_fmt_eu(out.get('ccc_after',0),0)} "
        f"(Δ {_fmt_eu(out.get('delta_ccc',0),0)} giorni)\n"
        f"Fabbisogno CC: {_fmt_eur(out.get('wc_need_before',0))} → {_fmt_eur(out.get('wc_need_after',0))} "
        f"(Δ cassa {_fmt_eur(out.get('delta_cash',0))})"
    )

# Chat CFO — prova POST /chat, fallback /chat/ask
def act_chat(history: List[Tuple[str, str]], user_input: str):
    msg = user_input or ""
    ctx = {}  # puoi passare qui tenant_id/sector ecc.
    ok, out = api_post("/chat", {"text": msg, "context": ctx})
    if not ok:
        ok2, out2 = api_post("/chat/ask", {"text": msg, "context": ctx})
        if not ok2:
            bot = f"❌ {out2}"
            return history + [(user_input, bot)], ""
        out = out2
    # normalizza risposta
    narrative = out.get("narrative") if isinstance(out, dict) else None
    bot = narrative or (json.dumps(out, ensure_ascii=False) if out is not None else "(nessuna risposta)")
    return history + [(user_input, bot)], ""

# ---------- UI ----------
def build_ui() -> gr.Blocks:
    with gr.Blocks(title="ZephyBloom CFO – Local Demo") as demo:
        gr.Markdown("## ZephyBloom — CFO Console (Locale)")

        with gr.Tabs():
            with gr.Tab("KPI"):
                with gr.Row():
                    fatt = gr.Number(label="Fatturato", value=DEF["fatturato"])
                    cv = gr.Number(label="Costi variabili", value=DEF["costi_variabili"])
                    cf = gr.Number(label="Costi fissi", value=DEF["costi_fissi"])
                with gr.Row():
                    amm = gr.Number(label="Ammortamenti", value=DEF["ammortamenti"])
                    inv = gr.Number(label="Investimenti", value=DEF["investimenti"])
                with gr.Row():
                    p0 = gr.Number(label="Prezzo medio", value=DEF["prezzo_medio"])
                    cvu = gr.Number(label="CV unitario", value=DEF["costo_variabile_unitario"])
                with gr.Row():
                    dso = gr.Number(label="DSO", value=DEF["dso"])
                    dio = gr.Number(label="DIO", value=DEF["dio"])
                    dpo = gr.Number(label="DPO", value=DEF["dpo"])
                run = gr.Button("Calcola KPI", variant="primary")
                out_txt = gr.Textbox(label="Sintesi", lines=5)
                out_json = gr.JSON(label="Dettaglio KPI", visible=False)
                run.click(act_kpi, inputs=[fatt, cv, cf, amm, inv, p0, cvu, dso, dio, dpo], outputs=[out_txt, out_json])

            with gr.Tab("Simulate"):
                f_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ Ricavi %")
                cv_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CV %")
                cf_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CF %")
                price_pct = gr.Slider(-20, 20, value=0, step=0.5, label="Δ Prezzo %")
                el = gr.Number(label="Elasticità", value=DEF["price_elasticity"])
                run_sim = gr.Button("Applica")
                sim_txt = gr.Textbox(label="Output", lines=3)
                sim_json = gr.JSON(label="Dettaglio", visible=False)
                run_sim.click(act_simulate, inputs=[fatt, cv, cf, amm, inv, p0, cvu, f_pct, cv_pct, cf_pct, price_pct, el], outputs=[sim_txt, sim_json])

            with gr.Tab("Pricing"):
                run_opt = gr.Button("Prezzo ottimale")
                opt_txt = gr.Textbox(label="Risultato", lines=2)
                run_opt.click(act_optimize_price, inputs=[fatt, cf, p0, cvu, el], outputs=[opt_txt])

                gr.Markdown("### Price ladder")
                pct_min = gr.Slider(-30, 0, value=-10, step=1, label="Min %")
                pct_max = gr.Slider(0, 30, value=10, step=1, label="Max %")
                pct_step = gr.Slider(0.5, 10, value=2, step=0.5, label="Step %")
                run_lad = gr.Button("Genera ladder")
                lad_best = gr.Textbox(label="Sintesi Best", lines=2)
                lad_table = gr.Dataframe(headers=["Δ%", "Prezzo", "Q.ty", "Ricavi", "Utile"], label="Ladder", interactive=False)
                run_lad.click(act_price_ladder, inputs=[fatt, cf, p0, cvu, el, pct_min, pct_max, pct_step], outputs=[lad_best, lad_table])

            with gr.Tab("Forecast"):
                hist = gr.Textbox(label="Storico (CSV)", value="180000,190000,200000,210000,220000,230000")
                periods = gr.Slider(1, 24, value=6, step=1, label="Orizzonte")
                method = gr.Dropdown(choices=["holt", "sma", "naive", "drift"], value="sma", label="Metodo")
                run_fc = gr.Button("Forecast")
                fc_txt = gr.Textbox(label="Output", lines=2)
                fc_tbl = gr.Dataframe(headers=["t", "forecast"], label="Serie", interactive=False)
                run_fc.click(act_forecast, inputs=[hist, periods, method], outputs=[fc_txt, fc_tbl])

            with gr.Tab("Valuation"):
                gr.Markdown("#### Project: NPV/IRR/Payback")
                cf_str = gr.Textbox(label="Cashflows (CSV, includi CF0)", value="-300000,120000,130000,140000,150000")
                rate = gr.Number(label="Discount rate (%)", value=10.0)
                run_pe = gr.Button("Calcola")
                pe_txt = gr.Textbox(label="Risultato", lines=2)
                pe_json = gr.JSON(label="Dettaglio", visible=False)
                run_pe.click(act_valuation_project, inputs=[cf_str, rate], outputs=[pe_txt, pe_json])

                gr.Markdown("#### DCF Equity")
                fcf_str = gr.Textbox(label="FCF (CSV anni 1..n)", value="250000,270000,290000,300000,310000")
                wacc = gr.Number(label="WACC (%)", value=11.0)
                g = gr.Number(label="g terminale (%)", value=2.0)
                nd = gr.Number(label="Net Debt", value=500000.0)
                run_dcf = gr.Button("Calcola DCF")
                dcf_txt = gr.Textbox(label="Risultato", lines=2)
                dcf_json = gr.JSON(label="Dettaglio", visible=False)
                run_dcf.click(act_valuation_dcf, inputs=[fcf_str, wacc, g, nd], outputs=[dcf_txt, dcf_json])

            with gr.Tab("Working Capital"):
                ddso = gr.Slider(-30, 30, value=0, step=1, label="Δ DSO (giorni)")
                ddio = gr.Slider(-30, 30, value=0, step=1, label="Δ DIO (giorni)")
                ddpo = gr.Slider(-30, 30, value=0, step=1, label="Δ DPO (giorni)")
                run_wc = gr.Button("Calcola impatto")
                wc_txt = gr.Textbox(label="Risultato", lines=3)
                run_wc.click(act_wc, inputs=[fatt, cv, dso, dio, dpo, ddso, ddio, ddpo], outputs=[wc_txt])

            with gr.Tab("Alerts / Rules"):
                run_al = gr.Button("Valuta alert")
                al_out = gr.Textbox(label="Alert attivi", lines=10)
                def _alerts():
                    ctx = {
                        "fatturato": float(fatt.value), "costi_variabili": float(cv.value), "costi_fissi": float(cf.value),
                        "prezzo_medio": float(p0.value), "costo_variabile_unitario": float(cvu.value),
                        "dso": float(dso.value), "dio": float(dio.value), "dpo": float(dpo.value),
                    }
                    ok, out = api_post("/alerts/evaluate", {"context": ctx})
                    if not ok:
                        return f"❌ {out}"
                    alerts = out.get("alerts", []) or []
                    if not alerts:
                        return "Nessun alert."
                    return "\n".join(f"[{a.get('severity','INFO').upper()}] {a.get('title','')}" for a in alerts[:10])
                run_al.click(_alerts, inputs=[], outputs=[al_out])

            with gr.Tab("Chat CFO"):
                gr.Markdown("Chiedi al CFO virtuale (usa gli endpoint /chat o /chat/ask del backend).")
                chat = gr.Chatbot(label="CFO Assistant", height=420)
                usr = gr.Textbox(label="Messaggio", placeholder="Es: quanto è il mio utile?")
                send = gr.Button("Invia", variant="primary")
                clear = gr.Button("Pulisci")
                def _send(history, msg):
                    return act_chat(history or [], msg)
                send.click(_send, inputs=[chat, usr], outputs=[chat, usr])
                clear.click(lambda: ([], ""), inputs=[], outputs=[chat, usr])

        gr.Markdown(
            f"Backend: **{_base_url()}** — Se vedi 401, imposta `ZB_APP_API_KEY`.\n"
            "Apri la scheda **Chat CFO** per provare la conversazione."
        )

    return demo

def main():
    demo = build_ui()
    # porta standard gradio
    port = int(os.getenv("PORT", "7860"))
    # host 0.0.0.0 per ambienti docker/colab
    url = demo.launch(server_name="0.0.0.0", server_port=port, share=False, prevent_thread_lock=True)
    # Stampa link utile
    print("\n=== Gradio in esecuzione ===")
    print(f"UI  →  http://127.0.0.1:{port}")
    if isinstance(url, tuple) and len(url) >= 1 and url[0]:
        print(f"Public/External: {url[0]}")
    print("============================\n")
    # Mantieni vivo il processo
    import time
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
