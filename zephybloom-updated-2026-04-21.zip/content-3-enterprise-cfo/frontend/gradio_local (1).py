# -*- coding: utf-8 -*-
# content/frontend/gradio_local.py — UI Gradio con Chat CFO + auto-boot backend (compat vecchie versioni)

from __future__ import annotations
import os, sys, json, time, threading
from typing import Any, Dict, Tuple, List

import requests
import gradio as gr

# ===================== Config & defaults =====================
DEF_BASE = {
    "fatturato": 1_200_000, "costi_variabili": 660_000, "costi_fissi": 300_000,
    "ammortamenti": 50_000, "investimenti": 200_000,
    "prezzo_medio": 40, "costo_variabile_unitario": 22,
    "dso": 35, "dio": 30, "dpo": 30, "price_elasticity": -1.2
}
DEF_SECTOR = os.getenv("ZB_SECTOR", "default")
DEF_TENANT = os.getenv("ZB_TENANT_ID", "demo")

def backend_base_url() -> str:
    return (os.getenv("BACKEND_BASE_URL") or "http://127.0.0.1:8000").rstrip("/")

def _headers() -> Dict[str, str]:
    h = {"Content-Type": "application/json"}
    if os.getenv("ZB_APP_API_KEY") or os.getenv("APP_API_KEY"):
        h["X-API-KEY"] = os.getenv("ZB_APP_API_KEY") or os.getenv("APP_API_KEY")
    if os.getenv("ZB_TENANT_ID"):
        h["X-Tenant-Id"] = os.getenv("ZB_TENANT_ID")
    return h

# ===================== HTTP helpers =====================
def api_get(path: str, timeout: float = 10) -> Tuple[bool, Any]:
    try:
        r = requests.get(f"{backend_base_url()}{path}", headers=_headers(), timeout=timeout)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:300])
    except Exception as e:
        return False, str(e)

def api_post(path: str, payload: Dict[str, Any], timeout: float = 30) -> Tuple[bool, Any]:
    try:
        r = requests.post(f"{backend_base_url()}{path}", data=json.dumps(payload), headers=_headers(), timeout=timeout)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:800])
    except Exception as e:
        return False, str(e)

def api_post_first(paths: List[str], payload: Dict[str, Any]) -> Tuple[str | None, bool, Any]:
    last = None
    for p in paths:
        ok, out = api_post(p, payload)
        if ok:
            return p, True, out
        last = (p, out)
    return (last[0] if last else None), False, (last[1] if last else "no-endpoint")

# ===================== Auto-boot backend =====================
_uvicorn_thread: threading.Thread | None = None

def _boot_backend_inprocess(host: str, port: int):
    import uvicorn
    from content.api.main import app as fastapi_app
    config = uvicorn.Config(app=fastapi_app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    return t

def ensure_backend_running(timeout_s: float = 12.0) -> None:
    host = os.getenv("BACKEND_HOST", "0.0.0.0")
    try:
        port = int(os.getenv("BACKEND_PORT", "8000"))
    except Exception:
        port = 8000
    ok, _ = api_get("/health", timeout=2)
    if ok:
        return
    global _uvicorn_thread
    if _uvicorn_thread is None or not _uvicorn_thread.is_alive():
        _uvicorn_thread = _boot_backend_inprocess(host, port)
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        ok, _ = api_get("/health", timeout=2)
        if ok: return
        time.sleep(0.4)

# ===================== UI helpers (format) =====================
def _fmt_eur(x: Any) -> str:
    try:
        v = float(x); neg = v < 0; v = abs(v)
        s = f"{v:,.0f}".replace(",", " ").replace(".", ",").replace(" ", ".")
        return f"{'-' if neg else ''}€ {s}"
    except Exception:
        return "€ 0"

def _fmt_pct(x: Any, decimals: int = 1) -> str:
    try:
        v = float(x); return f"{v:.{decimals}f}%".replace(".", ",")
    except Exception:
        return "0,0%"

# ===================== Callbacks core tabs =====================
def cb_kpi(ctx: Dict[str, Any]) -> tuple[str, Dict[str, Any] | None]:
    ok, out = api_post("/kpi/compute", ctx)
    if not ok: return f"❌ Errore: {out}", None
    lines = [
        f"Ricavi: {_fmt_eur(out.get('fatturato', 0))}",
        f"Utile: {_fmt_eur(out.get('utile', 0))}",
        f"EBITDA: {_fmt_eur(out.get('ebitda', 0))}",
        f"MC: {_fmt_eur(out.get('margine_contribuzione', 0))} ({_fmt_pct((out.get('mc_rate', 0) or 0)*100)})",
    ]
    return "\n".join(lines), out

def cb_simulate(ctx: Dict[str, Any], f_pct: float, cv_pct: float, cf_pct: float, p_pct: float, el: float):
    base = {k: ctx.get(k, 0) for k in [
        "fatturato","costi_variabili","costi_fissi","ammortamenti","investimenti","prezzo_medio","costo_variabile_unitario"
    ]}
    delta = {"fatturato_pct": f_pct, "costi_variabili_pct": cv_pct, "costi_fissi_pct": cf_pct, "price_pct": p_pct, "price_elasticity": el}
    ok, out = api_post("/simulate", {"base": base, "delta": delta})
    if not ok: return f"❌ Errore: {out}", None
    txt = f"Ricavi {_fmt_eur(out.get('fatturato', 0))} | Utile {_fmt_eur(out.get('utile', 0))} | EBITDA {_fmt_eur(out.get('ebitda', 0))}"
    return txt, out

def cb_ladder(ctx: Dict[str, Any], pmin: float, pmax: float, pstep: float):
    base = {
        "fatturato": ctx.get("fatturato", 0), "costi_fissi": ctx.get("costi_fissi", 0),
        "prezzo_medio": ctx.get("prezzo_medio", 0), "costo_variabile_unitario": ctx.get("costo_variabile_unitario", 0),
        "price_elasticity": ctx.get("price_elasticity", -1.2),
    }
    ok, out = api_post("/whatif/price_ladder", {"base": base, "pct_min": pmin, "pct_max": pmax, "pct_step": pstep})
    if not ok: return f"❌ Errore: {out}", None, None
    rows = out.get("rows") or []
    best = out.get("best")
    best_txt = "—" if not best else f"Best {best['pct']:+.1f}% → prezzo {_fmt_eur(best['price'])}, utile {_fmt_eur(best['profit'])}"
    table = [["Δ%", "Prezzo", "Q.ty", "Ricavi", "Utile"]]
    for r in rows:
        table.append([f"{r['pct']:+.1f}%", _fmt_eur(r["price"]), f"{r['quantity']:.0f}", _fmt_eur(r["revenue"]), _fmt_eur(r["profit"])])
    chart = {"pct": [r["pct"] for r in rows], "profit": [r["profit"] for r in rows]}
    return best_txt, table, chart

# ===================== Chat CFO =====================
def _extract_answer(payload: Dict[str, Any]) -> str:
    for k in ("answer", "narrative", "text", "reply", "message"):
        v = payload.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return json.dumps(payload, ensure_ascii=False)

def cb_chat(
    history: List[tuple[str, str]],
    user_msg: str,
    ctx: Dict[str, Any],
    tenant_id: str,
    sector: str
) -> tuple[List[tuple[str, str]], str]:
    if not (user_msg or "").strip():
        return history, ""
    base_payloads = [
        {"text": user_msg, "context": {**ctx, "tenant_id": tenant_id, "sector": sector}},
        {"message": user_msg, "context": {**ctx, "tenant_id": tenant_id, "sector": sector}},
        {"query": user_msg, "context": {**ctx, "tenant_id": tenant_id, "sector": sector}},
    ]
    paths = ["/chat/ask", "/chat", "/nlp/chat"]
    last_err = None
    for body in base_payloads:
        path_used, ok, out = api_post_first(paths, body)
        if ok:
            ans = _extract_answer(out)
            adv = out.get("advisories") if isinstance(out, dict) else None
            if isinstance(adv, list) and adv:
                tags = " | ".join(f"[{(a.get('severity','info') or '').upper()}] {a.get('title','')}" for a in adv[:3])
                if tags.strip():
                    ans = f"{ans}\n\n— Advisories: {tags}"
            history = history + [(user_msg, ans)]
            return history, ""
        last_err = f"{path_used or '-'} → {str(out)[:200]}"
    history = history + [(user_msg, f"❌ Chat non disponibile ({last_err}). Verifica backend /chat*.")]
    return history, ""

# ===================== UI build =====================
def build_ui():
    if hasattr(gr, "Blocks"):
        with gr.Blocks(title="ZephyBloom CFO — Console") as demo:
            gr.Markdown("## ZephyBloom CFO — Console (con Chat)")
            ctx = gr.State(DEF_BASE.copy())
            with gr.Row():
                tenant = gr.Textbox(label="Tenant ID", value=DEF_TENANT)
                sector = gr.Textbox(label="Sector", value=DEF_SECTOR)
                # spacer compat: niente 'scale' (versioni gradio vecchie non lo supportano)
                gr.Markdown("")

            with gr.Tabs():
                # --- Chat ---
                with gr.Tab("Chat CFO"):
                    chat = gr.Chatbot(label="CFO Assistant", height=420, type="tuple")
                    chat_in = gr.Textbox(label="Scrivi qui…", placeholder="Es: Portami l’utile e un piano di azione", lines=2)
                    btn_send = gr.Button("Invia", variant="primary")
                    btn_clear = gr.Button("Pulisci chat")

                    def _send(h, msg, c, t, s):
                        return cb_chat(h or [], msg, c, t, s)
                    chat_in.submit(_send, inputs=[chat, chat_in, ctx, tenant, sector], outputs=[chat, chat_in])
                    btn_send.click(_send, inputs=[chat, chat_in, ctx, tenant, sector], outputs=[chat, chat_in])
                    btn_clear.click(lambda: [], outputs=[chat])

                # --- KPI ---
                with gr.Tab("KPI"):
                    with gr.Row():
                        fatt = gr.Number(label="Fatturato", value=DEF_BASE["fatturato"])
                        cv = gr.Number(label="Costi variabili", value=DEF_BASE["costi_variabili"])
                        cf = gr.Number(label="Costi fissi", value=DEF_BASE["costi_fissi"])
                    with gr.Row():
                        amm = gr.Number(label="Ammortamenti", value=DEF_BASE["ammortamenti"])
                        inv = gr.Number(label="Investimenti", value=DEF_BASE["investimenti"])
                    with gr.Row():
                        p0 = gr.Number(label="Prezzo medio", value=DEF_BASE["prezzo_medio"])
                        cvu = gr.Number(label="CV unitario", value=DEF_BASE["costo_variabile_unitario"])
                    with gr.Row():
                        dso = gr.Number(label="DSO", value=DEF_BASE["dso"])
                        dio = gr.Number(label="DIO", value=DEF_BASE["dio"])
                        dpo = gr.Number(label="DPO", value=DEF_BASE["dpo"])
                    btn = gr.Button("Calcola KPI", variant="primary")
                    out_txt = gr.Textbox(lines=5, label="Sintesi")
                    out_json = gr.JSON(label="Dettaglio", visible=False)

                    def _merge(*vals):
                        return dict(zip(
                            ["fatturato","costi_variabili","costi_fissi","ammortamenti","investimenti","prezzo_medio","costo_variabile_unitario","dso","dio","dpo"],
                            vals
                        ))
                    def _run_kpi(*vals):
                        d = _merge(*vals); ctx.value = d
                        return cb_kpi(d)
                    btn.click(_run_kpi, inputs=[fatt,cv,cf,amm,inv,p0,cvu,dso,dio,dpo], outputs=[out_txt, out_json])

                # --- Simulate ---
                with gr.Tab("Simulate"):
                    f_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ Ricavi %")
                    cv_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CV %")
                    cf_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CF %")
                    price_pct = gr.Slider(-20, 20, value=0, step=0.5, label="Δ Prezzo %")
                    el = gr.Number(label="Elasticità", value=DEF_BASE["price_elasticity"])
                    btn2 = gr.Button("Applica variazioni", variant="primary")
                    sim_txt = gr.Textbox(lines=3, label="Risultato")
                    sim_json = gr.JSON(visible=False)
                    btn2.click(lambda f,cvv,cfv,pct,e: cb_simulate(ctx.value, f, cvv, cfv, pct, e),
                               inputs=[f_pct,cv_pct,cf_pct,price_pct,el],
                               outputs=[sim_txt, sim_json])

                # --- Price Ladder ---
                with gr.Tab("Price Ladder"):
                    pmin = gr.Number(label="Min %", value=-10)
                    pmax = gr.Number(label="Max %", value=10)
                    pstep = gr.Number(label="Step %", value=2)
                    btn3 = gr.Button("Genera ladder", variant="primary")
                    lad_best = gr.Textbox(lines=2, label="Best")
                    lad_table = gr.Dataframe(headers=["Δ%","Prezzo","Q.ty","Ricavi","Utile"])
                    if hasattr(gr, "LinePlot"):
                        lad_plot = gr.LinePlot(x="pct", y="profit", label="Profit vs Δ%")
                        btn3.click(lambda a,b,c: cb_ladder(ctx.value, a,b,c), inputs=[pmin,pmax,pstep], outputs=[lad_best,lad_table,lad_plot])
                    else:
                        btn3.click(lambda a,b,c: cb_ladder(ctx.value, a,b,c), inputs=[pmin,pmax,pstep], outputs=[lad_best,lad_table])

            gr.Markdown("— _Se il backend non è avviato, questa UI prova ad avviarlo automaticamente._")
        return demo

    # Fallback Interface (per gradio molto vecchio)
    return gr.Interface(
        fn=lambda prompt: json.dumps({"hint": "Aggiorna Gradio per usare la Chat."}, ensure_ascii=False),
        inputs=gr.Textbox(label="Prompt"),
        outputs=gr.Textbox(label="Output"),
        title="ZephyBloom CFO — Legacy UI"
    )

# ===================== Launcher =====================
def main():
    ensure_backend_running()
    demo = build_ui()
    host = os.getenv("GRADIO_HOST", "0.0.0.0")
    try: port = int(os.getenv("GRADIO_PORT", "7860"))
    except Exception: port = 7860
    share = os.getenv("GRADIO_SHARE", "false").lower() in ("1","true","yes","y")
    for a in sys.argv[1:]:
        if a in ("--share","-s"): share = True
        elif a.startswith("--host="): host = a.split("=",1)[1]
        elif a.startswith("--port="):
            try: port = int(a.split("=",1)[1])
            except Exception: pass

    try:
        ret = demo.launch(server_name=host, server_port=port, share=share, prevent_thread_lock=True)
    except TypeError:
        ret = demo.launch(server_name=host, server_port=port, share=share)

    local_url = f"http://{'127.0.0.1' if host in ('0.0.0.0','') else host}:{port}"
    share_url = None
    if isinstance(ret, tuple) and len(ret) >= 3:
        _, local_url, share_url = ret[:3]
    elif hasattr(demo, "share_url"):
        share_url = getattr(demo, "share_url")

    print("\n===== Gradio avviato =====")
    print(f"Local:  {local_url}")
    if share: print(f"Public: {share_url or '(in creazione …)'}")
    print(json.dumps({"local_url": local_url, "share": share, "share_url": share_url}, ensure_ascii=False))

    try:
        while True: time.sleep(2)
    except KeyboardInterrupt:
        print("\n[Gradio] Stop richiesto dall’utente.")

if __name__ == "__main__":
    main()
