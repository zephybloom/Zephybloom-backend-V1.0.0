# -*- coding: utf-8 -*-
# content/frontend/gradio.py
from __future__ import annotations

import os
import json
import math
from typing import Any, Dict, List, Optional, Tuple

import gradio as gr
import requests

try:
    from content.api.config import settings
except Exception:
    # fallback leggero per evitare import-time errors in ambienti minimal
    class _S:
        BACKEND_BASE_URL = os.getenv("BACKEND_BASE_URL", "http://127.0.0.1:8000")
        APP_API_KEY = os.getenv("ZB_APP_API_KEY", None)
        UI_PATH = os.getenv("ZB_UI_PATH", "/ui")
    settings = _S()  # type: ignore


# ---------------------------
# Helpers HTTP
# ---------------------------
def _api_base_url(default: str) -> str:
    url = getattr(settings, "BACKEND_BASE_URL", None) or default or "http://127.0.0.1:8000"
    return url.rstrip("/")

def _api_headers() -> Dict[str, str]:
    headers = {"Content-Type": "application/json"}
    # API Key globale se presente
    app_key = getattr(settings, "APP_API_KEY", None) or os.getenv("ZB_APP_API_KEY")
    if app_key:
        headers["X-API-KEY"] = app_key
    return headers

def api_get(base_url: str, path: str, params: Optional[Dict[str, Any]] = None) -> Tuple[bool, Any]:
    url = f"{_api_base_url(base_url)}{path}"
    try:
        r = requests.get(url, params=params, headers=_api_headers(), timeout=15)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:400])
    except Exception as e:
        return False, str(e)

def api_post(base_url: str, path: str, payload: Dict[str, Any]) -> Tuple[bool, Any]:
    url = f"{_api_base_url(base_url)}{path}"
    try:
        r = requests.post(url, data=json.dumps(payload), headers=_api_headers(), timeout=30)
        ok = r.status_code == 200
        return ok, (r.json() if ok else r.text[:600])
    except Exception as e:
        return False, str(e)


# ---------------------------
# Default context (placeholder)
# ---------------------------
DEF = dict(
    fatturato=1_200_000.0,
    costi_variabili=660_000.0,
    costi_fissi=300_000.0,
    ammortamenti=50_000.0,
    investimenti=200_000.0,
    prezzo_medio=40.0,
    costo_variabile_unitario=22.0,
    dso=35.0, dio=30.0, dpo=30.0,
    price_elasticity=-1.2,
)


# ---------------------------
# UI Builders (callback)
# ---------------------------
def _fmt_eur(x: Any) -> str:
    try:
        v = float(x)
        neg = v < 0
        v = abs(v)
        s = f"{v:,.0f}".replace(",", " ").replace(".", ",")
        s = s.replace(" ", ".")
        return f"{'-' if neg else ''}€ {s}"
    except Exception:
        return "€ 0"

def _fmt_pct(x: Any, decimals: int = 1) -> str:
    try:
        v = float(x)
        return f"{v:.{decimals}f}%".replace(".", ",")
    except Exception:
        return "0,0%"

def _fmt_eu(n: Any, d: int = 0) -> str:
    try:
        v = float(n)
        s = f"{v:,.{d}f}".replace(",", " ").replace(".", ",")
        return s.replace(" ", ".")
    except Exception:
        return "0"

def do_kpi(base_url: str,
           fatturato, costi_variabili, costi_fissi, ammortamenti, investimenti,
           prezzo_medio, costo_variabile_unitario, dso, dio, dpo):
    payload = {
        "fatturato": fatturato, "costi_variabili": costi_variabili, "costi_fissi": costi_fissi,
        "ammortamenti": ammortamenti, "investimenti": investimenti,
        "prezzo_medio": prezzo_medio, "costo_variabile_unitario": costo_variabile_unitario,
        "dso": dso, "dio": dio, "dpo": dpo,
    }
    ok, out = api_post(base_url, "/kpi/compute", payload)
    if not ok:
        return f"❌ Errore: {out}", None
    # testo + piccoli numeri chiave
    lines = [
        f"Ricavi: {_fmt_eur(out.get('fatturato', 0))}",
        f"Utile: {_fmt_eur(out.get('utile', 0))}",
        f"EBITDA: {_fmt_eur(out.get('ebitda', 0))}",
        f"MC: {_fmt_eur(out.get('margine_contribuzione', 0))} ({_fmt_pct((out.get('mc_rate', 0) or 0)*100)})",
        f"BEP Ricavi: {_fmt_eur(out.get('break_even', 0))}",
    ]
    return "\n".join(lines), out

def do_simulate(base_url: str,
                fatturato, costi_variabili, costi_fissi, ammortamenti, investimenti,
                prezzo_medio, costo_variabile_unitario, f_pct, cv_pct, cf_pct, p_pct, elasticity):
    base = {
        "fatturato": fatturato, "costi_variabili": costi_variabili, "costi_fissi": costi_fissi,
        "ammortamenti": ammortamenti, "investimenti": investimenti,
        "prezzo_medio": prezzo_medio, "costo_variabile_unitario": costo_variabile_unitario,
    }
    delta = {
        "fatturato_pct": f_pct, "costi_variabili_pct": cv_pct, "costi_fissi_pct": cf_pct,
        "price_pct": p_pct, "price_elasticity": elasticity,
    }
    ok, out = api_post(base_url, "/simulate", {"base": base, "delta": delta})
    if not ok:
        return f"❌ Errore: {out}", None
    # sintetico
    ricavi = _fmt_eur(out.get("fatturato", 0))
    utile = _fmt_eur(out.get("utile", 0))
    ebitda = _fmt_eur(out.get("ebitda", 0))
    mc = _fmt_eur(out.get("margine_contribuzione", 0))
    mcr = _fmt_pct((out.get("mc_rate", 0) or 0)*100)
    txt = f"Ricavi {ricavi} | Utile {utile} | EBITDA {ebitda} | MC {mc} ({mcr})"
    return txt, out

def do_optimize_price(base_url: str,
                      fatturato, costi_fissi, prezzo_medio, costo_variabile_unitario, elasticity):
    base = {
        "fatturato": fatturato, "costi_fissi": costi_fissi,
        "prezzo_medio": prezzo_medio, "costo_variabile_unitario": costo_variabile_unitario,
        "price_elasticity": elasticity,
    }
    ok, out = api_post(base_url, "/optimize/price", {"base": base})
    if not ok:
        return f"❌ Errore: {out}"
    try:
        bpct = out.get("best_pct")
        bprice = out.get("best_price")
        bprofit = out.get("best_profit")
        return f"Prezzo ottimale: {bpct:+.1f}% → {_fmt_eur(bprice)}; Utile atteso: {_fmt_eur(bprofit)}"
    except Exception:
        return json.dumps(out, ensure_ascii=False, indent=2)

def do_price_ladder(base_url: str,
                    fatturato, costi_fissi, prezzo_medio, costo_variabile_unitario, elasticity,
                    pct_min, pct_max, pct_step):
    base = {
        "fatturato": fatturato, "costi_fissi": costi_fissi,
        "prezzo_medio": prezzo_medio, "costo_variabile_unitario": costo_variabile_unitario,
        "price_elasticity": elasticity,
    }
    ok, out = api_post(base_url, "/whatif/price_ladder", {
        "base": base, "pct_min": pct_min, "pct_max": pct_max, "pct_step": pct_step
    })
    if not ok:
        return f"❌ Errore: {out}", None, None

    rows = out.get("rows", []) or []
    best = out.get("best")
    # tabella compatta
    header = ["Δ%", "Prezzo", "Q.ty", "Ricavi", "Utile"]
    table = [header] + [
        [f"{r['pct']:+.1f}%", _fmt_eur(r["price"]), _fmt_eu(r["quantity"], 0), _fmt_eur(r["revenue"]), _fmt_eur(r["profit"])]
        for r in rows
    ]
    # trace per chart (profit vs pct)
    chart = {
        "pct": [r["pct"] for r in rows],
        "profit": [r["profit"] for r in rows],
    }
    # best line
    best_txt = "—"
    if best:
        best_txt = f"Best: {best['pct']:+.1f}% → prezzo {_fmt_eur(best['price'])}, utile {_fmt_eur(best['profit'])}"
    return best_txt, table, chart

def do_forecast(base_url: str, history_str: str, periods: int, method: str):
    # parse "100,120,130"
    try:
        hist = [float(x.strip().replace(",", ".")) for x in history_str.split(",") if x.strip()]
    except Exception:
        return "Formato storico non valido.", None
    ok, out = api_post(base_url, "/forecast", {"history": hist, "periods": periods, "method": method})
    if not ok:
        return f"❌ Errore: {out}", None
    fc = out.get("forecast", [])
    s = ", ".join(_fmt_eu(v, 0) for v in fc)
    chart = {"x": list(range(1, len(fc)+1)), "y": fc}
    return f"Previsione: {s}", chart

def do_valuation_project(base_url: str, cashflows_str: str, rate: float):
    try:
        cfs = [float(x.strip().replace(",", ".")) for x in cashflows_str.split(",") if x.strip()]
    except Exception:
        return "Formato CF non valido.", None
    ok, out = api_post(base_url, "/valuation", {"cashflows": cfs, "discount_rate_pct": rate})
    if not ok:
        return f"❌ Errore: {out}", None
    pe = out.get("project_eval", {})
    txt = f"NPV {_fmt_eur(pe.get('npv', 0))}, IRR {_fmt_pct(pe.get('irr', 0), 2)}, Payback {int(pe.get('payback_period', -1))} anni"
    return txt, pe

def do_valuation_dcf(base_url: str, fcf_str: str, rate: float, g: float, net_debt: float):
    try:
        fcf = [float(x.strip().replace(",", ".")) for x in fcf_str.split(",") if x.strip()]
    except Exception:
        return "Formato FCF non valido.", None
    ok, out = api_post(base_url, "/valuation", {
        "dcf_fcf": fcf, "discount_rate_pct": rate, "terminal_growth_pct": g, "net_debt": net_debt
    })
    if not ok:
        return f"❌ Errore: {out}", None
    d = out.get("dcf", {})
    txt = f"EV {_fmt_eur(d.get('enterprise_value', 0))}, Equity {_fmt_eur(d.get('equity_value', 0))} (WACC {_fmt_eu(d.get('wacc_pct', 0), 2)}%)"
    return txt, d

def do_wc(base_url: str, fatturato, costi_variabili, dso, dio, dpo, ddso, ddio, ddpo):
    base = {
        "fatturato": fatturato, "costi_variabili": costi_variabili,
        "dso": dso, "dio": dio, "dpo": dpo,
        "dso_delta": ddso, "dio_delta": ddio, "dpo_delta": ddpo,
    }
    ok, out = api_post(base_url, "/whatif/wc_impact", {"base": base})
    if not ok:
        return f"❌ Errore: {out}"
    txt = (
        f"CCC: {_fmt_eu(out.get('ccc_before', 0), 0)} → {_fmt_eu(out.get('ccc_after', 0), 0)} (Δ {_fmt_eu(out.get('delta_ccc', 0), 0)} giorni)\n"
        f"Fabbisogno CC: {_fmt_eur(out.get('wc_need_before', 0))} → {_fmt_eur(out.get('wc_need_after', 0))} "
        f"(Δ cassa {_fmt_eur(out.get('delta_cash', 0))})"
    )
    return txt

def do_alerts(base_url: str,
              fatturato, costi_variabili, costi_fissi, prezzo_medio, costo_variabile_unitario,
              dso, dio, dpo):
    ctx = {
        "fatturato": fatturato, "costi_variabili": costi_variabili, "costi_fissi": costi_fissi,
        "prezzo_medio": prezzo_medio, "costo_variabile_unitario": costo_variabile_unitario,
        "dso": dso, "dio": dio, "dpo": dpo
    }
    ok, out = api_post(base_url, "/alerts/evaluate", {"context": ctx})
    if not ok:
        return f"❌ Errore: {out}"
    alerts = out.get("alerts", []) or []
    if not alerts:
        return "Nessun alert attivo."
    lines = []
    for a in alerts[:10]:
        sev = a.get("severity", "info").upper()
        title = a.get("title", "")
        code = a.get("code", "")
        lines.append(f"[{sev}] {title} ({code})")
    return "\n".join(lines)


# ---------------------------
# Gradio App
# ---------------------------
def create_demo(base_url: str = "") -> gr.Blocks:
    base_url = base_url or getattr(settings, "BACKEND_BASE_URL", "http://127.0.0.1:8000")

    with gr.Blocks(theme=gr.themes.Soft(), title="ZephyBloom CFO Console") as demo:
        gr.Markdown("## ZephyBloom — CFO Console")
        with gr.Tabs():
            # --- KPI ---
            with gr.Tab("KPI"):
                with gr.Row():
                    fatt = gr.Number(label="Fatturato", value=DEF["fatturato"])
                    cv = gr.Number(label="Costi variabili", value=DEF["costi_variabili"])
                    cf = gr.Number(label="Costi fissi", value=DEF["costi_fissi"])
                with gr.Row():
                    amm = gr.Number(label="Ammortamenti", value=DEF["ammortamenti"])
                    inv = gr.Number(label="Investimenti", value=DEF["investimenti"])
                with gr.Row():
                    p0 = gr.Number(label="Prezzo medio", value=DEF["prezzo_medio"])
                    cvu = gr.Number(label="CV unitario", value=DEF["costo_variabile_unitario"])
                with gr.Row():
                    dso = gr.Number(label="DSO", value=DEF["dso"])
                    dio = gr.Number(label="DIO", value=DEF["dio"])
                    dpo = gr.Number(label="DPO", value=DEF["dpo"])
                run_kpi = gr.Button("Calcola KPI", variant="primary")
                kpi_out = gr.Textbox(label="Risultato", lines=5)
                kpi_raw = gr.JSON(label="Dettaglio KPI", visible=False)

                run_kpi.click(
                    fn=lambda *a: do_kpi(base_url, *a),
                    inputs=[fatt, cv, cf, amm, inv, p0, cvu, dso, dio, dpo],
                    outputs=[kpi_out, kpi_raw],
                )

            # --- Simulate ---
            with gr.Tab("Simulate"):
                with gr.Row():
                    f_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ Ricavi %")
                    cv_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CV %")
                    cf_pct = gr.Slider(-50, 50, value=0, step=1, label="Δ CF %")
                with gr.Row():
                    price_pct = gr.Slider(-20, 20, value=0, step=0.5, label="Δ Prezzo %")
                    el = gr.Number(label="Elasticità", value=DEF["price_elasticity"])
                run_sim = gr.Button("Applica variazioni", variant="primary")
                sim_out = gr.Textbox(label="Risultato", lines=3)
                sim_raw = gr.JSON(label="Dettaglio", visible=False)

                run_sim.click(
                    fn=lambda *a: do_simulate(base_url, *a),
                    inputs=[fatt, cv, cf, amm, inv, p0, cvu, f_pct, cv_pct, cf_pct, price_pct, el],
                    outputs=[sim_out, sim_raw],
                )

            # --- Pricing ---
            with gr.Tab("Pricing"):
                gr.Markdown("### Optimize & Ladder")
                with gr.Row():
                    run_opt = gr.Button("Calcola prezzo ottimale", variant="primary")
                    out_opt = gr.Textbox(label="Risultato", lines=2)
                run_opt.click(
                    fn=lambda *a: do_optimize_price(base_url, *a),
                    inputs=[fatt, cf, p0, cvu, el],
                    outputs=[out_opt],
                )

                gr.Markdown("#### Price ladder")
                with gr.Row():
                    pct_min = gr.Slider(-30, 0, value=-10, step=1, label="Min %")
                    pct_max = gr.Slider(0, 30, value=10, step=1, label="Max %")
                    pct_step = gr.Slider(0.5, 10, value=2, step=0.5, label="Step %")
                run_ladder = gr.Button("Genera ladder")
                ladder_best = gr.Textbox(label="Sintesi Best", lines=2)
                ladder_table = gr.Dataframe(headers=["Δ%", "Prezzo", "Q.ty", "Ricavi", "Utile"], label="Ladder (top→bottom = profit)", interactive=False)
                ladder_plot = gr.LinePlot(label="Profit vs Δ Prezzo", x="pct", y="profit")

                def _ladder_cb(*a):
                    best_txt, table, chart = do_price_ladder(base_url, *a)
                    return best_txt, table, chart

                run_ladder.click(
                    fn=_ladder_cb,
                    inputs=[fatt, cf, p0, cvu, el, pct_min, pct_max, pct_step],
                    outputs=[ladder_best, ladder_table, ladder_plot],
                )

            # --- Forecast ---
            with gr.Tab("Forecast"):
                hist = gr.Textbox(label="Storico (CSV)", value="180000,190000,200000,210000,220000,230000")
                periods = gr.Slider(1, 24, value=6, step=1, label="Orizzonte")
                method = gr.Dropdown(["holt", "sma", "naive", "drift"], value="sma", label="Metodo")
                run_fc = gr.Button("Forecast", variant="primary")
                fc_out = gr.Textbox(label="Output", lines=2)
                fc_plot = gr.LinePlot(label="Forecast", x="x", y="y")

                run_fc.click(
                    fn=lambda h, p, m: do_forecast(base_url, h, int(p), m),
                    inputs=[hist, periods, method],
                    outputs=[fc_out, fc_plot],
                )

            # --- Valuation ---
            with gr.Tab("Valuation"):
                gr.Markdown("#### Project: NPV / IRR / Payback")
                cf_str = gr.Textbox(label="Cashflows (CSV, includi CF0)", value="-300000,120000,130000,140000,150000")
                rate = gr.Number(label="Discount rate (%)", value=10.0)
                run_pe = gr.Button("Calcola NPV/IRR", variant="primary")
                pe_out = gr.Textbox(label="Risultato", lines=2)
                pe_raw = gr.JSON(label="Dettaglio", visible=False)
                run_pe.click(
                    fn=lambda s, r: do_valuation_project(base_url, s, float(r)),
                    inputs=[cf_str, rate],
                    outputs=[pe_out, pe_raw],
                )

                gr.Markdown("#### DCF Equity")
                fcf_str = gr.Textbox(label="FCF (CSV, anni 1..n)", value="250000,270000,290000,300000,310000")
                wacc = gr.Number(label="WACC (%)", value=11.0)
                g = gr.Number(label="g terminale (%)", value=2.0)
                nd = gr.Number(label="Net Debt", value=500000.0)
                run_dcf = gr.Button("Calcola DCF", variant="primary")
                dcf_out = gr.Textbox(label="Risultato", lines=2)
                dcf_raw = gr.JSON(label="Dettaglio", visible=False)
                run_dcf.click(
                    fn=lambda s, r, gg, ndebt: do_valuation_dcf(base_url, s, float(r), float(gg), float(ndebt)),
                    inputs=[fcf_str, wacc, g, nd],
                    outputs=[dcf_out, dcf_raw],
                )

            # --- Working Capital ---
            with gr.Tab("Working Capital"):
                ddso = gr.Slider(-30, 30, value=0, step=1, label="Δ DSO (giorni)")
                ddio = gr.Slider(-30, 30, value=0, step=1, label="Δ DIO (giorni)")
                ddpo = gr.Slider(-30, 30, value=0, step=1, label="Δ DPO (giorni)")
                run_wc = gr.Button("Calcola impatto", variant="primary")
                wc_out = gr.Textbox(label="Risultato", lines=3)
                run_wc.click(
                    fn=lambda *a: do_wc(base_url, *a),
                    inputs=[fatt, cv, dso, dio, dpo, ddso, ddio, ddpo],
                    outputs=[wc_out],
                )

            # --- Alerts / Rules ---
            with gr.Tab("Alerts / Rules"):
                run_al = gr.Button("Valuta alert", variant="primary")
                al_out = gr.Textbox(label="Alert attivi", lines=10)
                run_al.click(
                    fn=lambda *a: do_alerts(base_url, *a),
                    inputs=[fatt, cv, cf, p0, cvu, dso, dio, dpo],
                    outputs=[al_out],
                )

        gr.Markdown(
            "— _ZephyBloom CFO • UI Gradio_. Se vedi errori di autenticazione, imposta `ZB_APP_API_KEY` e ricarica."
        )

    return demo
