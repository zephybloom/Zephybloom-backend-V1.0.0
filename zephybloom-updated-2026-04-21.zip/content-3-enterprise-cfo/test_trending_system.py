"""
TEST: Historical Trending in Decision Engine
============================================

Demonstrates:
1. Month 1 & Month 2 company metrics
2. Trend analysis calculation
3. Decision Engine with trend context
4. Output formatting with trend indicators
"""

import sys
sys.path.insert(0, '/Users/thestar23/Downloads/content-3-enterprise-cfo')

from core.trend_analysis import TrendAnalyzer, format_trend_output
from nlp.cfo_decision_engine import CFODecisionEngine, create_decision_engine


def test_trending_system():
    """Full test of trending system with Decision Engine"""
    
    print("\n" + "="*80)
    print("🔥 ZEPHYBLOOM CFO BRAIN - HISTORICAL TREND ANALYSIS TEST")
    print("="*80)
    
    # ========================================
    # SCENARIO 1: Company with Declining Margins
    # ========================================
    print("\n\n1️⃣  SCENARIO: MARGIN COMPRESSION (Month-over-Month Decline)")
    print("-" * 80)
    
    # Month 1 metrics (healthy)
    month1_metrics = {
        "fatturato": 5_000_000,
        "costi_variabili": 3_250_000,  # 65% of revenue
        "costi_fissi": 900_000,
        "investimenti": 500_000,
        "gross_profit": 1_750_000,
        "gross_margin_pct": 35.0,
        "ebitda": 850_000,
        "ebitda_margin_pct": 17.0,
        "net_profit": 850_000,
        "net_margin_pct": 17.0,
        "roi_pct": 170.0,
    }
    
    # Month 2 metrics (declining margins)
    month2_metrics = {
        "fatturato": 5_100_000,  # +2% revenue growth
        "costi_variabili": 3_468_000,  # +6.7% COGS (problem!)
        "costi_fissi": 920_000,
        "investimenti": 500_000,
        "gross_profit": 1_632_000,
        "gross_margin_pct": 32.0,  # Down from 35%
        "ebitda": 712_000,
        "ebitda_margin_pct": 13.96,  # Down from 17%
        "net_profit": 712_000,
        "net_margin_pct": 13.96,  # Down from 17%
        "roi_pct": 142.4,
    }
    
    # Analyze trends
    analyzer = TrendAnalyzer()
    trends = analyzer.analyze_metrics(month2_metrics, month1_metrics, "Acme Manufacturing", None)
    
    print("\n📊 METRIC EVOLUTION:")
    print(f"  Revenue:        €5.0M → €5.1M (+2.0%)")
    print(f"  Gross Margin:   35.0% → 32.0% (-3.0%) ⚠️  ALERT")
    print(f"  EBITDA Margin:  17.0% → 14.0% (-3.0%) ⚠️  ALERT")
    print(f"  Net Margin:     17.0% → 14.0% (-3.0%) ⚠️  ALERT")
    
    print("\n" + format_trend_output(trends))
    
    # Now feed this to Decision Engine
    print("\n\n🎯 DECISION ENGINE WITH TREND CONTEXT:")
    print("-" * 80)
    
    engine = create_decision_engine()
    decision = engine.analyze(
        month2_metrics,
        company_name="Acme Manufacturing",
        trend_summary=format_trend_output(trends)
    )
    
    print(decision.to_response())
    
    # ========================================
    # SCENARIO 2: Company with Improving Margins
    # ========================================
    print("\n\n" + "="*80)
    print("2️⃣  SCENARIO: MARGIN EXPANSION (Month-over-Month Improvement)")
    print("-" * 80)
    
    # Month 1: struggling
    month1_saas = {
        "fatturato": 3_000_000,
        "costi_variabili": 1_050_000,  # 35% - challenging
        "costi_fissi": 800_000,
        "investimenti": 300_000,
        "gross_profit": 1_950_000,
        "gross_margin_pct": 65.0,
        "ebitda": 1_150_000,
        "ebitda_margin_pct": 38.3,
        "net_profit": 1_150_000,
        "net_margin_pct": 38.3,
        "roi_pct": 383.3,
    }
    
    # Month 2: improving (cost discipline)
    month2_saas = {
        "fatturato": 3_150_000,  # +5% revenue
        "costi_variabili": 976_500,  # Down to 31% of revenue (better efficiency)
        "costi_fissi": 780_000,  # Down 2.5% (fixed cost control)
        "investimenti": 300_000,
        "gross_profit": 2_173_500,
        "gross_margin_pct": 69.0,  # Up from 65%
        "ebitda": 1_393_500,
        "ebitda_margin_pct": 44.25,  # Up from 38.3%
        "net_profit": 1_393_500,
        "net_margin_pct": 44.25,  # Up from 38.3%
        "roi_pct": 464.5,
    }
    
    # Analyze trends
    trends_saas = analyzer.analyze_metrics(month2_saas, month1_saas, "TechFlow SaaS", None)
    
    print("\n📊 METRIC EVOLUTION:")
    print(f"  Revenue:        €3.0M → €3.15M (+5.0%)")
    print(f"  Gross Margin:   65.0% → 69.0% (+4.0%) ✅ IMPROVING")
    print(f"  EBITDA Margin:  38.3% → 44.3% (+6.0%) ✅ IMPROVING")
    print(f"  Net Margin:     38.3% → 44.3% (+6.0%) ✅ IMPROVING")
    
    print("\n" + format_trend_output(trends_saas))
    
    # Decision Engine with improvement trends
    print("\n\n🎯 DECISION ENGINE WITH TREND CONTEXT:")
    print("-" * 80)
    
    decision_saas = engine.analyze(
        month2_saas,
        company_name="TechFlow SaaS",
        trend_summary=format_trend_output(trends_saas)
    )
    
    print(decision_saas.to_response())
    
    # ========================================
    # SCENARIO 3: Volatile Metrics (Red Flag)
    # ========================================
    print("\n\n" + "="*80)
    print("3️⃣  SCENARIO: PROFIT CRASH (Multiple Alert Signals)")
    print("-" * 80)
    
    # Month 1: solid
    month1_volatile = {
        "fatturato": 4_000_000,
        "costi_variabili": 2_400_000,  # 60%
        "costi_fissi": 800_000,
        "investimenti": 400_000,
        "gross_profit": 1_600_000,
        "gross_margin_pct": 40.0,
        "ebitda": 800_000,
        "ebitda_margin_pct": 20.0,
        "net_profit": 800_000,
        "net_margin_pct": 20.0,
        "roi_pct": 200.0,
    }
    
    # Month 2: crash (lost large customer + cost spike)
    month2_volatile = {
        "fatturato": 3_200_000,  # -20% (lost customer)
        "costi_variabili": 2_112_000,  # 66% (worse utilization)
        "costi_fissi": 900_000,  # +12.5% (can't cut quickly)
        "investimenti": 400_000,
        "gross_profit": 1_088_000,
        "gross_margin_pct": 34.0,  # Down 6 points
        "ebitda": 188_000,
        "ebitda_margin_pct": 5.88,  # Down 14 points (CRITICAL!)
        "net_profit": 188_000,
        "net_margin_pct": 5.88,
        "roi_pct": 47.0,
    }
    
    # Analyze - should show multiple alerts
    trends_volatile = analyzer.analyze_metrics(month2_volatile, month1_volatile, "Retail Corp", None)
    
    print("\n📊 METRIC EVOLUTION:")
    print(f"  Revenue:        €4.0M → €3.2M (-20.0%) ⚠️  ALERT")
    print(f"  Gross Margin:   40.0% → 34.0% (-6.0%) ⚠️  ALERT")
    print(f"  EBITDA Margin:  20.0% → 5.9%  (-14.1%) ⚠️  CRITICAL ALERT")
    print(f"  Net Margin:     20.0% → 5.9%  (-14.1%) ⚠️  CRITICAL ALERT")
    
    print("\n" + format_trend_output(trends_volatile))
    
    # Decision Engine - should trigger critical decision
    print("\n\n🎯 DECISION ENGINE WITH TREND CONTEXT:")
    print("-" * 80)
    
    decision_volatile = engine.analyze(
        month2_volatile,
        company_name="Retail Corp",
        trend_summary=format_trend_output(trends_volatile)
    )
    
    print(decision_volatile.to_response())
    
    # ========================================
    # SUMMARY
    # ========================================
    print("\n\n" + "="*80)
    print("✅ HISTORICAL TRENDING SYSTEM TEST COMPLETE")
    print("="*80)
    print("""
    What you just saw:
    
    1. ✅ Trend Analysis Module (core/trend_analysis.py)
       - Calculates month-over-month changes
       - Identifies improving vs worsening metrics
       - Generates trend alerts for significant changes
       - Calculates momentum score
    
    2. ✅ Decision Engine Integration
       - Accepts optional trend_summary parameter
       - Includes trends in decision context
       - Output formatted with trend indicators at the top
    
    3. ✅ Output Format
       - Trends appear FIRST (📊 Trends vs last month)
       - Shows each metric with ↑ or ↓ indicator
       - Flags metrics that need alerts (⚠️)
       - Shows momentum direction (📈 Improving / 📉 Declining)
    
    4. ✅ Real-world Scenarios
       - Declining margins (supply chain issue)
       - Improving margins (operational excellence)
       - Profit crash (customer loss + cost spike)
    
    Next Steps:
    ──────────
    1. Integrate into /cfo/chat endpoint (routes_cfo.py)
    2. Store company metrics history in DB (db/models.py ← CompanyMetricsHistory added)
    3. Fetch historical metrics on each analysis request
    4. Generate trends automatically + pass to Decision Engine
    """)


if __name__ == "__main__":
    test_trending_system()
