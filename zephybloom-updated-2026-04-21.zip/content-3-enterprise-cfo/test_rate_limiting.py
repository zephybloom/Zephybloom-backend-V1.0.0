"""
Test rate limiting enforcement.

Verify that rate limits are enforced correctly.
"""

import pytest
from fastapi.testclient import TestClient
from api.main import app
from api.config import settings

client = TestClient(app)


class TestRateLimitingEnforcement:
    """Test suite for rate limiting"""
    
    def test_rate_limit_config_exists(self):
        """Test that rate limiting configuration is in place"""
        assert settings.RATE_LIMIT_ENABLED is True
        assert settings.RATE_LIMIT_PER_TENANT > 0
        assert settings.RATE_LIMIT_WINDOW_S > 0
    
    def test_rate_limit_headers_on_response(self):
        """Test that rate limit headers are included in response"""
        response = client.get(
            "/health",
            headers={"X-Tenant-Id": "test"}
        )
        
        # Response should include rate limit headers
        assert "X-RateLimit-Limit" in response.headers or response.status_code == 200
    
    def test_high_request_volume_respected(self):
        """Test that many rapid requests respect rate limits"""
        # This test depends on in-memory rate limiter
        # In production with Redis, this would be more strict
        
        limit = settings.RATE_LIMIT_PER_TENANT
        
        # Make sequential requests
        responses = []
        for i in range(limit + 10):
            response = client.post(
                "/cfo/ai-analyze",
                headers={"X-Tenant-Id": "test-limit"},
                json={
                    "fatturato": 1000000,
                    "costi_variabili": 400000,
                    "costi_fissi": 300000,
                    "investimenti": 0,
                    "company_name": "Test"
                }
            )
            responses.append(response.status_code)
        
        # Some requests should eventually be rate limited (429)
        # or at least we see a mix of 200/422/429
        status_codes = set(responses)
        assert len(status_codes) > 1  # Different responses


class TestProductionRateLimitSettings:
    """Test production-ready rate limiting"""
    
    def test_tenant_rate_limit_reasonable(self):
        """Test tenant rate limits are production-grade"""
        # Per tenant: 1000 req/min = ~16.67 req/sec
        assert settings.RATE_LIMIT_PER_TENANT >= 100
        assert settings.RATE_LIMIT_PER_TENANT <= 10000
    
    def test_window_size_reasonable(self):
        """Test rate limit window is reasonable"""
        # Window should be 60 seconds (1 minute)
        assert settings.RATE_LIMIT_WINDOW_S == 60
    
    def test_api_key_rate_limit_reasonable(self):
        """Test API key rate limits"""
        assert settings.RATE_LIMIT_API_KEY_PER_MINUTE >= 50
        assert settings.RATE_LIMIT_API_KEY_PER_MINUTE <= 500


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
