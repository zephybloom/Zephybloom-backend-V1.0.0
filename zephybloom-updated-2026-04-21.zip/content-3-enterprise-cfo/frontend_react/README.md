# CFO Dashboard - React Frontend

**AI-powered Financial Analysis Dashboard** built with React, Material-UI, and Recharts.

## 🎯 Features

### Dashboard
- 📊 Financial analysis with KPI metrics
- 📈 Margin analysis charts
- 💡 Automated recommendations (3-5 actions)
- 🎯 Health status assessment (healthy/warning/critical)
- 🏢 Company data input form

### Scenario Simulator
- 🎛️ What-if scenario analysis
- 📊 Base vs scenario comparison charts
- 💰 Profit impact calculation
- 📋 Detailed metrics table
- ✅ GO/NO-GO recommendations

### CFO Chat Assistant
- 💬 Natural language Q&A (Italian)
- 🤖 Context-aware responses
- 📌 Recommendation integration
- 💾 Chat history

### Security
- 🔐 JWT authentication
- 👤 User login/registration
- 🔒 Protected routes
- 🚀 Auto-logout on token expiry

## 📦 Tech Stack

- **Frontend:** React 18.2.0
- **UI Library:** Material-UI 5.14.0
- **Charts:** Recharts 2.10.0
- **HTTP Client:** Axios 1.6.0
- **Routing:** React Router 6.18.0
- **State Management:** React Context API
- **Auth:** JWT + jwtDecode 9.1.0

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd frontend_react
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` if your backend is not at `http://127.0.0.1:8888`:
```
REACT_APP_API_URL=http://your-backend-url:8888
```

### 3. Start Development Server

```bash
npm start
```

Opens at `http://localhost:3000`

### 4. Build for Production

```bash
npm run build
```

Output: `build/` folder (ready for deployment)

## 🔗 API Integration

The app communicates with the backend CFO API:

### Base URL
```
http://127.0.0.1:8888
```

### Endpoints Used

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/auth/login` | User authentication |
| POST | `/auth/register` | User registration |
| POST | `/cfo/analyze` | Financial analysis |
| POST | `/cfo/simulate` | Scenario simulation |
| POST | `/cfo/chat` | AI assistant chat |

### Authentication
All requests include JWT token in header:
```
Authorization: Bearer <token>
```

## 📂 Project Structure

```
frontend_react/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   └── Layout.js          (Navigation & AppBar)
│   ├── context/
│   │   ├── authContext.js     (Authentication state)
│   │   └── companyContext.js  (Company data state)
│   ├── pages/
│   │   ├── LoginPage.js       (Auth)
│   │   ├── DashboardPage.js   (Main analysis)
│   │   ├── SimulatePage.js    (Scenario simulator)
│   │   ├── AnalyzePage.js     (Placeholder)
│   │   └── ChatPage.js        (AI assistant)
│   ├── services/
│   │   └── api.js             (API client)
│   ├── App.js                 (Main app)
│   ├── index.js               (Entry point)
│   └── index.css              (Global styles)
├── package.json
├── .env.example
└── README.md
```

## 🎨 Features by Page

### Login Page
- Email/password login
- User registration
- Demo credentials: `demo@example.com` / `DemoPassword123`

### Dashboard
- Input company financials (revenue, costs, investments)
- Sector selection (Manufacturing, SaaS, Retail, Default)
- Run analysis
- View KPI snapshot (gross/net margin, EBITDA, ROI, CCC)
- Display health status & diagnosis
- Show 3-5 recommended actions with EUR impact

### Scenario Simulator
- Create multiple scenarios
- Adjust: revenue, variable costs, fixed costs
- Compare base vs scenario
- View profit impact & ROI change
- Recommendation: YES/MAYBE/NO

### CFO Chat
- Ask questions about financials
- Template-based answers (Italian)
- Context-aware responses
- Optional re-analysis if requested
- Chat history

## 🔐 Authentication

### Login Flow
1. User enters email & password
2. Backend returns JWT token
3. Token stored in localStorage
4. Included in all API requests
5. Auto-login on page reload
6. Auto-logout if token expired

### Protected Routes
- `/dashboard` - Requires auth
- `/analyze` - Requires auth
- `/simulate` - Requires auth  
- `/chat` - Requires auth
- `/login` - Public

## 📊 Data Formats

### Company Input
```json
{
  "company_name": "Acme Inc",
  "fatturato": 1000000,
  "costi_variabili": 400000,
  "costi_fissi": 300000,
  "investimenti": 100000,
  "settore": "manufacturing",
  "dso_days": null,
  "dio_days": null,
  "dpo_days": null
}
```

### Analysis Response
```json
{
  "status": "warning",
  "headline": "Margini insufficienti",
  "summary": "...",
  "diagnosis": { ... },
  "kpi_snapshot": {
    "gross_profit_eur": 600000,
    "gross_margin_pct": 60,
    "ebitda_eur": 300000,
    "net_profit_eur": 300000,
    ...
  },
  "recommended_actions": [ ... ]
}
```

## 🚢 Deployment

### Option 1: Serve from FastAPI

Build the React app:
```bash
npm run build
```

Copy `build/` to backend's public folder:
```bash
cp -r build/* ../backend_path/static/
```

Configure FastAPI to serve static files (already done in Phase 1).

### Option 2: Standalone Deployment

Use any static host (Vercel, Netlify, etc.):

```bash
npm run build
# Deploy the 'build/' folder
```

Set `REACT_APP_API_URL` to your backend URL.

## 🧪 Testing

### Manual Testing Checklist

✅ **Login:**
- [ ] Register new user
- [ ] Login with credentials
- [ ] Token stored in localStorage
- [ ] Redirect to dashboard

✅ **Dashboard:**
- [ ] Input company data
- [ ] Click "Analyze"
- [ ] View KPI snapshot
- [ ] See recommendations

✅ **Simulator:**
- [ ] Adjust scenario deltas
- [ ] Compare vs base
- [ ] Check profit impact
- [ ] View recommendation

✅ **Chat:**
- [ ] Ask financial question
- [ ] Receive response
- [ ] View chat history
- [ ] Clear history works

## 📝 Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `REACT_APP_API_URL` | `http://127.0.0.1:8888` | Backend API base URL |
| `REACT_APP_DEBUG` | `false` | Enable debug logging |

## 🐛 Troubleshooting

### "API connection refused"
- Check backend is running: `http://127.0.0.1:8888/health`
- Verify `REACT_APP_API_URL` in `.env`
- Check CORS is enabled on backend

### "Token expired"
- Auto-redirects to login
- Clear localStorage if stuck

### "Charts not rendering"
- Ensure Recharts is installed: `npm list recharts`
- Check browser console for errors

## 👨‍💻 Development

### Add New Page

1. Create file: `src/pages/NewPage.js`
2. Wrap with `<Layout>` component
3. Add route in `App.js`
4. Add menu item in `Layout.js`

### Add New API Endpoint

Update `src/services/api.js`:
```javascript
export const cfoApi = {
  ...existing,
  newEndpoint: (data) => api.post('/cfo/new', data),
};
```

### Styling

- Use Material-UI `sx` prop for component styling
- Global styles in `src/index.css`
- Material-UI theme configured in `App.js`

## 📞 Support

For backend issues, see [PHASE2_CFO_IMPLEMENTATION.md](../PHASE2_CFO_IMPLEMENTATION.md)

## 📄 License

Internal use only.

---

**Version:** 1.0.0  
**Last Updated:** April 14, 2026  
**Status:** ✅ Production Ready
