import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Box,
  IconButton,
  Menu,
  MenuItem,
  Typography,
  Chip,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BoltIcon from '@mui/icons-material/Bolt';
import AnalyzeIcon from '@mui/icons-material/TrendingUp';
import SimulateIcon from '@mui/icons-material/Balance';
import ChatIcon from '@mui/icons-material/Chat';
import InventoryIcon from '@mui/icons-material/Inventory';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import StorefrontIcon from '@mui/icons-material/Storefront';
import EngineeringIcon from '@mui/icons-material/Engineering';
import DescriptionIcon from '@mui/icons-material/Description';
import StorageIcon from '@mui/icons-material/Storage';
import LogoutIcon from '@mui/icons-material/Logout';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useAuth } from '../context/authContext';

const Layout = ({ children }) => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
    handleMenuClose();
  };

  const menuItems = [
    { label: 'Dashboard', path: '/dashboard', icon: <DashboardIcon /> },
    { label: 'War Room', path: '/war-room', icon: <BoltIcon /> },
    { label: 'Report CFO', path: '/report', icon: <DescriptionIcon /> },
    { label: 'Data Room', path: '/data-room', icon: <StorageIcon /> },
    { label: 'Analyze', path: '/analyze', icon: <AnalyzeIcon /> },
    { label: 'Unit Economics', path: '/unit-economics', icon: <InventoryIcon /> },
    { label: 'Restaurant CFO', path: '/restaurant-cfo', icon: <RestaurantIcon /> },
    { label: 'Ecommerce CFO', path: '/ecommerce-cfo', icon: <StorefrontIcon /> },
    { label: 'Construction CFO', path: '/construction-cfo', icon: <EngineeringIcon /> },
    { label: 'Simulate', path: '/simulate', icon: <SimulateIcon /> },
    { label: 'Chat', path: '/chat', icon: <ChatIcon /> },
  ];

  const handleNavigate = (path) => {
    navigate(path);
    setMobileOpen(false);
  };

  const drawer = (
    <Box sx={{ p: 2, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
        <Box
          sx={{
            width: 34,
            height: 34,
            borderRadius: 1,
            background: 'linear-gradient(135deg, #35c6b6, #7aa7ff)',
            boxShadow: '0 12px 28px rgba(53,198,182,0.22)',
          }}
        />
        <Box>
          <Typography variant="h6" sx={{ fontWeight: 900, letterSpacing: 0 }}>
            ZephyBloom
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Executive CFO AI
          </Typography>
        </Box>
      </Box>
      <Chip
        label="Decision intelligence"
        size="small"
        sx={{
          mb: 2,
          borderRadius: 1,
          color: '#9ff0e7',
          backgroundColor: 'rgba(53,198,182,0.1)',
          border: '1px solid rgba(53,198,182,0.18)',
        }}
      />
      <List sx={{ display: 'flex', flexDirection: 'column', gap: 0.4 }}>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.path}
            onClick={() => handleNavigate(item.path)}
            sx={{
              borderRadius: 1,
              color: 'text.secondary',
              '& .MuiListItemIcon-root': { color: 'inherit', minWidth: 38 },
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.055)',
                color: 'text.primary',
              },
            }}
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14, fontWeight: 700 }} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#070808' }}>
      {/* AppBar */}
      <AppBar position="fixed" sx={{ zIndex: theme => theme.zIndex.drawer + 1 }}>
        <Toolbar sx={{ minHeight: 70 }}>
          <IconButton
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            {mobileOpen ? <CloseIcon /> : <MenuIcon />}
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 900 }}>
            CFO Command Center
          </Typography>
          <Chip
            label="Live financial cockpit"
            size="small"
            sx={{
              display: { xs: 'none', md: 'inline-flex' },
              borderRadius: 1,
              mr: 1,
              color: '#9ff0e7',
              backgroundColor: 'rgba(53,198,182,0.1)',
              border: '1px solid rgba(53,198,182,0.2)',
            }}
          />
          <IconButton
            onClick={handleMenuOpen}
            color="inherit"
            sx={{ ml: 2 }}
          >
            <AccountCircleIcon />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            <MenuItem disabled>
              <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                {user?.email}
              </Typography>
            </MenuItem>
            <MenuItem onClick={handleLogout}>
              <LogoutIcon sx={{ mr: 1 }} />
              Logout
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* Drawer */}
      <Box sx={{ display: { xs: 'none', sm: 'block' }, width: 270, flexShrink: 0 }}>
        <Box
          sx={{
            pt: 9,
            height: '100vh',
            position: 'fixed',
            width: 270,
            borderRight: '1px solid rgba(255,255,255,0.08)',
            backgroundColor: 'rgba(11,13,13,0.92)',
            backdropFilter: 'blur(18px)',
          }}
        >
          {drawer}
        </Box>
      </Box>

      {/* Mobile Drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        sx={{ display: { xs: 'block', sm: 'none' } }}
      >
        {drawer}
      </Drawer>

      {/* Main Content */}
      <Box
        sx={{
          flexGrow: 1,
          p: { xs: 2, sm: 3 },
          pt: 11,
          background:
            'linear-gradient(180deg, rgba(53,198,182,0.06) 0%, rgba(7,8,8,0) 260px), #070808',
          minHeight: '100vh',
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

export default Layout;
