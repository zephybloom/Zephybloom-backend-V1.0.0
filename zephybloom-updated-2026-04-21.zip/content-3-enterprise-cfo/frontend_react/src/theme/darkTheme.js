import { createTheme } from '@mui/material/styles';

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#070808',
      paper: '#101313',
    },
    primary: {
      main: '#35c6b6',
      light: '#7be0d5',
      dark: '#159283',
    },
    secondary: {
      main: '#7aa7ff',
      light: '#a8c4ff',
      dark: '#4c78d6',
    },
    success: {
      main: '#4caf50',
      light: '#81c784',
      dark: '#2e7d32',
    },
    warning: {
      main: '#ff9800',
      light: '#ffb74d',
      dark: '#e65100',
    },
    error: {
      main: '#f44336',
      light: '#ef5350',
      dark: '#c62828',
    },
    info: {
      main: '#2196f3',
      light: '#64b5f6',
      dark: '#1565c0',
    },
    text: {
      primary: '#f4f7f5',
      secondary: '#9aa6a1',
      disabled: '#5d6662',
    },
    divider: '#252b29',
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '2.5rem',
      letterSpacing: '-0.5px',
    },
    h2: {
      fontWeight: 600,
      fontSize: '2rem',
      letterSpacing: 0,
    },
    h3: {
      fontWeight: 600,
      fontSize: '1.75rem',
    },
    h4: {
      fontWeight: 600,
      fontSize: '1.5rem',
    },
    h5: {
      fontWeight: 500,
      fontSize: '1.25rem',
    },
    h6: {
      fontWeight: 500,
      fontSize: '1rem',
    },
    body1: {
      fontSize: '0.95rem',
      lineHeight: 1.6,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.5,
    },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          background:
            'radial-gradient(circle at 50% -20%, rgba(53,198,182,0.16), transparent 36%), #070808',
          color: '#f4f7f5',
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: 'rgba(8, 10, 10, 0.82)',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          backdropFilter: 'blur(18px)',
          boxShadow: 'none',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: '#101313',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 8,
          boxShadow: '0 18px 60px rgba(0,0,0,0.22)',
          transition: 'border-color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease',
          '&:hover': {
            boxShadow: '0 22px 70px rgba(0,0,0,0.28)',
            borderColor: 'rgba(53,198,182,0.42)',
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 700,
          borderRadius: 8,
          transition: 'all 0.2s ease',
        },
        containedPrimary: {
          background: 'linear-gradient(135deg, #35c6b6 0%, #7aa7ff 100%)',
          color: '#061010',
          boxShadow: '0 14px 34px rgba(53,198,182,0.22)',
          '&:hover': {
            boxShadow: '0 18px 44px rgba(53,198,182,0.3)',
          },
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            backgroundColor: '#0b0d0d',
            borderRadius: 8,
            '& fieldset': {
              borderColor: '#2a302e',
            },
            '&:hover fieldset': {
              borderColor: '#35c6b6',
            },
            '&.Mui-focused fieldset': {
              borderColor: '#35c6b6',
            },
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundColor: '#101313',
          backgroundImage: 'none',
        },
      },
    },
  },
  shape: {
    borderRadius: 8,
  },
});

export default darkTheme;
