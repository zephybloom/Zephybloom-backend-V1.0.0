import React, { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  CircularProgress,
  Container,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import Layout from '../components/Layout';
import { cfoApi } from '../services/api';
import { useCompany } from '../context/companyContext';

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

const DEFAULT_FORM = {
  annual_revenue: 900000,
  variable_costs: 300000,
  fixed_costs: 180000,
  invested_capital: 120000,
  opening_days_per_month: 25,
  average_daily_covers: 90,
  average_ticket: 36,
  target_food_cost_pct: 30,
  waste_pct: 2,
  delivery_commissions_pct: 0,
};

const DEFAULT_INGREDIENTS = [
  { name: 'mozzarella', unit_cost: 0.006 },
  { name: 'farina', unit_cost: 0.001 },
  { name: 'pomodoro', unit_cost: 0.003 },
];

const DEFAULT_MENU = [
  {
    name: 'Margherita',
    price: 9,
    monthly_units: 1200,
    ingredient_1: 'mozzarella',
    quantity_1: 120,
    ingredient_2: 'farina',
    quantity_2: 180,
    ingredient_3: 'pomodoro',
    quantity_3: 80,
  },
  {
    name: 'Piatto premium',
    price: 24,
    monthly_units: 280,
    ingredient_1: 'mozzarella',
    quantity_1: 180,
    ingredient_2: 'pomodoro',
    quantity_2: 120,
    ingredient_3: '',
    quantity_3: 0,
  },
];

const DEFAULT_STAFF = [
  { role: 'Cuoco', count: 2, monthly_cost: 2400 },
  { role: 'Sala', count: 3, monthly_cost: 1600 },
];

const DEFAULT_SCENARIO = {
  name: 'Scenario operativo',
  price_delta_pct: 5,
  covers_delta_pct: 10,
  ingredient_cost_delta_pct: -3,
  staff_cost_delta_pct: 0,
  fixed_cost_delta_pct: 0,
  waste_delta_pct: -1,
  target_dish: '',
};

function RestaurantCFOPage() {
  const { updateCompanyData, saveOperationalData } = useCompany();
  const [form, setForm] = useState(DEFAULT_FORM);
  const [ingredients, setIngredients] = useState(DEFAULT_INGREDIENTS);
  const [menu, setMenu] = useState(DEFAULT_MENU);
  const [staff, setStaff] = useState(DEFAULT_STAFF);
  const [analysis, setAnalysis] = useState(null);
  const [simulation, setSimulation] = useState(null);
  const [scenario, setScenario] = useState(DEFAULT_SCENARIO);
  const [readiness, setReadiness] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const restaurantAnalysis = analysis?.restaurant_analysis;
  const summary = restaurantAnalysis?.summary;

  const operationalData = useMemo(() => ({
    ...form,
    ingredient_costs: ingredients.filter((row) => row.name),
    menu_items: menu.filter((row) => row.name).map((row) => ({
      name: row.name,
      price: Number(row.price || 0),
      monthly_units: Number(row.monthly_units || 0),
      recipe: [
        { ingredient: row.ingredient_1, quantity: Number(row.quantity_1 || 0) },
        { ingredient: row.ingredient_2, quantity: Number(row.quantity_2 || 0) },
        { ingredient: row.ingredient_3, quantity: Number(row.quantity_3 || 0) },
      ].filter((item) => item.ingredient && item.quantity > 0),
    })),
    staff_roles: staff.filter((row) => row.role),
  }), [form, ingredients, menu, staff]);

  const updateForm = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: Number(value || 0) }));
  };

  const updateScenario = (field, value, numeric = true) => {
    setScenario((prev) => ({ ...prev, [field]: numeric ? Number(value || 0) : value }));
  };

  const updateList = (setter, index, field, value, numeric = false) => {
    setter((prev) =>
      prev.map((row, rowIndex) =>
        rowIndex === index ? { ...row, [field]: numeric ? Number(value || 0) : value } : row
      )
    );
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError('');
    try {
      const [analysisResponse, readinessResponse] = await Promise.all([
        cfoApi.restaurantAnalyze(operationalData),
        cfoApi.dataRequirements('restaurant', operationalData),
      ]);
      setAnalysis(analysisResponse.data);
      setReadiness(readinessResponse.data.data_readiness);
      updateCompanyData({
        fatturato: operationalData.annual_revenue,
        costi_variabili: operationalData.variable_costs,
        costi_fissi: operationalData.fixed_costs,
        investimenti: operationalData.invested_capital,
        settore: 'restaurant',
      });
      saveOperationalData('restaurant', operationalData);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulate = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.restaurantSimulate(operationalData, scenario);
      setSimulation(response.data.restaurant_simulation);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const metric = (label, value) => (
    <Card>
      <CardContent>
        <Typography color="textSecondary">{label}</Typography>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>{value}</Typography>
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>
              Restaurant CFO
            </Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Calcola food cost, prime cost, break-even e prezzo target dei piatti.
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<RestaurantIcon />} onClick={handleAnalyze} disabled={loading}>
            {loading ? <CircularProgress size={22} /> : 'Analizza ristorante'}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        <Card sx={{ mb: 4 }}>
          <CardHeader title="Numeri base" subheader="Dati annuali e capacità del locale." />
          <CardContent>
            <Grid container spacing={2}>
              {Object.entries({
                annual_revenue: 'Fatturato annuo',
                variable_costs: 'Costi variabili annui',
                fixed_costs: 'Costi fissi annui',
                invested_capital: 'Capitale investito',
                opening_days_per_month: 'Giorni apertura/mese',
                average_daily_covers: 'Coperti medi/giorno',
                average_ticket: 'Scontrino medio',
                target_food_cost_pct: 'Food cost target %',
                waste_pct: 'Spreco %',
                delivery_commissions_pct: 'Commissioni delivery %',
              }).map(([field, label]) => (
                <Grid item xs={12} sm={6} md={3} key={field}>
                  <TextField
                    label={label}
                    type="number"
                    value={form[field]}
                    fullWidth
                    size="small"
                    onChange={(event) => updateForm(field, event.target.value)}
                  />
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>

        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader
                title="Ingredienti"
                action={<Button size="small" startIcon={<AddIcon />} onClick={() => setIngredients((prev) => [...prev, { name: '', unit_cost: 0 }])}>Riga</Button>}
              />
              <CardContent>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ingrediente</TableCell>
                      <TableCell>Costo unitario</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ingredients.map((row, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <TextField size="small" value={row.name} fullWidth onChange={(event) => updateList(setIngredients, index, 'name', event.target.value)} />
                        </TableCell>
                        <TableCell>
                          <TextField size="small" type="number" value={row.unit_cost} fullWidth onChange={(event) => updateList(setIngredients, index, 'unit_cost', event.target.value, true)} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader
                title="Personale"
                action={<Button size="small" startIcon={<AddIcon />} onClick={() => setStaff((prev) => [...prev, { role: '', count: 1, monthly_cost: 0 }])}>Riga</Button>}
              />
              <CardContent>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Ruolo</TableCell>
                      <TableCell>Persone</TableCell>
                      <TableCell>Costo mensile</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {staff.map((row, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <TextField size="small" value={row.role} fullWidth onChange={(event) => updateList(setStaff, index, 'role', event.target.value)} />
                        </TableCell>
                        <TableCell>
                          <TextField size="small" type="number" value={row.count} fullWidth onChange={(event) => updateList(setStaff, index, 'count', event.target.value, true)} />
                        </TableCell>
                        <TableCell>
                          <TextField size="small" type="number" value={row.monthly_cost} fullWidth onChange={(event) => updateList(setStaff, index, 'monthly_cost', event.target.value, true)} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="Menu e ricette"
            subheader="Ogni piatto può usare fino a tre ingredienti in questa prima versione."
            action={<Button size="small" startIcon={<AddIcon />} onClick={() => setMenu((prev) => [...prev, { name: '', price: 0, monthly_units: 0, ingredient_1: '', quantity_1: 0, ingredient_2: '', quantity_2: 0, ingredient_3: '', quantity_3: 0 }])}>Piatto</Button>}
          />
          <CardContent sx={{ overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 1050 }}>
              <TableHead>
                <TableRow>
                  <TableCell>Piatto</TableCell>
                  <TableCell>Prezzo</TableCell>
                  <TableCell>Vendite/mese</TableCell>
                  <TableCell>Ingrediente 1</TableCell>
                  <TableCell>Qta 1</TableCell>
                  <TableCell>Ingrediente 2</TableCell>
                  <TableCell>Qta 2</TableCell>
                  <TableCell>Ingrediente 3</TableCell>
                  <TableCell>Qta 3</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {menu.map((row, index) => (
                  <TableRow key={index}>
                    {[
                      ['name', false],
                      ['price', true],
                      ['monthly_units', true],
                      ['ingredient_1', false],
                      ['quantity_1', true],
                      ['ingredient_2', false],
                      ['quantity_2', true],
                      ['ingredient_3', false],
                      ['quantity_3', true],
                    ].map(([field, numeric]) => (
                      <TableCell key={field} sx={{ minWidth: numeric ? 110 : 150 }}>
                        <TextField
                          size="small"
                          type={numeric ? 'number' : 'text'}
                          value={row[field]}
                          fullWidth
                          onChange={(event) => updateList(setMenu, index, field, event.target.value, numeric)}
                        />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="Scenario operativo"
            subheader="Simula leve reali: prezzo, coperti, spreco, ingredienti, personale e costi fissi."
            action={
              <Button variant="outlined" onClick={handleSimulate} disabled={loading}>
                Simula scenario
              </Button>
            }
          />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={3}>
                <TextField label="Nome scenario" value={scenario.name} fullWidth size="small" onChange={(event) => updateScenario('name', event.target.value, false)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField label="Piatto target opzionale" value={scenario.target_dish} fullWidth size="small" onChange={(event) => updateScenario('target_dish', event.target.value, false)} />
              </Grid>
              {[
                ['price_delta_pct', 'Prezzo %'],
                ['covers_delta_pct', 'Coperti %'],
                ['ingredient_cost_delta_pct', 'Ingredienti %'],
                ['staff_cost_delta_pct', 'Personale %'],
                ['fixed_cost_delta_pct', 'Costi fissi %'],
                ['waste_delta_pct', 'Spreco punti %'],
              ].map(([field, label]) => (
                <Grid item xs={12} sm={6} md={2} key={field}>
                  <TextField
                    label={label}
                    type="number"
                    value={scenario[field]}
                    fullWidth
                    size="small"
                    onChange={(event) => updateScenario(field, event.target.value)}
                  />
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>

        {summary && (
          <>
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={3}>{metric('Food cost', `${summary.food_cost_pct}%`)}</Grid>
              <Grid item xs={12} md={3}>{metric('Labour cost', `${summary.labour_cost_pct}%`)}</Grid>
              <Grid item xs={12} md={3}>{metric('Prime cost', `${summary.prime_cost_pct}%`)}</Grid>
              <Grid item xs={12} md={3}>{metric('Break-even coperti/giorno', summary.break_even_covers_per_day)}</Grid>
            </Grid>

            {simulation && (
              <Card sx={{ mb: 4 }}>
                <CardHeader title="Risultato scenario" subheader={simulation.decision} />
                <CardContent>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={3}>{metric('Delta utile annuo', formatCurrency(simulation.delta.net_profit_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta ricavi annui', formatCurrency(simulation.delta.annual_revenue_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta prime cost', `${simulation.delta.prime_cost_pct}%`)}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta break-even', simulation.delta.break_even_covers_per_day)}</Grid>
                  </Grid>
                  <Typography sx={{ mt: 3, fontWeight: 800 }}>
                    Scenario: utile {formatCurrency(simulation.simulated.summary.net_profit_eur)} | margine netto {simulation.simulated.summary.net_margin_pct}% | ROI {simulation.simulated.summary.roi_pct}%
                  </Typography>
                </CardContent>
              </Card>
            )}

            {readiness && (
              <Alert severity={readiness.can_answer_precisely ? 'success' : 'warning'} sx={{ mb: 4 }}>
                Precisione dati: {readiness.answer_precision_pct}% - {readiness.readiness_level}
              </Alert>
            )}

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Piatti migliori per utile" />
                  <CardContent>
                    {(restaurantAnalysis.top_dishes_by_profit || []).slice(0, 5).map((dish, index) => (
                      <Box key={dish.name} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{index + 1}. {dish.name}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Utile/mese {formatCurrency(dish.monthly_profit_eur)} | Margine {dish.gross_margin_pct}% | Food cost {dish.food_cost_pct}%
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Piatti da correggere" />
                  <CardContent>
                    {(restaurantAnalysis.dishes_to_fix || []).slice(0, 5).map((dish) => (
                      <Box key={dish.name} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{dish.name}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Prezzo {formatCurrency(dish.price_eur)} | Prezzo target {formatCurrency(dish.recommended_price_for_target_margin_eur)} | {dish.decision}
                        </Typography>
                      </Box>
                    ))}
                    {restaurantAnalysis.dishes_to_fix?.length === 0 && (
                      <Typography variant="body2" color="textSecondary">Nessun piatto critico evidente.</Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Decisione CFO" />
                  <CardContent>
                    {(restaurantAnalysis.recommendations || []).map((item, index) => (
                      <Typography key={index} sx={{ mb: 1 }}>
                        {index + 1}. {item}
                      </Typography>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default RestaurantCFOPage;
