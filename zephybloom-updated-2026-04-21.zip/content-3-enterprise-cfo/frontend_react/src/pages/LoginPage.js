import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Container,
  Grid,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import ShieldOutlinedIcon from '@mui/icons-material/ShieldOutlined';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import AutoGraphIcon from '@mui/icons-material/AutoGraph';
import { useAuth } from '../context/authContext';

function LoginPage() {
  const navigate = useNavigate();
  const { login, register, demoLogin, error, loading } = useAuth();
  const [tab, setTab] = useState(0);
  const [formData, setFormData] = useState({
    email: 'demo@example.com',
    password: 'DemoPassword123',
    full_name: '',
  });
  const [localError, setLocalError] = useState('');

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleLogin = async (event) => {
    event.preventDefault();
    if (!formData.email || !formData.password) {
      setLocalError('Inserisci email e password.');
      return;
    }
    const success = await login(formData.email, formData.password);
    if (success) navigate('/dashboard');
  };

  const handleRegister = async (event) => {
    event.preventDefault();
    if (!formData.email || !formData.password || !formData.full_name) {
      setLocalError('Completa tutti i campi.');
      return;
    }
    const success = await register(formData.email, formData.password, formData.full_name);
    if (success) navigate('/dashboard');
  };

  const handleDemoLogin = () => {
    demoLogin();
    navigate('/dashboard');
  };

  const metrics = [
    ['€2.4M', 'opportunità identificate'],
    ['<3 min', 'lettura CFO'],
    ['25+', 'KPI e leve operative'],
  ];

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: '#070808', overflow: 'hidden' }}>
      <Container maxWidth="lg" sx={{ py: { xs: 4, md: 7 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: { xs: 5, md: 8 } }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Box sx={{ width: 34, height: 34, borderRadius: 1, background: 'linear-gradient(135deg, #35c6b6, #7aa7ff)' }} />
            <Typography variant="h6" sx={{ fontWeight: 900 }}>ZephyBloom CFO</Typography>
          </Box>
          <Button variant="outlined" onClick={handleDemoLogin} sx={{ display: { xs: 'none', sm: 'inline-flex' } }}>
            Entra in demo
          </Button>
        </Box>

        <Grid container spacing={4} alignItems="center">
          <Grid item xs={12} md={7}>
            <Chip
              label="Trusted CFO intelligence for growing companies"
              sx={{
                mb: 3,
                borderRadius: 1,
                color: '#9ff0e7',
                backgroundColor: 'rgba(53,198,182,0.1)',
                border: '1px solid rgba(53,198,182,0.2)',
              }}
            />
            <Typography
              variant="h1"
              sx={{
                maxWidth: 780,
                fontSize: { xs: '2.8rem', md: '4.8rem' },
                lineHeight: 0.98,
                fontWeight: 900,
                letterSpacing: 0,
              }}
            >
              Il CFO virtuale che trasforma numeri in decisioni.
            </Typography>
            <Typography color="text.secondary" sx={{ mt: 3, maxWidth: 650, fontSize: '1.08rem', lineHeight: 1.8 }}>
              Analizza margini, cassa, prodotti, canali, commesse e report direzionali. Ogni risposta mostra qualità,
              fonti e dati mancanti, così sai quando agire e quando completare la Data Room.
            </Typography>

            <Box sx={{ display: 'flex', gap: 2, mt: 4, flexWrap: 'wrap' }}>
              <Button variant="contained" size="large" endIcon={<ArrowForwardIcon />} onClick={handleDemoLogin}>
                Apri il CFO cockpit
              </Button>
              <Button variant="outlined" size="large" onClick={() => setTab(1)}>
                Crea accesso
              </Button>
            </Box>

            <Grid container spacing={2} sx={{ mt: 5, maxWidth: 720 }}>
              {metrics.map(([value, label]) => (
                <Grid item xs={12} sm={4} key={label}>
                  <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', pt: 2 }}>
                    <Typography variant="h4" sx={{ fontWeight: 900 }}>{value}</Typography>
                    <Typography color="text.secondary" variant="body2">{label}</Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Grid>

          <Grid item xs={12} md={5}>
            <Card sx={{ border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(16,19,19,0.86)', backdropFilter: 'blur(18px)' }}>
              <CardContent sx={{ p: { xs: 3, md: 4 } }}>
                <Typography variant="h5" sx={{ fontWeight: 900, mb: 1 }}>
                  Accesso executive
                </Typography>
                <Typography color="text.secondary" sx={{ mb: 3 }}>
                  Entra nella dashboard e lavora sulla tua azienda.
                </Typography>

                <Tabs value={tab} onChange={(event, value) => { setTab(value); setLocalError(''); }} variant="fullWidth" sx={{ mb: 3 }}>
                  <Tab label="Login" />
                  <Tab label="Register" />
                </Tabs>

                {(error || localError) && <Alert severity="error" sx={{ mb: 2 }}>{error || localError}</Alert>}

                <Box component="form" onSubmit={tab === 0 ? handleLogin : handleRegister} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {tab === 1 && (
                    <TextField label="Nome completo" name="full_name" value={formData.full_name} onChange={handleInputChange} fullWidth disabled={loading} />
                  )}
                  <TextField label="Email" type="email" name="email" value={formData.email} onChange={handleInputChange} fullWidth disabled={loading} />
                  <TextField label="Password" type="password" name="password" value={formData.password} onChange={handleInputChange} fullWidth disabled={loading} />
                  <Button type="submit" variant="contained" size="large" disabled={loading}>
                    {loading ? <CircularProgress size={22} /> : tab === 0 ? 'Accedi' : 'Crea account'}
                  </Button>
                  <Button type="button" variant="outlined" size="large" onClick={handleDemoLogin} disabled={loading}>
                    Entra in demo locale
                  </Button>
                </Box>

                <Grid container spacing={1.5} sx={{ mt: 3 }}>
                  {[
                    [ShieldOutlinedIcon, 'Risposte con confidenza'],
                    [QueryStatsIcon, 'War Room settimanale'],
                    [AutoGraphIcon, 'Report CFO mensile'],
                  ].map(([Icon, label]) => (
                    <Grid item xs={12} key={label}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, color: 'text.secondary' }}>
                        <Icon sx={{ fontSize: 18, color: '#35c6b6' }} />
                        <Typography variant="body2">{label}</Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}

export default LoginPage;
