import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Chip,
  CircularProgress,
  Container,
  Grid,
  Typography,
} from '@mui/material';
import BoltIcon from '@mui/icons-material/Bolt';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import StorefrontIcon from '@mui/icons-material/Storefront';
import EngineeringIcon from '@mui/icons-material/Engineering';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

const SECTOR_META = {
  restaurant: {
    label: 'Restaurant CFO',
    icon: <RestaurantIcon />,
    route: '/restaurant-cfo',
  },
  ecommerce: {
    label: 'Ecommerce CFO',
    icon: <StorefrontIcon />,
    route: '/ecommerce-cfo',
  },
  construction: {
    label: 'Construction CFO',
    icon: <EngineeringIcon />,
    route: '/construction-cfo',
  },
};

function WarRoomPage() {
  const { companyData, operationalDataBySector } = useCompany();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cards, setCards] = useState([]);
  const [priorityDecision, setPriorityDecision] = useState(null);
  const [portfolioSummary, setPortfolioSummary] = useState(null);
  const [executiveSummary, setExecutiveSummary] = useState(null);
  const [decisionQueue, setDecisionQueue] = useState([]);
  const [weeklyAgenda, setWeeklyAgenda] = useState([]);
  const [executionTracker, setExecutionTracker] = useState([]);
  const [dataGapBoard, setDataGapBoard] = useState([]);
  const [stopGoBoard, setStopGoBoard] = useState([]);
  const [memorySummary, setMemorySummary] = useState(null);
  const [memoryDecisions, setMemoryDecisions] = useState([]);
  const [feedbackMessage, setFeedbackMessage] = useState('');

  const activeSectors = useMemo(
    () => Object.keys(operationalDataBySector || {}).filter((sector) => SECTOR_META[sector]),
    [operationalDataBySector]
  );

  const loadDecisionMemory = useCallback(async () => {
    try {
      const response = await cfoApi.memoryDecisions();
      setMemorySummary(response.data.summary);
      setMemoryDecisions(response.data.decisions || []);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    }
  }, []);

  useEffect(() => {
    loadDecisionMemory();
  }, [loadDecisionMemory]);

  const handleBuildWarRoom = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.warRoom(operationalDataBySector, companyData.settore);
      const warRoom = response.data.war_room;
      setCards((warRoom.sector_cards || []).map((card) => ({
        ...card,
        ...SECTOR_META[card.sector],
        scoreLabel: card.score_label,
        keyMetric: card.key_metric,
        keyMetricLabel: card.key_metric_label,
      })));
      setPriorityDecision(warRoom.priority_decision);
      setPortfolioSummary(warRoom.portfolio_summary);
      setExecutiveSummary(warRoom.executive_summary);
      setDecisionQueue(warRoom.decision_queue || []);
      setWeeklyAgenda(warRoom.weekly_agenda || []);
      setExecutionTracker(warRoom.execution_tracker || []);
      setDataGapBoard(warRoom.data_gap_board || []);
      setStopGoBoard(warRoom.stop_go_board || []);
      setMemorySummary(response.data.decision_memory?.summary || warRoom.memory_context?.summary || null);
      await loadDecisionMemory();
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDecisionFeedback = async (item) => {
    const rawImpact = window.prompt('Impatto reale stimato in EUR? Usa 0 se non lo sai ancora.', '0');
    if (rawImpact === null) return;
    const actualImpact = Number(rawImpact || 0);
    setFeedbackMessage('');
    try {
      await cfoApi.decisionFeedback(item.decision_id, {
        was_implemented: true,
        actual_impact_eur: Number.isFinite(actualImpact) ? actualImpact : 0,
        sector: item.sector,
      });
      setExecutionTracker((prev) =>
        prev.map((decision) =>
          decision.decision_id === item.decision_id ? { ...decision, status: 'done' } : decision
        )
      );
      setFeedbackMessage(`Feedback registrato per ${item.decision_id}.`);
      await loadDecisionMemory();
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((entry) => entry.msg).join(' | ') : detail || err.message);
    }
  };

  const handleDecisionStatus = async (item, status) => {
    const reason =
      status === 'archived'
        ? window.prompt('Perché vuoi archiviare questa decisione?', 'Non è più prioritaria')
        : window.prompt('Nota CFO per questa decisione?', 'Rimandata alla prossima review');
    if (reason === null) return;
    setFeedbackMessage('');
    try {
      await cfoApi.updateMemoryDecision(item.decision_id, {
        status,
        reason,
        postpone_days: status === 'todo' ? 7 : undefined,
      });
      setExecutionTracker((prev) =>
        prev.map((decision) =>
          decision.decision_id === item.decision_id ? { ...decision, status } : decision
        )
      );
      setFeedbackMessage(
        status === 'archived'
          ? `Decisione archiviata: ${item.decision_id}.`
          : `Decisione rimandata alla prossima review: ${item.decision_id}.`
      );
      await loadDecisionMemory();
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((entry) => entry.msg).join(' | ') : detail || err.message);
    }
  };

  const executionPlan = priorityDecision?.execution_plan;

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>
              CFO War Room
            </Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Una vista unica su rischi, dati mancanti, opportunità e prossime azioni.
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<BoltIcon />} onClick={handleBuildWarRoom} disabled={loading || activeSectors.length === 0}>
            {loading ? <CircularProgress size={22} /> : 'Costruisci War Room'}
          </Button>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}
        {feedbackMessage && <Alert severity="success" sx={{ mb: 3 }} onClose={() => setFeedbackMessage('')}>{feedbackMessage}</Alert>}

        {activeSectors.length === 0 && (
          <Alert severity="info" sx={{ mb: 4 }}>
            Nessun verticale operativo salvato. Analizza prima Restaurant, Ecommerce o Construction CFO.
          </Alert>
        )}

        {activeSectors.length > 0 && cards.length === 0 && (
          <Alert severity="success" sx={{ mb: 4 }}>
            Verticali disponibili: {activeSectors.map((sector) => SECTOR_META[sector].label).join(', ')}. Avvia la War Room per aggregarli.
          </Alert>
        )}

        {portfolioSummary && (
          <Grid container spacing={2} sx={{ mb: 4 }}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary">Precisione media dati</Typography>
                  <Typography variant="h5" sx={{ fontWeight: 800 }}>
                    {portfolioSummary.readiness_avg_pct}%
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary">Settori pronti</Typography>
                  <Typography variant="h5" sx={{ fontWeight: 800 }}>
                    {portfolioSummary.sectors_ready}/{cards.length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography color="textSecondary">Vincolo principale</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 800 }}>
                    {String(portfolioSummary.main_constraint || '').replaceAll('_', ' ')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}

        {memorySummary && (
          <Card sx={{ mb: 4 }}>
            <CardHeader title="Storico decisioni" subheader={memorySummary.next_review} />
            <CardContent>
              <Grid container spacing={2} sx={{ mb: 2 }}>
                <Grid item xs={6} md={3}>
                  <Typography color="textSecondary">Aperte</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 800 }}>{memorySummary.open_decisions || 0}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography color="textSecondary">Completate</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 800 }}>{memorySummary.completed_decisions || 0}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography color="textSecondary">Sotto target</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 800 }}>{memorySummary.below_target_count || 0}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography color="textSecondary">Impatto reale</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 800 }}>{formatCurrency(memorySummary.actual_impact_eur || 0)}</Typography>
                </Grid>
              </Grid>
              {memorySummary.memory_quality && (
                <Alert severity={memorySummary.memory_quality === 'clean' ? 'success' : 'warning'} sx={{ mb: 2 }}>
                  Qualità memoria: {String(memorySummary.memory_quality).replaceAll('_', ' ')}
                  {(memorySummary.memory_quality_notes || []).map((note) => (
                    <Typography key={note} variant="body2">{note}</Typography>
                  ))}
                </Alert>
              )}
              {(memoryDecisions || []).slice(0, 5).map((decision) => (
                <Box key={decision.decision_id} sx={{ mb: 2, pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center', mb: 1 }}>
                    <Chip label={decision.decision_id} size="small" />
                    <Chip label={decision.status} size="small" color={decision.status === 'done' ? 'success' : 'warning'} />
                    {decision.is_stale && <Chip label="stale" size="small" color="error" />}
                    <Typography sx={{ fontWeight: 800 }}>{SECTOR_META[decision.sector]?.label || decision.sector || 'CFO'}</Typography>
                  </Box>
                  <Typography variant="body2" sx={{ mb: 0.5 }}>
                    {decision.next_action || decision.decision}
                  </Typography>
                  {decision.actual_impact_eur !== null && decision.actual_impact_eur !== undefined && (
                    <Typography variant="body2" color="textSecondary">
                      Impatto: {formatCurrency(decision.actual_impact_eur)} | Esito: {decision.outcome_review?.status || 'misurato'}
                    </Typography>
                  )}
                  {decision.status === 'todo' && (
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                      <Button size="small" onClick={() => handleDecisionFeedback(decision)}>
                        Segna eseguita
                      </Button>
                      <Button size="small" onClick={() => handleDecisionStatus(decision, 'todo')}>
                        Rimanda 7 giorni
                      </Button>
                      <Button size="small" color="warning" onClick={() => handleDecisionStatus(decision, 'archived')}>
                        Archivia
                      </Button>
                    </Box>
                  )}
                </Box>
              ))}
            </CardContent>
          </Card>
        )}

        {priorityDecision && (
          <Card sx={{ mb: 4 }}>
            <CardHeader
              title={priorityDecision.title}
              subheader={SECTOR_META[priorityDecision.sector]?.label || 'CFO War Room'}
              avatar={SECTOR_META[priorityDecision.sector]?.icon || <BoltIcon />}
            />
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 800, mb: 1 }}>
                {priorityDecision.decision}
              </Typography>
              <Typography color="textSecondary" sx={{ mb: 1 }}>
                {priorityDecision.why}
              </Typography>
              <Typography>
                {priorityDecision.next_step}
              </Typography>
              {priorityDecision.board_instruction && (
                <Alert severity="success" sx={{ mt: 2 }}>
                  {priorityDecision.board_instruction}
                </Alert>
              )}
              {executionPlan && (
                <Box sx={{ mt: 3 }}>
                  <Typography sx={{ fontWeight: 800, mb: 1 }}>Questa settimana</Typography>
                  {(executionPlan.this_week || []).map((action, index) => (
                    <Typography key={action} variant="body2" sx={{ mb: 0.5 }}>
                      {index + 1}. {action}
                    </Typography>
                  ))}
                  <Typography sx={{ fontWeight: 800, mt: 2, mb: 1 }}>KPI da controllare</Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {(executionPlan.kpis || []).map((kpi) => (
                      <Chip key={kpi} label={kpi} size="small" />
                    ))}
                  </Box>
                  {executionPlan.recommended_simulation && (
                    <Alert severity="info" sx={{ mt: 2 }}>
                      Simulazione consigliata: {executionPlan.recommended_simulation}
                    </Alert>
                  )}
                </Box>
              )}
            </CardContent>
          </Card>
        )}

        {executiveSummary && (
          <Card sx={{ mb: 4 }}>
            <CardHeader title="Executive Summary" subheader={executiveSummary.headline} />
            <CardContent>
              <Typography sx={{ mb: 2 }}>{executiveSummary.diagnosis}</Typography>
              <Typography sx={{ fontWeight: 800, mb: 1 }}>Da fare ora</Typography>
              {(executiveSummary.do_now || []).map((item) => (
                <Typography key={item} variant="body2" sx={{ mb: 0.5 }}>- {item}</Typography>
              ))}
              <Typography sx={{ fontWeight: 800, mt: 2, mb: 1 }}>Da non fare</Typography>
              {(executiveSummary.do_not_do || []).map((item) => (
                <Typography key={item} variant="body2" sx={{ mb: 0.5 }}>- {item}</Typography>
              ))}
              <Alert severity="info" sx={{ mt: 2 }}>{executiveSummary.cfo_note}</Alert>
            </CardContent>
          </Card>
        )}

        {weeklyAgenda.length > 0 && (
          <Card sx={{ mb: 4 }}>
            <CardHeader title="Agenda CFO della settimana" subheader="Azioni ordinate per impatto e urgenza" />
            <CardContent>
              <Grid container spacing={2}>
                {weeklyAgenda.map((item) => (
                  <Grid item xs={12} md={4} key={`${item.day}-${item.sector}`}>
                    <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 2, height: '100%' }}>
                      <Typography sx={{ fontWeight: 800 }}>{item.day}</Typography>
                      <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                        {SECTOR_META[item.sector]?.label || item.sector} | Owner: {item.owner}
                      </Typography>
                      <Typography sx={{ mb: 1 }}>{item.action}</Typography>
                      <Chip label={`KPI: ${item.kpi}`} size="small" />
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        )}

        {decisionQueue.length > 0 && (
          <Card sx={{ mb: 4 }}>
            <CardHeader title="Coda decisionale" subheader="Le decisioni che il CFO AI metterebbe in ordine questa settimana" />
            <CardContent>
              {decisionQueue.map((item) => (
                <Box key={`${item.rank}-${item.sector}`} sx={{ mb: 2, pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', mb: 1 }}>
                    <Chip label={`#${item.rank}`} size="small" color="primary" />
                    <Typography sx={{ fontWeight: 800 }}>{item.label}</Typography>
                    <Chip label={item.go_no_go?.status || 'TEST'} size="small" color={item.go_no_go?.status === 'GO' ? 'success' : 'warning'} />
                  </Box>
                  <Typography sx={{ mb: 0.5 }}>{item.decision}</Typography>
                  <Typography variant="body2" color="textSecondary">{item.why}</Typography>
                  {item.economic_lever && (
                    <Typography variant="body2" sx={{ mt: 1 }}>
                      Leva: {item.economic_lever.label} | Target: {item.economic_lever.target}
                    </Typography>
                  )}
                </Box>
              ))}
            </CardContent>
          </Card>
        )}

        {executionTracker.length > 0 && (
          <Card sx={{ mb: 4 }}>
            <CardHeader title="Controllo esecuzione" subheader="Come verificare se le decisioni stanno funzionando" />
            <CardContent>
              {executionTracker.map((item) => (
                <Box key={item.decision_id} sx={{ mb: 2, pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', mb: 1 }}>
                    <Chip label={item.decision_id} size="small" />
                    <Chip label={item.status} size="small" color="warning" />
                    <Typography sx={{ fontWeight: 800 }}>{SECTOR_META[item.sector]?.label || item.sector}</Typography>
                  </Box>
                  <Typography sx={{ mb: 1 }}>{item.next_action}</Typography>
                  <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                    {item.success_metric?.rule}
                  </Typography>
                  <Typography variant="body2">
                    Follow-up: {item.follow_up_question}
                  </Typography>
                  <Button size="small" sx={{ mt: 1 }} onClick={() => handleDecisionFeedback(item)}>
                    Segna eseguita
                  </Button>
                  <Button size="small" sx={{ mt: 1, ml: 1 }} onClick={() => handleDecisionStatus(item, 'todo')}>
                    Rimanda
                  </Button>
                  <Button size="small" color="warning" sx={{ mt: 1, ml: 1 }} onClick={() => handleDecisionStatus(item, 'archived')}>
                    Archivia
                  </Button>
                </Box>
              ))}
            </CardContent>
          </Card>
        )}

        {(dataGapBoard.length > 0 || stopGoBoard.length > 0) && (
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {dataGapBoard.length > 0 && (
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Dati che bloccano precisione" />
                  <CardContent>
                    {dataGapBoard.map((gap) => (
                      <Typography key={`${gap.sector}-${gap.key}`} variant="body2" sx={{ mb: 1 }}>
                        <strong>{gap.label}</strong>: {gap.field}
                      </Typography>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            )}
            {stopGoBoard.length > 0 && (
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Stop / Go control" />
                  <CardContent>
                    {stopGoBoard.map((rule) => (
                      <Alert key={rule.sector} severity={rule.status === 'GO' ? 'success' : 'warning'} sx={{ mb: 1 }}>
                        <strong>{rule.label}</strong>: {rule.rule} Kill switch: {rule.kill_switch}
                      </Alert>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            )}
          </Grid>
        )}

        <Grid container spacing={3}>
          {cards.map((card) => (
            <Grid item xs={12} md={4} key={card.sector}>
              <Card sx={{ height: '100%' }}>
                <CardHeader
                  title={card.label}
                  subheader={card.scoreLabel}
                  avatar={card.icon}
                  action={<Chip label={`${card.readiness.answer_precision_pct}% dati`} color={card.readiness.can_answer_precisely ? 'success' : 'warning'} />}
                />
                <CardContent>
                  <Typography color="textSecondary">{card.keyMetricLabel}</Typography>
                  <Typography variant="h5" sx={{ fontWeight: 800, mb: 2 }}>
                    {typeof card.keyMetric === 'number' && card.keyMetricLabel?.toLowerCase().includes('eur')
                      ? formatCurrency(card.keyMetric)
                      : card.keyMetric}
                  </Typography>
                  <Typography sx={{ fontWeight: 800, mb: 1 }}>Rischio</Typography>
                  <Typography variant="body2" sx={{ mb: 2 }}>{card.risk}</Typography>
                  <Typography sx={{ fontWeight: 800, mb: 1 }}>Opportunità</Typography>
                  <Typography variant="body2" sx={{ mb: 2 }}>{card.opportunity}</Typography>
                  <Typography sx={{ fontWeight: 800, mb: 1 }}>Prossima azione</Typography>
                  <Typography variant="body2">{card.action}</Typography>
                  {card.playbook && (
                    <Box sx={{ mt: 2 }}>
                      <Typography sx={{ fontWeight: 800, mb: 1 }}>Playbook CFO</Typography>
                      <Typography variant="body2" sx={{ mb: 1 }}>
                        {card.playbook.decision}
                      </Typography>
                      <Typography variant="body2" color="textSecondary">
                        Owner: {card.playbook.owner}
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Layout>
  );
}

export default WarRoomPage;
