import React, { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Container,
  Grid,
  LinearProgress,
  Paper,
  Typography,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import RefreshIcon from '@mui/icons-material/Refresh';
import BoltIcon from '@mui/icons-material/Bolt';
import ShieldOutlinedIcon from '@mui/icons-material/ShieldOutlined';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';
import KPICard from './components/KPICard';
import TrendChart from './components/TrendChart';
import DataInputWizard from './components/DataInputWizard';

const MONTHS = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];

const INDUSTRY_MAP = {
  Technology: 'saas',
  Finanza: 'services',
  Healthcare: 'services',
  Retail: 'retail',
  Manufacturing: 'manufacturing',
  Energia: 'services',
  Telecomunicazioni: 'saas',
  Altro: 'default',
};

const toNumber = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const normalizeCompanyData = (data = {}) => ({
  company_name: data.company_name || 'My Company',
  fatturato: toNumber(data.fatturato ?? data.revenue, 1000000),
  costi_variabili: toNumber(data.costi_variabili ?? data.cogs, 400000),
  costi_fissi: toNumber(data.costi_fissi ?? data.opex, 300000),
  investimenti: toNumber(data.investimenti, 100000),
  settore: INDUSTRY_MAP[data.industry] || data.settore || 'default',
  dso_days: toNumber(data.dso_days, 30),
  dio_days: toNumber(data.dio_days, 45),
  dpo_days: toNumber(data.dpo_days, 30),
  target_profit_margin: toNumber(data.target_profit_margin, 20),
  target_growth_rate: toNumber(data.target_growth_rate, 15),
  debt_ratio: toNumber(data.debt_ratio, 30),
  country: data.country || 'Italia',
});

const eur = (value = 0) => {
  const number = Number(value) || 0;
  if (Math.abs(number) >= 1000000) return `€${(number / 1000000).toFixed(2)}M`;
  if (Math.abs(number) >= 1000) return `€${(number / 1000).toFixed(0)}K`;
  return `€${number.toFixed(0)}`;
};

const getApiErrorMessage = (err, fallback) => {
  const detail = err.response?.data?.detail;
  if (Array.isArray(detail)) return detail.map((item) => item.msg || JSON.stringify(item)).join(' | ');
  if (typeof detail === 'string') return detail;
  return err.message || fallback;
};

const buildTrendData = (data, kpiSnapshot = {}) => {
  const revenue = toNumber(data?.fatturato, 1000000);
  const growthRate = toNumber(data?.target_growth_rate, 12) / 100;
  const netMargin = toNumber(kpiSnapshot.net_margin_pct, 15) / 100;
  const startRevenue = revenue / (1 + Math.max(growthRate, -0.8));

  return MONTHS.map((month, index) => {
    const progress = index / (MONTHS.length - 1);
    const monthlyRevenue = startRevenue + ((revenue - startRevenue) * progress);
    return {
      month,
      revenue: Math.round(monthlyRevenue),
      profit: Math.round(monthlyRevenue * netMargin),
    };
  });
};

const costBreakdown = (companyData = {}) => {
  const variable = toNumber(companyData.costi_variabili, 400000);
  const fixed = toNumber(companyData.costi_fissi, 300000);
  const total = Math.max(variable + fixed, 1);
  return [
    ['Variabili', variable, '#35c6b6'],
    ['Fissi', fixed, '#7aa7ff'],
    ['Investimenti', toNumber(companyData.investimenti, 100000), '#4caf50'],
  ].map(([label, value, color]) => ({ label, value, color, pct: Math.round((value / total) * 100) }));
};

function DashboardPage() {
  const { companyData, updateCompanyData, currentAnalysis, saveAnalysis } = useCompany();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showWizard, setShowWizard] = useState(false);
  const [trends, setTrends] = useState(null);
  const [cfoBrief, setCfoBrief] = useState(null);

  useEffect(() => {
    if (companyData && !currentAnalysis) {
      handleAnalyze();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFetchTrends = async (sourceData = companyData) => {
    try {
      const response = await cfoApi.trends(sourceData?.company_name || 'default');
      setTrends(response.data);
    } catch (err) {
      setTrends(null);
    }
  };

  const handleAnalyze = async (sourceData = companyData) => {
    setLoading(true);
    setError('');
    try {
      const payload = normalizeCompanyData(sourceData);
      if (payload.costi_variabili >= payload.fatturato) {
        throw new Error('I costi variabili devono essere inferiori al fatturato.');
      }
      const response = await cfoApi.aiAnalyze(payload, 'Qual è la prossima decisione CFO?', true);
      setCfoBrief(response.data);
      saveAnalysis(response.data.base_analysis, payload);
      await handleFetchTrends(payload);
    } catch (err) {
      setError(getApiErrorMessage(err, 'Analysis failed'));
    } finally {
      setLoading(false);
    }
  };

  const handleWizardSubmit = async (formData) => {
    setLoading(true);
    try {
      const normalizedData = normalizeCompanyData(formData);
      updateCompanyData(normalizedData);
      setShowWizard(false);
      await handleAnalyze(normalizedData);
    } catch (err) {
      setError('Failed to update company data');
    } finally {
      setLoading(false);
    }
  };

  if (showWizard) {
    return (
      <Layout>
        <Container maxWidth="md">
          <Button variant="text" onClick={() => setShowWizard(false)} sx={{ mb: 2 }}>
            Torna alla dashboard
          </Button>
          <Typography variant="h4" sx={{ fontWeight: 900, mb: 3 }}>
            Aggiorna dati aziendali
          </Typography>
          <DataInputWizard onSubmit={handleWizardSubmit} loading={loading} />
        </Container>
      </Layout>
    );
  }

  const kpiSnapshot = currentAnalysis?.kpi_snapshot || {};
  const insight = cfoBrief?.industry_insight;
  const primaryConstraint = insight?.primary_constraint;
  const nextMove = insight?.next_best_move;
  const validation = cfoBrief?.answer_validation;
  const warRoom = cfoBrief?.war_room;
  const finalDecision = warRoom?.final_decision;
  const trendData = buildTrendData(companyData, kpiSnapshot);
  const netProfit = (companyData?.fatturato || 0) - (companyData?.costi_variabili || 0) - (companyData?.costi_fissi || 0);
  const ebitda = kpiSnapshot.ebitda_eur ?? netProfit;
  const grossMargin = kpiSnapshot.gross_margin_pct ?? (((companyData?.fatturato || 1) - (companyData?.costi_variabili || 0)) / (companyData?.fatturato || 1)) * 100;
  const netMargin = kpiSnapshot.net_margin_pct ?? (netProfit / (companyData?.fatturato || 1)) * 100;

  return (
    <Layout>
      <Container maxWidth="xl">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Chip
              label="Executive financial cockpit"
              sx={{
                mb: 2,
                borderRadius: 1,
                color: '#9ff0e7',
                backgroundColor: 'rgba(53,198,182,0.1)',
                border: '1px solid rgba(53,198,182,0.2)',
              }}
            />
            <Typography variant="h3" sx={{ fontWeight: 900, letterSpacing: 0, mb: 1 }}>
              Dashboard CFO
            </Typography>
            <Typography color="text.secondary">
              {companyData?.company_name || 'Company'} · {companyData?.settore || 'default'} · ultimo aggiornamento live
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
            <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => handleAnalyze()} disabled={loading}>
              Aggiorna analisi
            </Button>
            <Button variant="contained" startIcon={<EditIcon />} onClick={() => setShowWizard(true)}>
              Modifica dati
            </Button>
          </Box>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Grid container spacing={2.5} sx={{ mb: 3 }}>
              <Grid item xs={12} sm={6} lg={3}>
                <KPICard title="Fatturato" value={eur(companyData?.fatturato)} trend={trends?.revenue_trend?.change_pct ?? 12.5} trendLabel="vs prec." color="primary" />
              </Grid>
              <Grid item xs={12} sm={6} lg={3}>
                <KPICard title="Utile netto" value={eur(netProfit)} trend={trends?.net_margin_trend?.change_pct ?? 8.7} trendLabel="vs prec." color="success" />
              </Grid>
              <Grid item xs={12} sm={6} lg={3}>
                <KPICard title="EBITDA" value={eur(ebitda)} trend={5.3} trendLabel="vs prec." color="primary" />
              </Grid>
              <Grid item xs={12} sm={6} lg={3}>
                <KPICard title="Margine netto" value={`${netMargin.toFixed(1)}%`} trend={netMargin >= 20 ? 3.1 : -1.4} trendLabel="vs target" color={netMargin >= 20 ? 'success' : 'warning'} />
              </Grid>
            </Grid>

            <Grid container spacing={2.5} sx={{ mb: 3 }}>
              <Grid item xs={12} lg={8}>
                <Card sx={{ height: '100%', background: 'linear-gradient(180deg, rgba(255,255,255,0.045), rgba(255,255,255,0.012))' }}>
                  <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 2 }}>
                      <Box>
                        <Typography variant="overline" sx={{ color: '#35c6b6', fontWeight: 900 }}>
                          CFO Brief
                        </Typography>
                        <Typography variant="h5" sx={{ fontWeight: 900 }}>
                          {insight?.health_label || cfoBrief?.base_analysis?.headline || 'Analisi pronta'}
                        </Typography>
                      </Box>
                      <Chip
                        label={validation?.response_source || 'deterministic'}
                        color={validation?.is_valid === false ? 'warning' : 'success'}
                        sx={{ borderRadius: 1 }}
                      />
                    </Box>
                    <Typography color="text.secondary" sx={{ maxWidth: 900, lineHeight: 1.8 }}>
                      {primaryConstraint?.summary || cfoBrief?.base_analysis?.summary || 'Aggiorna i dati per generare una diagnosi CFO completa.'}
                    </Typography>
                    <Grid container spacing={2} sx={{ mt: 2 }}>
                      {[
                        ['Vincolo principale', primaryConstraint?.type || 'Da verificare', primaryConstraint?.risk_window || 'Risk window n/d'],
                        ['Next move', nextMove?.move || cfoBrief?.ai_response?.priority_action || 'Completa analisi', nextMove?.supporting_action || 'Azione collegata al vincolo'],
                        ['Decisione War Room', finalDecision?.action || 'In attesa', finalDecision?.why || 'Ordina le priorità per impatto e rischio'],
                      ].map(([title, value, subtitle]) => (
                        <Grid item xs={12} md={4} key={title}>
                          <Box sx={{ p: 2, borderRadius: 1, backgroundColor: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.07)', height: '100%' }}>
                            <Typography variant="caption" color="text.secondary">{title}</Typography>
                            <Typography sx={{ fontWeight: 900, mt: 0.7 }}>{value}</Typography>
                            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.7 }}>{subtitle}</Typography>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} lg={4}>
                <Card sx={{ height: '100%' }}>
                  <CardContent sx={{ p: 3 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                      <BoltIcon sx={{ color: '#35c6b6' }} />
                      <Typography variant="h6" sx={{ fontWeight: 900 }}>Decision quality</Typography>
                    </Box>
                    <Typography variant="h3" sx={{ fontWeight: 900, mb: 1 }}>
                      {warRoom?.business_quality_score || 72}/100
                    </Typography>
                    <Typography color="text.secondary" sx={{ mb: 2 }}>
                      Punteggio CFO su margine, cassa, rischio e qualità dei dati.
                    </Typography>
                    {Object.entries(warRoom?.score_breakdown || { margin: 16, cash: 13, growth: 15, risk: 14 }).map(([key, value]) => (
                      <Box key={key} sx={{ mb: 1.6 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.6 }}>
                          <Typography variant="body2" color="text.secondary">{key.replaceAll('_', ' ')}</Typography>
                          <Typography variant="body2" sx={{ fontWeight: 800 }}>{value}/20</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={(Number(value) / 20) * 100}
                          sx={{ height: 7, borderRadius: 1, backgroundColor: 'rgba(255,255,255,0.08)' }}
                        />
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Grid container spacing={2.5} sx={{ mb: 3 }}>
              <Grid item xs={12} lg={8}>
                <TrendChart data={trendData} title="Fatturato vs utile operativo" />
              </Grid>
              <Grid item xs={12} lg={4}>
                <Card sx={{ height: '100%' }}>
                  <CardContent sx={{ p: 3 }}>
                    <Typography variant="h6" sx={{ fontWeight: 900, mb: 3 }}>
                      Ripartizione economica
                    </Typography>
                    {costBreakdown(companyData).map((item) => (
                      <Box key={item.label} sx={{ mb: 2.2 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.7 }}>
                          <Typography color="text.secondary">{item.label}</Typography>
                          <Typography sx={{ fontWeight: 900 }}>{eur(item.value)}</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={Math.min(item.pct, 100)}
                          sx={{
                            height: 10,
                            borderRadius: 1,
                            backgroundColor: 'rgba(255,255,255,0.08)',
                            '& .MuiLinearProgress-bar': { backgroundColor: item.color },
                          }}
                        />
                      </Box>
                    ))}
                    <Box sx={{ mt: 3, p: 2, borderRadius: 1, backgroundColor: 'rgba(53,198,182,0.08)', border: '1px solid rgba(53,198,182,0.18)' }}>
                      <Typography variant="body2" sx={{ fontWeight: 800, mb: 0.5 }}>
                        Margine lordo {grossMargin.toFixed(1)}%
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Proteggi questo indicatore prima di spingere nuova crescita.
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Paper sx={{ p: 3, border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(16,19,19,0.72)' }}>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} md={8}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, mb: 1 }}>
                    <ShieldOutlinedIcon sx={{ color: '#35c6b6' }} />
                    <Typography variant="h6" sx={{ fontWeight: 900 }}>Insight CFO verificabile</Typography>
                  </Box>
                  <Typography color="text.secondary">
                    Le risposte della chat includono qualità, confidenza, fonti e dati mancanti. Questo riduce risposte casuali e rende la consulenza più difendibile.
                  </Typography>
                </Grid>
                <Grid item xs={12} md={4} sx={{ display: 'flex', justifyContent: { xs: 'flex-start', md: 'flex-end' }, gap: 1, flexWrap: 'wrap' }}>
                  <Button variant="outlined">Scarica report</Button>
                  <Button variant="contained">Apri War Room</Button>
                </Grid>
              </Grid>
            </Paper>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default DashboardPage;
