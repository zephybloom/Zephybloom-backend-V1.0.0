import React, { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  CircularProgress,
  Container,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import AddIcon from '@mui/icons-material/Add';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import Layout from '../components/Layout';
import { cfoApi } from '../services/api';

const DEFAULT_ROWS = [
  {
    customer: 'Cliente A',
    product: 'Premium Pack',
    supplier: 'Supplier 1',
    quantity: 10,
    unit_price: 500,
    purchase_price: 180,
    discounts: 0,
    commissions: 100,
    logistics_cost: 0,
  },
  {
    customer: 'Cliente B',
    product: 'Low Margin Pack',
    supplier: 'Supplier 2',
    quantity: 20,
    unit_price: 100,
    purchase_price: 85,
    discounts: 0,
    commissions: 0,
    logistics_cost: 200,
  },
];

const COLUMNS = [
  'customer',
  'product',
  'supplier',
  'quantity',
  'unit_price',
  'purchase_price',
  'discounts',
  'commissions',
  'logistics_cost',
];

const NUMERIC_COLUMNS = new Set([
  'quantity',
  'unit_price',
  'purchase_price',
  'discounts',
  'commissions',
  'logistics_cost',
]);

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

const parseCsv = (text) => {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map((header) => header.trim());
  return lines.slice(1).map((line) => {
    const values = line.split(',').map((value) => value.trim());
    return headers.reduce((acc, header, index) => {
      acc[header] = NUMERIC_COLUMNS.has(header) ? Number(values[index] || 0) : values[index] || '';
      return acc;
    }, {});
  });
};

function UnitEconomicsPage() {
  const [rows, setRows] = useState(DEFAULT_ROWS);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const totals = analysis?.unit_economics?.totals;
  const requiredColumns = useMemo(() => COLUMNS.join(', '), []);

  const updateRow = (index, field, value) => {
    setRows((prev) =>
      prev.map((row, rowIndex) =>
        rowIndex === index
          ? { ...row, [field]: NUMERIC_COLUMNS.has(field) ? Number(value || 0) : value }
          : row
      )
    );
  };

  const addRow = () => {
    setRows((prev) => [
      ...prev,
      {
        customer: '',
        product: '',
        supplier: '',
        quantity: 1,
        unit_price: 0,
        purchase_price: 0,
        discounts: 0,
        commissions: 0,
        logistics_cost: 0,
      },
    ]);
  };

  const handleCsvUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const text = await file.text();
    const parsed = parseCsv(text);
    if (!parsed.length) {
      setError('CSV non valido. Inserisci header e almeno una riga.');
      return;
    }
    setRows(parsed);
    setError('');
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.unitEconomics(rows);
      setAnalysis(response.data);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const renderRanking = (title, items, nameKey) => (
    <Card sx={{ height: '100%' }}>
      <CardHeader title={title} />
      <CardContent>
        {(items || []).slice(0, 5).map((item, index) => (
          <Box key={`${title}-${index}`} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
            <Typography sx={{ fontWeight: 800 }}>
              {index + 1}. {item[nameKey]}
            </Typography>
            <Typography variant="body2" color="textSecondary">
              Margine {item.gross_margin_pct}% | Utile {formatCurrency(item.profit_eur)}
            </Typography>
          </Box>
        ))}
        {(!items || items.length === 0) && (
          <Typography variant="body2" color="textSecondary">
            Nessun dato disponibile.
          </Typography>
        )}
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>
              Unit Economics
            </Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Carica clienti, prodotti, fornitori e costi unitari per trovare dove nasce il margine.
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Button component="label" variant="outlined" startIcon={<UploadFileIcon />}>
              Import CSV
              <input hidden accept=".csv,text/csv" type="file" onChange={handleCsvUpload} />
            </Button>
            <Button variant="outlined" startIcon={<AddIcon />} onClick={addRow}>
              Riga
            </Button>
            <Button variant="contained" startIcon={<AnalyticsIcon />} onClick={handleAnalyze} disabled={loading}>
              {loading ? <CircularProgress size={22} /> : 'Analizza'}
            </Button>
          </Box>
        </Box>

        <Alert severity="info" sx={{ mb: 3 }}>
          CSV richiesto: {requiredColumns}
        </Alert>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        <Card sx={{ mb: 4 }}>
          <CardHeader title="Dati granulari" subheader="Modifica le righe o importa un CSV con gli stessi header." />
          <CardContent>
            <TableContainer component={Paper}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {COLUMNS.map((column) => (
                      <TableCell key={column}>{column}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, rowIndex) => (
                    <TableRow key={rowIndex}>
                      {COLUMNS.map((column) => (
                        <TableCell key={column} sx={{ minWidth: NUMERIC_COLUMNS.has(column) ? 110 : 160 }}>
                          <TextField
                            value={row[column] ?? ''}
                            type={NUMERIC_COLUMNS.has(column) ? 'number' : 'text'}
                            size="small"
                            fullWidth
                            onChange={(event) => updateRow(rowIndex, column, event.target.value)}
                          />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>

        {analysis && (
          <>
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Ricavi analizzati</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{formatCurrency(totals?.revenue_eur)}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Utile contributivo</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{formatCurrency(totals?.profit_eur)}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Margine lordo</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{totals?.gross_margin_pct}%</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Righe</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{analysis.row_count}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={4}>
                {renderRanking('Top prodotti per margine', analysis.unit_economics.top_products_by_margin, 'product')}
              </Grid>
              <Grid item xs={12} md={4}>
                {renderRanking('Top clienti per utile', analysis.unit_economics.top_customers_by_profit, 'customer')}
              </Grid>
              <Grid item xs={12} md={4}>
                {renderRanking('Prodotti da correggere', analysis.unit_economics.products_to_fix, 'product')}
              </Grid>
            </Grid>

            <Card>
              <CardHeader title="Raccomandazioni CFO" />
              <CardContent>
                {(analysis.unit_economics.recommendations || []).map((recommendation, index) => (
                  <Typography key={recommendation} sx={{ mb: 1 }}>
                    {index + 1}. {recommendation}
                  </Typography>
                ))}
              </CardContent>
            </Card>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default UnitEconomicsPage;
