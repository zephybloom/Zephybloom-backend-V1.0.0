import React, { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Chip,
  CircularProgress,
  Container,
  Grid,
  TextField,
  Typography,
} from '@mui/material';
import StorageIcon from '@mui/icons-material/Storage';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

function DataRoomPage() {
  const { companyData, updateCompanyData, operationalDataBySector, saveOperationalData } = useCompany();
  const [dataRoom, setDataRoom] = useState(null);
  const [activeStepId, setActiveStepId] = useState(null);
  const [fieldValues, setFieldValues] = useState({});
  const [structuredValues, setStructuredValues] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [historySummary, setHistorySummary] = useState(null);
  const [importEntity, setImportEntity] = useState('sku_sales');
  const [importRowsJson, setImportRowsJson] = useState('[{"sku":"Hero","price":75,"purchase_cost":24,"monthly_units":500}]');

  const companyId = companyData.company_name || 'default';

  const applySnapshot = (snapshot) => {
    if (!snapshot) return;
    if (snapshot.company_data) {
      updateCompanyData(snapshot.company_data);
    }
    Object.entries(snapshot.operational_data_by_sector || {}).forEach(([sector, data]) => {
      saveOperationalData(sector, data);
    });
  };

  const buildDataRoom = async (
    companyPayload = companyData,
    operationalPayload = operationalDataBySector,
    save = false
  ) => {
    const response = await cfoApi.dataRoom(companyPayload, operationalPayload, companyPayload.settore, {
      companyId,
      save,
    });
    const nextDataRoom = response.data.data_room;
    applySnapshot(response.data.snapshot);
    setDataRoom(nextDataRoom);
    setActiveStepId(nextDataRoom.guided_collection?.first_step?.step_id || null);
    setFieldValues({});
    setStructuredValues({});
    await loadDataRoomHistory();
    return nextDataRoom;
  };

  const loadDataRoomHistory = async () => {
    try {
      const response = await cfoApi.dataRoomHistory(companyId);
      setHistorySummary(response.data.history_summary);
    } catch (err) {
      setHistorySummary(null);
    }
  };

  useEffect(() => {
    const loadSavedDataRoom = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await cfoApi.getDataRoom(companyId);
        applySnapshot(response.data.snapshot);
        setDataRoom(response.data.data_room);
        setActiveStepId(response.data.data_room.guided_collection?.first_step?.step_id || null);
        await loadDataRoomHistory();
        setMessage('Data Room salvata caricata.');
      } catch (err) {
        if (err.response?.status !== 404) {
          setError(err.response?.data?.detail || err.message);
        }
        await loadDataRoomHistory();
      } finally {
        setLoading(false);
      }
    };
    loadSavedDataRoom();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  const guidedSteps = dataRoom?.guided_collection?.steps || [];
  const activeStep = guidedSteps.find((step) => step.step_id === activeStepId) || dataRoom?.guided_collection?.first_step;

  const fieldColumns = (field) => {
    if (Array.isArray(field.example) && field.example[0] && typeof field.example[0] === 'object') {
      return Object.keys(field.example[0]);
    }
    if (field.example && typeof field.example === 'object' && !Array.isArray(field.example)) {
      return Object.keys(field.example);
    }
    return ['name', 'value'];
  };

  const ensureStructuredRows = (field) => {
    const current = structuredValues[field.key];
    if (current) return current;
    if (field.type === 'object') {
      const example = field.example && typeof field.example === 'object' && !Array.isArray(field.example) ? field.example : {};
      const rows = Object.keys(example).length
        ? Object.entries(example).map(([key, value]) => ({ key, value: String(value ?? '') }))
        : [{ key: '', value: '' }];
      return rows;
    }
    const columns = fieldColumns(field);
    return [{ ...Object.fromEntries(columns.map((column) => [column, ''])) }];
  };

  const updateStructuredCell = (field, rowIndex, column, value) => {
    setStructuredValues((prev) => {
      const rows = [...ensureStructuredRows(field)];
      rows[rowIndex] = { ...rows[rowIndex], [column]: value };
      return { ...prev, [field.key]: rows };
    });
  };

  const addStructuredRow = (field) => {
    setStructuredValues((prev) => {
      const rows = [...ensureStructuredRows(field)];
      if (field.type === 'object') {
        rows.push({ key: '', value: '' });
      } else {
        rows.push({ ...Object.fromEntries(fieldColumns(field).map((column) => [column, ''])) });
      }
      return { ...prev, [field.key]: rows };
    });
  };

  const removeStructuredRow = (field, rowIndex) => {
    setStructuredValues((prev) => {
      const rows = ensureStructuredRows(field).filter((_, index) => index !== rowIndex);
      const fallback = field.type === 'object'
        ? [{ key: '', value: '' }]
        : [{ ...Object.fromEntries(fieldColumns(field).map((column) => [column, ''])) }];
      return { ...prev, [field.key]: rows.length ? rows : fallback };
    });
  };

  const handleBuild = async () => {
    setLoading(true);
    setError('');
    setMessage('');
    try {
      await buildDataRoom(companyData, operationalDataBySector, false);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const parseFieldValue = (field, rawValue) => {
    if (rawValue === '') return undefined;
    if (field.type === 'number') {
      const value = Number(rawValue);
      if (!Number.isFinite(value)) {
        throw new Error(`${field.label}: inserisci un numero valido.`);
      }
      return value;
    }
    if (['table', 'object', 'list'].includes(field.type)) {
      if (Array.isArray(rawValue) && field.type === 'object') {
        return rawValue.reduce((acc, row) => {
          if (row.key) {
            acc[row.key] = parseScalar(row.value);
          }
          return acc;
        }, {});
      }
      if (Array.isArray(rawValue)) {
        return rawValue
          .map((row) => Object.fromEntries(
            Object.entries(row)
              .filter(([, value]) => value !== '')
              .map(([key, value]) => [key, parseScalar(value)])
          ))
          .filter((row) => Object.keys(row).length > 0);
      }
      try {
        return JSON.parse(rawValue);
      } catch (err) {
        throw new Error(`${field.label}: inserisci JSON valido.`);
      }
    }
    return rawValue;
  };

  const parseScalar = (value) => {
    if (value === '' || value === undefined || value === null) return value;
    const numeric = Number(value);
    return Number.isFinite(numeric) && String(value).trim() !== '' ? numeric : value;
  };

  const handleFieldChange = (key, value) => {
    setFieldValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveActiveStep = async () => {
    const step = activeStep;
    if (!step) return;
    setSaving(true);
    setError('');
    setMessage('');
    try {
      const patch = {};
      (step.fields || []).forEach((field) => {
        const structured = structuredValues[field.key];
        const raw = structured || fieldValues[field.key];
        if (raw !== undefined && raw !== '' && !(Array.isArray(raw) && raw.length === 0)) {
          patch[field.key] = parseFieldValue(field, raw);
        }
      });
      if (Object.keys(patch).length === 0) {
        throw new Error('Inserisci almeno un valore prima di salvare.');
      }

      let nextCompanyData = companyData;
      let nextOperationalData = operationalDataBySector;
      if (step.destination === 'company_data') {
        nextCompanyData = { ...companyData, ...patch };
        updateCompanyData(patch);
      } else if (step.destination?.startsWith('operational_data_by_sector.')) {
        const sector = step.destination.split('.').pop();
        const currentSectorData = operationalDataBySector[sector] || {};
        const mergedSectorData = { ...currentSectorData, ...patch };
        nextOperationalData = {
          ...operationalDataBySector,
          [sector]: mergedSectorData,
        };
        saveOperationalData(sector, mergedSectorData);
      } else {
        throw new Error(`Destinazione non supportata: ${step.destination}`);
      }

      await buildDataRoom(nextCompanyData, nextOperationalData, true);
      setMessage(`Dati salvati: ${step.label}. Readiness aggiornata.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleImportRows = async () => {
    setSaving(true);
    setError('');
    setMessage('');
    try {
      const rows = JSON.parse(importRowsJson);
      if (!Array.isArray(rows) || rows.length === 0) {
        throw new Error('Inserisci un array JSON con almeno una riga.');
      }
      const activeSector = companyData.settore || dataRoom?.active_sector || 'default';
      const response = await cfoApi.importDataRoomRows({
        company_id: companyId,
        company_name: companyData.company_name || 'Azienda',
        active_sector: activeSector,
        entity: importEntity,
        rows,
      });
      applySnapshot(response.data.snapshot);
      setDataRoom(response.data.data_room);
      await loadDataRoomHistory();
      setMessage(`Import completato: ${rows.length} righe in ${importEntity}.`);
    } catch (err) {
      setError(err.response?.data?.detail || err.message);
    } finally {
      setSaving(false);
    }
  };

  const renderStructuredEditor = (field) => {
    if (!['table', 'object', 'list'].includes(field.type)) return null;
    const rows = ensureStructuredRows(field);
    if (field.type === 'object') {
      return (
        <Box sx={{ mt: 2 }}>
          {rows.map((row, index) => (
            <Grid container spacing={1} key={`${field.key}-${index}`} sx={{ mb: 1 }}>
              <Grid item xs={5}>
                <TextField
                  label="Chiave"
                  value={row.key || ''}
                  onChange={(event) => updateStructuredCell(field, index, 'key', event.target.value)}
                  fullWidth
                  size="small"
                />
              </Grid>
              <Grid item xs={5}>
                <TextField
                  label="Valore"
                  value={row.value || ''}
                  onChange={(event) => updateStructuredCell(field, index, 'value', event.target.value)}
                  fullWidth
                  size="small"
                />
              </Grid>
              <Grid item xs={2}>
                <Button size="small" color="warning" onClick={() => removeStructuredRow(field, index)}>
                  Rimuovi
                </Button>
              </Grid>
            </Grid>
          ))}
          <Button size="small" onClick={() => addStructuredRow(field)}>Aggiungi riga</Button>
        </Box>
      );
    }

    const columns = fieldColumns(field);
    return (
      <Box sx={{ mt: 2 }}>
        {rows.map((row, index) => (
          <Box key={`${field.key}-${index}`} sx={{ mb: 2, p: 1, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
            <Grid container spacing={1}>
              {columns.map((column) => (
                <Grid item xs={12} sm={6} key={column}>
                  <TextField
                    label={column}
                    value={row[column] || ''}
                    onChange={(event) => updateStructuredCell(field, index, column, event.target.value)}
                    fullWidth
                    size="small"
                  />
                </Grid>
              ))}
            </Grid>
            <Button size="small" color="warning" sx={{ mt: 1 }} onClick={() => removeStructuredRow(field, index)}>
              Rimuovi riga
            </Button>
          </Box>
        ))}
        <Button size="small" onClick={() => addStructuredRow(field)}>Aggiungi riga</Button>
      </Box>
    );
  };

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>
              CFO Data Room
            </Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Dati aziendali, gap prioritari e domande operative per rendere il CFO AI preciso.
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<StorageIcon />} onClick={handleBuild} disabled={loading}>
            {loading ? <CircularProgress size={22} /> : 'Analizza Data Room'}
          </Button>
          <Button
            variant="outlined"
            onClick={async () => {
              setLoading(true);
              setError('');
              setMessage('');
              try {
                await buildDataRoom(companyData, operationalDataBySector, true);
                setMessage('Data Room salvata nel profilo azienda.');
              } catch (err) {
                setError(err.response?.data?.detail || err.message);
              } finally {
                setLoading(false);
              }
            }}
            disabled={loading}
          >
            Salva Data Room
          </Button>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}
        {message && <Alert severity="success" sx={{ mb: 3 }} onClose={() => setMessage('')}>{message}</Alert>}

        {!dataRoom && (
          <Alert severity="info" sx={{ mb: 4 }}>
            La Data Room usa i dati aziendali salvati e i verticali Restaurant, Ecommerce, Construction o Hotel.
          </Alert>
        )}

        {dataRoom && (
          <>
            <Grid container spacing={2} sx={{ mb: 4 }}>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Readiness CFO</Typography>
                    <Typography variant="h4" sx={{ fontWeight: 800 }}>{dataRoom.readiness_score_pct}%</Typography>
                    <Chip label={dataRoom.readiness_level} size="small" sx={{ mt: 1 }} />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Settore attivo</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{dataRoom.active_sector}</Typography>
                    <Typography variant="body2">Copertura verticale: {dataRoom.sector_entities?.coverage_pct || 0}%</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Gap prioritari</Typography>
                    <Typography variant="h5" sx={{ fontWeight: 800 }}>{(dataRoom.priority_gaps || []).length}</Typography>
                    <Typography variant="body2">Da chiudere prima di scalare la logica CFO.</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="Domande CFO da fare ora" />
              <CardContent>
                {(dataRoom.next_questions || []).map((question) => (
                  <Typography key={question} sx={{ mb: 1 }}>- {question}</Typography>
                ))}
              </CardContent>
            </Card>

            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Import veloce" subheader="Incolla righe JSON da CSV/Excel convertito" />
                  <CardContent>
                    <TextField
                      label="Entità"
                      value={importEntity}
                      onChange={(event) => setImportEntity(event.target.value)}
                      fullWidth
                      size="small"
                      helperText="sku_sales, suppliers, staff_roles, sales_channels, projects, menu_items"
                      sx={{ mb: 2 }}
                    />
                    <TextField
                      label="Righe JSON"
                      value={importRowsJson}
                      onChange={(event) => setImportRowsJson(event.target.value)}
                      fullWidth
                      multiline
                      minRows={5}
                      sx={{ mb: 2 }}
                    />
                    <Button variant="contained" onClick={handleImportRows} disabled={saving}>
                      {saving ? <CircularProgress size={20} /> : 'Importa righe'}
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Storico Data Room" subheader="Ultimo cambiamento salvato" />
                  <CardContent>
                    {historySummary?.has_history ? (
                      <>
                        <Typography sx={{ mb: 1 }}>{historySummary.cfo_comment}</Typography>
                        <Grid container spacing={1}>
                          <Grid item xs={4}>
                            <Typography color="textSecondary">Readiness</Typography>
                            <Typography sx={{ fontWeight: 800 }}>
                              {historySummary.latest?.readiness_score_pct ?? 0}%
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography color="textSecondary">Delta righe</Typography>
                            <Typography sx={{ fontWeight: 800 }}>
                              {historySummary.delta?.row_count ?? 0}
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography color="textSecondary">Versioni</Typography>
                            <Typography sx={{ fontWeight: 800 }}>{historySummary.snapshot_count}</Typography>
                          </Grid>
                        </Grid>
                        <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                          Ultimo salvataggio: {historySummary.latest?.created_at || 'n/d'}
                        </Typography>
                      </>
                    ) : (
                      <Typography color="textSecondary">
                        Salva o importa dati per iniziare a confrontare le versioni della Data Room.
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {activeStep && (
              <Card sx={{ mb: 4 }}>
                <CardHeader
                  title="Raccolta guidata"
                  subheader={activeStep.why}
                />
                <CardContent>
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 3 }}>
                    {guidedSteps.map((step, index) => (
                      <Chip
                        key={step.step_id}
                        label={`${index + 1}. ${step.label}`}
                        color={step.step_id === activeStep.step_id ? 'primary' : 'default'}
                        onClick={() => {
                          setActiveStepId(step.step_id);
                          setFieldValues({});
                          setStructuredValues({});
                        }}
                      />
                    ))}
                  </Box>
                  <Typography sx={{ fontWeight: 800, mb: 2 }}>
                    Step attivo: {activeStep.label}
                  </Typography>
                  <Grid container spacing={2}>
                    {(activeStep.fields || []).map((field) => (
                      <Grid item xs={12} md={6} key={field.key}>
                        <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 2, height: '100%' }}>
                          <Typography sx={{ fontWeight: 800 }}>{field.label}</Typography>
                          <Typography variant="body2" color="textSecondary">
                            Tipo: {field.type}{field.unit ? ` | Unità: ${field.unit}` : ''}
                          </Typography>
                          <Typography variant="body2" sx={{ mt: 1 }}>
                            Esempio: {typeof field.example === 'object' ? JSON.stringify(field.example) : String(field.example || 'n/d')}
                          </Typography>
                          <Chip label={field.destination} size="small" sx={{ mt: 1 }} />
                          {['table', 'object', 'list'].includes(field.type) ? (
                            renderStructuredEditor(field)
                          ) : (
                            <TextField
                              label="Valore"
                              value={fieldValues[field.key] ?? ''}
                              onChange={(event) => handleFieldChange(field.key, event.target.value)}
                              fullWidth
                              type={field.type === 'number' ? 'number' : 'text'}
                              placeholder={String(field.example || '')}
                              sx={{ mt: 2 }}
                            />
                          )}
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                  <Button variant="contained" sx={{ mt: 3 }} onClick={handleSaveActiveStep} disabled={saving}>
                    {saving ? <CircularProgress size={20} /> : 'Salva step attivo'}
                  </Button>
                </CardContent>
              </Card>
            )}

            <Grid container spacing={3} sx={{ mb: 4 }}>
              {(dataRoom.areas || []).map((area) => (
                <Grid item xs={12} md={6} key={area.area}>
                  <Card sx={{ height: '100%' }}>
                    <CardHeader
                      title={area.label}
                      subheader={area.why}
                      action={<Chip label={`${area.coverage_pct}%`} color={area.coverage_pct >= 80 ? 'success' : 'warning'} />}
                    />
                    <CardContent>
                      <Typography variant="body2" sx={{ mb: 1 }}>Stato: {area.status}</Typography>
                      <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                        Presenti: {(area.present_fields || []).join(', ') || 'nessuno'}
                      </Typography>
                      <Typography variant="body2" color="textSecondary">
                        Mancanti: {(area.missing_fields || []).slice(0, 5).join(', ') || 'nessuno'}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="Gap prioritari" subheader="Ordinati per impatto sulla precisione CFO" />
              <CardContent>
                {(dataRoom.priority_gaps || []).map((gap) => (
                  <Box key={`${gap.type}-${gap.area}`} sx={{ mb: 2, pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Chip label={gap.type} size="small" sx={{ mr: 1 }} />
                    <Typography component="span" sx={{ fontWeight: 800 }}>{gap.label}</Typography>
                    <Typography variant="body2" sx={{ mt: 0.5 }}>{gap.impact}</Typography>
                    <Typography variant="body2" color="textSecondary">
                      Mancano: {(gap.missing || []).join(', ') || 'dettaglio operativo'}
                    </Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default DataRoomPage;
