import React, { useState } from 'react';
import {
  Container,
  Card,
  CardContent,
  CardHeader,
  TextField,
  Button,
  Box,
  Typography,
  Paper,
  Alert,
  CircularProgress,
  Chip,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const toNumber = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const buildCompanyPayload = (companyData = {}) => ({
  fatturato: toNumber(companyData.fatturato, 1000000),
  costi_variabili: toNumber(companyData.costi_variabili, 400000),
  costi_fissi: toNumber(companyData.costi_fissi, 300000),
  investimenti: toNumber(companyData.investimenti, 100000),
  settore: companyData.settore || 'default',
  company_name: companyData.company_name || 'My Company',
  dso_days: toNumber(companyData.dso_days, 30),
  dio_days: toNumber(companyData.dio_days, 45),
  dpo_days: toNumber(companyData.dpo_days, 30),
});

function ChatPage() {
  const { companyData, chatHistory, addChatMessage, getOperationalData, operationalDataBySector } = useCompany();
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    const userMessage = {
      role: 'user',
      content: message,
    };
    addChatMessage(userMessage);
    setMessage('');
    setLoading(true);
    setError('');

    try {
      const companyPayload = buildCompanyPayload(companyData);
      const operationalData = getOperationalData(companyPayload.settore);
      const response = await cfoApi.chat({
        message,
        company_data: companyPayload,
        operational_data: operationalData || undefined,
        operational_data_by_sector: operationalDataBySector || undefined,
        chat_history: chatHistory.map((item) => ({
          role: item.role,
          content: item.content,
        })),
      });

      addChatMessage({
        role: 'assistant',
        content: response.data.response || 'Analisi completata.',
        answerQuality: response.data.conversation_state?.answer_quality,
      });
    } catch (err) {
      const detail = err.response?.data?.detail;
      const messageText = Array.isArray(detail)
        ? detail.map((item) => item.msg || JSON.stringify(item)).join(' | ')
        : detail || err.message || 'Chat failed';
      setError(messageText);
      addChatMessage({
        role: 'assistant',
        content: `Non riesco a completare la risposta: ${messageText}`,
      });
    } finally {
      setLoading(false);
    }
  };

  const operationalData = getOperationalData(companyData.settore);
  const quickPrompts = companyData.settore === 'restaurant' && operationalData
    ? [
        'Quali piatti hanno più margine?',
        'Se aumento i prezzi del 5% e i coperti del 10% cosa succede?',
        'Se riduco gli sprechi di 1 punto cosa cambia?',
      ]
    : companyData.settore === 'ecommerce' && operationalData
    ? [
        'Quali SKU devo spingere?',
        'Se aumento i prezzi del 5% e gli ordini del 10% cosa succede?',
        'Quanto posso spendere massimo di CAC?',
      ]
    : companyData.settore === 'construction' && operationalData
    ? [
        'Quale commessa ha più rischio cassa?',
        'Se i materiali aumentano del 10% e incasso il SAL del 15% cosa succede?',
        'Dove ho WIP non fatturato?',
      ]
    : [];

  return (
    <Layout>
      <Container maxWidth="md">
        <Typography variant="h4" sx={{ mb: 4, fontWeight: 700 }}>
          CFO Assistant Chat
        </Typography>

        {operationalData && (
          <Alert severity="success" sx={{ mb: 3 }}>
            Contesto operativo attivo per {companyData.settore}. La chat userà anche i dati salvati nelle pagine verticali.
          </Alert>
        )}

        {quickPrompts.length > 0 && (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
            {quickPrompts.map((prompt) => (
              <Button key={prompt} variant="outlined" size="small" onClick={() => setMessage(prompt)}>
                {prompt}
              </Button>
            ))}
          </Box>
        )}

        <Card sx={{ height: '600px', display: 'flex', flexDirection: 'column' }}>
          <CardHeader title="Ask Financial Questions" />
          <CardContent
            sx={{
              flex: 1,
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
            }}
          >
            {chatHistory.length === 0 ? (
              <Typography variant="body2" sx={{ color: 'text.secondary', textAlign: 'center' }}>
                Ask a question about your company's financials...
              </Typography>
            ) : (
              chatHistory.map((msg, idx) => (
                <Paper
                  key={idx}
                  sx={{
                    p: 2,
                    backgroundColor: msg.role === 'user' ? '#e3f2fd' : '#f5f5f5',
                    borderRadius: 1,
                    alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
                    maxWidth: '80%',
                  }}
                >
                  <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 1 }}>
                    {msg.role === 'user' ? 'You' : 'CFO Assistant'}
                  </Typography>
                  <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>{msg.content}</Typography>
                  {msg.answerQuality && (
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                      <Chip
                        size="small"
                        label={`Qualità: ${msg.answerQuality.quality_level}`}
                        color={msg.answerQuality.quality_level === 'high' ? 'success' : msg.answerQuality.quality_level === 'medium' ? 'warning' : 'error'}
                      />
                      <Chip size="small" label={`Confidenza: ${Math.round((msg.answerQuality.confidence_score || 0) * 100)}%`} />
                      <Chip size="small" label={msg.answerQuality.policy} />
                      {(msg.answerQuality.sources || []).slice(0, 2).map((source) => (
                        <Chip key={source.type || source.label} size="small" variant="outlined" label={source.label || source.type} />
                      ))}
                    </Box>
                  )}
                </Paper>
              ))
            )}
          </CardContent>

          {error && <Alert severity="error" sx={{ mx: 2, mb: 2 }}>{error}</Alert>}

          <Box sx={{ p: 2, borderTop: '1px solid #ddd', display: 'flex', gap: 1 }}>
            <TextField
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !loading && handleSendMessage()}
              placeholder="Ask a question..."
              fullWidth
              size="small"
              disabled={loading}
            />
            <Button
              variant="contained"
              endIcon={<SendIcon />}
              onClick={handleSendMessage}
              disabled={loading || !message.trim()}
            >
              {loading ? <CircularProgress size={24} /> : 'Send'}
            </Button>
          </Box>
        </Card>
      </Container>
    </Layout>
  );
}

export default ChatPage;
