import React from 'react';
import { Box, Card, CardContent, Typography } from '@mui/material';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const ProfitGauge = ({ current = 20, target = 25, title = 'Profit Margin' }) => {
  const data = [
    { name: 'Attuale', value: current, fill: '#00bcd4' },
    { name: 'Rimanente', value: Math.max(0, 100 - current), fill: 'rgba(0, 188, 212, 0.2)' },
  ];

  const isOnTarget = current >= target;

  return (
    <Card
      sx={{
        background: `linear-gradient(135deg, #1a1f2e 0%, #22252f 100%)`,
        border: '2px solid #00bcd4',
      }}
    >
      <CardContent>
        <Typography variant="h6" sx={{ mb: 2, color: 'textSecondary' }}>
          {title}
        </Typography>

        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={85}
              paddingAngle={0}
              dataKey="value"
              startAngle={180}
              endAngle={0}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        <Box sx={{ textAlign: 'center', mt: 2 }}>
          <Typography variant="h4" sx={{ color: '#00bcd4', fontWeight: 700 }}>
            {current}%
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Target: {target}%
          </Typography>
          <Typography
            variant="body2"
            sx={{
              color: isOnTarget ? '#4caf50' : '#ff9800',
              fontWeight: 600,
              mt: 1,
            }}
          >
            {isOnTarget ? '✓ On Target' : `⚠ ${(target - current).toFixed(1)}% away`}
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
};

export default ProfitGauge;
