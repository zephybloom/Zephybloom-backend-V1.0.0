import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const TrendChart = ({ data, title = 'Revenue Trend', dataKey = 'revenue', color = '#00bcd4' }) => {
  // Deterministic fallback: never invent random financial data.
  const chartData = data || Array.from({ length: 12 }, (_, i) => ({
    month: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'][i],
    revenue: 900000 + (i * 12000),
    profit: 120000 + (i * 5000),
  }));

  const formatValue = (value) => {
    if (value >= 1000000) return `€${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `€${(value / 1000).toFixed(0)}K`;
    return `€${value}`;
  };

  return (
    <Card
      sx={{
        background: 'linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.012))',
        border: '1px solid rgba(255,255,255,0.08)',
      }}
    >
      <CardContent>
        <Typography variant="h6" sx={{ mb: 2, color: 'textSecondary' }}>
          {title}
        </Typography>

        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={chartData}>
            <defs>
              <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#35c6b6" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#35c6b6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#4caf50" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#4caf50" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.07)" />
            <XAxis dataKey="month" stroke="#9aa6a1" />
            <YAxis stroke="#9aa6a1" tickFormatter={formatValue} width={70} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0b0d0d',
                border: '1px solid rgba(255,255,255,0.12)',
                borderRadius: '8px',
              }}
              labelStyle={{ color: '#e0e0e0' }}
              formatter={(value) => formatValue(value)}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#35c6b6"
              strokeWidth={3}
              dot={{ fill: '#35c6b6', r: 3 }}
              activeDot={{ r: 6 }}
              name="Ricavi"
            />
            <Line
              type="monotone"
              dataKey="profit"
              stroke="#4caf50"
              strokeWidth={3}
              dot={{ fill: '#4caf50', r: 3 }}
              activeDot={{ r: 6 }}
              name="Profitto"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default TrendChart;
