import React, { useState } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Card,
  CardContent,
  Typography,
  TextField,
  MenuItem,
  Grid,
  Alert,
  CircularProgress,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const steps = [
  'Dati Base Azienda',
  'Dati Finanziari',
  'KPI Target',
  'Conferma',
];

const INDUSTRIES = [
  'Technology',
  'Finanza',
  'Healthcare',
  'Retail',
  'Manufacturing',
  'Energia',
  'Telecomunicazioni',
  'Altro',
];

const COUNTRIES = [
  'Italia',
  'Germania',
  'Francia',
  'Spagna',
  'Inghilterra',
  'USA',
  'Altro',
];

const DataInputWizard = ({ onSubmit, loading = false }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    // Step 1
    company_name: '',
    industry: '',
    country: '',
    // Step 2
    revenue: 1000000,
    cogs: 400000,
    opex: 300000,
    // Step 3
    target_profit_margin: 20,
    target_growth_rate: 15,
    debt_ratio: 30,
  });
  const [errors, setErrors] = useState({});

  const handleChange = (field) => (event) => {
    setFormData({
      ...formData,
      [field]: event.target.value,
    });
    if (errors[field]) {
      setErrors({ ...errors, [field]: '' });
    }
  };

  const validateStep = (step) => {
    const newErrors = {};

    if (step === 0) {
      if (!formData.company_name) newErrors.company_name = 'Nome azienda obbligatorio';
      if (!formData.industry) newErrors.industry = 'Settore obbligatorio';
      if (!formData.country) newErrors.country = 'Paese obbligatorio';
    }

    if (step === 1) {
      if (!formData.revenue || formData.revenue <= 0) newErrors.revenue = 'Ricavi devono essere > 0';
      if (!formData.cogs || formData.cogs < 0) newErrors.cogs = 'COGS non valido';
      if (!formData.opex || formData.opex < 0) newErrors.opex = 'OpEx non valido';
    }

    if (step === 2) {
      if (formData.target_profit_margin < 0 || formData.target_profit_margin > 100) {
        newErrors.target_profit_margin = 'Deve essere tra 0 e 100';
      }
      if (formData.target_growth_rate < 0 || formData.target_growth_rate > 100) {
        newErrors.target_growth_rate = 'Deve essere tra 0 e 100';
      }
      if (formData.debt_ratio < 0 || formData.debt_ratio > 100) {
        newErrors.debt_ratio = 'Deve essere tra 0 e 100';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      if (activeStep === steps.length - 1) {
        onSubmit(formData);
      } else {
        setActiveStep((prev) => prev + 1);
      }
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Box sx={{ py: 4 }}>
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      <Card sx={{ minHeight: 400 }}>
        <CardContent>
          {/* Step 1: Dati Base */}
          {activeStep === 0 && (
            <Box>
              <Typography variant="h5" sx={{ mb: 3 }}>
                📋 Informazioni Aziendali
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Nome Azienda"
                    value={formData.company_name}
                    onChange={handleChange('company_name')}
                    error={!!errors.company_name}
                    helperText={errors.company_name}
                    placeholder="Es. Acme Corp"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    select
                    fullWidth
                    label="Settore"
                    value={formData.industry}
                    onChange={handleChange('industry')}
                    error={!!errors.industry}
                    helperText={errors.industry}
                  >
                    {INDUSTRIES.map((ind) => (
                      <MenuItem key={ind} value={ind}>
                        {ind}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    select
                    fullWidth
                    label="Paese"
                    value={formData.country}
                    onChange={handleChange('country')}
                    error={!!errors.country}
                    helperText={errors.country}
                  >
                    {COUNTRIES.map((country) => (
                      <MenuItem key={country} value={country}>
                        {country}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
              </Grid>
            </Box>
          )}

          {/* Step 2: Dati Finanziari */}
          {activeStep === 1 && (
            <Box>
              <Typography variant="h5" sx={{ mb: 3 }}>
                💰 Dati Finanziari Attuali
              </Typography>
              <Alert severity="info" sx={{ mb: 3 }}>
                Inserisci i dati finanziari dell'ultimo anno fiscale
              </Alert>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Ricavi Annuali (€)"
                    type="number"
                    value={formData.revenue}
                    onChange={handleChange('revenue')}
                    error={!!errors.revenue}
                    helperText={errors.revenue || formatCurrency(formData.revenue)}
                    inputProps={{ step: '100000' }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Costo del Venduto (COGS €)"
                    type="number"
                    value={formData.cogs}
                    onChange={handleChange('cogs')}
                    error={!!errors.cogs}
                    helperText={errors.cogs || formatCurrency(formData.cogs)}
                    inputProps={{ step: '50000' }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Spese Operative (OpEx €)"
                    type="number"
                    value={formData.opex}
                    onChange={handleChange('opex')}
                    error={!!errors.opex}
                    helperText={errors.opex || formatCurrency(formData.opex)}
                    inputProps={{ step: '50000' }}
                  />
                </Grid>
              </Grid>
            </Box>
          )}

          {/* Step 3: KPI Target */}
          {activeStep === 2 && (
            <Box>
              <Typography variant="h5" sx={{ mb: 3 }}>
                🎯 Obiettivi KPI
              </Typography>
              <Alert severity="success" sx={{ mb: 3 }}>
                Definisci gli obiettivi di performance per i prossimi 12 mesi
              </Alert>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Margine di Profitto Target (%)"
                    type="number"
                    value={formData.target_profit_margin}
                    onChange={handleChange('target_profit_margin')}
                    error={!!errors.target_profit_margin}
                    helperText={errors.target_profit_margin}
                    inputProps={{ min: 0, max: 100, step: 1 }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Target Crescita (%)"
                    type="number"
                    value={formData.target_growth_rate}
                    onChange={handleChange('target_growth_rate')}
                    error={!!errors.target_growth_rate}
                    helperText={errors.target_growth_rate}
                    inputProps={{ min: 0, max: 100, step: 1 }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Rapporto Debito Target (%)"
                    type="number"
                    value={formData.debt_ratio}
                    onChange={handleChange('debt_ratio')}
                    error={!!errors.debt_ratio}
                    helperText={errors.debt_ratio}
                    inputProps={{ min: 0, max: 100, step: 1 }}
                  />
                </Grid>
              </Grid>
            </Box>
          )}

          {/* Step 4: Conferma */}
          {activeStep === 3 && (
            <Box>
              <Box sx={{ textAlign: 'center', mb: 3 }}>
                <CheckCircleIcon sx={{ fontSize: 60, color: 'success.main', mb: 2 }} />
                <Typography variant="h5">Riepilogo Dati</Typography>
              </Box>

              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography color="textSecondary">Azienda</Typography>
                  <Typography variant="h6">{formData.company_name}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography color="textSecondary">Settore</Typography>
                  <Typography variant="h6">{formData.industry}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography color="textSecondary">Ricavi</Typography>
                  <Typography variant="h6">{formatCurrency(formData.revenue)}</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography color="textSecondary">Margine Target</Typography>
                  <Typography variant="h6">{formData.target_profit_margin}%</Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography color="textSecondary">Growth Target</Typography>
                  <Typography variant="h6">{formData.target_growth_rate}%</Typography>
                </Grid>
                <Grid item xs={12}>
                  <Alert severity="info">
                    Clicca "Seleziona" per confermareconfigurazione e accedere al dashboard
                  </Alert>
                </Grid>
              </Grid>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Buttons */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
        <Button
          disabled={activeStep === 0 || loading}
          onClick={handleBack}
          variant="outlined"
          startIcon={<ArrowBackIcon />}
        >
          Indietro
        </Button>

        <Button
          onClick={handleNext}
          variant="contained"
          disabled={loading}
          endIcon={
            loading ? (
              <CircularProgress size={20} />
            ) : activeStep === steps.length - 1 ? null : (
              <ArrowForwardIcon />
            )
          }
        >
          {activeStep === steps.length - 1 ? 'Seleziona' : 'Avanti'}
        </Button>
      </Box>
    </Box>
  );
};

export default DataInputWizard;
