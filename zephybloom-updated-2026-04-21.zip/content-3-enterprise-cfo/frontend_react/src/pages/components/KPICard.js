import React from 'react';
import { Card, CardContent, Box, Typography, Chip } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';

const KPICard = ({ 
  title, 
  value, 
  unit = '', 
  trend = null, 
  trendLabel = '', 
  icon: Icon = null,
  color = 'primary',
}) => {
  const isTrendingUp = trend > 0;

  return (
    <Card
      sx={{
        background: 'linear-gradient(180deg, rgba(255,255,255,0.045) 0%, rgba(255,255,255,0.015) 100%)',
        border: '1px solid',
        borderColor: color === 'primary' ? 'rgba(53,198,182,0.35)' :
                     color === 'success' ? 'rgba(76,175,80,0.35)' :
                     color === 'warning' ? 'rgba(255,152,0,0.35)' : 'rgba(122,167,255,0.35)',
        overflow: 'hidden',
        position: 'relative',
        minHeight: 130,
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Typography color="textSecondary" variant="body2" sx={{ fontWeight: 800 }}>
            {title}
          </Typography>
          {Icon && <Icon sx={{ color: color === 'primary' ? '#35c6b6' : '#fff', fontSize: 22 }} />}
        </Box>

        <Typography variant="h3" sx={{ fontWeight: 900, mb: 1, color: '#f4f7f5', letterSpacing: 0 }}>
          {value}
          <Typography component="span" variant="h6" sx={{ ml: 1, color: 'textSecondary' }}>
            {unit}
          </Typography>
        </Typography>

        {trend !== null && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {isTrendingUp ? (
              <TrendingUpIcon sx={{ color: '#4caf50', fontSize: 18 }} />
            ) : (
              <TrendingDownIcon sx={{ color: '#f44336', fontSize: 18 }} />
            )}
            <Chip
              label={`${Math.abs(trend)}% ${trendLabel}`}
              size="small"
              sx={{
                backgroundColor: isTrendingUp ? 'rgba(76, 175, 80, 0.14)' : 'rgba(244, 67, 54, 0.14)',
                color: isTrendingUp ? '#4caf50' : '#f44336',
                borderRadius: 1,
              }}
            />
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default KPICard;
