import React, { useState } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  TextField,
  Button,
  Box,
  Typography,
  Paper,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const toNumber = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const buildCompanyPayload = (companyData = {}) => ({
  fatturato: toNumber(companyData.fatturato, 1000000),
  costi_variabili: toNumber(companyData.costi_variabili, 400000),
  costi_fissi: toNumber(companyData.costi_fissi, 300000),
  investimenti: toNumber(companyData.investimenti, 100000),
  settore: companyData.settore || 'default',
  company_name: companyData.company_name || 'My Company',
});

function SimulatePage() {
  const { companyData, currentAnalysis, saveSimulation } = useCompany();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [simulation, setSimulation] = useState(null);
  const [scenarioName, setScenarioName] = useState('Scenario 1');
  const [deltas, setDeltas] = useState({
    fatturato_pct: 10,
    costi_variabili_pct: 0,
    costi_fissi_pct: 0,
    investimenti_pct: 0,
  });

  const handleDeltaChange = (field, value) => {
    setDeltas(prev => ({
      ...prev,
      [field]: parseFloat(value) || 0,
    }));
  };

  const handleSimulate = async () => {
    setLoading(true);
    setError('');
    try {
      const baseAnalysis = buildCompanyPayload(companyData);
      const scenarioDeltas = {
        fatturato_delta: Math.round(baseAnalysis.fatturato * (deltas.fatturato_pct / 100)),
        costi_variabili_delta: Math.round(baseAnalysis.costi_variabili * (deltas.costi_variabili_pct / 100)),
        costi_fissi_delta: Math.round(baseAnalysis.costi_fissi * (deltas.costi_fissi_pct / 100)),
        investimenti_delta: Math.round(baseAnalysis.investimenti * (deltas.investimenti_pct / 100)),
      };
      const response = await cfoApi.simulate({
        scenario_name: scenarioName,
        base_analysis: baseAnalysis,
        ...scenarioDeltas,
      });
      setSimulation(response.data);
      saveSimulation(response.data);
    } catch (err) {
      setError(err.response?.data?.detail || 'Simulation failed');
    } finally {
      setLoading(false);
    }
  };

  const comparisonData = simulation ? [
    {
      metric: 'Fatturato',
      base: companyData.fatturato,
      scenario: companyData.fatturato * (1 + (deltas.fatturato_pct || 0) / 100),
    },
    {
      metric: 'Net Profit',
      base: simulation.base_analysis.kpi_snapshot.net_profit_eur,
      scenario: simulation.scenario_analysis.kpi_snapshot.net_profit_eur,
    },
    {
      metric: 'Gross Margin %',
      base: simulation.base_analysis.kpi_snapshot.gross_margin_pct,
      scenario: simulation.scenario_analysis.kpi_snapshot.gross_margin_pct,
    },
    {
      metric: 'EBITDA',
      base: simulation.base_analysis.kpi_snapshot.ebitda_eur,
      scenario: simulation.scenario_analysis.kpi_snapshot.ebitda_eur,
    },
  ] : [];

  return (
    <Layout>
      <Container maxWidth="lg">
        <Typography variant="h4" sx={{ mb: 4, fontWeight: 700 }}>
          Scenario Simulator
        </Typography>

        {!currentAnalysis && (
          <Alert severity="info" sx={{ mb: 3 }}>
            Puoi simulare subito con i dati aziendali correnti. L'analisi dashboard aggiunge solo il confronto storico.
          </Alert>
        )}

        <Grid container spacing={3}>
          {/* Scenario Configuration */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader title="Create Scenario" />
              <CardContent sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  label="Scenario Name"
                  value={scenarioName}
                  onChange={(e) => setScenarioName(e.target.value)}
                  fullWidth
                  size="small"
                />

                <Box sx={{ p: 2, backgroundColor: '#f5f5f5', borderRadius: 1 }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 1 }}>
                    Fatturato (%)
                  </Typography>
                  <TextField
                    label="Variazione %"
                    type="number"
                    value={deltas.fatturato_pct}
                    onChange={(e) => handleDeltaChange('fatturato_pct', e.target.value)}
                    fullWidth
                    size="small"
                    inputProps={{ step: '1' }}
                  />
                  <Typography variant="caption" sx={{ mt: 1, display: 'block' }}>
                    Base: €{companyData.fatturato.toLocaleString()}
                    → Scenario: €{Math.round(companyData.fatturato * (1 + (deltas.fatturato_pct || 0) / 100)).toLocaleString()}
                  </Typography>
                </Box>

                <Box sx={{ p: 2, backgroundColor: '#f5f5f5', borderRadius: 1 }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 1 }}>
                    Costi variabili (%)
                  </Typography>
                  <TextField
                    label="Variazione %"
                    type="number"
                    value={deltas.costi_variabili_pct}
                    onChange={(e) => handleDeltaChange('costi_variabili_pct', e.target.value)}
                    fullWidth
                    size="small"
                    inputProps={{ step: '1' }}
                  />
                </Box>

                <Box sx={{ p: 2, backgroundColor: '#f5f5f5', borderRadius: 1 }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 1 }}>
                    Costi fissi (%)
                  </Typography>
                  <TextField
                    label="Variazione %"
                    type="number"
                    value={deltas.costi_fissi_pct}
                    onChange={(e) => handleDeltaChange('costi_fissi_pct', e.target.value)}
                    fullWidth
                    size="small"
                    inputProps={{ step: '1' }}
                  />
                </Box>

                {error && <Alert severity="error">{error}</Alert>}

                <Button
                  variant="contained"
                  fullWidth
                  onClick={handleSimulate}
                  disabled={loading}
                  sx={{ mt: 2 }}
                >
                  {loading ? <CircularProgress size={24} /> : 'Run Simulation'}
                </Button>
              </CardContent>
            </Card>
          </Grid>

          {/* Simulation Results */}
          {simulation && (
            <>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Recommendation" />
                  <CardContent>
                    <Paper
                      sx={{
                        p: 2,
                        backgroundColor:
                          simulation.comparison.recommendation.includes('YES')
                            ? '#e8f5e9'
                            : simulation.comparison.recommendation.includes('MAYBE')
                            ? '#fff3e0'
                            : '#ffebee',
                        borderRadius: 1,
                      }}
                    >
                      <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>
                        {simulation.comparison.recommendation}
                      </Typography>

                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                        <Typography variant="body2">
                          <strong>Profit Impact:</strong> €
                          {simulation.comparison.profit_delta_eur.toLocaleString('it-IT')}
                        </Typography>
                        <Typography variant="body2">
                          <strong>Impact %:</strong> {simulation.comparison.profit_delta_pct.toFixed(2)}%
                        </Typography>
                        {simulation.comparison.roi_delta_pct && (
                          <Typography variant="body2">
                            <strong>ROI Change:</strong> {simulation.comparison.roi_delta_pct.toFixed(2)}%
                          </Typography>
                        )}
                      </Box>
                    </Paper>
                  </CardContent>
                </Card>
              </Grid>

              {/* Comparison Chart */}
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Base vs Scenario Comparison" />
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={comparisonData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="metric" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="base" fill="#8884d8" name="Base" />
                        <Bar dataKey="scenario" fill="#82ca9d" name="Scenario" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </Grid>

              {/* Detailed Comparison Table */}
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Detailed Metrics" />
                  <CardContent>
                    <TableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                            <TableCell><strong>Metric</strong></TableCell>
                            <TableCell align="right"><strong>Base</strong></TableCell>
                            <TableCell align="right"><strong>Scenario</strong></TableCell>
                            <TableCell align="right"><strong>Change</strong></TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow>
                            <TableCell>Fatturato</TableCell>
                            <TableCell align="right">
                              €{simulation.base_analysis.input?.fatturato?.toLocaleString?.('it-IT') || companyData.fatturato.toLocaleString('it-IT')}
                            </TableCell>
                            <TableCell align="right">
                              €{Math.round(companyData.fatturato * (1 + (deltas.fatturato_pct || 0) / 100)).toLocaleString('it-IT')}
                            </TableCell>
                            <TableCell align="right">
                              {(Math.round(companyData.fatturato * ((deltas.fatturato_pct || 0) / 100))).toLocaleString('it-IT')}
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell>Gross Margin %</TableCell>
                            <TableCell align="right">
                              {simulation.base_analysis.kpi_snapshot.gross_margin_pct.toFixed(1)}%
                            </TableCell>
                            <TableCell align="right">
                              {simulation.scenario_analysis.kpi_snapshot.gross_margin_pct.toFixed(1)}%
                            </TableCell>
                            <TableCell align="right">
                              {(simulation.scenario_analysis.kpi_snapshot.gross_margin_pct - simulation.base_analysis.kpi_snapshot.gross_margin_pct).toFixed(1)}pp
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell><strong>Net Profit</strong></TableCell>
                            <TableCell align="right">
                              <strong>€{simulation.base_analysis.kpi_snapshot.net_profit_eur.toLocaleString('it-IT')}</strong>
                            </TableCell>
                            <TableCell align="right">
                              <strong>€{simulation.scenario_analysis.kpi_snapshot.net_profit_eur.toLocaleString('it-IT')}</strong>
                            </TableCell>
                            <TableCell align="right">
                              <strong>{simulation.comparison.profit_delta_eur.toLocaleString('it-IT')}</strong>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </CardContent>
                </Card>
              </Grid>
            </>
          )}
        </Grid>
      </Container>
    </Layout>
  );
}

export default SimulatePage;
