import React, { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  CircularProgress,
  Container,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import StorefrontIcon from '@mui/icons-material/Storefront';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(Number(value || 0));

const DEFAULT_FORM = {
  annual_revenue: 600000,
  fixed_costs: 90000,
  invested_capital: 80000,
  average_order_value: 75,
  monthly_orders: 800,
  customer_acquisition_cost: 18,
  monthly_ad_spend: 12000,
  payment_fees_pct: 2,
  return_rate_pct: 5,
};

const DEFAULT_SKUS = [
  { sku: 'Hero Product', price: 75, purchase_cost: 24, shipping_cost: 7, monthly_units: 500, marketplace_fee_pct: 0 },
  { sku: 'Low Margin Product', price: 40, purchase_cost: 31, shipping_cost: 6, monthly_units: 300, marketplace_fee_pct: 0 },
];

const DEFAULT_SCENARIO = {
  name: 'Scenario ecommerce',
  price_delta_pct: 5,
  volume_delta_pct: 10,
  purchase_cost_delta_pct: -3,
  shipping_cost_delta_pct: 0,
  return_rate_delta_pct: -1,
  ad_spend_delta_pct: 0,
  cac_delta_pct: 0,
  target_sku: '',
};

function EcommerceCFOPage() {
  const { updateCompanyData, saveOperationalData } = useCompany();
  const [form, setForm] = useState(DEFAULT_FORM);
  const [skus, setSkus] = useState(DEFAULT_SKUS);
  const [analysis, setAnalysis] = useState(null);
  const [simulation, setSimulation] = useState(null);
  const [scenario, setScenario] = useState(DEFAULT_SCENARIO);
  const [readiness, setReadiness] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const ecommerceAnalysis = analysis?.ecommerce_analysis;
  const summary = ecommerceAnalysis?.summary;

  const operationalData = useMemo(() => ({
    ...form,
    sku_sales: skus.filter((row) => row.sku),
  }), [form, skus]);

  const updateForm = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: Number(value || 0) }));
  };

  const updateSku = (index, field, value, numeric = true) => {
    setSkus((prev) =>
      prev.map((row, rowIndex) =>
        rowIndex === index ? { ...row, [field]: numeric ? Number(value || 0) : value } : row
      )
    );
  };

  const updateScenario = (field, value, numeric = true) => {
    setScenario((prev) => ({ ...prev, [field]: numeric ? Number(value || 0) : value }));
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError('');
    try {
      const [analysisResponse, readinessResponse] = await Promise.all([
        cfoApi.ecommerceAnalyze(operationalData),
        cfoApi.dataRequirements('ecommerce', operationalData),
      ]);
      setAnalysis(analysisResponse.data);
      setReadiness(readinessResponse.data.data_readiness);
      updateCompanyData({
        fatturato: operationalData.annual_revenue,
        costi_variabili: operationalData.annual_revenue - analysisResponse.data.ecommerce_analysis.summary.annual_contribution_eur,
        costi_fissi: operationalData.fixed_costs,
        investimenti: operationalData.invested_capital,
        settore: 'ecommerce',
      });
      saveOperationalData('ecommerce', operationalData);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulate = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.ecommerceSimulate(operationalData, scenario);
      setSimulation(response.data.ecommerce_simulation);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const metric = (label, value) => (
    <Card>
      <CardContent>
        <Typography color="textSecondary">{label}</Typography>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>{value}</Typography>
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>Ecommerce CFO</Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Calcola margine SKU, resi, spedizioni, CAC, ROAS e break-even CAC.
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<StorefrontIcon />} onClick={handleAnalyze} disabled={loading}>
            {loading ? <CircularProgress size={22} /> : 'Analizza ecommerce'}
          </Button>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}

        <Card sx={{ mb: 4 }}>
          <CardHeader title="Numeri base" subheader="Dati annui, ordini, CAC, resi e advertising." />
          <CardContent>
            <Grid container spacing={2}>
              {Object.entries({
                annual_revenue: 'Fatturato annuo',
                fixed_costs: 'Costi fissi annui',
                invested_capital: 'Capitale investito',
                average_order_value: 'AOV',
                monthly_orders: 'Ordini/mese',
                customer_acquisition_cost: 'CAC',
                monthly_ad_spend: 'Ads/mese',
                payment_fees_pct: 'Fee pagamento %',
                return_rate_pct: 'Resi %',
              }).map(([field, label]) => (
                <Grid item xs={12} sm={6} md={3} key={field}>
                  <TextField label={label} type="number" value={form[field]} fullWidth size="small" onChange={(event) => updateForm(field, event.target.value)} />
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="SKU"
            subheader="Prezzo, costo prodotto, spedizione e unità mensili."
            action={<Button size="small" startIcon={<AddIcon />} onClick={() => setSkus((prev) => [...prev, { sku: '', price: 0, purchase_cost: 0, shipping_cost: 0, monthly_units: 0, marketplace_fee_pct: 0 }])}>SKU</Button>}
          />
          <CardContent sx={{ overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 850 }}>
              <TableHead>
                <TableRow>
                  <TableCell>SKU</TableCell>
                  <TableCell>Prezzo</TableCell>
                  <TableCell>Costo prodotto</TableCell>
                  <TableCell>Spedizione</TableCell>
                  <TableCell>Unità/mese</TableCell>
                  <TableCell>Marketplace fee %</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {skus.map((row, index) => (
                  <TableRow key={index}>
                    {[
                      ['sku', false],
                      ['price', true],
                      ['purchase_cost', true],
                      ['shipping_cost', true],
                      ['monthly_units', true],
                      ['marketplace_fee_pct', true],
                    ].map(([field, numeric]) => (
                      <TableCell key={field} sx={{ minWidth: numeric ? 120 : 180 }}>
                        <TextField size="small" type={numeric ? 'number' : 'text'} value={row[field]} fullWidth onChange={(event) => updateSku(index, field, event.target.value, numeric)} />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="Scenario operativo"
            subheader="Simula prezzo, volume, resi, CAC, ads, spedizioni e costo prodotto."
            action={<Button variant="outlined" onClick={handleSimulate} disabled={loading}>Simula scenario</Button>}
          />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={3}>
                <TextField label="Nome scenario" value={scenario.name} fullWidth size="small" onChange={(event) => updateScenario('name', event.target.value, false)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField label="SKU target opzionale" value={scenario.target_sku} fullWidth size="small" onChange={(event) => updateScenario('target_sku', event.target.value, false)} />
              </Grid>
              {[
                ['price_delta_pct', 'Prezzo %'],
                ['volume_delta_pct', 'Ordini/volume %'],
                ['purchase_cost_delta_pct', 'Costo prodotto %'],
                ['shipping_cost_delta_pct', 'Spedizione %'],
                ['return_rate_delta_pct', 'Resi punti %'],
                ['ad_spend_delta_pct', 'Ads %'],
                ['cac_delta_pct', 'CAC %'],
              ].map(([field, label]) => (
                <Grid item xs={12} sm={6} md={2} key={field}>
                  <TextField label={label} type="number" value={scenario[field]} fullWidth size="small" onChange={(event) => updateScenario(field, event.target.value)} />
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>

        {summary && (
          <>
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={3}>{metric('Margine contributivo', `${summary.contribution_margin_pct}%`)}</Grid>
              <Grid item xs={12} md={3}>{metric('Break-even CAC', formatCurrency(summary.break_even_cac_eur))}</Grid>
              <Grid item xs={12} md={3}>{metric('ROAS', summary.roas)}</Grid>
              <Grid item xs={12} md={3}>{metric('Utile netto', formatCurrency(summary.net_profit_eur))}</Grid>
            </Grid>

            {simulation && (
              <Card sx={{ mb: 4 }}>
                <CardHeader title="Risultato scenario" subheader={simulation.decision} />
                <CardContent>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={3}>{metric('Delta utile annuo', formatCurrency(simulation.delta.net_profit_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta ricavi annui', formatCurrency(simulation.delta.annual_revenue_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta break-even CAC', formatCurrency(simulation.delta.break_even_cac_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta ROAS', simulation.delta.roas)}</Grid>
                  </Grid>
                  <Typography sx={{ mt: 3, fontWeight: 800 }}>
                    Scenario: utile {formatCurrency(simulation.simulated.summary.net_profit_eur)} | margine netto {simulation.simulated.summary.net_margin_pct}% | break-even CAC {formatCurrency(simulation.simulated.summary.break_even_cac_eur)}
                  </Typography>
                </CardContent>
              </Card>
            )}

            {readiness && (
              <Alert severity={readiness.can_answer_precisely ? 'success' : 'warning'} sx={{ mb: 4 }}>
                Precisione dati: {readiness.answer_precision_pct}% - {readiness.readiness_level}
              </Alert>
            )}

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="SKU migliori per utile" />
                  <CardContent>
                    {(ecommerceAnalysis.top_skus_by_profit || []).slice(0, 5).map((sku, index) => (
                      <Box key={sku.sku} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{index + 1}. {sku.sku}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Utile/mese {formatCurrency(sku.monthly_contribution_eur)} | Margine {sku.contribution_margin_pct}% | {sku.decision}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="SKU da correggere" />
                  <CardContent>
                    {(ecommerceAnalysis.skus_to_fix || []).slice(0, 5).map((sku) => (
                      <Box key={sku.sku} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{sku.sku}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Margine {sku.contribution_margin_pct}% | Contributo/unità {formatCurrency(sku.contribution_per_unit_eur)} | {sku.decision}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Decisione CFO" />
                  <CardContent>
                    {(ecommerceAnalysis.recommendations || []).map((item, index) => (
                      <Typography key={index} sx={{ mb: 1 }}>{index + 1}. {item}</Typography>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default EcommerceCFOPage;
