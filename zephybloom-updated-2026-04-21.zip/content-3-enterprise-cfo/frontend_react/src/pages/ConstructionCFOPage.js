import React, { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  CircularProgress,
  Container,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EngineeringIcon from '@mui/icons-material/Engineering';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(Number(value || 0));

const DEFAULT_FORM = {
  fixed_costs: 80000,
  invested_capital: 120000,
};

const DEFAULT_PROJECTS = [
  {
    project: 'Cantiere A',
    contract_value: 240000,
    materials_cost: 82000,
    labor_cost: 46000,
    subcontractor_cost: 28000,
    other_cost: 10000,
    progress_pct: 65,
    billed_pct: 45,
    collected_pct: 25,
    delay_weeks: 2,
    penalty_pct_per_week: 0.5,
    change_orders_approved: 12000,
    change_orders_unapproved: 8000,
  },
];

const DEFAULT_SCENARIO = {
  name: 'Scenario construction',
  materials_cost_delta_pct: 10,
  labor_cost_delta_pct: 0,
  subcontractor_cost_delta_pct: 0,
  billed_delta_pct: 10,
  collected_delta_pct: 15,
  delay_weeks_delta: 0,
  change_orders_approved_delta: 0,
  fixed_cost_delta_pct: 0,
  target_project: '',
};

function ConstructionCFOPage() {
  const { updateCompanyData, saveOperationalData } = useCompany();
  const [form, setForm] = useState(DEFAULT_FORM);
  const [projects, setProjects] = useState(DEFAULT_PROJECTS);
  const [analysis, setAnalysis] = useState(null);
  const [simulation, setSimulation] = useState(null);
  const [scenario, setScenario] = useState(DEFAULT_SCENARIO);
  const [readiness, setReadiness] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const constructionAnalysis = analysis?.construction_analysis;
  const summary = constructionAnalysis?.summary;

  const operationalData = useMemo(() => ({
    ...form,
    projects: projects.filter((row) => row.project),
  }), [form, projects]);

  const updateForm = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: Number(value || 0) }));
  };

  const updateProject = (index, field, value, numeric = true) => {
    setProjects((prev) =>
      prev.map((row, rowIndex) =>
        rowIndex === index ? { ...row, [field]: numeric ? Number(value || 0) : value } : row
      )
    );
  };

  const updateScenario = (field, value, numeric = true) => {
    setScenario((prev) => ({ ...prev, [field]: numeric ? Number(value || 0) : value }));
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError('');
    try {
      const [analysisResponse, readinessResponse] = await Promise.all([
        cfoApi.constructionAnalyze(operationalData),
        cfoApi.dataRequirements('construction', operationalData),
      ]);
      const result = analysisResponse.data.construction_analysis;
      setAnalysis(analysisResponse.data);
      setReadiness(readinessResponse.data.data_readiness);
      updateCompanyData({
        fatturato: result.summary.contract_value_eur,
        costi_variabili: result.summary.expected_total_cost_eur,
        costi_fissi: operationalData.fixed_costs,
        investimenti: operationalData.invested_capital,
        settore: 'construction',
      });
      saveOperationalData('construction', operationalData);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulate = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.constructionSimulate(operationalData, scenario);
      setSimulation(response.data.construction_simulation);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const metric = (label, value) => (
    <Card>
      <CardContent>
        <Typography color="textSecondary">{label}</Typography>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>{value}</Typography>
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>Construction CFO</Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Leggi margine per commessa, SAL, incassi, WIP e cash gap.
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<EngineeringIcon />} onClick={handleAnalyze} disabled={loading}>
            {loading ? <CircularProgress size={22} /> : 'Analizza commesse'}
          </Button>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}

        <Card sx={{ mb: 4 }}>
          <CardHeader title="Struttura" subheader="Costi fissi e capitale impiegato." />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={3}>
                <TextField label="Costi fissi annui" type="number" value={form.fixed_costs} fullWidth size="small" onChange={(event) => updateForm('fixed_costs', event.target.value)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField label="Capitale investito" type="number" value={form.invested_capital} fullWidth size="small" onChange={(event) => updateForm('invested_capital', event.target.value)} />
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="Commesse"
            subheader="Valore, costi, avanzamento, fatturato SAL e incassi."
            action={<Button size="small" startIcon={<AddIcon />} onClick={() => setProjects((prev) => [...prev, { project: '', contract_value: 0, materials_cost: 0, labor_cost: 0, subcontractor_cost: 0, other_cost: 0, progress_pct: 0, billed_pct: 0, collected_pct: 0, delay_weeks: 0, penalty_pct_per_week: 0, change_orders_approved: 0, change_orders_unapproved: 0 }])}>Commessa</Button>}
          />
          <CardContent sx={{ overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 1500 }}>
              <TableHead>
                <TableRow>
                  <TableCell>Commessa</TableCell>
                  <TableCell>Valore</TableCell>
                  <TableCell>Materiali</TableCell>
                  <TableCell>Manodopera</TableCell>
                  <TableCell>Subappalti</TableCell>
                  <TableCell>Altri costi</TableCell>
                  <TableCell>Avanz. %</TableCell>
                  <TableCell>SAL fatturato %</TableCell>
                  <TableCell>Incassato %</TableCell>
                  <TableCell>Ritardo sett.</TableCell>
                  <TableCell>Penale %/sett.</TableCell>
                  <TableCell>Varianti approvate</TableCell>
                  <TableCell>Varianti non approvate</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {projects.map((row, index) => (
                  <TableRow key={index}>
                    {[
                      ['project', false],
                      ['contract_value', true],
                      ['materials_cost', true],
                      ['labor_cost', true],
                      ['subcontractor_cost', true],
                      ['other_cost', true],
                      ['progress_pct', true],
                      ['billed_pct', true],
                      ['collected_pct', true],
                      ['delay_weeks', true],
                      ['penalty_pct_per_week', true],
                      ['change_orders_approved', true],
                      ['change_orders_unapproved', true],
                    ].map(([field, numeric]) => (
                      <TableCell key={field} sx={{ minWidth: numeric ? 115 : 170 }}>
                        <TextField size="small" type={numeric ? 'number' : 'text'} value={row[field]} fullWidth onChange={(event) => updateProject(index, field, event.target.value, numeric)} />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card sx={{ mb: 4 }}>
          <CardHeader
            title="Scenario operativo"
            subheader="Simula materiali, SAL, incassi, ritardi, varianti e costi fissi."
            action={<Button variant="outlined" onClick={handleSimulate} disabled={loading}>Simula scenario</Button>}
          />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={3}>
                <TextField label="Nome scenario" value={scenario.name} fullWidth size="small" onChange={(event) => updateScenario('name', event.target.value, false)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField label="Commessa target opzionale" value={scenario.target_project} fullWidth size="small" onChange={(event) => updateScenario('target_project', event.target.value, false)} />
              </Grid>
              {[
                ['materials_cost_delta_pct', 'Materiali %'],
                ['labor_cost_delta_pct', 'Manodopera %'],
                ['subcontractor_cost_delta_pct', 'Subappalti %'],
                ['billed_delta_pct', 'SAL fatturato punti %'],
                ['collected_delta_pct', 'Incassato punti %'],
                ['delay_weeks_delta', 'Ritardo settimane'],
                ['change_orders_approved_delta', 'Varianti approvate EUR'],
                ['fixed_cost_delta_pct', 'Costi fissi %'],
              ].map(([field, label]) => (
                <Grid item xs={12} sm={6} md={2} key={field}>
                  <TextField label={label} type="number" value={scenario[field]} fullWidth size="small" onChange={(event) => updateScenario(field, event.target.value)} />
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>

        {summary && (
          <>
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={3}>{metric('Valore commesse', formatCurrency(summary.contract_value_eur))}</Grid>
              <Grid item xs={12} md={3}>{metric('Margine atteso', `${summary.expected_margin_pct}%`)}</Grid>
              <Grid item xs={12} md={3}>{metric('Cash gap', formatCurrency(summary.cash_gap_eur))}</Grid>
              <Grid item xs={12} md={3}>{metric('WIP non fatturato', formatCurrency(summary.wip_unbilled_eur))}</Grid>
            </Grid>

            {simulation && (
              <Card sx={{ mb: 4 }}>
                <CardHeader title="Risultato scenario" subheader={simulation.decision} />
                <CardContent>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={3}>{metric('Delta utile overhead', formatCurrency(simulation.delta.net_profit_after_overhead_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta margine', `${simulation.delta.expected_margin_pct}%`)}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta cash gap', formatCurrency(simulation.delta.cash_gap_eur))}</Grid>
                    <Grid item xs={12} md={3}>{metric('Delta WIP', formatCurrency(simulation.delta.wip_unbilled_eur))}</Grid>
                  </Grid>
                  <Typography sx={{ mt: 3, fontWeight: 800 }}>
                    Scenario: utile dopo overhead {formatCurrency(simulation.simulated.summary.net_profit_after_overhead_eur)} | cash gap {formatCurrency(simulation.simulated.summary.cash_gap_eur)} | WIP {formatCurrency(simulation.simulated.summary.wip_unbilled_eur)}
                  </Typography>
                </CardContent>
              </Card>
            )}

            {readiness && (
              <Alert severity={readiness.can_answer_precisely ? 'success' : 'warning'} sx={{ mb: 4 }}>
                Precisione dati: {readiness.answer_precision_pct}% - {readiness.readiness_level}
              </Alert>
            )}

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Commesse con rischio cassa" />
                  <CardContent>
                    {(constructionAnalysis.projects_by_cash_risk || []).slice(0, 5).map((project, index) => (
                      <Box key={project.project} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{index + 1}. {project.project}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Cash gap {formatCurrency(project.cash_gap_eur)} | WIP {formatCurrency(project.wip_unbilled_eur)} | {project.decision}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Commesse da correggere" />
                  <CardContent>
                    {(constructionAnalysis.projects_to_fix || []).slice(0, 5).map((project) => (
                      <Box key={project.project} sx={{ py: 1, borderBottom: '1px solid #37474f' }}>
                        <Typography sx={{ fontWeight: 800 }}>{project.project}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Margine {project.expected_margin_pct}% | Ritardo rischio {formatCurrency(project.delay_risk_eur)} | {project.decision}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Decisione CFO" />
                  <CardContent>
                    {(constructionAnalysis.recommendations || []).map((item, index) => (
                      <Typography key={index} sx={{ mb: 1 }}>{index + 1}. {item}</Typography>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default ConstructionCFOPage;
