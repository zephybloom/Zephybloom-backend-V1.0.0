import React from 'react';
import { Container, Box, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';

function AnalyzePage() {
  const navigate = useNavigate();

  return (
    <Layout>
      <Container maxWidth="lg">
        <Typography variant="h4" sx={{ mb: 4, fontWeight: 700 }}>
          Financial Analysis
        </Typography>
        <Box sx={{ p: 3, backgroundColor: '#f5f5f5', borderRadius: 2, textAlign: 'center' }}>
          <Typography variant="body1" sx={{ mb: 2 }}>
            Detailed financial analysis features are available on the Dashboard.
          </Typography>
          <Button variant="contained" onClick={() => navigate('/dashboard')}>
            Go to Dashboard
          </Button>
        </Box>
      </Container>
    </Layout>
  );
}

export default AnalyzePage;
