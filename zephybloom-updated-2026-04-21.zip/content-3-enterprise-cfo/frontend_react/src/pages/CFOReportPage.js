import React, { useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Chip,
  CircularProgress,
  Container,
  Grid,
  Typography,
} from '@mui/material';
import DescriptionIcon from '@mui/icons-material/Description';
import Layout from '../components/Layout';
import { useCompany } from '../context/companyContext';
import { cfoApi } from '../services/api';

const formatCurrency = (value) =>
  new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

function CFOReportPage() {
  const { companyData, operationalDataBySector } = useCompany();
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');

  const reportPayload = () => ({
    company_id: companyData.company_id || companyData.company_name || 'default',
    company_name: companyData.company_name || 'Azienda',
    company_data: companyData,
    operational_data_by_sector: operationalDataBySector,
  });

  const handleGenerate = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await cfoApi.monthlyReport(reportPayload());
      setReport(response.data.report);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPdf = async () => {
    setExporting(true);
    setError('');
    try {
      const response = await cfoApi.monthlyReportPdf(reportPayload());
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `report-cfo-${report?.company_id || 'azienda'}-${report?.period || 'mensile'}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((item) => item.msg).join(' | ') : detail || err.message);
    } finally {
      setExporting(false);
    }
  };

  const handleDownloadMarkdown = () => {
    if (!report?.markdown) return;
    const blob = new Blob([report.markdown], { type: 'text/markdown;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `report-cfo-${report.company_id || 'azienda'}-${report.period || 'mensile'}.md`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  };

  const sections = report?.sections || {};
  const executive = sections.executive_summary || {};
  const ceoBrief = sections.ceo_brief || {};
  const financeBrief = sections.finance_brief || {};
  const snapshot = sections.financial_snapshot || {};
  const warRoom = sections.war_room || {};
  const memory = sections.decision_memory || {};
  const dataQuality = sections.data_quality || {};

  return (
    <Layout>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800 }}>
              Report CFO
            </Typography>
            <Typography color="textSecondary" sx={{ mt: 1 }}>
              Executive summary mensile con numeri, War Room, memoria decisioni e prossimi 30 giorni.
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            <Button variant="contained" startIcon={<DescriptionIcon />} onClick={handleGenerate} disabled={loading}>
              {loading ? <CircularProgress size={22} /> : 'Genera report'}
            </Button>
            {report && (
              <>
                <Button variant="outlined" onClick={handleDownloadPdf} disabled={exporting}>
                  {exporting ? <CircularProgress size={20} /> : 'Scarica PDF'}
                </Button>
                <Button variant="outlined" onClick={handleDownloadMarkdown}>
                  Scarica Markdown
                </Button>
              </>
            )}
          </Box>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>{error}</Alert>}

        {!report && (
          <Alert severity="info" sx={{ mb: 4 }}>
            Il report usa i dati aziendali correnti, i verticali salvati, la War Room e la memoria decisioni.
          </Alert>
        )}

        {report && (
          <>
            <Card sx={{ mb: 4 }}>
              <CardHeader
                title={executive.headline}
                subheader={`Periodo: ${report.period} | Score report: ${executive.score}/100`}
              />
              <CardContent>
                <Typography sx={{ mb: 2 }}>{executive.diagnosis}</Typography>
                <Alert severity="success">{executive.board_message}</Alert>
              </CardContent>
            </Card>

            <Grid container spacing={2} sx={{ mb: 4 }}>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Fatturato</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 800 }}>{formatCurrency(snapshot.revenue_eur)}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">Utile netto</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 800 }}>{formatCurrency(snapshot.net_profit_eur)}</Typography>
                    <Typography variant="body2">{snapshot.net_margin_pct}%</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">EBITDA</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 800 }}>{formatCurrency(snapshot.ebitda_eur)}</Typography>
                    <Typography variant="body2">{snapshot.ebitda_margin_pct}%</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary">ROI</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 800 }}>{snapshot.roi_pct}%</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Sintesi CEO" subheader={ceoBrief.status} />
                  <CardContent>
                    <Typography sx={{ fontWeight: 800, mb: 1 }}>{ceoBrief.one_liner}</Typography>
                    <Typography variant="body2" sx={{ mb: 1 }}>Rischio: {ceoBrief.main_risk}</Typography>
                    <Typography variant="body2" sx={{ mb: 1 }}>Decisione: {ceoBrief.decision}</Typography>
                    <Alert severity="info" sx={{ mt: 2 }}>
                      Entro 7 giorni: {ceoBrief.action_7_days}
                    </Alert>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Sintesi Finance" subheader={financeBrief.decision_status} />
                  <CardContent>
                    {(financeBrief.kpi_watchlist || []).map((item) => (
                      <Chip key={item} label={item} size="small" sx={{ mr: 1, mb: 1 }} />
                    ))}
                    <Typography variant="body2" sx={{ mt: 1 }}>{financeBrief.memory_status}</Typography>
                    <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>{financeBrief.data_priority}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="Decisioni da board" subheader="Approvare, bloccare, monitorare e chiedere" />
              <CardContent>
                {(sections.board_decisions || []).map((item) => (
                  <Box key={item.decision} sx={{ mb: 2, pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Chip label={item.decision} size="small" color={item.decision === 'APPROVARE' ? 'success' : 'default'} sx={{ mr: 1 }} />
                    <Typography component="span" sx={{ fontWeight: 800 }}>{item.recommendation}</Typography>
                    <Typography variant="body2" color="textSecondary" sx={{ mt: 0.5 }}>{item.why}</Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>

            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Prossimi 30 giorni" />
                  <CardContent>
                    {(sections.next_30_days || []).map((item) => (
                      <Box key={item.priority} sx={{ mb: 2 }}>
                        <Chip label={`#${item.priority}`} size="small" color="primary" sx={{ mr: 1 }} />
                        <Typography component="span" sx={{ fontWeight: 800 }}>{item.action}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          Owner: {item.owner} | KPI: {item.kpi}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Memoria decisioni" subheader={memory.summary?.next_review} />
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={4}>
                        <Typography color="textSecondary">Aperte</Typography>
                        <Typography variant="h6" sx={{ fontWeight: 800 }}>{memory.summary?.open_decisions || 0}</Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Typography color="textSecondary">Completate</Typography>
                        <Typography variant="h6" sx={{ fontWeight: 800 }}>{memory.summary?.completed_decisions || 0}</Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Typography color="textSecondary">Impatto</Typography>
                        <Typography variant="h6" sx={{ fontWeight: 800 }}>{formatCurrency(memory.summary?.actual_impact_eur)}</Typography>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="Domande CFO al team" subheader="Dati e follow-up da chiedere prima della prossima review" />
              <CardContent>
                {(sections.team_questions || []).map((item) => (
                  <Box key={`${item.owner}-${item.question}`} sx={{ mb: 2 }}>
                    <Typography sx={{ fontWeight: 800 }}>{item.owner}</Typography>
                    <Typography>{item.question}</Typography>
                    <Typography variant="body2" color="textSecondary">{item.why}</Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="War Room" subheader="Priorità e controlli da portare in riunione" />
              <CardContent>
                <Typography sx={{ fontWeight: 800, mb: 1 }}>
                  {warRoom.priority_decision?.decision || 'Nessuna priorità ancora generata'}
                </Typography>
                <Typography color="textSecondary" sx={{ mb: 2 }}>
                  {warRoom.priority_decision?.why}
                </Typography>
                {(warRoom.weekly_agenda || []).slice(0, 3).map((item) => (
                  <Typography key={`${item.day}-${item.action}`} variant="body2" sx={{ mb: 0.5 }}>
                    - {item.day}: {item.action}
                  </Typography>
                ))}
              </CardContent>
            </Card>

            <Card sx={{ mb: 4 }}>
              <CardHeader title="Qualità dati" subheader={dataQuality.cfo_note} />
              <CardContent>
                <Typography sx={{ mb: 1 }}>Readiness media: {dataQuality.readiness_avg_pct || 0}%</Typography>
                {(dataQuality.missing_items || []).slice(0, 5).map((gap) => (
                  <Typography key={`${gap.sector}-${gap.key}`} variant="body2" color="textSecondary">
                    - {gap.label}: {gap.field}
                  </Typography>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader title="Markdown report" subheader="Base pronta per export PDF" />
              <CardContent>
                <Box component="pre" sx={{ whiteSpace: 'pre-wrap', fontFamily: 'monospace', fontSize: 13, m: 0 }}>
                  {report.markdown}
                </Box>
              </CardContent>
            </Card>
          </>
        )}
      </Container>
    </Layout>
  );
}

export default CFOReportPage;
