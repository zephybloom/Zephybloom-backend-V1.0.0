import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

// Pages
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import AnalyzePage from './pages/AnalyzePage';
import SimulatePage from './pages/SimulatePage';
import ChatPage from './pages/ChatPage';
import UnitEconomicsPage from './pages/UnitEconomicsPage';
import RestaurantCFOPage from './pages/RestaurantCFOPage';
import EcommerceCFOPage from './pages/EcommerceCFOPage';
import ConstructionCFOPage from './pages/ConstructionCFOPage';
import WarRoomPage from './pages/WarRoomPage';
import CFOReportPage from './pages/CFOReportPage';
import DataRoomPage from './pages/DataRoomPage';

// Context
import { AuthProvider, ProtectedRoute } from './context/authContext';
import { CompanyProvider } from './context/companyContext';

// Themes
import darkTheme from './theme/darkTheme';

function App() {
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <Router>
        <AuthProvider>
          <CompanyProvider>
            <Routes>
              {/* Public routes */}
              <Route path="/login" element={<LoginPage />} />

              {/* Protected routes */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/war-room"
                element={
                  <ProtectedRoute>
                    <WarRoomPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/report"
                element={
                  <ProtectedRoute>
                    <CFOReportPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/data-room"
                element={
                  <ProtectedRoute>
                    <DataRoomPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/analyze"
                element={
                  <ProtectedRoute>
                    <AnalyzePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/simulate"
                element={
                  <ProtectedRoute>
                    <SimulatePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/chat"
                element={
                  <ProtectedRoute>
                    <ChatPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/unit-economics"
                element={
                  <ProtectedRoute>
                    <UnitEconomicsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/restaurant-cfo"
                element={
                  <ProtectedRoute>
                    <RestaurantCFOPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/ecommerce-cfo"
                element={
                  <ProtectedRoute>
                    <EcommerceCFOPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/construction-cfo"
                element={
                  <ProtectedRoute>
                    <ConstructionCFOPage />
                  </ProtectedRoute>
                }
              />

              {/* Redirects */}
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route path="*" element={<Navigate to="/dashboard" />} />
            </Routes>
          </CompanyProvider>
        </AuthProvider>
      </Router>
    </ThemeProvider>
  );
}

export default App;
