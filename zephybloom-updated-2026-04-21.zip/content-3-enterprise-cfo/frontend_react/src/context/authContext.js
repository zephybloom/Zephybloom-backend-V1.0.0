import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import api from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Verify token on mount
  useEffect(() => {
    if (token) {
      try {
        if (token.startsWith('demo.')) {
          const demoUser = JSON.parse(localStorage.getItem('demo_user') || '{}');
          setUser(demoUser.email ? demoUser : { email: 'demo@example.com', demo: true });
          api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
          setLoading(false);
          return;
        }

        const decoded = jwtDecode(token);
        if (decoded.exp * 1000 > Date.now()) {
          setUser(decoded);
          api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        } else {
          logout();
        }
      } catch (e) {
        logout();
      }
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (email, password) => {
    setError(null);
    try {
      const response = await api.post('/auth/login', { email, password });
      const { access_token } = response.data;
      
      localStorage.setItem('token', access_token);
      setToken(access_token);
      
      const decoded = jwtDecode(access_token);
      setUser(decoded);
      
      api.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
      return true;
    } catch (err) {
      const message = err.response?.data?.detail || 'Login failed. Please try again.';
      setError(message);
      return false;
    }
  };

  const demoLogin = () => {
    const demoToken = `demo.${Date.now()}`;
    const demoUser = {
      email: 'demo@example.com',
      name: 'Demo CFO',
      tenant_id: 'demo_tenant',
      demo: true,
    };

    localStorage.setItem('token', demoToken);
    localStorage.setItem('demo_user', JSON.stringify(demoUser));
    setToken(demoToken);
    setUser(demoUser);
    api.defaults.headers.common['Authorization'] = `Bearer ${demoToken}`;
    return true;
  };

  const register = async (email, password, full_name) => {
    setError(null);
    try {
      await api.post('/auth/register', { email, password, full_name });
      return await login(email, password);
    } catch (err) {
      const message = err.response?.data?.detail || 'Registration failed. Please try again.';
      setError(message);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('demo_user');
    setToken(null);
    setUser(null);
    delete api.defaults.headers.common['Authorization'];
  };

  const isAuthenticated = !!token && !!user;

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      error,
      login,
      demoLogin,
      register,
      logout,
      isAuthenticated,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate('/login');
    }
  }, [loading, isAuthenticated, navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return isAuthenticated ? children : null;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
