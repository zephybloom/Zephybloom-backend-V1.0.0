import React, { createContext, useState, useContext } from 'react';

const CompanyContext = createContext();

const readStoredJson = (key, fallback) => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
};

export const CompanyProvider = ({ children }) => {
  const [companyData, setCompanyData] = useState(() => readStoredJson('cfo_company_data', {
    company_name: '',
    fatturato: 1000000,
    costi_variabili: 400000,
    costi_fissi: 300000,
    investimenti: 100000,
    settore: 'default',
    dso_days: null,
    dio_days: null,
    dpo_days: null,
  }));

  const [operationalDataBySector, setOperationalDataBySector] = useState(() =>
    readStoredJson('cfo_operational_data_by_sector', {})
  );
  const [currentAnalysis, setCurrentAnalysis] = useState(null);
  const [analysisHistory, setAnalysisHistory] = useState([]);
  const [simulations, setSimulations] = useState([]);
  const [chatHistory, setChatHistory] = useState([]);

  const updateCompanyData = (data) => {
    setCompanyData(prev => {
      const next = {
        ...prev,
        ...data,
      };
      localStorage.setItem('cfo_company_data', JSON.stringify(next));
      return next;
    });
  };

  const saveOperationalData = (sector, data) => {
    const normalizedSector = sector || 'default';
    setOperationalDataBySector(prev => {
      const next = {
        ...prev,
        [normalizedSector]: {
          ...data,
          saved_at: new Date().toISOString(),
        },
      };
      localStorage.setItem('cfo_operational_data_by_sector', JSON.stringify(next));
      return next;
    });
  };

  const getOperationalData = (sector) => {
    const normalizedSector = sector || companyData.settore || 'default';
    return operationalDataBySector[normalizedSector] || null;
  };

  const saveAnalysis = (analysis, companyDataSnapshot = companyData) => {
    setCurrentAnalysis(analysis);
    setAnalysisHistory(prev => [
      {
        ...analysis,
        timestamp: new Date().toISOString(),
        companyData: { ...companyDataSnapshot },
      },
      ...prev,
    ].slice(0, 20)); // Keep last 20 analyses
  };

  const saveSimulation = (simulation) => {
    setSimulations(prev => [
      {
        ...simulation,
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ].slice(0, 10)); // Keep last 10 simulations
  };

  const addChatMessage = (message) => {
    setChatHistory(prev => [
      ...prev,
      {
        ...message,
        timestamp: new Date().toISOString(),
      },
    ]);
  };

  const clearChatHistory = () => {
    setChatHistory([]);
  };

  return (
    <CompanyContext.Provider value={{
      companyData,
      updateCompanyData,
      operationalDataBySector,
      saveOperationalData,
      getOperationalData,
      currentAnalysis,
      saveAnalysis,
      analysisHistory,
      simulations,
      saveSimulation,
      chatHistory,
      addChatMessage,
      clearChatHistory,
    }}>
      {children}
    </CompanyContext.Provider>
  );
};

export const useCompany = () => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within CompanyProvider');
  }
  return context;
};
