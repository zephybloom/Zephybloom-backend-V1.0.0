import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://127.0.0.1:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

// Handle response errors
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API Methods
export const authApi = {
  login: (email, password) =>
    api.post('/auth/login', { email, password }),
  register: (email, password, full_name) =>
    api.post('/auth/register', { email, password, full_name }),
};

export const cfoApi = {
  analyze: (data) =>
    api.post('/cfo/analyze', data),
  aiAnalyze: (data, specificQuestion = '', useMock = true) =>
    api.post('/cfo/ai-analyze', data, {
      params: {
        specific_question: specificQuestion || undefined,
        use_mock: useMock,
      },
    }),
  simulate: (data) =>
    api.post('/cfo/simulate', data),
  unitEconomics: (rows) =>
    api.post('/cfo/unit-economics', { rows }),
  restaurantAnalyze: (data) =>
    api.post('/cfo/restaurant/analyze', { data }),
  restaurantSimulate: (data, scenario) =>
    api.post('/cfo/restaurant/simulate', { data, scenario }),
  ecommerceAnalyze: (data) =>
    api.post('/cfo/ecommerce/analyze', { data }),
  ecommerceSimulate: (data, scenario) =>
    api.post('/cfo/ecommerce/simulate', { data, scenario }),
  constructionAnalyze: (data) =>
    api.post('/cfo/construction/analyze', { data }),
  constructionSimulate: (data, scenario) =>
    api.post('/cfo/construction/simulate', { data, scenario }),
  warRoom: (operationalDataBySector, activeSector) =>
    api.post('/cfo/war-room', {
      operational_data_by_sector: operationalDataBySector,
      active_sector: activeSector,
    }),
  monthlyReport: (payload) =>
    api.post('/cfo/report/monthly', payload),
  monthlyReportPdf: (payload) =>
    api.post('/cfo/report/monthly/pdf', payload, { responseType: 'blob' }),
  decisionFeedback: (decisionId, feedback) =>
    api.post(`/cfo/decision/${encodeURIComponent(decisionId)}/feedback`, feedback),
  decisionAccuracy: () =>
    api.get('/cfo/decisions/accuracy'),
  memorySnapshot: (payload) =>
    api.post('/cfo/memory/snapshot', payload),
  memorySummary: (companyId = 'default', months = 12) =>
    api.get(`/cfo/memory/summary?company_id=${encodeURIComponent(companyId)}&months=${months}`),
  memoryDecisions: (statusFilter = '') =>
    api.get(`/cfo/memory/decisions${statusFilter ? `?status_filter=${encodeURIComponent(statusFilter)}` : ''}`),
  memoryDecisionDetail: (decisionId) =>
    api.get(`/cfo/memory/decisions/${encodeURIComponent(decisionId)}`),
  updateMemoryDecision: (decisionId, payload) =>
    api.patch(`/cfo/memory/decisions/${encodeURIComponent(decisionId)}`, payload),
  dataRoom: (companyData, operationalDataBySector, activeSector, options = {}) =>
    api.post('/cfo/data-room', {
      company_id: options.companyId || companyData.company_name || 'default',
      company_data: companyData,
      operational_data_by_sector: operationalDataBySector,
      active_sector: activeSector,
      save: Boolean(options.save),
      merge: options.merge !== false,
    }),
  getDataRoom: (companyId = 'default') =>
    api.get(`/cfo/data-room?company_id=${encodeURIComponent(companyId)}`),
  dataRoomContext: (companyId = 'default') =>
    api.get(`/cfo/data-room/context?company_id=${encodeURIComponent(companyId)}`),
  dataRoomHistory: (companyId = 'default', limit = 12) =>
    api.get(`/cfo/data-room/history?company_id=${encodeURIComponent(companyId)}&limit=${limit}`),
  importDataRoomRows: (payload) =>
    api.post('/cfo/data-room/import', payload),
  dataRequirements: (sector, providedData = {}) =>
    api.post('/cfo/data-requirements', { sector, provided_data: providedData }),
  answerQuality: (payload) =>
    api.post('/cfo/answer-quality', payload),
  chat: (data) =>
    api.post('/cfo/chat', data),
  trends: (companyId = 'default') =>
    api.get(`/cfo/trends?company_id=${encodeURIComponent(companyId)}`),
};

export default api;
