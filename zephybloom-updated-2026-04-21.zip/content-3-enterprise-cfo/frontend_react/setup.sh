#!/bin/bash

# CFO React App - Setup Script

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║        CFO Dashboard - Frontend Setup                          ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Step 1: Check Node.js
echo "📌 Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install from https://nodejs.org/"
    exit 1
fi
echo "✅ Node.js $(node --version)"
echo "✅ npm $(npm --version)"
echo ""

# Step 2: Install dependencies
echo "📌 Installing dependencies..."
if [ -d "node_modules" ]; then
    echo "   Dependencies already installed, skipping..."
else
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ npm install failed"
        exit 1
    fi
fi
echo "✅ Dependencies installed"
echo ""

# Step 3: Setup environment
echo "📌 Setting up environment..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "✅ Created .env from .env.example"
else
    echo "✅ .env already exists"
fi
echo ""

# Step 4: Display info
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║        ✅ Setup Complete!                                     ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "🚀 To start the development server:"
echo "   npm start"
echo ""
echo "📖 App will open at: http://localhost:3000"
echo ""
echo "🔗 Backend API: http://127.0.0.1:8888"
echo ""
echo "📊 Default Demo Login:"
echo "   Email: demo@example.com"
echo "   Password: DemoPassword123"
echo ""
echo "📝 Build for production:"
echo "   npm run build"
echo ""
