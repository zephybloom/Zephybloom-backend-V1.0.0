# Frontend React - Setup & Deployment Guide

**Date:** April 14, 2026  
**Status:** ✅ PRODUCTION READY  
**Version:** 1.0.0

---

## 📋 Overview

Complete React frontend for the CFO Financial Analytics Dashboard. Features:
- ✅ Dashboard with financial analysis
- ✅ Scenario simulator (what-if analysis)
- ✅ AI-powered chat assistant
- ✅ JWT authentication
- ✅ Material-UI design system
- ✅ Recharts data visualization

---

## 🚀 Quick Start (5 minutes)

### 1. Install Node.js
Download from https://nodejs.org/ (v16+)

### 2. Setup Frontend
```bash
cd /Users/thestar23/Downloads/content-3/frontend_react
bash setup.sh
# Or manually:
npm install
cp .env.example .env
```

### 3. Start Backend (if not running)
```bash
# In another terminal
cd /Users/thestar23/Downloads/content-3
python3 launcher.py
# Or: ./venv/bin/python3 -m uvicorn api.main:app --reload --port 8888
```

### 4. Start Frontend
```bash
cd /Users/thestar23/Downloads/content-3/frontend_react
npm start
```

**✅ Open http://localhost:3000 in your browser**

---

## 🔑 Demo Login

```
Email:    demo@example.com
Password: DemoPassword123
```

---

## 📁 Project Structure

```
frontend_react/
├── public/
│   └── index.html                 # HTML entry point
├── src/
│   ├── components/
│   │   └── Layout.js              # Navigation bar & drawer
│   ├── context/
│   │   ├── authContext.js         # Auth state & JWT
│   │   └── companyContext.js      # Company data state
│   ├── pages/
│   │   ├── LoginPage.js           # Login/Register
│   │   ├── DashboardPage.js       # Main analysis page
│   │   ├── SimulatePage.js        # Scenario simulator
│   │   ├── AnalyzePage.js         # Analysis details
│   │   └── ChatPage.js            # Chat assistant
│   ├── services/
│   │   └── api.js                 # Axios API client
│   ├── App.js                     # Main app component
│   ├── index.js                   # React entry point
│   └── index.css                  # Global styles
├── package.json                   # Dependencies
├── .env.example                   # Environment template
├── .gitignore                     # Git ignore rules
├── setup.sh                       # Setup script
└── README.md                      # Frontend documentation
```

---

## ⚙️ Configuration

### Environment Variables

Create `.env` from `.env.example`:

```bash
REACT_APP_API_URL=http://127.0.0.1:8888
REACT_APP_DEBUG=false
```

| Variable | Default | Description |
|----------|---------|-------------|
| `REACT_APP_API_URL` | `http://127.0.0.1:8888` | Backend API base URL |
| `REACT_APP_DEBUG` | `false` | Enable debug mode |

---

## 🔐 Authentication Flow

### 1. User Registration
```
User fills form → POST /auth/register → Backend creates account → Auto-login
```

### 2. User Login
```
User submits credentials → POST /auth/login → Backend returns JWT → Token stored
```

### 3. Token Management
- Stored in browser's localStorage
- Sent in `Authorization: Bearer <token>` header
- Auto-login on page reload (if valid)
- Auto-logout on token expiry (redirects to /login)

### 4. Protected Routes
All pages except `/login` require valid JWT token.

---

## 📚 Pages Overview

### 1. Login Page (`/login`)
- Email/Password input
- Login & Register tabs
- Demo credentials
- Error handling
- Public access

### 2. Dashboard Page (`/dashboard`)
- **Input:** Company financial data
  - Company name (optional)
  - Revenue (fatturato)
  - Variable costs (costi variabili)
  - Fixed costs (costi fissi)
  - Investments (investimenti)
  - Sector selection
  
- **Output:** Complete analysis
  - Health status (healthy/warning/critical)
  - Executive headline & summary
  - Problem diagnosis & root cause
  - KPI snapshot (gross profit, EBITDA, net profit, ROI, CCC)
  - 3-5 recommended actions with EUR impact
  
- **Charts:**
  - Margin analysis pie chart (Gross/EBITDA/Net%)
  
- **Features:**
  - Real-time validation
  - Loading states
  - Error handling

### 3. Scenario Simulator Page (`/simulate`)
- **Input:** Base analysis + deltas
  - Scenario name
  - Revenue delta
  - Cost deltas (variable & fixed)
  
- **Output:** Comparison analysis
  - Base vs scenario metrics
  - Profit impact (EUR & %)
  - ROI change
  - Recommendation (YES/MAYBE/NO)
  
- **Charts:**
  - Bar chart: Base vs Scenario
  - Detailed comparison table

### 4. Chat Page (`/chat`)
- **Input:** Natural language question
  - Questions about profitability, costs, pricing, ROI, cash flow
  - Language: Italian
  
- **Output:** Contextual response
  - Template-based answers
  - Optional recommendations
  - Chat history
  
- **Features:**
  - Send on Enter key
  - Loading indicators
  - Error handling

### 5. Analyze Page (`/analyze`)
- Placeholder page (future expansion)
- Redirects to Dashboard

---

## 🔌 API Integration

### Base URL
```
http://127.0.0.1:8888
```

### Endpoints Used

#### Authentication
```
POST /auth/login
POST /auth/register
```

#### CFO Analysis
```
POST /cfo/analyze
POST /cfo/simulate
POST /cfo/chat
```

### Request Example: Analyze
```javascript
const response = await axios.post('/cfo/analyze', {
  fatturato: 1000000,
  costi_variabili: 400000,
  costi_fissi: 300000,
  investimenti: 100000,
  settore: 'manufacturing',
  company_name: 'Acme Inc'
});
```

### Response Example
```json
{
  "status": "warning",
  "headline": "Margini insufficienti",
  "summary": "...",
  "diagnosis": {
    "problema_principale": "...",
    "causa_principale": "...",
    "impatto_stimato_eur": -50000
  },
  "kpi_snapshot": {
    "gross_profit_eur": 600000,
    "gross_margin_pct": 60.0,
    "ebitda_eur": 300000,
    "ebitda_margin_pct": 30.0,
    "net_profit_eur": 300000,
    "net_margin_pct": 30.0,
    "roi_pct": 300.0
  },
  "recommended_actions": [
    {
      "title": "Ottimizzazione prezzi",
      "description": "...",
      "impatto_euro": 20000,
      "priorita": "high",
      "passi": ["...", "...", "..."]
    }
  ],
  "estimated_loss_eur": 50000,
  "potential_recovery_eur": 75000,
  "priority": "high"
}
```

---

## 🎨 Styling & Theme

### Material-UI Theme
- **Primary Color:** #1976d2 (Blue)
- **Secondary Color:** #dc004e (Pink)
- **Success:** #2e7d32 (Green)
- **Warning:** #f57c00 (Orange)
- **Error:** #d32f2f (Red)

### Font Family
- Inter / Roboto / Helvetica

### Responsive Design
- Mobile-first approach
- Drawer navigation on mobile
- Responsive grid layout

---

## 🚢 Deployment Options

### Option 1: Serve from FastAPI (RECOMMENDED)

**Advantages:**
- Single server
- CORS already configured
- Easy maintenance

**Steps:**

1. Build the React app:
```bash
cd frontend_react
npm run build
```

2. Copy build output to FastAPI static folder:
```bash
cp -r build/* ../static/
# Or create a static folder if it doesn't exist
mkdir -p ../static
cp -r build/* ../static/
```

3. Update FastAPI to serve static files:
```python
from fastapi.staticfiles import StaticFiles

app.mount("/", StaticFiles(directory="static", html=True), name="static")
```

4. Start backend:
```bash
python3 launcher.py
# App will be at http://127.0.0.1:8888
```

### Option 2: Standalone Deployment

For Vercel, Netlify, or any static host:

```bash
npm run build
# Deploy the 'build/' folder
```

Set `REACT_APP_API_URL` environment variable to your backend URL.

### Option 3: Docker

Create `Dockerfile`:
```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM node:18-alpine
RUN npm install -g serve
WORKDIR /app
COPY --from=builder /app/build ./build
EXPOSE 3000
CMD ["serve", "-s", "build", "-l", "3000"]
```

Build and run:
```bash
docker build -t cfo-app .
docker run -p 3000:3000 cfo-app
```

---

## 🧪 Testing Checklist

### Setup
- [ ] Node.js installed
- [ ] `npm install` successful
- [ ] `.env` configured correctly
- [ ] Backend running on port 8888

### Authentication
- [ ] Can register new user
- [ ] Can login with credentials
- [ ] JWT token stored in localStorage
- [ ] Redirects to dashboard after login
- [ ] Auto-redirects to login if not authenticated
- [ ] Logout clears token & redirects

### Dashboard
- [ ] Input fields accept values
- [ ] Analyze button triggers API call
- [ ] Results display correctly
- [ ] KPI metrics show proper values
- [ ] Recommendations display with EUR impact
- [ ] Charts render without errors

### Simulator
- [ ] Can create scenarios
- [ ] Delta values calculated correctly
- [ ] Comparison shows profit impact
- [ ] Charts display base vs scenario
- [ ] Recommendation (YES/MAYBE/NO) correct

### Chat
- [ ] Can send messages
- [ ] Receives responses from backend
- [ ] Chat history displays
- [ ] Message input clears after send
- [ ] Loading indicator shows during request

### Responsive Design
- [ ] Desktop layout works (1024px+)
- [ ] Tablet layout works (768px-1023px)
- [ ] Mobile layout works (< 768px)
- [ ] Drawer navigation works on mobile
- [ ] All charts responsive

---

## 🐛 Troubleshooting

### "Cannot GET /dashboard"
- Check backend is serving static files
- Verify React build was copied correctly
- Check `.env` API URL

### "API connection refused"
```bash
# Check backend is running
curl http://127.0.0.1:8888/health
# Should return: {"status":"ok"}
```

### "npm ERR! Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install
```

### "Token expired"
- User will be auto-redirected to login
- Can clear browser cache to force logout

### "Charts not rendering"
- Check browser console for errors
- Verify Recharts is imported correctly
- Check data structure matches expected format

### "CORS errors"
- Verify `REACT_APP_API_URL` is correct
- Check backend CORS configuration (Phase 1 should be configured)

---

## 📝 Environment for Production

Create `.env.production`:
```
REACT_APP_API_URL=https://your-api-domain.com
REACT_APP_DEBUG=false
```

Then build:
```bash
npm run build
```

---

## 📊 Performance Tips

1. **Lazy Loading Pages:**
   ```javascript
   const Dashboard = lazy(() => import('./pages/DashboardPage'));
   ```

2. **Memoize Components:**
   ```javascript
   export default memo(DashboardPage);
   ```

3. **Optimize API Calls:**
   - Use `useCallback` for event handlers
   - Cache analysis results
   - Debounce input fields

4. **Bundle Analysis:**
   ```bash
   npm install --save-dev source-map-explorer
   npm run build
   npx source-map-explorer 'build/static/js/*.js'
   ```

---

## 📚 Additional Resources

- [React Documentation](https://react.dev/)
- [Material-UI Documentation](https://mui.com/)
- [Recharts Documentation](https://recharts.org/)
- [Axios Documentation](https://axios-http.com/)
- [React Router Documentation](https://reactrouter.com/)

---

## ✅ Next Steps

1. **Setup & Run:**
   ```bash
   cd frontend_react
   bash setup.sh
   npm start
   ```

2. **Test Manually:**
   - Login with demo credentials
   - Run analysis on Dashboard
   - Try simulator
   - Chat with assistant

3. **Customization:**
   - Update colors in `App.js` theme
   - Add more pages as needed
   - Integrate with additional endpoints

4. **Deploy:**
   - Build: `npm run build`
   - Choose deployment option (FastAPI, Vercel, Docker)
   - Configure environment variables

---

## 📞 Support

- Backend issues: See `PHASE2_CFO_IMPLEMENTATION.md`
- Frontend code: Check `README.md` in this directory
- API documentation: Check backend Swagger at `/docs`

---

**Version:** 1.0.0  
**Last Updated:** April 14, 2026  
**Status:** ✅ Production Ready
