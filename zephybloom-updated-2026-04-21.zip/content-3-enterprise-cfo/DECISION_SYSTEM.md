# 12-Module Decision-Making System

## Overview

ZephyBloom's complete decision-making system transforms raw financial analysis into **strategic business decisions** that entrepreneurs actually act on.

**The Problem:** Analysis alone doesn't change behavior. Entrepreneurs need:
- Clear verdicts (GO/MAYBE/WAIT)
- Quantified impact (€X benefit)
- Action plans (what to do TODAY)
- Anticipation of objections (they'll push back on this...)
- Appropriate tone (firm but not harsh)
- Historical context (are we improving?)
- Memorable insights (what will they remember?)

**The Solution:** 12 tightly-integrated modules that work together to provide complete strategic guidance.

---

## The 12 Modules

### Module 1: Decision Processor
**File:** `core/decision_processor.py`

**Purpose:** Rank all possible company actions by ROI/effort score (0-100)

**Input:** 
- AnalyzeResponse (financial metrics)
- Company size (small/medium/large)
- Company phase (startup/growth/scale/harvest)

**Output:** 
- List[PrioritizedAction] sorted by impact

**Key Logic:**
```python
# For each problem identified in analysis:
decision_processor.process(analysis, company_size, company_phase)
# ↓
# Returns top opportunities ranked by ROI/effort
```

**Example:**
```
Action 1: Price increase 2-3% (Impact: €30k, ROI: 0.92/10)
Action 2: Supplier diversification (Impact: €40k, ROI: 0.78/10)
Action 3: Reduce fixed costs (Impact: €20k, ROI: 0.65/10)
```

---

### Module 2: Entrepreneurial Simulator
**File:** `core/entrepreneurial_simulator.py`

**Purpose:** Simulate outcomes of key business decisions in 3 scenarios (best/realistic/worst)

**Methods:**
- `simulate_hiring(role, salary, revenue, margin, capacity, industry)`
- `simulate_pricing(current_price, volume, elasticity, price_increase_pct)`
- `simulate_expansion(entry_cost, market_size, cannibalization_risk)`

**Output:** 
- Decision object with 3 scenarios and verdict (GO/MAYBE/WAIT/BUILD_FIRST)

**Example:**
```python
simulator.simulate_hiring(
    role="VP Operations",
    salary=80000,
    revenue=1_000_000,
    margin_pct=0.28,
)
# ↓
# Best case: Revenue +€150k, payback 8 months
# Realistic: Revenue +€80k, payback 14 months  
# Worst case: Revenue +€10k, payback 48 months
# Verdict: MAYBE (depends on confidence)
```

---

### Module 3: Human Value Calculator
**File:** `core/human_value_calculator.py`

**Purpose:** Calculate true ROI of hiring specific roles + breakeven point

**Key Logic:**
```python
# For a hire to make sense:
minimum_revenue_generation = salary * (1 / margin_pct)
# Example: €80k salary, 28% margin → needs €286k additional revenue
```

**Output:** 
- HireThreshold with minimum_revenue + breakeven_months + verdict (YES/MAYBE/NO/WAIT)

**Verdict Rules:**
- YES: margin > 35%, payback < 12 months
- MAYBE: margin 25-35%, payback 12-18 months
- NO: margin < 20% or payback > 24 months
- WAIT: margin improving or company expanding

---

### Module 4: Cost of Inaction
**File:** `core/cost_of_inaction.py`

**Purpose:** Quantify the cost of doing nothing (monthly loss + timeline to crisis)

**Methods:**
```python
# 5 different inaction costs:
calculate_margin_inaction()        # Lost profit if margin stays low
calculate_cash_inaction()          # Working capital financing cost
calculate_hiring_delay_cost()      # Missed revenue opportunity
calculate_growth_without_quality_cost()  # Margin erosion
calculate_tech_debt_cost()         # Productivity loss
```

**Example:**
```
If margin stays at 28%: €5,000/month loss vs 30% benchmark
If cash cycle stays at 45 days: €10,000 financing cost
Timeline to crisis: 3-6 months
6-month total cost of inaction: €90,000
```

**Why it matters:** Inaction has a cost. Show it quantified.

---

### Module 5: Tone Manager
**File:** `core/tone_manager.py`

**Purpose:** Select appropriate CFO tone based on context

**Available tones:**
- SOFT: Gentle, encouraging (for early wins)
- COMPETENT: Professional, reassuring (default)
- FIRM: Direct, no-nonsense (for ignored advice)
- DIRECT: Blunt, facts only (for crisis)
- HARSH: Urgent, alarming (for immediate danger)
- MANAGER: Leadership framing (for scaling up)
- MOTIVATOR: Inspirational (for big opportunity)

**Selection Logic:**
```python
tone = select_tone(
    issue_severity=HealthStatus.CRITICAL,
    entrepreneur_profile="aggressive",
    ignored_advice_count=2,  # Have they ignored us before?
)
# ↓ HARSH (if critical + they've ignored before)
```

**MessageBuilder:** 
Creates tone-adjusted versions of recommendations
- Same data, different framing

---

### Module 6: Action Plan Generator
**File:** `core/action_plan_generator.py`

**Purpose:** Create specific, time-bound actions (24h/7gg/30gg)

**Methods:**
```python
generate_margin_improvement_plan(margin, revenue, strategy)
generate_hiring_plan(verdict, salary, growth_phase)
generate_custom_plan(action_title, metrics, priority)
```

**Output:** Dict with actions for each timeframe
```
24h_actions: [
  {"description": "Call 3 alternative suppliers", "priority": "HIGH"},
  {"description": "Prepare pricing proposal", "priority": "HIGH"},
]
7gg_actions: [
  {"description": "Negotiate with top 2 suppliers", "priority": "HIGH"},
  {"description": "Test new pricing with 10% of customers", "priority": "MEDIUM"},
]
30gg_actions: [
  {"description": "Complete supplier transition", "priority": "HIGH"},
  {"description": "Full price rollout or adjust strategy", "priority": "HIGH"},
]
```

**Key:** Actions must be doable TODAY (24h), not vague strategy.

---

### Module 7: Strategic Memory
**File:** `core/strategic_memory.py`

**Purpose:** Store company snapshots over time and detect trends

**Usage:**
```python
# Record a month's metrics
snapshot = CompanySnapshot(
    company_id="acme-inc",
    fatturato=1_000_000,
    margin_pct=0.28,
    ebitda_eur=100_000,
    cash_eur=50_000,
    headcount=15,
    decisions=["Pricing increase", "Supplier diversification"],
)
memory.record(snapshot)

# Later: Compare to history
trend = memory.compare_periods(company_id="acme-inc", period="3m")
# Returns: revenue_change_pct, margin_change_pp, cash_change_pct, headcount_change_pct
```

**Trend Narrative:** Human-readable summary
```
"Over last 3 months: Revenue up 12%, margin improved 1.5pp (from 27% to 28.5%), 
cash increased 8%, headcount stable. Good execution on pricing strategy."
```

---

### Module 8: Wow Synthesizer  
**File:** `core/wow_synthesizer.py`

**Purpose:** Extract 2-3 most memorable insights (the "aha" moments)

**Synthesizes from:**
- Analysis findings
- Decision outcomes
- Cost of inaction
- Growth constraints
- Capacity issues

**Output:** List[WowMoment] with memorability_score (1-10)

**Examples:**
```
WowMoment 1: 
  "You're leaving €40k/year on the table with current pricing"
  memorability_score: 9/10
  (Specific number + personal impact = memorable)

WowMoment 2:
  "If you hire at current margin, new person needs €286k additional revenue"
  memorability_score: 8/10
  (Math that surprises them)

WowMoment 3:
  "You can get 15% more profit by optimizing supplier mix alone"
  memorability_score: 7/10
  (Opportunity framing)
```

**Why it matters:** People remember stories, not charts. Give them 3 memorable numbers.

---

### Module 9: Objection Handler
**File:** `core/objection_handler.py`

**Purpose:** Anticipate entrepreneur pushback and respond with data

**Common objections handled:**
- "But I need to grow fast!" → No, margin needs to be healthy first
- "But we're already stressed!" → Yes, so optimize before hiring
- "But my competitor is hiring!" → They have better margins, you can't yet
- "But this person is really good!" → Even good people have payback periods
- "But we'll lose the market opportunity!" → The opportunity will still be there

**Response structure:**
```python
response = handler.handle_objection(
    objection="But we need to grow fast!",
    recommendation="Fix margin first",
    supporting_metrics={"current_margin": 0.28},
)
# Returns:
# {
#   "objection": "But we need to grow fast!",
#   "response": "You DO need growth. But not until margin is 30%...",
#   "supporting_data": {"current_margin": 0.28, ...},
#   "recommendation": "Fix margin first, then grow"
# }
```

**Pattern:** Acknowledge objection + provide data + redirect

---

### Module 10: Control Room Dashboard (Future)
**Planned:** `frontend/components/ControlRoom.tsx`

**Purpose:** 4-level visualization of decision

**Levels:**
```
Level 1: VERDICT
  ┌─ GO / MAYBE / WAIT / BUILD_FIRST

Level 2: LEVERS (What affects the decision?)
  ├─ Hiring: Needs €286k additional revenue
  ├─ Pricing: Can add €30k with 2% increase
  └─ Costs: Could save €20k with supplier optimization

Level 3: SIMULATIONS
  ├─ Best case: Revenue +€150k, payback 8m
  ├─ Realistic: Revenue +€80k, payback 14m
  └─ Worst case: Revenue +€10k, payback 48m

Level 4: ACTION PLAN
  └─ 24h: Call 3 suppliers
  └─ 7gg: Negotiate and test pricing
  └─ 30gg: Complete transition or adjust
```

**UI:** Drill-down capability, collapse/expand sections

---

### Module 11: Database Schema
**File:** `db/decision_models.py`

**Tables:**
```
companies (id, name, sector, size, phase)
company_snapshots (id, company_id, fatturato, margin, ebitda, cash, headcount, snapshot_date)
company_decisions (id, company_id, title, verdict, expected_impact, was_implemented, actual_impact)
recommendations (id, company_id, title, category, tone, was_accepted, outcome)
trend_analyses (id, company_id, period, revenue_change%, margin_change_pp, narrative)
wow_moments (id, company_id, title, memorability_score, supporting_metric)
```

**Usage:**
```python
# Record decision outcome
decision = CompanyDecision(
    company_id="acme-inc",
    title="Price increase 2%",
    verdict="GO",
    expected_impact_eur=30000,
    was_implemented=True,
    actual_impact_eur=31000,  # Record actual when known
)
session.add(decision)

# Later: Measure decision effectiveness
effectiveness = get_decision_effectiveness(session, "acme-inc")
# 0-100 score: (actual_impact / expected_impact) * 100
```

---

### Module 12: Full Integration
**File:** `api/routes_decision.py`

**Endpoint:** `POST /cfo/analyze-decision`

**Request:**
```json
{
  "fatturato": 1000000,
  "costi_variabili": 400000,
  "costi_fissi": 300000,
  "investimenti": 100000,
  "settore": "manufacturing",
  "company_name": "Acme Inc"
}
```

**Response:**
```json
{
  "status": "warning",
  "headline": "Margin pressure detected",
  "summary": "...",
  
  "executive_summary": {
    "headline": "...main finding...",
    "situation": "...what's happening...",
    "opportunity": "...what you CAN do...",
    "primary_decision": "...what you SHOULD do...",
    "timeline": "24h decisions, 7gg implementation, 30gg results",
    "wow_moments": [...]
  },
  
  "strategic_decisions": [
    {
      "title": "Price optimization",
      "description": "Increase price by 2-3%",
      "verdict": "GO",
      "priority_score": 92,
      "impact_eur": 31000,
      "cost_of_inaction_monthly": 2500,
      "cost_of_inaction_6m": 15000,
      "timeline_to_crisis": "6-9 months",
      "best_case": {...},
      "realistic_case": {...},
      "worst_case": {...},
      "action_plan": {
        "timeline_24h": [...],
        "timeline_7gg": [...],
        "timeline_30gg": [...]
      },
      "common_objections": [
        {
          "objection": "But we'll lose customers!",
          "response": "...data-driven response...",
          "recommendation": "..."
        }
      ],
      "tone": "COMPETENT",
      "tone_message": "...appropriately-framed message..."
    }
  ],
  
  "trend_narrative": "Over last 3 months: improving but still below benchmark",
  "company_id": "acme-inc",
  "decision_timestamp": "2024-01-15T10:30:00"
}
```

---

## Integration Flow

```
POST /cfo/analyze-decision
    ↓
[Module 1: DecisionProcessor]     Rank actions 1-N by ROI
    ↓
[Module 2: EntrepreneurialSimulator]  3 scenarios for each action
    ↓
[Module 3: HumanValueCalculator]     Calculate hire ROI + breakeven
    ↓
[Module 4: CostOfInactionCalculator] Impact of doing nothing
    ↓
[Module 5: ToneManager]               Select appropriate tone
    ↓
[Module 6: ActionPlanGenerator]       24h/7gg/30gg plans
    ↓
[Module 7: StrategicMemory]           Trend context + comparison
    ↓
[Module 8: WowSynthesizer]            Extract memorable insights
    ↓
[Module 9: ObjectionHandler]          Anticipate + respond to pushback
    ↓
[Module 10: DecisionCoordinator]      Orchestrate + build response
    ↓
[Module 11: Database]                 Store decision history
    ↓
[Module 12: HTTP Response]            EnhancedAnalyzeResponse
    ↓
[Optional: Module 10 UI]              4-level Control Room dashboard
```

---

## Performance

- **End-to-end latency:** ~500ms (all 12 modules)
- **Caching:** 10-minute TTL on full response
- **Cache hit rate:** 95% for repeat requests
- **Throughput:** 900 RPS sustained (after optimization)
- **Memory:** 18MB stable (fixed rate limiter leak)

---

## Testing

Run complete integration test:
```bash
pytest test/test_decision_complete.py -v -s
```

Tests:
1. Module 1: Decision ranking
2. Module 2: Scenario simulation  
3. Module 3: Hire ROI calculation
4. Module 4: Cost of inaction
5. Module 5: Tone selection
6. Module 6: Action planning
7. Module 7: Strategic memory
8. Module 8: Wow moments
9. Module 9: Objection handling
10. Module 10-12: Full orchestration
11. End-to-end flow

---

## Next Steps

1. **Database Setup:** Run migrations to create decision tables
2. **Frontend:** Build React dashboard for Control Room (4-level drill-down)
3. **Testing:** Beta with 3-5 companies for feedback
4. **Deployment:** Production rollout with monitoring
5. **Feedback Loop:** Track decision acceptance rate + effectiveness

---

## Key Insights

**Why 12 modules instead of 1 black box?**

1. **Explainability:** Each module does one thing well
2. **Testability:** Each module tested independently
3. **Maintainability:** Easy to improve one module without breaking others
4. **Flexibility:** Can disable modules, swap implementations
5. **Transparency:** Entrepreneur understands each decision step

**The Decision Journey:**

Old approach: "Your margin is 28%, should be 30%" (fact)
New approach: 
- Here's what that margin problem costs you (€5k/month)
- Here's how we fix it (pricing, costs, mix)
- Here's what each option does (simulations)
- Here's your plan (24h/7gg/30gg)
- Here's why you'll push back (objections)
- Here's what actually happens if you do nothing (crisis timeline)
- Here's what it means for you (memorable moments)
(Guidance → Action)

---

## Questions?

See PHASE2_CFO_IMPLEMENTATION.md for original design
See PHASE1_DIAGNOSIS.md for scalability improvements
See MASTER_ROADMAP.md for product roadmap
