# -*- coding: utf-8 -*-
# content/utils/logging_utils.py — JSON logging con context vars, sampling e SafeLogger
from __future__ import annotations

import json
import logging
import os
import socket
import sys
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Mapping
from contextvars import ContextVar
import random

__all__ = [
    "configure_root_logging",
    "get_logger",
    "bind_context",
    "clear_context",
    "with_extra",
    "convo_id_var",
    "user_id_var",
    "route_var",
    "request_id_var",
]

# ---------------------------------------------------------------------
# Context variables per tracciare richiesta/conversazione
# ---------------------------------------------------------------------
convo_id_var: ContextVar[str] = ContextVar("convo_id", default="-")
user_id_var: ContextVar[str] = ContextVar("user_id", default="-")
route_var: ContextVar[str] = ContextVar("route", default="-")
request_id_var: ContextVar[str] = ContextVar("request_id", default="-")

HOSTNAME = socket.gethostname()
APP_NAME = os.environ.get("APP_NAME", "zephybloom")
APP_ENV = os.environ.get("APP_ENV", os.environ.get("ENV", "dev"))

def _iso8601(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat().replace("+00:00", "Z")

def _safe_json(obj: Any) -> Any:
    """Rende serializzabile in JSON: dict/list ricorsivi, altrimenti str()."""
    try:
        json.dumps(obj)
        return obj
    except Exception:
        if isinstance(obj, Mapping):
            return {str(k): _safe_json(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple, set)):
            return [_safe_json(x) for x in obj]
        return str(obj)

class JsonFormatter(logging.Formatter):
    """Formatter JSON con campi standard, context vars e extra."""
    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "ts": _iso8601(record.created),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "pid": os.getpid(),
            "hostname": HOSTNAME,
            "env": APP_ENV,
            "app": APP_NAME,
            "convo_id": convo_id_var.get(),
            "user_id": user_id_var.get(),
            "route": route_var.get(),
            "request_id": request_id_var.get(),
        }

        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)

        # Raccogli qualsiasi attributo extra presente su record
        reserved = {
            "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
            "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
            "created", "msecs", "relativeCreated", "thread", "threadName", "process",
            "processName",
        }
        extras: Dict[str, Any] = {}
        for k, v in record.__dict__.items():
            if k not in reserved and not k.startswith("_"):
                extras[k] = v
        if isinstance(getattr(record, "extra", None), dict):
            extras.update(record.extra)  # compat

        if extras:
            payload.update({k: _safe_json(v) for k, v in extras.items()})

        return json.dumps(payload, ensure_ascii=False)

class _SamplingFilter(logging.Filter):
    """Tiene tutte le WARN+ e campiona INFO/DEBUG secondo LOG_SAMPLE_RATE (0..1)."""
    def __init__(self, rate: float) -> None:
        super().__init__()
        self.rate = max(0.0, min(rate, 1.0))
    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno >= logging.WARNING:
            return True
        if self.rate >= 1.0:
            return True
        return random.random() < self.rate

def configure_root_logging(level: Optional[str] = None) -> None:
    """
    Configura il root logger con formatter JSON.
    Env supportati:
      - LOG_LEVEL           (default INFO)
      - LOG_SAMPLE_RATE     (0..1, default 1.0)
    """
    lvl = (level or os.environ.get("LOG_LEVEL") or "INFO").upper()
    root = logging.getLogger()
    root.setLevel(lvl)

    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(JsonFormatter())

    try:
        rate = float(os.environ.get("LOG_SAMPLE_RATE", "1.0"))
    except Exception:
        rate = 1.0
    handler.addFilter(_SamplingFilter(rate))

    root.addHandler(handler)

# -------- SafeLogger: accetta kwargs arbitrari e li mette in extra= ----------
class SafeLogger:
    """
    Wrapper che evita errori tipo: logger.info("...", env="prod")
    Sposta automaticamente tutti i kwargs non riservati in 'extra={...}'.
    """
    __slots__ = ("_logger",)
    _RESERVED = {"exc_info", "stack_info", "stacklevel", "extra"}

    def __init__(self, logger: logging.Logger) -> None:
        self._logger = logger

    def _emit(self, level: int, msg: str, *args, **kwargs) -> None:
        extra = kwargs.pop("extra", {}) or {}
        # qualsiasi altro kw → extra
        spill = {k: v for k, v in kwargs.items() if k not in self._RESERVED}
        if spill:
            if not isinstance(extra, dict):
                extra = {"_extra": _safe_json(extra)}
            extra.update(spill)
        # parametri standard (se presenti) restano gestiti da logging
        exc_info = kwargs.get("exc_info", None)
        stack_info = kwargs.get("stack_info", None)
        stacklevel = kwargs.get("stacklevel", 1)
        self._logger.log(level, msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra)

    # Metodi comuni
    def debug(self, msg: str, *args, **kwargs) -> None:   self._emit(logging.DEBUG, msg, *args, **kwargs)
    def info(self, msg: str, *args, **kwargs) -> None:    self._emit(logging.INFO, msg, *args, **kwargs)
    def warning(self, msg: str, *args, **kwargs) -> None: self._emit(logging.WARNING, msg, *args, **kwargs)
    def error(self, msg: str, *args, **kwargs) -> None:   self._emit(logging.ERROR, msg, *args, **kwargs)
    def critical(self, msg: str, *args, **kwargs) -> None:self._emit(logging.CRITICAL, msg, *args, **kwargs)
    def exception(self, msg: str, *args, **kwargs) -> None:
        kwargs["exc_info"] = kwargs.get("exc_info", True)
        self._emit(logging.ERROR, msg, *args, **kwargs)

    # Accesso trasparente ad altri attributi/metodi del logger originale
    def __getattr__(self, name: str):
        return getattr(self._logger, name)

def get_logger(name: str) -> SafeLogger:
    """Restituisce un logger 'safe' che accetta kwargs arbitrari come extra."""
    return SafeLogger(logging.getLogger(name))

def bind_context(
    *,
    convo_id: Optional[str] = None,
    user_id: Optional[str] = None,
    route: Optional[str] = None,
    request_id: Optional[str] = None,
) -> None:
    """Imposta i context vars (thread/coroutine-local)."""
    if convo_id is not None:
        convo_id_var.set(str(convo_id))
    if user_id is not None:
        user_id_var.set(str(user_id))
    if route is not None:
        route_var.set(str(route))
    if request_id is not None:
        request_id_var.set(str(request_id))

def clear_context() -> None:
    """Resetta i context vars al default (utile nei test o ai confini di una request)."""
    convo_id_var.set("-")
    user_id_var.set("-")
    route_var.set("-")
    request_id_var.set("-")

def with_extra(logger: logging.Logger, **extra: Any):
    """
    Convenience per allegare extra a una singola riga:
        with_extra(log, component="kpi").info("computed", took_ms=12)
    """
    class _Proxy:
        def __init__(self, logger: logging.Logger, base: Dict[str, Any]) -> None:
            self._logger = logger
            self._base = base
        def _emit(self, level: int, msg: str, **kv: Any) -> None:
            data = dict(self._base)
            data.update(kv)
            self._logger.log(level, msg, extra=data)
        def debug(self, msg: str, **kv: Any) -> None: self._emit(logging.DEBUG, msg, **kv)
        def info(self, msg: str, **kv: Any) -> None: self._emit(logging.INFO, msg, **kv)
        def warning(self, msg: str, **kv: Any) -> None: self._emit(logging.WARNING, msg, **kv)
        def error(self, msg: str, **kv: Any) -> None: self._emit(logging.ERROR, msg, **kv)
        def critical(self, msg: str, **kv: Any) -> None: self._emit(logging.CRITICAL, msg, **kv)
    return _Proxy(logging.getLogger(logger.name if hasattr(logger, "name") else str(logger)), {k: _safe_json(v) for k, v in extra.items()})
