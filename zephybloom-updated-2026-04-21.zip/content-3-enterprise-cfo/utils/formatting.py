# -*- coding: utf-8 -*-
"""
Formattazione di valori numerici e stringhe per presentation layer.
Spostato da api/routes_*.py per consolidare logiche duplicate.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

from utils.coercion import safe_float, safe_str, safe_dict, safe_list


# =========================
# Numero → Stringa per UI
# =========================

def fmt_eur(x: float) -> str:
    """
    Formatta un importo in EUR con abbreviazioni intelligenti.
    
    Esempi:
      - 1.500.000 → "1.50 mln €"
      - 1.000 → "1.0 k€"
      - 100 → "100 €"
    """
    v = safe_float(x, 0.0)
    sign = "-" if v < 0 else ""
    v = abs(v)
    
    if v >= 1_000_000_000:
        return f"{sign}{v / 1_000_000_000:.2f} mld €"
    if v >= 1_000_000:
        return f"{sign}{v / 1_000_000:.2f} mln €"
    if v >= 1_000:
        return f"{sign}{v / 1_000:.1f} k€"
    return f"{sign}{v:,.0f} €".replace(",", ".")


def fmt_pct(x: float) -> str:
    """
    Formatta un decimale (0...1) come percentuale.
    
    Es:
      - 0.15 → "15.0%"
      - 0.025 → "2.5%"
    """
    try:
        return f"{float(x) * 100:.1f}%"
    except Exception:
        return "-"


def fmt_pct100(x: float) -> str:
    """
    Formatta un valore già in forma percento (es. 15.5 = 15.5%).
    
    Es:
      - 15.5 → "15.5%"
      - 2.3 → "2.3%"
    """
    try:
        return f"{float(x):.1f}%"
    except Exception:
        return "-"


def fmt_number(x: float, decimals: int = 2) -> str:
    """Formatta un numero generico con decimali specificati"""
    try:
        f = float(x)
        if not math.isfinite(f):
            return "-"
        return f"{f:.{decimals}f}".replace(",", ".")
    except Exception:
        return "-"


def fmt_bps(x: float) -> str:
    """Formatta in basis points (0.01% = 1 bps)"""
    try:
        return f"{float(x) * 10000:.0f} bps"
    except Exception:
        return "-"


# =========================
# Value → String per risposta
# =========================

def safe_value_str(v: Any) -> Optional[str]:
    """
    Converte un valore numerico a stringa EUR formattata.
    Ritorna None se il valore non è un numero finito.
    
    Tipicamente usato per ChatResponse.value_str.
    """
    if not isinstance(v, (int, float)):
        return None
    if not math.isfinite(float(v)):
        return None
    return fmt_eur(float(v))


# =========================
# Serializzazione Advisory/Sources
# =========================

def serialize_advisories(items: Any) -> List[Dict[str, Any]]:
    """
    Converte una lista di Advisory (dict, Pydantic model, obj) 
    in lista standardizzata di dict.
    
    Output schema:
      {
        "code": str,
        "title": str,
        "detail": str,
        "severity": str,  # "info" | "warning" | "critical"
        "suggestions": List[str]
      }
    """
    out: List[Dict[str, Any]] = []
    
    for a in items or []:
        if a is None:
            continue
        
        # Tentativo Pydantic model_dump() prima
        if hasattr(a, "model_dump"):
            try:
                d = a.model_dump()
                if isinstance(d, dict):
                    out.append({
                        "code": d.get("code", "INFO"),
                        "title": d.get("title", ""),
                        "detail": d.get("detail", ""),
                        "severity": d.get("severity", "info"),
                        "suggestions": safe_list(d.get("suggestions")) or [],
                    })
                    continue
            except Exception:
                pass
        
        # Se è un dict
        if isinstance(a, dict):
            out.append({
                "code": a.get("code", "INFO"),
                "title": a.get("title", ""),
                "detail": a.get("detail", ""),
                "severity": a.get("severity", "info"),
                "suggestions": safe_list(a.get("suggestions")) or [],
            })
            continue
        
        # Fallback: getattr
        out.append({
            "code": safe_str(getattr(a, "code", "INFO")),
            "title": safe_str(getattr(a, "title", "")),
            "detail": safe_str(getattr(a, "detail", "")),
            "severity": safe_str(getattr(a, "severity", "info")),
            "suggestions": safe_list(getattr(a, "suggestions", [])),
        })
    
    return out


def safe_sources(v: Any) -> Optional[List[Dict[str, Any]]]:
    """
    Valida una lista di source dict/models e ritorna una lista standardizzata.
    Ritorna None se lista è vuota o None.
    
    Output schema:
      {
        "title": str,
        "url": str,
        "relevance": float,  # 0...1
        ...
      }
    """
    if v is None:
        return None
    if not isinstance(v, list):
        return None
    
    out: List[Dict[str, Any]] = []
    for item in v:
        if isinstance(item, dict):
            out.append(item)
        elif hasattr(item, "model_dump"):
            try:
                d = item.model_dump()
                if isinstance(d, dict):
                    out.append(d)
            except Exception:
                continue
    
    return out if out else None


# =========================
# Alias per backward compatibility
# =========================

_fmt_eur = fmt_eur
_fmt_pct = fmt_pct
_fmt_pct100 = fmt_pct100
_safe_value_str = safe_value_str
_serialize_advisories = serialize_advisories
_safe_sources = safe_sources
