# -*- coding: utf-8 -*-
"""
Circuit Breaker per LLM API calls.

Previene cascading failures quando l'LLM (OpenAI, etc) è in problemi:
  - CLOSED: Normal operation, requests pass through
  - OPEN: Too many failures, requests fail immediately
  - HALF_OPEN: Testing if service recovered, limited requests allowed

Utilizzo:

    breaker = CircuitBreaker(
        failure_threshold=5,       # failures before opening
        recovery_timeout_s=60,     # seconds before trying again
        name="openai_api"
    )

    try:
        result = breaker.call(llm_provider.chat, messages=..., **kwargs)
    except CircuitBreakerOpenError:
        # Use fallback / return cached result / degraded mode
        return "Servizio temporaneamente non disponibile"
"""
from __future__ import annotations

import time
import threading
from enum import Enum
from typing import Callable, Any, TypeVar, Generic
from dataclasses import dataclass

from utils.errors import (
    LLMAppError,
    LLMRateLimitAppError,
    TimeoutAppError,
    ExternalServiceAppError,
    ServiceUnavailableAppError,
)


T = TypeVar("T")


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"          # Normal: requests pass through
    OPEN = "open"              # Failures exceeded: requests rejected immediately
    HALF_OPEN = "half_open"    # Testing recovery: limited requests allowed


class CircuitBreakerOpenError(Exception):
    """Circuit breaker is OPEN - service is down."""
    pass


@dataclass
class CircuitBreakerStats:
    """Statistiche di stato del circuit breaker."""
    state: CircuitState
    failure_count: int
    success_count: int
    last_failure_time: float | None
    opened_at: float | None
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "failures": self.failure_count,
            "successes": self.success_count,
            "last_error_ago_s": time.time() - self.last_failure_time if self.last_failure_time else None,
            "open_duration_s": time.time() - self.opened_at if self.opened_at else None,
        }


class CircuitBreaker(Generic[T]):
    """
    Thread-safe circuit breaker per external service calls.
    
    Args:
        failure_threshold: Numero di failure prima di aprire il circuit
        success_threshold: Numero di success in HALF_OPEN prima di chiudere
        recovery_timeout_s: Tempo (secondi) prima di passare da OPEN a HALF_OPEN
        name: Identificativo del breaker (logging)
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        success_threshold: int = 2,
        recovery_timeout_s: int = 60,
        name: str = "circuit_breaker",
    ):
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.recovery_timeout_s = recovery_timeout_s
        self.name = name
        
        # State
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: float | None = None
        self._opened_at: float | None = None
        
        # Thread safety
        self._lock = threading.RLock()
    
    def call(self, func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
        """
        Execute func with circuit breaker protection.
        
        Raises:
            CircuitBreakerOpenError: Se il breaker è OPEN
            Eccezione originale: Se func fallisce
        """
        with self._lock:
            state = self._state
            
            # Se OPEN e timeout non scaduto → rifiuta subito
            if state == CircuitState.OPEN:
                if not self._should_attempt_reset():
                    raise CircuitBreakerOpenError(
                        f"Circuit breaker '{self.name}' is OPEN. "
                        f"Retry in {self.recovery_timeout_s}s."
                    )
                # Timeout scaduto → passa a HALF_OPEN per test
                self._state = CircuitState.HALF_OPEN
                self._success_count = 0
        
        # Prova la chiamata (fuori dal lock per non bloccare troppo)
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure(e)
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if recovery timeout has elapsed."""
        if self._opened_at is None:
            return False
        elapsed = time.time() - self._opened_at
        return elapsed >= self.recovery_timeout_s
    
    def _on_success(self) -> None:
        """Handle successful call."""
        with self._lock:
            self._failure_count = 0
            
            if self._state == CircuitState.CLOSED:
                return  # Stay CLOSED
            
            # HALF_OPEN: count successes toward recovery
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    self._state = CircuitState.CLOSED
                    self._opened_at = None
    
    def _on_failure(self, exc: Exception) -> None:
        """Handle failed call."""
        with self._lock:
            self._last_failure_time = time.time()
            
            if self._state == CircuitState.OPEN:
                return  # Already open, don't increment
            
            if self._state == CircuitState.HALF_OPEN:
                # Fail in HALF_OPEN → reopen
                self._state = CircuitState.OPEN
                self._opened_at = time.time()
                self._success_count = 0
                return
            
            # CLOSED: count failures
            self._failure_count += 1
            if self._failure_count >= self.failure_threshold:
                self._state = CircuitState.OPEN
                self._opened_at = time.time()
    
    def get_state(self) -> CircuitBreakerStats:
        """Get current breaker state and stats."""
        with self._lock:
            return CircuitBreakerStats(
                state=self._state,
                failure_count=self._failure_count,
                success_count=self._success_count,
                last_failure_time=self._last_failure_time,
                opened_at=self._opened_at,
            )
    
    def reset(self) -> None:
        """Manually reset the circuit breaker to CLOSED."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._success_count = 0
            self._last_failure_time = None
            self._opened_at = None
    
    def __repr__(self) -> str:
        stats = self.get_state()
        return f"<CircuitBreaker {self.name} state={stats.state.value} failures={stats.failure_count}>"


# Global LLM circuit breaker (singleton)
_LLM_BREAKER: CircuitBreaker | None = None


def get_llm_breaker(
    failure_threshold: int = 5,
    recovery_timeout_s: int = 60,
) -> CircuitBreaker:
    """Get or create the global LLM circuit breaker."""
    global _LLM_BREAKER
    
    if _LLM_BREAKER is None:
        _LLM_BREAKER = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout_s=recovery_timeout_s,
            name="llm_api",
        )
    
    return _LLM_BREAKER


def reset_llm_breaker() -> None:
    """Reset the global LLM breaker. Useful for testing."""
    global _LLM_BREAKER
    if _LLM_BREAKER:
        _LLM_BREAKER.reset()
