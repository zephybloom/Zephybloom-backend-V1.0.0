# -*- coding: utf-8 -*-
# content/utils/validators.py — Normalizzazione & Validazione contratta (rate/pct, alias, invarianti)
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Iterable

from utils.fmt_parse import parse_number, parse_pct


# =========================
# Alias chiavi (normalizza)
# =========================
def _clean_key(k: str) -> str:
    """
    Normalizza il nome chiave prima del mapping:
    - lowercase
    - trim
    - spazi → underscore
    - dash → underscore
    """
    k = (k or "").strip().lower()
    k = k.replace("-", "_").replace(" ", "_")
    while "__" in k:
        k = k.replace("__", "_")
    return k


def _norm_key(k: str) -> str:
    k = _clean_key(k)

    alias_map = {
        # -------------------------
        # ricavi / vendite
        # -------------------------
        "vendite": "fatturato",
        "sales": "fatturato",
        "ricavi": "fatturato",
        "revenue": "fatturato",
        "turnover": "fatturato",
        "fatt": "fatturato",
        "fatturato_euro": "fatturato",
        "sales_eur": "fatturato",
        "revenues": "fatturato",

        # -------------------------
        # costi variabili / fissi
        # -------------------------
        "cv": "costi_variabili",
        "costi_var": "costi_variabili",
        "variabili": "costi_variabili",
        "variable_costs": "costi_variabili",
        "variable": "costi_variabili",
        "costi_variab": "costi_variabili",

        "cf": "costi_fissi",
        "costi_fix": "costi_fissi",
        "fissi": "costi_fissi",
        "fixed_costs": "costi_fissi",
        "fixed": "costi_fissi",
        "costi_fissi_totali": "costi_fissi",

        # -------------------------
        # investimenti / capex
        # -------------------------
        "capex": "investimenti",
        "invest": "investimenti",
        "capex_euro": "investimenti",
        "investimento": "investimenti",
        "investments": "investimenti",
        "investment": "investimenti",

        # -------------------------
        # unit economics
        # -------------------------
        "prezzo": "prezzo_medio",
        "price": "prezzo_medio",
        "avg_price": "prezzo_medio",
        "average_price": "prezzo_medio",
        "prezzo_medio_unitario": "prezzo_medio",

        "cvu": "costo_variabile_unitario",
        "unit_cost": "costo_variabile_unitario",
        "costo_unitario": "costo_variabile_unitario",
        "cvu_medio": "costo_variabile_unitario",
        "variable_unit_cost": "costo_variabile_unitario",

        # -------------------------
        # extra contabili
        # -------------------------
        "ammort": "ammortamenti",
        "depr": "ammortamenti",
        "depreciation": "ammortamenti",
        "depreciations": "ammortamenti",

        "cost_of_goods": "cogs",
        "cost_of_goods_sold": "cogs",
        "cost_of_goodssold": "cogs",
        "costo_del_venduto": "cogs",

        # -------------------------
        # working capital (giorni)
        # -------------------------
        "days_sales_outstanding": "dso",
        "giorni_incasso": "dso",
        "gg_incasso": "dso",

        "days_inventory_outstanding": "dio",
        "giorni_magazzino": "dio",
        "gg_magazzino": "dio",

        "days_payables_outstanding": "dpo",
        "giorni_pagamento": "dpo",
        "gg_pagamento": "dpo",

        # -------------------------
        # elasticità prezzo
        # -------------------------
        "elasticity": "price_elasticity",
        "elasticita": "price_elasticity",
        "elasticita_prezzo": "price_elasticity",
        "price_elasticity": "price_elasticity",

        # -------------------------
        # tax / rates
        # -------------------------
        "tasse": "tax_rate",
        "tax": "tax_rate",
        "taxrate": "tax_rate",
        "tax_rate_pct": "tax_rate",
        "aliquota": "tax_rate",
        "aliquota_fiscale": "tax_rate",
        "iva": "tax_rate",

        "discount_rate": "discount_rate_pct",
        "discount": "discount_rate_pct",
        "discount_pct": "discount_rate_pct",

        "growth_rate": "growth_rate_pct",
        "growth": "growth_rate_pct",
        "growth_pct": "growth_rate_pct",

        "terminal_growth": "terminal_growth_pct",
        "g_terminal": "terminal_growth_pct",
        "terminal_growth_rate": "terminal_growth_pct",

        # -------------------------
        # metriche legacy / growth
        # -------------------------
        "margin": "margin_pct",
        "margine": "margin_pct",
        "mc_pct": "mc_rate_pct",
        "price_change": "price_change_pct",

        "churn": "churn_rate",
        "churn_pct": "churn_rate",
        "gross_margin": "gross_margin_rate",
        "net_margin": "net_margin_rate",
    }

    return alias_map.get(k, k)


# =========================
# Regole percentuali/frazioni
# =========================

# Chiavi in PERCENT POINTS (0..100)
PERCENT_KEYS: set[str] = {
    "discount_rate_pct",
    "growth_rate_pct",
    "inflation_pct",
    "margin_pct",
    "mc_rate_pct",
    "price_change_pct",
    "terminal_growth_pct",
    "price_pct",
    "tax_rate",
    "roi_pct",
    "churn_pct",
}

# Chiavi RATE in frazione [0..1]
FRACTION_RATE_KEYS: set[str] = {
    "mc_rate",
    "gross_margin_rate",
    "net_margin_rate",
    "roi",
    "churn_rate",
}

# Chiavi che possono superare 1 pur essendo “rate-like”
# es. NRR = 1.10
FRACTION_OR_ABOVE_KEYS: set[str] = {
    "nrr",
}

# Chiavi intrinsecamente non negative
NONNEGATIVE_KEYS: set[str] = {
    "fatturato",
    "costi_variabili",
    "costi_fissi",
    "investimenti",
    "prezzo_medio",
    "costo_variabile_unitario",
    "cogs",
    "ammortamenti",
    "dso",
    "dio",
    "dpo",
    "tax_rate",
    "discount_rate_pct",
    "growth_rate_pct",
    "terminal_growth_pct",
    "mrr",
    "arpu",
    "ltv",
    "cac",
}


# =========================
# Parser interni
# =========================
def _parse_percent_points(x: Any) -> Optional[float]:
    """
    Interpreta x come punti percentuali:
    - '12%'  -> 12.0
    - '0,12' -> 12.0
    - '12'   -> 12.0
    """
    if x is None:
        return None
    v = parse_pct(x, as_fraction=False)
    return float(v) if v is not None else None


def _parse_fraction(x: Any) -> Optional[float]:
    """
    Interpreta x come frazione:
    - '12%'  -> 0.12
    - '0,12' -> 0.12
    - '12'   -> 0.12
    """
    if x is None:
        return None

    v_pct = parse_pct(x, as_fraction=True)
    if v_pct is not None:
        return float(v_pct)

    v = parse_number(x)
    if v is None:
        return None

    return float(v) if abs(v) <= 1.0 else float(v) / 100.0


def _parse_num(x: Any) -> Optional[float]:
    v = parse_number(x)
    return float(v) if v is not None else None


def _is_scalar_like(x: Any) -> bool:
    return isinstance(x, (str, int, float)) and not isinstance(x, bool)


# ======================================
# Clamp helpers
# ======================================
def clamp_rate01(v: Optional[float]) -> Optional[float]:
    """Clamp frazione a [0..1] (None passa)."""
    if v is None:
        return None
    try:
        return max(0.0, min(float(v), 1.0))
    except Exception:
        return None


def clamp_pct100(v: Optional[float]) -> Optional[float]:
    """Clamp punti percentuali a [0..100] (None passa)."""
    if v is None:
        return None
    try:
        return max(0.0, min(float(v), 100.0))
    except Exception:
        return None


def clamp_nonneg(v: Optional[float]) -> Optional[float]:
    """Clamp non-negativo (None passa)."""
    if v is None:
        return None
    try:
        return max(0.0, float(v))
    except Exception:
        return None


# ======================================
# Normalizzazione contesto
# ======================================
def normalize_context_numeric(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Converte un contesto eterogeneo in valori numerici puliti.

    Regole:
    - Alias chiave (vendite→fatturato, cv/cf, capex→investimenti, tax→tax_rate, …)
    - Numeri EU/EN con k/mln/mld/bn
    - Chiavi *_pct o in PERCENT_KEYS → punti percentuali clampate a [0..100]
    - FRACTION_RATE_KEYS → frazioni clampate a [0..1]
    - FRACTION_OR_ABOVE_KEYS → frazione, ma può restare >1 se coerente (es. NRR)
    - Chiavi non parseable scalari vengono preservate, così il contesto descrittivo non si perde
    - Valori bool/list/dict vengono ignorati
    """
    out: Dict[str, Any] = {}

    for raw_k, raw_v in (ctx or {}).items():
        if raw_v is None:
            continue

        k = _norm_key(str(raw_k))

        # scarta strutture complesse
        if isinstance(raw_v, (dict, list, tuple, set, bool)):
            continue

        # -------------------------
        # Percent points
        # -------------------------
        if k.endswith("_pct") or k in PERCENT_KEYS:
            v = _parse_percent_points(raw_v)
            if v is None:
                num = _parse_num(raw_v)
                if num is not None:
                    v = num * 100.0 if abs(num) <= 1.0 else num

            if v is not None:
                out[k] = clamp_pct100(float(v)) or 0.0
            elif _is_scalar_like(raw_v):
                out[k] = raw_v
            continue

        # -------------------------
        # Fractions [0..1]
        # -------------------------
        if k in FRACTION_RATE_KEYS or "_pct_per_" in k or k.endswith("_rate"):
            v = _parse_fraction(raw_v)
            if v is not None:
                out[k] = clamp_rate01(float(v)) or 0.0
            elif _is_scalar_like(raw_v):
                out[k] = raw_v
            continue

        # -------------------------
        # Fractions, ma possibili >1 (NRR)
        # -------------------------
        if k in FRACTION_OR_ABOVE_KEYS:
            v = _parse_fraction(raw_v)
            if v is not None:
                out[k] = float(v)
            elif _is_scalar_like(raw_v):
                out[k] = raw_v
            continue

        # -------------------------
        # Numeric default
        # -------------------------
        v = _parse_num(raw_v)
        if v is not None:
            if k in NONNEGATIVE_KEYS:
                out[k] = clamp_nonneg(float(v)) or 0.0
            else:
                out[k] = float(v)
        elif _is_scalar_like(raw_v):
            out[k] = raw_v

    return out


def normalize_context_numeric_clamped(ctx: Dict[str, Any]) -> Dict[str, float]:
    """
    Variante utile in punti più sensibili:
    normalizza e poi applica clamp coerenti alle principali famiglie di campi.
    """
    out = normalize_context_numeric(ctx)

    for k, v in list(out.items()):
        if k in FRACTION_RATE_KEYS:
            out[k] = clamp_rate01(v) or 0.0
        elif k in PERCENT_KEYS:
            out[k] = clamp_pct100(v) or 0.0
        elif k in NONNEGATIVE_KEYS:
            out[k] = clamp_nonneg(v) or 0.0

    return out


# ==========================
# Invarianti KPI
# ==========================
def validate_kpi_invariants(payload: Dict[str, float]) -> Tuple[bool, Dict[str, Any]]:
    """
    Valida le identità fondamentali dei KPI:
      - gross_margin == sales - cogs
      - gross_margin_rate == gross_margin / sales
      - ebitda == ebit + depreciation
      - break_even_revenue == break_even_qty * prezzo_medio

    Ritorna:
      (ok, diagnostics)
    """
    diag: Dict[str, Any] = {}
    ok = True

    sales = payload.get("sales", payload.get("fatturato"))
    cogs = payload.get("cogs", payload.get("costi_variabili"))
    gross_margin = payload.get("gross_margin", payload.get("margine_contribuzione"))
    gross_margin_rate = payload.get("gross_margin_rate", payload.get("mc_rate"))
    ebit = payload.get("ebit")
    ebitda = payload.get("ebitda")
    depreciation = payload.get("depreciation", payload.get("ammortamenti"))
    be_qty = payload.get("break_even_qty", payload.get("be_qty"))
    be_rev = payload.get("break_even_revenue", payload.get("be_revenue"))
    prezzo = payload.get("prezzo_medio")

    def _almost_eq(a: Optional[float], b: Optional[float], tol: float = 1e-6) -> bool:
        if a is None or b is None:
            return True
        try:
            af = float(a)
            bf = float(b)
        except Exception:
            return False
        return abs(af - bf) <= tol * (1.0 + max(abs(af), abs(bf)))

    # gross_margin == sales - cogs
    if sales is not None and cogs is not None and gross_margin is not None:
        expected = float(sales) - float(cogs)
        if not _almost_eq(gross_margin, expected):
            ok = False
            diag["gross_margin_identity"] = {
                "expected": expected,
                "got": gross_margin,
            }

    # gross_margin_rate == gross_margin / sales
    if sales is not None and gross_margin is not None and gross_margin_rate is not None:
        try:
            sf = float(sales)
            if sf > 0:
                expected_rate = float(gross_margin) / sf
                if not _almost_eq(gross_margin_rate, expected_rate):
                    ok = False
                    diag["gross_margin_rate_identity"] = {
                        "expected": expected_rate,
                        "got": gross_margin_rate,
                    }
        except Exception:
            ok = False
            diag["gross_margin_rate_identity"] = {
                "error": "unable_to_compute",
            }

    # ebitda == ebit + depreciation
    if ebit is not None and depreciation is not None and ebitda is not None:
        expected = float(ebit) + float(depreciation)
        if not _almost_eq(ebitda, expected):
            ok = False
            diag["ebitda_identity"] = {
                "expected": expected,
                "got": ebitda,
            }

    # break_even_revenue == break_even_qty * prezzo_medio
    if be_qty is not None and be_rev is not None and prezzo is not None:
        expected = float(be_qty) * float(prezzo)
        if not _almost_eq(be_rev, expected):
            ok = False
            diag["breakeven_identity"] = {
                "expected": expected,
                "got": be_rev,
            }

    return ok, diag


# ==========================
# Helpers utili extra
# ==========================
def pick_numeric_subset(ctx: Dict[str, Any], keys: Iterable[str]) -> Dict[str, float]:
    """
    Estrae e normalizza solo un sottoinsieme di chiavi.
    """
    raw = {k: ctx.get(k) for k in keys if k in ctx}
    return normalize_context_numeric(raw)


def merge_numeric_context(*chunks: Dict[str, Any]) -> Dict[str, float]:
    """
    Merge ordinato di più context:
    l'ultimo vince.
    """
    merged: Dict[str, Any] = {}
    for ch in chunks:
        if isinstance(ch, dict):
            merged.update(ch)
    return normalize_context_numeric(merged)


__all__ = [
    "normalize_context_numeric",
    "normalize_context_numeric_clamped",
    "clamp_rate01",
    "clamp_pct100",
    "clamp_nonneg",
    "validate_kpi_invariants",
    "pick_numeric_subset",
    "merge_numeric_context",
    "PERCENT_KEYS",
    "FRACTION_RATE_KEYS",
    "FRACTION_OR_ABOVE_KEYS",
    "NONNEGATIVE_KEYS",
]
