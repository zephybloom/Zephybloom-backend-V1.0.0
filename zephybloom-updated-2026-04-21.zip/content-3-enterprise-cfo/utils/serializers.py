# -*- coding: utf-8 -*-
# content/utils/serializers.py — Conversioni unità e rounding coerenti
from __future__ import annotations

def as_pct(rate_0_1: float) -> float:
    """0..1 -> 0..100"""
    if rate_0_1 is None:
        return 0.0
    return float(rate_0_1) * 100.0

def as_rate(pct_0_100: float) -> float:
    """0..100 -> 0..1"""
    if pct_0_100 is None:
        return 0.0
    return float(pct_0_100) / 100.0

def round_eur(x: float, nd: int = 2) -> float:
    return round(float(x or 0.0), nd)

def round_rate(x: float, nd: int = 4) -> float:
    return round(float(x or 0.0), nd)

def round_pct(x: float, nd: int = 1) -> float:
    return round(float(x or 0.0), nd)
