# -*- coding: utf-8 -*-
# content/utils/errors.py — Errori applicativi tipizzati (HTTP-friendly)
from __future__ import annotations

from typing import Any, Dict, Optional, Type


__all__ = [
    "AppError",
    "ValidationAppError",
    "NotFoundAppError",
    "UnauthorizedAppError",
    "ForbiddenAppError",
    "RateLimitAppError",
    "ConflictAppError",
    "ExternalServiceAppError",
    "TimeoutAppError",
    "ServiceUnavailableAppError",
    # Domain-specific errors
    "LLMAppError",
    "LLMRateLimitAppError",
    "CalculationAppError",
    "KnowledgeBaseAppError",
    "IntentMatchingAppError",
    # helper
    "from_exception",
]


class AppError(Exception):
    """
    Base class per errori applicativi.
    - code: stringa stabile usata dal client per branch logico
    - http_status: suggerimento di status HTTP
    - details: payload extra (serializzabile)
    - cause: eccezione originale opzionale (non serializzata)
    """
    code: str = "app_error"
    http_status: int = 400

    def __init__(self, message: str, *, details: Optional[Dict[str, Any]] = None, cause: Exception | None = None):
        super().__init__(message)
        self.message = message
        self.details: Dict[str, Any] = dict(details or {})
        self.cause = cause

    # --------- helpers fluenti ---------
    def with_status(self, status: int) -> "AppError":
        self.http_status = int(status)
        return self

    def with_details(self, details: Dict[str, Any]) -> "AppError":
        self.details.update(details or {})
        return self

    def add_detail(self, key: str, value: Any) -> "AppError":
        self.details[str(key)] = value
        return self

    # --------- serializzazione ---------
    def to_dict(self) -> Dict[str, Any]:
        return {"error": {"code": self.code, "message": self.message, "details": self.details}}

    def to_http(self) -> Dict[str, Any]:
        """
        Restituisce una struttura comoda per risposte HTTP:
          {"status": 4xx/5xx, "body": {...}}
        """
        return {"status": int(self.http_status), "body": self.to_dict()}

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.code}({self.http_status}): {self.message}"

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{self.__class__.__name__} code={self.code!r} http={self.http_status} message={self.message!r}>"


class ValidationAppError(AppError):
    code = "validation_error"
    http_status = 422


class NotFoundAppError(AppError):
    code = "not_found"
    http_status = 404


class UnauthorizedAppError(AppError):
    code = "unauthorized"
    http_status = 401


class ForbiddenAppError(AppError):
    code = "forbidden"
    http_status = 403


class RateLimitAppError(AppError):
    code = "rate_limited"
    http_status = 429


class ConflictAppError(AppError):
    code = "conflict"
    http_status = 409


class ExternalServiceAppError(AppError):
    code = "external_service_error"
    http_status = 502


class TimeoutAppError(AppError):
    code = "timeout"
    http_status = 504


class ServiceUnavailableAppError(AppError):
    code = "service_unavailable"
    http_status = 503


# =============================================================
# Domain-Specific Errors (Business Logic Layer)
# =============================================================

class LLMAppError(ExternalServiceAppError):
    """Errori durante operazioni LLM (OpenAI, modellazione, ecc)."""
    code = "llm_error"
    http_status = 502


class LLMRateLimitAppError(RateLimitAppError):
    """LLM ha raggiunto rate limit (dovrebbe attivare circuit breaker)."""
    code = "llm_rate_limited"
    http_status = 429


class CalculationAppError(AppError):
    """Errore durante calcoli finanziari (divisione per zero, etc)."""
    code = "calculation_error"
    http_status = 400


class KnowledgeBaseAppError(AppError):
    """Errore durante operazioni RAG/knowledge base."""
    code = "kb_error"
    http_status = 500


class IntentMatchingAppError(ValidationAppError):
    """Fallimento nel match di intent NLP."""
    code = "intent_not_found"
    http_status = 422


# ---------------------------
# Factory: mapping eccezioni → AppError
# ---------------------------
_EXCEPTION_MAP: Dict[Type[BaseException], Type[AppError]] = {
    KeyError: NotFoundAppError,
    PermissionError: ForbiddenAppError,
    TimeoutError: TimeoutAppError,
    ConnectionError: ExternalServiceAppError,
    ValueError: ValidationAppError,
}


def from_exception(exc: BaseException, *, default: Type[AppError] = AppError, message: str | None = None) -> AppError:
    """
    Converte un'eccezione generica in AppError tipizzato.
    Esempio d’uso:
        try:
            ...
        except Exception as e:
            raise from_exception(e).with_details({"component": "kpi"})
    """
    for exc_type, app_err in _EXCEPTION_MAP.items():
        if isinstance(exc, exc_type):
            return app_err(message or str(exc), cause=exc)
    return default(message or str(exc), cause=exc)
