"""
Type coercion utilities for safe numeric and container operations.

Provides centralized functions for converting and validating values with guard rails
against NaN, Inf, None, and type mismatches. All functions return safe defaults rather
than raising exceptions.

Key patterns:
- safe_float(x) → float with NaN/Inf handling
- safe_int(x) → int with fallback
- safe_dict/list(x) → coerce containers or return empty
- soft_fraction(x) → intelligent percentage normalization (0.5-1.5 as fraction, 5-150 as percent)
- ensure_finite(x) → raise ValueError if NaN/Inf
- clip01(x), nonneg(x), clamp(x, mn, mx) → numeric constraints

Backward compatibility aliases (_asf, _safe_dict, etc.) maintain compatibility with legacy code.
"""

import math
from typing import Any, Optional, TypeVar, Union

T = TypeVar('T')

# ==================== CORE NUMERIC COERCION ====================


def safe_float(value: Any, default: float = 0.0) -> float:
    """
    Convert value to float with robust NaN/Inf handling.
    
    Args:
        value: Input value (int, float, str, or anything)
        default: Fallback if conversion fails or result is NaN/Inf
        
    Returns:
        Valid float or default
        
    Examples:
        >>> safe_float(3.14)
        3.14
        >>> safe_float("2.5")
        2.5
        >>> safe_float(float('nan'))
        0.0
        >>> safe_float(None)
        0.0
    """
    try:
        f = float(value)
        # Replace NaN/Inf with default
        return f if math.isfinite(f) else default
    except (TypeError, ValueError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    """
    Convert value to int with fallback.
    
    Args:
        value: Input value
        default: Fallback if conversion fails
        
    Returns:
        Valid int or default
    """
    try:
        return int(float(value))  # Parse floats first (e.g., "3.5" → 3)
    except (TypeError, ValueError):
        return default


def is_finite(value: Any) -> bool:
    """
    Check if value is a finite number (not NaN, not Inf).
    
    Args:
        value: Value to check
        
    Returns:
        True if value is finite float/int, False otherwise
    """
    try:
        f = float(value)
        return math.isfinite(f)
    except (TypeError, ValueError):
        return False


def ensure_finite(value: Any, name: str = "value") -> float:
    """
    Convert to float and raise ValueError if not finite.
    
    Used for strict validation where NaN/Inf is an error condition.
    
    Args:
        value: Input value
        name: Parameter name for error message
        
    Returns:
        Finite float
        
    Raises:
        ValueError: If value is NaN, Inf, or cannot convert to number
    """
    f = safe_float(value, default=None)
    if f is None or not math.isfinite(f):
        raise ValueError(f"{name} must be a finite number, got {value}")
    return f


# ==================== CONTAINER COERCION ====================


def safe_dict(value: Any, default: Optional[dict] = None) -> dict:
    """
    Coerce value to dict or return empty dict.
    
    Args:
        value: Value to coerce (dict, or anything with .items())
        default: Fallback (default: {})
        
    Returns:
        dict instance
    """
    if isinstance(value, dict):
        return value
    if default is None:
        default = {}
    try:
        return dict(value)
    except (TypeError, ValueError):
        return default


def safe_list(value: Any, default: Optional[list] = None) -> list:
    """
    Coerce value to list or return empty list.
    
    Args:
        value: Value to coerce (list, iterable, or single item)
        default: Fallback (default: [])
        
    Returns:
        list instance
    """
    if isinstance(value, list):
        return value
    if default is None:
        default = []
    try:
        if isinstance(value, (str, dict)):
            # Don't iterate over string chars or dict keys
            raise TypeError()
        return list(value)
    except (TypeError, ValueError):
        return default


# ==================== NUMERIC CONSTRAINTS ====================


def nonneg(value: Any, default: float = 0.0) -> float:
    """
    Convert to float and enforce non-negative constraint.
    
    Args:
        value: Input value
        default: Fallback if conversion fails
        
    Returns:
        max(0, safe_float(value))
    """
    f = safe_float(value, default=default)
    return max(0.0, f)


def clip01(value: Any, default: float = 0.0) -> float:
    """
    Clamp value to [0, 1] range.
    
    Useful for percentages, probabilities, weights.
    
    Args:
        value: Input value
        default: Fallback if conversion fails
        
    Returns:
        Value clamped to [0.0, 1.0]
    """
    f = safe_float(value, default=default)
    return max(0.0, min(1.0, f))


def clamp(value: Any, minimum: float, maximum: float, default: float = 0.0) -> float:
    """
    Clamp value to [minimum, maximum] range.
    
    Args:
        value: Input value
        minimum: Lower bound
        maximum: Upper bound
        default: Fallback if conversion fails
        
    Returns:
        Value clamped to range
    """
    f = safe_float(value, default=default)
    return max(minimum, min(maximum, f))


# ==================== SPECIAL CONVERSIONS ====================


def soft_fraction(value: Any, default: float = 0.0) -> float:
    """
    Intelligently convert value to fraction with automatic percentage detection.
    
    Heuristic:
    - Values in range [0.0, 1.5] → treated as fractions (0.35 = 35%)
    - Values in range (1.5, 150+] → treated as percentages (35 = 35%, converted to 0.35)
    - Values outside range → clamped to [0, 1]
    
    Use case: User input "35" or "0.35" both become the same 0.35 fraction.
    
    Args:
        value: Numeric value (int, float, or str)
        default: Fallback
        
    Returns:
        Value in [0, 1] range
        
    Examples:
        >>> soft_fraction(0.35)  # Fraction
        0.35
        >>> soft_fraction(35)    # Percentage
        0.35
        >>> soft_fraction("35%") # Percentage string (% stripped by caller)
        0.35
        >>> soft_fraction(2.5)   # Out of range, clamped
        1.0
    """
    f = safe_float(value, default=None)
    if f is None:
        return default
    
    # Heuristic: values > 1.5 are likely percentages
    if f > 1.5:
        f = f / 100.0
    
    # Clamp to [0, 1]
    return clip01(f, default=default)


# ==================== STRING COERCION ====================


def safe_str(value: Any, default: str = "") -> str:
    """
    Convert value to string with fallback.
    
    Args:
        value: Input value
        default: Fallback if conversion fails or value is None
        
    Returns:
        String representation or default
        
    Examples:
        >>> safe_str(123)
        "123"
        >>> safe_str(3.14)
        "3.14"
        >>> safe_str(None)
        ""
        >>> safe_str([1, 2], default="N/A")
        "[1, 2]"
    """
    if value is None:
        return default
    try:
        return str(value)
    except (TypeError, ValueError):
        return default


# ==================== BACKWARD COMPATIBILITY ALIASES ====================
# Legacy function names for existing code using _asf, _safe_dict, etc.

_asf = safe_float  # Type alias for legacy code
_safe_int = safe_int
_safe_dict = safe_dict
_safe_list = safe_list
_finite_or_zero = lambda x: safe_float(x, default=0.0)  # Legacy pattern


__all__ = [
    "safe_float",
    "safe_int",
    "safe_dict",
    "safe_list",
    "safe_str",
    "is_finite",
    "ensure_finite",
    "nonneg",
    "clip01",
    "clamp",
    "soft_fraction",
    # Backward compatibility aliases
    "_asf",
    "_safe_int",
    "_safe_dict",
    "_safe_list",
    "_finite_or_zero",
]
