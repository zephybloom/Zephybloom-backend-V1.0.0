# -*- coding: utf-8 -*-
# content/utils/math_utils.py — safe math helpers (scalato)
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_EVEN, getcontext
import math
from typing import List, Union

Number = Union[int, float]

__all__ = [
    "safe_div",
    "pct",
    "clamp",
    "bankers_round",
    "almost_equal",
    "rolling_mean",
    "ewma",
    "median",
    "variance",
    "stddev",
    "holt_winters_additive",
]

# -----------------------------
# Safe arithmetic
# -----------------------------
def safe_div(num: Number | None, den: Number | None, default: float = 0.0) -> float:
    """
    Divisione sicura: se den≈0, NaN o None → default.
    Usa isclose sul denominatore per robustezza numerica.
    """
    try:
        if num is None or den is None:
            return float(default)
        n = float(num)
        d = float(den)
        if not (math.isfinite(n) and math.isfinite(d)) or math.isclose(d, 0.0, abs_tol=1e-12):
            return float(default)
        return n / d
    except Exception:
        return float(default)


def pct(part: Number | None, total: Number | None, default: float = 0.0) -> float:
    """
    Percentuale in punti (0..100). Esempio: pct(20, 80) -> 25.0
    """
    try:
        if part is None or total is None:
            return float(default)
        n = float(part) * 100.0
        d = float(total)
        if not (math.isfinite(n) and math.isfinite(d)) or math.isclose(d, 0.0, abs_tol=1e-12):
            return float(default)
        return n / d
    except Exception:
        return float(default)


def clamp(x: Number | None, low: Number | None, high: Number | None) -> float:
    """
    Limita x nell'intervallo [low, high].
    Se low/high sono None, il lato corrispondente è illimitato.
    """
    try:
        v = float(x) if x is not None else 0.0
        if not math.isfinite(v):
            return 0.0
        if low is not None:
            v = max(float(low), v)
        if high is not None:
            v = min(float(high), v)
        return float(v)
    except Exception:
        return 0.0


def bankers_round(x: Number, ndigits: int = 0) -> float:
    """
    Round half-to-even (bancario): utile in finance/reporting.
    """
    try:
        getcontext().rounding = ROUND_HALF_EVEN
        q = Decimal(str(float(x))).quantize(Decimal(1).scaleb(-int(ndigits)))
        return float(q)
    except Exception:
        return round(float(x), int(ndigits))


def almost_equal(a: Number, b: Number, tol: float = 1e-9) -> bool:
    """Confronto con tolleranza assoluta."""
    try:
        return math.isclose(float(a), float(b), rel_tol=0.0, abs_tol=float(tol))
    except Exception:
        return False


# -----------------------------
# Statistiche semplici
# -----------------------------
def rolling_mean(arr: List[Number], window: int = 3) -> float:
    if not arr:
        return 0.0
    w = max(1, min(int(window), len(arr)))
    vals = [float(x) for x in arr[-w:] if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not vals:
        return 0.0
    return float(sum(vals)) / float(len(vals))


def ewma(arr: List[Number], alpha: float = 0.3) -> float:
    if not arr:
        return 0.0
    try:
        a = float(alpha)
    except Exception:
        a = 0.3
    a = min(max(a, 0.0), 1.0)
    vals = [float(x) for x in arr if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not vals:
        return 0.0
    v = vals[0]
    for x in vals[1:]:
        v = a * x + (1.0 - a) * v
    return float(v)


def median(arr: List[Number]) -> float:
    vals = [float(x) for x in arr if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not vals:
        return 0.0
    s = sorted(vals)
    n = len(s)
    m = n // 2
    return float(s[m]) if n % 2 else float((s[m - 1] + s[m]) / 2.0)


def variance(arr: List[Number]) -> float:
    """
    Varianza popolazione (non corretta). Per varianza campionaria usa n-1.
    """
    vals = [float(x) for x in arr if isinstance(x, (int, float)) and math.isfinite(float(x))]
    n = len(vals)
    if n == 0:
        return 0.0
    m = sum(vals) / float(n)
    return float(sum((x - m) ** 2 for x in vals) / float(n))


def stddev(arr: List[Number]) -> float:
    v = variance(arr)
    return math.sqrt(v) if v >= 0.0 else 0.0


# -----------------------------
# Holt-Winters (additivo, senza stagionalità)
# -----------------------------
def holt_winters_additive(series: List[Number], alpha: float = 0.35, beta: float = 0.15, periods: int = 6) -> List[float]:
    """
    Trend additivo (L,B). Restituisce `periods` valori futuri.
    - Se serie troppo corta/degenerata, ritorna estensione dell’ultimo valore.
    - alpha/beta clampati in [0,1].
    """
    p = max(1, min(int(periods or 1), 120))  # guard-rail runtime
    if not series:
        return [0.0] * p

    # Filtra non numerici/Inf/NaN
    s = [float(x) for x in series if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not s:
        return [0.0] * p
    if len(s) == 1:
        return [s[-1]] * p

    a = min(max(float(alpha), 0.0), 1.0)
    b = min(max(float(beta), 0.0), 1.0)

    # Inizializzazione semplice
    L = s[0]
    B = s[1] - s[0]

    for x in s:
        L_prev = L
        L = a * x + (1.0 - a) * (L + B)
        B = b * (L - L_prev) + (1.0 - b) * B

    return [L + (i + 1) * B for i in range(p)]
