# -*- coding: utf-8 -*-
# content/utils/fmt_parse.py — Parse/format numeri stile EU (k/M/B, virgola it, %, €)
from __future__ import annotations

import math
import re
import unicodedata
from typing import Optional, Tuple, Dict, Any, Iterable

__all__ = [
    "normalize_whitespace",
    "normalize_text",
    "strip_currency",
    "parse_number",
    "parse_eur",
    "parse_pct",
    "to_number",
    "safe_float",
    "fmt_int",
    "fmt_kmb",
    "fmt_eur",
    "fmt_pct",
    "fmt_number_eu",
    "fmt_eur_or_nd",
    # alias retro-compatibilità
    "parse_money",
    "parse_percent",
    "parse_importo",
    # helper
    "guess_number_or_pct",
    "coerce_context_numbers",
]

# ----------------------------------------------------------------------
# Normalizzazioni base
# ----------------------------------------------------------------------

NBSP = "\u00A0"
NNBSP = "\u202F"

_CURRENCY_SIGNS = r"[€$£¥₽₺₹]"
_CURRENCY_WORDS = [
    # EUR
    "eur", "euro", "euri",
    # USD
    "usd", "dollari", "dollaro", "dollars", "dollar",
    # GBP
    "gbp", "sterline", "sterlina", "pound", "pounds",
    # JPY
    "yen", "jpy",
    # CHF / altri
    "chf", "franchi", "franco",
    "cad", "aud",
]

_CURRENCY_WORDS_RE = re.compile(
    r"\b(" + "|".join(map(re.escape, _CURRENCY_WORDS)) + r")\b",
    flags=re.IGNORECASE,
)

# Token testuali di percentuale
_PERCENT_WORDS_RE = re.compile(
    r"\b(percento|percentuale|perc\.?)\b",
    flags=re.IGNORECASE,
)

# Sostituzioni “sporche”
_DASH_TRANSLATION = str.maketrans({
    "\u2013": "-",  # en dash
    "\u2014": "-",  # em dash
    "\u2212": "-",  # minus sign
    "\u2019": "'",  # apostrofo smart
    "\u2018": "'",
    "\uff05": "%",  # full width percent
})


def normalize_whitespace(s: str) -> str:
    """Comprimi spazi e NBSP in singoli spazi."""
    if not s:
        return ""
    s = str(s).replace(NBSP, " ").replace(NNBSP, " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def normalize_text(s: str) -> str:
    """
    Normalizza testo per matching robusto:
    - minuscole
    - rimozione accenti/diacritici
    - conserva solo [a-z0-9] e spazi
    - comprime spazi multipli

    Esempio:
      "Fatturató Prezzi!!! 2,0 Mln" -> "fatturato prezzi 2 0 mln"
    """
    if not s:
        return ""
    s = str(s).translate(_DASH_TRANSLATION).lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def strip_currency(s: str) -> str:
    """Rimuove simboli e parole di valuta comuni lasciando numeri e suffissi."""
    if not s:
        return ""
    s = str(s)
    s = re.sub(_CURRENCY_SIGNS, " ", s)
    s = _CURRENCY_WORDS_RE.sub(" ", s)
    return normalize_whitespace(s)


def _normalize_numeric_text(s: str) -> str:
    """Normalizzazione generica per parsing numerico."""
    if not s:
        return ""
    s = str(s).translate(_DASH_TRANSLATION)
    s = s.replace(NBSP, " ").replace(NNBSP, " ")
    s = strip_currency(s)
    s = _PERCENT_WORDS_RE.sub("%", s)
    s = re.sub(r"\s*%\s*", "%", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


# ----------------------------------------------------------------------
# Parser numerici
# ----------------------------------------------------------------------

_MULT_ALTERNATIVES = r"(?:miliardi|mld|billion|bn|milioni|mln|mil|thousand|[kKmMbB])"
_PERC_ALTERNATIVES = r"(?:%|\bpercento\b|\bperc\.\b|\bpercentuale\b)"

_NUMBER_RE = re.compile(
    rf"""
    (?P<sign>[+-])?
    \s*
    (?P<int>\d{{1,3}}(?:[.\s,]\d{{3}})*|\d+)?
    (?P<dec>[.,]\d+)?
    \s*
    (?P<mult>{_MULT_ALTERNATIVES})?
    \s*
    (?P<perc>{_PERC_ALTERNATIVES})?
    """,
    flags=re.VERBOSE | re.IGNORECASE,
)

# pattern “chiaro” per trovare il blocco numerico utile
_STRICT_NUMERIC_TOKEN = re.compile(
    rf"""
    [+-]?
    (?:
        \d{{1,3}}(?:[.\s,]\d{{3}})+(?:[.,]\d+)? |
        \d+(?:[.,]\d+)?
    )
    (?:\s*(?:{_MULT_ALTERNATIVES}))?
    (?:\s*(?:{_PERC_ALTERNATIVES}))?
    """,
    flags=re.VERBOSE | re.IGNORECASE,
)

_MULTIPLIERS: Dict[str, float] = {
    "k": 1e3,
    "m": 1e6,
    "b": 1e9,
    "mln": 1e6,
    "milioni": 1e6,
    "mil": 1e6,
    "mld": 1e9,
    "miliardi": 1e9,
    "billion": 1e9,
    "bn": 1e9,
    "thousand": 1e3,
}


def _is_thousands_sep_style(s: str, sep: str) -> bool:
    """
    True se la stringa sembra usare `sep` come separatore delle migliaia.
    Esempi:
      "1.234" -> '.' True
      "1,234" -> ',' True
      "12.34" -> False
    """
    if sep not in s:
        return False
    parts = s.split(sep)
    if len(parts) < 2:
        return False
    if not parts[0].isdigit() or len(parts[0]) > 3:
        return False
    return all(p.isdigit() and len(p) == 3 for p in parts[1:])


def _normalize_core_number(core: str) -> Optional[str]:
    """
    Converte una rappresentazione EU/EN/sporca in stringa float-compatibile con '.'
    come separatore decimale.
    """
    if not core:
        return None

    core = core.strip().replace(" ", "")

    # caso con sia '.' che ','
    if "." in core and "," in core:
        # scegli l'ultimo come decimale, l'altro come migliaia
        last_dot = core.rfind(".")
        last_comma = core.rfind(",")
        if last_comma > last_dot:
            # 1.234,56 -> 1234.56
            core = core.replace(".", "")
            core = core.replace(",", ".")
        else:
            # 1,234.56 -> 1234.56
            core = core.replace(",", "")
        return core

    # solo virgola
    if "," in core:
        if _is_thousands_sep_style(core, ","):
            return core.replace(",", "")
        # altrimenti assumi virgola decimale
        return core.replace(",", ".")

    # solo punto
    if "." in core:
        if _is_thousands_sep_style(core, "."):
            return core.replace(".", "")
        return core

    return core


def _to_float_from_groups(g: Dict[str, Optional[str]]) -> Optional[float]:
    """Converte i gruppi regex in float, rispettando stile italiano/ibrido."""
    if not g:
        return None

    sign = -1.0 if (g.get("sign") or "") == "-" else 1.0
    int_part = (g.get("int") or "").strip()
    dec_part = (g.get("dec") or "").strip()

    if not int_part and not dec_part:
        return None

    # ricostruisci token centrale grezzo
    raw_core = f"{int_part}{dec_part}"
    core = _normalize_core_number(raw_core)
    if core is None:
        return None

    try:
        base = float(core)
    except Exception:
        return None

    mult_raw = (g.get("mult") or "").strip().lower()
    mult = _MULTIPLIERS.get(mult_raw, 1.0) if mult_raw else 1.0

    return sign * base * mult


def _has_percent_token(g: Dict[str, Optional[str]]) -> bool:
    return bool(g.get("perc"))


def _extract_numeric_token(txt: str) -> Optional[str]:
    """
    Estrae il token numerico più plausibile dalla stringa.
    Preferisce match strutturati.
    """
    if not txt:
        return None
    m = _STRICT_NUMERIC_TOKEN.search(txt)
    if m:
        return m.group(0).strip()

    m2 = _NUMBER_RE.search(txt)
    if m2:
        return m2.group(0).strip()

    return None


def parse_number(s: Any) -> Optional[float]:
    """
    Parser numerico robusto:
      - "2.0M", "600k", "1,5 mln", "-2,3 mld", "1 bn"
      - "€ 3.200,50", "10", "0,12", "1,234.56"
      - ignora % come semantica percentuale (quello è compito di parse_pct)

    Ritorna float o None.
    """
    if s is None:
        return None

    if isinstance(s, bool):
        return None

    if isinstance(s, (int, float)):
        try:
            v = float(s)
            return v if math.isfinite(v) else None
        except Exception:
            return None

    txt = _normalize_numeric_text(str(s))
    if not txt:
        return None

    token = _extract_numeric_token(txt)
    if not token:
        # fallback semplice
        simple = txt.replace("%", "").strip()
        if not simple:
            return None
        simple_norm = _normalize_core_number(simple)
        if simple_norm is None:
            return None
        try:
            v = float(simple_norm)
            return v if math.isfinite(v) else None
        except Exception:
            return None

    m = _NUMBER_RE.search(token)
    if not m:
        return None

    g = m.groupdict()
    val = _to_float_from_groups(g)
    if val is None or not math.isfinite(val):
        return None
    return val


def parse_eur(s: Any) -> Optional[float]:
    """Parsing comodo per importi in euro (accetta simboli/parole)."""
    return parse_number(s)


def parse_pct(s: Any, *, as_fraction: bool = False) -> Optional[float]:
    """
    Parsing percentuali.

    Se as_fraction=False:
      "12%"   -> 12.0
      "1,5%"  -> 1.5
      "0,12"  -> 12.0
      "0.35"  -> 35.0
      "35"    -> 35.0

    Se as_fraction=True:
      "12%"   -> 0.12
      "1,5%"  -> 0.015
      "0,12"  -> 0.12
      "0.35"  -> 0.35
      "35"    -> 0.35
    """
    if s is None:
        return None

    txt = _normalize_numeric_text(str(s))
    if not txt:
        return None

    token = _extract_numeric_token(txt)
    has_pct = "%" in txt

    # prova a capire anche dai gruppi regex
    if token:
        m = _NUMBER_RE.search(token)
        if m:
            has_pct = has_pct or _has_percent_token(m.groupdict())

    val = parse_number(txt)
    if val is None:
        return None

    if as_fraction:
        if has_pct:
            return val / 100.0
        return val if abs(val) <= 1.0 else val / 100.0

    # punti percentuali
    if has_pct:
        return val
    return val * 100.0 if abs(val) <= 1.0 else val


# Retro-compatibilità
parse_money = parse_eur
parse_percent = parse_pct
parse_importo = parse_eur


def to_number(x: Any, default: float = 0.0) -> float:
    """Coercizione sicura a float, con default."""
    v = parse_number(x)
    try:
        return float(v) if v is not None else float(default)
    except Exception:
        return float(default)


def safe_float(x: Any, default: float = 0.0) -> float:
    """Alias di to_number (retro-compat)."""
    return to_number(x, default=default)


# ----------------------------------------------------------------------
# Formatter (stile it-IT)
# ----------------------------------------------------------------------
def _format_it_number(n: float, decimals: int = 0) -> str:
    """
    Formatta numero stile italiano:
      - separatore migliaia = "."
      - separatore decimali = ","
    """
    if decimals < 0:
        decimals = 0

    sign = "-" if float(n) < 0 else ""
    n = abs(float(n))

    q = f"{n:.{decimals}f}"  # en format
    intp, frac = (q.split(".") + [""])[:2]

    intp_rev = intp[::-1]
    parts = [intp_rev[i:i + 3] for i in range(0, len(intp_rev), 3)]
    intp_fmt = ".".join(p[::-1] for p in parts[::-1])

    if decimals > 0:
        return f"{sign}{intp_fmt},{frac}"
    return f"{sign}{intp_fmt}"


def fmt_int(n: Any) -> str:
    """Intero con separatori italiani."""
    try:
        v = int(round(float(n)))
    except Exception:
        return "0"
    return _format_it_number(v, 0)


def fmt_kmb(n: Any, *, decimals: int = 1, italian_suffix: bool = True) -> str:
    """
    Compatta con suffissi:
      - se italian_suffix=True: k, mln, mld
      - altrimenti: k, M, B
    """
    try:
        v = float(n)
        if not math.isfinite(v):
            return "0"
    except Exception:
        return "0"

    abs_v = abs(v)
    if abs_v >= 1e9:
        base = v / 1e9
        suf = "mld" if italian_suffix else "B"
    elif abs_v >= 1e6:
        base = v / 1e6
        suf = "mln" if italian_suffix else "M"
    elif abs_v >= 1e3:
        base = v / 1e3
        suf = "k"
    else:
        return _format_it_number(v, 0)

    num = _format_it_number(base, decimals)
    return f"{num} {suf}"


def fmt_eur(
    n: Any,
    decimals: int = 0,
    symbol: str = "€",
    symbol_first: bool = True,
    space: str = " ",
) -> str:
    """
    Formatta importi in stile IT:
      - Compat: fmt_eur(val, decimals=0, symbol="€")
      - Opzioni extra: symbol_first / space
    """
    try:
        v = float(n)
        if not math.isfinite(v):
            v = 0.0
    except Exception:
        v = 0.0

    s = _format_it_number(v, decimals)
    if symbol_first:
        return f"{symbol}{space}{s}"
    return f"{s}{space}{symbol}"


def fmt_pct(x: Any, *, decimals: int = 1, assume_fraction: bool = False) -> str:
    """
    Formatta percentuali:
      - se assume_fraction=True: 0.123 -> "12,3%"
      - altrimenti: 12.3 -> "12,3%"
    """
    try:
        v = float(x)
        if not math.isfinite(v):
            v = 0.0
    except Exception:
        v = 0.0

    if assume_fraction and abs(v) <= 1.0:
        v = v * 100.0

    s = _format_it_number(v, decimals)
    return f"{s}%"


def fmt_number_eu(value: Optional[float], decimals: int = 2) -> str:
    return _format_it_number(float(value), decimals) if value is not None else "n/d"


def fmt_eur_or_nd(value: Optional[float], decimals: int = 2) -> str:
    return fmt_eur(value, decimals=decimals) if value is not None else "n/d"


# ----------------------------------------------------------------------
# Helper opzionali
# ----------------------------------------------------------------------
def guess_number_or_pct(s: Any) -> Tuple[Optional[float], bool]:
    """
    Prova a capire se la stringa rappresenta un numero o una percentuale.
    Ritorna (valore, is_percent).

    Il valore torna come punti percentuali se is_percent=True.
    """
    if s is None:
        return None, False

    txt = _normalize_numeric_text(str(s))
    if not txt:
        return None, False

    is_pct = "%" in txt or bool(_PERCENT_WORDS_RE.search(txt))

    val = parse_pct(txt, as_fraction=False) if is_pct else parse_number(txt)
    return val, is_pct


def coerce_context_numbers(d: Dict[str, Any], keys: Iterable[str]) -> Dict[str, float]:
    """
    Converte un sottoinsieme di chiavi di un dict in float con parse_number.
    Utile per normalizzare il context in entrata.
    """
    out: Dict[str, float] = {}
    for k in keys:
        out[str(k)] = to_number(d.get(k), 0.0)
    return out